cwd=/Users/pankajdoharey/Development/Projects/janet
argv=/tmp/janet-next-baseline-3ae1e1a8/build/bender test/suite-proc-capture-locality.janet
env=JANET_LANES=2 JANET_NO_PROFILE=1
timeout=10
