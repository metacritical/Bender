# Trinecraft material recipes, format version 1. Edit colors as RGBA byte tuples.
# Optional per-recipe fields: :brightness 0..2, :grain-density 0..16,
# :pixel-size 1..64 (integer). Missing controls default to 1.
# Missing or invalid individual recipes fall back to builtins on load.
{:version 1
 :recipes { :stone {:version 1 :kind :noise :base [126 128 130 255] :dark [93 97 100 255] :light [158 160 157 255] :scale 4 :seed 1}
   :dirt {:version 1 :kind :noise :base [125 85 52 255] :dark [94 60 38 255] :light [153 108 68 255] :scale 5 :seed 2}
   :grass {:version 1 :kind :speckle :base [83 159 59 255] :dark [49 123 43 255] :light [111 184 72 255] :scale 1 :seed 3}
   :sand {:version 1 :kind :speckle :base [221 207 145 255] :dark [191 174 114 255] :light [240 227 173 255] :scale 1 :seed 5}
   :water {:version 1 :kind :wave :base [55 116 190 255] :dark [36 88 156 255] :light [85 151 211 255] :scale 5 :seed 6}
   :wood {:version 1 :kind :grain :base [136 94 51 255] :dark [90 56 29 255] :light [163 119 67 255] :scale 5 :seed 7}
   :leaves {:version 1 :kind :voronoi :base [48 113 48 255] :dark [30 79 36 255] :light [69 141 57 255] :scale 5 :seed 8}
   :snow {:version 1 :kind :speckle :base [232 238 246 255] :dark [206 216 232 255] :light [246 250 255 255] :scale 2 :seed 11}
   :masonry {:version 1 :kind :brick :base [153 85 66 255] :dark [82 75 70 255] :light [185 112 86 255] :scale 8 :seed 9}
   :tiles {:version 1 :kind :checker :base [180 180 170 255] :dark [80 85 90 255] :light [220 220 210 255] :scale 4 :seed 10}}}
