# Renderer appearance settings, version 1.
# Water look: wave strength, ripples, glint, transparency and underwater
# caustics. Missing file uses the reference-inspired defaults.
{:version 1
 :water-detail-distance 55
 :water-normal-strength 0.45
 :water-specular-power 96
 :water-specular-strength 0.9
 :water-fresnel-strength 0.55
 :water-ripple-strength 1
 :water-alpha-shallow 0.55
 :water-alpha-deep 0.88
 :water-alpha-fresnel 0.35
 :water-alpha-cap 0.95
 :caustic-strength 0.55
 :underwater-tint-strength 0.78
}
