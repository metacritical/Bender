# Inert, versioned renderer appearance data. No GL or game dependency.
(def version 1)
(def defaults
  {:version 1 :water-detail-distance 55.0 :water-normal-strength 0.45
   :water-specular-power 96.0 :water-specular-strength 0.9
   :water-fresnel-strength 0.55 :water-ripple-strength 1.0
   :water-alpha-shallow 0.55 :water-alpha-deep 0.88
   :water-alpha-fresnel 0.35 :water-alpha-cap 0.95
   :caustic-strength 0.55 :underwater-tint-strength 0.78})
(def ranges
  {:water-detail-distance [1 128] :water-normal-strength [0 1]
   :water-specular-power [1 256] :water-specular-strength [0 2]
   :water-fresnel-strength [0 1] :water-ripple-strength [0 2]
   :water-alpha-shallow [0 1] :water-alpha-deep [0 1]
   :water-alpha-fresnel [0 1] :water-alpha-cap [0 1]
   :caustic-strength [0 2] :underwater-tint-strength [0 1]})
(defn validate [data]
  (and (or (table? data) (struct? data))
       (= (get data :version) version)
       (= (length (keys data)) (length (keys defaults)))
       (every? (map (fn [[key bounds]]
                      (let [value (get data key)]
                        (and (number? value) (>= value (bounds 0))
                             (<= value (bounds 1))))) (pairs ranges)))))
(defn- parse-data [text]
  (let [p (parser/new)]
    (parser/consume p text)
    (parser/eof p)
    (when (= (parser/status p) :error) (error "invalid appearance data syntax"))
    (when (not (parser/has-more p)) (error "empty appearance data"))
    (let [value (get (parser/produce p true) 0)]
      (when (parser/has-more p) (error "appearance data must contain one form"))
      (when (not (validate value)) (error "unsupported appearance version or values"))
      value)))
(defn load [&opt path]
  "Missing file uses builtins; invalid or unreadable file throws."
  (let [path (or path "data/appearance.janet")
        f (file/open path :rb)]
    (if (nil? f)
      (if (os/stat path) (error "cannot read appearance file") defaults)
      (let [text (try (file/read f :all)
                      ([err] (file/close f) (error err)))]
        (file/close f)
        (parse-data text)))))

(def setting-order
  [:water-detail-distance :water-normal-strength :water-specular-power
   :water-specular-strength :water-fresnel-strength :water-ripple-strength
   :water-alpha-shallow :water-alpha-deep :water-alpha-fresnel :water-alpha-cap
   :caustic-strength :underwater-tint-strength])

(defn- num
  "Render one value compactly: integers without a decimal tail, floats short.

  %j prints 0.94999999999999996 for what the author wrote as 0.95, which makes
  a hand-edited settings file look like it has been corrupted."
  [v]
  (if (= v (math/floor v))
    (string/format "%.0f" v)
    (string/format "%.6g" v)))

(defn format-settings
  "Render appearance settings as a readable, hand-editable file."
  [settings]
  (def out @"")
  (buffer/push-string out
    "# Renderer appearance settings, version 1.\n"
    "# Water look: wave strength, ripples, glint, transparency and underwater\n"
    "# caustics. Missing file uses the reference-inspired defaults.\n")
  (def extra (filter (fn [k]
                       (and (not= k :version)
                            (nil? (find (fn [o] (= o k)) setting-order))))
                     (sort (keys settings))))
  # Match the container shape of the input: `merge` yields a table and load
  # compares by type, so emitting a struct for table input would make a
  # save/load round trip unequal even when every value matched.
  (buffer/push-string out (if (table? settings) "@{:version 1\n" "{:version 1\n"))
  (each k (array/concat @[] setting-order extra)
    (def v (get settings k))
    # :version is the header of the document, not a setting to repeat.
    (when (and (not (nil? v)) (not= k :version))
      (buffer/push-string out
        (string/format " %s %s\n" (string ":" k) (num v)))))
  (buffer/push-string out "}\n")
  (string out))

(defn save [settings &opt path]
  "Validate and atomically replace the appearance file only on explicit call."
  (when (not (validate settings)) (error "invalid appearance settings"))
  (let [path (or path "data/appearance.janet")
        tmp (string path ".tmp-" (os/getpid) "-" (os/time))
        f (file/open tmp :wbn)]
    (try
      (do (when (nil? f) (error "cannot open temporary appearance file"))
          (file/write f (format-settings settings))
          (file/flush f)
          (file/close f)
          (os/rename tmp path))
      ([err]
        (when f (try (file/close f) ([ignored] nil)))
        (try (os/rm tmp) ([ignored] nil))
        (error err)))
    settings))
(defn source [&opt path]
  (let [path (or path "data/appearance.janet")]
    {:path path :settings (load path)}))
(defn current [state] (get state :settings))
(defn reload [state]
  "Return new state only after fully validating the file; errors leave caller state untouched."
  (let [path (get state :path)]
    (when (not (string? path)) (error "appearance source needs a path"))
    {:path path :settings (load path)}))
