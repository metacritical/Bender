# Pure world-space perspective frustum tests. Planes are [nx ny nz d],
# with unit inward normals and signed distance nx*x + ny*y + nz*z + d.
# Touching a plane counts as visible.

(defn dot3 [ax ay az bx by bz]
  (+ (* ax bx) (* ay by) (* az bz)))

(defn unit3 [x y z]
  (let [length (math/sqrt (dot3 x y z x y z))]
    (assert (> length 0) "frustum: zero-length direction")
    [(/ x length) (/ y length) (/ z length)]))

(defn plane [nx ny nz px py pz]
  (let [[x y z] (unit3 nx ny nz)]
    [x y z (- (dot3 x y z px py pz))]))

(defn frustum-from-camera
  ``Build six normalized inward planes from camera position, target, up,
  vertical FOV in degrees, aspect ratio, and near/far clipping distances.``
  [position target up fovy aspect near far]
  (assert (and (> aspect 0) (> near 0) (> far near))
          "frustum: invalid viewport or clipping distances")
  (let [px (get position 0) py (get position 1) pz (get position 2)
        [fx fy fz] (unit3 (- (get target 0) px)
                          (- (get target 1) py)
                          (- (get target 2) pz))
        # Prefer the supplied up, but switch axes when it is parallel to forward.
        ux (get up 0) uy (get up 1) uz (get up 2)
        rx (- (* fy uz) (* fz uy))
        ry (- (* fz ux) (* fx uz))
        rz (- (* fx uy) (* fy ux))
        parallel? (< (dot3 rx ry rz rx ry rz) 1e-12)
        # World Z is safe for a vertical view; world Y for a Z-axis view.
        fallback-z? (> (math/abs fy) 0.9)
        [right-x right-y right-z]
        (if parallel?
          (if fallback-z?
            (unit3 fy (- fx) 0)
            (unit3 (- fz) 0 fx))
          (unit3 rx ry rz))
        up-x (- (* right-y fz) (* right-z fy))
        up-y (- (* right-z fx) (* right-x fz))
        up-z (- (* right-x fy) (* right-y fx))
        slope-y (math/tan (* fovy (/ math/pi 360)))
        slope-x (* slope-y aspect)]
    (assert (and (> fovy 0) (< fovy 180)) "frustum: invalid vertical FOV")
    [(plane fx fy fz (+ px (* fx near)) (+ py (* fy near)) (+ pz (* fz near)))
     (plane (- fx) (- fy) (- fz)
            (+ px (* fx far)) (+ py (* fy far)) (+ pz (* fz far)))
     (plane (+ (* fx slope-x) right-x)
            (+ (* fy slope-x) right-y)
            (+ (* fz slope-x) right-z) px py pz)
     (plane (- (* fx slope-x) right-x)
            (- (* fy slope-x) right-y)
            (- (* fz slope-x) right-z) px py pz)
     (plane (+ (* fx slope-y) up-x)
            (+ (* fy slope-y) up-y)
            (+ (* fz slope-y) up-z) px py pz)
     (plane (- (* fx slope-y) up-x)
            (- (* fy slope-y) up-y)
            (- (* fz slope-y) up-z) px py pz)]))

(defn point-inside?
  ``Whether world-space x, y, z lies on or inside every plane.``
  [frustum x y z]
  (var i 0)
  (var visible true)
  (while (and visible (< i (length frustum)))
    (let [p (get frustum i)]
      (when (< (+ (dot3 (get p 0) (get p 1) (get p 2) x y z)
                  (get p 3)) 0)
        (set visible false)))
    (++ i))
  visible)

(defn aabb-visible?
  ``Conservative intersection test for scalar min/max world coordinates.
  The positive vertex is selected directly without temporary allocations.``
  [frustum min-x min-y min-z max-x max-y max-z]
  (var i 0)
  (var visible true)
  (while (and visible (< i (length frustum)))
    (let [p (get frustum i)
          nx (get p 0) ny (get p 1) nz (get p 2)]
      (when (< (+ (* nx (if (>= nx 0) max-x min-x))
                  (* ny (if (>= ny 0) max-y min-y))
                  (* nz (if (>= nz 0) max-z min-z))
                  (get p 3)) 0)
        (set visible false)))
    (++ i))
  visible)

(defn chunk-visible?
  ``Test the chunk AABB at integer cx, cz; sizes default to 16 x 256 x 16.``
  [frustum cx cz &opt chunk-x chunk-y chunk-z]
  (let [sx (or chunk-x 16) sy (or chunk-y 256) sz (or chunk-z 16)
        x (* sx cx) z (* sz cz)]
    (aabb-visible? frustum x 0 z (+ x sx) sy (+ z sz))))

(defn sphere-visible?
  ``Conservative sphere/frustum intersection with scalar center and radius.``
  [frustum x y z radius]
  (assert (>= radius 0) "frustum: negative sphere radius")
  (var i 0)
  (var visible true)
  (while (and visible (< i (length frustum)))
    (let [p (get frustum i)]
      (when (< (+ (dot3 (get p 0) (get p 1) (get p 2) x y z)
                  (get p 3) radius) 0)
        (set visible false)))
    (++ i))
  visible)
