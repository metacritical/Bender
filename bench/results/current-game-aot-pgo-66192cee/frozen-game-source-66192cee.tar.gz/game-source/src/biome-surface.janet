# Trinecraft — biome to surface-material policy. Pure, versioned, no I/O.
#
# OWNERSHIP. This module owns one decision: given the biome a column already has,
# which EXISTING block ids fill its top and its subsoil, and whether a water
# column stands above it. It reads no file, imports no world/atlas/GL, holds no
# mutable state, and is NOT wired into any generator. Nothing calls it from
# `main.janet`, `worldgen`, the terrain cache or save loading; it runs only in
# its own headless tests. Old saves are untouched because nothing here is
# reachable from them.
#
# THE BIOME VOCABULARY IS NOT INVENTED HERE. `src/climate-biome.janet` owns it and
# owns `biome-revision`. This file is a LAYER OVER that output: it must map every
# biome the classifier can return, and it must refuse anything else rather than
# guess a material from climate of its own. An unknown biome is therefore
# `:unavailable` with `:preserve-legacy true`, which tells a future integrator to
# keep whatever the legacy generator already produced instead of writing new
# blocks over it.
#
# THE PUBLISHED VOCABULARY NOW MATCHES THIS POLICY. `climate-biome/biomes` once
# omitted `:savanna` while `classify-valid` returned it for warm wet ground; that
# classifier bug is fixed, and `:savanna` is a published member. The policy below
# is keyed by what the classifier RETURNS, which is now the same set, and this
# module needed no change for the fix: it already carried `:savanna`.
#
# WATER IS A FLAG, NEVER A SOLID, AND NOT A PROMISE. `:ocean` describes a SEABED:
# solid terrain in `:top`/`:subsoil` plus `water? true`. The flag means "this
# column is underwater", nothing more -- this module places no water, fills no
# column and performs no flow. The future generator owns filling above the seabed,
# and it is the only party that knows the sea level. Ids 0 (air) and 5 (water) are
# refused for `:top`/`:subsoil`, so the policy cannot express solid water.
#
# THRESHOLDS ARE AUTHORED, NOT MEASURED, and belong to `climate-biome`. This file
# adds no numbers of its own: it re-exports the classifier's thresholds and
# revision in `basis` so a stored surface can be traced to the rule set that made
# it. `surface-revision` must be bumped when any material choice below changes,
# because a column built under different choices is not the same column.

(import ./climate-biome :as bio)
(import ./materials :as mat)

(def version 1)

#: Bumped when any material choice, or the water flag, below changes.
(def surface-revision 1)

#: Where the rules came from. `:authored` means a human chose them; no model, no
#: measurement, no inference.
(def provenance :authored)

(defn- solid-material
  "Resolve a live block name to its id, refusing air and water as terrain."
  [name]
  (def id (mat/name->id name))
  (when (nil? id)
    (error (string "biome-surface: no live block id for " name)))
  (when (or (= id (mat/name->id :air)) (= id (mat/name->id :water)))
    (error (string "biome-surface: " name " cannot be terrain")))
  id)

(defn- descriptor
  "A frozen top/subsoil descriptor. Structs are immutable by construction."
  [top subsoil &opt water?]
  {:top (solid-material top)
   :subsoil (solid-material subsoil)
   :top-name top
   :subsoil-name subsoil
   :water? (truthy? water?)})

#: The authored policy: biome -> frozen descriptor. Keys are exactly the biomes
#: `climate-biome/classify` can return.
(def policy
  {:ocean            (descriptor :sand :sand true)
   :shore            (descriptor :sand :sand)
   :ice              (descriptor :snow :dirt)
   :tundra           (descriptor :dirt :stone)
   :taiga            (descriptor :grass :dirt)
   :temperate-forest (descriptor :grass :dirt)
   :grassland        (descriptor :grass :dirt)
   :savanna          (descriptor :grass :dirt)
   :desert           (descriptor :sand :stone)})

#: Provenance of every number this policy depends on. `climate-biome` owns the
#: thresholds; this module owns only the material choices.
(def basis
  {:provenance provenance
   :authority :climate-biome
   :biome-revision bio/biome-revision
   :surface-revision surface-revision
   :thresholds bio/thresholds
   :thresholds-source :authored-unmeasured})

(defn descriptor-of
  "The frozen surface descriptor for a biome, or nil when no policy exists."
  [biome]
  (when (keyword? biome) (get policy biome)))

(defn valid?
  "Are all policy entries frozen, id-resolving, and free of solid water?"
  []
  (and (= (length policy) (length (keys policy)))
       (every? (map |(and (struct? $)
                          (number? (get $ :top)) (number? (get $ :subsoil))
                          (not= 0 (get $ :top)) (not= 0 (get $ :subsoil))
                          (not= 5 (get $ :top)) (not= 5 (get $ :subsoil)))
                    (values policy)))))

#: The answer when there is no biome to look up. ONE shared struct literal, which
#: Janet makes a read-only table, so no caller can mutate it; every no-answer path
#: returns the SAME value, so `=` is stable across calls and a caller can compare
#: against `unavailable` directly. It is not a sentinel number and not a default
#: biome: `:reason :missing-climate` says plainly that no climate arrived here.
(def unavailable
  {:status :unavailable :reason :missing-climate :preserve-legacy true
   :surface-revision surface-revision :provenance provenance})

(defn surface
  ``The surface material for one column, or `unavailable`.

  `biome` is a keyword, or a `climate-biome/classify` result whose biome is read
  with `biome-of`. `elevation` and `sea` are BOTH PROVIDED BY THE CALLER in world
  blocks and are neither defaulted nor adjudicated here: this module has no
  opinion about where the waterline is, so it cannot reject an elevation or a sea
  level it was handed. It also promises no water and performs no flow. The water
  fill belongs to the future generator; the flag only says the column is
  underwater, so the generator knows to fill above a solid seabed.

  Answers:

    * `{:status :classified :biome .. :top .. :subsoil .. :water? ..}`
    * `unavailable` -- the SAME struct every time, `:reason :missing-climate`

  An unknown biome never yields an invented material, and never an arm for it.``
  [biome elevation sea]
  # `elevation`/`sea` are accepted for call-site symmetry with the classifier and
  # carried through unused: a policy lookup is a function of the biome alone.
  (def b (if (keyword? biome) biome (bio/biome-of biome)))
  (def d (descriptor-of b))
  (if (nil? d)
    unavailable
    {:status :classified :biome b
     :top (d :top) :subsoil (d :subsoil) :water? (d :water?)
     :top-name (d :top-name) :subsoil-name (d :subsoil-name)
     :surface-revision surface-revision :provenance provenance}))

(defn classified? [r] (= :classified (get r :status)))
