# First-person pickaxe overlay. Drawn in screen space after EndMode3D.
# This module owns neither input nor the window; callers decide when to show it.
(import ./rl :as rl)

(defn segments
  "Return screen-space [x1 y1 x2 y2 color thickness] strokes. Progress is
  0..1 during a strike and nil while idle; dimensions are current window pixels."
  [width height &opt progress]
  (def scale (max 0.5 (min (/ width 1280) (/ height 800))))
  (def swing (if (nil? progress) 0
                 (* (math/sin (* math/pi (max 0 (min 1 progress)))) 72 scale)))
  (def x (- width (* 146 scale) swing))
  (def y (+ height (* 65 scale) (- (* swing 0.5))))
  (defn point [px py] [(math/floor (+ x (* px scale)))
                       (math/floor (+ y (* py scale)))])
  (defn stroke [a b color thickness]
    (def p (point (a 0) (a 1)))
    (def q (point (b 0) (b 1)))
    [(p 0) (p 1) (q 0) (q 1) color (max 1 (math/floor (* thickness scale)))])
  [(stroke [-15 -10] [110 -265] [0x45 0x2d 0x1c 0xff] 18)
   (stroke [-20 -12] [105 -260] [0x95 0x60 0x32 0xff] 11)
   (stroke [88 -264] [123 -287] [0x40 0x48 0x52 0xff] 17)
   (stroke [25 -294] [157 -286] [0x48 0x55 0x62 0xff] 23)
   (stroke [21 -300] [155 -294] [0xb3 0xc4 0xce 0xff] 9)
   (stroke [24 -292] [-5 -275] [0x48 0x55 0x62 0xff] 13)
   (stroke [155 -288] [180 -269] [0x48 0x55 0x62 0xff] 13)])

(defn draw
  "Draw a first-person pickaxe after rl/end-mode-3d, before rl/end-drawing.
  Supply window width/height and optional strike progress 0..1 (nil = idle)."
  [width height &opt progress]
  (each segment (segments width height progress)
    (def x1 (segment 0)) (def y1 (segment 1))
    (def x2 (segment 2)) (def y2 (segment 3))
    (def color (segment 4)) (def thick (segment 5))
    # DrawRectangle is already bound; rotate-free stepped strokes require no
    # new rl bindings, meshes, GPU resources, or camera/depth state.
    (def steps (max 1 (math/ceil (max (math/abs (- x2 x1))
                                      (math/abs (- y2 y1))))))
    (for i 0 (+ steps 1)
      (def t (/ i steps))
      (rl/draw-rectangle (math/floor (+ x1 (* (- x2 x1) t)))
                         (math/floor (+ y1 (* (- y2 y1) t)))
                         thick thick color))))
