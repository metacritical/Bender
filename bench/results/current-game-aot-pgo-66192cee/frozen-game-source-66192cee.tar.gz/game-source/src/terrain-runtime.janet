# Read-only native terrain package discovery. macOS uses the shipping system
# CommonCrypto SHA-256 via Janet FFI, reading assets in 64 KiB chunks. This
# module never loads model/native pipeline code, downloads assets, runs Python,
# or enables learned generation: pipeline proof remains a separate prerequisite.

(def manifest-name "terrain-runtime.janet")
(def max-manifest-bytes 16384)
(def revision "ad2df557eca5645f588766101cf3bc3682455c3e")
(def runtime-version "1.31.1")
(def max-path-bytes 4096)
(def assets [
  {:name "coarse_model.onnx" :bytes 22497125}
  {:name "base_model.onnx" :bytes 2029994361}
  {:name "decoder_model.onnx" :bytes 223854143}
  {:name "pipeline_data.json" :bytes 12226}
  {:name "world_pipeline_config.json" :bytes 774}
  {:name "libonnxruntime.1.31.1.dylib" :bytes nil}
  {:name "libtrinecraft-terrain.dylib" :bytes nil}])
(def known-sha256 {
  "base_model.onnx" "543de788f73d0a4012685c908259f615601102aace4751aeccec64154ba145c0"
  "decoder_model.onnx" "6473ae47ca6ec4d743d30fe4f5d381fe4158899714eff09b762005bdbdef68c1"})
(defn- fail [reason] (error (string "terrain runtime: " reason)))
(defn- obj? [value] (or (table? value) (struct? value)))
(defn- exact? [value wanted]
  (and (obj? value) (= (length (keys value)) (length wanted))
       (every? (map (fn [key] (has-key? value key)) wanted))))
(defn- uint? [value]
  (and (number? value) (not (nan? value)) (< 0 value)
       (= value (math/floor value)) (<= value 4294967295)))
(defn- hex64? [value]
  (and (string? value) (= 64 (length value))
       (every? (map (fn [c] (or (<= 48 c 57) (<= 97 c 102))) value))))
(defn- plain? [value]
  (cond
    (or (nil? value) (boolean? value) (string? value) (keyword? value)) true
    (number? value) (and (not (nan? value)) (< -1e308 value 1e308))
    (or (tuple? value) (array? value)) (every? (map plain? value))
    (obj? value) (every? (map (fn [[key v]] (and (keyword? key) (plain? v)))
                              (pairs value)))
    true false))
(defn- parse-one [bytes]
  (def p (parser/new))
  (parser/consume p bytes)
  (when (= :error (parser/status p)) (fail "invalid manifest syntax"))
  (parser/eof p)
  (when (= :error (parser/status p)) (fail "invalid manifest syntax"))
  (def forms @[])
  (while (parser/has-more p)
    (each form (parser/produce p true) (array/push forms form)))
  (unless (= 1 (length forms)) (fail "manifest must have one data form"))
  (def form (get forms 0))
  (unless (plain? form) (fail "manifest contains non-data"))
  form)
(defn- read-manifest [path]
  (def stat (os/lstat path))
  (unless (and stat (= :file (get stat :mode))
               (<= (get stat :size) max-manifest-bytes))
    (fail "manifest absent, linked, or oversized"))
  (def f (file/open path :rb))
  (unless f (fail "manifest unreadable"))
  (def bytes (try (file/read f :all) ([err] (file/close f) (error err))))
  (file/close f)
  (unless (and bytes (<= (length bytes) max-manifest-bytes))
    (fail "manifest exceeds byte limit"))
  (parse-one bytes))
(defn- validate [m &opt fixture-pins]
  # Fixture pins are accepted ONLY by the test-local discovery entry point;
  # production discover never accepts caller-supplied pins.
  (unless (exact? m [:version :revision :platform :arch :runtime-version
                     :provider :assets])
    (fail "manifest keys mismatch"))
  (unless (= 1 (get m :version)) (fail "unsupported manifest version"))
  (unless (= revision (get m :revision)) (fail "unsupported model revision"))
  (unless (= runtime-version (get m :runtime-version))
    (fail "unsupported ONNX Runtime version"))
  (unless (= :terrain-diffusion-native (get m :provider))
    (fail "unsupported learned provider"))
  (unless (and (= :macos (get m :platform)) (= :aarch64 (get m :arch)))
    (fail "unsupported package platform; only macOS arm64 is specified"))
  (def files (get m :assets))
  (unless (exact? files (map |(keyword (get $ :name)) assets))
    (fail "asset keys mismatch"))
  (each asset assets
    (def name (get asset :name))
    (def row (get files (keyword name)))
    (unless (exact? row [:bytes :sha256]) (fail (string name " metadata keys mismatch")))
    (unless (uint? (get row :bytes)) (fail (string name " invalid byte length")))
    (def pinned-bytes (if fixture-pins (get (get fixture-pins (keyword name)) :bytes)
                        (get asset :bytes)))
    (def pinned-sha (if fixture-pins (get (get fixture-pins (keyword name)) :sha256)
                      (get known-sha256 name)))
    (when (and pinned-bytes (not= pinned-bytes (get row :bytes)))
      (fail (string name " pinned byte length mismatch")))
    (unless (hex64? (get row :sha256)) (fail (string name " invalid SHA-256")))
    (when (and pinned-sha (not= pinned-sha (get row :sha256)))
      (fail (string name " pinned SHA-256 mismatch"))))
  m)
(defn- path-ok? [value]
  (and (string? value) (<= 1 (length value) max-path-bytes)
       (not (string/find "\x00" value))))
(def hash-chunk-bytes 65536)
(defn- commoncrypto []
  (unless (= :macos (os/which)) (fail "system SHA-256 unavailable on this platform"))
  (def lib (ffi/native "/usr/lib/libSystem.dylib"))
  (def init (ffi/lookup lib "CC_SHA256_Init"))
  (def update (ffi/lookup lib "CC_SHA256_Update"))
  (def final (ffi/lookup lib "CC_SHA256_Final"))
  (unless (and init update final) (fail "system SHA-256 symbols unavailable"))
  {:library lib :init init :update update :final final
   :init-sig (ffi/signature :default :int :ptr)
   :update-sig (ffi/signature :default :int :ptr :ptr :uint)
   :final-sig (ffi/signature :default :int :ptr :ptr)})
(defn sha256-file [path]
  ``Stream SHA-256 through macOS CommonCrypto; never slurp multi-GB graphs.
  Missing libraries, symbols, read failures and link paths fail closed.``
  (unless (path-ok? path) (fail "invalid hash path"))
  (def st (os/lstat path))
  (unless (and st (= :file (get st :mode))) (fail "hash input missing or linked"))
  (def api (commoncrypto))
  # Oversized storage avoids assuming a compiler-private CC_SHA256_CTX layout.
  # CommonCrypto declares a 32-byte state plus length and block buffer; 256 is
  # more than its public C ABI requires on the supported macOS arm64 target.
  (def ctx (buffer/new-filled 256 0))
  (def out (buffer/new-filled 32 0))
  (unless (= 1 (ffi/call (get api :init) (get api :init-sig) ctx))
    (fail "SHA-256 initialization failed"))
  (def f (file/open path :rb))
  (unless f (fail "hash input unreadable"))
  (try
    (do (var consumed 0)
        (while (def chunk (file/read f hash-chunk-bytes))
          (when (> (length chunk) hash-chunk-bytes)
            (fail "hash reader exceeded chunk boundary"))
          (+= consumed (length chunk))
          (unless (= 1 (ffi/call (get api :update) (get api :update-sig)
                                 ctx chunk (length chunk)))
            (fail "SHA-256 update failed")))
        (file/close f)
        (unless (= consumed (get st :size)) (fail "hash input changed during read")))
    ([err] (try (file/close f) ([ignored] nil)) (error err)))
  (unless (= 1 (ffi/call (get api :final) (get api :final-sig) out ctx))
    (fail "SHA-256 finalization failed"))
  (string/join (map |(string/format "%02x" $) out) ""))
(defn- join [root name] (string root "/" name))
(defn- dirname [path]
  (var slash nil)
  (for i 0 (length path)
    (when (= 47 (get path i)) (set slash i)))
  (if (nil? slash) "." (if (= 0 slash) "/" (string/slice path 0 slash))))
(defn- unavailable [code reason source root]
  {:available false :status code :reason reason :source source :root root})
(defn- choose-root [opts]
  (unless (or (nil? opts) (obj? opts)) (fail "options must be a table"))
  (def opts (or opts {}))
  (unless (every? (map (fn [key]
                         (some |(= $ key)
                               [:model-dir :env-model-dir :executable :platform :arch]))
                       (keys opts)))
    (fail "unknown discovery option"))
  (def explicit (get opts :model-dir))
  (def env (if (has-key? opts :env-model-dir)
             (get opts :env-model-dir) (os/getenv "TRINECRAFT_TERRAIN_MODEL")))
  (def executable (get opts :executable))
  (cond
    (not (nil? explicit)) [:explicit explicit]
    (and (string? env) (> (length env) 0)) [:environment env]
    (and (path-ok? executable) (= 47 (get executable 0)))
    [:executable (join (dirname executable) "assets/terrain")]
    true [:none nil]))
(defn- discover-impl [opts &opt fixture-pins]
  ``Return a read-only, never-ready discovery report. :model-dir takes priority
  over TRINECRAFT_TERRAIN_MODEL, then <executable-dir>/assets/terrain. Supply
  :env-model-dir explicitly in tests, including nil to suppress ambient env.
  Explicit invalid paths do not fall back to another package.``
  (def [source raw] (choose-root opts))
  (when (= source :none)
    (break (unavailable :missing-root "specify --model-dir, TRINECRAFT_TERRAIN_MODEL, or executable path" source nil)))
  (unless (path-ok? raw)
    (break (unavailable :invalid-root "selected model directory path is invalid" source raw)))
  (def root-stat (os/lstat raw))
  (unless (and root-stat (= :directory (get root-stat :mode)))
    (break (unavailable :missing-root "selected model directory is missing or linked" source raw)))
  # Root is caller-selected; leaf names are fixed here. lstat refuses symlinked
  # metadata/assets; no manifest-provided path is ever joined to the root.
  (def attempt (try [true (validate (read-manifest (join raw manifest-name)) fixture-pins)]
                    ([err] [false (string err)])))
  (unless (get attempt 0)
    (break (unavailable :invalid-manifest (get attempt 1) source raw)))
  (def m (get attempt 1))
  (unless (and (= (get m :platform) (or (get opts :platform) (os/which)))
               (= (get m :arch) (or (get opts :arch) (os/arch))))
    (break (unavailable :unsupported-platform "package platform differs from host" source raw)))
  (var bad-asset nil)
  (each asset assets
    (when (nil? bad-asset)
      (def name (get asset :name))
      (def meta (get (get m :assets) (keyword name)))
      (def st (os/lstat (join raw name)))
      (cond
        (not (and st (= :file (get st :mode))))
        (set bad-asset (unavailable :missing-asset
                         (string "required asset missing or linked: " name) source raw))
        (not= (get st :size) (get meta :bytes))
        (set bad-asset (unavailable :size-mismatch
                         (string "asset byte length mismatch: " name) source raw)))))
  (when bad-asset (break bad-asset))
  (var hash-issue nil)
  (each asset assets
    (when (nil? hash-issue)
      (def name (get asset :name))
      (def expected (get (get (get m :assets) (keyword name)) :sha256))
      (def result (try [true (sha256-file (join raw name))]
                       ([err] [false (string err)])))
      (if (not (get result 0))
        (set hash-issue (unavailable :hash-unavailable
                          (string "cannot verify SHA-256 of " name ": " (get result 1))
                          source raw))
        (when (not= expected (get result 1))
          (set hash-issue (unavailable :hash-mismatch
                            (string "SHA-256 mismatch: " name) source raw))))))
  (when hash-issue (break hash-issue))
  {:available false :status :unverified
   :reason "every packaged asset passed SHA-256; native inference pipeline proof unavailable"
   :source source :root raw :manifest m})
(defn discover [&opt opts]
  "Production discovery always enforces the fixed graph size/digest pins."
  (discover-impl opts))
(defn fixture-discover [opts pins]
  ``Hermetic package QA with a complete small pin map; never used for
  production discovery, always :available false even when all hashes match.``
  (unless (exact? pins (map |(keyword (get $ :name)) assets))
    (fail "fixture pins must cover every fixed asset"))
  (each asset assets
    (def pin (get pins (keyword (get asset :name))))
    (unless (and (exact? pin [:bytes :sha256]) (uint? (get pin :bytes))
                 (hex64? (get pin :sha256)))
      (fail "invalid fixture pin")))
  (discover-impl opts pins))
