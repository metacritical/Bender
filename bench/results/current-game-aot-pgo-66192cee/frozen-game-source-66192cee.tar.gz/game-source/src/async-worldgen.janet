# Isolated chunk terrain scheduler. The proc lanes are process-global and owned
# exclusively by one non-fallback scheduler; callers must not start other lanes.
# A worker that never finishes worldgen cannot be interrupted: drain/teardown
# necessarily wait for its response before quitting workers and stopping lanes.
(import ./worldgen :as worldgen)
(import ./world :as world)

(defn- generate-blocks [request]
  (worldgen/generate-into (buffer/new world/chunk-volume)
                          (request :cx) (request :cz) (request :seed)))

(defn- bounded-integer? [value minimum maximum]
  (and (= (type value) :number)
       (<= minimum value maximum)
       (= value (math/floor value))))

(def max-coordinate 134217727)
(def max-priority 9007199254740991)
(def- ownership @{:active false})

(defn- worker [results]
  (ev/give results [:ready (proc/self-pid)])
  (var active true)
  (while active
    (def message (proc/recv))
    (if (= message :quit)
      (do (ev/give results [:quit (proc/self-pid)]) (set active false))
      (let [[ok value] (protect (generate-blocks message))]
        (ev/give results [:result (message :sequence)
                          (if ok {:blocks value} {:error (string value)})])))))

(defn- check-response [response]
  (if (= (response 0) :down)
    (error (string "worldgen worker exited: " (response 1) " " (response 2)))
    (unless (= (response 0) :result)
      (error (string "worldgen worker sent unexpected " (response 0)
                     " outside shutdown: " response))))
  response)

(defn- receive [scheduler]
  (check-response (ev/take (scheduler :results))))

(defn- stop-workers [scheduler]
  # All job responses MUST have been collected first; result channel has room
  # for every quit ACK and DOWN. A normal DOWN after ACK proves the worker
  # exited; lanes-stop may still detach unrelated stragglers.
  (each pid (scheduler :workers) (proc/send pid :quit))
  (def acknowledged @{})
  (def exited @{})
  (var remaining-acks (length (scheduler :workers)))
  (var remaining-down (length (scheduler :workers)))
  (while (or (> remaining-acks 0) (> remaining-down 0))
    (def response (ev/take (scheduler :results)))
    (if (= (response 0) :quit)
      (let [serial ((response 1) 2)]
        (assert (not (get acknowledged serial)) "duplicate worker quit ACK")
        (put acknowledged serial true)
        (put scheduler :quit-acks (+ 1 (scheduler :quit-acks)))
        (set remaining-acks (- remaining-acks 1)))
      (if (= (response 0) :down)
        (let [serial (response 1)]
          (assert (and (get acknowledged serial) (= (response 2) :normal)
                       (not (get exited serial)))
                  "worker exited without clean quit ACK")
          (put exited serial true)
          (set remaining-down (- remaining-down 1)))
        (error (string "unexpected response during shutdown: " response)))))
  (proc/lanes-stop)
  (put ownership :active false))

(defn new [&opt options]
  (def opts (or options {}))
  (def concurrency (or (get opts :concurrency) 2))
  (def capacity (or (get opts :capacity) 32))
  (assert (bounded-integer? concurrency 1 64) "concurrency must be between 1 and 64")
  (assert (bounded-integer? capacity 1 2147483583) "capacity must be positive bounded integer")
  (def fallback (or (get opts :fallback) false))
  (when (not fallback)
    (assert (and (not (ownership :active)) (= (proc/lanes) 0))
            "proc lanes already active; scheduler requires exclusive ownership"))
  (def scheduler @{:concurrency concurrency :capacity capacity
                   :generation 0 :sequence 0 :pending @[] :running @[] :completed @[]
                   :fallback fallback :closed false :workers @[] :next-worker 0
                   :worker-busy @[] :results nil :quit-acks 0})
  (unless fallback
    # Reserve enough slots for all admitted jobs plus worker acknowledgements.
    (put scheduler :results (ev/thread-chan (+ capacity concurrency)))
    (proc/lanes-start concurrency)
    (put ownership :active true)
    (proc/lanes-policy :round-robin)
    (let [results (scheduler :results)
          [ok error] (protect
                       (for _ 0 concurrency
                         (def pid (proc/spawn (fn [] (worker results)) 1))
                         (array/push (scheduler :workers) pid)
                         (array/push (scheduler :worker-busy) false))
                       (var ready 0)
                       (while (< ready concurrency)
                         (def response (ev/take results))
                         (assert (= (response 0) :ready) "worker failed to start")
                         # self-pid in the ready message proves serial registration.
                         # Monitoring earlier can spuriously report :noproc.
                         (def pid (response 1))
                         (ev/give (pid 3) [:proc-monitor (pid 2) (pid 2) results])
                         (set ready (+ ready 1))))]
      (unless ok
        # Incomplete initialization must not masquerade as safe teardown:
        # an unacknowledged process could remain in a detached lane.
        (error (string "worldgen worker initialization failed; lanes remain owned: " error)))))
  scheduler)

(defn- ordered [a b]
  (if (= (a :priority) (b :priority))
    (< (a :sequence) (b :sequence))
    (> (a :priority) (b :priority))))

(defn- launch [scheduler]
  (unless (scheduler :fallback)
    (assert (= (proc/lanes-policy) :round-robin)
            "worldgen scheduler requires round-robin lane policy"))
  (var dispatching true)
  (while (and dispatching (not (scheduler :closed))
              (< (length (scheduler :running)) (scheduler :concurrency))
              (> (length (scheduler :pending)) 0))
    (def request (get (scheduler :pending) 0))
    (if (scheduler :fallback)
      (do
        (array/remove (scheduler :pending) 0)
        (array/push (scheduler :running) (put request :sync true)))
      (let [count (length (scheduler :workers))
            start (scheduler :next-worker)]
        (var attempted 0)
        (var dispatched false)
        (while (and (< attempted count) (not dispatched))
          (def index (mod (+ start attempted) count))
          (set attempted (+ attempted 1))
          (unless (get (scheduler :worker-busy) index)
            (let [pid (get (scheduler :workers) index)
                  [ok value] (protect (proc/try-send pid request))]
              (if ok
                (when value
                  (array/remove (scheduler :pending) 0)
                  (put request :worker-index index)
                  (array/push (scheduler :running) request)
                  (put (scheduler :worker-busy) index true)
                  (put scheduler :next-worker (mod (+ index 1) count))
                  (set dispatched true))
                # Only a thrown send is a dispatch error; false is backpressure.
                (do
                  (array/remove (scheduler :pending) 0)
                  (put request :result {:error (string "worldgen dispatch failed: " value)})
                  (when (= (request :generation) (scheduler :generation))
                    (array/push (scheduler :completed) request))
                  (set dispatched true))))))
        # A full idle mailbox cannot be waited on here. A future poll retries;
        # worker-busy prevents queued jobs, so drain cannot reach this state.
        (unless dispatched (set dispatching false))))))

(defn submit [scheduler cx cz seed &opt priority]
  (assert (not (scheduler :closed)) "scheduler is closed")
  (assert (and (bounded-integer? cx (- max-coordinate) max-coordinate)
               (bounded-integer? cz (- max-coordinate) max-coordinate)
               (bounded-integer? seed -2147483648 2147483647)
               (bounded-integer? (if (= priority nil) 0 priority) (- max-priority) max-priority))
          "worldgen request requires bounded integral cx, cz, seed, and priority")
  (if (>= (+ (length (scheduler :pending)) (length (scheduler :running))
              (length (scheduler :completed))) (scheduler :capacity))
    nil
    (do
      (assert (< (scheduler :sequence) max-priority) "worldgen sequence exhausted")
      (def request @{:cx cx :cz cz :seed seed :priority (if (= priority nil) 0 priority)
                     :generation (scheduler :generation) :sequence (scheduler :sequence)})
      (put scheduler :sequence (+ 1 (scheduler :sequence)))
      (array/push (scheduler :pending) request)
      (sort (scheduler :pending) ordered)
      (launch scheduler)
      (request :sequence))))

(defn cancel [scheduler]
  (put scheduler :generation (+ 1 (scheduler :generation)))
  (array/clear (scheduler :pending))
  (array/clear (scheduler :completed))
  scheduler)

(defn- finish [scheduler response]
  (assert (= (response 0) :result) "unexpected worker response")
  (var index 0)
  (while (and (< index (length (scheduler :running)))
              (not (= ((get (scheduler :running) index) :sequence) (response 1))))
    (set index (+ index 1)))
  (assert (< index (length (scheduler :running))) "unknown worker response")
  (def request (get (scheduler :running) index))
  (array/remove (scheduler :running) index)
  (put (scheduler :worker-busy) (request :worker-index) false)
  (put request :result (response 2))
  (when (= (request :generation) (scheduler :generation))
    (array/push (scheduler :completed) request)))

(defn- finish-sync [scheduler]
  (var index 0)
  (while (< index (length (scheduler :running)))
    (def request (get (scheduler :running) index))
    (if (request :sync)
      (do
        (array/remove (scheduler :running) index)
        (let [[ok value] (protect (generate-blocks request))]
          (put request :result (if ok {:blocks value} {:error (string value)})))
        (when (= (request :generation) (scheduler :generation))
          (array/push (scheduler :completed) request)))
      (set index (+ index 1)))))

(defn- deliver [scheduler]
  (def results @[])
  (sort (scheduler :completed) ordered)
  (var blocked false)
  (while (and (not blocked) (> (length (scheduler :completed)) 0))
    (def request (get (scheduler :completed) 0))
    (each outstanding (scheduler :running)
      (when (and (= (outstanding :generation) (scheduler :generation))
                 (ordered outstanding request)) (set blocked true)))
    (each outstanding (scheduler :pending)
      (when (and (= (outstanding :generation) (scheduler :generation))
                 (ordered outstanding request)) (set blocked true)))
    (unless blocked
      (array/remove (scheduler :completed) 0)
      (array/push results request)))
  results)

(defn poll [scheduler]
  (unless (scheduler :fallback)
    (var response (ev/try-take (scheduler :results)))
    (while response
      (finish scheduler (check-response response))
      (set response (ev/try-take (scheduler :results)))))
  (finish-sync scheduler)
  (launch scheduler)
  (deliver scheduler))

(defn drain [scheduler]
  (var stalled false)
  (while (and (not stalled)
              (or (> (length (scheduler :pending)) 0)
                  (> (length (scheduler :running)) 0)))
    (launch scheduler)
    (finish-sync scheduler)
    (if (> (length (scheduler :running)) 0)
      (finish scheduler (receive scheduler))
      # An idle worker's full mailbox is transient backpressure, not a job
      # to wait for. Normally impossible with one owned job per worker.
      (when (> (length (scheduler :pending)) 0) (set stalled true))))
  (deliver scheduler))

(defn teardown [scheduler]
  (unless (scheduler :closed)
    (cancel scheduler)
    (put scheduler :closed true)
    # Canceled in-flight jobs still own responses. Receive every one before
    # quitting workers; lanes-stop alone would detach busy workers.
    (while (> (length (scheduler :running)) 0)
      (finish-sync scheduler)
      (when (> (length (scheduler :running)) 0)
        (finish scheduler (receive scheduler))))
    (unless (scheduler :fallback) (stop-workers scheduler)))
  scheduler)
