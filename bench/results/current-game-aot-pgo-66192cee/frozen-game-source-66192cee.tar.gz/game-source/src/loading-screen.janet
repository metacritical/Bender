# Trinecraft -- the loading screen's presentation layer.
#
# What this module owns, and what it deliberately does not:
#
#   * It owns BACKGROUNDS and TEXT. It does not own the loading state machine,
#     the tile counts, the worker, or the decision to cancel. The caller passes
#     a plain view-model table and this file draws it. That split is why the
#     whole thing is testable headless: everything below that is not a raylib
#     call is a pure function over numbers.
#
#   * Every count rendered here is one the caller MEASURED. There is no
#     synthetic percentage, no interpolated progress, and no ETA. The bar fills
#     from `ready/total` -- validated spawn tiles over required spawn tiles --
#     and nothing else. A loading screen that invents motion is worse than one
#     that sits still, because the invented number is the only thing the player
#     can see while the real work is invisible.
#
#   * Assets are OPTIONAL. A fresh clone has none (`.gitignore` ignores `*.png`),
#     so the gradient path is not an error branch, it is the shipped default and
#     the thing that has to look deliberate. Photographs are an enhancement.
#
#   * Construction touches only the filesystem. No GL call happens until `draw`,
#     so `new` is safe before a window exists -- which is the only way the caller
#     can build the screen and then open the window in a different order.

(import ./rl :as rl)

#
# --- Tunables -----------------------------------------------------------
#

(def default-max-images 4)      # two resident pairs: current + next
(def default-cycle-seconds 8)   # per slide
(def default-fade-seconds 1)    # crossfade at the tail of a slide

(def image-extensions ["png" "jpg" "jpeg" "webp"])

# The home-screen artwork. A FILENAME, not a directory: this is a specific
# designed image with a baked logo and characters, unlike the slideshow's
# interchangeable photographs. Missing is normal (assets are gitignored), so the
# gradient path below is the shipped default and must look deliberate.
(def default-main-art "assets/Trinexraft_main.png")

# Text sizes. One column, left aligned, three weights -- the restraint is the
# design: a loading screen is a title and a sentence, not a dashboard.
(def size-title 34)
(def size-subtitle 18)
(def size-stage 20)
(def size-count 20)
(def size-small 18)
(def size-tiny 16)

(def pad-left 64)
(def pad-top 64)
(def bar-width 420)
(def bar-height 8)
(def title-tracking 2)          # extra px between title glyphs

# Colours. Chosen against a MEASURED worst case rather than by eye: the
# brightest of the four supplied backgrounds reaches 208/255 luminance, and
# the scrims below are sized so every text colour still clears WCAG AA for
# its size over that. `muted` was 0x9a and only reached 2.1:1 -- it is lifted
# to 0xb4 here, and the scrims are deepened to match.
(def col-title [0xf2 0xf5 0xf8 0xff])
(def col-subtitle [0xd6 0xdf 0xe8 0xff])
(def col-stage [0xff 0xd2 0x7a 0xff])      # warm accent: "something is happening"
(def col-text [0xe6 0xec 0xf2 0xff])
(def col-muted [0xb4 0xc0 0xcc 0xff])
# A hard shadow under text, not a blur: at 16-20 px a soft shadow smears the
# glyph. One offset copy is enough to hold an edge over the brightest sky.
(def col-shadow [0x00 0x00 0x00 0xb4])
(def col-bar-bg [0x0d 0x14 0x10 0xe6])
# Moss over stone: a cool stone grey frame with a warm moss fill, which is what
# the sample's bar reads as at a glance.
(def col-frame-outer [0x2a 0x2f 0x2a 0xff])
(def col-frame-inner [0x5d 0x68 0x5a 0xff])
# Fill is CYAN -> PURPLE, as the reference loader has it. The moss/stone FRAME
# above is untouched: the frame reads as carved stone around a glowing sigil,
# which is the look the sample is going for.
(def col-fill-cyan [0x3f 0xe0 0xe8 0xff])
(def col-fill-purple [0x9a 0x5c 0xf4 0xff])
# The glow is a lighter band laid over the leading edge, not a shader effect:
# three nested rectangles give the falloff at zero GPU cost and no new shader.
(def col-fill-glow [0xd8 0xf4 0xff 0xc0])
(def col-fill-core [0xf2 0xe8 0xff 0xe0])
(def col-error [0xff 0x9a 0x8a 0xff])

# Fallback gradient: near-black at the bottom, deep blue-navy at the top. The
# same two colours the scrim uses, so the transition from gradient to photograph
# is a lighting change rather than a palette change.
(def col-grad-top [0x1b 0x2b 0x3d 0xff])
(def col-grad-bottom [0x0b 0x12 0x1a 0xff])

#
# --- Pure geometry ------------------------------------------------------
#

(defn- clamp [x lo hi]
  (if (< x lo) lo (if (> x hi) hi x)))

(defn- finite?
  ``True for a real number that arithmetic can be trusted with.

  Janet has no `infinite?`, and NaN is the only value that is not equal to
  itself, so both tests are needed: a NaN would sail through a range check
  (`(> nan 0)` is true in terms of ordering weirdness) and an infinity would
  make the crop scale zero.``
  [x]
  (and (number? x) (= x x) (< (math/abs x) 1.0e308)))

(defn cover
  ``Source rectangle that cover-crops `src-w`x`src-h` into `dst-w`x`dst-h`.

  "Cover" means the destination is fully painted with no letterboxing and no
  distortion: the scale is the LARGER of the two axis ratios, so the image
  overflows on one axis and the overflow is cropped evenly from both sides.
  Centred, because the supplied backgrounds all put their subject near the
  middle and the bright mass on the upper right.

  Returns `[sx sy sw sh]` in SOURCE pixels, always inside the image bounds, so
  a caller may hand it straight to DrawTexturePro without a guard. Degenerate
  input (zero or negative dimensions, non-finite numbers) yields the full
  source rect: drawing the whole image is a defensible answer, a division by
  zero is not.``
  [src-w src-h dst-w dst-h]
  (def full [0 0 (max 0 src-w) (max 0 src-h)])
  (if (or (not (finite? src-w)) (not (finite? src-h))
          (not (finite? dst-w)) (not (finite? dst-h))
          (<= src-w 0) (<= src-h 0) (<= dst-w 0) (<= dst-h 0))
    full
    (let [scale (max (/ dst-w src-w) (/ dst-h src-h))
          # Source pixels actually consumed: destination divided by the scale.
          want-w (/ dst-w scale)
          want-h (/ dst-h scale)
          crop-w (min src-w want-w)
          crop-h (min src-h want-h)]
      [(* 0.5 (- src-w crop-w)) (* 0.5 (- src-h crop-h)) crop-w crop-h])))

(defn cycle-position
  ``Which slide is showing at `elapsed`, and at what alpha.

  Returns `[index alpha]` where `index` is the slide that OWNS this cycle --
  the one that has been on screen since the cycle began. A slide holds fully
  opaque for `cycle - fade` seconds, then crossfades OUT over the last `fade`
  seconds of its own cycle while the NEXT slide fades in underneath/over it.

  Returning the outgoing index (not the incoming one) is what makes the
  sequence continuous: at `within = cycle` the next cycle begins with
  `index + 1` at alpha 255, which is exactly what the fade was converging to.
  Returning the incoming index instead would snap it from 0 to 255 at the
  boundary and flash the new slide for one frame before fading it in.

  `alpha` is the outgoing slide's alpha, 0..255; the incoming slide is drawn at
  `255 - alpha`, so the pair always sums to a constant and no frame is dim
  mid-fade. Only two textures are ever needed, because the pair is adjacent.
  `index` derives from `floor(elapsed / cycle) mod count`, so any elapsed value
  -- including one restored after a pause -- lands on the right slide.``
  [elapsed cycle-seconds fade-seconds count]
  (cond
    (or (not (finite? elapsed)) (<= count 0)) [0 255]
    (or (not (finite? cycle-seconds)) (<= cycle-seconds 0)) [0 255]
    true
    (let [cycle cycle-seconds
          # A fade longer than the cycle would leave no opaque time at all;
          # clamping keeps the hold non-negative without changing the period.
          fade (clamp (if (finite? fade-seconds) fade-seconds 0) 0 cycle)
          # mod on a non-negative value; guard the negative elapsed case so a
          # clock reset cannot produce a negative index.
          shifted (if (neg? elapsed) 0 elapsed)
          turns (math/floor (/ shifted cycle))
          index (mod turns count)
          within (- shifted (* turns cycle))
          hold (- cycle fade)]
      (if (or (<= fade 0) (<= within hold))
        [(math/floor index) 255]
        (let [t (/ (- within hold) fade)
              # Ease the fade: linear alpha on a photographic background reads
              # as a mechanical wipe at exactly the midpoint. Smoothstep keeps
              # the endpoints identical and the middle less abrupt.
              eased (* t t (- 3 (* 2 t)))]
          [(math/floor index)
           (math/floor (* 255 (clamp (- 1 eased) 0 1)))])))))

(defn bar-frac
  ``Fraction of required spawn tiles that are validated, 0..1. Measured only.

  `ready` is a count of decoded tiles, never an estimate. `ready > total` clamps
  to 1 so a miscount cannot overflow the bar.

  A missing or nonsensical `total` yields 0, but 0 here is NOT a claim that
  nothing is done -- it is the absence of a fraction. The distinction lives one
  level up, in `determinate?`: `0 of 25` is a MEASUREMENT of zero and renders as
  "0%", while `nil` or `0` total renders as "progress not reported". Collapsing
  those two into one number is exactly how a screen ends up claiming 0% of a job
  that has not started counting.``
  [ready total]
  (if (or (not (finite? ready)) (not (finite? total)) (<= total 0))
    0
    (clamp (/ ready total) 0 1)))

(defn bar-fill
  ``Pixel width of the filled portion of a `width`-wide bar.``
  [ready total width]
  (max 0 (math/floor (* width (bar-frac ready total)))))

(defn format-elapsed
  ``Seconds as `M:SS`. Minutes are unbounded, seconds are two digits.

  A cold spawn bake runs to minutes, so the minute field must not wrap at 60
  and must not be a percentage of anything: it is a clock.``
  [seconds]
  (def s (if (and (finite? seconds) (pos? seconds)) (math/floor seconds) 0))
  (def m (math/floor (/ s 60)))
  (def r (- s (* m 60)))
  (string (math/floor m) ":" (if (< r 10) "0" "") (math/floor r)))

#
# --- Pure text shaping --------------------------------------------------
#

(defn wrap-text
  ``Greedy word wrap into at most `max-lines` lines of `max-chars` characters.

  Greedy is correct here: the text is a fixed diagnostic sentence, and a
  balanced wrap would move words between lines as the message changes, which
  reads as flicker. A single token longer than a line is hard-broken rather
  than allowed to overflow, and a final line that still does not fit is
  truncated with an ellipsis -- a loading screen must never let one long
  backend path run off the window.

  Always returns a non-empty list for non-empty input: a caller that renders
  the result must never be handed an empty sequence to iterate over.``
  [text max-chars max-lines]
  (def n (max 1 (math/floor max-chars)))
  (def limit (max 1 (math/floor max-lines)))
  (def words (filter |(not (empty? $)) (string/split " " (string (or text "")))))
  (if (empty? words)
    @[""]
    (do
      (def lines @[])
      (var cur "")
      (defn push-cur []
        (when (not (empty? cur)) (array/push lines cur) (set cur "")))
      (each word words
        (cond
          # Fits on the current line (with the space that joins it).
          (<= (+ (length cur) (if (empty? cur) 0 1) (length word)) n)
          (set cur (if (empty? cur) word (string cur " " word)))

          # Long token: hard-break it across as many lines as it needs.
          (> (length word) n)
          (do
            (push-cur)
            (var rest word)
            (while (> (length rest) n)
              (array/push lines (string/slice rest 0 n))
              (set rest (string/slice rest n)))
            (set cur rest))

          # Word fits on a fresh line.
          true
          (do (push-cur) (set cur word))))
      (push-cur)
      # Bound the line count, and ellipsize the last surviving line so that
      # truncation is visible rather than looking like the message ended.
      (def bounded
        (if (<= (length lines) limit)
          lines
          (array/slice lines 0 limit)))
      (when (< (length bounded) (length lines))
        (def last-i (- (length bounded) 1))
        (def last-line (get bounded last-i))
        (def keep (max 0 (- n 1)))
        # Three ASCII dots, not U+2026: raylib's default font is the 224-glyph
        # ASCII set, so a typographic ellipsis renders as nothing at all --
        # the one place where "invisible" would look like the message simply
        # stopped. "..." also survives any future font swap.
        (put bounded last-i
             (string (if (> (length last-line) keep)
                       (string/slice last-line 0 keep)
                       last-line)
                     "...")))
      (if (empty? bounded) @[""] bounded))))

#
# --- Discovery (filesystem only, never throws) --------------------------
#

(defn- extension-of
  "Lower-cased extension of `name`, or \"\" when it has none."
  [name]
  (def parts (string/split "." (string/ascii-lower (string name))))
  (if (<= (length parts) 1) "" (last parts)))

(defn- image-file? [name]
  (some |(= $ (extension-of name)) image-extensions))

# --- Curated slide names ------------------------------------------------
#
# Discovery must NOT accept "any image in the directory". The asset root can be
# resolved from the EXECUTABLE rather than the repo, and a compiler checkout's
# assets directory holds logo and mascot art (bender.png, janet-big.png). A
# permissive scan put a cartoon beer screenshot on the loading screen, which is
# what a generic `*.png` filter produces when the root points somewhere else.
#
# So a default slide is one of the FOUR shipped Gemini backgrounds, by name. The
# main poster is excluded because it has its own path and its own screen, and
# the loader sample is excluded because it is a design reference with a baked
# fake progress bar -- drawing it under a live bar would show two bars.
(def slide-prefix "Gemini_Generated_Image_")

(def excluded-slide-names
  # Named explicitly rather than by pattern: these are specific files with a
  # specific job elsewhere, not a class of file to be filtered out later.
  ["Trinexraft_main.png" "trineraft_main_loader_sampel.png"])

(defn- curated-slide?
  ``A default slide: one of the four shipped backgrounds, and nothing else.

  Explicitly passed paths bypass this entirely -- `resolve-paths` documents that
  a caller naming a file gets that file. This is only the rule for DISCOVERY,
  where we are guessing on the user's behalf and must guess narrowly.``
  [name]
  (and (string? name)
       (some |(= $ (extension-of name)) image-extensions)
       (not (some |(= $ name) excluded-slide-names))
       # Basename, not the whole path: callers and tests pass both, and a path
       # that begins with "/" would never match a name prefix.
       (string/has-prefix? slide-prefix (last (string/split "/" name)))))

(defn discover
  ``Image paths under `dir`, sorted, truncated to `max-images`.

  Sorted is not cosmetic: an unsorted directory listing is whatever the
  filesystem happens to return, so without it the slideshow order -- and thus
  what a screenshot shows -- differs between machines and between runs on the
  same machine. `os/dir` throws on an absent or unreadable directory; an absent
  directory is the NORMAL case for a fresh clone, so it yields an empty list.``
  [dir max-images]
  (def limit (if (and (number? max-images) (>= max-images 0))
               (math/floor max-images)
               default-max-images))
  (def entries (try (os/dir (string dir)) ([_] nil)))
  (if (nil? entries)
    @[]
    (let [names (sort (filter curated-slide?
                              (filter |(and (string? $) (not (empty? $))) entries)))
          picked (if (>= limit (length names)) names (array/slice names 0 limit))]
      (map |(string dir "/" $) picked))))

(defn resolve-paths
  ``The path list this screen will use, from explicit paths or a directory.

  An explicit path that does not exist is dropped HERE, at construction, so a
  misconfigured `--loading-backgrounds` degrades once at startup instead of
  logging a failure on every frame forever. An explicit path that exists is
  kept even if its extension is unrecognised: the caller named it, and raylib's
  decoder is the authority on whether it can read it, not my extension list.``
  [opts]
  (def explicit (get opts :paths))
  (def limit (let [m (get opts :max-images default-max-images)]
               (if (and (number? m) (>= m 0)) (math/floor m) default-max-images)))
  (if (and explicit (not (empty? explicit)))
    # An explicit path that exists is kept even if its extension is
    # unrecognised: the caller named it, and raylib's decoder -- not my
    # extension list -- is the authority on whether it can be read.
    (let [kept (filter |(and (string? $) (not (empty? $)) (os/stat $)) explicit)]
      (if (>= limit (length kept)) (values kept) (array/slice kept 0 limit)))
    (if (has-key? opts :asset-dir)
      (if (get opts :asset-dir) (discover (get opts :asset-dir) limit) @[])
      (discover (string (or (get opts :root) ".") "/assets") limit))))

#
# --- Screen state -------------------------------------------------------
#

(defn new
  ``Build a loading screen. Filesystem only: safe before `init-window`.

  Textures are decoded on the first `draw`, because that is the first moment a
  GL context is guaranteed to exist. Storing the path list now means `paths`
  can be reported (in a QA line, in a test) without any GL state at all.``
  [&opt opts]
  (def o (or opts {}))
  (def paths (resolve-paths o))
  @{:root (or (get o :root) ".")
    :paths paths
    :cycle-seconds (if (and (number? (get o :cycle-seconds))
                            (pos? (get o :cycle-seconds)))
                     (get o :cycle-seconds) default-cycle-seconds)
    :fade-seconds (let [f (get o :fade-seconds default-fade-seconds)]
                    (if (and (number? f) (>= f 0)) f default-fade-seconds))
    :textures nil          # @[texture ...]; decoded lazily, aligned with :paths
    :attempted false       # decode has run (not the same as "succeeded")
    :failures 0            # how many paths failed to decode
    :elapsed 0.0           # slideshow clock, advanced by draw
    :loaded 0
    # The dedicated home-screen artwork, kept SEPARATE from the slideshow: it is
    # never a slide, never faded, and never drawn under the loading bar. One
    # extra bounded texture owned by the same presenter, so dispose still has a
    # single owner.
    # The default is RELATIVE to the asset root, which the caller resolves; a
    # bare filename would be looked up against the process cwd and would miss
    # the game's assets whenever the game is launched from elsewhere. When the
    # caller names the poster explicitly (as `main` does), that path wins.
    :main-art (or (get o :main-art)
                  (if (and (string? (get o :asset-dir))
                           (not (empty? (get o :asset-dir))))
                    (string (get o :asset-dir) "/Trinexraft_main.png")
                    default-main-art))
    :main-texture nil      # decoded once, on demand
    :main-attempted false  # decode has been tried (not the same as success)
    :main-failed false     # decode failed; fall back to the gradient, quietly
    :tip (or (get o :tip) nil)})

(defn paths [screen] (screen :paths))
(defn loaded-count [screen] (screen :loaded))
(defn fallback? [screen]
  "True when no background decoded, so the gradient is what is on screen."
  [screen]
  (zero? (screen :loaded)))

#
# --- Texture lifecycle (GL) ---------------------------------------------
#

(defn- image-field-offsets [t]
  (map |($ :offset) ((ffi/struct-info t) :fields)))

(def image-offsets (image-field-offsets rl/image-type))

(defn- read-image [value]
  "Marshal an Image struct value into a mutable buffer raylib can take a pointer to."
  (def buf (buffer/new-filled (ffi/size rl/image-type) 0))
  (for i 0 5
    (ffi/write (get [:ptr :int :int :int :int] i) (get value i) buf
               (get image-offsets i)))
  buf)

(defn- decode-one
  ``Decode and upload one image, downscaled to fit `max-w`x`max-h`.

  Returns the texture, or nil with a reason. Every failure mode of a real
  asset name -- a truncated file, a zero-byte file, a path that vanished
  between discovery and now, a format raylib cannot read -- is caught here, so
  ONE bad image costs one slide and never the screen.

  The downscale matters: these sources are 2752x1536, which is 16 MB of VRAM
  as RGBA. Two resident slides at full size would be 32 MB spent on pixels
  that a 1280x800 window never samples. Resizing on the CPU first means the
  upload is screen-sized.``
  [path max-w max-h]
  (try
    (do
      (def image (rl/load-image path))
      # raylib returns a zeroed Image (data == NULL) rather than throwing when
      # the file cannot be read, so a nil data pointer is the real failure test.
      (if (nil? (get image 0))
        [nil (string "could not decode " path)]
        (do
          (def buf (read-image image))
          (def w (get image 1))
          (def h (get image 2))
          (when (and (number? max-w) (number? max-h)
                     (pos? max-w) (pos? max-h) (pos? w) (pos? h)
                     (or (> w max-w) (> h max-h)))
            # Fit inside the box without upscaling and without changing aspect.
            (def scale (min (/ max-w w) (/ max-h h)))
            (rl/image-resize buf (max 1 (math/floor (* w scale)))
                             (max 1 (math/floor (* h scale)))))
          (def sized (ffi/read rl/image-type buf))
          (def texture (rl/load-texture-from-image sized))
          # Bilinear, not point: a photograph scaled to the framebuffer is the
          # one place in this project where nearest-neighbour is wrong.
          (rl/set-texture-filter texture rl/texture-filter-bilinear)
          (rl/unload-image sized)
          [texture nil])))
    ([err] [nil (string err)])))

(defn ensure-loaded
  ``Decode up to `limit` backgrounds that are not decoded yet. Returns the
  total number loaded, counting earlier calls.

  Deferred out of `new` because raylib textures need an initialised GL context,
  but NOT done all at once: four 2752x1536 PNGs are ~0.5 s of CPU, and paying
  that in the frame where the window first appears is exactly the hitch that
  makes a loading screen feel worse than no loading screen. `draw` therefore
  decodes ONE image per frame by default -- the first frame paints the
  gradient immediately and the photograph fades in a frame or two later, which
  reads as intentional rather than as a stall.

  `limit` lets a caller that genuinely wants everything early (a capture, a QA
  run) ask for it: `(ensure-loaded screen w h 4)`. Calls are cumulative and
  idempotent -- a path already decoded is never decoded twice, and a failure is
  counted once and skipped thereafter.``
  [screen max-w max-h &opt limit]
  # `LoadTextureFromImage` without an initialised GPU SEGFAULTS -- raylib logs
  # "GPU is not ready" and then dereferences a null GL function pointer, which
  # no `try` can catch. Checking here turns a process crash into a no-op, so a
  # caller that gets the ordering wrong loses a background instead of the game.
  (if (not (rl/window-ready?))
    (screen :loaded)
    (do
  (def paths (screen :paths))
  (def want (if (and (number? limit) (pos? limit)) (math/floor limit) 1))
  (def textures (or (screen :textures) @[]))
  (put screen :textures textures)
  # `:next-path` is the index into :paths of the next undecoded candidate, so
  # progress survives across frames without rescanning the list.
  (var cursor (or (screen :next-path) 0))
  (var decoded 0)
  (var failures (screen :failures))
  (while (and (< cursor (length paths)) (< decoded want))
    (def path (get paths cursor))
    (++ cursor)
    (def [texture reason] (decode-one path max-w max-h))
    (if texture
      (do (array/push textures texture) (++ decoded))
      (do (++ failures)
          (eprint (string "warning: loading background " reason)))))
  (put screen :next-path cursor)
  (put screen :failures failures)
  (put screen :loaded (length textures))
  # `:attempted` now means "every candidate has been tried", not "decode ran
  # once" -- the distinction is what lets dispose and the gradient fallback
  # share one code path regardless of how many frames the decode took.
  (when (>= cursor (length paths)) (put screen :attempted true))
  (screen :loaded))))

(defn dispose
  ``Unload every texture this screen owns. Idempotent.

  Must be called on ALL exit paths -- a normal start, a failed load, a cancel,
  and both process-exit branches. A GL texture is not garbage collected, so a
  missed call leaks VRAM for the life of the process. Calling twice is a no-op
  rather than an error, because the exit path that runs after a failure is
  exactly the one that is easiest to double-run.``
  [screen]
  (when-let [textures (screen :textures)]
    (each texture textures
      (try (rl/unload-texture texture) ([_] nil)))
    (put screen :textures @[])
    (put screen :loaded 0))
  (when-let [texture (screen :main-texture)]
    (try (rl/unload-texture texture) ([_] nil))
    (put screen :main-texture nil))
  (put screen :attempted true)
  screen)

#
# --- Drawing helpers ----------------------------------------------------
#

(defn- draw-text-shadowed
  "Draw `text` with a 1px shadow, so it holds an edge over a bright sky."
  [text x y size color]
  (rl/draw-text text (+ (math/floor x) 1) (+ (math/floor y) 1) size col-shadow)
  (rl/draw-text text (math/floor x) (math/floor y) size color))

(defn- draw-text-tracked
  "Draw `text` with extra letter spacing, returning the x after the last glyph."
  [text x y size color tracking]
  (var cx x)
  (each i (range (length text))
    (def glyph (string/slice text i (+ i 1)))
    (draw-text-shadowed glyph cx y size color)
    (+= cx (+ (rl/measure-text glyph size) tracking)))
  cx)

(defn- draw-scrim [width height]
  "Legibility gradients, not a black wash: bottom band and left column only."
  # Alphas are measured, not guessed: 150 at the bottom (bar labels sit there)
  # and 190 at the left edge, where the title sits over the brightest part of a
  # sky. Both fall off to zero so the photograph is still visible in the middle
  # -- that is the difference between a scrim and a black wash.
  (def bottom-h (math/floor (* height 0.42)))
  (rl/draw-rectangle-gradient-v 0 (- height bottom-h) width bottom-h
                                [0x00 0x00 0x00 0x00] [0x00 0x00 0x00 0xbe])
  (def left-w (math/floor (* width 0.52)))
  (rl/draw-rectangle-gradient-h 0 0 left-w height
                                [0x00 0x00 0x00 0xbe] [0x00 0x00 0x00 0x00]))

(defn- draw-slide [texture width height alpha]
  # Texture2D { uint id; int width; int height; int mipmaps; int format; } is
  # returned as a positional tuple, not a keyed table: read the fields the same
  # way atlas.janet reads Image fields, by index.
  (def src-w (get texture 1))
  (def src-h (get texture 2))
  (def [sx sy sw sh] (cover src-w src-h width height))
  (rl/draw-texture-pro texture
                       [sx sy sw sh]
                       [0 0 width height]
                       [0 0]
                       0.0
                       [0xff 0xff 0xff alpha]))

# Human labels for the internal stage keywords the caller passes. A state
# machine names its states for the code that switches on them, not for a
# reader: rendering `:await` at the user produced "WAIT", which reads as an
# instruction rather than as a description of what the program is doing. Any
# keyword not listed here falls back to a title-cased form, so an unanticipated
# state still reads as a sentence fragment instead of SHOUTING.
(def stage-labels
  {:probe "Preparing"
   :await "Generating terrain"
   :wait "Generating terrain"
   :await-tiles "Generating terrain"
   :build-world "Building the world"
   :build-meshes "Building the world"
   :meshing "Meshing chunks"
   :ready "Starting"
   :failed "Could not start"
   :cancelled "Cancelled"
   :timed-out "Timed out"})

(defn- title-case [s]
  "First letter upper, the rest left alone -- `foo bar` -> `Foo bar`."
  (if (empty? s)
    s
    (string (string/ascii-upper (string/slice s 0 1)) (string/slice s 1))))

(defn stage-text
  ``A sentence-fragment label for a stage keyword or string.

  Internal keywords are mapped through `stage-labels`; anything unmapped is
  de-snaked and title-cased rather than upper-cased, because a full-caps label
  competes with the title for attention and reads as a command.``
  [view]
  (def stage (get view :stage))
  # `(string :await)` is "await" with no colon, so there is nothing to strip --
  # slicing here silently ate the first letter of every unmapped keyword.
  (cond
    (nil? stage) ""
    (keyword? stage) (or (get stage-labels stage)
                         (title-case (string/replace-all "_" " " (string stage))))
    (string? stage) (or (get stage-labels (keyword stage))
                        (title-case (string/replace-all "_" " " stage)))
    ""))

#
# --- The frame ----------------------------------------------------------
#

(defn ensure-main-loaded
  ``Decode the home-screen artwork once. Returns the texture, or nil.

  Deliberately NOT part of `ensure-loaded`: the slideshow is a rotating set of
  interchangeable photographs, while this is one designed image with its own
  baked logo, subtitle and characters. Sharing a decode path would put the main
  art in a rotation it must never join.

  Bounded and single-shot like the slideshow decode: one attempt, no retry, so
  a missing asset costs one stat rather than a stat per frame. Failure is silent
  to the screen (the gradient is the fallback) but recorded, because a designer
  whose title art silently vanished deserves to find out from a test rather than
  from a screenshot.``
  [screen max-w max-h]
  (cond
    (screen :main-texture) (screen :main-texture)
    (or (screen :main-attempted) (not (rl/window-ready?))) nil
    true
    (do
      (put screen :main-attempted true)
      (def path (screen :main-art))
      (if (or (not (string? path)) (empty? path) (not (os/stat path)))
        (do (put screen :main-failed true) nil)
        (let [[texture reason] (decode-one path max-w max-h)]
          (if texture
            (do (put screen :main-texture texture) texture)
            (do (put screen :main-failed true)
                (eprint (string "warning: home artwork " reason))
                nil)))))))

(defn paint-main-background
  ``Paint the HOME screen backdrop: the dedicated artwork, or the gradient.

  Never the slideshow. The home screen shows one designed image whose logo,
  subtitle and characters are part of the composition; rotating it with the
  loading photographs would move a logo that the artwork fixed in place, and
  fading it would cross-fade a title with a landscape.

  No scrim is painted here. The menu's readability is its own responsibility and
  a full-frame wash would destroy exactly the artwork this exists to show --
  `menu-view` paints a panel behind its own text instead.``
  [screen width height]
  (when (and (rl/window-ready?)
             (number? width) (number? height) (pos? width) (pos? height))
    (rl/draw-rectangle-gradient-v 0 0 width height
                                  col-grad-top col-grad-bottom)
    (when-let [texture (ensure-main-loaded screen width height)]
      # Opaque, full-frame, cover-cropped: the artwork is a poster, not a
      # wallpaper being tinted.
      (draw-slide texture width height 255)))
  (if (screen :main-texture) 1 0))

(defn paint-background
  ``Paint the full-frame artwork only: gradient, then the slideshow slide(s).

  Public because the MENU needs exactly this and nothing else. Keeping it here
  rather than in the menu means a single presenter instance serves both screens
  -- one decode, one slideshow clock, one texture set -- which is the difference
  between "the art continues" and "the art restarts when the menu closes".

  Advances the slideshow clock itself, so a caller that paints the menu with
  this and then hands the same screen to `draw` gets a continuous cycle rather
  than a jump.

  Returns the number of textures loaded so far. Zero means the gradient is the
  whole background, which is the correct look for a fresh clone with no assets.``
  [screen width height]
  # `draw-rectangle-gradient-v` is a GL call and SEGFAULTS with no window, the
  # same way LoadTextureFromImage does -- raylib calls through a null GL pointer
  # rather than raising, so no `try` can catch it. Guarding here keeps the
  # documented rule true: this module may be constructed and asked to paint
  # before `init-window`, and doing so must be a no-op, not a crash.
  (if (not (and (rl/window-ready?)
                (number? width) (number? height) (pos? width) (pos? height)))
    # Refused: report the count that is actually loaded. Returning nil here
    # made callers unable to tell "no window" from "no assets" by arithmetic.
    (screen :loaded)
    (do
    (def dt (rl/get-frame-time))
    (when (and (number? dt) (pos? dt)) (+= (screen :elapsed) dt))
    # Base coat. Always painted, even under a photograph: a partially
    # transparent or truncated asset must not reveal the window's clear colour,
    # which is whatever the last frame left behind.
    (rl/draw-rectangle-gradient-v 0 0 width height
                                  col-grad-top col-grad-bottom)
    # ONE decode per frame, so the first frame is the gradient alone and appears
    # immediately; failures fall through to it.
    (def loaded (ensure-loaded screen width height 1))
    (when (pos? loaded)
      (def textures (screen :textures))
      (def [index alpha] (cycle-position (screen :elapsed)
                                         (screen :cycle-seconds)
                                         (screen :fade-seconds)
                                         loaded))
      (def current (get textures index))
      (def next-index (mod (+ index 1) loaded))
      (def upcoming (get textures next-index))
      # Draw the OUTGOING slide first at its own alpha, then the incoming over
      # it. With one image both are the same texture and the second draw is
      # skipped, which is why a single-asset install has no fade at all.
      (when (and (> loaded 1) (< alpha 255))
        (draw-slide current width height alpha)
        (draw-slide upcoming width height (- 255 alpha)))
      (when (or (= loaded 1) (= alpha 255))
        (draw-slide current width height 255)))
    loaded)))

(defn paint-scrim
  ``The legibility gradients alone, for a screen that supplies its own text.

  The menu needs the darkening but none of the loading text; drawing the menu on
  bare artwork makes the type unreadable over a bright sky, which is the exact
  failure the scrim exists to prevent. Same constants as `draw`, so the two
  screens agree on how dark "dark enough" is.``
  [width height]
  # Same GL readiness rule as `paint-background`: no window, no gradient call.
  (when (and (rl/window-ready?)
             (number? width) (number? height) (pos? width) (pos? height))
    (draw-scrim width height)))


(def bar-min-width 380)   # never narrower than a readable bar
(def bar-max-width 620)
(def bar-span 0.34)       # sample places it across ~33..66% of frame width
(def bar-thickness 18)
(def frame-thickness 5)

(defn bar-geometry
  ``Where the loading bar sits, as `[x y w h]`, from the frame size.

  Derived rather than hardcoded so the sample's proportions survive a resize:
  centred horizontally, spanning ~34% of the width, sitting at ~86-93% of the
  height. Clamped to a minimum width so a narrow window still shows a bar
  rather than a sliver.``
  [width height]
  (def w (max bar-min-width (min bar-max-width (math/floor (* width bar-span)))))
  (def h bar-thickness)
  (def x (math/floor (- (/ width 2) (/ w 2))))
  (def y (math/floor (* height 0.88)))
  [x y w h])

(defn- fill-bar
  "One solid rectangle, shadowed so it reads on a busy photograph."
  [x y w h color]
  (when (pos? w)
    (rl/draw-rectangle (+ (math/floor x) 2) (+ (math/floor y) 2)
                       (math/floor w) (math/floor h) col-shadow)
    (rl/draw-rectangle (math/floor x) (math/floor y)
                       (math/floor w) (math/floor h) color)))

(defn draw-moss-bar
  ``The moss-framed loading bar, with its LIVE fill and a real percentage.

  The sample image has a bar baked into the picture; this is the same bar drawn
  live, so the fill and the number always describe the actual state. Nothing
  here invents progress: `ready/total` is the caller's measured count, and when
  it is absent the bar is drawn empty and the label says so rather than
  pretending to be 0% of a job.

  When `total` is nil or zero the bar is INDETERMINATE: the frame is drawn and a
  band sweeps across it, with no percentage, because there is no denominator to
  divide by. That is the honest rendering for a generation phase that reports a
  stage and a sentence but no count -- a 0% bar would claim progress had not
  started, and an invented fraction would be worse.

  Returns `[x y w h]` so a test can assert the placement without a GPU.``
  [width height ready total &opt stage-name]
  (def [x y w h] (bar-geometry width height))
  # Stone frame: a dark outer rule with a lighter inner rule, which reads as a
  # carved border rather than a rectangle outline at this thickness.
  (fill-bar (- x frame-thickness) (- y frame-thickness)
            (+ w (* 2 frame-thickness)) (+ h (* 2 frame-thickness))
            col-frame-outer)
  (fill-bar (- x 2) (- y 2) (+ w 4) (+ h 4) col-frame-inner)
  (fill-bar x y w h col-bar-bg)
  (def determinate? (and (number? total) (pos? total)))
  (def frac (if determinate?
              (bar-frac (if (number? ready) ready 0) total)
              0))
  (def filled (math/floor (* w frac)))
  # Indeterminate: a band that sweeps. Derived from the caller's own clock so it
  # needs no state here and stays deterministic in a test.
  (def sweep-w (math/floor (/ w 3)))
  (def sweep-x
    (if determinate?
      0
      (let [span (+ w sweep-w)
            # `mod`, not `math/mod`: Janet's remainder operator handles the
            # positive operands here and needs no import.
            t (mod (* 0.5 (rl/get-time)) 1.0)]
        (math/floor (- (* span t) sweep-w)))))
  (when (and (not determinate?) (pos? w))
    # The sweep, clipped to the bar by drawing it as three rects: the part
    # left of the bar start, the visible slice, and the part past the end.
    (def sx (max 0 (min w (+ sweep-x 0))))
    (def ex (max 0 (min w (+ sweep-x sweep-w))))
    (when (> ex sx)
      (fill-bar (+ x sx) y (- ex sx) h col-fill-cyan)
      (fill-bar (+ x sx) y (- ex sx) (max 2 (math/floor (/ h 3))) col-fill-glow)))
  (when (and determinate? (pos? filled))
    # CYAN -> PURPLE, stepped rather than smoothly interpolated: three nested
    # rectangles are enough to read as a gradient at 18px tall, and they cost
    # nothing. A real gradient would need a shader, which this module has no
    # business adding for one bar.
    (def third (math/floor (/ filled 3)))
    (def two-thirds (* 2 third))
    # Body: cyan at the left, purple at the right, with the boundary at the
    # two-thirds mark where the eye reads the transition.
    (fill-bar x y two-thirds h col-fill-cyan)
    (fill-bar (+ x two-thirds) y (- filled two-thirds) h col-fill-purple)
    # Glow: a lighter band along the top of the fill, then a bright core at
    # the leading edge. Two rects, and the leading edge is what makes a bar
    # look lit rather than printed.
    (fill-bar x y filled (max 2 (math/floor (/ h 3))) col-fill-glow)
    (when (>= filled 6)
      (fill-bar (- (+ x filled) 4) y 4 h col-fill-core)))
  # Label centred ON the bar, as in the sample.
  #
  # Determinate: the real percentage. Indeterminate: the words "progress not
  # reported" -- not "...". An ellipsis is ambiguous between "loading" and "the
  # number is missing", and this screen exists to say which. `stage-name`, when
  # the caller supplies one, is preferred because it is SPECIFIC ("Generating").
  (def label-pct (string "LOADING  " (math/floor (* 100 frac)) "%"))
  (def label-unknown
    (if (and (string? stage-name) (not (empty? stage-name)))
      (string/ascii-upper (string stage-name) "  -  progress not reported")
      "LOADING  -  progress not reported"))
  (def text (if determinate? label-pct label-unknown))
  (def tw (rl/measure-text text size-small))
  (draw-text-shadowed text
                      (+ x (math/floor (/ (- w tw) 2)))
                      (+ y (math/floor (/ (- h size-small) 2)) -2)
                      size-small col-text)
  [x y w h])

(defn- ctx-percent
  "Integer percent of the measured count, or nil when nothing is known."
  [ready total]
  (when (and (number? total) (pos? total) (number? ready))
    (math/floor (* 100 (bar-frac ready total)))))

(defn choose-tip
  ``Pick a tip that is TRUE for the state the loader is actually in.

  The old line said "tiles are generated on first launch and can take several
  minutes" unconditionally, which is a lie whenever the cache is already baked
  and the loader is only checking it. A tip is allowed to be generic; it is not
  allowed to describe work that is not happening.

  Two other rules, both from the reference's own mistake: no promise of an
  ability that does not exist (its sample conjures nothing here), and no claim
  about the artwork itself.

  Returns a string.``
  [view]
  (def ready (get view :ready))
  (def total (get view :total))
  (def pct (ctx-percent ready total))
  (cond
    # Nothing measured, nothing to say about progress.
    (nil? total) "TIP: Press F to switch between walking and flying."
    # Complete but the stage has not advanced: checking, not generating.
    (and pct (>= pct 100))
    "TIP: Press F to switch between walking and flying."
    # Partway through: the honest statement is that tiles are arriving.
    (and pct (pos? pct))
    "TIP: Terrain tiles arrive one at a time; the map grows as they land."
    # Zero reported: generation genuinely may take minutes.
    "TIP: Tiles are generated on first launch and can take several minutes."))

(defn draw-tip
  ``One muted tip line near the bottom, as the sample has.

  A tip is a FACT or an instruction, never a prediction: "several minutes on
  first launch" is a warning the operator can act on, "almost there" is not.``
  [width height tip]
  (when (and (string? tip) (not (empty? tip)))
    (def chars (max 20 (math/floor (/ (- width (* 2 pad-left)) 9))))
    (each line (wrap-text tip chars 1)
      (def tw (rl/measure-text line size-tiny))
      (draw-text-shadowed line
                          (math/floor (- (/ width 2) (/ tw 2)))
                          (- height 46) size-tiny col-muted))))

(defn draw
  ``Draw one loading frame. Call INSIDE an existing begin/end-drawing pair.

  Never opens or closes drawing: the caller owns the frame, because the same
  frame may later grow a console or a panel and this module must not fight it
  for that state.

  Every field of `view` is optional. A missing count renders as absent rather
  than as zero -- "0 / 25" and "not reported" are different facts and the
  screen must not blur them.``
  [screen model width height]
  (when (and (number? width) (number? height) (pos? width) (pos? height))
    (def view (or model {}))
    # NO clock advance here: `paint-background` owns it. Advancing in both
    # places doubled the slideshow rate on the loading screen only, which is
    # the kind of bug that looks like "the fade timing is wrong" rather than
    # "the clock is ticked twice".

    # 1-2. Artwork: base coat plus slideshow. Extracted so the MENU paints the
    #      identical thing from the SAME presenter instance -- one decode, one
    #      clock, one set of textures across both screens.
    (paint-background screen width height)

    # 3. Scrim, then 4. text -- text last so the fade can never tint it.
    (draw-scrim width height)

    (def x pad-left)
    (var y pad-top)
    (draw-text-tracked "TRINECRAFT" x y size-title col-title title-tracking)
    (+= y (+ size-title 12))
    (draw-text-shadowed "Growing your world" x y size-subtitle col-subtitle)
    (+= y (+ size-subtitle 40))

    (def error (get view :error))
    (def failed (or error (= :failed (get view :stage))
                    (= "failed" (get view :stage))))
    (if failed
      # An error block replaces the stage line: two lines competing for the
      # same slot would make the failure read as a status, and the reason is
      # the only thing worth reading at that point.
      (do
        (draw-text-shadowed "COULD NOT START" x y size-stage col-error)
        (+= y (+ size-stage 10))
        (def chars (max 20 (math/floor (/ (- width (* 2 pad-left)) 10))))
        (each line (wrap-text (or error "the terrain could not be prepared")
                              chars 4)
          (draw-text-shadowed line x y size-small col-text)
          (+= y (+ size-small 6)))
        (+= y 16))
      (do
        # `stage-text` already produced a sentence fragment; upper-casing it
        # here would undo the mapping and shout the state machine at the user.
        (def head (stage-text view))
        (def detail (and (string? (get view :detail)) (get view :detail)))
        (def line (if (empty? head)
                    (or detail "")
                    (if detail (string head "  -  " detail) head)))
        (when (not (empty? line))
          (draw-text-shadowed line x y size-stage col-stage)
          (+= y (+ size-stage 16)))))

    # Readiness bar, emulating the sample's framing WITHOUT its baked fake bar:
    # the sample is a still with a static bar painted in. This is the live one,
    # in the same place, driven by a real count.
    (def total (get view :total))
    (def ready (get view :ready))
    # A bar is drawn whenever the caller is LOADING something, counted or not.
    # A generation phase that reports a stage but no count gets the
    # indeterminate sweep; a phase with a count gets the real fill. Suppressing
    # the bar entirely -- the old behaviour -- made generation look like a
    # plain text screen, which is exactly what was reported missing.
    (when (or (and (number? total) (>= total 0)) (get view :stage))
      (def shown-ready (if (number? ready) ready 0))
      (draw-moss-bar width height shown-ready total (get view :stage-name))
      (+= y (+ size-count 12)))

    # Chunk/mesh counts: a separate field, drawn only when supplied. These are
    # NOT readiness -- they are progress through work that only starts once the
    # tiles exist -- so folding them into one number would double-count.
    (def chunk-ready (get view :chunk-ready))
    (def mesh-ready (get view :mesh-ready))
    (when (or (number? chunk-ready) (number? mesh-ready))
      (def parts @[])
      (when (number? chunk-ready)
        (array/push parts (string "chunks " (math/floor chunk-ready) " / "
                                 (math/floor (or total 0)))))
      (when (number? mesh-ready)
        (array/push parts (string "meshes " (math/floor mesh-ready) " / "
                                 (math/floor (or total 0)))))
      (draw-text-shadowed (string/join parts "    ") x y size-small col-muted)
      (+= y (+ size-small 16)))

    (def elapsed (get view :elapsed))
    (when (number? elapsed)
      (draw-text-shadowed (string "elapsed " (format-elapsed elapsed))
                    x y size-tiny col-muted))

    # Footer, pinned: the hint may be long, so it never competes with the
    # counts for vertical space.
    (def hint (get view :hint "Esc to cancel"))
    (draw-text-shadowed hint pad-left (- height 76) size-tiny col-muted)
    # TIP line, centred, matching the sample's bottom line.
    # The tip is contextual: an explicit override wins, then the screen's own,
    # then the truthful per-stage default.
    (draw-tip width height
              (or (get view :tip) (screen :tip) (choose-tip view)))
    (when (< (if (number? ready) ready 0) (if (number? total) total 0))
      (rl/draw-text
        "Tiles are generated on first launch and can take several minutes."
        pad-left (- height 52) size-tiny col-muted))
    screen))
