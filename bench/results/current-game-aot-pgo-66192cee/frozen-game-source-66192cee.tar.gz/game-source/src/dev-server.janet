# Trinecraft — development socket server.
#
# A line-oriented REPL socket into the LIVE game, for driving the engine from
# an external editor (Emacs) instead of from the in-game console.
#
# Four constraints shape this file, and all four are load-bearing:
#
# 1. THE FRAME LOOP MUST NEVER BLOCK OR SUSPEND. raylib's window and GL
#    context belong to the main thread, so anything that waits would freeze
#    rendering and the OS would mark the window unresponsive. This rules out
#    the obvious implementation: `net/accept` and `ev/read` with a timeout
#    both ARM A GLOBAL TIMEOUT SIGNAL (`janet_addtimeout`), and that signal
#    escapes into whatever the main fiber is doing, aborting unrelated work
#    inside the frame. That is not a theoretical hazard -- it surfaced as a
#    `timeout` error thrown out of `stream/in-radius?` during ordinary
#    streaming.
#
#    So the waiting happens in DEDICATED FIBERS, which may block freely, and
#    the frame loop only ever uses `ev/try-take`, which by contract never
#    suspends. A reader fiber per connection does the blocking `ev/read`; the
#    frame loop drains a channel.
#
# 2. THE EVALUATOR IS ALREADY WRITTEN. `console/evaluate` runs source inside an
#    :e-masked fiber, trapping both compile and runtime errors, and captures
#    printed output. A second evaluator here would be a second place for the
#    game to die, so this module imports that one and does not reinvent it.
#
# 3. NO LISTENER UNLESS ASKED. An open eval port is remote code execution for
#    anything that can reach it. The caller decides whether to construct a
#    server at all; this module has no default port and no autostart.
#
# 4. EVALUATION HAPPENS ON THE FRAME LOOP, NOT IN A READER FIBER. Game state is
#    single-threaded and the evaluator mutates it directly. Evaluating from a
#    fiber that is merely cooperative would still interleave with a frame in
#    progress, so the reader fibers only ever move BYTES; decoding and
#    evaluating is done by `pump` between frames.
#
# Protocol. One request is one line of Janet source. Replies are a single
# line:  `ok <printed output> => <value>`  or  `err <printed output> => <error>`.
# Newlines inside output are escaped as `\n` so a reply is unambiguously one
# line and the client never has to parse a continuation state.

(import ./console :as console)
(import ./rl :as rl)

(def default-port 0)          # 0 asks the OS for a free port
(def max-line-bytes 65536)    # refuse runaway input rather than buffering it
(def max-connections 16)      # a dev socket needs a handful, not a swarm
(def inbox-capacity 256)      # queued events before a reader is throttled

#
# --- Reply formatting ---------------------------------------------------
#

(defn escape-reply
  ``Collapse a value's string form onto one line.

  The protocol is line-delimited, so any raw newline would desynchronize the
  client. Escaping backslash first is not optional: doing it second would
  turn the backslashes this function inserts into escaped backslashes.``
  [s]
  (def out @"")
  # Iterate bytes, not characters: Janet's string iteration yields integers,
  # and every byte under 0x80 is its own character in the sequences that
  # matter here (newline, carriage return, backslash).
  (each b (string s)
    (cond
      (= b 10) (buffer/push-string out "\\n")
      (= b 13) (buffer/push-string out "\\r")
      (= b 92) (buffer/push-string out "\\\\")
      (buffer/push-byte out b)))
  (string out))

(defn format-reply
  ``Render one evaluation result as a single protocol line.

  `%q` is used for values so strings stay visually distinct from symbols and
  a client can tell `"3"` from `3` without a second round trip.``
  [result]
  (def output (escape-reply (or (result :output) "")))
  (if (result :ok)
    (string "ok " output " => "
            (if (nil? (result :value))
              "nil"
              (try (string/format "%q" (result :value))
                   ([err] (string "<unprintable: " err ">")))))
    (string "err " output " => "
            (escape-reply (string (result :error))))))

#
# --- State --------------------------------------------------------------
#

(defn server-new
  ``Open a listener. Returns nil when the port cannot be bound, so a caller
  can report the failure and keep running instead of dying on startup.

  `con` is the live console whose environment the socket evaluates against --
  that is what makes the socket and the `~` prompt the same REPL with two
  front ends, rather than two REPLs with two environments.``
  [con &opt host port]
  (def listener
    (try (net/listen (or host "127.0.0.1") (string (or port default-port)) :stream)
         ([err] (eprint (string "dev-server: cannot listen: " err))
                nil)))
  (when listener
    @{:listener listener
      :con con
      :connections @[]
      :inbox (ev/chan inbox-capacity)
      :port nil                 # filled by `bound-port` once resolvable
      :served 0                 # total forms evaluated, for status
      :acceptor nil
      :closed false}))

(defn bound-port
  ``The port actually bound. Resolving it matters because port 0 is the
  useful default -- it lets several dev sessions coexist -- and the client
  cannot guess which port the OS picked. `net/localname` returns
  `[host port]`; anything else is treated as unresolvable rather than
  guessed at.``
  [server]
  (or (server :port)
      (do
        (def info (try (net/localname (server :listener)) ([err] nil)))
        (def p (if (and (indexed? info) (>= (length info) 2))
                 (get info 1)
                 nil))
        (when (number? p)
          (put server :port p)
          p))))

(defn connection-count [server] (length (server :connections)))

#
# --- Acceptor and reader fibers -----------------------------------------
#
# These are the only places that block. They live outside the frame loop so
# that waiting here cannot suspend rendering or arm a global timeout.
#

(defn- emit
  ``Hand one event to the frame loop.

  A give can fail because the channel is closed -- the server may shut down
  while a reader is still parked in `ev/read`. That is an ordinary shutdown
  race, not a fault, so it ends the reader quietly instead of raising out of
  a fiber nobody is watching.``
  [server event]
  (try (ev/give (server :inbox) event)
       ([err] nil)))

(defn- reader-fiber
  ``Block on this connection forever, forwarding received bytes as events.

  Only bytes cross the channel; no decoding and no evaluation happens here,
  because that would touch game state off the frame loop.

  A reader exits on EOF, on error, or once the server is closed -- and it
  always announces its departure so `pump` can prune the connection.``
  [server conn]
  (fn []
    (var running true)
    (while running
      (def chunk (buffer/new 4096))
      (def outcome (try [:ok (ev/read (conn :stream) 4096 chunk)]
                        ([err] [:err err])))
      (case (outcome 0)
        :err
        (do (emit server [:closed conn])
            (set running false))
        :ok
        (if (nil? (outcome 1))
          (do (emit server [:closed conn])
              (set running false))
          (if (pos? (length chunk))
            (emit server [:data conn (string (buffer/slice chunk 0 (length chunk)))])
            # An empty read should not busy-spin this fiber.
            (ev/sleep 0.001)))))
    conn))

(defn- start-acceptor
  ``Accept connections forever, in a fiber, so `pump` never waits for one.

  The listener is not closed here; `close` closes it, which makes the blocked
  `net/accept` fail and the loop exit.``
  [server]
  (ev/go (fn []
           (var running true)
           (while running
             (def outcome (try [:ok (net/accept (server :listener))]
                               ([err] [:err err])))
             (if (= :ok (outcome 0))
               (emit server [:accept (outcome 1)])
               (set running false)))
           server)))

(defn start
  ``Begin accepting. Separate from `server-new` so tests can build a server
  without background fibers racing them.``
  [server]
  (when server
    (unless (or (server :closed) (server :acceptor))
      (set (server :acceptor) (start-acceptor server))))
  server)

#
# --- Per-frame pump -----------------------------------------------------
#

(defn- connection-new [server stream]
  (def conn @{:stream stream
              :buffer @""
              :closed false})
  # Start the reader only after the connection exists, so its events always
  # carry a reference `pump` can resolve.
  (ev/go (reader-fiber server conn))
  conn)

(defn- close-connection [conn]
  (unless (conn :closed)
    (set (conn :closed) true)
    (try (:close (conn :stream)) ([err] nil)))
  conn)

(defn- send-line [conn line]
  (unless (conn :closed)
    (try
      (:write (conn :stream) (string line "\n"))
      ([err] (close-connection conn)))))

(defn- respond
  ``Handle one complete request line.

  A blank line is ignored rather than evaluated: a client that sends trailing
  newlines should not get a stream of `nil` replies.``
  [server conn line]
  (def trimmed (string/trim line))
  (if (= trimmed "")
    @{:ok true :value nil :output ""}
    (do
      (def result (console/evaluate (server :con) trimmed))
      (++ (server :served))
      (send-line conn (format-reply result))
      result)))

(defn- take-data
  ``Append received bytes and evaluate every complete line.

  Bounded: the caller drains at most a fixed number of events per frame, so a
  flooding client cannot monopolize a frame. Completed lines are capped per
  connection per frame for the same reason.``
  [server conn text]
  (buffer/push-string (conn :buffer) text)
  (when (> (length (conn :buffer)) max-line-bytes)
    (close-connection conn))
  (unless (conn :closed)
    (var handled 0)
    (while (and (< handled 16) (not (conn :closed)))
      (def buf (string (conn :buffer)))
      (def nl (string/find "\n" buf))
      (if nl
        (do
          (def line (string/slice buf 0 nl))
          (def rest (string (string/slice buf (+ nl 1))))
          (set (conn :buffer) @"")
          (buffer/push-string (conn :buffer) rest)
          (respond server conn line)
          (++ handled))
        (set handled 16))))
  conn)

(defn pump
  ``One bounded slice of server work, called once per frame.

  WHY THE YIELD. Janet runs ev fibers -- the acceptor and the readers -- only
  when the main fiber suspends. A pure render loop never suspends, so without
  a yield the acceptor would be created and never execute: the socket would
  listen and serve nothing. `ev/sleep 0` is a zero-duration suspension,
  measured at ~1.8 microseconds of CPU, so it costs essentially nothing per
  frame while letting the network fibers make progress.

  Only `ev/try-take` is used to drain results, and that never suspends, so the
  frame loop still cannot be parked by a slow or hostile client. Work is
  capped at a small number of events per frame, and a backlog waits for the
  next frame. Returns the number of events processed; 0 on an idle frame.``
  [server &opt max-events]
  (default max-events 32)
  (if (nil? server)
    0
    (do
      (ev/sleep 0)
      (def events (server :inbox))
      (var processed 0)
      (var running true)
      (while (and running (< processed max-events))
        (def event (ev/try-take events))
        (if (nil? event)
          (set running false)
          (do
            (++ processed)
            (case (event 0)
              :accept
              (when (< (connection-count server) max-connections)
                (array/push (server :connections)
                            (connection-new server (event 1))))
              :data
              (take-data server (event 1) (event 2))
              :closed
              (close-connection (event 1))))))
      # Prune dead connections once per pump, not once per event.
      (def live @[])
      (each conn (server :connections)
        (unless (conn :closed) (array/push live conn)))
      (set (server :connections) live)
      processed)))

(defn close
  "Drop every connection and the listener. Idempotent."
  [server]
  (unless (server :closed)
    (set (server :closed) true)
    (each conn (server :connections)
      (close-connection conn))
    (set (server :connections) @[])
    (try (:close (server :listener)) ([err] nil))
    (try (ev/chan-close (server :inbox)) ([err] nil)))
  server)

(defn status
  "A small table for the HUD or an editor status line."
  [server]
  (if server
    @{:port (bound-port server)
      :connections (connection-count server)
      :served (server :served)}
    @{:port nil :connections 0 :served 0}))
