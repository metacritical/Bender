# Pure bounded policy for one persistent patch producer. No threads, process,
# renderer, filesystem, or model ownership lives here.
(def max-coordinate 134217727)
(def max-pending 16)
(def max-history 32)
(def max-epoch 9007199254740991)

(defn- integer-between? [value lo hi]
  (and (= :number (type value)) (<= lo value hi)
       (= value (math/floor value))))

(defn- coord? [px pz]
  (and (integer-between? px (- max-coordinate) max-coordinate)
       (integer-between? pz (- max-coordinate) max-coordinate)))

(defn- same? [item px pz]
  (and (= px (item :px)) (= pz (item :pz))))

(defn- find-at [items px pz]
  (var found nil)
  (each item items (when (same? item px pz) (set found item)))
  found)

(defn- remove-at! [items px pz]
  (var i 0)
  (while (< i (length items))
    (if (same? (items i) px pz)
      (array/remove items i)
      (++ i))))

(defn- forget-oldest! [scheduler]
  (def history (scheduler :history))
  (when (>= (length history) max-history)
    (array/remove history 0)))

(defn- record! [scheduler item phase]
  (remove-at! (scheduler :history) (item :px) (item :pz))
  (forget-oldest! scheduler)
  (array/push (scheduler :history)
              {:px (item :px) :pz (item :pz) :phase phase :epoch (scheduler :epoch)}))

(defn new [&opt opts]
  "Create a mutable, per-world-identity policy. Caller owns this table and the
   physical producer; never reuse it for a different world identity."
  (def options (or opts {}))
  (def capacity (or (get options :capacity) max-pending))
  (assert (integer-between? capacity 1 max-pending) "pending capacity must be 1..16")
  @{:capacity capacity :epoch 0 :sequence 0 :pending @[] :lease nil :history @[]
    :cx 0 :cz 0 :dx 0 :dz 0})

(defn focus! [scheduler cx cz &opt dx dz]
  "Update priority anchor and forward lookahead vector, each signed and bounded."
  (default dx 0) (default dz 0)
  (assert (and (coord? cx cz) (coord? dx dz)) "invalid bounded patch focus")
  (put scheduler :cx cx) (put scheduler :cz cz)
  (put scheduler :dx dx) (put scheduler :dz dz)
  scheduler)

(defn- rank [scheduler item]
  (def rx (- (item :px) (scheduler :cx)))
  (def rz (- (item :pz) (scheduler :cz)))
  # A bounded forward preference only breaks equal Manhattan-distance ties;
  # nearest always wins. Max products stay below exact 2^53 integer precision.
  (def ahead (+ (* rx (scheduler :dx)) (* rz (scheduler :dz))))
  @[ (+ (math/abs rx) (math/abs rz))
     (- ahead) (item :px) (item :pz) (item :sequence)])

(defn- less-rank? [a b]
  (var less false)
  (var decided false)
  (for i 0 (length a)
    (when (not decided)
      (cond (< (a i) (b i)) (do (set less true) (set decided true))
            (> (a i) (b i)) (set decided true))))
  less)

(defn status [scheduler]
  "Bounded detached snapshot. The lease is a token, never an aliased producer buffer."
  {:epoch (scheduler :epoch)
   :pending (length (scheduler :pending))
   :inflight (if (scheduler :lease) 1 0)
   :lease (when-let [lease (scheduler :lease)]
            {:px (lease :px) :pz (lease :pz) :epoch (lease :epoch)
             :token (lease :token) :cancelled (lease :cancelled)})
   :history (length (scheduler :history))})

(defn request! [scheduler px pz &opt present?]
  "Queue once, unless already pending/leased/published. `present?` is a pure
   caller predicate for durable published patches evicted from bounded history."
  (assert (coord? px pz) "invalid bounded signed patch coordinate")
  (when present? (assert (= :function (type present?)) "present? must be a function"))
  (cond
    (and present? (present? px pz)) :present
    (find-at (scheduler :pending) px pz) :duplicate
    (when-let [lease (scheduler :lease)] (same? lease px pz)) :duplicate
    (when-let [old (find-at (scheduler :history) px pz)]
      (= :published (old :phase))) :published
    (>= (length (scheduler :pending)) (scheduler :capacity)) :full
    true (do (put scheduler :sequence (+ 1 (scheduler :sequence)))
             (array/push (scheduler :pending)
                         {:px px :pz pz :sequence (scheduler :sequence)})
             :queued)))

(defn take! [scheduler]
  "Admit one patch only when no physical worker lease remains, even if cancelled."
  (when (and (nil? (scheduler :lease)) (> (length (scheduler :pending)) 0))
    (var selected nil)
    (each item (scheduler :pending)
      (when (or (nil? selected)
                (less-rank? (rank scheduler item) (rank scheduler selected)))
        (set selected item)))
    (remove-at! (scheduler :pending) (selected :px) (selected :pz))
    (put scheduler :sequence (+ 1 (scheduler :sequence)))
    (def lease @{:px (selected :px) :pz (selected :pz)
                 :epoch (scheduler :epoch) :token (scheduler :sequence)
                 :cancelled false})
    (put scheduler :lease lease)
    {:px (lease :px) :pz (lease :pz) :epoch (lease :epoch)
     :token (lease :token)}))

(defn- matching-lease? [scheduler ticket]
  (def lease (scheduler :lease))
  (and lease (= :struct (type ticket))
       (= (lease :px) (get ticket :px)) (= (lease :pz) (get ticket :pz))
       (= (lease :epoch) (get ticket :epoch))
       (= (lease :token) (get ticket :token))))

(defn complete! [scheduler ticket validated?]
  "Acknowledge the exact physical lease; publish ONLY validated current-epoch
   data. Caller owns artifact validation and publication, not this pure policy."
  (assert (= :boolean (type validated?)) "validated? must be boolean")
  (if (not (matching-lease? scheduler ticket))
    :stale
    (let [lease (scheduler :lease)]
      (put scheduler :lease nil)
      (if (or (lease :cancelled) (not= (lease :epoch) (scheduler :epoch)))
        :discarded
        (do (record! scheduler lease (if validated? :published :failed))
            (if validated? :published :failed))))))

(defn fail! [scheduler ticket]
  (complete! scheduler ticket false))

(defn cancel! [scheduler]
  "Advance epoch, discard queued work, but retain the physical in-flight lease
   until its producer explicitly acknowledges via complete!/fail!."
  (assert (< (scheduler :epoch) max-epoch) "epoch exhausted")
  (put scheduler :epoch (+ 1 (scheduler :epoch)))
  (array/clear (scheduler :pending))
  (array/clear (scheduler :history))
  (when-let [lease (scheduler :lease)] (put lease :cancelled true))
  (status scheduler))

(defn retry! [scheduler px pz]
  "Only a failed patch may be explicitly retried; admission still respects cap."
  (assert (coord? px pz) "invalid bounded signed patch coordinate")
  (def old (find-at (scheduler :history) px pz))
  (if (or (nil? old) (not= :failed (old :phase)))
    :not-failed
    (if (>= (length (scheduler :pending)) (scheduler :capacity))
      :full
      (do (remove-at! (scheduler :history) px pz)
          (request! scheduler px pz)))))
