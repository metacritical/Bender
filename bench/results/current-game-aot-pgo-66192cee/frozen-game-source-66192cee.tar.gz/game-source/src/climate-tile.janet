# Trinecraft — a BOUND READER over the producer's existing climate wire.
#
# OWNERSHIP. This module owns reading and validating climate data that ALREADY
# EXISTS in the producer's format. It owns no file format of its own and writes
# nothing. It does NOT classify: with no measured units there is no honest biome
# to return, so no classifier lives here. It holds no state and imports nothing
# but the interpreter. No GL, no window, no world, no game.
#
# ---------------------------------------------------------------------------
# THE WIRE IS THE PRODUCER'S, NOT THIS MODULE'S
# ---------------------------------------------------------------------------
#
# `tools/scenic_terrain.py` `export_raw(..., climate=)` is the authoritative
# climate format on this project. It does exactly this (`:188-192`):
#
#     climate_values = np.asarray(climate, dtype=np.float32)
#     if climate_values.shape[:2] != values.shape:
#         raise ScenicError("climate must share the elevation grid")
#     arrays["climate"] = climate_values
#
# and records `"has_climate": climate is not None` in the sidecar JSON (`:212`).
# From that source the wire is precisely:
#
#   * an array named "climate" inside the raw export's npz container,
#   * float32,
#   * shape[:2] == the elevation grid, i.e. (height, width) with the channel
#     axis LAST -- (H, W, 5) for the five channels upstream stacks,
#   * row-major, so within a sample the channel turns over fastest, then x, then z.
#
# An earlier version of this module invented a fixed 5140-byte "TDC1" file.
# That was wrong and has been deleted: it duplicated a format the producer
# already defines, and a second definition of the same data is how two readers
# come to disagree about one artifact.
#
# ---------------------------------------------------------------------------
# WHY AN OWNED BUFFER AND NOT A FILE
# ---------------------------------------------------------------------------
#
# Janet cannot decode an npz. The container is a ZIP archive, `np.savez_compressed`
# writes its members with DEFLATE, and this runtime has no inflate, no zip reader
# and no zlib -- verified by probing the interpreter, which reports every one of
# `zip/open`, `zip/read`, `zlib/inflate` and `deflate` as absent. Reading the
# container here would mean hand-writing DEFLATE, which would be a second decoder
# for a format another language owns.
#
# So the boundary is explicit and narrow: an OWNING CACHE LAYER decodes the
# container and hands this module
#
#     (read values shape meta)
#
# where `values` is ONE OWNED, TYPED BUFFER of little-endian float32 already in
# the producer's channel-last order, `shape` is the (height, width, channels)
# triple the producer declared, and `meta` is the raw-export sidecar record.
# `read` is the entry point a cache layer calls; `validate` is the shape it
# delegates to and takes the presence flag already parsed.
#
# That keeps this module pure Janet, keeps the honesty checks where the data
# enters the process, and states the exact contract a cache layer must satisfy.
# Crucially, NO default is invented when those are absent: absence is
# `:unavailable` with no `:values` key at all, so a caller cannot read it as a
# zeroed climate. A ZERO SAMPLE INSIDE a present buffer is a different thing and
# is ACCEPTED -- 0 degrees C is a real datum, and refusing it would discard the
# freezing point, which matters. Only NaN and infinity are refused.

(def version 1)

#: The channel contract, in the producer's last-axis order, with the units the
#: pinned upstream source establishes. Channel 4 is the LAPSE-RATE coefficient,
#: NOT humidity.
#:
#: THE UNIT CHAIN, cited so it can be checked rather than believed:
#:
#:   1. The coarse stage emits `cat([sample * weight_window, weight_window])`
#:      (`world_pipeline.py:1056`): every tensor carries C weighted values PLUS
#:      a blend-weight channel.
#:   2. `_compute_climate` opens with `coarse_init[:-1] / coarse_init[-1:]`
#:      (`:1426`), which is upstream's own de-normalisation, documented verbatim
#:      in `annotated_infinite_panorama.py` `normalize()` -- "dividing the first C
#:      channels by the last recovers the weighted average across overlapping
#:      tiles", clamped at 1e-6 so the divisor is never zero.
#:   3. The conditioning is quantile-matched against WorldClim distributions
#:      (`native/proof/conditioning.c`), whose units are degrees C and mm/year.
#:
#: So the divisor RECOVERS physical magnitude and the channels are physical.
#:
#: WHAT "KNOWN UNITS" DOES AND DOES NOT LICENCE. The units are known from source,
#: so a caller may present this data with those units and rely on the dimensions.
#: What is NOT established is CALIBRATION: no sample has been decoded and checked
#: against a known range, so a threshold in millimetres or degrees is provisional.
#: That distinction mattered for biome classification, which is why none lives
#: here. For reading, validation and sampling it changes nothing, and the reader
#: is therefore usable now.
(def channels
  [:temperature                  # degrees C, elevation-adjusted mean
   :temperature-seasonality      # standard deviation in degrees C
   :precipitation                # millimetres per year
   :precipitation-variability    # coefficient of variation, percent
   :lapse-rate])                 # degrees C per metre

(def channel-count 5)

(def channel-index (zipcoll channels (range channel-count)))

#: How well the units are established.
#:
#:   :source-derived  the dimensions follow from cited source (above). ENOUGH to
#:                    read, validate and sample. THIS IS WHERE THIS MODULE IS.
#:   :measured        additionally, one real sample has been checked against a
#:                    known range, which is what CALIBRATED thresholds would need.
#:
#: Reading does not require `:measured`, and says so rather than implying its data
#: is unusable.
(def unit-basis :source-derived)

(defn units-verified?
  "True when the units are established well enough to READ with. True today."
  []
  (or (= :measured unit-basis) (= :source-derived unit-basis)))

(defn units-measured?
  "True only when a sample has been checked against a known range. False today."
  []
  (= :measured unit-basis))

(def unit-contract
  {:temperature
   {:unit :celsius :confidence :source-derived
    :basis (string "temp_realistic = temp_baseline + beta*max(elev,0) from the "
                   "conditioning temperature, world_pipeline.py:1462")}
   :temperature-seasonality
   {:unit :standard-deviation-celsius :confidence :source-derived
    :basis (string "de-normalised conditioning channel 3; upstream documents a "
                   "x100 form (minecraft_api.py:196) which is NOT confirmed, so "
                   "the magnitude remains open")}
   :precipitation
   {:unit :millimetres-per-year :confidence :source-derived
    :basis (string "de-normalised conditioning channel 4; WorldClim-matched, and "
                   "upstream's precip/PET aridity requires mm/yr "
                   "(minecraft_api.py:381-384)")}
   :precipitation-variability
   {:unit :percent :confidence :source-derived
    :basis (string "de-normalised conditioning channel 5; upstream consumes it as "
                   "a coefficient of variation in percent (minecraft_api.py:198)")}
   :lapse-rate
   {:unit :celsius-per-metre :confidence :source-derived
    :basis "beta_up[0], the fitted lapse coefficient itself, world_pipeline.py:1462"}})

(defn channel-unit [channel] (get (get unit-contract channel) :unit))
(defn units-known? [] (units-verified?))

(defn channel-basis
  "The citation for a channel's unit, or nil for an unknown channel."
  [channel]
  (get (get unit-contract channel) :basis))

(defn- fail [reason] (error (string "climate: " reason)))
(defn- integer? [n] (and (number? n) (= n (math/floor n))))
(defn- finite? [n]
  (and (number? n) (not (nan? n)) (< -1e308 n) (< n 1e308)))

#
# --- Validating the producer's array ------------------------------------
#

(defn shape?
  ``Is `shape` a usable (height, width, channels) triple?

  Requires exactly three axes, positive integer extents, and the five channels
  this contract defines. A (H, W) grid with no channel axis is the shape that
  describes elevation alone, so it is refused rather than guessed at.``
  [shape]
  (and (or (tuple? shape) (array? shape))
       (= 3 (length shape))
       (every? (map (fn [n] (and (integer? n) (pos? n))) shape))
       (= channel-count (get shape 2))))

(defn sample-count
  "How many climate samples `shape` describes: height * width."
  [shape]
  (* (get shape 0) (get shape 1)))

(defn expected-bytes
  ``The exact byte length of a channel-last float32 buffer for `shape`.

  Four bytes per value: the producer declares `dtype=np.float32` explicitly, so
  any other width is a different array rather than a different view.``
  [shape]
  (when (shape? shape) (* (sample-count shape) channel-count 4)))

(defn- le-u32
  "Unsigned 32-bit little-endian integer at `offset`, byte by byte."
  [b o]
  (+ (get b o) (* 256 (get b (+ o 1)))
     (* 65536 (get b (+ o 2))) (* 16777216 (get b (+ o 3)))))

(defn- bits-f32
  ``The finite f32 whose 32-bit pattern is `bits`, or raise.

  Normal, subnormal and zero patterns are all accepted -- unlike a writer, a
  READER must not refuse a value the producer legitimately emitted. NaN and the
  infinities are refused, because they cannot be classified and silently
  substituting zero would invent data.``
  [bits offset]
  (def negative (>= bits 2147483648))
  (def biased (mod (math/floor (/ bits 8388608)) 256))
  (def fraction (mod bits 8388608))
  (when (= biased 255)
    (fail (string "sample " offset " is NaN or infinite; a climate value must be finite")))
  (def magnitude
    (if (= biased 0)
      (math/ldexp (/ fraction 8388608) -126)   # subnormal, including zero
      (math/ldexp (+ 1 (/ fraction 8388608)) (- biased 127))))
  (if negative (- 0 magnitude) magnitude))

(defn- read-f32
  "The little-endian float32 at byte `offset` of `buffer`."
  [buffer offset]
  (bits-f32 (le-u32 buffer offset) (div offset 4)))

#
# --- The bound read -----------------------------------------------------
#

(defn parse-meta
  ``The `has_climate` flag from a raw-export sidecar record, as a boolean.

  `tools/scenic_terrain.py:212` writes `"has_climate": climate is not None`, so
  a JSON sidecar carries `true`/`false` under that key. This accepts the two
  shapes a cache layer can hand over -- a boolean already parsed, or the key
  absent, which means the record predates climate and must be treated as no
  claim. Anything else is refused rather than coerced: a string "false" is not
  false, and guessing here would attach climate to a map that has none.``
  [meta]
  (def record (or meta {}))
  (unless (or (table? record) (struct? record))
    (fail "metadata must be a table"))
  (def v (get record :has_climate))
  (cond
    (nil? v) false
    (= true v) true
    (= false v) false
    (fail (string "metadata :has_climate must be a boolean, got "
                  (string/format "%q" v)))))

(defn validate
  ``Validate one owned, typed climate buffer against the producer's contract.

  `values` is a buffer or string holding little-endian float32 samples in the
  producer's channel-last order, or nil when the producer wrote no climate.
  `shape` is the (height, width, 5) triple the producer declared. `meta` is the
  raw-export sidecar record, which must agree about whether climate is present.

  Returns `{:status :present :shape .. :samples .. :width .. :height .. :bytes ..
  :values <frozen per-channel arrays>}`, or `{:status :unavailable}` when the
  climate is legitimately absent.

  REFUSES, rather than degrading, when the sidecar and the buffer disagree about
  presence, the shape is not channel-last with five channels, the buffer length
  is not exactly what the shape requires, or any sample is NaN or infinite.
  Reads nothing from disk and writes nothing.``
  [values shape declared]
  (unless (boolean? declared)
    (fail "the presence flag must be a boolean; use `read` to parse metadata"))
  (cond
    # No buffer and no claim: the producer wrote no climate. This is the shipped
    # state of every existing map, and it is NOT an error.
    (and (nil? values) (not (truthy? declared)))
    @{:status :unavailable :reason :absent}

    # The sidecar is the producer's own record of whether it wrote climate. A
    # buffer that contradicts it means the pair does not belong together, and
    # reading it would attach climate to the wrong map.
    (and (nil? values) (truthy? declared))
    (fail "metadata declares climate but no buffer was supplied")

    (and (not (nil? values)) (not (truthy? declared)))
    (fail "metadata declares no climate but a buffer was supplied")

    (not (or (buffer? values) (string? values)))
    (fail "climate values must be a buffer or string of raw float32")

    (not (shape? shape))
    (fail (string "shape must be (height width " channel-count "), got "
                  (string/format "%q" shape)))

    (not= (expected-bytes shape) (length values))
    (fail (string "buffer is " (length values) " bytes, shape "
                  (string/format "%q" shape) " requires exactly "
                  (expected-bytes shape)))

    :else
    (let [h (get shape 0)
          w (get shape 1)
          n (sample-count shape)
          per-channel (map (fn [_] (array/new-filled n 0)) (range channel-count))]
      # Channel-major extraction from a channel-last buffer: the byte for sample
      # s and channel c is (s * 5 + c) * 4, so the channel axis turns over
      # fastest within a sample -- the producer's own order.
      (for s 0 n
        (for c 0 channel-count
          (put (get per-channel c) s (read-f32 values (* (+ (* s channel-count) c) 4)))))
      (def out @{})
      (each channel channels
        (put out channel (freeze (get per-channel (get channel-index channel)))))
      @{:status :present
        :height h :width w :samples n :bytes (length values)
        :shape (freeze [h w channel-count])
        :values (freeze out)})))

(defn read
  ``Read one climate array handed over by an owning cache layer.

  TWO CALL SHAPES, one function, so a caller has nothing to get wrong:

    (read nil nil meta)              -- the producer wrote no climate
    (read buffer [h w 5] meta)       -- the producer wrote one

  Returns `{:status :present ...}` or `{:status :unavailable :reason :absent}`,
  and raises on anything malformed. It reads no file: the container is another
  language's format (see the header), so the buffer arrives already decoded and
  this function is the validation boundary.

  This is the ONLY entry point a cache layer needs.``
  [values shape meta]
  (validate values shape (parse-meta meta)))

(defn present? [r] (= :present (get r :status)))
(defn unavailable? [r] (= :unavailable (get r :status)))

#
# --- Deterministic sampling --------------------------------------------
#
# The producer's buffer is addressed by SAMPLE index, not by chunk: one sample is
# one cell of the raw elevation grid. Mapping a world column onto a sample is the
# cache layer's job, because it owns the grid transform. What this module
# guarantees is the arithmetic ONCE it is given a grid index -- pure, channel-last,
# x-fastest, and refusing outside the grid rather than clamping.
#

(defn sample-index
  ``The sample index for grid cell (x, z), x-fastest, or nil outside the grid.

  The producer's matrix convention is `[z][x]` -- its `_fetch` transposes
  deliberately, see `terrain_backend.py:1456`: "indexes rows by i (z) and columns
  by j (x)". So z is the major axis and x the minor. A cell outside the declared
  grid returns nil and is NEVER clamped to an edge sample, because an edge sample
  is a different place on the map.``
  [result x z]
  (when (and (present? result) (finite? x) (finite? z))
    (def xi (math/floor x))
    (def zi (math/floor z))
    (def w (get result :width))
    (def h (get result :height))
    (when (and (<= 0 xi) (< xi w) (<= 0 zi) (< zi h))
      (+ xi (* zi w)))))

(defn sample
  ``The five channel values at grid cell (x, z), from a validated result.

  `{:status :sampled :x :z :index :values <frozen struct>}` when inside the grid,
  or `{:status :unavailable :reason ...}` when not. It never substitutes a
  neighbouring cell's value and never returns a zero for a gap.``
  [result x z]
  (unless (and (or (table? result) (struct? result)) (present? result))
    (fail "sample needs a validated, present climate result"))
  (def index (sample-index result x z))
  (if (nil? index)
    @{:status :unavailable
      :reason (if (and (finite? x) (finite? z)) :outside-grid :invalid-coordinate)}
    (do
      (def values (get result :values))
      (def out @{})
      (each channel channels
        (put out channel (get (get values channel) index)))
      @{:status :sampled
        :x (math/floor x) :z (math/floor z) :index index
        :values (freeze out)})))

(defn sampled? [r] (= :sampled (get r :status)))
