# Native world providers. The learned model is NOT installed in the game.
# This registry describes only controls whose values actually change generation.
(import ./world :as world)
(import ./worldgen :as worldgen)
(import ./scenic-worldgen :as scenic)
(import ./generation-job :as generation-job)

(def version 1)
(def defaults {:height-scale 1.0 :height-offset 0 :sea-level 28
               :forest-density 0})
(def controls [
  {:id :height-scale :label "Relief scale" :category :terrain
   :type :number :min 0.5 :max 2.0 :default 1.0}
  {:id :height-offset :label "Elevation offset" :category :terrain
   :type :integer :min -16 :max 64 :default 0}
  {:id :sea-level :label "Sea level" :category :terrain
   :type :integer :min 0 :max 128 :default 28}
  {:id :forest-density :label "Authored forest density" :category :content
   :type :integer :min 0 :max 100 :default 0}])
#
# --- Versioned procedural settings --------------------------------------
#
# `version` above is the DEFAULT and the legacy contract: every saved procedural
# world carries settings-version 1 and exactly the four controls in `controls`.
# Version 2 is the same generator with one fifth authored control -- authored
# clearings -- and it exists as a SEPARATE version rather than a widening of v1
# for one reason: identity is an exact string over a per-version key set, so
# widening v1 would make every already-saved world refuse to load.
#
# The version is chosen by the caller and is NEVER inferred. A world records the
# version it was made with and keeps it for life; nothing upgrades on load and
# nothing upgrades on save. That is what makes "old saves are untouched"
# checkable rather than merely intended.
#
# The profile stays :v2h256 for both versions. A profile names the terrain
# pipeline (tall world, engine height 256), not the decoration on top of it, and
# a second profile here would claim a terrain contract that has not changed.
(def settings-versions [1 2])
(def defaults-v2 {:height-scale 1.0 :height-offset 0 :sea-level 28
                  :forest-density 0 :clearing-density 0})
(def controls-v2 (array/concat @[] controls
                    @[{:id :clearing-density
                       :label "Authored clearing frequency" :category :content
                       :type :integer :min 0 :max 100 :default 0}]))
(defn- version-controls [v]
  ``The declared controls for settings version `v`, or nil for an unknown one.

  Unknown versions return nil rather than falling back to the newest: a fallback
  would silently reinterpret a saved world under rules it was not made under.``
  (cond (= v 1) controls (= v 2) controls-v2 false nil))
(defn- version-defaults [v]
  (cond (= v 1) defaults (= v 2) defaults-v2 false nil))
(defn settings-version? [v]
  "Is `v` a settings version this module can generate and validate?"
  (truthy? (some |(= $ v) settings-versions)))
#
# --- Terrain Diffusion, temporary Python provider ----------------------
#
# These are the settings `tools/terrain_new_game.py` ACTUALLY accepts. There is no
# `steps` control and none is offered: the upstream pipeline runs a fixed number
# of denoise steps, and a knob that changed nothing would be the exact dishonesty
# this registry exists to avoid. `size` moves in whole tiles because the artifact
# is tiled, which the CLI enforces too.
(def python-tile 16)
(def python-controls [
  {:id :size :label "Map size (px)" :category :terrain
   :type :integer :min 16 :max 512 :default 128 :step python-tile}
  {:id :sea-level :label "Sea level" :category :terrain
   :type :integer :min 0 :max 128 :default 28}
  {:id :profile :label "Generation profile" :category :terrain
   :type :choice :choices ["alpine"] :default "alpine"}])
(def python-defaults {:size 128 :sea-level 28 :profile "alpine"})

# Seed 0. The world seed record allows 0, and the provider REFUSES it because
# upstream treats a falsy seed as "draw a random world" -- the recorded seed would
# then not describe the terrain. Mapping 0 to another model seed silently would be
# worse: two worlds whose records differ would generate identical terrain, and
# nobody reading the manifest could tell. So the mapping is named, versioned and
# inspectable instead of hidden in a cast.
(def seed-mapping-version 1)
(def python-model-seed-ceiling 2147483647)
(def python-seed-zero-model-seed 2147483647)

(defn python-model-seed
  ``The model seed a world seed generates with, and whether it was remapped.

  Returns `[model-seed version]` where version is nil when the world seed was used
  unchanged. World seed 0 maps to a fixed non-zero model seed: deterministic, the
  same on every machine and every run, and recorded in the slot's provenance so a
  later reader can rediscover the rule rather than guess it.``
  [world-seed]
  (assert (and (number? world-seed) (= world-seed (math/floor world-seed)))
          "world seed must be an integer")
  (assert (<= 0 world-seed python-model-seed-ceiling)
          "world seed is outside the provider's range")
  (if (zero? world-seed)
    [python-seed-zero-model-seed seed-mapping-version]
    [world-seed nil]))

(def registry [
  {:id :procedural :label "Native procedural" :available true
   :version version :controls controls
   # A world UI must be able to offer a second settings contract without
   # hardcoding a control it cannot validate against. These two keys are
   # ADDITIVE: `:version`/`:controls` keep their v1 meaning, so a consumer that
   # only knows about v1 (the shipped menu) sees exactly what it saw before.
   :settings-versions settings-versions
   :controls-v2 controls-v2}
  {:id :terrain-diffusion-python
   :label "Terrain Diffusion - Python (temporary)"
   :available false :version 1 :controls python-controls
   :defaults python-defaults
   :reason "Offline Python package readiness has not been verified."
   :note "Runs tools/terrain_new_game.py once per world. Slower than native and
          not a shipped runtime."}
  {:id :terrain-diffusion-native :label "Terrain Diffusion (native)"
   :available false :version 0 :controls []
   :reason "The native terrain pipeline is not verified end to end yet."}])

# Runtime readiness is a per-session observation, never persisted in a world.
# The CLI --check performs offline pin verification only; it never loads models.
(def python-readiness-timeout-seconds 30)
(defn- readiness-status [probe]
  {:state (get probe :state) :reason (get probe :reason)
   :detail (get probe :detail)
   :pid (when (get probe :job) (get (get probe :job) :pid))})
(defn python-readiness-new [opts]
  ``Construct an unavailable offline probe. The caller owns the optional
  generation-job :slot, polls every frame, and closes it at shutdown.``
  (assert (or (table? opts) (struct? opts)) "readiness options must be a table")
  (def python (get opts :python))
  (def script (get opts :script))
  (def timeout (get opts :timeout-seconds python-readiness-timeout-seconds))
  (def check-out (get opts :check-out "/tmp/trinecraft-readiness-unused"))
  (assert (and (string? python) (<= 1 (length python) 4096)
               (string? script) (<= 1 (length script) 4096)
               (string? check-out) (<= 1 (length check-out) 4096))
          "readiness requires bounded python, script, and check-out paths")
  (assert (and (number? timeout) (<= 1 timeout 120))
          "readiness timeout must be 1..120 seconds")
  (def job-opts (get opts :job-opts {}))
  (assert (or (table? job-opts) (struct? job-opts))
          "readiness job options must be a table")
  @{:python python :script script :check-out check-out :timeout-seconds timeout
    :job-opts job-opts :slot (get opts :slot @{:job nil})
    :clock (get opts :clock (fn [] (os/clock :monotonic)))
    :job nil :deadline nil :state :unavailable :detail nil
    :reason "Offline Python package readiness has not been verified."})
(defn python-readiness-start! [probe]
  ``Start a single direct --check child via generation-job; no model inference.
  Missing script is unavailable without spawning; no success is cached globally.``
  (when (get probe :job)
    (error "readiness probe already owns a job"))
  (put probe :state :unavailable)
  (put probe :detail nil)
  (put probe :reason "Offline Python package readiness has not been verified.")
  (if (not= :file (os/lstat (get probe :script) :mode))
    (put probe :reason "Temporary Python provider script is missing or linked.")
    (let [options (merge (get probe :job-opts)
                         {:slot (get probe :slot) :validate (fn [job] true)})
          argv @[(get probe :python) (get probe :script) "--out"
                  (get probe :check-out) "--check"]
          job (generation-job/start "offline Python provider check" argv options)]
      (put probe :job job)
      (put probe :deadline (+ ((get probe :clock))
                              (get probe :timeout-seconds)))
      (if (= :running (get job :phase))
        (do (put probe :state :checking)
            (put probe :reason "Checking pinned Python provider package offline."))
        (do (put probe :state :unavailable)
            (put probe :detail (get job :error))
            (put probe :reason "Python interpreter could not be started. Check --terrain-python.")
            # An unreaped child remains owned by the shared slot after failure.
            (when (nil? (get (get probe :slot) :job))
              (put probe :job nil))))))
  (readiness-status probe))
(defn python-readiness-poll! [probe]
  ``Nonblocking frame poll. A timeout cancels the owned process and remains
  unavailable through the supervisor's TERM/KILL/reap lifecycle.``
  (when-let [job (get probe :job)]
    (when (and (= :running (get job :phase))
               (>= ((get probe :clock)) (get probe :deadline)))
      (put probe :state :unavailable)
      (put probe :reason "Offline Python provider check timed out.")
      (generation-job/cancel job))
    (def result (generation-job/poll job))
    (case (get result :phase)
      :succeeded (do (when (and (= :checking (get probe :state))
                                (nil? (get (get probe :slot) :job)))
                       (put probe :state :verified)
                       (put probe :reason nil))
                     (when (nil? (get (get probe :slot) :job))
                       (put probe :job nil)))
      :failed (do (put probe :detail (get result :error))
                  (when (= :checking (get probe :state))
                    (put probe :reason
                         (if (and (number? (get result :exit-code))
                                  (<= 0 (get result :exit-code) 255))
                           (string "Offline Python package check failed (exit "
                                   (get result :exit-code) "); see log.")
                           "Offline Python package check failed; see log.")))
                  (put probe :state :unavailable)
                  (when (nil? (get (get probe :slot) :job))
                    (put probe :job nil)))
      :cancelled (do (put probe :state :unavailable)
                     (when (nil? (get (get probe :slot) :job))
                       (put probe :job nil)))
      nil))
  (readiness-status probe))
(defn python-readiness-cancel! [probe]
  "Cancel an outstanding check; never claim readiness from its late exit."
  (when-let [job (get probe :job)] (generation-job/cancel job))
  (put probe :state :unavailable)
  (put probe :reason "Offline Python provider check cancelled.")
  (readiness-status probe))
(defn python-readiness-close! [probe]
  "Shutdown-only collection; do not call on a GUI frame."
  (when-let [job (get probe :job)]
    (def result (generation-job/close job))
    (if (nil? (get (get probe :slot) :job))
      (do (put probe :job nil)
          (put probe :reason "Offline Python provider check closed."))
      (do (put probe :detail (get result :error))
          (put probe :reason "Offline Python provider cleanup pending; owned child not reaped."))))
  (put probe :state :unavailable)
  (when (nil? (get probe :reason))
    (put probe :reason "Offline Python provider check closed."))
  (readiness-status probe))
(defn providers-for-runtime [probe]
  ``Fresh descriptors for the menu; only a verified probe enables generation.
  Static provider schemas remain available to saved-world validation.``
  (map (fn [descriptor]
         (if (= :terrain-diffusion-python (get descriptor :id))
           (merge descriptor {:available (= :verified (get probe :state))
                              :readiness (if probe (get probe :state) :unavailable)
                              :reason (if (= :verified (get probe :state)) nil
                                        (if probe (get probe :reason)
                                          "Offline Python package readiness has not been verified."))})
           descriptor)) registry))
(defn providers [] (providers-for-runtime nil))
(defn provider-info [id]
  (first (filter |(= (get $ :id) id) registry)))

(defn controls-for
  ``The controls declared for a provider at a settings version.

  Version 1 is the default, so a caller that does not know versions yet gets the
  list it has always got. An unknown provider or version raises rather than
  returning nil: a UI that silently rendered no controls would look like a
  provider with nothing to configure.

  The version is asked for EXPLICITLY here. validate-settings will infer one for a
  runtime caller that omits it, but a UI asking what it can render must say which
  contract it is rendering, or it would draw a v2 control set under a v1
  manifest.``
  [provider-id &opt settings-version]
  (def provider (provider-info provider-id))
  (assert provider (string "unknown world provider " provider-id))
  (def v (or settings-version version))
  (def declared (if (= :procedural provider-id)
                  (version-controls v)
                  (if (= v 1) (provider :controls) nil)))
  (assert declared (string "unsupported settings version " v
                           " for provider " provider-id))
  declared)

(defn- control-value-ok? [control value]
  (case (control :type)
    :choice (and (string? value)
                 (truthy? (some |(= $ value) (control :choices))))
    :integer (and (number? value) (= value (math/floor value))
                  (<= (control :min) value (control :max))
                  (or (not (has-key? control :step))
                      (zero? (% (- value (control :min)) (control :step)))))
    :number (and (number? value) (<= (control :min) value (control :max)))
    false))

(defn provider-defaults [provider-id &opt settings-version]
  "Every declared control's default for a provider and version, as a plain table."
  (def provider (provider-info provider-id))
  (def v (or settings-version version))
  (def declared (if (= :procedural provider-id) (version-controls v) (when provider (provider :controls))))
  (def out @{})
  (when declared
    (each control declared
      (when (has-key? control :default) (put out (control :id) (control :default)))))
  out)

(defn settings-version-for [provider-id settings]
  ``The settings version a RUNTIME request is validated under when the caller
  does not name one.

  Version 1 unless the provider can generate more than one AND the table carries
  a key only a later version declares -- currently `:clearing-density`, which is
  version 2's sole addition. So a settings table that says nothing about clearings
  is read as v1, and one that does is read as v2, without any caller having to
  learn versioning to keep working.

  This is explicitly NOT how a saved record is read. The catalogue validates a
  manifest under the version that manifest declares and refuses a mismatch, so a
  stored file never decides the rules it is judged by. Inference exists only to
  keep an in-memory caller working, and it is table-driven so a future version's
  distinguishing key is added in exactly one place.``
  [provider-id settings]
  (def provider (provider-info provider-id))
  (assert provider (string "unknown world provider " provider-id))
  (if (and (or (nil? settings) (table? settings) (struct? settings))
           settings
           (has-key? settings :clearing-density)
           (= :procedural provider-id))
    2
    version))

(defn validate-settings [provider-id settings &opt settings-version]
  ``Return a canonical complete settings struct for THIS provider and VERSION.

  Validation reads the provider's OWN control list and nothing else. The previous
  version consulted the module-level procedural defaults for every provider, so a
  procedural knob handed to a learned provider would have been accepted -- settings
  leaking across providers, which is how a world gets generated with values its
  screen never showed.

  The VERSION selects the control list. `:procedural` has two -- version 1, the
  four shipped controls every saved world carries, and version 2, which adds
  `:clearing-density`. The lists are disjoint contracts, not a superset: a v2
  setting handed to v1 is refused as an unknown control, and a v1 setting handed
  to v2 is filled in from the v2 defaults rather than being silently widened in
  place. Omitting the version means version 1, so every existing caller keeps
  exactly the behaviour it had.

  INFERENCE IS FOR RUNTIME ONLY, and only when the caller declines to say. If a
  caller passes no version and this provider has more than one, a table carrying
  `:clearing-density` is validated as version 2 rather than being rejected as an
  unknown v1 control. That keeps a UI that has not learned versions yet working
  with a v2 settings table. A RECORD must never rely on it: the catalogue reads a
  saved manifest under the version that manifest declares and refuses a mismatch,
  because inferring there would let a stored file decide which rules it is judged
  by. Use `settings-version-for` to see what would be chosen.

  A provider whose value must also satisfy a `:step` (a tiled map size) has that
  enforced here, so the UI cannot offer a size the artifact reader would reject.

  NO AVAILABILITY GATE. This is a SCHEMA question -- is this value inside what the
  provider declares -- and must answer the same whether or not the provider can run
  right now. Gating it on availability would make SAVED worlds unloadable whenever
  a provider is unavailable, so a player who generated a world and then lost the
  Python environment could no longer open their own map. Whether the provider can
  GENERATE is `available?`/`assert-generatable`, checked where generation starts.``
  (def provider (provider-info provider-id))
  (assert provider "unknown world provider")
  (assert (or (nil? settings) (table? settings) (struct? settings))
          "world settings must be a table")
  (def v (if settings-version
           settings-version
           (settings-version-for provider-id settings)))
  (assert (settings-version? v)
          (string "unsupported settings version " v " for provider " provider-id))
  # The version's controls are the ONLY ones declared. A learned provider has one
  # list for every version it accepts, which is why this looks it up per version
  # rather than assuming the module-level procedural list.
  (def declared-controls
    (if (= :procedural provider-id) (version-controls v) (provider :controls)))
  (def declared @{})
  (each control declared-controls (put declared (control :id) control))
  (when settings
    (each k (keys settings)
      (assert (has-key? declared k)
              (string "provider " provider-id " version " v
                      " has no setting " k))))
  (def full @{})
  (each control declared-controls
    (def id (control :id))
    (def value (if (and settings (has-key? settings id))
                 (get settings id) (get control :default)))
    (assert (control-value-ok? control value)
            (string "invalid " provider-id " setting " id))
    (put full id value))
  (freeze full))

(defn available? [provider-id &opt probe]
  "Can this provider GENERATE now? Python requires an explicit verified probe."
  (def descriptor (first (filter |(= provider-id (get $ :id))
                                 (providers-for-runtime probe))))
  (truthy? (and descriptor (get descriptor :available))))

(defn assert-generatable
  ``Refuse generation for an unavailable provider.

  Deliberately separate from `validate-settings`: loading and saving a world ask
  the schema question, while STARTING a generation asks this one. Conflating them
  is how a saved map becomes unopenable the moment its provider is unavailable.``
  [provider-id &opt probe]
  (assert (provider-info provider-id) "unknown world provider")
  (assert (available? provider-id probe) "world provider unavailable")
  provider-id)

(defn settings-descriptor [provider-id settings &opt settings-version]
  ``Canonical identity input only. Persistence must pin this descriptor before
  exposing configurable New Game worlds; this does not hash or save anything.

  The descriptor reports the VERSION it was resolved at, and only version 2
  carries `:clearing-density`. That is what makes the catalogue's identity string
  able to tell a v2 world whose clearings are at 0 apart from a v1 world: both
  generate identical terrain, but they were made under different settings
  contracts, and a v1 world must not be reinterpreted as a v2 one.``
  (def v (if settings-version settings-version
           (settings-version-for provider-id settings)))
  (def s (validate-settings provider-id settings v))
  (def base {:provider provider-id :version v :engine-height world/chunk-y
             :height-scale (s :height-scale) :height-offset (s :height-offset)
             :sea-level (s :sea-level) :forest-density (s :forest-density)})
  (if (= 2 v)
    (merge base {:clearing-density (s :clearing-density)})
    base))

(defn- height-function [seed settings]
  (let [scale (settings :height-scale) offset (settings :height-offset)]
    (fn [wx wz]
      (let [base (worldgen/height-at seed wx wz)
            h (math/floor (+ 28 (* scale (- base 28)) offset))]
        (max 4 (min worldgen/scenic-max-height h))))))

(defn generate-into! [provider-id blocks cx cz seed settings &opt settings-version]
  ``Generate native voxel terrain; default settings preserve shipped noise bytes.
  Forests and clearings are explicitly authored decoration, never learned climate.

  A v2 world whose every other control is at its default and whose
  `:clearing-density` is 0 generates through the UNCHANGED `worldgen/generate-into`
  fast path, so v2-at-0 is byte-identical terrain to v1. That is deliberate: the
  version distinguishes which settings contract a world was made under, not the
  bytes it produces, and a save must not change appearance merely by being
  re-made at a newer version. Clearing density 0 is also inert inside
  `scenic/decorate!`, so the slow path at 0 is byte-exact too.``
  (def v (if settings-version settings-version
           (settings-version-for provider-id settings)))
  (def s (validate-settings provider-id settings v))
  (assert (and (buffer? blocks) (= (length blocks) world/chunk-volume))
          "blocks must be a full world chunk buffer")
  (assert (and (number? seed) (= seed (math/floor seed)))
          "world seed must be an integer")
  (assert (and (number? cx) (= cx (math/floor cx))
               (number? cz) (= cz (math/floor cz)))
          "chunk coordinates must be integers")
  # A v2 world at v1-equivalent defaults takes the identical fast path. Comparing
  # against the version's OWN defaults is what keeps this honest: a v2 world with
  # clearings set is not equal to `defaults-v2` and falls through to the decorated
  # path.
  (if (= s (if (= 2 v) defaults-v2 defaults))
    (worldgen/generate-into blocks cx cz seed)
    (let [height-at (height-function seed s)
          tile (buffer/new-filled 256 0)]
      (for z 0 16
        (for x 0 16
          (put tile (+ x (* z 16))
               (height-at (+ (* cx 16) x) (+ (* cz 16) z)))))
      (worldgen/generate-from-heights-scenic
        blocks cx cz tile {:sea-level (s :sea-level)})
      (when (> (s :forest-density) 0)
        (scenic/decorate! blocks cx cz height-at
          {:seed seed :sea-level (s :sea-level)
           :density (s :forest-density) :tree-line 80
           :tree-slope 3
           # Only a v2 settings table can carry this; v1 leaves it absent, which
           # the module reads as its own authored default of 0.
           :clearing-density (get s :clearing-density 0)}))
      blocks)))

#
# --- Offline readiness -------------------------------------------------
#
# A readiness check runs `--check`, which validates LOCAL files and digests and
# loads no model. It is still not free: it hashes multi-gigabyte weights, so a
# few seconds is normal. Two consequences are designed in rather than discovered:
#
#   * it never runs at import or at startup -- only when a player selects this
#     provider, so the menu's first frame cannot stall on a digest;
#   * readiness is a per-session probe, never a global cached claim; an on-disk
#     package can change, so a new check must validate pins again.
# The generation-job supervisor owns spawn, cancellation, timeout cleanup and reap.
