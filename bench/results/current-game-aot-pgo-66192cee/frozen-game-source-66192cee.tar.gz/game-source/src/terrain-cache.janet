# Trinecraft — terrain height-tile cache consumer.
#
# The GAME side of the cache. It reads precomputed 16x16 height tiles and asks a
# separate backend process for the tiles it lacks. No inference, no subprocess:
# the only channel is files.
#
# ---------------------------------------------------------------------------
# Two products, one wire layout
# ---------------------------------------------------------------------------
#
#   TDH2  LEGACY  magic "TDH2", format 2, band 4..60    -- streaming worlds
#   TDS3  SCENIC  magic "TDS3", format 3, band 4..252   -- one fixed map
#
# Both are 308-byte tiles with an identical header, so only the magic and the
# band differ:
#
#   offset  size  type     field
#   0       4     char[4]  magic b"TDH2" or b"TDS3"
#   4       4     int32    chunk x (little-endian, signed)
#   8       4     int32    chunk z (little-endian, signed)
#   12      4     uint32   payload length, always 256
#   16      4     uint32   CRC-32 of the payload
#   20      32    byte[32] SHA-256 of the payload
#   52      256   uint8    heights, x-fastest: index = x + 16*z
#
# THE BAND IS DERIVED FROM THE VALIDATED MAGIC, NEVER FROM A MANIFEST NUMBER.
# A manifest can narrow what it accepts; it can never raise the ceiling the
# decoder enforces, because the decoder picks the band before it reads any
# manifest field. The 253..255 range stays reserved so a future band can widen
# without ambiguity, and 252 leaves headroom under the engine's 256-block column.
#
# Checked here: exact length 308 (covering a short header, truncation AND
# trailing bytes), magic, payload length, CRC-32, the header's (cx,cz) against
# the requested coordinates, and every height inside the profile's band.
#
# The SHA-256 is NOT checked: this build has none, and a hand-rolled one would be
# a silent-mistake machine that also duplicates the identity the Python producer
# owns. The cached CRC-32 catches accidental corruption, the only realistic
# failure of a file published by atomic rename; Python verifies both digests.
# This is not authentication and makes no security claim.
#
# Byte order is assembled from individual bytes, never through ffi: a cache file
# is a cross-machine artifact, and ffi reads host byte order.
#
# ---------------------------------------------------------------------------
# Layout under the identity directory
# ---------------------------------------------------------------------------
#
#   <dir>/manifest.janet          inert identity twin (read here)
#   <dir>/provenance.json    scenic map record, CRC-bound by the twin
#   <dir>/manifest.json           authoritative record for Python (not read)
#   <dir>/tiles/<cx>_<cz>.tdh     complete tiles, writer publishes atomically
#   <dir>/requests/<cx>_<cz>.req  request marker written by this module
#   <dir>/errors/<cx>_<cz>.txt    backend failure, terminal
#
# `<cx>_<cz>` is signed decimal, e.g. `tiles/-3_12.tdh`.
#
# A request's FILE NAME is the whole message; its body is an echo that is never
# parsed. It appears by atomic rename, so a backend never sees a partial marker.
# One coordinate maps to one marker, so `request` is idempotent and a slow
# backend cannot grow the queue. Failure is terminal: once an errors file exists
# the coordinate is never requested again, and nothing here retries on a timer.
#
# The manifest twin is PARSED, never evaluated, so a symbol or form is refused
# rather than executed. The key set is exact per profile and anything else is a
# refusal. The identity is an opaque 64-hex string from Python, carried here
# unexamined.
#
#   legacy (6 keys, unchanged):
#     {:format 2 :magic "TDH2" :identity "<64 hex>" :seed 4
#      :payload-bytes 256 :tile-bytes 308}
#
#   scenic (12 keys):
#     {:format 3 :magic "TDS3" :identity "<64 hex>" :seed 4
#      :payload-bytes 256 :tile-bytes 308
#      :height-min 4 :height-max 252
#      :bounds [cx0 cz0 cx1 cz1]   ; inclusive chunk bounds, signed
#      :origin [ox oz]             ; fixed global origin, signed, opaque units
#      :json-crc32 <uint32>        ; CRC-32 over provenance.json's bytes
#      :json-bytes <int>           ; that file's exact size
#     }
#
# Janet has no JSON parser and no SHA-256, so CRC-32 over the JSON's exact bytes
# is the ONLY link this side can really verify. It catches a truncated or
# half-published record; it is integrity, not authentication. Both numbers must
# agree or the scenic cache is refused.
#
# A scenic map is finite: coordinates outside `:bounds` are never requested and
# a tile found there is refused rather than served, so a stale artifact from
# another mapping cannot leak into this world. Nothing here substitutes noise
# for missing terrain, and nothing starts an offline worker.
#
# ---------------------------------------------------------------------------
# Optional climate: an EXPLICIT attachment, never a file this module finds
# ---------------------------------------------------------------------------
#
# Climate is a second product with its own format and its own owner. The wire
# belongs to `tools/scenic_terrain.py` `export_raw(..., climate=)` and the bound
# reader over it is `src/climate-tile.janet`; NEITHER is redefined here.
#
# Opening a cache stays exactly what it was: it reads `manifest.janet` (and, for
# scenic, `provenance.json`) and nothing else. There is no `climate.npz`, no
# `climate.json`, no glob and no sidecar discovery -- a cache with climate data
# lying beside it opens as a cache without climate, because FINDING a file is not
# the same as being TOLD what it is, and the container is another language's
# format. A caller that has decoded climate data and owns it says so once:
#
#   (attach-climate cache values shape meta)   ; values nil == producer wrote none
#
# That validates through `climate-tile/read` -- the single presence, shape,
# length and NaN authority -- then requires the grid to COVER THIS MAP EXACTLY.
# The producer anchors its elevation grid at `chunk_min` with shape
# `(chunks_z*16, chunks_x*16)`, so any other shape describes a different map and
# is refused rather than stretched onto this one. Attachment stores the validated
# result on the cache and writes nothing to disk.
#
# Queries then answer in the reader's own vocabulary:
#
#   (cache-climate cache)                 ; validated result, or :not-attached
#   (climate-shape cache)                 ; expected (H W 5), or nil if unbounded
#   (climate-cell cache cx cz &opt ox oz) ; chunk -> [gx gz] cell, or nil
#   (climate-at cache cx cz &opt ox oz)   ; sampled values, or :unavailable
#
# Absence is never an error and never a zeroed climate: an unattached cache
# answers `:not-attached`, a map whose producer wrote no climate answers
# `:absent`, and a chunk outside `:bounds` answers `:outside-map`. Height access
# is untouched by all of it -- the tile format, the manifest key sets and
# `read-height-tile` do not know climate exists.

(import ./terrain-integrity :as integrity)
(import ./climate-tile :as climate)

(def tile-bytes 308)
(def header-bytes 52)
(def payload-bytes 256)
#: One tile is 16x16 heights, so the vertical/horizontal extent of a map in
#: HEIGHTS is its chunk extent times this. The climate grid is anchored at the
#: map's `chunk_min` on the same 16-height lattice.
(def tile-size 16)

#: The largest climate grid this cache will ever hold: a 512x512 map, five
#: channels, float32 -- 5 MiB. A scenic map cannot exceed 512 chunks a side, so
#: this is the real ceiling rather than an arbitrary one, and it is checked
#: BEFORE any work happens on an attachment. It exists so a caller cannot hand
#: over a grid that is merely self-consistent and quietly park megabytes in the
#: cache; it is a product cap, not the reader's per-buffer bound.
(def climate-max-cells (* 512 512))
(def climate-max-bytes (* climate-max-cells climate/channel-count 4))
# The legacy band, kept exported because callers already use these names. A
# scenic cache never reads them: its band comes from its own profile.
(def height-min 4)
(def height-max 60)
(def scenic-height-max 252)
(def manifest-max-bytes 4096)            # ~1000x the largest sane twin
(def json-max-bytes 65536)               # hard cap on provenance.json
(def max-pending 128)
(def default-pending 64)                 # pending requests kept by default
(def default-poll 4)

#: The wire magic IS the format version. Everything a decoder needs to refuse a
#: tile -- band, expected format number, whether the product is bounded -- hangs
#: off this table, so no manifest field can widen what a tile may contain.
(def profiles
  {:legacy @{:magic "TDH2" :format 2 :height-min 4 :height-max 60 :bounded false}
   :scenic @{:magic "TDS3" :format 3 :height-min 4 :height-max 252 :bounded true}})

(def legacy-manifest-keys [:format :magic :identity :seed :payload-bytes :tile-bytes])

(def scenic-manifest-keys
  [:format :magic :identity :seed :payload-bytes :tile-bytes
   :height-min :height-max :bounds :origin :json-crc32 :json-bytes])

(defn- fail [reason] (error (string "terrain cache: " reason)))
(defn- profile-for [magic] (first (filter |(= magic ((profiles $) :magic)) [:legacy :scenic])))

(defn- le-u32
  "Unsigned 32-bit little-endian integer at `offset`, byte by byte."
  [b o]
  (+ (get b o) (* 256 (get b (+ o 1))) (* 65536 (get b (+ o 2))) (* 16777216 (get b (+ o 3)))))

(defn- le-i32
  "Signed 32-bit little-endian integer at `offset`, two's complement."
  [b o]
  (def u (le-u32 b o))
  (if (>= u 2147483648) (- u 4294967296) u))

(defn valid-coord?
  "Is this a signed 32-bit integer chunk coordinate?"
  [v]
  (and (= (type v) :number) (= v (math/floor v)) (<= -2147483648 v 2147483647)))

(defn- integer? [v] (and (number? v) (= v (math/floor v))))

(defn- magic-of
  "The 4-byte magic in front of `bytes`, or nil when there cannot be one."
  [bytes]
  (when (and (or (string? bytes) (buffer? bytes)) (>= (length bytes) 4))
    (string/slice bytes 0 4)))

(defn tile-profile
  ``\`:legacy\`, \`:scenic\` or nil, from the magic alone.

  This is the one place a band is chosen, and it reads four bytes of the file --
  not the manifest, not a caller argument.``
  [bytes]
  (profile-for (magic-of bytes)))

(defn- decode-known
  "Decode `bytes` under `profile`, whose band is already fixed."
  [profile bytes cx cz]
  (def band (profiles profile))
  (unless (or (string? bytes) (buffer? bytes)) (fail "a tile must be a string or buffer"))
  (unless (and (valid-coord? cx) (valid-coord? cz))
    (fail "coordinates must be signed 32-bit integers"))
  (def n (length bytes))
  (when (< n header-bytes) (fail (string "truncated header: " n " bytes")))
  (when (not= n tile-bytes) (fail (string "length " n ", expected exactly " tile-bytes)))
  (def magic (string/slice bytes 0 4))
  (unless (= magic (band :magic))
    (fail (string "bad magic \"" magic "\", expected \"" (band :magic) "\" for the "
                  (string profile) " profile")))
  (def file-cx (le-i32 bytes 4))
  (def file-cz (le-i32 bytes 8))
  (unless (and (= file-cx cx) (= file-cz cz))
    (fail (string "coordinates (" file-cx "," file-cz ") do not match requested ("
                  cx "," cz ")")))
  (def declared (le-u32 bytes 12))
  (unless (= payload-bytes declared)
    (fail (string "payload length " declared ", expected " payload-bytes)))
  (def payload (string/slice bytes header-bytes tile-bytes))
  (def actual (integrity/crc32 payload))
  (def stored (le-u32 bytes 16))
  (unless (= stored actual)
    (fail (string "CRC-32 mismatch: header " stored ", payload " actual)))
  # Bytes 20..51 hold the writer's SHA-256 -- skipped deliberately; see header.
  (def heights (buffer/new-filled payload-bytes 0))
  (for i 0 payload-bytes
    (def h (get payload i))
    (unless (<= (band :height-min) h (band :height-max))
      (fail (string "height[" i "]=" h " outside " (band :height-min) ".."
                    (band :height-max) " for the " (string profile) " profile")))
    (put heights i h))
  heights)

(defn decode-tile
  ``Decode one 308-byte tile whose header must name `(cx, cz)`; returns the
  256-byte height buffer, x-fastest. Throws on malformed input.

  The band comes from the tile's own magic (TDH2 -> 4..60, TDS3 -> 4..252), so
  this accepts either product. A cache that must only ever see its own profile
  should call `decode-tile-for`. The requested coordinates are part of the
  contract -- a tile for another chunk is rejected rather than relocated.``
  [bytes cx cz]
  (def profile (tile-profile bytes))
  (unless profile
    (fail (string "bad magic \"" (or (magic-of bytes) "") "\"; expected TDH2 or TDS3")))
  (decode-known profile bytes cx cz))

(defn decode-tile-for
  ``Decode `bytes` as `profile` (":legacy" or ":scenic"), or refuse.

  A cache calls this so a scenic world can never be fed a legacy tile, or the
  other way round, even when both files are individually well formed.``
  [profile bytes cx cz]
  (unless (profiles profile) (fail (string "unknown profile " (string profile))))
  (decode-known profile bytes cx cz))

#
# --- Paths --------------------------------------------------------------
#

(defn tiles-dir [dir] (string dir "/tiles"))
(defn requests-dir [dir] (string dir "/requests"))
(defn errors-dir [dir] (string dir "/errors"))
(defn coord-name
  "The signed coordinate stem shared by every file in the cache."
  [cx cz] (string cx "_" cz))

(defn tile-path [dir cx cz] (string (tiles-dir dir) "/" (coord-name cx cz) ".tdh"))
(defn request-path [dir cx cz] (string (requests-dir dir) "/" (coord-name cx cz) ".req"))
(defn error-path [dir cx cz] (string (errors-dir dir) "/" (coord-name cx cz) ".txt"))
(defn scenic-json-path [dir] (string dir "/provenance.json"))

(defn- read-capped
  ``At most `cap` bytes of `path`, or nil when it cannot be opened.

  Never `:all`: the cache directory is written by another process, so a path can
  be a FIFO, a runaway log or a corrupt multi-megabyte tile, and reading it whole
  would allocate far more than any length check could then refuse. A counted
  `file/read` is synchronous and bounded in bytes, not in wall time.``
  [path cap]
  (def f (file/open path :rb))
  (when f (def d (try (file/read f cap) ([err] nil))) (file/close f) d))

#
# --- Manifest -----------------------------------------------------------
#

(defn plain-data?
  "True for values the manifest may hold; rejects symbols, buffers and forms."
  [v]
  (cond
    (or (nil? v) (boolean? v) (string? v) (keyword? v)) true
    (number? v) (and (not (nan? v)) (< -1e308 v) (< v 1e308))
    (or (tuple? v) (array? v)) (every? (map plain-data? v))
    (or (table? v) (struct? v))
    (every? (map (fn [[k x]] (and (keyword? k) (plain-data? x))) (pairs v)))
    true false))

(defn- hex64? [s]
  (and (string? s) (= 64 (length s))
       (every? (map (fn [i] (or (<= 48 (get s i) 57) (<= 97 (get s i) 102))) (range 64)))))

(defn- parse-one
  "Parse exactly one plain-data form from `text`; never evaluates it."
  [text]
  (def r (protect (parse-all text)))
  (unless (get r 0) (fail "manifest.janet is not Janet data"))
  (def forms (get r 1))
  (unless (= 1 (length forms)) (fail "manifest.janet must contain exactly one form"))
  (def v (get forms 0))
  (unless (plain-data? v) (fail "manifest.janet holds a non-data form; never evaluated"))
  v)

(defn- pair-of
  "Two signed 32-bit integers from a parsed `[a b]`, or an error."
  [v what]
  (unless (and (or (tuple? v) (array? v)) (= 2 (length v)))
    (fail (string "manifest.janet :" what " must be a two-element vector")))
  (def a (get v 0))
  (def b (get v 1))
  (unless (and (valid-coord? a) (valid-coord? b))
    (fail (string "manifest.janet :" what " must hold two signed 32-bit integers")))
  [a b])

(defn- bounds-of
  "Inclusive `[cx0 cz0 cx1 cz1]` from a parsed vector, ordered, or an error."
  [v]
  (unless (and (or (tuple? v) (array? v)) (= 4 (length v)))
    (fail "manifest.janet :bounds must be a four-element vector [cx0 cz0 cx1 cz1]"))
  (def b [(get v 0) (get v 1) (get v 2) (get v 3)])
  (each c b
    (unless (valid-coord? c)
      (fail "manifest.janet :bounds must hold signed 32-bit integers")))
  (unless (and (<= (get b 0) (get b 2)) (<= (get b 1) (get b 3)))
    (fail "manifest.janet :bounds must satisfy cx0<=cx1 and cz0<=cz1"))
  b)

(defn- check-json-binding
  ``Bind `provenance.json` to the twin by its exact size and CRC-32.

  Janet can parse neither JSON nor SHA-256, so this is the only real link
  available: it detects a truncated or half-published record. Integrity only.``
  [dir expected-bytes expected-crc]
  (def path (scenic-json-path dir))
  (def stat (os/stat path))
  (unless stat
    (fail (string "no provenance.json in " dir
                  "; the scenic manifest names a map record that is not there")))
  (when (> (get stat :size) json-max-bytes)
    (fail (string "provenance.json exceeds " json-max-bytes " bytes")))
  (def bytes (read-capped path (+ 1 json-max-bytes)))
  (unless bytes (fail "provenance.json is unreadable"))
  (when (> (length bytes) json-max-bytes)
    (fail (string "provenance.json is larger than " json-max-bytes " bytes")))
  (when (not= expected-bytes (length bytes))
    (fail (string "provenance.json is " (length bytes)
                  " bytes, the manifest binds " expected-bytes
                  " (truncated or replaced record)")))
  (def actual (integrity/crc32 (string bytes)))
  (unless (= expected-crc actual)
    (fail (string "provenance.json CRC-32 is " actual ", the manifest binds "
                  expected-crc " (the record does not match its twin)")))
  (length bytes))

(defn- load-legacy [rec]
  (each k legacy-manifest-keys
    (unless (some (fn [x] (= x k)) (keys rec))
      (fail (string "manifest.janet is missing " k))))
  (unless (= (length (keys rec)) (length legacy-manifest-keys))
    (fail "manifest.janet has an unexpected key for format 2"))
  (each [ok why]
    [[(= 2 (get rec :format)) "format must be 2"]
     [(hex64? (get rec :identity)) "identity must be 64 lowercase hex characters"]
     [(valid-coord? (get rec :seed)) "seed must be an integer"]
     [(= payload-bytes (get rec :payload-bytes)) (string "payload-bytes must be " payload-bytes)]
     [(= tile-bytes (get rec :tile-bytes)) (string "tile-bytes must be " tile-bytes)]]
    (unless ok (fail (string "manifest.janet :" why))))
  (freeze @{:profile :legacy :format 2 :magic "TDH2" :identity (get rec :identity)
            :seed (get rec :seed) :payload-bytes payload-bytes :tile-bytes tile-bytes
            :height-min 4 :height-max 60 :bounds nil :origin nil
            :json-crc32 nil :json-bytes nil}))

(defn- load-scenic [dir rec]
  (each k scenic-manifest-keys
    (unless (some (fn [x] (= x k)) (keys rec))
      (fail (string "manifest.janet is missing " k
                    " (a scenic manifest needs the full format-3 key set)"))))
  (unless (= (length (keys rec)) (length scenic-manifest-keys))
    (fail "manifest.janet has an unexpected key for format 3"))
  (def lo (get rec :height-min))
  (def hi (get rec :height-max))
  (unless (and (integer? lo) (integer? hi))
    (fail "manifest.janet :height-min and :height-max must be integers"))
  # The band may NARROW the profile's band, never widen it: the decoder's ceiling
  # comes from the magic, and a manifest cannot raise it by declaring a number.
  (unless (and (<= ((profiles :scenic) :height-min) lo) (<= lo hi)
               (<= hi ((profiles :scenic) :height-max)))
    (fail (string "manifest.janet band " lo ".." hi " is outside the TDS3 band 4..252")))
  (def bounds (bounds-of (get rec :bounds)))
  (def origin (pair-of (get rec :origin) "origin"))
  (def json-bytes (get rec :json-bytes))
  (unless (and (integer? json-bytes) (pos? json-bytes) (<= json-bytes json-max-bytes))
    (fail (string "manifest.janet :json-bytes must be 1.." json-max-bytes)))
  (def json-crc (get rec :json-crc32))
  (unless (and (integer? json-crc) (<= 0 json-crc 4294967295))
    (fail "manifest.janet :json-crc32 must be an unsigned 32-bit integer"))
  (each [ok why]
    [[(= 3 (get rec :format)) "format must be 3"]
     [(hex64? (get rec :identity)) "identity must be 64 lowercase hex characters"]
     [(valid-coord? (get rec :seed)) "seed must be an integer"]
     [(= payload-bytes (get rec :payload-bytes)) (string "payload-bytes must be " payload-bytes)]
     [(= tile-bytes (get rec :tile-bytes)) (string "tile-bytes must be " tile-bytes)]]
    (unless ok (fail (string "manifest.janet :" why))))
  (check-json-binding dir json-bytes json-crc)
  (freeze @{:profile :scenic :format 3 :magic "TDS3" :identity (get rec :identity)
            :seed (get rec :seed) :payload-bytes payload-bytes :tile-bytes tile-bytes
            :height-min lo :height-max hi :bounds bounds :origin origin
            :json-crc32 json-crc :json-bytes json-bytes}))

(defn load-manifest
  ``Read and validate `<dir>/manifest.janet`; returns a frozen record.

  Parsed as data, never evaluated. The profile comes from `:magic`, then that
  profile's exact key set is required -- so a format-2 twin cannot smuggle a
  scenic field and a scenic twin cannot omit one. A scenic twin is additionally
  bound to `provenance.json` by that file's size and CRC-32.

  Directory-name/identity agreement and the session's seed are the caller's
  external checks; this function cannot see either.``
  [dir]
  (unless (string? dir) (fail "identity directory must be a string"))
  (def path (string dir "/manifest.janet"))
  (def stat (os/stat path))
  (unless stat
    (fail (string "no manifest.janet in " dir
                  "; the identity directory cannot be identified")))
  (when (> (get stat :size) manifest-max-bytes)
    (fail (string "manifest.janet exceeds " manifest-max-bytes " bytes")))
  (def bytes (read-capped path manifest-max-bytes))
  (unless bytes (fail "manifest.janet is unreadable"))
  (def rec (parse-one (string bytes)))
  (unless (or (table? rec) (struct? rec))
    (fail "manifest.janet must be a single table literal"))
  (def profile (profile-for (get rec :magic)))
  (unless profile
    (fail (string "manifest.janet :magic must be \"TDH2\" or \"TDS3\", got "
                  (string (get rec :magic)))))
  (if (= profile :scenic) (load-scenic dir rec) (load-legacy rec)))

#
# --- Consumer -----------------------------------------------------------
#

(defn cache-new
  ``Open a consumer over one identity directory.

  Refuses a cache baked for a seed other than `expected-seed`: it would serve
  terrain from another generation. `capacity` bounds pending requests (default
  64, cap 128). Creates nothing -- opening must not write into a baked artifact.``
  [dir expected-seed &opt capacity]
  (default capacity default-pending)
  (unless (valid-coord? expected-seed) (fail "expected seed must be an integer"))
  (unless (and (valid-coord? capacity) (pos? capacity) (<= capacity max-pending))
    (fail (string "capacity must be 1.." max-pending)))
  (def manifest (load-manifest dir))
  (unless (= expected-seed (manifest :seed))
    (fail (string "cache was baked for seed " (manifest :seed)
                  ", this session uses seed " expected-seed)))
  @{:dir dir :identity (manifest :identity) :seed (manifest :seed)
    :profile (manifest :profile) :format (manifest :format) :magic (manifest :magic)
    :height-min (manifest :height-min) :height-max (manifest :height-max)
    :bounds (manifest :bounds) :origin (manifest :origin)
    :json-crc32 (manifest :json-crc32) :json-bytes (manifest :json-bytes)
    :capacity capacity :available @{} :pending @[] :failed @{}
    :cursor 0 :closed false
    # Climate is nil until a caller explicitly attaches one: opening a cache
    # discovers nothing, so absence here is the shipped, normal state. Its
    # projection rides alongside, because where the grid sits and how wide a
    # sample is cannot be recovered from the data alone.
    :climate nil :climate-projection nil})

(defn cache-profile
  "`:legacy` (TDH2, band 4..60, unbounded) or `:scenic` (TDS3, bounded)."
  [cache] (cache :profile))

(defn cache-bounds
  "`[cx0 cz0 cx1 cz1]` inclusive chunk bounds for a scenic cache, or nil."
  [cache] (cache :bounds))

(defn cache-meta
  "Frozen profile metadata: identity, seed, band, bounds, origin and JSON binding."
  [cache]
  (freeze @{:profile (cache :profile) :format (cache :format) :magic (cache :magic)
            :identity (cache :identity) :seed (cache :seed)
            :height-min (cache :height-min) :height-max (cache :height-max)
            :bounds (cache :bounds) :origin (cache :origin)
            :json-crc32 (cache :json-crc32) :json-bytes (cache :json-bytes)}))

(defn in-bounds?
  ``Is this coordinate inside the declared map?

  A legacy cache is unbounded and answers true for every valid coordinate; a
  scenic cache answers only inside its inclusive `[cx0 cz0 cx1 cz1]`.``
  [cache cx cz]
  (unless (and (valid-coord? cx) (valid-coord? cz))
    (fail "in-bounds? requires signed 32-bit integer coordinates"))
  (def b (cache :bounds))
  (if (nil? b)
    true
    (and (<= (get b 0) cx (get b 2)) (<= (get b 1) cz (get b 3)))))

(defn- key [cx cz] (coord-name cx cz))
(defn- closed? [cache] (cache :closed))

#
# --- Optional climate: explicit attachment ------------------------------
#
# Everything below is additive. Nothing above reads these fields, so a cache
# behaves identically with or without climate: the tile format, the manifest key
# sets, `read-height-tile`, `request` and `poll` are unaware climate exists.
#

#: The answer for a cache nobody attached climate to. Frozen, and carrying NO
#: `:values` key at all, so it cannot be mistaken for a zeroed climate.
(def not-attached
  (freeze @{:status :unavailable :reason :not-attached}))

(defn climate-extent
  ``The `[chunks_x chunks_z cells_x cells_z]` extent of this map, or nil when
  unbounded.

  A scenic map covers `cx0..cx1` and `cz0..cz1` chunks of 16 cells, so its world
  cell extent follows from `:bounds` alone -- it is a property of the map, never a
  number a caller chooses.``
  [cache]
  (def b (cache :bounds))
  (when b
    (def cx (+ 1 (- (get b 2) (get b 0))))
    (def cz (+ 1 (- (get b 3) (get b 1))))
    [cx cz (* cx tile-size) (* cz tile-size)]))

(defn climate-shape
  ``The `(height width 5)` grid an unattached projection would have to match.

  This is the map's own cell extent -- correct only when climate is 1:1 with the
  world, which is NOT guaranteed: a map may be upsampled from a coarser climate
  grid. Use it as the expected shape for the 1:1 case, and `attach-climate!` with
  an explicit scale otherwise. nil for an unbounded cache.``
  [cache]
  (def e (climate-extent cache))
  (when e [(get e 3) (get e 2) climate/channel-count]))

(defn cache-climate
  ``An IMMUTABLE view of the climate result attached here, or `:not-attached`.

  Never opens a file: climate data arrives only through `attach-climate!`, and
  the container format is another language's (see the module header).

  What comes back is read-only all the way down: a struct whose `:values` is a
  struct of tuples. Mutating it is a runtime error, not a silent corruption of
  the cache's own copy, so a caller cannot break later classifications by
  editing what it was handed. The stored result is frozen at attach time, so
  this is a structural guarantee rather than a copy made per query.``
  [cache]
  (or (cache :climate) not-attached))

(defn climate-projection
  ``The origin-and-scale projection this cache carries, or nil when unattached.

  `origin` is the WORLD voxel origin of climate grid cell (0,0) and `scale` how
  many world cells one climate cell spans. It is stored because it cannot be
  derived: a 128x128 climate grid can back a 128x128 map or a 256x256 one, and
  those two readings place every sample in a different spot.``
  [cache]
  (cache :climate-projection))

(defn- same-climate?
  "Do two attach results say the same thing? Frozen data compares structurally."
  [a b]
  (cond
    (not= (get a :status) (get b :status)) false
    (climate/present? a)
    (and (= (get a :shape) (get b :shape))
         (= (get a :bytes) (get b :bytes))
         (= (get a :values) (get b :values)))
    true))

(defn- grid-of
  "The `(height width)` a present climate result describes."
  [result] [(get result :height) (get result :width)])

(defn- owned-to-leaves?
  ``Is `v` immutable all the way down, so it can be stored without copying?

  Arrays, tables and buffers are mutable at any depth, so they are never owned.
  A tuple or struct is owned only if every element is owned. Scalars are.``
  [v]
  (cond
    (or (array? v) (buffer? v) (table? v)) false
    (tuple? v) (every? (map owned-to-leaves? v))
    (struct? v) (every? (map (fn [[_ x]] (owned-to-leaves? x)) (pairs v)))
    true))

(defn- own-deep
  ``A frozen, fully OWNED copy of `v`, safe to keep after the caller returns.

  `climate-tile/read` hands back a MUTABLE table: its channel arrays are frozen
  but the table around them is not, so a caller holding that table can `put` a
  new `:status` or wipe `:values` and thereby corrupt whatever the cache kept.
  Storing the caller's object would make the cache's climate depend on a
  reference it does not control, and a later biome classification reading through
  it would silently change -- exactly the aliasing bug the climate reader's own
  header warns about, one level up.

  So attachment OWNERS its data: every array becomes a tuple (immutable and
  structurally comparable, which is also what makes idempotent re-attachment
  work) and every table becomes a struct.

  A tuple or struct is NOT automatically owned. Being immutable, it can still
  HOLD something mutable -- `(struct :values @[1 2 3])` is a read-only wrapper
  around a live array, and mutating that array through it changes what the
  wrapper reports. Returning such a container as-is would leave the cache
  sharing the caller's memory, which is the whole bug this function exists to
  prevent. So the scan is RECURSIVE and the container is rebuilt whenever any
  element is still mutable; a container that is already owned to the leaves is
  returned untouched, so the common case (tuples of numbers) costs one pass and
  no allocation.``
  [v]
  (cond
    (array? v) (tuple ;(map own-deep v))
    (buffer? v) (string v)
    (table? v) (struct ;(mapcat (fn [[k x]] [k (own-deep x)]) (pairs v)))
    (tuple? v) (if (every? (map owned-to-leaves? v))
                 v (tuple ;(map own-deep v)))
    (struct? v) (if (every? (map (fn [[_ x]] (owned-to-leaves? x)) (pairs v)))
                  v (struct ;(mapcat (fn [[k x]] [k (own-deep x)]) (pairs v))))
    v))

(defn attach-climate!
  ``Attach an ALREADY-VALIDATED climate result under an explicit projection.

  `decoded` is a result from `climate-tile` (`:present` with frozen per-channel
  values, or the `:unavailable` "producer wrote no climate" record) -- this
  function never decodes bytes itself and never opens a container. `origin` is
  the world voxel position of grid cell (0,0) as `[ox oz]`; `scale` how many
  world cells one climate cell spans.

  THE PROJECTION IS NEVER INFERRED. Two checks make a wrong reading impossible:

    * `origin` must equal the map's own declared origin (`:origin`, the
      producer's `origin_voxels`). Sampling with a different anchor would shift
      every sample while still landing inside the grid, so a mismatch is refused
      rather than quietly reprojected.
    * `scale` is a positive integer: how many world cells one climate cell
      spans. It defaults to 1 in `attach-climate`, which is the ordinary 1:1 map.
      A coarser grid is accepted ONLY when it covers the map exactly --
      `grid * scale == map cells` on both axes. A 128 grid over a 512 map needs
      scale 4; scale 1 there would claim one sample for four columns and is
      refused with both extents named. A grid that would leave a remainder is
      refused too, because closing that gap means inventing values the producer
      never emitted. Nothing is ever resampled or interpolated here.

  The caller's `decoded` is COPIED into an owned, frozen equivalent, so mutating
  the table it was given afterwards cannot alter what this cache will classify
  with. Returns the cached (owned) climate result. Re-attaching identical data is
  idempotent; different data is refused. Reads nothing from disk, writes
  nothing.``
  [cache decoded origin scale]
  (when (closed? cache) (fail "cache is closed"))
  (unless (or (table? cache) (struct? cache))
    (fail "attach-climate! needs a cache"))
  (unless (and (or (table? decoded) (struct? decoded))
               (or (climate/present? decoded) (climate/unavailable? decoded)))
    (fail "decoded climate must be a climate-tile result (:present or :unavailable)"))
  (when (climate/present? decoded)
    (unless (cache :bounds)
      (fail (string "climate attaches only to a bounded scenic cache; a legacy "
                    "cache declares no map extent to check a grid against")))
    (unless (and (or (tuple? origin) (array? origin)) (= 2 (length origin))
                 (valid-coord? (get origin 0)) (valid-coord? (get origin 1)))
      (fail "origin must be two signed integers, the world voxel origin of cell (0,0)"))
    # The anchor must match BOTH the manifest's declared origin and the map's
    # own cell origin. The producer derives `chunk_min` from `origin_voxels`, so
    # a map covering chunks `cx0..cx1` necessarily starts at world
    # `(cx0*16, cz0*16)`; an origin disagreeing with that is not a projection,
    # it is a mis-declaration, and sampling through it would silently place every
    # sample on the wrong cell while still landing inside the grid.
    (def b (cache :bounds))
    (def expected-origin [(* (get b 0) tile-size) (* (get b 1) tile-size)])
    (def declared (cache :origin))
    (each [ok why]
      [[(= (get origin 0) (get expected-origin 0))
        (string "origin x " (get origin 0) ", this map's cells begin at x "
                (get expected-origin 0) " (chunk " (get b 0) " x " tile-size ")")]
       [(= (get origin 1) (get expected-origin 1))
        (string "origin z " (get origin 1) ", this map's cells begin at z "
                (get expected-origin 1) " (chunk " (get b 1) " x " tile-size ")")]]
      (unless ok
        (fail (string "climate " why
                      "; sampling under a different anchor would misplace every "
                      "sample, so it is refused rather than reprojected"))))
    (when declared
      (unless (and (= (get origin 0) (get declared 0))
                   (= (get origin 1) (get declared 1)))
        (fail (string "climate origin " (string (tuple ;origin))
                      " does not match this map's declared origin "
                      (string (tuple ;declared))))))
    (unless (and (integer? scale) (pos? scale))
      (fail "scale must be a positive integer"))
    # COVERAGE, not resampling. A climate cell spans `scale` world cells on each
    # axis, so the grid must cover the map EXACTLY: `gw * scale == cells_x` and
    # `gh * scale == cells_z`. A grid that would leave a remainder is refused,
    # because filling the gap would mean interpolating values the producer never
    # emitted. `scale 1` is simply the identity case and remains the default.
    (def e (climate-extent cache))
    (def [gh gw] (grid-of decoded))
    (def want-x (* gw scale))
    (def want-z (* gh scale))
    (unless (and (= want-x (get e 2)) (= want-z (get e 3)))
      (fail (string "climate grid is " gw "x" gh " at scale " scale
                    ", covering " want-x "x" want-z " world cells, but this map is "
                    (get e 2) "x" (get e 3)
                    "; the grid must cover the map exactly, and a remainder is "
                    "refused rather than resampled"))))
  # A grid can be self-consistent and still be far too large to keep. Checked
  # before copying, so an over-cap attachment costs nothing.
  (when (climate/present? decoded)
    (def cells (* (get decoded :width) (get decoded :height)))
    (when (> cells climate-max-cells)
      (fail (string "climate grid is " cells " cells, above the "
                    climate-max-cells "-cell cap (a 512x512 map)")))
    (when (> (get decoded :bytes) climate-max-bytes)
      (fail (string "climate payload is " (get decoded :bytes)
                    " bytes, above the " climate-max-bytes "-byte cap"))))
  (def owned (own-deep decoded))
  (def current (cache :climate))
  (when current
    (unless (same-climate? current owned)
      (fail "climate is already attached to this cache and this is different data")))
  (put cache :climate owned)
  (put cache :climate-projection
       (if (climate/present? owned)
         (freeze @{:origin (freeze [(get origin 0) (get origin 1)]) :scale scale})
         nil))
  owned)

(defn attach-climate
  ``Validate a raw climate product and attach it in one call.

  `values` is a buffer or string of little-endian channel-last float32 (nil when
  the producer wrote no climate), `shape` its `(height width 5)` grid, and `meta`
  the raw-export sidecar record. Validation is delegated wholesale to
  `climate-tile/read` -- the single presence, shape, length and NaN authority --
  and attachment is then delegated to `attach-climate!`.

  `origin` defaults to the map's own `:origin` and `scale` to 1, which is the
  1:1 reading. Because those defaults are only valid when the grid really matches
  the map, a mismatched grid is still refused: passing no projection never
  implies a guess.``
  [cache values shape meta &opt origin scale]
  (def result (climate/read values shape meta))
  (attach-climate! cache result (or origin (cache :origin)) (or scale 1)))

(defn- known? [cache cx cz] (truthy? (get (cache :available) (key cx cz))))
(defn- pending-index [cache cx cz]
  (def k (key cx cz))
  (var found nil)
  (for i 0 (length (cache :pending))
    (def e (get (cache :pending) i))
    (if (and (nil? found) (= k (key (e :cx) (e :cz)))) (set found i)))
  found)

(defn- error-reason
  "Trimmed, length-capped backend failure text, or nil when there is none."
  [dir cx cz]
  (def b (read-capped (error-path dir cx cz) 201))
  (when b
    (def t (string/trim (string b)))
    (if (= 201 (length b)) (string (string/slice t 0 200) "...") t)))

(defn read-height-tile
  ``The heights for one coordinate, or nil when no tile exists yet.

  Throws when the tile exists but is malformed, when it was written for the
  other profile, and when the backend recorded a terminal failure: silence about
  a file that can never be used would hide terrain that will never appear.

  Outside a scenic map's bounds this returns nil -- but a tile that IS present
  out there is refused, because serving it would inject another mapping's
  terrain into this world. One `stat` plus at most 309 bytes are read: bounded in
  bytes, still synchronous, no claim to be non-blocking.``
  [cache cx cz]
  (when (closed? cache) (fail "cache is closed"))
  (unless (and (valid-coord? cx) (valid-coord? cz))
    (fail "coordinates must be signed 32-bit integers"))
  (def dir (cache :dir))
  (def path (tile-path dir cx cz))
  (def inside (in-bounds? cache cx cz))
  (if (os/stat path)
    (let [bytes (read-capped path (+ 1 tile-bytes))]
      (unless bytes (fail (string "tile " path " is unreadable")))
      (when (> (length bytes) tile-bytes)
        (fail (string "tile " path " is larger than " tile-bytes " bytes")))
      (unless inside
        (fail (string "tile " path " is outside the declared map bounds "
                      (string (cache :bounds)))))
      (def heights (decode-tile-for (cache :profile) bytes cx cz))
      (put (cache :available) (key cx cz) true)
      heights)
    (do (put (cache :available) (key cx cz) nil)
        (when inside
          (if-let [why (error-reason dir cx cz)]
            (fail (string "backend failed for (" cx "," cz "): " why)))))))

(defn- ensure-dir [path]
  (or (get (protect (os/mkdir path)) 0) (= :directory (os/stat path :mode))))

(defn- stamp-request
  ``Publish one request marker by atomic rename: `:requested`, `:suppressed`
  (a marker already exists) or `:error`.``
  [cache cx cz]
  (def dir (cache :dir))
  (def dest (request-path dir cx cz))
  (if (not (ensure-dir (requests-dir dir))) :error
      (if (os/stat dest) :suppressed
          (do
            (def tmp (string (requests-dir dir) "/." (coord-name cx cz) "."
                             (os/getpid) ".tmp"))
            (def f (file/open tmp :wbn))
            (if (nil? f) :error
                (do (file/write f (string "cx=" cx " cz=" cz " format="
                                          (cache :magic) "\n"))
                    (file/close f)
                    (if (get (protect (os/rename tmp dest)) 0) :requested
                        (do (try (os/rm tmp) ([e] nil)) :error))))))))

(defn request
  ``Ask the backend for one coordinate: `:ready`, `:requested`, `:suppressed`
  (queued or terminally failed), `:queued` (pending set full), `:error`,
  `:closed`, or `:out-of-bounds`.

  A scenic map is finite, so a coordinate outside its bounds answers
  `:out-of-bounds` and writes nothing -- there is no worker to start and no
  noise to substitute. Idempotent: one coordinate maps to one marker file.``
  [cache cx cz]
  (cond
    (closed? cache) :closed
    (not (and (valid-coord? cx) (valid-coord? cz)))
    (fail "request requires signed 32-bit integer coordinates")
    (not (in-bounds? cache cx cz)) :out-of-bounds
    # A backend may have delivered the tile since this cache last looked, so a
    # missing hint is not proof of absence. One stat is fine on this slow path.
    (or (known? cache cx cz)
        (not (nil? (os/stat (tile-path (cache :dir) cx cz)))))
    (do (put (cache :available) (key cx cz) true) :ready)
    (or (get (cache :failed) (key cx cz))
        (not (nil? (os/stat (error-path (cache :dir) cx cz))))) :suppressed
    (not (nil? (pending-index cache cx cz))) :suppressed
    (>= (length (cache :pending)) (cache :capacity)) :queued
    true
    (let [out (stamp-request cache cx cz)]
      (when (= out :requested) (array/push (cache :pending) @{:cx cx :cz cz}))
      out)))

(defn poll
  ``Probe pending coordinates and collect what resolved; never throws.

  Returns `@[[:ready cx cz heights] [:error cx cz reason] ...]`, probing at most
  `limit` per call (default 4). The window rotates: always starting at index 0
  would re-probe the head and never visit a ready coordinate behind a burst of
  unanswered ones. The queue keeps its own order and the cursor addresses it, so
  `ceil(n/limit)` calls cover it, and an empty probe keeps the coordinate queued.
  A malformed tile or a backend error file is terminal and reported once.``
  [cache &opt limit]
  (default limit default-poll)
  (unless (and (valid-coord? limit) (pos? limit))
    (fail "poll limit must be a positive integer"))
  (if (or (closed? cache) (empty? (cache :pending))) @[]
      (let [pending (cache :pending)
            count (length pending)
            start (mod (cache :cursor) count)
            probed (min limit count)
            results @[]
            keep @[]]
      (for i 0 count
        (def e (get pending i))
        (def cx (e :cx))
        (def cz (e :cz))
        (if (< (mod (- i start) count) probed)
          (let [probe (protect (read-height-tile cache cx cz))]
            (cond
              (not (get probe 0))
              (do (def why (string (get probe 1)))
                  (put (cache :failed) (key cx cz) why)
                  (array/push results [:error cx cz why]))
              (nil? (get probe 1)) (array/push keep e)      # still absent
              (array/push results [:ready cx cz (get probe 1)])))
          (array/push keep e)))
      (put cache :pending keep)
      (put cache :cursor (mod (+ start probed) count))
      results)))

(defn available?
  "Is this coordinate's tile known to be present?"
  [cache cx cz] (known? cache cx cz))

(defn failed?
  "Did this coordinate fail terminally?"
  [cache cx cz] (truthy? (get (cache :failed) (key cx cz))))

(defn cancel
  ``Drop one coordinate from the local pending set, leaving its marker on disk
  for a later session; true when something was removed.``
  [cache cx cz]
  (def i (pending-index cache cx cz))
  (if (nil? i) false (do (array/remove (cache :pending) i) true)))

(defn climate-cell
  ``The `[gx gz]` climate grid cell for a chunk column, or nil when off the map.

  Computed through the ATTACHED projection, never from the bounds anchor alone:

      gx = floor((cx*16 + ox - origin_x) / scale)

  so a climate grid that starts at a world origin other than the map's first
  chunk, or that spans more than one world cell per sample, is still addressed
  correctly. `ox`/`oz` select a column inside the chunk (`0..15`, default 0).

  Answers nil when climate is unattached or the point falls outside the grid.
  It NEVER clamps: an edge cell is a different place on the map.``
  [cache cx cz &opt ox oz]
  (default ox 0)
  (default oz 0)
  (unless (and (valid-coord? cx) (valid-coord? cz))
    (fail "climate-cell requires signed 32-bit integer coordinates"))
  (unless (and (integer? ox) (<= 0 ox (dec tile-size)))
    (fail (string "in-chunk x offset must be 0.." (dec tile-size))))
  (unless (and (integer? oz) (<= 0 oz (dec tile-size)))
    (fail (string "in-chunk z offset must be 0.." (dec tile-size))))
  (def result (cache :climate))
  (def projection (cache :climate-projection))
  (when (and (climate/present? result) projection)
    (def o (projection :origin))
    (def s (projection :scale))
    (def gx (math/floor (/ (- (+ (* cx tile-size) ox) (get o 0)) s)))
    (def gz (math/floor (/ (- (+ (* cz tile-size) oz) (get o 1)) s)))
    (when (and (<= 0 gx (dec (get result :width)))
               (<= 0 gz (dec (get result :height))))
      [gx gz])))

(defn- owned-answer
  ``A frozen, owned copy of a sample answer -- or of an unavailable marker.

  `climate-tile/sample` returns a mutable table, so handing it straight out would
  let a caller edit one reader's answer and (through a shared shape) mislead the
  next. Every query answer leaves this module as a struct of plain numbers.``
  [v]
  (own-deep v))

(defn climate-at-world
  ``Sample climate at WORLD voxel (wx, wz) through the attached projection.

  This is the honest coordinate path. The projection -- not the map bounds --
  decides where a sample lands:

      gx = floor((wx - ox) / scale)      gz = floor((wz - oz) / scale)

  where `ox`/`oz` is the world origin of grid cell (0,0) stored at attach time.
  Division, not multiplication by a ratio: with `scale` a positive integer, floor
  division is exact and needs no rounding decision.

  Returns `climate-tile/sample`'s record for an inside cell, or
  `{:status :unavailable}` with `:not-attached`, `:absent` or `:outside-map`
  (the world point fell outside the grid). It never clamps to an edge sample and
  never invents a value, and it throws for nothing but a non-finite coordinate.``
  [cache wx wz]
  (unless (and (number? wx) (number? wz) (not (nan? wx)) (not (nan? wz))
               (< -1e308 wx) (< wx 1e308) (< -1e308 wz) (< wz 1e308))
    (fail "climate-at-world needs finite world coordinates"))
  (def result (cache-climate cache))
  (def projection (cache :climate-projection))
  (cond
    (climate/unavailable? result)
    (owned-answer @{:status :unavailable :reason (get result :reason)})
    (nil? projection)
    (owned-answer @{:status :unavailable :reason :not-attached})
    true
    (let [o (projection :origin)
          s (projection :scale)
          gx (math/floor (/ (- wx (get o 0)) s))
          gz (math/floor (/ (- wz (get o 1)) s))]
      (if (or (< gx 0) (>= gx (get result :width))
              (< gz 0) (>= gz (get result :height)))
        (owned-answer @{:status :unavailable :reason :outside-map})
        (owned-answer (climate/sample result gx gz))))))

(defn climate-at
  ``Sample climate at the world position of chunk (cx, cz) plus a column offset.

  A chunk occupies `16 x 16` world cells and starts at `(cx*16, cz*16)`; `ox`/`oz`
  pick a column inside it (`0..15`, default the chunk's first column). The point
  is then sampled through `climate-at-world`, so the attached projection decides
  the grid cell and the map bounds never do.

  Unavailable answers are the same vocabulary as `climate-at-world`:
  `:not-attached`, `:absent`, `:outside-map`.``
  [cache cx cz &opt ox oz]
  (default ox 0)
  (default oz 0)
  (unless (and (valid-coord? cx) (valid-coord? cz))
    (fail "climate-at requires signed 32-bit integer chunk coordinates"))
  (unless (and (integer? ox) (<= 0 ox (dec tile-size)))
    (fail (string "in-chunk x offset must be 0.." (dec tile-size))))
  (unless (and (integer? oz) (<= 0 oz (dec tile-size)))
    (fail (string "in-chunk z offset must be 0.." (dec tile-size))))
  (climate-at-world cache (+ (* cx tile-size) ox) (+ (* cz tile-size) oz)))

(defn close
  "Release the consumer. Markers stay on disk for a later session."
  [cache] (put cache :closed true) cache)

(defn status
  ``A small table for a HUD line, the console `(stats)` verb or a readout.

  `:climate` is one of `:absent` (no climate attached, including every cache
  that never asked), `:present` or `:unavailable` (attached, but the producer
  wrote none). It is a MARKER only -- no grid is copied, so this table stays
  cheap, and every other key means exactly what it did before climate existed.``
  [cache]
  (def c (cache :climate))
  @{:dir (cache :dir) :identity (cache :identity) :seed (cache :seed)
    :profile (cache :profile) :bounds (cache :bounds)
    :capacity (cache :capacity) :available (length (cache :available))
    :pending (length (cache :pending)) :failed (length (cache :failed))
    :closed (cache :closed)
    :climate (cond
               (nil? c) :absent
               (climate/present? c) :present
               :else :unavailable)})
