# CPU-only versioned recipes; no atlas or GL dependency.
# Public: version, fallback, recipes, validate, resolve, sample, load, save,
#         source, current, reload.
# Optional controls: :brightness (0..2), :grain-density (0..16), :pixel-size (1..64).
# RGBA colors are byte tuples. Coordinates passed to sample are pixel coordinates.
(def version 1)
# Precedence for v1 files: valid authored entries win; absent/invalid entries
# use current builtins. Only exact tracked 434d1ad grain defaults migrate in
# memory to reference-inspired speckle builtins. No authored file is rewritten;
# a save explicitly persists the effective map. Other valid grain edits survive.
(def legacy-speckle-defaults
  {:grass {:version 1 :kind :grain :base [83 159 59 255] :dark [49 123 43 255] :light [111 184 72 255] :scale 4 :seed 3}
   :sand {:version 1 :kind :grain :base [221 207 145 255] :dark [191 174 114 255] :light [240 227 173 255] :scale 3 :seed 5}})
(def fallback {:version 1 :kind :checker :base [255 0 255 255]
               :dark [30 30 30 255] :light [255 0 255 255]
               :scale 4 :seed 0})
(def recipes
  {:stone {:version 1 :kind :noise :base [126 128 130 255] :dark [93 97 100 255] :light [158 160 157 255] :scale 4 :seed 1}
   :dirt {:version 1 :kind :noise :base [125 85 52 255] :dark [94 60 38 255] :light [153 108 68 255] :scale 5 :seed 2}
   :grass {:version 1 :kind :speckle :base [83 159 59 255] :dark [49 123 43 255] :light [111 184 72 255] :scale 1 :seed 3}
   :sand {:version 1 :kind :speckle :base [221 207 145 255] :dark [191 174 114 255] :light [240 227 173 255] :scale 1 :seed 5}
   :water {:version 1 :kind :wave :base [55 116 190 255] :dark [36 88 156 255] :light [85 151 211 255] :scale 5 :seed 6}
   :wood {:version 1 :kind :grain :base [136 94 51 255] :dark [90 56 29 255] :light [163 119 67 255] :scale 5 :seed 7}
   :leaves {:version 1 :kind :voronoi :base [48 113 48 255] :dark [30 79 36 255] :light [69 141 57 255] :scale 5 :seed 8}
   :masonry {:version 1 :kind :brick :base [153 85 66 255] :dark [82 75 70 255] :light [185 112 86 255] :scale 8 :seed 9}
   :tiles {:version 1 :kind :checker :base [180 180 170 255] :dark [80 85 90 255] :light [220 220 210 255] :scale 4 :seed 10}
   :snow {:version 1 :kind :speckle :base [232 238 246 255] :dark [206 216 232 255] :light [246 250 255 255] :scale 2 :seed 11}})

(defn- byte? [n] (and (number? n) (>= n 0) (<= n 255) (= n (math/floor n))))
(defn- color? [c]
  (and (tuple? c) (= (length c) 4)
       (byte? (get c 0)) (byte? (get c 1))
       (byte? (get c 2)) (byte? (get c 3))))
(defn- plain-data? [v]
  (cond
    (or (nil? v) (boolean? v) (number? v) (string? v) (keyword? v)) true
    (tuple? v) (every? (map plain-data? v))
    (or (table? v) (struct? v))
    (every? (map (fn [[k value]] (and (keyword? k) (plain-data? value))) (pairs v)))
    false))
(defn- finite-range? [n low high]
  (and (number? n) (>= n low) (<= n high)))
(defn validate [r]
  "True for supported version-1 recipe data; optional controls have defaults."
  (and (or (table? r) (struct? r)) (= (get r :version) version)
       (some |(= (get r :kind) $) [:grain :noise :voronoi :wave :checker :brick :speckle])
       (color? (get r :base)) (color? (get r :dark)) (color? (get r :light))
       (number? (get r :scale)) (> (get r :scale) 0) (<= (get r :scale) 4096)
       (number? (get r :seed)) (= (get r :seed) (math/floor (get r :seed)))
        (finite-range? (get r :brightness 1.0) 0 2)
        (finite-range? (get r :grain-density 1.0) 0 16)
        (finite-range? (get r :pixel-size 1) 1 64)
        (= (get r :pixel-size 1) (math/floor (get r :pixel-size 1)))))
(defn resolve [entry]
  "Resolve a recipe or built-in keyword; invalid/unknown entries use fallback."
  (let [candidate (if (or (table? entry) (struct? entry)) entry (get recipes entry))]
    (if (validate candidate) candidate fallback)))

(defn- parse-data [text]
  (let [p (parser/new)]
    (parser/consume p text)
    # Check the consume status BEFORE signalling end-of-input: once the parser
    # holds an unchecked error, `parser/eof` raises instead of reporting, so the
    # caller sees an internal parser error rather than the real diagnosis.
    (when (= (parser/status p) :error) (error "invalid material data syntax"))
    (parser/eof p)
    (when (= (parser/status p) :error) (error "invalid material data syntax"))
    (when (not (parser/has-more p)) (error "empty material data"))
    (let [value (get (parser/produce p true) 0)]
      (when (parser/has-more p) (error "material data must contain one form"))
      (when (not (plain-data? value)) (error "material data contains non-data forms"))
      value)))
(defn- sanitize [data]
  (when (not (and (or (table? data) (struct? data))
                  (= (get data :version) version)
                  (or (table? (get data :recipes)) (struct? (get data :recipes)))))
    (error "unsupported material data version or shape"))
  (let [out (table)]
    (each [name recipe] (pairs recipes)
      (let [candidate (get (get data :recipes) name)]
        (put out name (if (validate candidate)
                        (if (or (deep= candidate recipe)
                                (deep= candidate (get legacy-speckle-defaults name)))
                           recipe candidate)
                        recipe))))
    (each [name candidate] (pairs (get data :recipes))
      (when (and (keyword? name) (nil? (get recipes name)) (validate candidate))
        (put out name candidate)))
    out))
(defn load [&opt path]
  "Load one inert Janet data form; missing file returns builtins, malformed file errors."
  (let [path (or path "data/materials.janet")
        f (file/open path :rb)]
    (if (nil? f) recipes
        (let [text (try (file/read f :all)
                         ([err] (file/close f) (error err)))]
          (file/close f)
          (sanitize (parse-data text))))))

(def material-order [:stone :dirt :grass :sand :water :wood :leaves :snow :masonry :tiles])

(defn- color-literal
  "Render one RGBA colour as a literal tuple, matching the hand-written style."
  [c]
  (string/format "[%d %d %d %d]" (get c 0) (get c 1) (get c 2) (get c 3)))

(defn format-recipes
  ``Render the recipe map as a file meant to be READ AND EDITED by hand.

  `%j` would round-trip correctly but writes the whole map on one line without
  the explanatory header -- the difference between a config file and a dump.
  Since this file is the authoring surface, layout is part of the contract.

  Known blocks are written in the built-in order so a diff after a save shows
  only what actually changed; unknown blocks follow in sorted order so a custom
  recipe is never silently dropped.``
  [cleaned]
  (def out @"")
  (buffer/push-string out
    "# Trinecraft material recipes, format version 1. Edit colors as RGBA byte tuples.\n"
    "# Optional per-recipe fields: :brightness 0..2, :grain-density 0..16,\n"
    "# :pixel-size 1..64 (integer). Missing controls default to 1.\n"
    "# Missing or invalid individual recipes fall back to builtins on load.\n"
    "{:version 1\n :recipes {")
  # Known blocks in built-in order, then any custom block alphabetically, so a
  # save produces a minimal diff and never drops a custom recipe.
  (def known (filter (fn [k] (not (nil? (get cleaned k)))) material-order))
  (def extra (filter (fn [k] (nil? (find (fn [o] (= o k)) material-order)))
                     (sort (keys cleaned))))
  (def ordered (array/concat @[] known extra))
  (var first true)
  (each k ordered
    (def key (if (keyword? k) k (keyword k)))
    (def r (get cleaned key))
    (unless first (buffer/push-string out "\n  "))
    (set first false)
    (buffer/push-string out
      (string/format " %s %s:version 1 :kind %s :base %s :dark %s :light %s"
                     (string ":" (if (keyword? k) k (keyword k)))
                     (if (table? r) "@{" "{")
                     (string ":" (r :kind))
                     (color-literal (r :base))
                     (color-literal (r :dark))
                     (color-literal (r :light))))
    (each opt [:scale :seed :brightness :grain-density :pixel-size]
      (when (get r opt)
        (buffer/push-string out
          (string/format " :%s %s" opt
                         (if (or (= opt :scale) (= opt :seed)
                                 (= opt :grain-density) (= opt :pixel-size))
                           (string/format "%d" (get r opt))
                           (string (get r opt)))))))
    (buffer/push-string out "}"))
  (buffer/push-string out "}}\n")
  (string out))

(defn save [entries &opt path]
  "Validate and atomically replace version-1 material data; return sanitized map."
  (let [path (or path "data/materials.janet")
        cleaned (sanitize {:version version :recipes entries})
        tmp (string path ".tmp-" (os/getpid) "-" (os/time))
        f (file/open tmp :wbn)]
    (try
      (do
        (when (nil? f) (error "cannot open temporary material file"))
        (file/write f (format-recipes cleaned))
        (file/flush f)
        (file/close f)
        (os/rename tmp path))
      ([err]
        (when f (try (file/close f) ([ignored] nil)))
        (try (os/rm tmp) ([ignored] nil))
        (error err)))
    cleaned))

# The caller owns this state. Reload returns a new state only after parsing and
# validating the complete file; an error leaves the previous state untouched.
# Pass (get state :recipes) to atlas/build-atlas-image. No GL work happens here.
(defn source [&opt path]
  "Create a file-backed material state; load the file now (or use builtins if absent)."
  (let [path (or path "data/materials.janet")]
    {:path path :recipes (load path)}))
(defn current [state]
  "Return the active recipe map for atlas image generation."
  (get state :recipes))
(defn reload [state]
  "Re-read the state's path; return a new state on success, throw on failure."
  (let [path (get state :path)]
    (when (not (string? path)) (error "material source needs a path"))
    {:path path :recipes (load path)}))

(defn- hash-cell [seed x y]
  (let [m 2147483647
        a (mod (+ (* (mod x m) 48271) (* (mod y m) 69621)
                  (* (mod seed m) 16807) 1) m)]
    (mod (* a 48271) m)))
(defn- fract [x] (- x (math/floor x)))
(defn- lerp [a b t] (+ a (* (- b a) t)))
(defn- lattice [seed x y] (/ (hash-cell seed x y) 2147483647.0))
(defn- noise [seed x y]
  (let [ix (math/floor x) iy (math/floor y)
        fx (fract x) fy (fract y)
        u (* fx fx (- 3 (* 2 fx))) v (* fy fy (- 3 (* 2 fy)))]
    (lerp (lerp (lattice seed ix iy) (lattice seed (+ ix 1) iy) u)
          (lerp (lattice seed ix (+ iy 1)) (lattice seed (+ ix 1) (+ iy 1)) u) v)))
(defn- voronoi [seed x y]
  (let [ix (math/floor x) iy (math/floor y)]
    (var nearest 2.0)
    (for cy (- iy 1) (+ iy 2)
      (for cx (- ix 1) (+ ix 2)
        (let [px (+ cx (lattice seed cx cy)) py (+ cy (lattice (+ seed 41) cx cy))
              dx (- x px) dy (- y py)]
          (set nearest (min nearest (+ (* dx dx) (* dy dy)))))))
    (min 1.0 nearest)))
(defn- clamp [v] (max 0.0 (min 1.0 v)))
(defn- tint [r amount]
  (let [base (get r :base) target (get r (if (< amount 0.5) :dark :light))
        blend (* 2 (math/abs (- amount 0.5))) brightness (get r :brightness 1.0)]
    [(min 255 (math/floor (+ 0.5 (* brightness (lerp (get base 0) (get target 0) blend)))))
     (min 255 (math/floor (+ 0.5 (* brightness (lerp (get base 1) (get target 1) blend)))))
     (min 255 (math/floor (+ 0.5 (* brightness (lerp (get base 2) (get target 2) blend)))))
     (get base 3)]))
(defn- speckle [seed x y]
  (mod (+ (* (+ x seed) 73856093) (* (+ y seed) 19349663)
          (* (+ x seed) (+ y seed) 83492791)) 17))
(defn sample [entry x y]
  "Return RGBA bytes for a built-in keyword or validated recipe at pixel x,y."
  (let [r (resolve entry) scale (get r :scale) seed (get r :seed)
        pixel-size (get r :pixel-size 1)
        density (get r :grain-density 1.0)
        u (/ (* (math/floor (/ x pixel-size)) pixel-size) scale)
        v (/ (* (math/floor (/ y pixel-size)) pixel-size) scale)
        amount (case (get r :kind)
                 :speckle (let [n (speckle seed (math/floor (/ x pixel-size))
                                             (math/floor (/ y pixel-size)))]
                            (if (< n 2) 0.0 (if (> n 14) 1.0 0.5)))
                 :grain (noise seed (* density (+ (* u 0.22) (* v 0.08))) (* density v 2.5))
                 :noise (noise seed u v)
                 :voronoi (- 1 (voronoi seed u v))
                 :wave (* 0.5 (+ 1 (math/sin (+ (* v 6.283185307179586)
                                                  (* 0.8 (noise seed u v))))))
                 :checker (if (= (mod (+ (math/floor u) (math/floor v)) 2) 0) 0.0 1.0)
                 :brick (let [row (math/floor v)
                              bx (fract (+ u (* 0.5 (mod row 2)))) by (fract v)]
                          (if (or (< bx 0.08) (< by 0.08)) 0.0
                              (+ 0.55 (* 0.45 (noise seed u v)))))
                 0.5)]
    (tint r (clamp amount))))
