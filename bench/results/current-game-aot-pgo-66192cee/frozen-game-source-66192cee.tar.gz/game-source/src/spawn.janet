# Bounded dry-land spawn search over *loaded* voxel chunks only.
(import ./world :as world)
(import ./player :as player)

(defn- loaded-block [w x y z]
  (let [cx (world/world-to-chunk-coord x)
        cz (world/world-to-chunk-coord z)]
    (when (world/world-get-chunk w cx cz)
      (world/world-get-block w x y z))))

(defn- foot-cells [x z]
  (let [cx (+ x 0.5) cz (+ z 0.5) hw player/half-width]
    [(math/floor (- cx hw)) (math/floor (+ cx hw))
     (math/floor (- cz hw)) (math/floor (+ cz hw))]))

(defn- ground-support? [id]
  # Wood and leaves collide with the player but cannot be a spawn floor.
  (or (= id world/block-stone) (= id world/block-dirt)
      (= id world/block-grass) (= id world/block-sand)
      (= id world/block-snow)))

(defn- safe-at? [w x y z]
  # Same inclusive collision footprint as player/box-collides?, but water and
  # missing chunks both reject: neither is a safe floor or breathable air.
  (let [[x0 x1 z0 z1] (foot-cells x z)]
    (var safe true)
    (for bx x0 (+ x1 1)
      (for bz z0 (+ z1 1)
        (let [support (loaded-block w bx (- y 1) bz)]
          (unless (and support (ground-support? support))
            (set safe false)))
        (for by y (+ (math/floor (+ y player/player-height)) 1)
          (unless (= (loaded-block w bx by bz) world/block-air)
            (set safe false)))))
    safe))

# The waterline the search refuses to seat a player at or below. 28 is the
# shipped sea level and stays the default, so a session that never names one
# keeps exactly the search it had before this option existed.
(def default-sea-level 28)
# Bound the generic search by build height, not one provider's UI controls:
# imported scenic maps can have a different declared waterline.
(def sea-level-max (- world/chunk-y 2))

(defn- resolve-sea-level
  ``Validate an optional sea level, defaulting to the shipped 28.

  Integral and bounded are separate tests on purpose: NaN makes `(= v (floor v))`
  false and an infinity fails the range, so a fractional AND a non-finite value
  are both refused rather than silently becoming a different waterline.``
  [sea-level]
  (def v (if (nil? sea-level) default-sea-level sea-level))
  (assert (and (number? v) (= v (math/floor v)) (<= 0 v sea-level-max))
          (string "spawn sea level must be an integer 0.." sea-level-max))
  v)

(defn candidate-safe?
  ``Find safe feet Y above `sea-level` at integer column x,z, or nil.

  `sea-level` is optional and defaults to the shipped 28. It is a WATERLINE, not
  a terrain input: moving it changes which band the search may seat a player in
  and changes nothing that is generated, so a saved world's bytes and its
  identity are untouched.

  The lowest admissible feet are `sea + 1`, because the generator fills water for
  every block at or below the waterline (`src/worldgen.janet:145-148`): feet one
  block above it stand in air, and anything lower would seat the player in water.
  That bound is inclusive, so a column whose ground lies exactly AT the waterline
  is still usable -- the block under the feet is that dry ground, not water, and
  the floor still has to pass `ground-support?`. Returns nil for ocean,
  obstruction, or any missing footprint chunk.``
  [w x z &opt sea-level]
  (def sea (resolve-sea-level sea-level))
  (var position nil)
  # Prefer the highest clear supported standing place. The ceiling is excluded
  # because the player's 1.8-block body must fit wholly within build height.
  (var y (- world/chunk-y 2))
  (while (and (nil? position) (>= y (+ 1 sea)))
    (when (safe-at? w x y z)
      (set position @[(+ x 0.5) y (+ z 0.5)]))
    (-- y))
  position)

(defn- config [&opt options]
  (let [opts (or options {})
        x (get opts :origin-x 0)
        z (get opts :origin-z 0)
        radius (get opts :radius 8)
        sea (resolve-sea-level (get opts :sea-level))]
    (assert (and (number? x) (= x (math/floor x))
                 (number? z) (= z (math/floor z))
                 (number? radius) (= radius (math/floor radius))
                 (<= 0 radius 256))
            "spawn origin must be integral and radius 0..256")
    [x z radius sea]))

#
# --- Terrain-aware ranked seating (OPT-IN) ------------------------------
#
# The legacy search above stops at the FIRST safe column: it answers "can a body
# stand here", never "is this a place worth standing". A player who wanted to
# start inside a valley looking across it got whichever dry column the ring
# walk reached first, and the initial yaw was a constant -- so the opening view
# could point at a wall, at open sky, or off the edge of a finite map.
#
# This block adds a SECOND policy without touching the first. `:view-policy`
# absent means the old search runs, byte for byte, which is what keeps every
# existing world's spawn identical. Only an explicit `:enclosed-v1` opts in,
# and that is a caller's decision (`main` is not changed here).
#
# Three rules shape the ranking:
#
#   * THE HARD GATE IS UNCHANGED. `candidate-safe?` still decides whether a body
#     fits. Terrain quality is judged only for columns that already passed it,
#     so a ranked result can never be one the legacy search would refuse.
#
#   * UNKNOWN IS NOT EMPTY. A column whose chunk is not loaded yields nil, and
#     that means "not observed", never "flat". Treating it as flat would rank a
#     seat against a fabricating landscape -- precisely the failure that makes a
#     spawn look safe and then put the player against a wall nobody measured.
#
#   * WORK IS BOUNDED AND COUNTED. Every candidate costs a FIXED number of column
#     samples, and the budget is spent in those units. A 256-column slice can
#     therefore never turn into 256 full neighbourhood scans, and re-entering the
#     search with any slicing walks the same columns in the same order, so the
#     result does not depend on how the budget was chopped.

# Eight azimuths as EXACT integer unit vectors, clockwise from +x. Trig would
# put a diagonal sample on a neighbouring column depending on rounding; integers
# mean the same world always produces the same scores.
(def azimuths
  @[[1 0] [1 1] [0 1] [-1 1] [-1 0] [-1 -1] [0 -1] [1 -1]])

(def view-defaults
  @{:min-edge 2             # columns of KNOWN terrain demanded around the seat
    :sight-radii @[8 16 32] # horizon sample distances, in columns
    :min-rise 2             # blocks of rise that count as enclosing terrain
    :max-slope 2            # max ground delta to a neighbour for a walkable seat
    })

# How many of the eight azimuths must rise before a seat is CALLED enclosed. Five
# allows one open side -- the valley mouth the player looks out of -- while
# refusing a ridge, a peak or a coastline, where most directions fall away.
(def enclosed-azimuths 5)

(defn- ground-y
  ``Topmost walkable ground block at column x,z, or nil when NOT OBSERVED.

  nil conflates "chunk not loaded" with "loaded and no ground at all", and both
  mean the same thing to this policy: nothing here may be used as evidence.
  Reading the top down from the build ceiling is what makes "a canopy is not
  ground" true here as well.

  `memo` is an optional per-candidate cache keyed by the column. Every sample is
  a scan from the build ceiling, so the ring, the edge cushion and each sight
  radius would otherwise rescan the same neighbouring columns several times per
  candidate; the cache makes each column cost one scan instead of up to eight.
  It is passed in rather than shared BECAUSE the search is resumable: a cache
  that survived across frames would be unbounded state inside a bounded walk.``
  [w x z &opt memo]
  (def key [x z])
  (def cached (if memo (get memo key ::missing) ::missing))
  (if (not= cached ::missing)
    cached
    (let [found
          (when (world/world-get-chunk w (world/world-to-chunk-coord x)
                                         (world/world-to-chunk-coord z))
            (var y (- world/chunk-y 2))
            (var hit nil)
            (while (and (nil? hit) (>= y 0))
              (when (ground-support? (world/world-get-block w x y z))
                (set hit y))
              (-- y))
            hit)]
      (when memo (put memo key found))
      found)))

(defn- view-config
  ``Validate the opt-in view options, or raise naming the offending one.

  Every bound is explicit because each is a COST multiplier: `:sight-radii` and
  `:min-edge` decide how many columns one candidate samples, and an unbounded
  value would turn a bounded search into an unbounded one during a frame.``
  [opts]
  (def d view-defaults)
  (def min-edge (or (get opts :min-edge) (d :min-edge)))
  (def radii (or (get opts :sight-radii) (d :sight-radii)))
  (def min-rise (or (get opts :min-rise) (d :min-rise)))
  (def max-slope (or (get opts :max-slope) (d :max-slope)))
  (assert (and (number? min-edge) (= min-edge (math/floor min-edge))
               (<= 1 min-edge 16))
          "spawn :min-edge must be an integer 1..16")
  (assert (and (indexed? radii) (pos? (length radii))
               (truthy? (all |(and (number? $) (= $ (math/floor $))
                                   (<= 1 $ 64))
                             radii)))
          "spawn :sight-radii must be a non-empty list of integers 1..64")
  (assert (and (number? min-rise) (= min-rise (math/floor min-rise))
               (<= 1 min-rise 64))
          "spawn :min-rise must be an integer 1..64")
  (assert (and (number? max-slope) (= max-slope (math/floor max-slope))
               (<= 0 max-slope 16))
          "spawn :max-slope must be an integer 0..16")
  @{:min-edge min-edge :sight-radii radii :min-rise min-rise
    :max-slope max-slope})

(defn- view-cost
  ``Column samples one candidate costs: the gate, the ring, the edge, the horizon.

  Each term counts SAMPLES, not distance: the ring is eight columns, the edge
  cushion is eight (one per azimuth, whatever `:min-edge` puts their distance at),
  and the horizon is one per azimuth per sight radius. The memo in `ground-y`
  means repeated columns are scanned once, so this is an upper bound on the work
  and never an undercount -- a budget the loader cannot keep is worse than a
  slightly generous one.``
  [vc]
  (+ 1 8 8 (* 8 (length (vc :sight-radii)))))

(defn- view-candidate
  ``Score one SAFE column. Returns nil when it must not be seated, else a record.

  `feet` is the GATE's own answer for this column -- the y a body was proven to
  stand at -- so the ground under it is `feet - 1` by construction and the slope
  comparison is made against measured ground, never against a guess about where
  the surface is.

  `memo` is a per-candidate cache of `ground-y` results. Passing it here (rather
  than sharing one across the whole search) keeps the cache bounded to one
  candidate, which is what makes a resumed search cost the same as a continuous
  one.

  `:unknown` in the evidence is a real COUNT of samples that could not be
  observed, and a candidate is refused when it is non-zero. Reporting a literal 0
  while silently skipping unobserved columns would be the same lie told in a
  different place.``
  [w x z feet vc memo]
  (def base (dec feet))
  (var unknown 0)
  # Local walkable slope: a seat on a cliff face is technically safe and a bad
  # place to open the game.
  (var flat-enough true)
  (each [dx dz] azimuths
    (def gy (ground-y w (+ x dx) (+ z dz) memo))
    (cond
      (nil? gy) (++ unknown)
      (> (math/abs (- gy base)) (vc :max-slope)) (set flat-enough false)))
  # The edge cushion: never seat within `min-edge` columns of terrain nobody has
  # loaded, so the world around the player is real for at least that far.
  (each [dx dz] azimuths
    (when (nil? (ground-y w (+ x (* dx (vc :min-edge)))
                            (+ z (* dz (vc :min-edge))) memo))
      (++ unknown)))
  (if (or (pos? unknown) (not flat-enough))
    nil
    (do
      (var rising 0)
      (var focus-dir nil)
      (var focus-rise nil)
      (each [dx dz] azimuths
        (var hi (- base 100000))
        (var seen true)
        (each r (vc :sight-radii)
          (def gy (ground-y w (+ x (* dx r)) (+ z (* dz r)) memo))
          (if (nil? gy) (set seen false) (if (> gy hi) (set hi gy))))
        (if (not seen)
          (++ unknown)
          (do
            (def rise (- hi base))
            (when (>= rise (vc :min-rise)) (++ rising))
            # THE HIGHEST RELIEF DIRECTION, not the lowest horizon.
            #
            # Facing the lowest horizon is the intuition for a valley mouth, and
            # it is wrong for a first frame: the lowest horizon can be open sky
            # (rise 0), a step down to a beach, or -- on a finite map -- the edge
            # of what is loaded. All of those put the least terrain in the view.
            # The direction that ROSE the most is the one backed by the most
            # terrain, so the opening frame looks at rising ground inside the
            # world, with the valley under the player's feet.
            (when (or (nil? focus-rise) (> rise focus-rise))
              (set focus-rise rise)
              (set focus-dir [dx dz])))))
      (if (pos? unknown)
        nil
        (let [dir (or focus-dir [1 0])]
          @{:x x :z z :y feet
            :yaw (math/atan2 (get dir 1) (get dir 0))
            :pitch -0.12
            :enclosure? (>= rising enclosed-azimuths)
            :evidence @{:azimuths (length azimuths) :rising rising
                        :unknown unknown :radii (length (vc :sight-radii))
                        :focus-rise focus-rise}})))))

(defn- better-view?
  ``Is `a` a better seat than `b`? Deterministic, and prefers the EARLIER column.

  Strictly-greater on rising azimuths means a tie keeps the seat found first,
  and the ring walk finds nearest columns first -- so "most enclosed" and
  "closest to the origin" never fight, and the same world always yields the
  same seat however the budget was sliced.``
  [a b]
  (if (nil? b)
    true
    (> (get-in a [:evidence :rising]) (get-in b [:evidence :rising]))))

(defn- record-view
  "Store a scored candidate on the search as best-enclosed or first-safe."
  [search cand]
  (if (cand :enclosure?)
    (when (better-view? cand (search :best)) (put search :best cand))
    (when (nil? (search :first-safe)) (put search :first-safe cand))))

(defn- finish-view
  ``Turn a finished policy search into the legacy result shape plus the view.

  A seat is reported only if one survived the gate; otherwise `:exhausted`, whose
  meaning is unchanged ("this bounded region has no seat"). An enclosed seat is
  preferred; a merely safe one is returned with `:fallback? true` instead of a
  yaw nobody measured.``
  [search]
  (def best (search :best))
  (def safe (search :first-safe))
  (def pick (or best safe))
  (put search :status (if pick :found :exhausted))
  (when pick
    (put search :position @[(+ (pick :x) 0.5) (pick :y) (+ (pick :z) 0.5)])
    (put search :yaw (pick :yaw))
    (put search :pitch (pick :pitch))
    (put search :enclosure? (pick :enclosure?))
    (put search :fallback? (not (pick :enclosure?)))
    (put search :view-evidence (pick :evidence)))
  search)

(defn search-new
  ``Create a bounded deterministic search, ordered by Manhattan ring then x.

  Options: :origin-x, :origin-z (integer columns), :radius (default 8),
  :sea-level (integer 0..`sea-level-max`, default 28). The sea level is
  validated here, so a bad value fails at construction rather than midway
  through a bounded search.

  `:view-policy` is OPT-IN and absent by default. Without it the search is the
  original first-safe walk and the returned state carries NO extra keys, so an
  existing caller sees exactly what it always saw. `:enclosed-v1` adds ranked
  seating with the view options (`:min-edge`, `:sight-radii`, `:min-rise`,
  `:max-slope`); their validation runs HERE so a bad value fails at construction
  rather than after the loader has already started walking columns.``
  [&opt options]
  (let [[x z radius sea] (config options)
        opts (or options {})
        policy (get opts :view-policy)]
    (assert (or (nil? policy) (= :enclosed-v1 policy))
            "spawn :view-policy must be :enclosed-v1 or absent")
    (def base @{:origin-x x :origin-z z :radius radius :sea-level sea
                :ring 0 :dx 0
                :status :searching :position nil :examined 0
                :requiredchunks @{}})
    (if (nil? policy)
      base
      (do
        (put base :view-policy policy)
        (put base :view-config (view-config opts))
        # `:best` is the most enclosed seat so far and `:first-safe` the earliest
        # safe one, so a region with no enclosure still produces an honest
        # fallback instead of nothing.
        (put base :best nil)
        (put base :first-safe nil)
        (put base :counts @{:safe 0 :suitable 0})
        # Budget saved by earlier calls that was too small to score a candidate.
        # Started at 0 and capped at one candidate's cost, so it is a bounded
        # residue rather than unbounded state.
        (put base :credit 0)
        base))))

(defn- advance [search]
  (let [ring (search :ring) dx (search :dx)]
    (if (< dx ring)
      (put search :dx (+ dx 1))
      (if (< ring (search :radius))
        (do (put search :ring (+ ring 1))
            (put search :dx (- (+ ring 1))))
        (put search :status :exhausted)))))

(defn- mark-missing [search w x z]
  (let [[x0 x1 z0 z1] (foot-cells x z)]
    (for bx x0 (+ x1 1)
      (for bz z0 (+ z1 1)
        (let [cx (world/world-to-chunk-coord bx)
              cz (world/world-to-chunk-coord bz)]
          (unless (world/world-get-chunk w cx cz)
            (put (search :requiredchunks) [cx cz] true)))))))

(defn legacy-search-step
  "The original first-safe walk. Unchanged, and what every caller gets by default."
  [search w budget]
  (var count 0)
  (while (and (= (search :status) :searching) (< count budget))
    (let [ring (search :ring)
          dx (search :dx)
          dz (* (if (get search :lower) -1 1) (- ring (math/abs dx)))
          x (+ (search :origin-x) dx)
          z (+ (search :origin-z) dz)]
      (mark-missing search w x z)
      (when-let [position (candidate-safe? w x z (search :sea-level))]
        (put search :position position)
        (put search :status :found))
      (++ count)
      (put search :examined (+ 1 (search :examined)))
      (when (= (search :status) :searching)
        (if (= dz 0)
          (advance search)
          # The lower half of each ring follows its upper half.
          (if (get search :lower)
            (do (put search :lower false) (advance search))
            (put search :lower true))))))
  search)

(defn view-search-step
  ``The ranked walk: score every safe column, keep the best, stop when spent.

  THE BUDGET IS A REAL BOUND AND IT MUST ALWAYS MAKE PROGRESS. A caller that
  slices the search thinner than one candidate used to get nothing back, forever:
  a loop feeding `1` never examined a column and never finished. Silent
  starvation is the worst failure a resumable search can have, because it looks
  exactly like "still working".

  So leftover budget is CARRIED in `:credit` and refunded to the next call. One
  unit per call eventually accumulates to a candidate and the walk advances --
  progress is guaranteed, not merely likely. The carry is capped at one
  candidate's cost: a bounded residue cannot grow without bound, and the cap is
  what keeps the promise "the budget bounds the work THIS call does" true, since
  at most one candidate is ever paid for out of savings.

  A candidate is scored ATOMICALLY, only when the full cost is available. Credit
  never buys part of a score, so the verdict cannot depend on where the slicing
  fell and the result stays slicing-independent.``
  [search w budget]
  (def vc (search :view-config))
  (def cost (view-cost vc))
  # THE CARRY. Savings from earlier calls are folded into this call's budget, then
  # whatever is left is folded back out. The residue is capped at one candidate so
  # it cannot grow without bound, and the cap is also what keeps the promise that
  # a call does at most its budget worth of new work: at most one candidate is
  # ever paid for out of savings.
  (var avail (+ (min (or (search :credit) 0) cost) budget))
  (var spent 0)
  (while (and (= (search :status) :searching)
              (<= (+ spent cost) avail))
    (let [ring (search :ring)
          dx (search :dx)
          dz (* (if (get search :lower) -1 1) (- ring (math/abs dx)))
          x (+ (search :origin-x) dx)
          z (+ (search :origin-z) dz)]
      (mark-missing search w x z)
      (def feet (candidate-safe? w x z (search :sea-level)))
      (when feet
        # The hard gate accepted this column. The count is bumped BEFORE scoring
        # so the two refusals stay distinguishable in the evidence a caller
        # reports: "safe but not rankable" is not "not safe".
        (put search :counts @{:safe (inc ((search :counts) :safe))
                              :suitable ((search :counts) :suitable)})
        (def y (get feet 1))
        # One memo PER CANDIDATE: bounded by the candidate, never by the search,
        # so a resumed search costs exactly what a continuous one does.
        (def memo @{})
        (when-let [cand (view-candidate w x z y vc memo)]
          (record-view search cand)
          (put search :counts @{:safe ((search :counts) :safe)
                                :suitable (inc ((search :counts) :suitable))})))
      (+= spent cost)
      (put search :examined (+ 1 (search :examined)))
      (when (= (search :status) :searching)
        (if (= dz 0)
          (advance search)
          (if (get search :lower)
            (do (put search :lower false) (advance search))
            (put search :lower true))))))
  # What was not spent is carried, capped. Under a budget below one candidate this
  # is the whole of the call's progress: the savings grow until a candidate is
  # affordable, so even a caller feeding 1 unit per call eventually advances.
  (put search :credit (min (- avail spent) cost))
  (when (= (search :status) :exhausted)
    (finish-view search))
  search)

(defn candidate-cost
  ``The budget one candidate costs under this search, for a caller that slices.

  Exposed because the number is a CONTRACT: a caller dividing a frame budget
  across searches needs to know what one unit of progress costs, and a policy that
  silently needed 41 where its caller assumed 1 would starve without a symptom.
  Returns 1 for the legacy policy, where a unit is a whole column.``
  [search]
  (if (nil? (search :view-policy))
    1
    (view-cost (search :view-config))))

(defn search-step
  ``Examine at most budget WORK UNITS; mutate and return the search state.
  Exhausted means the bounded region yielded no dry spawn, not permission to
  fabricate terrain. :requiredchunks lists unloaded footprints encountered.

  The budget's unit depends on the policy, deliberately:

    * `:first-safe` (default) -- one unit is one COLUMN, exactly as before. Every
      existing caller and test keeps its arithmetic.
    * `:enclosed-v1` -- one unit is one COLUMN SAMPLE. Scoring a seat reads its
      ring, its edge cushion and its horizon across every sight radius, so a
      column costs `view-cost` units. Charging by sample is what stops a
      256-column slice from becoming thousands of height lookups inside one
      frame, which is the only reason a ranked search can run in the loader.``
  [search w budget]
  (assert (and (number? budget) (= budget (math/floor budget))
               (<= 0 budget 65536)) "budget must be an integer 0..65536")
  (def policy (search :view-policy))
  (if (nil? policy)
    (legacy-search-step search w budget)
    (view-search-step search w budget)))

(defn- full-budget
  ``Enough budget to finish the search under either policy.

  Under the default it is the exact column count the old caller computed; under
  `:enclosed-v1` each column costs `view-cost`, so the number is scaled rather
  than left short.``
  [search radius]
  (def columns (+ 1 (* 2 radius (+ radius 1))))
  (if (nil? (search :view-policy))
    columns
    (* columns (view-cost (search :view-config)))))

(defn find-dry-spawn
  ``Search all candidate columns now; return a safe position or nil.

  Takes the same options as `search-new`, including :sea-level and, when the
  caller opts in, :view-policy. With `:enclosed-v1` the returned position is the
  best-ENCLOSED safe seat in the bounded region; the yaw that goes with it is on
  the returned search, which is why `view-spawn` exists.

  The return value is unchanged in SHAPE: a position or nil. A caller that wants
  the view asks for `view-spawn`.``
  [w &opt options]
  (let [search (search-new options)
        radius (search :radius)]
    (search-step search w (full-budget search radius))
    (search :position)))

(defn view-spawn
  ``The ranked seat AND its view, or nil when the bounded region has no seat.

  Returns `{:position :yaw :pitch :enclosure? :fallback? :evidence}`. `:enclosure?`
  is never optimistic: a seat with no enclosing terrain comes back with
  `:fallback? true` and the report says so, rather than a yaw nobody measured.``
  [w &opt options]
  (let [search (search-new options)
        radius (search :radius)]
    (search-step search w (full-budget search radius))
    (when-let [pos (search :position)]
      @{:position pos
        :yaw (search :yaw)
        :pitch (search :pitch)
        :enclosure? (truthy? (search :enclosure?))
        :fallback? (truthy? (search :fallback?))
        :evidence (or (search :view-evidence) @{})})))
