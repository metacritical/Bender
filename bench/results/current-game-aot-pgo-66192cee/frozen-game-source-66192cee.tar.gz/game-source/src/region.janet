# TRCR v2 file format: 20-byte header (magic[4]="TRCR", version:u16=2,
# reserved:u16=0, count:u32, height:u32=256, volume:u32=65536), followed
# by count 16-byte index entries (cx:i32, cz:i32, offset:u32, length:u32)
# and contiguous payloads in index order. Each payload is palette-count:u16,
# bits:u8 (1/2/4/8), reserved:u8=0, palette IDs:u8[count], followed by
# 65536 indices packed low-bit-first, ceil(65536*bits/8) bytes. All multibyte
# fields use ffi/read and ffi/write native byte order; supported hosts are
# little-endian. v1's 64-high blocks are incompatible and NEVER auto-padded.
(import ./world)
(import ./palette)

(def magic [84 82 67 82]) # TRCR
(def version 2)
(def stored-height 256)
(def stored-volume 65536)
(def header-bytes 20)
(defn require-tall-world []
  (when (or (not= world/chunk-y stored-height)
            (not= world/chunk-volume stored-volume))
    (error "TRCR v2 requires engine chunk height 256 and volume 65536")))
(def index-bytes 16)
(def max-u32 4294967295)
(def min-i32 -2147483648)
(def max-i32 2147483647)
(def max-chunks 65536)

(defn fail [reason] (error (string "invalid region: " reason)))
(defn valid-i32? [n]
  (and (number? n) (= n (math/floor n)) (<= min-i32 n max-i32)))
(defn copy-bytes [dst offset src]
  (for i 0 (length src) (put dst (+ offset i) (get src i))))
(defn slice-bytes [src offset count]
  (def out (buffer/new-filled count 0))
  (for i 0 count (put out i (get src (+ offset i))))
  out)
(defn read-field [kind data offset size]
  (when (> (+ offset size) (length data)) (fail "truncated field"))
  (ffi/read kind data offset))

# Payload: palette-count:u16, bits:u8, reserved:u8, palette IDs,
# followed by 65,536 indices packed low-bit-first (x varies fastest).
(defn encode-chunk [ch]
  (when (not= world/chunk-volume (length (get ch :blocks)))
    (fail "block count"))
  (def packed (palette/pack (get ch :blocks)))
  (def colors (get packed :palette))
  (def data (get packed :data))
  (when (or (< (length colors) 1) (> (length colors) 256))
    (fail "palette count"))
  (def out (buffer/new-filled (+ 4 (length colors) (length data)) 0))
  (ffi/write :uint16 (length colors) out 0)
  (ffi/write :uint8 (get packed :bits) out 2)
  (copy-bytes out 4 colors)
  (copy-bytes out (+ 4 (length colors)) data)
  out)

(defn decode-chunk [payload]
  (when (< (length payload) 4) (fail "truncated palette"))
  (def count (read-field :uint16 payload 0 2))
  (def bits (read-field :uint8 payload 2 1))
  (when (or (< count 1) (> count 256)
            (not= bits (cond (<= count 2) 1 (<= count 4) 2
                              (<= count 16) 4 true 8))
            (not= (get payload 3) 0)
            (not= (length payload) (+ 4 count (/ (* world/chunk-volume bits) 8))))
    (fail "palette layout"))
  (def colors @[])
  (def seen @{})
  (for i 0 count
    (def id (get payload (+ 4 i)))
    (when (get seen id) (fail "duplicate palette ID"))
    (put seen id true)
    (array/push colors id))
  (def data (slice-bytes payload (+ 4 count) (/ (* world/chunk-volume bits) 8)))
  (def mask (- (blshift 1 bits) 1))
  (def per-byte (/ 8 bits))
  (for i 0 world/chunk-volume
    (def index (band mask (brshift (get data (math/floor (/ i per-byte)))
                                   (* bits (mod i per-byte)))))
    (when (>= index count) (fail "palette index")))
  (palette/unpack @{:palette colors :bits bits :count world/chunk-volume :data data}))

(defn read-file [path]
  (def file (file/open path :rb))
  (when (nil? file) (error (string "cannot open region: " path)))
  (def data (file/read file :all))
  (file/close file)
  (when (nil? data) (fail "file read"))
  data)

# Index validation is shared by load-region and region-info. It checks the
# entire file length but deliberately never decodes the chunk payload bytes.
(defn inspect [bytes]
  (require-tall-world)
  (when (< (length bytes) 12) (fail "truncated header"))
  (for i 0 4
    (when (not= (get bytes i) (get magic i)) (fail "magic")))
  (def file-version (read-field :uint16 bytes 4 2))
  (when (= file-version 1)
    (fail "legacy TRCR v1 uses 64-high chunks; migration required, refusing to pad old world"))
  (when (not= file-version version) (fail "unsupported version"))
  (when (< (length bytes) header-bytes) (fail "truncated header"))
  (when (not= 0 (read-field :uint16 bytes 6 2)) (fail "reserved header"))
  (when (or (not= stored-height (read-field :uint32 bytes 12 4))
            (not= stored-volume (read-field :uint32 bytes 16 4)))
    (fail "chunk height/volume mismatch; refusing incompatible world"))
  (def count (read-field :uint32 bytes 8 4))
  (when (> count max-chunks) (fail "chunk count"))
  (def start (+ header-bytes (* count index-bytes)))
  (when (> start (length bytes)) (fail "truncated index"))
  (def entries @[])
  (def seen @{})
  (var expected start)
  (for i 0 count
    (def entry (+ header-bytes (* i index-bytes)))
    (def cx (read-field :int32 bytes entry 4))
    (def cz (read-field :int32 bytes (+ entry 4) 4))
    (def offset (read-field :uint32 bytes (+ entry 8) 4))
    (def size (read-field :uint32 bytes (+ entry 12) 4))
    (def key [cx cz])
    (when (get seen key) (fail "duplicate chunk coordinates"))
    (put seen key true)
    (when (or (= size 0) (not= offset expected)
              (> offset (length bytes)) (> size (- (length bytes) offset)))
      (fail "payload offset or length"))
    (array/push entries @{:cx cx :cz cz :offset offset :length size})
    (set expected (+ offset size)))
  (when (not= expected (length bytes)) (fail "trailing bytes"))
  entries)

(defn save-region [path chunks]
  (require-tall-world)
  (def count (length chunks))
  (when (> count max-chunks) (fail "chunk count"))
  (def records @[])
  (def seen @{})
  (var total (+ header-bytes (* count index-bytes)))
  (each ch chunks
    (def cx (get ch :cx))
    (def cz (get ch :cz))
    (when (not (and (valid-i32? cx) (valid-i32? cz)))
      (fail "chunk coordinates"))
    (def key [cx cz])
    (when (get seen key) (fail "duplicate chunk coordinates"))
    (put seen key true)
    (def payload (encode-chunk ch))
    (when (> (+ total (length payload)) max-u32) (fail "file too large"))
    (array/push records [ch payload total])
    (set total (+ total (length payload))))
  (def bytes (buffer/new-filled total 0))
  (for i 0 4 (put bytes i (get magic i)))
  (ffi/write :uint16 version bytes 4)
  (ffi/write :uint16 0 bytes 6)
  (ffi/write :uint32 count bytes 8)
  (ffi/write :uint32 stored-height bytes 12)
  (ffi/write :uint32 stored-volume bytes 16)
  (each [i record] (pairs records)
    (def [ch payload offset] record)
    (def pos (+ header-bytes (* i index-bytes)))
    (ffi/write :int32 (get ch :cx) bytes pos)
    (ffi/write :int32 (get ch :cz) bytes (+ pos 4))
    (ffi/write :uint32 offset bytes (+ pos 8))
    (ffi/write :uint32 (length payload) bytes (+ pos 12))
    (copy-bytes bytes offset payload))
  (def file (file/open path :wb))
  (when (nil? file) (error (string "cannot write region: " path)))
  (file/write file bytes)
  (file/close file)
  count)

(defn load-region [path]
  (def bytes (read-file path))
  (def entries (inspect bytes))
  (def chunks @[])
  (each item entries
    (def cx (get item :cx))
    (def cz (get item :cz))
    (def blocks (decode-chunk
                  (slice-bytes bytes (get item :offset) (get item :length))))
    (def ch (world/chunk-new cx cz))
    (put ch :blocks blocks)
    (array/push chunks ch))
  chunks)

(defn save-world [path w]
  (def chunks @[])
  (each [_ ch] (pairs (get w :chunks))
    (when ch (array/push chunks ch)))
  (save-region path chunks))

(defn load-world [path &opt w]
  (def target (if (nil? w) (world/world-new) w))
  # Decode all records before mutating an existing world.
  (def chunks (load-region path))
  (each ch chunks (world/world-put-chunk target ch))
  target)

(defn region-info [path]
  (def bytes (read-file path))
  (def entries (inspect bytes))
  (def coords @[])
  (each item entries
    (array/push coords [(get item :cx) (get item :cz)]))
  @{:version version :height stored-height :volume stored-volume
    :chunk-count (length entries) :bytes (length bytes) :chunks coords})
