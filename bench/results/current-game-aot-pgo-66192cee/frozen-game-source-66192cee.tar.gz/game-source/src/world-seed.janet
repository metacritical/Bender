# Seed input contract for a new world. Inert, pure, no game or GPU dependency.
#
# A seed reaches the engine three ways -- a typed number, an arbitrary string,
# and "surprise me" -- and every one of them must end as the same thing: an
# unsigned 31-bit integer in `0..2147483647`. That range is chosen because the
# procedural generator reduces every seed through `worldgen/i32` and mixes it
# modulo `hash-modulus` (2^31-1), so a wider value would be silently re-wrapped
# by the generator anyway, and a downstream native PRNG can take a 31-bit
# unsigned value without a signed/unsigned question.
#
# Version 1 contract, stable and intentionally narrow:
#
#   * The input is ASCII decimal or arbitrary UTF-8 text. It is trimmed of outer
#     ASCII whitespace first, because a trailing newline from a UI field or a
#     shell argument is not a different seed.
#   * The input is NUMERIC when, after trimming, it is an optional `+`/`-`
#     followed by one or more ASCII digits and nothing else. A leading-zero form
#     is the same number: "00042" and "42" both reduce to 42.
#   * Numeric input is reduced digit by digit modulo 2^31. It is never parsed as
#     a float, so `scan-number`'s precision loss and its handling of huge or
#     exponent forms cannot enter the contract. A negative number wraps in the
#     stable two's-complement way: "-1" is 2^31-1, not -1.
#   * Every other non-blank input is TEXT. Text is hashed over its UTF-8 bytes
#     with CRC-32 from `src/terrain-integrity.janet`, under the domain tag
#     "text-v1:", reduced to 31 bits. The tag keeps a text seed from ever
#     colliding with the numeric reduction of the same characters and lets a
#     future contract change without silently reinterpreting saved seeds.
#   * Unicode is NOT normalized. The bytes as given are the seed, so "é" as
#     U+00E9 and as U+0065 U+0301 are different worlds by explicit design; a
#     normalization form would have to be versioned and stored to be safe.
#   * Blank input is never a seed. It is an explicit error, so the UI must
#     offer "random" as its own affordance instead of an empty field silently
#     meaning something.
#
# Random seeds use `os/cryptorand`, which is a real CSPRNG-backed source in
# bender. An entropy source can be injected for tests and for a caller that
# already holds recorded bytes, in which case the same bytes always produce the
# same seed and the result is reproducible. No global mutable RNG is consulted,
# so a test can never be perturbed by another test.

(import ./terrain-integrity :as integrity)

(def version 1)

# The largest value a seed may take, and the modulus every reduction uses.
(def modulus 2147483648)
(def max-seed 2147483647)

# Domain tag for text seeds. Changing this changes every text world, so it is
# part of the versioned contract and must be bumped together with `version`.
(def text-tag "text-v1:")

(defn- fail [reason] (error (string "invalid seed: " reason)))

(defn- digit? [c] (and (<= 48 c) (<= c 57)))

(defn- sign-or-digit? [c] (or (= c 43) (= c 45) (digit? c)))  # + - 0-9

(defn- numeric-text?
  ``True when `s` is an optional sign followed by one or more ASCII digits.

  Checked byte by byte rather than with a regex or `scan-number`, so a value
  like "1e5", "0x10", " 12 " or "12.0" is TEXT, not a number.``
  [s]
  (def n (length s))
  (if (< n 1)
    false
    (let [start (if (or (= 43 (get s 0)) (= 45 (get s 0))) 1 0)]
      (and (< start n)                       # a bare "+" or "-" is text
           (every? (map (fn [i] (digit? (get s i))) (range start n)))))))

(defn- numeric-value
  ``Reduce a validated numeric string to `0..2147483647`, digit by digit.

  Each step stays below 2^35 (2147483647*10+9), far inside the 2^53 an IEEE
  double represents exactly, so the reduction is exact for any digit count
  without ever forming a float or an unbounded integer.``
  [s]
  (def negative (= 45 (get s 0)))
  (def start (if (or (= 43 (get s 0)) (= 45 (get s 0))) 1 0))
  (var magnitude 0)
  (for i start (length s)
    (set magnitude (% (+ (* magnitude 10) (- (get s i) 48)) modulus)))
  (if negative (% (- modulus magnitude) modulus) magnitude))

(defn- text-value
  ``CRC-32 of the tagged UTF-8 bytes, reduced to 31 bits.

  `integrity/crc32` is CRC-32/ISO-HDLC over bytes and is already shared
  with the region and tile integrity checks, so text seeds reuse one verified
  implementation instead of inventing another hash.``
  [s]
  (% (integrity/crc32 (string text-tag s)) modulus))

(defn parse-seed-input
  ``Interpret a seed as typed by a user.

  Returns a frozen struct:

    {:version 1 :input <original string> :kind :numeric|:text
     :value <int 0..2147483647> :canonical <decimal string>}

  `:input` is the text exactly as supplied, so a UI can display and re-save
  what the user actually typed. `:canonical` is the decimal form of `:value`
  and is what should be persisted and shown as the resolved seed.

  Blank or whitespace-only input raises: blank means "the user asked for a
  random world", which is `random-identity`, not a seed of zero. A caller that
  wants a random world must say so explicitly rather than pass "" and hope.``
  [text]
  (unless (string? text)
    (fail "seed input must be a string"))
  (def trimmed (string/trim text))
  (when (= 0 (length trimmed))
    (fail (string "blank input is not a seed; ask for a random world explicitly")))
  (def kind (if (numeric-text? trimmed) :numeric :text))
  (def value (if (= kind :numeric)
               (numeric-value trimmed)
               (text-value trimmed)))
  (freeze @{:version version
            :input text
            :kind kind
            :value value
            :canonical (string value)}))

(defn seed-of
  "The resolved 31-bit seed of a parsed input."
  [parsed]
  (get parsed :value))

(defn entropy-bytes
  ``Draw 4 bytes of entropy from the operating system.

  bender provides `os/cryptorand`, which is a CSPRNG-backed source; there is no
  insecure global RNG in this module and none is consulted.``
  []
  (os/cryptorand 4))

(defn- seed-from-entropy
  ``Reduce 4 entropy bytes to 31 bits, keeping every bit independent.

  Big-endian assembly of all four bytes, then masked to 31 bits. The mask drops
  the top bit rather than reducing modulo 2^31, which would bias the result by
  making the low values twice as likely.``
  [bytes]
  (unless (or (buffer? bytes) (string? bytes))
    (fail "entropy must be bytes"))
  (unless (= 4 (length bytes))
    (fail "entropy must be exactly 4 bytes"))
  (def packed
    (+ (* (get bytes 0) 16777216)
       (* (get bytes 1) 65536)
       (* (get bytes 2) 256)
       (get bytes 3)))
  # `band` rejects an operand outside the signed 32-bit range, and `packed`
  # reaches 2^32-1, so subtract the top bit instead of masking it away.
  (if (>= packed modulus) (- packed modulus) packed))

(defn random-identity
  ``A random seed, plus the entropy it came from.

  `entropy` may be injected as 4 bytes for a reproducible test or for a caller
  that already recorded the draw; by default the operating system is asked.
  The returned `:entropy` is the exact buffer used, so a world created with a
  random seed can be described down to the bytes that produced it instead of
  merely asserting "random".``
  [&opt entropy]
  (def bytes (or entropy (entropy-bytes)))
  (def value (seed-from-entropy bytes))
  (freeze @{:version version
            :input nil
            :kind :random
            :value value
            :canonical (string value)
            :entropy (string bytes)}))

(defn describe
  "One-line human form of a parsed seed or random identity."
  [parsed]
  (def kind (get parsed :kind))
  (def value (get parsed :value))
  (case kind
    :numeric (string value " (numeric " (string/format "%q" (get parsed :input)) ")")
    :text (string value " (text " (string/format "%q" (get parsed :input)) ")")
    :random (string value " (random)")
    (fail "unknown seed kind")))
