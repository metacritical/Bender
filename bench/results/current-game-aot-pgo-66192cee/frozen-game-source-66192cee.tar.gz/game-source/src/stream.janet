# Trinecraft — chunk streaming policy.
#
# Which chunks should exist, which should be dropped, and in what order the
# work should happen. Deliberately free of rendering and world mutation: the
# caller owns GPU lifetime and chunk generation, this module only decides.
# That split is what lets the policy be tested headless, and it is the part
# most likely to be wrong -- an off-by-one in the radius silently costs a ring
# of chunks every frame.
#
# Ordering matters as much as membership. Chunks are loaded nearest-first so
# the terrain closing in around the player fills before the horizon, and
# unloaded with hysteresis so a player walking back and forth across a chunk
# boundary does not thrash the same chunk in and out.

(import ./world :as world)

(defn chunk-coord-of
  "Chunk coordinate containing a world X or Z."
  [wx]
  (math/floor (/ wx world/chunk-x)))

(defn chunk-distance2
  ``Squared chunk-space distance. Squared because it is only ever compared,
  and a square root per chunk per frame buys nothing.``
  [ax az bx bz]
  (def dx (- ax bx))
  (def dz (- az bz))
  (+ (* dx dx) (* dz dz)))

(defn in-radius?
  ``Circular, not square. A square region loads corner chunks that are
  1.41x further away than the chunks directly ahead of the player, which is
  wasted work in the direction nobody is looking.``
  [cx cz px pz radius]
  (<= (chunk-distance2 cx cz px pz) (* radius radius)))

(defn chunks-in-radius
  ``Every chunk coordinate within `radius` of (px,pz), nearest first.

  Nearest-first is the whole point: under a per-frame work budget only the
  first few entries get serviced, so the order decides what the player sees
  appear next.``
  [px pz radius]
  (def out @[])
  (for dz (- radius) (+ radius 1)
    (for dx (- radius) (+ radius 1)
      (def cx (+ px dx))
      (def cz (+ pz dz))
      (when (in-radius? cx cz px pz radius)
        (array/push out @[cx cz (chunk-distance2 cx cz px pz)]))))
  (sort-by |($ 2) out)
  out)

(defn missing-chunks
  ``Chunks that should exist but do not, nearest first. `has?` is a predicate
  on (cx cz) so this module never needs to know how the world stores them.``
  [px pz radius has?]
  (def out @[])
  (each entry (chunks-in-radius px pz radius)
    (unless (has? (entry 0) (entry 1))
      (array/push out entry)))
  out)

(defn surplus-chunks
  ``Loaded chunks far enough out to drop.

  The hysteresis margin is not decoration. Unloading at exactly `radius`
  means a player stepping one block across a chunk boundary unloads a ring
  and immediately reloads it, paying full worldgen and meshing cost for no
  visible change. Dropping only beyond radius+margin makes that oscillation
  free.``
  [px pz radius margin loaded-keys]
  (def limit (+ radius margin))
  (def out @[])
  (each key loaded-keys
    (def cx (key 0))
    (def cz (key 1))
    (unless (in-radius? cx cz px pz limit)
      (array/push out @[cx cz (chunk-distance2 cx cz px pz)])))
  # Furthest first, so if the budget only allows a few unloads per frame the
  # most useless chunks go first.
  (sort-by |(- ($ 2)) out)
  out)

(defn seam-neighbours
  ``The four chunks whose meshes change when (cx,cz) appears or vanishes.

  A chunk's mesh depends on its neighbours' blocks at the shared face, so a
  newly streamed chunk invalidates the four around it. Skipping this leaves a
  wall of stale faces at every seam where a chunk arrived -- visible as solid
  sheets hanging in the air between chunks.``
  [cx cz]
  @[@[(- cx 1) cz] @[(+ cx 1) cz] @[cx (- cz 1)] @[cx (+ cz 1)]])

(defn budget-new
  ``A per-frame work budget measured in milliseconds, not chunk count.

  Counting chunks is the obvious approach and the wrong one: worldgen and
  meshing vary several-fold in cost between an empty chunk and a dense one,
  so a fixed count produces exactly the frame spikes streaming is meant to
  avoid. Time is what the frame actually has.``
  [ms]
  @{:ms ms :start 0 :spent 0 :items 0})

(defn budget-begin [b]
  (set (b :start) (os/clock))
  (set (b :spent) 0)
  (set (b :items) 0)
  b)

(defn budget-elapsed [b]
  (* 1000 (- (os/clock) (b :start))))

(defn budget-exhausted? [b]
  (>= (budget-elapsed b) (b :ms)))

(defn budget-remaining [b]
  (- (b :ms) (budget-elapsed b)))

(defn budget-allows?
  ``Is there room for a job expected to cost `estimate` ms?

  Checking only whether the budget is already spent is not enough. A work
  item cannot be preempted once begun, so starting a 9 ms chunk with 0.5 ms
  left overshoots by the entire item -- which is how a 6 ms budget produced
  27 ms frames. Refusing to start work that will not fit is what actually
  bounds the frame.

  But the first job of a frame is ALWAYS admitted, even when its estimate
  exceeds the whole budget. Without that rule any job costing more than the
  budget starves permanently: a 7.3 ms chunk under a 6 ms budget is refused
  every frame forever, and streaming deadlocks after the first chunk. This
  guarantees forward progress while still bounding overshoot to a single
  item -- the budget shapes throughput, it must never halt it.``
  [b estimate]
  (or (zero? (b :items))
      (>= (budget-remaining b) estimate)))

(defn ema-new
  ``Exponential moving average of a job's cost, used to predict the next one.

  A fixed estimate cannot work: worldgen and meshing vary several-fold
  between an empty chunk and a dense one, and differ again between machines
  and between interpreted and native builds. Measuring is the only estimate
  that stays correct.``
  [initial &opt alpha]
  @{:value initial :alpha (or alpha 0.25)})

(defn ema-update [e sample]
  (set (e :value) (+ (* (- 1 (e :alpha)) (e :value)) (* (e :alpha) sample)))
  (e :value))

(defn budget-note [b]
  (set (b :spent) (* 1000 (- (os/clock) (b :start))))
  (++ (b :items))
  b)
