# Trinecraft — optional scenic climate attachment. One artifact, one answer, no
# policy.
#
# WHAT THIS MODULE OWNS. Given a bounded scenic cache opened through
# `terrain-cache/cache-new` (so its `manifest.janet` is already bound to
# `provenance.json` by that file's exact size and CRC-32), this module answers one
# question: does this artifact carry a climate container, and if so what exactly
# does it say? When it does, it loads those bytes once, hands them to
# `climate-tile/read` — the single presence/shape/length/NaN authority — and
# attaches the result to the cache through `terrain-cache/attach-climate!` under an
# EXPLICIT origin and scale.
#
# WHAT IT DOES NOT OWN, ON PURPOSE.
#
#   * No validation schema of its own. `world-catalog/climate-metadata` and the
#     block schema behind it are the authority on what a climate block may say, and
#     `world-catalog/check-climate` is the authority on whether the bytes beside
#     that block are the bytes it describes. This module calls them; it does not
#     re-implement one field of either, and it adds no second JSON reader.
#   * No decoding of its own. `climate-tile` owns the float32 wire format, the
#     channel contract, and the refusal of NaN and infinity.
#   * No projection arithmetic of its own. `terrain-cache/attach-climate!` owns the
#     coverage check and the sampling maths; this module only supplies the two
#     numbers that function refuses to guess.
#   * No surface policy. Nothing here classifies a biome, chooses a block, or is
#     reachable from any generator. Absence of climate changes nothing at all.
#
# THE THREE BINDINGS, AND WHO CHECKS WHICH. Climate bytes are trustworthy only when
# three links hold, and this module is deliberately explicit about which link it
# verifies itself:
#
#   1. manifest.janet -> provenance.json      (byte length + CRC-32)
#         VERIFIED BY `terrain-cache/cache-new`, before this module is reached.
#   2. provenance.json -> climate.f32         (declared length + CRC-32 + SHA-256)
#         VERIFIED BY `world-catalog/check-climate`, which also refuses BOTH
#         directions of a presence mismatch.
#   3. climate.f32 -> the buffer handed to the reader
#         VERIFIED HERE, on the exact bytes about to be decoded, so link three is
#         checked on this read rather than inherited from a read that already
#         finished. The window between "verified on disk" and "decoded in memory"
#         is one read, and it is never widened to two.
#
# WHY THE PRODUCER'S `scale` IS NOT THE ATTACHMENT SCALE. This is the one place a
# reader can silently misaddress every sample, so it is stated rather than assumed:
#
#   * `projection.scale` in the record divides `source-grid` into `artifact-grid`
#     (`tools/scenic_terrain.py` `climate_projection`). It is the SOURCE-TO-ARTIFACT
#     upsample ratio. It is not a count of world cells.
#   * The container itself is emitted at the ARTIFACT grid — one float32 sample per
#     map pixel — and the catalogue additionally requires the declared shape to
#     equal this map's own pixel extent (`world-catalog/climate-shape-for`).
#   * So the number `attach-climate!` needs is "how many world cells one climate
#     cell spans", and it follows from the MAP EXTENT and the CLIMATE GRID. That is
#     `world-scale` below: derived, required to be one exact integer on both axes,
#     and then re-checked by `attach-climate!` against the map extent.
#
# A record with `scale: 4` over a quarter-size source grid is therefore perfectly
# loadable, and every sample still lands where the map says it does: the producer's
# ratio is reported as `:producer-scale` beside the world `:scale`, so a caller sees
# both numbers instead of believing one is the other.
#
# UNITS AND CALIBRATION STAY HONEST. `:unit-basis` is `climate-tile`'s
# `:source-derived` and `:calibrated` is copied from the record (FALSE today).
# Neither is upgraded by anything here: this module reads data, and reading does not
# measure it.
#
# NO DISCOVERY. The payload path is `<dir>/climate.f32` — one fixed name taken from
# `world-catalog/climate-name`. There is no `os/dir`, no glob, no second candidate
# filename and no sidecar lookup. A cache with climate data lying beside it under any
# other name opens as a cache without climate, which is the correct reading of
# "nobody told me what that file is".
#
# A LEGACY CACHE ANSWERS `:unavailable`, NOT AN ERROR. A cache with no `:bounds`
# cannot express a map extent, so no grid can be checked against it and nothing is
# attached. That is absence, not failure, and reporting absence is this module's
# whole job in that case: it touches not one field of the cache.

(import ./world-catalog :as catalog)
(import ./climate-tile :as climate)
(import ./terrain-cache :as terrain)
(import ./terrain-integrity :as integrity)

(def version 1)

#: The one optional seventh artifact entry, taken from the catalogue rather than
#: retyped, so the reader and the publisher cannot drift to different names.
(def climate-name catalog/climate-name)

(defn- fail [why] (error (string "scenic climate: " why)))
(defn- obj? [x] (or (table? x) (struct? x)))
(defn- integer? [n] (and (number? n) (= n (math/floor n))))

(defn payload-path
  "The EXACT path of this artifact's climate container: `<dir>/climate.f32`."
  [dir]
  (unless (and (string? dir) (pos? (length dir)))
    (fail "artifact directory must be a non-empty path string"))
  (string dir "/" climate-name))

(defn payload-present?
  ``Is anything occupying the container's exact path?

  Presence only, and never followed: this answers whether the named entry exists,
  not whether it is usable. A symlink or a directory answers `true` here and is
  refused later by `world-catalog/check-climate`, which is the authority requiring
  a regular, bounded, unlinked file. Deciding presence any other way here would
  turn a linked payload into a silently missing one — a refusal disguised as
  absence, which is exactly the confusion this engine refuses to ship.``
  [dir]
  (not (nil? (os/lstat (payload-path dir)))))

(defn- read-bounded
  ``At most `limit` bytes of a regular, unlinked file, or raise.

  A counted `file/read` rather than `:all`: the directory is written by another
  process, so a path can be a FIFO or a runaway file, and reading it whole would
  allocate far more than the length check that follows could then refuse.``
  [path limit what]
  (def st (os/lstat path))
  (unless (and st (= :file (get st :mode)))
    (fail (string what " must be a regular, unlinked file: " path)))
  (when (> (get st :size) limit)
    (fail (string what " is " (get st :size) " bytes, above the " limit
                  "-byte bound this reader accepts")))
  (def f (file/open path :rb))
  (unless f (fail (string "cannot open " what ": " path)))
  (def bytes
    (try
      (do (def b (file/read f (+ 1 limit))) (file/close f) b)
      ([e] (try (file/close f) ([_] nil)) (error e))))
  (unless bytes (fail (string what " is unreadable: " path)))
  (when (> (length bytes) limit)
    (fail (string what " is larger than the " limit "-byte bound this reader accepts")))
  bytes)

(defn- read-payload
  "Exactly `expected` bytes of the container, or raise."
  [path expected]
  (def bytes (read-bounded path expected "climate payload"))
  (unless (= expected (length bytes))
    (fail (string "climate payload is " (length bytes) " bytes, the declared "
                  "contract binds " expected
                  "; a short payload is a different file, not a readable one")))
  bytes)

(defn world-scale
  ``How many world cells one climate cell spans, for this map and this grid.

  DERIVED, never read out of the record's `projection.scale` (see the header): a
  map covers `16 * chunks` world cells per axis and the climate grid covers `grid`
  cells per axis, so their ratio is the only value under which the grid covers the
  map. `terrain-cache/attach-climate!` re-checks the same coverage, so this is the
  supplied number and that function is the authority.

  Refuses a non-integer ratio on EITHER axis and refuses two different integer
  ratios, because a grid needing two scales is not a projection this engine can
  express — and closing a remainder would mean inventing samples the producer never
  emitted.``
  [bounds grid]
  (unless (and (or (array? bounds) (tuple? bounds))
               (= 4 (length bounds))
               (every? (map integer? bounds)))
    (fail "bounds must be four integers [cx0 cz0 cx1 cz1]"))
  (unless (and (or (array? grid) (tuple? grid))
               (= 2 (length grid))
               (every? (map (fn [n] (and (integer? n) (pos? n))) grid)))
    (fail "climate grid must be two positive integers (height width)"))
  (def chunks-x (+ 1 (- (get bounds 2) (get bounds 0))))
  (def chunks-z (+ 1 (- (get bounds 3) (get bounds 1))))
  (unless (and (pos? chunks-x) (pos? chunks-z))
    (fail (string "bounds " (string (tuple ;bounds)) " do not describe a map")))
  (def cells-x (* chunks-x terrain/tile-size))
  (def cells-z (* chunks-z terrain/tile-size))
  (def gh (get grid 0))
  (def gw (get grid 1))
  (when (> gw cells-x)
    (fail (string "climate grid is " gw " cells wide, wider than this map's "
                  cells-x " world cells")))
  (when (> gh cells-z)
    (fail (string "climate grid is " gh " cells tall, taller than this map's "
                  cells-z " world cells")))
  (def sx (div cells-x gw))
  (def sz (div cells-z gh))
  (unless (= cells-x (* sx gw))
    (fail (string "climate grid width " gw " does not divide this map's " cells-x
                  " world cells; the grid must cover the map exactly and a "
                  "remainder is refused rather than resampled")))
  (unless (= cells-z (* sz gh))
    (fail (string "climate grid height " gh " does not divide this map's " cells-z
                  " world cells; the grid must cover the map exactly and a "
                  "remainder is refused rather than resampled")))
  (unless (= sx sz)
    (fail (string "climate grid " gw "x" gh " needs scale " sx " across and " sz
                  " down; one attachment carries one integer scale")))
  sx)

(defn present?
  ``Does this artifact CARRY a verified, decodable climate container?

  True for `attach!` and for `info-of` alike: it answers about the artifact, not
  about the cache. Use `attached?` when what you need to know is whether the data
  was actually adopted by a cache.``
  [info]
  (= :present (get info :status)))

(defn attached?
  "Did `attach!` actually attach a verified payload to the cache?"
  [info]
  (= true (get info :attached)))

(defn unavailable?
  "Is this the answer for an artifact with no usable climate container?"
  [info]
  (= :unavailable (get info :status)))

(defn- frozen-units
  "The reader's own channel-to-unit vocabulary, frozen so no caller can edit it."
  []
  (freeze (struct ;(mapcat (fn [channel] [channel (climate/channel-unit channel)])
                          climate/channels))))

(defn- declaration-of
  ``The verified climate declaration behind the contract, from the same bytes.

  `world-catalog/climate-metadata` returns the payload contract but not the
  projection or the `calibrated` flag, so those leaves are read through
  `world-catalog/climate-declaration` — the catalogue's own accessor over the same
  record. This adds no schema and no reader: it only reaches fields the catalogue
  has already validated.``
  [provenance]
  (def declared (catalog/climate-declaration provenance true))
  (unless (table? declared)
    (fail "a verified climate payload has no readable declaration"))
  declared)

(defn- absent [reason path]
  @{:status :unavailable :reason reason :attached false :path path})

(defn- inspect
  ``Inspect the artifact, and when it carries climate decode it exactly once.

  Returns `[info decoded]`. `info` is a MUTABLE table that the public functions
  freeze before returning, and it holds no buffer and no reference into the decoded
  result. `decoded` is `nil` when the producer wrote no climate, so in that case
  nothing is read, decoded or attached.``
  [cache]
  (unless (obj? cache) (fail "climate attachment needs a cache"))
  (def dir (get cache :dir))
  (def path (payload-path dir))
  (def bounds (get cache :bounds))
  (if (nil? bounds)
    [ (absent :unbounded path) nil ]
    (let [payload? (payload-present? dir)
          # The catalogue's own contract check: presence in BOTH directions, the
          # declared byte length, CRC-32 and SHA-256, and a block that describes
          # THIS map. nil means the shipped six-entry artifact, which is not an
          # error anywhere in this engine.
          contract (catalog/check-climate dir bounds payload?)]
      (if (nil? contract)
        [ (absent :absent path) nil ]
        (let [provenance (read-bounded (string dir "/provenance.json")
                                       catalog/max-learned-aux-bytes
                                       "provenance.json")
              declared (declaration-of provenance)
              projection (get declared "projection")
              source-grid (get projection "source-grid")
              declared-shape (get contract :shape)
              grid [(get declared-shape 0) (get declared-shape 1)]
              artifact-grid (get projection "artifact-grid")
              origin (get projection "origin")]
          # The scale derivation is sound only because the climate grid IS this
          # artifact's pixel grid; `world-catalog/climate-block` pins that, and the
          # assertion keeps the reason next to its use rather than in a comment a
          # future edit can drift away from.
          (unless (and (= (get grid 0) (get artifact-grid 0))
                       (= (get grid 1) (get artifact-grid 1)))
            (fail (string "climate grid " (get grid 0) "x" (get grid 1)
                          " is not this artifact's pixel grid "
                          (get artifact-grid 0) "x" (get artifact-grid 1)
                          "; a world scale cannot be derived from it")))
          (def scale (world-scale bounds grid))
          (def expected (get contract :bytes))
          (def bytes (read-payload path expected))
          # Link three of the header's chain, on the exact bytes about to be
          # decoded. A mismatch here means the file changed under us between the
          # catalogue's verification and this read.
          (unless (= (get contract :crc32) (integrity/crc32 bytes))
            (fail (string "climate payload CRC-32 changed between verification and "
                          "decoding; refusing to decode bytes nobody can vouch for")))
          # `has_climate true` is not a guess: the payload exists, the record
          # declares it, and both directions were checked by `check-climate`. The
          # reader is the single presence authority, and its answer is verified
          # below rather than assumed.
          (def decoded (climate/read bytes (freeze [ (get grid 0) (get grid 1)
                                                     climate/channel-count])
                                     (freeze @{:has_climate true})))
          (unless (climate/present? decoded)
            (fail "a declared, verified payload did not decode as present"))
          [ @{:status :present
              :attached false          # set by `attach!`, never claimed early
              :path path
              :shape (freeze [(get grid 0) (get grid 1) climate/channel-count])
              :channels climate/channels
              :units (frozen-units)
              :unit-basis climate/unit-basis
              :units-measured? (climate/units-measured?)
              :basis (get declared "basis")
              :calibrated (get declared "calibrated")
              :bytes expected
              :crc32 (get contract :crc32)
              :sha256 (get contract :sha256)
              :origin (freeze [(get origin 0) (get origin 1)])
              :scale scale
              # The producer's SOURCE->ARTIFACT ratio, reported for traceability
              # and never used as a world scale (see the header).
              :producer-scale (get projection "scale")
              :producer-source-grid (freeze [(get source-grid 0) (get source-grid 1)])
              :producer-artifact-grid (freeze [(get artifact-grid 0)
                                               (get artifact-grid 1)])}
            decoded])))))

(defn attach!
  ``Attach this artifact's optional climate to `cache`; returns frozen info.

  The one entry point. It loads `climate.f32` ONLY when the artifact declares it,
  binds it to the record through the catalogue's own checks, re-verifies the bytes
  it is about to decode, decodes them with `climate-tile/read`, and attaches the
  result under the origin and derived scale. It returns a frozen info record and
  nothing else: no buffer, no decoded table, no mutable alias to either, so a caller
  cannot corrupt what the cache will sample with.

  THREE OUTCOMES, and only one of them touches the cache:

    * `:present` — attached, `:attached true`, describing exactly what was attached
      (shape, units, digests, origin, scale, producer's own ratio).
    * `:unavailable` `:reason :absent` — the shipped six-entry artifact. Heights,
      tiles, manifest and any saved identity are untouched.
    * `:unavailable` `:reason :unbounded` — a legacy cache, which declares no map
      extent for a grid to be checked against. Also untouched.

  A payload that fails ANY check raises instead of degrading to `:absent`, so a
  corrupt artifact can never be mistaken for a climate-less one.``
  [cache]
  (def [info decoded] (inspect cache))
  (when (climate/present? decoded)
    (put info :attached true)
    # `attach-climate!` re-checks coverage against the map extent and copies the
    # reader's result into an owned, immutable equivalent. Nothing bypasses it.
    (terrain/attach-climate! cache decoded (get info :origin) (get info :scale)))
  (freeze info))

(defn info-of
  ``A frozen DESCRIPTION of what this artifact carries, without attaching it.

  Same outcomes and fields as `attach!`, but the cache is never mutated: useful for
  a loading screen that wants to say "climate: 512x512, source-derived,
  uncalibrated" before a session commits to using it. It still verifies and still
  decodes — a description nobody verified would be a guess — so prefer `attach!`
  when the data is going to be used anyway.``
  [cache]
  (freeze (get (inspect cache) 0)))

(defn sampler
  ``A read-only sampling callback for this cache: `(fn [wx wz] -> answer)`.

  The callback delegates to `terrain-cache/climate-at-world`, so a caller sees that
  module's vocabulary unchanged — `:sampled` inside the grid, and `:unavailable`
  with `:not-attached`, `:absent` or `:outside-map` otherwise. It never clamps, never
  substitutes a neighbour, and never invents a value.

  Call `attach!` first: until then the cache answers `:not-attached`, which is the
  honest answer for climate that has been inspected but not adopted. The callback is
  deliberately NOT stored on the cache — it holds no state and closes over nothing
  but the cache itself, so there is no second place climate can live.``
  [cache]
  (unless (obj? cache) (fail "sampler needs a cache"))
  (fn [wx wz] (terrain/climate-at-world cache wx wz)))

(defn load!
  ``The ONE call a session makes: attach if there is climate, then hand back a
  status word and a sampler.

  This adds no verification of its own — it is `attach!` plus a status vocabulary a
  caller can branch on without reading five fields, so wiring a session does not
  require understanding the three-binding chain first:

      :attached   climate was verified, decoded and attached; the sampler answers
                  `:sampled` inside the map.
      :absent     the shipped six-entry artifact. Nothing was attached; the sampler
                  answers `:unavailable :not-attached`, and heights are untouched.
      :legacy     an unbounded cache, which declares no map extent to check a grid
                  against. Also nothing attached, also untouched.

  Returns `{:status <word> :sampler <fn> :info <frozen>}`. The sampler is ALWAYS
  present, including for `:absent` and `:legacy`, so a caller wires one function and
  never needs a nil check: an absent climate and an unattached one are answers, not
  errors. `:info` is `attach!`'s frozen record, so a UI can still say why.

  There is NO automatic policy here and nothing reads this yet. Enabling
  climate-driven surfaces in `main.janet` is a separate, versioned-profile decision
  that must not change an existing world's saved result.``
  [cache]
  (def info (attach! cache))
  (def status
    (cond
      (attached? info) :attached
      (= :unbounded (get info :reason)) :legacy
      :else :absent))
  {:status status :info info :sampler (sampler cache)})
