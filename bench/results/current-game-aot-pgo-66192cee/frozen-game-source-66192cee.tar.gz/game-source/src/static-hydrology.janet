# Trinecraft -- static hydrology analysis over a finite height grid.
#
# This module ANALYSES heights. It never produces them, never writes blocks, and
# never claims to model water. Given a finite grid of integer voxel heights it
# answers a fixed set of geometric questions -- which way each cell drains, how
# much of the grid drains through it, and where drainage collects -- and returns
# them as one inert, self-owned plan.
#
# Three rules shape everything below.
#
#   * THE HEIGHTS ARE THE CALLER'S. Nothing here invents a column, smooths one, or
#     perturbs a seed. A learned elevation field and a procedural one are analysed
#     identically, and the plan records that it is an AUTHORED STATIC ANALYSIS
#     rather than a model output. Heights are integer voxels because the engine's
#     height field is integer; a fractional height is refused rather than rounded,
#     since rounding would silently move the waterline.
#
#   * NO ITERATIVE FLOW. Drainage is one strict downhill step, chosen once. There
#     is no relaxation, no time step, no fill-and-recompute loop, and therefore no
#     convergence question. Where water would have to rise to escape, this module
#     says so instead of simulating the rise. A pit is reported as a BASIN CELL,
#     never as a filled lake: this analysis does not know how deep a lake would be
#     and must not pretend it does.
#
#   * STABLE AND DETERMINISTIC. Ties resolve by a fixed direction order, never by
#     floating point, and accumulation is computed in a total order over integer
#     heights. The same grid yields identical plans on every run and machine.

(def version 1)

# 8-way directions in a FIXED order. The order IS the tie-break: the first
# strictly-lower neighbour wins, so two runs cannot disagree about which way a
# symmetric cell drains.
(def directions [[1 0] [1 1] [0 1] [-1 1] [-1 0] [-1 -1] [0 -1] [1 -1]])

(def max-cells (* 512 512))   # bounded: the largest grid this analyses
(def default-river-threshold 64)

# Sink kinds, kept DISTINCT. All four mean "does not drain to a cell", but they
# say different things about the terrain, and collapsing them into one sentinel
# makes a pit indistinguishable from a hole in the data -- the exact confusion
# this module exists to avoid.
(def outlet-kinds [:outflow :basin :flat :void])

(defn index-of
  "Flat index of `(x,z)` in an x-fastest grid, matching the height tile layout."
  [cols x z]
  (+ x (* cols z)))

(defn- cell-count [heights rows cols]
  (assert (and (number? rows) (number? cols) (pos? rows) (pos? cols))
          "grid dimensions must be positive integers")
  (assert (and (= rows (math/floor rows)) (= cols (math/floor cols)))
          "grid dimensions must be integers")
  (def n (* rows cols))
  (assert (<= n max-cells)
          (string "grid exceeds the analysed maximum of " max-cells " cells"))
  (assert (= n (length heights))
          (string "heights must hold exactly " n " cells for a " rows "x" cols
                  " grid, got " (length heights)))
  n)

(defn- check-heights [heights]
  (for i 0 (length heights)
    (def h (get heights i))
    (unless (or (nil? h) (and (number? h) (= h (math/floor h))))
      (error (string "height at cell " i
                     " must be an integer voxel height or nil for no data")))))

(defn- receiver
  ``The flat index `(x,z)` drains into, or a sink keyword.

  `:outflow` on the grid edge -- the neighbour is outside the analysed area, and
  water leaving the area is the only assumption made about it. `:basin` when every
  in-grid neighbour is strictly higher, so a strict step cannot leave. `:flat`
  when some neighbour is EQUAL and none is lower: a plateau endpoint is not a pit,
  and calling it one would invent water.``
  [heights rows cols x z]
  (def h (get heights (index-of cols x z)))
  (if (nil? h)
    :void
    (do
      (var best nil)
      (var equal false)
      (each [dx dz] directions
        (def nx (+ x dx))
        (def nz (+ z dz))
        # Bounds first: an equal neighbour is evidence of a plateau, an off-grid
        # neighbour is not.
        (when (and (<= 0 nx) (< nx cols) (<= 0 nz) (< nz rows))
          (def nh (get heights (index-of cols nx nz)))
          (cond
            (nil? nh) nil
            (< nh h) (when (or (nil? best) (< nh (get heights best)))
                       (set best (index-of cols nx nz)))
            (= nh h) (set equal true))))
      (cond
        best best
        (or (= 0 x) (= 0 z) (= (dec cols) x) (= (dec rows) z)) :outflow
        equal :flat
        :basin))))

(defn outlet-kind-at
  "The sink keyword at `(x,z)`, or nil when the cell drains to another cell."
  [plan x z]
  (get (plan :outlet-kind) (index-of (plan :cols) x z)))

(defn downstream-at
  "Flat index `(x,z)` drains into, or nil when it is a sink."
  [plan x z]
  (get (plan :downstream) (index-of (plan :cols) x z)))

(defn coords-at
  ``World coordinates of `(x,z)`, offset by the plan's origin.

  The origin is OUTPUT MAPPING ONLY: a grid may describe a map whose first column
  is at a negative world coordinate, and the analysis is identical either way. It
  never participates in drainage.``
  [plan x z]
  (def o (plan :origin))
  [(+ (get o 0) x) (+ (get o 1) z)])

(defn direction-to
  ``Where `(x,z)` drains, as `[rx rz]` in GRID coordinates, or a sink keyword.

  Sink keywords are the honest part of a static analysis: `:outflow` leaves the
  analysed area, `:basin` cannot leave under a strict step, `:flat` sits on a
  plateau this analysis does not resolve, `:void` had no height data.``
  [plan x z]
  (def target (downstream-at plan x z))
  (if (number? target)
    [(mod target (plan :cols)) (math/floor (/ target (plan :cols)))]
    (outlet-kind-at plan x z)))

(defn accumulation-at
  "How many cells drain through `(x,z)`, itself included."
  [plan x z]
  (get (plan :accumulation) (index-of (plan :cols) x z)))

(defn river?
  ``Is `(x,z)` a river cell? Always a boolean.

  Reads the mask rather than comparing an accumulation COUNT, so the answer can
  never be a number. Janet treats 0 as truthy, so a caller given a count would read
  "river" out of a zero if it forgot to compare.``
  [plan x z]
  (= 1 (get (plan :river-mask) (index-of (plan :cols) x z))))

(defn analyze
  ``Analyse a finite height grid and return one inert, owned drainage plan.

  `heights` is x-fastest (`index = x + cols*z`), matching the height tile layout
  the engine already uses, with integer voxel heights and `nil` for a cell with no
  data. The grid must be FINITE and bounded; a partly-specified area would produce
  edge effects that look like findings.

  `opts` may carry `:river-threshold` and `:origin [ox oz]`. The origin only
  offsets the coordinates `coords-at` reports -- it never changes the analysis,
  the drainage, or any seed.

  Returns a NEW table owning its own arrays. Nothing is shared: two plans are
  independent, and mutating one cannot affect another. `:outlet-kind` gives the
  sink keyword for every cell (nil where it drains), so a caller can classify the
  grid without a second pass or a second array.

  Accumulation is computed in ONE topological pass over cells sorted by height
  descending, ties broken by index. Because a receiver is always strictly lower,
  that order is a valid reverse topological order: no recursion, no fixed point.``
  [heights rows cols &opt opts]
  (def o (or opts {}))
  (def n (cell-count heights rows cols))
  (check-heights heights)
  # SNAPSHOT the caller's heights ONCE, then read only the snapshot. Without this
  # the analysis re-reads the caller's array throughout, so a caller that mutated
  # its own input mid-call -- or kept one array behind two plans and edited it
  # between them -- could make one analysis see two different grids. The copy is
  # also what guarantees the RESULT cannot alias the input: nothing downstream can
  # reach the caller's storage, so no plan can be corrupted by a later edit to the
  # grid it came from. Copied AFTER validation so a rejected grid costs no work,
  # and copied UNCONDITIONALLY -- special-casing buffers would leave exactly the
  # alias this exists to remove.
  (def heights
    (do
      (def copy (array/new-filled n nil))
      (for i 0 n (put copy i (get heights i)))
      copy))
  (def threshold (or (get o :river-threshold) default-river-threshold))
  (assert (and (number? threshold) (= threshold (math/floor threshold))
               (pos? threshold))
          "river threshold must be a positive integer")
  (def origin (or (get o :origin) [0 0]))
  (assert (and (indexed? origin) (= 2 (length origin))
               (number? (get origin 0)) (number? (get origin 1)))
          "origin must be a pair of numbers")
  # Plain arrays, NOT buffers: a buffer element is one byte, so any grid larger
  # than 256 cells would silently truncate an index and route water to the wrong
  # cell.
  (def downstream (array/new-filled n nil))
  (def outlet-kind (array/new-filled n nil))
  (def counts @{:outflow 0 :basin 0 :flat 0 :void 0})
  (for z 0 rows
    (for x 0 cols
      (def r (receiver heights rows cols x z))
      (def i (index-of cols x z))
      (if (number? r)
        (put downstream i r)
        (do (put outlet-kind i r)
            (put counts r (inc (get counts r 0)))))))
  # Total order over integer heights, descending, ties by flat index. Sorting a
  # tuple compares numerically then by index, so this is a true total order and
  # does not rely on the sort being stable.
  (def order (sort-by (fn [i] [(- (get heights i)) i])
                      (filter |(number? (get heights $)) (range n))))
  # Accumulation starts at 1 for a cell WITH DATA and 0 for a void cell: there is
  # no column there to carry water, so counting it would credit a hole with flow
  # it cannot contribute. Upstream cells then add themselves into their receiver.
  (def acc (array/new-filled n 0))
  (for i 0 n
    (when (number? (get heights i)) (put acc i 1)))
  (each i order
    (def r (get downstream i))
    (when (number? r)
      (put acc r (+ (get acc r) (get acc i)))))
  # `:river-mask` is a 0/1 VECTOR, not a count, because Janet treats 0 as truthy.
  # A caller testing `(some |(> $ threshold) accumulation)` or an index of a count
  # would read "river here" from a zero. The mask is unambiguous, and `:rivers`
  # stays a count for reporting.
  # A river cell is one that collects at least the threshold AND has somewhere to
  # send it. A flat, basin or void cell has no downstream receiver, so it is not a
  # channel no matter how much it accumulates: calling a plateau endpoint a river
  # would put water on ground the analysis explicitly left unrouted.
  (def river-mask (array/new-filled n 0))
  (for i 0 n
    (when (and (number? (get downstream i))
               (>= (get acc i) threshold))
      (put river-mask i 1)))
  (def rivers (length (filter |(= 1 $) river-mask)))
  @{:kind :authored-static-analysis :version version
    :units :voxels :rows rows :cols cols :origin [;origin]
    :downstream downstream :outlet-kind outlet-kind :accumulation acc
    :river-mask river-mask
    :cells counts :river-threshold threshold :rivers rivers})
