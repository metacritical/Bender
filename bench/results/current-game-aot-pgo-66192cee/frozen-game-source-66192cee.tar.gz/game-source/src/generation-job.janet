# One directly owned CPU-generation child. No shell, detached workers, stdout
# pipes, inference, world mutation, or game integration live in this module.
# The caller must call poll once per frame (it pumps the Bender event loop).
(def max-progress-bytes 4096)
(def max-argv-length 128)
(def max-argument-bytes 8192)
(def cancel-grace-seconds 5)
(def progress-stages @[:resolve :verify :load :sample :export
                       :verify-artifact :ready :failed :cancelled])

(defn- bounded-count? [value]
  (or (nil? value)
      (and (number? value) (<= 0 value 2147483647)
           (= value (math/floor value)))))

(defn- parse-progress [text]
  # Parse one inert Janet table; never evaluate untrusted child output.
  (def forms (parse-all text))
  (assert (= 1 (length forms)) "progress must contain exactly one record")
  (def record (get forms 0))
  (assert (= :struct (type record)) "progress must be an inert struct")
  (assert (<= 2 (length record) 5) "progress has unexpected keys")
  (assert (= 1 (get record :version)) "progress schema version mismatch")
  (assert (some (fn [stage] (= stage (get record :stage))) progress-stages)
          "unknown progress stage")
  (assert (bounded-count? (get record :completed)) "invalid completed count")
  (assert (bounded-count? (get record :total)) "invalid total count")
  (assert (or (nil? (get record :message))
              (and (= :string (type (get record :message)))
                   (<= (length (get record :message)) 1024)))
          "invalid progress message")
  (each key (keys record)
    (assert (some (fn [allowed] (= key allowed))
                  @[:version :stage :completed :total :message])
            "unexpected progress field"))
  record)

(defn- status [job]
  @{:phase (job :phase) :pid (job :pid) :exit-code (job :exit-code)
    :progress (job :progress) :error (job :error)})

(defn- valid-argv? [argv]
  (when (or (= (type argv) :array) (= (type argv) :tuple))
    (when (and (> (length argv) 0) (<= (length argv) max-argv-length))
      (var valid true)
      (each arg argv
        (unless (and (= (type arg) :string)
                     (> (length arg) 0)
                     (<= (length arg) max-argument-bytes))
          (set valid false)))
      valid)))

(defn- stage [job]
  (when (job :progress-path)
    (let [[ok value] (protect ((job :read-progress) (job :progress-path)))]
      (if ok
        (when value
          (put job :progress value))
        (put job :error (string "progress read failed: " value)))))
  nil)

(defn- finish [job]
  (when (and (= (job :phase) :running) (not= nil ((job :completion) :exit-code)))
    (def code ((job :completion) :exit-code))
    (put job :exit-code code)
    (stage job)
    (if (= code 0)
      (let [[ok result] (protect ((job :validate) job))]
        (if (and ok result (nil? (job :error)))
          (put job :phase :succeeded)
          (do (put job :phase :failed)
              (when (nil? (job :error))
                (put job :error (string "artifact validation failed: "
                                        (if ok "validator rejected artifact" result)))))))
      (do (put job :phase :failed)
          (when (nil? (job :error))
            (put job :error (string "generation process exited " code)))))
    (when (= (get (job :slot) :job) job)
      (put (job :slot) :job nil)))
  job)

(defn- bounded-progress [path]
  # The child atomically replaces one inert Janet-data record; never read a
  # pipe, never evaluate a form, never accept an unbounded stage file.
  (def info (os/stat path))
  (when info
    (assert (<= (get info :size) max-progress-bytes)
            "progress exceeds 4096 bytes")
    (let [file (file/open path :rb)]
      (when file
        (def data (try (file/read file (+ max-progress-bytes 1))
                       ([err] (file/close file) (error err))))
        (file/close file)
        (assert (<= (length data) max-progress-bytes)
                "progress exceeds 4096 bytes")
        (parse-progress (string data))))))

(defn- default-spawn [argv]
  # Never redirect to an unread pipe: child stdout/stderr go to inherited streams
  # or the CLI's own bounded stage files. :p searches PATH without a shell.
  (os/spawn argv :p))

(defn- default-watch [process completion]
  (ev/go (fn []
           (let [[ok value] (protect (os/proc-wait process))]
             (if ok (put completion :exit-code value)
                 (put completion :wait-error (string value)))))))

# ev/sleep 0 yields to Bender's scheduler without blocking on a timer;
# the old ev/pump symbol is absent from this interpreter's event API.
(defn- default-pump [] (ev/sleep 0))
(defn- default-clock [] (os/clock :monotonic))
(defn- default-direct-reap [process completion]
  # Only used if watcher installation failed or its wait terminated with an error.
  # No live watcher owns this wait. The exact process was killed first.
  (def code (os/proc-wait process))
  (put completion :exit-code code)
  (put completion :wait-error nil)
  code)
(defn- default-term [process] (os/proc-kill process false :term))
(defn- default-kill [process] (os/proc-kill process false :kill))
(defn- default-wait [process completion]
  # Only called after a watcher completion or forced SIGKILL; poll never waits.
  # Never start a second wait: this job's watcher owns the sole reap.
  (when (completion :wait-error)
    (error (completion :wait-error)))
  (def deadline (+ (os/clock :monotonic) 5))
  (while (= nil (completion :exit-code))
    (when (>= (os/clock :monotonic) deadline)
      (error "owned child was not reaped after forced shutdown"))
    (ev/sleep 0.001)
    (when (completion :wait-error) (error (completion :wait-error))))
  (completion :exit-code))

(defn- cancellation-finish [job]
  (when (not= nil ((job :completion) :exit-code))
    (put job :exit-code ((job :completion) :exit-code))
    (put job :phase (if (job :error) :failed :cancelled))
    (when (= (get (job :slot) :job) job)
      (put (job :slot) :job nil)))
  job)

(defn- advance-cancellation [job]
  (when (= (job :phase) :cancelling)
    (let [[ok value] (protect ((job :pump)))]
      (unless ok (put job :error (string "event pump failed: " value))))
    (cond
      (not= nil ((job :completion) :exit-code))
      (cancellation-finish job)

      ((job :completion) :wait-error)
      (do (put job :phase :failed)
          (put job :error (string "process reap failed: " ((job :completion) :wait-error))))

      (>= ((job :clock)) (job :kill-after))
      (unless (job :kill-sent)
        (put job :kill-sent true)
        (let [[ok value] (protect ((job :kill) (job :process)))]
          (unless ok
            # ESRCH can race a successful exit; the watcher settles ownership.
            (put job :error (string "kill failed: " value)))))))
  job)

(defn start [request-prompt argv &opt opts]
  ``Own one direct argv child in caller-owned `opts :slot` (a mutable table).
  The caller must reserve the slot for this one job; other callers must not
  share or overwrite it. Returns a job table; spawn errors are failed jobs.``
  (def options (or opts {}))
  (def slot (or (get options :slot) @{:job nil}))
  (assert (= (type slot) :table) "generation slot must be a mutable table")
  (assert (= nil (get slot :job)) "generation slot already occupied")
  (assert (= (type request-prompt) :string) "generation prompt must be a string")
  (assert (valid-argv? argv) "generation argv must be bounded strings")
  (assert (= (type (get options :validate)) :function)
          "artifact validator function is required for success")
  (def completion @{:exit-code nil :wait-error nil})
  (def job @{:phase :running :pid nil :process nil :exit-code nil
             :progress nil :error nil :prompt request-prompt :argv argv
             :kill-after nil :kill-sent false
             :slot slot :completion completion
             :progress-path (get options :progress-path)
             :spawn (or (get options :spawn) default-spawn)
             :watch (or (get options :watch) default-watch)
             :pump (or (get options :pump) default-pump)
             :clock (or (get options :clock) default-clock)
             :term (or (get options :term) default-term)
             :kill (or (get options :kill) default-kill)
             :wait (or (get options :wait) default-wait)
             :direct-reap (or (get options :direct-reap) default-direct-reap)
             :read-progress (or (get options :read-progress) bounded-progress)
             :validate (get options :validate)})
  (put slot :job job)
  (let [[ok value] (protect ((job :spawn) argv))]
    (if ok
      (do
        (put job :process value)
        (put job :pid (get value :pid))
        (let [[watch-ok watch-error] (protect ((job :watch) value completion))]
          (unless watch-ok
            # A failed watcher cannot leave a live, unreapable child behind.
            (let [[kill-ok kill-error] (protect ((job :kill) value))]
              (unless kill-ok (put job :error (string "kill failed: " kill-error))))
            (let [[wait-ok wait-error] (protect ((job :direct-reap) value completion))]
              (unless wait-ok (put job :error (string "reap failed: " wait-error)))
              (put job :phase :failed)
              (when (nil? (job :error))
                (put job :error (string "process watcher failed: " watch-error)))
              (when wait-ok (put slot :job nil))))))
      (do
        (put job :phase :failed)
        (put job :error (string "generation spawn failed: " value))
        (put slot :job nil))))
  job)

(defn poll [job]
  ``Never wait for a child; drive one event-loop turn and inspect owned state.``
  (when (= (job :phase) :running)
    (let [[ok value] (protect ((job :pump)))]
      (unless ok (put job :error (string "event pump failed: " value))))
    (stage job)
    (if ((job :completion) :wait-error)
      (do (put job :phase :failed)
          (put job :error (string "process reap failed: " ((job :completion) :wait-error))))
      (finish job)))
  (advance-cancellation job)
  (status job))

(defn cancel [job]
  ``Send TERM once; poll grants five seconds before KILL and only releases a
  slot after the single watcher has reaped the exact owned process.``
  (finish job)
  (when (= (job :phase) :running)
    (put job :phase :cancelling)
    (put job :kill-after (+ ((job :clock)) cancel-grace-seconds))
    (let [[ok value] (protect ((job :term) (job :process)))]
      (unless ok
        # A child already exited can race TERM; collect its watcher before
        # releasing the slot rather than signalling another PID.
        (put job :error (string "term failed: " value)))))
  (status job))

(defn close [job]
  ``Shutdown-only blocking collection; never call on a GUI frame. TERM once,
  give the child five seconds, KILL the owned handle, then collect its watcher.``
  (finish job)
  # A terminated watcher cannot perform cleanup later. Retain ownership unless
  # the emergency reap succeeds; never unblock a second job on a wait error.
  (when (and (= (job :phase) :failed)
             (= (get (job :slot) :job) job) (job :process))
    (protect ((job :kill) (job :process)))
    (let [[ok value] (protect ((job :direct-reap) (job :process) (job :completion)))]
      (if ok
        (do (put job :exit-code value) (put (job :slot) :job nil))
        (put job :error (string "reap failed: " value)))))
  (when (= (job :phase) :running) (cancel job))
  (when (= (job :phase) :cancelling)
    (while (and (= (job :phase) :cancelling)
                (not (job :kill-sent)))
      (advance-cancellation job)
      (when (= (job :phase) :cancelling) (os/sleep 0.01)))
    (when (= (job :phase) :cancelling)
      (let [[ok value] (protect ((job :wait) (job :process) (job :completion)))]
        (if ok
          (do (put (job :completion) :exit-code value)
              (cancellation-finish job))
          (do (put job :phase :failed)
              (put job :error (string "reap failed: " value)))))))
  (status job))
