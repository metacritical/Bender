# Bounded, inert save catalogue. Caller supplies its own trusted root; no UI/GL.
# Layout: <root>/<32 lowercase hex id>/manifest.janet points to an immutable
# <snapshot>/world.trcr and CRC-bound sidecar. New slots publish a complete
# staging directory; updates publish the manifest pointer LAST, preserving
# the previous known-good snapshot if an intermediate write fails.
(import ./world)
(import ./world-seed :as world-seed)
(import ./world-provider :as provider)
(import ./region)
(import ./terrain-identity :as identity)
(import ./terrain-integrity :as integrity)
(import ./terrain-cache :as terrain-cache)
(import ./terrain-runtime :as terrain-runtime)
(import ./climate-tile :as climate)

(def version 1)
(def max-manifest-bytes 16384)
(def max-slots 256)
(def max-region-bytes 67108864)
(def manifest-name "manifest.janet")
(def region-name "world.trcr")
(def learned-provider :terrain-diffusion-python)
(def artifact-dir-name "scenic")
(def max-learned-tiles 1024)
(def max-learned-aux-bytes 65536)
(def learned-model-revision "ad2df557eca5645f588766101cf3bc3682455c3e")
#: The ONE optional seventh entry a learned artifact may carry. The producer
#: (`tools/scenic_terrain.py`, f7dd22c) writes it beside the tiles and describes
#: it in the CRC-bound `provenance.json`; nothing else is ever allowed here.
(def climate-name "climate.f32")
(def climate-container "flat-f32-le")
(def climate-container-version 1)
(def climate-dtype "f32<")
(defn- fail [why] (error (string "world catalogue: " why)))
(defn- model-seed-for [world-seed]
  (def mapping (try [true (provider/python-model-seed world-seed)]
                    ([e] [false (string e)])))
  (unless (get mapping 0) (fail (string "invalid Python world seed mapping: " (get mapping 1))))
  (get mapping 1))
(defn- finite? [x] (and (number? x) (not (nan? x)) (< -1e308 x 1e308)))
(defn- integer? [x] (and (finite? x) (= x (math/floor x))))
(defn- obj? [x] (or (struct? x) (table? x)))
(defn- exact? [x names]
  (and (obj? x) (= (length (keys x)) (length names))
       (every? (map |(not (nil? (get x $))) names))))
(defn safe-id? [id]
  (and (string? id) (= 32 (length id))
       (every? (map (fn [i] (def c (get id i))
                      (or (<= 48 c 57) (<= 97 c 102))) (range 32)))))
(defn- checked-id [id] (unless (safe-id? id) (fail "invalid slot id")) id)
(defn- checked-dir [path]
  (unless (string? path) (fail "root must be a path string"))
  (def st (os/lstat path))
  (unless (and st (= :directory (get st :mode)))
    (fail (string "missing directory or symlink: " path)))
  path)
(defn- checked-file [path limit]
  (def st (os/lstat path))
  (unless (and st (= :file (get st :mode)) (<= (get st :size) limit))
    (fail (string "missing, linked or oversized file: " path)))
  path)
(defn- slot-dir [root id] (string (checked-dir root) "/" (checked-id id)))
(defn- bytes-of [path limit]
  (checked-file path limit)
  (def f (file/open path :rb))
  (when (nil? f) (fail (string "cannot open " path)))
  (def bytes (try (file/read f :all) ([e] (file/close f) (error e))))
  (file/close f)
  (unless (and bytes (<= (length bytes) limit)) (fail "file exceeded byte limit"))
  bytes)
(defn- sha256 [path] (terrain-runtime/sha256-file path))
(defn- hex64? [text]
  (and (string? text) (= 64 (length text))
       (every? (map (fn [c] (or (<= 48 c 57) (<= 97 c 102))) text))))
(defn- bounded-shape? [bounds]
  (and (or (array? bounds) (tuple? bounds)) (= 4 (length bounds))
       (every? (map |(and (integer? $) (<= -2147483648 $ 2147483647)) bounds))
       (<= (get bounds 0) (get bounds 2)) (<= (get bounds 1) (get bounds 3))
       (<= (* (+ 1 (- (get bounds 2) (get bounds 0)))
              (+ 1 (- (get bounds 3) (get bounds 1)))) max-learned-tiles)))
(defn- parse [bytes]
  (def p (parser/new))
  (parser/consume p bytes)
  (when (= :error (parser/status p)) (fail "invalid manifest syntax"))
  (parser/eof p)
  (when (= :error (parser/status p)) (fail "invalid manifest syntax"))
  (def forms @[])
  (while (parser/has-more p)
    (each form (parser/produce p true) (array/push forms form)))
  (unless (= 1 (length forms)) (fail "manifest must contain one inert form"))
  (get forms 0))
(defn- seed-record [seed]
  (unless (and (obj? seed) (= 1 (get seed :version))
               (<= (length (keys seed)) 6)
               (every? (map (fn [key] (some |(= $ key)
                   [:version :kind :input :value :canonical :entropy])) (keys seed)))
               (some |(= $ (get seed :kind)) [:numeric :text :random])
               (integer? (get seed :value)) (<= 0 (get seed :value) world-seed/max-seed)
               (= (get seed :canonical) (string (get seed :value)))
               (if (= :random (get seed :kind))
                 (nil? (get seed :input))
                 (and (string? (get seed :input)) (<= 1 (length (get seed :input)) 256))))
    (fail "invalid seed contract"))
  (when (= :random (get seed :kind))
    (unless (and (string? (get seed :entropy)) (= 4 (length (get seed :entropy)))
                 (= (get seed :value)
                    (get (world-seed/random-identity (get seed :entropy)) :value)))
      (fail "random seed entropy mismatch")))
  (when (not= :random (get seed :kind))
    (when (not (nil? (get seed :entropy))) (fail "nonrandom seed has entropy")))
  # Saved :value is authoritative for generation. Keep :kind/:input for display,
  # but do not rehash saved text on load: future text-hash revisions must not
  # make already-resolved worlds unopenable or silently change their terrain.
  {:version 1 :kind (get seed :kind) :input (get seed :input)
   :value (get seed :value) :canonical (get seed :canonical)
   :entropy (get seed :entropy)})
(defn- player-record [player]
  (def pos (get player :pos))
  (unless (and (obj? player) (= 4 (length (keys player)))
               (every? (map (fn [key] (some |(= $ key)
                   [:pos :yaw :pitch :flying])) (keys player)))
               (or (array? pos) (tuple? pos)) (= 3 (length pos))
               (every? (map finite? pos))
               (<= 0 (get pos 1) (+ world/chunk-y 2))
               (finite? (get player :yaw)) (finite? (get player :pitch))
               (boolean? (get player :flying)))
    (fail "invalid player pose"))
  {:pos [(get pos 0) (get pos 1) (get pos 2)]
   :yaw (get player :yaw) :pitch (get player :pitch)
   :flying (get player :flying)})
(defn- settings-identity [settings &opt settings-version]
  # The descriptor is canonical, explicitly ordered, and versioned; no table
  # iteration order or locale-specific formatting participates in identity.
  #
  # VERSION 1 MUST EMIT BYTE-FOR-BYTE WHAT IT ALWAYS DID. Every saved procedural
  # world pins this string, so a cosmetic change here would make those worlds
  # refuse to load while looking like an unrelated improvement. Version 2 appends
  # one segment and carries `v2`, which is what lets a v2 world at clearing 0 stay
  # distinguishable from a v1 world even though their terrain is identical.
  (def v (or settings-version provider/version))
  (def d (provider/settings-descriptor :procedural settings v))
  (def base (string "procedural:v" (get d :version) ":h" (get d :engine-height)
                    ":scale=" (get d :height-scale)
                    ":offset=" (get d :height-offset)
                    ":sea=" (get d :sea-level)
                    ":forest=" (get d :forest-density)))
  (if (= 2 v)
    (string base ":clearing=" (get d :clearing-density))
    base))
(defn- procedural-settings [settings &opt settings-version]
  (def result (try [true (provider/validate-settings :procedural settings
                                                     (or settings-version provider/version))]
                    ([e] [false (string e)])))
  (unless (get result 0) (fail (string "invalid world setting: " (get result 1))))
  (get result 1))
(defn- learned-settings [settings]
  (unless (exact? settings [:size :sea-level :profile])
    (fail "invalid learned generation settings"))
  (def result (try [true (provider/validate-settings learned-provider settings)]
                    ([e] [false (string e)])))
  (unless (get result 0) (fail (string "invalid learned generation settings: " (get result 1))))
  (get result 1))
(defn- learned-settings-identity [settings seed digest]
  (string "terrain-diffusion-python:v1:seed=" seed ":artifact=" digest
          ":size=" (get settings :size)
          ":sea=" (get settings :sea-level)
          ":profile=" (get settings :profile)))
(defn- learned-record [record seed]
  (def a (get record :artifact))
  (unless (and (exact? a [:identity :digest :model-seed :seed-mapping-version
                          :bounds :origin :model-revision :manifest-sha256
                          :provenance-sha256 :ready-sha256])
               (hex64? (get a :identity)) (hex64? (get a :digest))
               (= (get a :model-seed) (get (model-seed-for (get seed :value)) 0))
               (= (get a :seed-mapping-version)
                  (or (get (model-seed-for (get seed :value)) 1) 0))
               (hex64? (get a :manifest-sha256))
               (hex64? (get a :provenance-sha256))
               (hex64? (get a :ready-sha256))
               (bounded-shape? (get a :bounds))
               (or (array? (get a :origin)) (tuple? (get a :origin)))
               (= 2 (length (get a :origin)))
               (every? (map |(and (integer? $) (<= -2147483648 $ 2147483647))
                            (get a :origin)))
               (= learned-model-revision (get a :model-revision)))
    (fail "invalid learned artifact metadata"))
  (unless (= 1 (get record :settings-version)) (fail "unsupported learned settings version"))
  (def settings (learned-settings (get record :settings)))
  (unless (= settings (get record :settings)) (fail "noncanonical learned settings"))
  (unless (= (get record :settings-identity)
             (learned-settings-identity settings (get seed :value) (get a :digest)))
    (fail "learned settings identity mismatch"))
  (unless (= (get record :digest) (get a :digest))
    (fail "learned digest mismatch"))
  record)
(defn- validate [record id]
  (def learned? (= learned-provider (get record :provider)))
  (def names (if learned?
               [:version :id :name :seed :provider :profile :snapshot
                :height :volume :region-version :region-crc :player :settings
                :settings-version :settings-identity :digest :artifact]
               [:version :id :name :seed :provider :profile :snapshot
                :height :volume :region-version :region-crc :player :settings
                :settings-version :settings-identity]))
  # Janet tables omit nil values: procedural slots cannot carry :digest.
  (unless (and (obj? record) (= (length (keys record)) (length names))
               (every? (map (fn [name] (some (fn [key] (= key name)) (keys record))) names)))
    (fail "manifest keys"))
  (unless (and (= version (get record :version)) (= id (get record :id))
               (safe-id? id) (string? (get record :name))
               (<= 1 (length (get record :name)) 128)
               (= 256 (get record :height)) (= 65536 (get record :volume))
               (= region/version (get record :region-version))
               (integer? (get record :region-crc))
               (<= 0 (get record :region-crc) 4294967295))
    (fail "unsupported manifest version, dimensions, id, name or CRC"))
  (unless (safe-id? (get record :snapshot))
    (fail "invalid snapshot pointer"))
  (def seed (seed-record (get record :seed)))
  (unless (= :v2h256 (get record :profile)) (fail "unsupported provider terrain profile"))
  (if learned?
    (learned-record record seed)
    (unless (and (= :procedural (get record :provider))
                 (nil? (get record :digest)))
      (fail "provider unavailable: only procedural v2h256 or temporary Python learned terrain is supported")))
  (player-record (get record :player))
  (when learned? (break record))
  (def settings-version (get record :settings-version))
  (unless (provider/settings-version? settings-version)
    (fail "unsupported settings version"))
  (def settings (get record :settings))
  # The key count is the version's contract, and it is EXACT in both directions:
  # a fifth key under v1 and a missing fifth key under v2 are both refused, so no
  # manifest can be read under a settings shape it was not written with.
  (def expected-count (if (= 2 settings-version) 5 4))
  (unless (and (obj? settings) (= expected-count (length (keys settings))))
    (fail (string "settings must contain exactly " expected-count
                  " generation controls for settings version " settings-version)))
  (def canonical (procedural-settings settings settings-version))
  (unless (= canonical settings) (fail "noncanonical world settings"))
  (unless (= (get record :settings-identity)
             (settings-identity canonical settings-version))
    (fail "world settings identity mismatch"))
  record)
(defn- encode [m]
  (def seed (get m :seed))
  (def p (get m :player))
  (string "{:version 1 :id " (string/format "%q" (get m :id))
          " :name " (string/format "%q" (get m :name))
          " :snapshot " (string/format "%q" (get m :snapshot))
          " :seed {:version 1 :kind :" (get seed :kind)
          " :input " (if (nil? (get seed :input)) "nil" (string/format "%q" (get seed :input)))
          " :value " (get seed :value)
          " :canonical " (string/format "%q" (get seed :canonical))
          (if (= :random (get seed :kind))
            (string " :entropy " (string/format "%q" (get seed :entropy))) "") "}"
          (if (= learned-provider (get m :provider))
            (string " :provider :terrain-diffusion-python :profile :v2h256 :digest "
                    (string/format "%q" (get m :digest)))
            " :provider :procedural :profile :v2h256 :digest nil")
          " :height 256 :volume 65536 :region-version 2 :region-crc " (get m :region-crc)
          " :player {:pos [" (get (get p :pos) 0) " " (get (get p :pos) 1)
          " " (get (get p :pos) 2) "] :yaw " (get p :yaw)
          " :pitch " (get p :pitch) " :flying " (get p :flying) "}"
          " :settings-version " (get m :settings-version)
          " :settings-identity " (string/format "%q" (get m :settings-identity))
          (if (= learned-provider (get m :provider))
            (let [a (get m :artifact) s (get m :settings) b (get a :bounds) o (get a :origin)]
              (string " :artifact {:identity " (string/format "%q" (get a :identity))
                      " :digest " (string/format "%q" (get a :digest))
                      " :model-seed " (get a :model-seed)
                      " :seed-mapping-version " (get a :seed-mapping-version)
                      " :bounds [" (get b 0) " " (get b 1) " " (get b 2) " " (get b 3) "]"
                      " :origin [" (get o 0) " " (get o 1) "]"
                      " :model-revision " (string/format "%q" (get a :model-revision))
                      " :manifest-sha256 " (string/format "%q" (get a :manifest-sha256))
                      " :provenance-sha256 " (string/format "%q" (get a :provenance-sha256))
                      " :ready-sha256 " (string/format "%q" (get a :ready-sha256)) "}"
                      " :settings {:size " (get s :size)
                      " :sea-level " (get s :sea-level)
                      " :profile " (string/format "%q" (get s :profile)) "}}\n"))
            (string " :settings {:height-scale " (get (get m :settings) :height-scale)
          " :height-offset " (get (get m :settings) :height-offset)
          " :sea-level " (get (get m :settings) :sea-level)
          " :forest-density " (get (get m :settings) :forest-density)
          # The fifth control is written only under settings version 2, so a v1
          # manifest encodes exactly the four keys it always did and stays
          # byte-identical on re-save.
          (if (= 2 (get m :settings-version))
            (string " :clearing-density " (get (get m :settings) :clearing-density))
            "") "}}\n"))))
(defn- write-file [path bytes]
  (def f (file/open path :wbn))
  (when (nil? f) (fail (string "cannot create " path)))
  (try (do (file/write f bytes) (file/flush f) (file/close f))
       ([e] (try (file/close f) ([ignored] nil)) (error e))))
(defn- artifact-path [snapshot-dir]
  (string snapshot-dir "/" artifact-dir-name))
(defn- tile-count [bounds]
  (* (+ 1 (- (get bounds 2) (get bounds 0)))
     (+ 1 (- (get bounds 3) (get bounds 1)))))

#
# --- Bounded JSON scanning: reading a declared contract, never running one ---
#
# `provenance.json` is written by another language and is ALREADY bound to the
# artifact by its CRC-32 and byte length (the cache twin checks both). What is
# missing is only the ability to READ one booleans-and-numbers field out of it
# without a JSON library, without `eval`, and without a dependency.
#
# So this is a scanner, not a parser for general use: it builds a table of
# STRING keys to values (string/float/boolean/nil/array/table), depth-capped,
# over input the caller already capped in bytes. It has no side effects, holds no
# state between calls, and never turns a value into code. A record it cannot read
# raises -- and the one caller treats that as "no declaration I can honour"
# rather than as a valid empty block.
(def json-max-depth 16)

(defn- j-fail [why] (fail (string "provenance.json: " why)))
(defn- j-at [s p] (when (< (get p 0) (length s)) (get s (get p 0))))
(defn- j-advance [p] (put p 0 (+ 1 (get p 0))))
(defn- j-at? [s p c] (and (j-at s p) (= c (j-at s p))))
(defn- j-space? [c] (and c (or (= c 32) (= c 9) (= c 10) (= c 13))))
(defn- j-skip-space [s p] (while (j-space? (j-at s p)) (j-advance p)))
(defn- j-digit? [c] (and c (<= 48 c 57)))
(defn- j-hex? [c]
  (and c (or (<= 48 c 57) (<= 65 c 70) (<= 97 c 102))))
(defn- j-hex-value [c]
  (cond (<= 48 c 57) (- c 48) (<= 65 c 70) (- c 55) (- c 87)))
(defn- j-push-codepoint [out cp]
  # UTF-8, so a decoded name can never collide with an unescaped one.
  (cond
    (< cp 128) (buffer/push-byte out cp)
    (< cp 2048) (buffer/push-byte out (+ 192 (brshift cp 6)) (+ 128 (band cp 63)))
    (< cp 65536) (buffer/push-byte out (+ 224 (brshift cp 12))
                                 (+ 128 (band (brshift cp 6) 63)) (+ 128 (band cp 63)))
    (buffer/push-byte out (+ 240 (brshift cp 18)) (+ 128 (band (brshift cp 12) 63))
                      (+ 128 (band (brshift cp 6) 63)) (+ 128 (band cp 63)))))
(defn- j-string [s p]
  (unless (j-at? s p 34) (j-fail "expected a string"))
  (j-advance p)
  (def out @"")
  (var done false)
  (while (not done)
    (def c (j-at s p))
    (cond
      (nil? c) (j-fail "unterminated string")
      (= c 34) (do (j-advance p) (set done true))
      (< c 32) (j-fail "raw control byte in string")
      (= c 92)
        (do
          (j-advance p)
          (def e (j-at s p))
          (j-advance p)
          (cond
            (nil? e) (j-fail "unterminated escape")
            (= e 34) (buffer/push-byte out 34)
            (= e 92) (buffer/push-byte out 92)
            (= e 47) (buffer/push-byte out 47)
            (= e 98) (buffer/push-byte out 8)
            (= e 102) (buffer/push-byte out 12)
            (= e 110) (buffer/push-byte out 10)
            (= e 114) (buffer/push-byte out 13)
            (= e 116) (buffer/push-byte out 9)
            (= e 117)
              (do
                (var cp 0)
                (repeat 4
                  (def h (j-at s p))
                  (unless (j-hex? h) (j-fail "truncated unicode escape"))
                  (set cp (+ (* cp 16) (j-hex-value h)))
                  (j-advance p))
                (j-push-codepoint out cp))
            (j-fail "unsupported escape in string")))
      (buffer/push-byte out c)
      (j-advance p)))
  (string out))
(defn- j-number [s p]
  (def start (get p 0))
  (while (let [c (j-at s p)]
           (and c (or (j-digit? c) (= c 45) (= c 43) (= c 46) (= c 101) (= c 69))))
    (j-advance p))
  (def text (string/slice s start (get p 0)))
  (def v (scan-number text))
  (unless (and v (not (nan? v)) (< -1e308 v 1e308))
    (j-fail (string "invalid number " text)))
  v)
(defn- j-literal [s p word value]
  (unless (= word (string/slice s (get p 0) (min (length s) (+ (get p 0) (length word)))))
    (j-fail "unexpected token"))
  (put p 0 (+ (get p 0) (length word)))
  value)
(defn- j-value-at [s p depth]
  (when (> depth json-max-depth) (j-fail "nesting is deeper than this reader accepts"))
  (j-skip-space s p)
  (def c (j-at s p))
  (cond
    (nil? c) (j-fail "unexpected end of record")
    (= c 34) (j-string s p)
    (= c 123)
      (do
        (j-advance p)
        (def out @{})
        # A REPEATED KEY IS REFUSED, not last-one-wins. JSON permits duplicates and
        # leaves the resolution to the reader, so two `climate` blocks -- or two
        # `crc32` fields inside one -- would let a writer show a validator one
        # value and a loader another. Presence is tracked in its own set because
        # `put`-ing nil deletes a key and would hide `{"a":null,"a":1}`.
        (def seen @{})
        (j-skip-space s p)
        (if (j-at? s p 125)
          (j-advance p)
          (forever
            (j-skip-space s p)
            (def key (j-string s p))
            (when (get seen key)
              (j-fail (string "duplicate key " (string/format "%q" key))))
            (put seen key true)
            (j-skip-space s p)
            (unless (j-at? s p 58) (j-fail "expected ':' after a key"))
            (j-advance p)
            (put out key (j-value-at s p (+ depth 1)))
            (j-skip-space s p)
            (cond (= (j-at s p) 44) (j-advance p)
                  (= (j-at s p) 125) (do (j-advance p) (break))
                  (j-fail "expected ',' or '}' in an object"))))
        out)
    (= c 91)
      (do
        (j-advance p)
        (def out @[])
        (j-skip-space s p)
        (if (j-at? s p 93)
          (j-advance p)
          (forever
            (array/push out (j-value-at s p (+ depth 1)))
            (j-skip-space s p)
            (cond (= (j-at s p) 44) (j-advance p)
                  (= (j-at s p) 93) (do (j-advance p) (break))
                  (j-fail "expected ',' or ']' in an array"))))
        out)
    (= c 116) (j-literal s p "true" true)
    (= c 102) (j-literal s p "false" false)
    (= c 110) (j-literal s p "null" nil)
    (or (j-digit? c) (= c 45)) (j-number s p)
    (j-fail "unexpected token")))
(defn- json-scan
  ``Read one JSON value from `bytes` without evaluating it.

  The input is already capped by the caller (`max-learned-aux-bytes`), and the
  scanner refuses deep nesting, raw control bytes and unterminated input rather
  than guessing. Objects come back as tables keyed by STRING -- no keyword
  coercion is applied to anything an outside writer chose.``
  [bytes]
  (def text (if (string? bytes) bytes (string bytes)))
  (def p (array/new-filled 1 0))
  (def value (j-value-at text p 0))
  (j-skip-space text p)
  (when (< (get p 0) (length text))
    (j-fail "trailing bytes after the record"))
  value)

#
# --- The optional climate container ------------------------------------------
#
# The producer writes `climate.f32` and describes it in the CRC-bound record.
# The catalogue's job is NOT to read climate -- it copies the artifact, and a
# loader decodes the buffer later. Its job is to refuse to publish half of one:
# a declaration with no payload, a payload with no declaration, a payload whose
# declared shape disagrees with this artifact's map bounds, or bytes that do not
# match the declared length, CRC-32 and SHA-256.
(defn- climate-shape-for [bounds]
  # The producer anchors its grid at the map's chunk-min with 16 pixels per
  # chunk: (chunks_z * 16, chunks_x * 16, 5). Anything else describes a
  # different map, and this refuses rather than stretching it onto this one.
  [(* 16 (+ 1 (- (get bounds 3) (get bounds 1))))
   (* 16 (+ 1 (- (get bounds 2) (get bounds 0))))
   climate/channel-count])
#: The block's EXACT key set. A climate block with a missing or extra key is not
#: a newer contract to be tolerated, it is a different document: refusing it keeps
#: "the producer wrote this" verifiable instead of assumed.
(def climate-block-keys
  ["container" "container-version" "file" "shape" "dtype" "order" "bytes"
   "channels" "units" "basis" "calibrated" "projection" "sha256" "crc32"])
#: The five channels, in the producer's last-axis order, and the unit STRINGS it
#: writes for them. These are compared EXACTLY: a block that renames a channel or
#: invents a unit is describing different data, and `:calibrated false` only means
#: something if the units it sits beside are the ones the reader understands.
(def climate-channels
  ["temperature" "temperature-seasonality" "precipitation"
   "precipitation-variability" "lapse-rate"])
(def climate-units
  {"temperature" "degrees C, elevation-adjusted mean"
   "temperature-seasonality" "degrees C, standard deviation"
   "precipitation" "millimetres per year"
   "precipitation-variability" "coefficient of variation, percent"
   "lapse-rate" "degrees C per metre"})
(defn- climate-block
  ``Validate the declared `climate` block against this artifact's own bounds.

  Returns `{:bytes .. :crc32 .. :sha256 .. :shape ..}`, or raises. Every field
  read here is one the producer promises; nothing is defaulted, and no value in
  the record is trusted because the record merely contains it.``
  [block bounds]
  (unless (table? block) (fail "learned artifact declares a non-object climate block"))
  # The key set is EXACT in both directions -- a missing or unknown field is a
  # different contract, not a superset to be tolerated.
  (unless (= (length climate-block-keys) (length (keys block)))
    (fail (string "learned artifact climate block must have exactly "
                  (length climate-block-keys) " keys")))
  # Presence only: `calibrated` is legitimately `false`, so a truthiness test here
  # would refuse the producer's own record. A JSON `null` cannot reach this point
  # as a present key -- the scanner's `put` of nil deletes it, so the count above
  # is what catches it.
  (each key climate-block-keys
    (unless (some |(= $ key) (keys block))
      (fail (string "learned artifact climate block is missing " (string/format "%q" key)))))
  (each [key expected]
    [["container" climate-container] ["dtype" climate-dtype]
     ["file" climate-name] ["container-version" climate-container-version]]
    (unless (= expected (get block key))
      (fail (string "learned artifact climate :" key " is not "
                    (string/format "%q" expected)))))
  (unless (= "source-derived" (get block "basis"))
    (fail "learned artifact climate basis must be :source-derived"))
  # `calibrated` is the producer's own honesty flag, and it is FALSE today. It is
  # not a gate: the dimensions follow from pinned source either way, and this
  # module classifies nothing. It must be a boolean so a loader cannot misread it.
  (unless (boolean? (get block "calibrated"))
    (fail "learned artifact climate :calibrated must be a boolean"))
  # Channel names and their unit strings are the reader's own vocabulary
  # (`climate-tile/channels`, `climate-tile/unit-contract`). A block that agrees
  # on count but not on names would be accepted by a merely-structural check and
  # then misread by every consumer downstream, so the names are compared exactly.
  (def channels (get block "channels"))
  (unless (and (array? channels) (= climate/channel-count (length channels)))
    (fail (string "learned artifact climate :channels must list "
                  climate/channel-count " names")))
  (each i (range climate/channel-count)
    (def name (get channels i))
    (unless (and (string? name) (= (get climate-channels i) name))
      (fail (string "learned artifact climate channel " i " must be "
                    (string/format "%q" (get climate-channels i))
                    ", got " (string/format "%q" name)))))
  (def units (get block "units"))
  (unless (and (table? units) (= climate/channel-count (length (keys units))))
    (fail "learned artifact climate :units must map each channel to one unit"))
  (each name climate-channels
    (def declared-unit (get units name))
    (unless (= (get climate-units name) declared-unit)
      (fail (string "learned artifact climate unit for " (string/format "%q" name)
                    " must be " (string/format "%q" (get climate-units name))))))
  # PROJECTION must describe THIS artifact's grid. The producer records the
  # source grid, the artifact grid and one integer scale; a loader that attaches
  # the buffer later needs those to agree with the map it is attaching to, so a
  # self-consistent block for a different grid is refused here rather than
  # discovered by a consumer.
  (def projection (get block "projection"))
  (unless (table? projection)
    (fail "learned artifact climate :projection must be an object"))
  (def artifact-grid (get projection "artifact-grid"))
  (def source-grid (get projection "source-grid"))
  (def scale (get projection "scale"))
  (unless (and (array? artifact-grid) (= 2 (length artifact-grid))
               (every? (map |(and (integer? $) (pos? $)) artifact-grid))
               (array? source-grid) (= 2 (length source-grid))
               (every? (map |(and (integer? $) (pos? $)) source-grid)))
    (fail "learned artifact climate :projection grids must be two positive integers each"))
  # The producer's grid is (rows, cols) with rows = height, cols = width, matching
  # shape[:2]. Both must equal this artifact's own pixel extents, and the scale
  # must be the single integer that relates them to the source grid.
  (def expected-grid [(get (climate-shape-for bounds) 0) (get (climate-shape-for bounds) 1)])
  (unless (and (= (get expected-grid 0) (get artifact-grid 0))
               (= (get expected-grid 1) (get artifact-grid 1)))
    (fail "learned artifact climate projection artifact-grid does not match this map"))
  (unless (and (integer? scale) (pos? scale)
               (= (get artifact-grid 0) (* scale (get source-grid 0)))
               (= (get artifact-grid 1) (* scale (get source-grid 1))))
    (fail "learned artifact climate projection scale must map source-grid onto artifact-grid"))
  (unless (= "cell-grid" (get projection "semantics"))
    (fail "learned artifact climate projection semantics must be :cell-grid"))
  (def origin (get projection "origin"))
  (unless (and (array? origin) (= 2 (length origin))
               (every? (map |(and (integer? $) (<= -2147483648 $ 2147483647)) origin)))
    (fail "learned artifact climate projection origin must be two signed 32-bit integers"))
  (def declared-shape (get block "shape"))
  (unless (and (array? declared-shape) (= 3 (length declared-shape))
               (every? (map |(and (integer? $) (pos? $)) declared-shape)))
    (fail "learned artifact climate :shape must be three positive integers"))
  (def shape (climate-shape-for bounds))
  (unless (every? (map (fn [i] (= (get shape i) (get declared-shape i))) (range 3)))
    (fail (string "learned artifact climate shape ["
                  (string/join (map string declared-shape) " ") "] does not match this "
                  "artifact's grid [" (string/join (map string shape) " ") "]")))
  (def expected-bytes (* (get shape 0) (get shape 1) (get shape 2) 4))
  (unless (<= expected-bytes terrain-cache/climate-max-bytes)
    (fail (string "learned artifact climate grid exceeds " terrain-cache/climate-max-bytes
                  " bytes")))
  (def declared-bytes (get block "bytes"))
  (unless (and (integer? declared-bytes) (= expected-bytes declared-bytes))
    (fail (string "learned artifact climate :bytes must be exactly " expected-bytes
                  " for this artifact's grid")))
  (def crc (get block "crc32"))
  (unless (and (integer? crc) (<= 0 crc 4294967295))
    (fail "learned artifact climate :crc32 must be an unsigned 32-bit integer"))
  (def digest (get block "sha256"))
  (unless (hex64? digest) (fail "learned artifact climate :sha256 must be 64 lowercase hex"))
  {:bytes expected-bytes :crc32 crc :sha256 digest :shape shape})
(defn climate-declaration
  ``The declared climate block of a record, or nil when it declares none.

  PUBLIC, and pure: `provenance` is the exact bytes of `provenance.json`, which the
  caller has already bound to the artifact by size and CRC-32. A cache loader
  reuses this instead of growing a second JSON reader, and it decides nothing
  about files -- presence is the caller's to supply as `payload?`.

  A record this reader cannot scan is treated as declaring NOTHING only when the
  artifact also carries no payload -- that is a pre-climate artifact, whose
  behaviour must not change. With a payload present, an unreadable record is a
  refusal: the bytes would be published without any contract at all.``
  [provenance payload?]
  (def scanned (try [true (json-scan provenance)] ([e] [false (string e)])))
  (if (get scanned 0)
    (let [record (get scanned 1)]
      (unless (table? record) (fail "learned artifact provenance.json is not an object"))
      (get record "climate"))
    (do (when payload? (fail (string "learned artifact carries climate payload but its "
                                     "record cannot be read: " (get scanned 1))))
        nil)))
(defn climate-metadata
  ``The VALIDATED climate contract of a record, or nil when it declares none.

  PUBLIC and pure: it touches no file and reads nothing but its arguments, so a
  cache loader can validate the same block the catalogue does without duplicating
  the schema. `provenance` is the exact `provenance.json` bytes (already bound to
  the artifact by size and CRC-32 by the cache twin), `bounds` is the artifact's
  inclusive `[cx0 cz0 cx1 cz1]`, and `payload?` says whether a payload file exists.

  Returns `{:shape .. :bytes .. :crc32 .. :sha256 ..}` or nil, and raises on a
  block that is malformed, duplicated, or describes a different grid. An
  unreadable record is "declares nothing" ONLY when there is no payload; with a
  payload it refuses, because unpublished bytes must never be unexplained.``
  [provenance bounds payload?]
  (def declared (climate-declaration provenance payload?))
  (when (nil? declared) (break nil))
  (unless payload?
    (fail "learned artifact declares climate but has no climate.f32 payload"))
  (climate-block declared bounds))
(defn check-climate
  ``Bind an artifact's optional climate payload to its declared contract.

  Returns `{:bytes .. :crc32 .. :sha256 .. :shape ..}`, or nil for the shipped
  six-entry artifact. Presence is checked in BOTH directions, so neither a
  declaration without bytes nor bytes without a declaration can be published.``
  [dir bounds payload?]
  (def declared (climate-declaration
                  (bytes-of (string dir "/provenance.json") max-learned-aux-bytes)
                  payload?))
  (cond
    (nil? declared)
      (do (when payload? (fail "learned artifact carries climate.f32 without declaring it"))
          nil)
    (not payload?)
      (fail "learned artifact declares climate but has no climate.f32 payload")
    :else
      (let [contract (climate-block declared bounds)
            path (string dir "/" climate-name)
            bytes (bytes-of path terrain-cache/climate-max-bytes)]
        (unless (= (get contract :bytes) (length bytes))
          (fail (string "learned artifact climate payload is " (length bytes)
                        " bytes, its contract declares " (get contract :bytes))))
        (unless (= (get contract :crc32) (integrity/crc32 bytes))
          (fail "learned artifact climate payload CRC-32 mismatch"))
        (unless (= (get contract :sha256) (sha256 path))
          (fail "learned artifact climate payload SHA-256 mismatch"))
        contract)))
(defn- verify-artifact [dir world-seed expected]
  (checked-dir dir)
  (def [model-seed mapping-version] (model-seed-for world-seed))
  (def names (os/dir dir))
  (def allowed ["manifest.janet" "manifest.json" "provenance.json"
                "summary.json" "READY" "tiles"])
  # EXACTLY six entries, or exactly those six plus `climate.f32`. The whitelist is
  # not widened: any other seventh name -- including a second climate-looking
  # file -- is still refused here, and a declared/payload disagreement is refused
  # by `check-climate` below.
  (def has-climate (some |(= $ climate-name) names))
  (unless (and (or (= (length names) 6) (and (= (length names) 7) has-climate))
               (every? (map |(some (fn [name] (= name $)) allowed)
                            (filter |(not= $ climate-name) names))))
    (fail "learned artifact files incomplete or unexpected"))
  (each name ["manifest.janet" "manifest.json" "provenance.json" "summary.json" "READY"]
    (checked-file (string dir "/" name) max-learned-aux-bytes))
  (def ready (string (bytes-of (string dir "/READY") max-learned-aux-bytes)))
  # The Python producer writes this marker only after its own full verification;
  # the catalogue additionally verifies every tile and the manifest binding.
  (unless (and (string/find "\"ready\": true" ready)
               (string/find "\"temporary\": true" ready))
    (fail "learned artifact is not READY"))
  (def cache (terrain-cache/cache-new dir model-seed))
  (def meta (terrain-cache/cache-meta cache))
  (unless (= :scenic (get meta :profile)) (fail "learned artifact must be TDS3 scenic"))
  (def bounds (get meta :bounds))
  (unless (bounded-shape? bounds) (fail "learned artifact exceeds finite map bounds"))
  (def tiles-dir (checked-dir (terrain-cache/tiles-dir dir)))
  (def tile-names (os/dir tiles-dir))
  (unless (= (tile-count bounds) (length tile-names))
    (fail "learned artifact tile count mismatch"))
  (each name tile-names
    (def path (string tiles-dir "/" name))
    (unless (and (string? name) (<= 5 (length name) 32)
                 (= :file (os/lstat path :mode)))
      (fail "learned artifact has linked or unexpected tile")))
  (for cx (get bounds 0) (+ 1 (get bounds 2))
    (for cz (get bounds 1) (+ 1 (get bounds 3))
      (def path (terrain-cache/tile-path dir cx cz))
      (checked-file path terrain-cache/tile-bytes)
      (unless (= terrain-cache/tile-bytes (get (os/lstat path) :size))
        (fail "learned tile byte length mismatch"))
      (unless (terrain-cache/read-height-tile cache cx cz)
        (fail "learned artifact missing tile"))))
  # The optional climate container, checked against THIS artifact's own bounds
  # and against its declared digests. Runs after the tiles so a corrupt tile is
  # still reported as a tile problem, and before `expected` so a tampered payload
  # is never confused with an identity mismatch.
  (def climate-contract (check-climate dir bounds has-climate))
  (when expected
    (unless (and (= (get expected :identity) (get meta :identity))
                 (every? (map (fn [i] (= (get (get expected :bounds) i) (get bounds i)))
                              (range 4)))
                 (every? (map (fn [i] (= (get (get expected :origin) i)
                                       (get (get meta :origin) i))) (range 2))))
      (fail "learned artifact identity or finite bounds mismatch")))
  (def actual {:identity (get meta :identity)
               :digest (get meta :identity)
               :model-seed model-seed :seed-mapping-version (or mapping-version 0)
               :bounds bounds :origin (get meta :origin)
               :model-revision learned-model-revision
               :manifest-sha256 (sha256 (string dir "/manifest.janet"))
               :provenance-sha256 (sha256 (string dir "/provenance.json"))
               :ready-sha256 (sha256 (string dir "/READY"))})
  (when expected
    (each key [:identity :digest :model-seed :seed-mapping-version
               :model-revision :manifest-sha256 :provenance-sha256 :ready-sha256]
      (unless (= (get actual key) (get expected key))
        (fail (string "learned artifact SHA-256 or metadata mismatch: " key)))))
  actual)
(defn inspect-artifact [dir world-seed]
  ``Validate a completed TDS3 map and return owned, bounded metadata for
  New Game. This does not copy, publish, or mark a catalogue slot ready; pass
  the same directory as :artifact-dir to create-slot after building the world.``
  (verify-artifact dir world-seed nil))
(defn- copy-artifact [source snapshot-dir seed expected]
  (def actual (verify-artifact source seed expected))
  (def destination (artifact-path snapshot-dir))
  (os/mkdir destination)
  (os/mkdir (string destination "/tiles"))
  (each name ["manifest.janet" "manifest.json" "provenance.json" "summary.json" "READY"]
    (write-file (string destination "/" name)
                (bytes-of (string source "/" name) max-learned-aux-bytes)))
  # The payload is copied only after `verify-artifact` above bound it to its
  # declared contract, and the destination is re-verified below -- so a snapshot
  # never publishes a record that declares climate without the bytes it names.
  (when (= :file (os/lstat (string source "/" climate-name) :mode))
    (write-file (string destination "/" climate-name)
                (bytes-of (string source "/" climate-name)
                          terrain-cache/climate-max-bytes)))
  (def bounds (get actual :bounds))
  (for cx (get bounds 0) (+ 1 (get bounds 2))
    (for cz (get bounds 1) (+ 1 (get bounds 3))
      (def filename (string (terrain-cache/coord-name cx cz) ".tdh"))
      (write-file (string destination "/tiles/" filename)
                  (bytes-of (string source "/tiles/" filename)
                            terrain-cache/tile-bytes))))
  (verify-artifact destination seed actual)
  actual)
(defn- random-id []
  (def bytes (os/cryptorand 16))
  (string/join (map |(string/format "%02x" $) bytes) ""))
(defn- manifest-for [id snapshot opts world player crc]
  (def seed (seed-record (get opts :seed)))
  (unless (= (get world :seed) (get seed :value)) (fail "world seed mismatch"))
  (def learned? (= learned-provider (get opts :provider)))
  # The settings version is the CALLER's, defaulting to the legacy 1. It is never
  # inferred from which keys happen to be present: a world made at v1 must stay v1
  # even if a future release could express it at v2, or re-saving would relabel an
  # existing world as generated under rules it predates.
  (def settings-version (or (get opts :settings-version) provider/version))
  (unless (provider/settings-version? settings-version)
    (fail "unsupported settings version"))
  (def settings (if learned? (learned-settings (get opts :settings))
                  (procedural-settings (get opts :settings) settings-version)))
  (def artifact (when learned? (get opts :artifact)))
  (unless (or (not learned?) (obj? artifact))
    (fail "learned artifact metadata required"))
  (def m {:version 1 :id id :snapshot snapshot :name (get opts :name) :seed seed
          :provider (or (get opts :provider) :procedural)
          :profile (or (get opts :profile) :v2h256)
          :digest (when learned? (get artifact :digest)) :artifact artifact
          :height 256 :volume 65536 :region-version 2 :region-crc crc
          :player (player-record player) :settings settings
          :settings-version settings-version
          :settings-identity (if learned?
                               (learned-settings-identity settings (get seed :value)
                                                          (get artifact :digest))
                               (settings-identity settings settings-version))})
  (validate m id))
(defn- stage-save [dir id snapshot world player opts]
  (def snapshot-dir (string dir "/" snapshot))
  (when (os/lstat snapshot-dir) (fail "snapshot collision"))
  (os/mkdir snapshot-dir)
  (def path (string snapshot-dir "/" region-name))
  (region/save-world path world)
  (def bytes (bytes-of path max-region-bytes))
  (def crc (integrity/crc32 bytes))
  (def learned? (= learned-provider (get opts :provider)))
  (def artifact (when learned?
                  (copy-artifact (get opts :artifact-dir) snapshot-dir
                                 (get world :seed) (get opts :artifact))))
  (def chosen (if learned? (merge opts {:artifact artifact}) opts))
  (def m (manifest-for id snapshot chosen world player crc))
  (def session (if learned?
                 (identity/diffusion-identity (get artifact :identity) (get world :seed))
                 (identity/procedural-identity (get world :seed)
                                               (get m :settings-identity))))
  (identity/write-atomic path session crc)
  (def content (encode m))
  (unless (<= (length content) max-manifest-bytes) (fail "manifest exceeds byte limit"))
  (write-file (string dir "/manifest.janet.tmp") content)
  (os/rename (string dir "/manifest.janet.tmp") (string dir "/" manifest-name))
  m)
# Cleanup is deliberately narrower than a recursive delete: only 32-hex
# directories with precisely the two files this module creates are owned.
# Unexpected names, links and types are left alone. Publication already
# succeeded when this runs; cleanup errors cannot invalidate the new snapshot.
(defn- prune-snapshots [dir keep-current keep-previous]
  (each snapshot (os/dir dir)
    (when (and (safe-id? snapshot)
               (not= snapshot keep-current)
               (not= snapshot keep-previous))
      (def path (string dir "/" snapshot))
      (when (= :directory (os/lstat path :mode))
        (def names (os/dir path))
        (when (and (= 2 (length names))
                   (some |(= $ region-name) names)
                   (some |(= $ (string region-name ".terrain.janet")) names)
                   (= :file (os/lstat (string path "/" region-name) :mode))
                   (= :file (os/lstat (string path "/" region-name ".terrain.janet") :mode)))
          (try (do (os/rm (string path "/" region-name))
                   (os/rm (string path "/" region-name ".terrain.janet"))
                   (os/rm path))
               ([ignored] nil)))))))
(defn load-manifest [root id]
  (def dir (slot-dir root id))
  (checked-dir dir)
  (validate (parse (bytes-of (string dir "/" manifest-name) max-manifest-bytes)) id))
(defn create-slot [root opts]
  (checked-dir root)
  (def id (random-id))
  (def target (slot-dir root id))
  (when (os/lstat target) (fail "slot id collision; retry creation"))
  (def tmp (string root "/." id ".creating"))
  (when (os/lstat tmp) (fail "slot staging path exists"))
  (os/mkdir tmp)
  (try
    (do (def seed (seed-record (get opts :seed)))
        (def world (get opts :world))
        (unless (and (obj? world) (obj? (get world :chunks))
                     (pos? (world/world-chunk-count world)))
          (fail "new slot requires a built world with at least one chunk"))
        (unless (= (get world :seed) (get seed :value)) (fail "world seed mismatch"))
        (stage-save tmp id (random-id) world (get opts :player) opts)
        (os/rename tmp target)
        id)
    ([e] (error e))))
(defn load-slot [root id]
  (def m (load-manifest root id))
  (def snapshot-dir (string (slot-dir root id) "/" (get m :snapshot)))
  (checked-dir snapshot-dir)
  (def path (string snapshot-dir "/" region-name))
  (def bytes (bytes-of path max-region-bytes))
  (def crc (integrity/crc32 bytes))
  (unless (= crc (get m :region-crc)) (fail "region CRC mismatch"))
  (def learned? (= learned-provider (get m :provider)))
  (def session (if learned?
                 (identity/diffusion-identity (get (get m :artifact) :identity)
                                              (get (get m :seed) :value))
                 (identity/procedural-identity
                   (get (get m :seed) :value) (get m :settings-identity))))
  (unless (= :match (get (identity/gate path session crc) :status))
    (fail "region identity mismatch or missing sidecar"))
  # Decode exactly the checked bytes, not a second path read.
  (def entries (region/inspect bytes))
  (def world (world/world-new))
  (put world :seed (get (get m :seed) :value))
  (each item entries
    (def blocks (region/decode-chunk
                  (region/slice-bytes bytes (get item :offset) (get item :length))))
    (def ch (world/chunk-new (get item :cx) (get item :cz)))
    (put ch :blocks blocks)
    (world/world-put-chunk world ch))
  (if learned?
    (let [artifact-dir (artifact-path snapshot-dir)]
      (verify-artifact artifact-dir (get world :seed) (get m :artifact))
      {:world world :player (get m :player) :manifest m :artifact-dir artifact-dir})
    {:world world :player (get m :player) :manifest m}))
(defn save-slot [root id world player opts]
  (def dir (slot-dir root id))
  (checked-dir dir)
  (def loaded (load-slot root id))
  (def old (get loaded :manifest))
  (unless (= (get world :seed) (get (get old :seed) :value))
    (fail "cannot change an existing world's seed"))
  (def supplied (or opts {}))
  (def learned? (= learned-provider (get old :provider)))
  (unless (or learned? (= :procedural (get old :provider))) (fail "provider unavailable"))
  (when (or (not (obj? supplied))
            (some (fn [key] (not= key :settings)) (keys supplied)))
    (fail "save options may only contain settings"))
  (when (and (has-key? supplied :settings)
             (not= (let [s (get supplied :settings)]
                     (if learned? (learned-settings s)
                         (procedural-settings s (get old :settings-version))))
                   (get old :settings)))
    (fail "cannot change generation settings of existing world"))
  # The OLD manifest's settings version is carried forward, never re-derived, so a
  # v1 snapshot re-saved stays v1 and a v2 stays v2. An upgrade is a deliberate
  # act with its own identity, not a side effect of pressing save.
  (def chosen {:seed (get old :seed) :name (get old :name)
               :provider (get old :provider) :profile (get old :profile)
               :settings (or (get supplied :settings) (get old :settings))
               :settings-version (get old :settings-version)
               :artifact (get old :artifact) :artifact-dir (get loaded :artifact-dir)})
  # Stage immutable region and identity; publish the manifest pointer last.
  (when (os/lstat (string dir "/manifest.janet.tmp"))
    (fail "pending manifest exists"))
  (def result (stage-save dir id (random-id) world player chosen))
  (prune-snapshots dir (get result :snapshot) (get old :snapshot))
  result)
(defn list-slots [root]
  (checked-dir root)
  (def names (os/dir root))
  (when (> (length names) max-slots) (fail "too many catalogue entries"))
  (def result @[])
  (each id names
    (when (safe-id? id)
      (def dir (string root "/" id))
      (if (not= :directory (os/lstat dir :mode))
        (array/push result {:id id :status :incompatible :reason "linked or invalid directory"})
        (let [attempt (try [true (load-manifest root id)] ([e] [false (string e)]))]
          (if (get attempt 0)
            (let [manifest (get attempt 1)]
              (if (= learned-provider (get manifest :provider))
                (let [verified (try [true (load-slot root id)]
                                    ([e] [false (string e)]))]
                  (if (get verified 0)
                    (array/push result {:id id :status :ready :manifest manifest})
                    (array/push result {:id id :status :incompatible
                                        :reason (get verified 1)})))
                (array/push result {:id id :status :ready :manifest manifest})))
            (array/push result {:id id :status :incompatible :reason (get attempt 1)}))))))
  result)
