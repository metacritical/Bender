# Trinecraft — in-game developer console.
#
# A Quake-style console on `~` that evaluates Janet against the LIVE game
# state, so the world can be inspected and reshaped without restarting.
#
# The binding constraint is that the REPL must never block. raylib's window
# and GL context belong to the main thread, so a conventional stdin REPL would
# stop the frame loop and the OS would mark the window unresponsive. This
# console instead evaluates BETWEEN frames inside the existing loop, and takes
# input from raylib's own key and character queues rather than from stdin.
#
# Everything in this file above the rendering section is pure logic over a
# state table: no raylib call is made while handling input or evaluating, so
# the whole console is testable headless.

(import ./rl :as rl)

(def max-scrollback 400)
(def max-history 100)
(def prompt-text "> ")

#
# --- State --------------------------------------------------------------
#

(defn console-new []
  @{:open false
    :input @""          # the line being edited
    :cursor 0           # caret index within :input
    :lines @[]          # scrollback, newest last: @{:text :kind}
    :history @[]        # submitted lines, newest last
    :history-index nil  # nil when editing a fresh line
    :stash nil          # the in-progress line parked while browsing history
    :scroll 0           # lines scrolled back from the bottom
    :env nil})

(defn emit
  ``Append a line of scrollback. `kind` is :echo, :out, :value, :error or
  :info, used only to colour it at draw time.``
  [c text &opt kind]
  (default kind :out)
  (each line (string/split "\n" (string text))
    (array/push (c :lines) @{:text line :kind kind}))
  # Trim from the front so a runaway loop printing forever cannot exhaust
  # memory; the console is a debugging tool and must not become the bug.
  (while (> (length (c :lines)) max-scrollback)
    (array/remove (c :lines) 0))
  c)

(defn clear-scrollback [c]
  (array/clear (c :lines))
  (set (c :scroll) 0)
  c)

#
# --- Environment --------------------------------------------------------
#

(defn bind!
  ``Build the evaluation environment from a table of symbol -> value.

  `parent` is the environment the console inherits from, and should normally
  be the caller's `(curenv)`. That matters more than it looks: inheriting the
  caller's env is what makes the engine modules reachable, so a developer can
  type `(world/world-get-block world 0 40 0)` rather than only being able to
  poke at whatever values were explicitly injected. Defaulting to root-env
  alone would expose the Janet stdlib and nothing of the game.

  The env is created once and reused, so `def`s entered at the console persist
  across submissions exactly as they do in a normal REPL. Injected values are
  the live game tables, so mutating one through the console mutates the
  running game.``
  [c bindings &opt parent]
  (def env (make-env (or parent root-env)))
  (eachp [sym value] bindings
    (put env sym @{:value value}))
  (set (c :env) env)
  c)

(defn define!
  "Add or replace one binding in an existing console environment."
  [c sym value]
  (put (c :env) sym @{:value value})
  c)

#
# --- Evaluation ---------------------------------------------------------
#

(defn evaluate
  ``Evaluate a source string against the console environment.

  Returns @{:ok bool :output string :value any :error any}. The work happens
  inside a fiber created with the :e signal mask, which traps BOTH runtime
  errors and compile errors, so no console input can take the game down.
  Rebinding :out to a buffer inside that fiber captures anything the code
  prints instead of letting it escape to the terminal.``
  [c code]
  (def out @"")
  (def fib
    (fiber/new
      (fn []
        (setdyn :out out)
        (eval-string code))
      :e))
  (fiber/setenv fib (c :env))
  (def result (resume fib))
  (if (= (fiber/status fib) :error)
    @{:ok false :output (string out) :error result}
    @{:ok true :output (string out) :value result}))

(defn- describe-error [err]
  (if (bytes? err) (string err) (string/format "%q" err)))

(defn submit
  ``Run the current input line: echo it, evaluate it, record the result and
  push it onto the history. Blank lines are ignored.``
  [c]
  (def code (string (c :input)))
  (set (c :input) @"")
  (set (c :cursor) 0)
  (set (c :history-index) nil)
  (set (c :stash) nil)
  (set (c :scroll) 0)
  (if (= "" (string/trim code))
    c
    (do
      (emit c (string prompt-text code) :echo)
      # Keep history free of immediate duplicates: holding Up through a long
      # session is useless when the same line repeats.
      (when (not= code (last (c :history)))
        (array/push (c :history) code))
      (while (> (length (c :history)) max-history)
        (array/remove (c :history) 0))
      (def r (evaluate c code))
      (when (not= "" (r :output))
        (emit c (string/trimr (r :output) "\n") :out))
      (if (r :ok)
        (unless (nil? (r :value))
          (emit c (string/format "%q" (r :value)) :value))
        (emit c (string "error: " (describe-error (r :error))) :error))
      c)))

#
# --- Line editing -------------------------------------------------------
#

(defn insert-char
  "Insert a unicode codepoint at the caret."
  [c codepoint]
  (def s (string/from-bytes codepoint))
  (def input (c :input))
  (def at (c :cursor))
  (set (c :input) (buffer (string/slice input 0 at) s (string/slice input at)))
  (set (c :cursor) (+ at (length s)))
  c)

(defn backspace [c]
  (def at (c :cursor))
  (when (pos? at)
    (def input (c :input))
    (set (c :input) (buffer (string/slice input 0 (- at 1))
                            (string/slice input at)))
    (set (c :cursor) (- at 1)))
  c)

(defn delete-forward [c]
  (def at (c :cursor))
  (def input (c :input))
  (when (< at (length input))
    (set (c :input) (buffer (string/slice input 0 at)
                            (string/slice input (+ at 1)))))
  c)

(defn move-cursor [c delta]
  (def n (+ (c :cursor) delta))
  (set (c :cursor) (max 0 (min (length (c :input)) n)))
  c)

(defn cursor-home [c] (set (c :cursor) 0) c)
(defn cursor-end [c] (set (c :cursor) (length (c :input))) c)

(defn kill-line
  "Ctrl-U: discard the whole line, like a shell."
  [c]
  (set (c :input) @"")
  (set (c :cursor) 0)
  c)

#
# --- History ------------------------------------------------------------
#

(defn history-prev
  ``Step back through submitted lines. The line currently being typed is
  stashed on the first step so returning past the newest entry restores it,
  rather than silently destroying unsent input.``
  [c]
  (def h (c :history))
  (when (pos? (length h))
    (when (nil? (c :history-index))
      (set (c :stash) (string (c :input))))
    (def idx (if (nil? (c :history-index))
               (- (length h) 1)
               (max 0 (- (c :history-index) 1))))
    (set (c :history-index) idx)
    (set (c :input) (buffer (get h idx)))
    (set (c :cursor) (length (c :input))))
  c)

(defn history-next [c]
  (def h (c :history))
  (unless (nil? (c :history-index))
    (def idx (+ (c :history-index) 1))
    (if (>= idx (length h))
      (do
        (set (c :history-index) nil)
        (set (c :input) (buffer (or (c :stash) "")))
        (set (c :stash) nil))
      (do
        (set (c :history-index) idx)
        (set (c :input) (buffer (get h idx)))))
    (set (c :cursor) (length (c :input))))
  c)

#
# --- Scrolling ----------------------------------------------------------
#

(defn scroll-by [c delta visible]
  (def limit (max 0 (- (length (c :lines)) visible)))
  (set (c :scroll) (max 0 (min limit (+ (c :scroll) delta))))
  c)

(defn visible-lines
  "The slice of scrollback to draw, given how many rows fit."
  [c rows]
  (def total (length (c :lines)))
  (def end (max 0 (- total (c :scroll))))
  (def start (max 0 (- end rows)))
  (array/slice (c :lines) start end))

#
# --- Input pump ---------------------------------------------------------
#

(defn toggle! [c]
  (set (c :open) (not (c :open)))
  c)

(defn handle-key
  ``Dispatch one raw keycode. Returns :closed when this key dismissed the
  console, so the caller can restore game input and recapture the mouse.``
  [c key rows]
  (cond
    (or (= key rl/key-enter) (= key rl/key-kp-enter)) (do (submit c) nil)
    (= key rl/key-backspace) (do (backspace c) nil)
    (= key rl/key-delete) (do (delete-forward c) nil)
    (= key rl/key-left) (do (move-cursor c -1) nil)
    (= key rl/key-right) (do (move-cursor c 1) nil)
    (= key rl/key-up) (do (history-prev c) nil)
    (= key rl/key-down) (do (history-next c) nil)
    (= key rl/key-home) (do (cursor-home c) nil)
    (= key rl/key-end) (do (cursor-end c) nil)
    (= key rl/key-page-up) (do (scroll-by c rows rows) nil)
    (= key rl/key-page-down) (do (scroll-by c (- rows) rows) nil)
    # ESC dismisses the console. raylib would otherwise close the window on
    # ESC, which is why main calls set-exit-key 0.
    (= key rl/key-escape) (do (set (c :open) false) :closed)
    (= key rl/key-grave) (do (set (c :open) false) :closed)
    nil))

(defn pump-input
  ``Drain raylib's key and character queues for this frame.

  Both queues must be read in a loop until they return 0, or input is lost
  whenever more than one event lands in a frame. Characters are handled after
  keys so a codepoint is never inserted by the same keystroke that closed the
  console.``
  [c rows]
  (var closed false)
  (var key (rl/key-pressed))
  (while (not= key 0)
    (when (= :closed (handle-key c key rows)) (set closed true))
    (set key (rl/key-pressed)))
  (var ch (rl/char-pressed))
  (while (not= ch 0)
    # The ` and ~ codepoints are the toggle key; never type them into the
    # line, or opening the console would immediately insert a stray char.
    (unless (or closed (= ch 96) (= ch 126))
      (insert-char c ch))
    (set ch (rl/char-pressed)))
  (if closed :closed nil))

(defn drain-input
  "Discard queued input, so the keystroke that opened the console is not typed."
  []
  (while (not= 0 (rl/key-pressed)))
  (while (not= 0 (rl/char-pressed))))

#
# --- Rendering ----------------------------------------------------------
#
# Kept separate from everything above: no function here is needed to test the
# console's behaviour.

(def line-height 18)
(def font-size 16)
(def pad 8)

(def kind-colors
  {:echo [0x9a 0xd8 0xff 0xff]
   :out [0xe0 0xe0 0xe0 0xff]
   :value [0xa8 0xf0 0xa0 0xff]
   :error [0xff 0x92 0x82 0xff]
   :info [0xf0 0xd0 0x60 0xff]})

(defn rows-for-height [height]
  (max 1 (- (math/floor (/ (- height (* 2 pad)) line-height)) 1)))

(defn draw [c width height]
  (when (c :open)
    (def rows (rows-for-height height))
    (rl/draw-rectangle 0 0 width height [0x0a 0x0e 0x14 0xee])
    (rl/draw-rectangle 0 (- height 2) width 2 [0x3a 0x5a 0x7a 0xff])

    (def shown (visible-lines c rows))
    (var y pad)
    (each line shown
      (rl/draw-text (line :text) pad y font-size
                    (get kind-colors (line :kind) (kind-colors :out)))
      (+= y line-height))

    # Input line, pinned to the bottom.
    (def iy (- height line-height pad))
    (def text (string prompt-text (c :input)))
    (rl/draw-text text pad iy font-size [0xff 0xff 0xff 0xff])
    # Caret: measure the text up to the caret so it lands correctly whatever
    # the glyph widths are.
    (def before (string prompt-text (string/slice (c :input) 0 (c :cursor))))
    (def caret-x (+ pad (rl/measure-text before font-size)))
    (rl/draw-rectangle caret-x iy 2 font-size [0xff 0xd0 0x40 0xff])

    (when (pos? (c :scroll))
      (def note (string/format "-- scrolled %d --" (c :scroll)))
      (rl/draw-text note (- width (rl/measure-text note font-size) pad) pad
                    font-size [0xf0 0xd0 0x60 0xff]))))

#
# --- Banner -------------------------------------------------------------
#

(defn greet [c]
  (emit c "Trinecraft console -- Janet over the live game state." :info)
  (emit c "(help) lists the available bindings.  ESC or ~ closes." :info)
  c)
