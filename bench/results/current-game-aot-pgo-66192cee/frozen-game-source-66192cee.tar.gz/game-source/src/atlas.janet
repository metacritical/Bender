# Procedural 4x4 block atlas. Image construction is CPU-only; upload needs GL.
(import ./rl :as rl)
(import ./world :as world)
(import ./material-recipes :as recipes)

(def atlas-cols 4)
(def atlas-rows 4)
(def tile-pixels 16)
(def atlas-width (* atlas-cols tile-pixels))
(def atlas-height (* atlas-rows tile-pixels))

# Tile 0 is reserved for air; grass occupies three separate slots.
(defn tile-for [block-id face]
  (case block-id
    1 1 # stone
    2 2 # dirt
    3 (if (= face 4) 3 (if (= face 5) 2 4))
    4 5 # sand
    5 6 # water
    6 7 # wood
    7 8 # leaves
    8 9 # snow
    0))

# Tuple literals are created once, not in the mesher's face loop.
(def tile-rects
  (map (fn [i]
         (let [x (mod i atlas-cols) y (math/floor (/ i atlas-cols))]
           [(/ x atlas-cols) (/ y atlas-rows)
            (/ (+ x 1) atlas-cols) (/ (+ y 1) atlas-rows)]))
       (range (* atlas-cols atlas-rows))))

(def face-rects
  (map (fn [block]
         (map (fn [face] (get tile-rects (tile-for block face)))
              (range 6)))
       (range 9)))

(defn face-uv [block-id face]
  (get (get face-rects block-id) face))

(defn inset-uv [rect px]
  (let [du (/ px atlas-width) dv (/ px atlas-height)
        u0 (get rect 0) v0 (get rect 1)
        u1 (get rect 2) v1 (get rect 3)]
    [(min (+ u0 du) (/ (+ u0 u1) 2))
     (min (+ v0 dv) (/ (+ v0 v1) 2))
     (max (- u1 du) (/ (+ u0 u1) 2))
     (max (- v1 dv) (/ (+ v0 v1) 2))]))

(def image-offsets (map |($ :offset) ((ffi/struct-info rl/image-type) :fields)))

# Tile 4 is a grass cap over dirt; sample both layers from the recipe map.
(def tile-materials [:stone :dirt :grass :grass-side :sand :water :wood :leaves :snow])
(defn tile-sample [recipe-map tile x y]
  (let [material (get tile-materials (- tile 1))
        layer (if (= material :grass-side)
                (if (< y 4) :grass :dirt)
                material)]
    (if (and (= material :grass-side)
             (deep= (get recipe-map :grass) (get recipes/recipes :grass))
             (deep= (get recipe-map :dirt) (get recipes/recipes :dirt)))
      # Reference-inspired c3c3374 seed-4 side cap; binary provenance unverified.
      (let [n (mod (+ (* (+ x 4) 73856093) (* (+ y 4) 19349663)
                      (* (+ x 4) (+ y 4) 83492791)) 17)]
        (cond
          (< y 4) (if (< n 4) [51 140 47 255] [80 168 62 255])
          (= y 4) [95 64 39 255]
          (< n 2) [95 64 39 255]
          (> n 14) [157 111 71 255]
          [125 85 52 255]))
      (recipes/sample (get recipe-map layer) x y))))

(defn paint-tile [image tile recipe-map]
  (let [ox (* (mod tile atlas-cols) tile-pixels)
        oy (* (math/floor (/ tile atlas-cols)) tile-pixels)]
    (for y 0 tile-pixels
      (for x 0 tile-pixels
        (rl/image-draw-rectangle image (+ ox x) (+ oy y) 1 1
                                 (tile-sample recipe-map tile x y))))))

(defn build-atlas-image [&opt recipe-map]
  (let [recipe-map (if (nil? recipe-map) recipes/recipes recipe-map)
        raw (rl/gen-image-color atlas-width atlas-height [0 0 0 0])
        image (buffer/new-filled (ffi/size rl/image-type) 0)]
    # raylib's ImageDrawRectangle takes Image*, unlike the by-value upload APIs.
    (each i (range 5)
      (ffi/write (get [:ptr :int :int :int :int] i) (get raw i) image (get image-offsets i)))
    (for tile 1 10 (paint-tile image tile recipe-map))
    image))

(defn load-atlas-texture [&opt recipe-map]
  # This function alone requires an initialized raylib window/GL context.
  (let [image (build-atlas-image recipe-map)
        value (ffi/read rl/image-type image)
        texture (rl/load-texture-from-image value)]
    (rl/set-texture-filter texture rl/texture-filter-point)
    (rl/unload-image value)
    texture))
