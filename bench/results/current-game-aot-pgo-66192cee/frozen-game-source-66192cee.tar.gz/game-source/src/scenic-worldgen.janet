# Trinecraft -- scenic map decoration: surface material and conifers.
#
# This module owns ONE chunk's contents given a height function. It does not
# own the height field, the water, the cache, or the stream: `height-at` is a
# caller-supplied `(fn [wx wz] -> height|nil)` over GLOBAL coordinates, and nil
# means "this map does not cover that point".
#
# Three rules shape everything below.
#
#   * WRITE ONLY YOUR OWN CHUNK. A conifer's canopy crosses chunk borders, so a
#     tree anchored at the edge of chunk A must also appear in chunk B. Rather
#     than reach into the neighbour (which would make the result depend on
#     generation order and on who ran first), every chunk independently
#     recomputes the SAME anchors from world coordinates and writes only the
#     cells that fall inside itself. Order-independence is then structural, not
#     something to be tested into place -- though it is tested anyway.
#
#   * NEVER INVENT TERRAIN. Where `height-at` returns nil the column stays air.
#     A map edge is a real edge; filling it with plausible-looking ground would
#     make absence indistinguishable from data.
#
#   * HEIGHTS ARE THE CALLER'S. Trees decorate above the ground; nothing here
#     ever writes the height function's value, so an on-disk height tile and the
#     rendered world cannot disagree.
#
# The snow and tree lines are AUTHORED constants, not a climate model. They
# describe where this scene puts snow, and nothing more.
#
# --- Opt-in biome surface policy ---------------------------------------
#
# `climate-biome` classifies a column; `biome-surface` maps a biome to existing
# block ids. Both are pure and neither was wired into a generator before this.
#
# OFF BY DEFAULT. `:surface-policy` nil means the legacy ladder, byte for byte.
# A caller names an authored version (`:v1`) and supplies `:climate-at`, an
# explicit `(fn [wx wz] -> reader answer)` over GLOBAL coordinates. This module
# imports no cache and holds no attached state; a caller with a cache binds
# `(fn [wx wz] (tc/climate-at-world cache wx wz))` at its own call site.
#
# THE CALLBACK MUST BE SIDE-EFFECT FREE AND MAY BE CALLED ONCE PER COLUMN. It is
# invoked only when a policy is selected, at increasing column order, and its
# answer is used immediately -- not cached, not retained. A reader that mutates
# state, yields, or assumes a single call per chunk will misbehave; a pure lookup
# (a decoded grid, a const, a closure over one) is the intended shape.
#
# ONE PRECEDENCE, TESTED. (1) Water fill is untouched: the ceiling stays
# `max(hh, sea)` and the policy's `:water?` flag is IGNORED, because this module
# already owns the sea fill from `:sea-level` -- honouring a second source would
# put water above sea level. (2) Snow still wins the top at or above
# `:snow-line`; the subsoil below it follows the policy. (3) When a policy
# resolves, it replaces the rock, shore and grass arms and owns the three-block
# subsoil band. (4) Otherwise the legacy ladder runs unchanged.
#
# A COLUMN CHANGES ONLY ON COMPLETE EVIDENCE: policy selected, reader present,
# sample usable, classifier `:classified`, and a policy entry for that biome.
# Anything short of all five keeps the legacy material. A malformed or
# unsupported reader answer is never an error and never an invented biome --
# reading is caller code and must not crash chunk generation.
#
# HEIGHT IS NEVER AFFECTED. Only the id at the surface and in the subsoil band
# changes; the height field is still the caller's.
#
# NO PARTIAL WRITES. The version and reader are validated BEFORE the buffer is
# cleared, so a refused policy leaves the caller's buffer exactly as it was.
#
# NOT PRODUCTION-WIRED. No provider, catalogue, world setting or save field; this
# module adds no setting key. A saved world would have to record
# `surface-policy/1`'s `:surface-revision` before a policy surface could be
# trusted on load, and that is deliberately out of scope here.

(import ./world :as world)
(import ./worldgen :as worldgen)
(import ./climate-biome :as bio)
(import ./biome-surface :as surf)

#
# --- Configuration ------------------------------------------------------
#

(def defaults
  {:seed 0
   :sea-level 28
   :snow-line 52        # authored: snow at or above this height
   :tree-line 48        # authored: no trees at or above this height
   :lattice 5           # anchor spacing in blocks; jitter keeps it off-grid
   :density 45          # percent of lattice cells that grow a tree
   :rock-slope 4        # height drop over one block that reads as a cliff
   :tree-slope 2        # steeper than this and no tree takes root
   :trunk-min 6
   :trunk-span 5
   :clearing-density 0  # authored percent of coarse cells holding a clearing
   # No biome surface policy unless a caller names a supported authored version.
   # `nil` is the legacy alpine ladder, byte for byte.
   :surface-policy nil})

(defn- opt [opts k]
  (let [v (get opts k)] (if (nil? v) (get defaults k) v)))

#
# --- The authored surface policy vocabulary ----------------------------
#
# A VERSION, NOT A BOOLEAN. "Use biome surfaces" is not one decision: the biome
# vocabulary, the thresholds behind it and the material choices can each move, and
# a world built under one set is not a world built under another. Naming the
# version is what makes a surface reproducible later, and what lets a future
# revision land without changing what `:v1` means.
#

(def surface-policy-versions
  ``Every authored surface-policy version this module can honour.

  A caller passes one of these as `:surface-policy`. Anything else -- including a
  plausible-looking `:v2` -- raises, so a version this code does not implement is
  never mistaken for one it does.``
  [:v1])

(def surface-policy/1
  ``What `:v1` means, stated once so a stored surface can be traced.

  The authority for the CLASSIFICATION is `climate-biome` and the authority for
  the MATERIALS is `biome-surface`; this module contributes no thresholds and no
  material choices of its own, only the precedence in the header comment. The
  revisions travel with the version because a classification or material change
  under the same version name would make two identically-labelled surfaces
  disagree.``
  {:version :v1
   :authority [:climate-biome :biome-surface]
   :provenance :authored
   :biome-revision bio/biome-revision
   :surface-revision surf/surface-revision
   :climate-key :status})

(defn surface-policy-version
  ``Resolve `:surface-policy` to a supported version keyword, or nil for legacy.

  Absent or nil is NOT an error: that is every existing scene and every saved
  world, and it must keep the legacy ladder exactly. A present value that is not
  a supported version raises instead of degrading, because the two failure modes
  are not symmetric -- silently ignoring a typo leaves the caller believing a
  policy is in force, while raising tells them it is not.``
  [opts]
  (def v (get (or opts {}) :surface-policy))
  (cond
    (nil? v) nil
    (some |(= v $) surface-policy-versions) v
    (error (string "surface-policy: unsupported version "
                   (string/format "%q" v) "; supported: "
                   (string/format "%q" surface-policy-versions)))))

(defn climate-reader-status
  ``Why a column's surface did or did not come from the biome policy.

  Callers get one table instead of reaching into the precedence rules:

    :selectable?  a supported `:surface-policy` version was named
    :policy       that version, or nil for the legacy ladder
    :reads?       a `:climate-at` function was supplied
    :sampled?     both of the above hold, so columns WILL consult the reader

  When `:sampled?` is false the chunk is legacy terrain, full stop -- there is no
  per-column sampling to explain, which is the answer most useful to a caller
  debugging "why is my policy not showing up". A policy with no reader is a
  legitimate configuration, not an error, so it is reported rather than raised.``
  [opts]
  (def o (or opts {}))
  (def policy (surface-policy-version o))
  (def reader (get o :climate-at))
  (def reads (truthy? reader))
  (when (and reads (not (function? reader)))
    (error "climate-at must be a function of (wx, wz)"))
  {:selectable? (not (nil? policy))
   :policy policy
   :reads? reads
   :sampled? (and (not (nil? policy)) reads)})

(defn scene-opts
  ``Options for one scene, derived from the MAP's declared metadata.

  The sea level belongs to the map, not to this module: a scenic artifact
  carries `sea_level` (and the rest of its mapping) in the map record beside its
  twin (currently `provenance.json`), computed once from the raw export. Hardcoding 28 here would put the waterline
  in the wrong place for any map whose mapping differs -- and silently, since
  the result still looks like plausible terrain.

  Takes a mapping record and returns a plain opts table. Missing keys fall back
  to the module defaults, so a partial mapping is usable. The snow and tree
  lines are NOT taken from the metadata: those are authored scene choices made
  after the raw profile is known, and are passed explicitly.

  `meta` accepts either `:sea-level` or `:sea_level`, because the Python side
  spells it with an underscore and Janet code with a hyphen.``
  [meta &opt extra]
  (def m (or meta {}))
  (def e (or extra {}))
  # Precedence, lowest first: module defaults, then the map's metadata, then
  # the caller's authored options. Authored wins because it is the explicit
  # decision; the metadata is a property of the artifact, not a request.
  (def out @{})
  (each k (keys defaults) (put out k (get defaults k)))
  (each [k v] (pairs m) (when (and (keyword? k) (not (nil? v))) (put out k v)))
  (each [k v] (pairs e) (when (not (nil? v)) (put out k v)))
  # The Python side spells it `sea_level`; Janet code uses a hyphen. Accept
  # both, and let an authored :sea-level (already applied above) win.
  (when (and (nil? (get e :sea-level)) (nil? (get e :sea_level)))
    (def sea (let [a (get m :sea-level) b (get m :sea_level)]
               (if (number? a) a (if (number? b) b nil))))
    (when (number? sea) (put out :sea-level sea)))
  out)

#
# --- Height sampling ----------------------------------------------------
#
# One 18x18 sample covers the chunk plus a one-block margin, so every slope
# query is answered from memory instead of from a fresh callback call. Without
# the margin, slopes at the chunk border would need neighbour chunks -- exactly
# the cross-chunk dependency the design avoids.
#

(def grid-n 18)

(defn- gid [x z] (+ (+ x 1) (* (+ z 1) grid-n)))

(defn- sample-grid
  ``Chunk heights plus a one-block margin, indexed by -1..16 in each axis.

  `nil` is preserved as nil: an uncovered point is absence, not height 0.``
  [cx cz height-at]
  (def g (array/new-filled (* grid-n grid-n)))
  (def bx (* cx world/chunk-x))
  (def bz (* cz world/chunk-z))
  (for z -1 (inc world/chunk-z)
    (for x -1 (inc world/chunk-x)
      (put g (gid x z) (height-at (+ bx x) (+ bz z)))))
  g)

(defn- slope-at
  ``Largest height difference against the four orthogonal neighbours.

  Missing neighbours contribute nothing rather than being treated as height 0,
  so a map edge does not read as a cliff.``
  [grid x z]
  (def h (get grid (gid x z)))
  (if (nil? h)
    0
    (let [h h]
      (var s 0)
      (each [dx dz] [[1 0] [-1 0] [0 1] [0 -1]]
        (def n (get grid (gid (+ x dx) (+ z dz))))
        (when n (set s (max s (math/abs (- h n))))))
      s)))

#
# --- Base scene ---------------------------------------------------------
#

(defn- top-block [h slope opts]
  (def sea (opt opts :sea-level))
  (cond
    (>= h (opt opts :snow-line)) world/block-snow
    (>= slope (opt opts :rock-slope)) world/block-stone
    (<= h (+ sea 1)) world/block-sand      # shoreline, never snow
    world/block-grass))

(defn- column-surface
  ``The policy surface for ONE column as `[top subsoil]`, or nil.

  Answers only when every step of the chain answers: a reader is supplied, the
  reader reports a usable sample at this GLOBAL column, the classifier returns
  `:classified` for the column's real height, and the policy holds materials for
  that biome. Every other outcome is nil, so the column keeps the terrain it
  already had.

  TWO SAMPLE STATUSES, ONE MEANING. `climate-tile/read` (a validated buffer)
  answers `:present`, while `climate-tile/sample` -- which is what
  `terrain-cache/climate-at-world` returns verbatim -- answers `:sampled` for an
  inside cell. Both mean "here are five channels", so both are accepted. Gating on
  `:present` alone silently degraded every column to legacy terrain for a caller
  that bound the real cache API, which is precisely the wiring most callers will
  use; the tests therefore cover both shapes.

  Climate coverage is finite and this is deliberately total. A map covers a
  limited area, a caller may hand over a coarser grid than the world, and the
  units behind the thresholds may be unverified. None of those may become an
  invented biome or a default material, because inventing one would rewrite
  terrain on a weakening of evidence.``
  [reader wx wz elevation sea]
  (def answer (reader wx wz))
  (def values (get answer :values))
  (def status (get answer :status))
  (if (or (nil? values)
          (not (some |(= status $) [:present :sampled])))
    nil
    (let [result (bio/classify values elevation sea)]
      (if (not (bio/classified? result))
        nil
        (let [s (surf/surface result elevation sea)]
          (if (surf/classified? s)
            [(s :top) (s :subsoil)]
            nil))))))

(defn fill
  ``Fill one chunk's columns: stone body, soil cap, and a surface block.

  Steep ground gets stone for its top three blocks instead of soil, so a cliff
  reads as rock rather than as a grass wall. Water fills to sea level exactly
  as the legacy generator does, so a scenic chunk and a legacy chunk agree
  about what an underwater column contains.

  With a `:surface-policy` selected AND a `:climate-at` reader AND a classified
  sample for the column, the policy's top and subsoil replace the rock, shore and
  grass arms. Snow still wins the top, and the water fill above the ground is
  untouched -- see the precedence rules in the header comment. With no policy, or
  with a column the reader cannot answer, the legacy ladder runs unchanged.``
  [blocks cx cz height-at opts]
  (def sea (opt opts :sea-level))
  (def rock-slope (opt opts :rock-slope))
  (def snow-line (opt opts :snow-line))
  (def top-y (dec world/chunk-y))
  # Resolved ONCE per chunk, and only then is the reader even looked at: a scene
  # with no policy must not pay a single sampling call, and an unsupported
  # version must raise here rather than after a chunk of work.
  (def policy (surface-policy-version opts))
  (def reader (when policy (get opts :climate-at)))
  (when (and reader (not (function? reader)))
    (error "climate-at must be a function of (wx, wz)"))
  (def bx (* cx world/chunk-x))
  (def bz (* cz world/chunk-z))
  (def g (sample-grid cx cz height-at))
  # Clear once, then write only up to each column's ceiling. Writing air for
  # every cell above the terrain meant 65536 stores per chunk at a 256-tall
  # world -- 9 ms, more than a whole frame -- for blocks that are already air.
  (buffer/fill blocks world/block-air)
  (for z 0 world/chunk-z
    (for x 0 world/chunk-x
      (def h (get g (gid x z)))
      (when h
        (def slope (slope-at g x z))
        (def steep (>= slope rock-slope))
        # Clamp BEFORE classifying: the elevation handed to the classifier must
        # be the height this chunk actually writes, or a 300-block column in a
        # 64-tall chunk would be classified as alpine terrain it never renders.
        (def hh (min h top-y))
        (def ps (when reader (column-surface reader (+ bx x) (+ bz z) hh sea)))
        (def surface
          (cond
            # The authored snow line outranks any biome: it is a scene decision
            # about where THIS vista puts snow, and every existing snowy world
            # must keep its cap.
            (>= h snow-line) world/block-snow
            ps (get ps 0)
            (top-block h slope opts)))
        (def subsoil
          (if ps (get ps 1) (if steep world/block-stone world/block-dirt)))
        # Water reaches sea level even below the ground, so the ceiling is the
        # taller of the surface and the water line.
        (def ceiling (min top-y (max hh sea)))
        (for y 0 (inc ceiling)
          (def id
            (cond
              (> y hh) world/block-water
              (= y 0) world/block-stone
              (= y hh) surface
              (>= y (- hh 3)) subsoil
              world/block-stone))
          (put blocks (world/block-index x y z) id)))))
  blocks)

#
# --- Clearings ----------------------------------------------------------
#
# A clearing is a CONNECTED opening in the forest, not a scatter of skipped
# anchors. That distinction is the whole reason this is a coarse-cell predicate
# rather than another per-anchor hash gate: suppressing anchors independently
# produces salt-and-pepper noise that reads as a rendering bug, while a disk
# reads as a glade.
#
# The predicate is a pure function of the SEED and the WORLD point -- never of
# the chunk, the generation order, or which neighbour ran first -- so a disk
# crossing a chunk border is recomputed identically on both sides, exactly as the
# tree anchors are. A query widens to every cell whose disk could reach the
# point; the radius is held to at most half a cell so that scan stays a small
# constant and a disk can never reach past the cells examined.
#
# AUTHORED, NOT LEARNED. This is a scene choice made on request, in the same
# family as the snow and tree lines. It is not model climate, not a biome
# classifier, and it reads no artifact: nothing here samples or infers anything.
#
# OPT-IN AND OFF BY DEFAULT. `:clearing-density` is 0 unless a caller passes it,
# and at 0 the predicate answers false without touching the hash, so every
# existing scene renders byte for byte as before. There is deliberately NO
# production control for this yet: exposing a knob means versioning world
# settings and the catalogue identity alongside it, so for now the module API is
# the only entry point.
#
# And clearings are NOT derived from `:forest-density`. Reading one authored
# knob out of another would silently change the scenery of worlds already saved
# with a forest density, which no version bump authorized.
#
# THE NUMBER IS A FREQUENCY, NOT AN AREA. `:clearing-density` is the percent of
# coarse CELLS that host a clearing -- a probability over cells -- and it is
# emphatically not the percent of ground that ends up cleared. Measured on seed
# 7 over a 800x800 block square: density 1 clears 0.3% of the area, 25 clears
# 7.5%, 50 clears 15.2%, and 99 clears 30.0%. The ceiling is under a third
# because one disk of radius 10 covers 317 of a cell's 1024 blocks and a cell
# hosts at most one: a coverage-percentage reading of this number would be wrong
# by up to 3x at the top of the range. Any future UI label must say something
# like "clearing frequency" and must not print a percent of area.

(def clearing-cell 32)      # coarse world cell that may host one clearing, in blocks
(def clearing-radius 10)    # disk radius in blocks; <= half a cell, so disks stay local

(defn- clearing-density [opts]
  ``The authoritative gate for this scene, validated on every query.

  The value is the percent of coarse CELLS that host a clearing, not a
  percentage of cleared ground; see the note above this function.

  A malformed value raises rather than being clamped: a silent 0 would turn a
  typo into "no clearings" and a silent 100 into "no forest", and neither would
  be visible in the result.``
  (def d (opt opts :clearing-density))
  (assert (and (number? d) (= d (math/floor d)) (<= 0 d 100))
          "clearing density must be an integer percent in 0..100")
  d)

(defn- cell-hosts-clearing?
  "Does coarse cell `cxi,czi` carry a clearing at this density?"
  [seed cxi czi density]
  (< (mod (worldgen/hash2 (+ seed 4057) cxi czi) 100) density))

(defn- cell-clearing-center
  "The clearing point inside coarse cell `cxi,czi`, chosen by the seed alone."
  [seed cxi czi]
  [(+ (* cxi clearing-cell) (mod (worldgen/hash2 (+ seed 5077) cxi czi) clearing-cell))
   (+ (* czi clearing-cell) (mod (worldgen/hash2 (+ seed 6091) cxi czi) clearing-cell))])

(defn- inside-clearing-disk? [wx wz ccx ccz]
  (def dx (- wx ccx))
  (def dz (- wz ccz))
  (<= (+ (* dx dx) (* dz dz)) (* clearing-radius clearing-radius)))

(defn clearing-at?
  ``Is the world point inside an authored clearing?

  `opts` is the table described by `defaults`. Density 0 answers false
  immediately and density 100 answers true, so both ends are exact: an absent
  record cannot change a single block, and the authored maximum means no anchor
  takes root anywhere. In between, the answer is a union of disks, each derived
  from the seed and its own coarse cell.

  Coordinates must be integers: the callers are tree anchors, and a fractional
  argument here would make the widened cell scan quietly disagree with the
  lattice. The disks are NOT required to cover the cells between them, so a
  point may sit in the gap between two clearings -- which is what keeps a dense
  setting forested rather than bald.``
  [wx wz opts]
  (assert (and (number? wx) (= wx (math/floor wx))
               (number? wz) (= wz (math/floor wz)))
          "clearing queries take integer world coordinates")
  (def density (clearing-density opts))
  (cond
    (zero? density) false
    (>= density 100) true
    (do
      (def seed (opt opts :seed))
      (var hit false)
      (def x0 (math/floor (/ (- wx clearing-radius) clearing-cell)))
      (def x1 (math/floor (/ (+ wx clearing-radius) clearing-cell)))
      (def z0 (math/floor (/ (- wz clearing-radius) clearing-cell)))
      (def z1 (math/floor (/ (+ wz clearing-radius) clearing-cell)))
      (for cz z0 (inc z1)
        (for cx x0 (inc x1)
          (when (and (not hit) (cell-hosts-clearing? seed cx cz density))
            (def c (cell-clearing-center seed cx cz))
            (when (inside-clearing-disk? wx wz (get c 0) (get c 1))
              (set hit true)))))
      hit)))

#
# --- Trees --------------------------------------------------------------
#

(defn- slope-at-around
  "Slope at a world point, sampled through the caller's height function."
  [height-at wx wz]
  (def h (height-at wx wz))
  (if (nil? h)
    0
    (let [h h]
      (var s 0)
      (each [dx dz] [[1 0] [-1 0] [0 1] [0 -1]]
        (def n (height-at (+ wx dx) (+ wz dz)))
        (when n (set s (max s (math/abs (- h n))))))
      s)))

(defn tree-at
  ``The conifer anchored in lattice cell `lx,lz`, or nil.

  Every input is a world coordinate or the seed, so two chunks -- and two runs
  -- derive the identical tree. The jitter is what keeps the result from
  reading as a plantation grid: without it every trunk sits at a cell corner
  and the forest looks stamped.``
  [lx lz height-at opts]
  (def seed (opt opts :seed))
  (def lattice (max 1 (opt opts :lattice)))
  (def h1 (worldgen/hash2 seed lx lz))
  (def h2 (worldgen/hash2 (+ seed 1013) lx lz))
  (def h3 (worldgen/hash2 (+ seed 2027) lx lz))
  (def h4 (worldgen/hash2 (+ seed 3041) lx lz))
  # Sparse by gate, not by rejection: a cell either grows a tree or it does
  # not, so the density is stable across chunk borders.
  (if (>= (mod h3 100) (opt opts :density))
    nil
    (let [ax (+ (* lx lattice) (mod h1 lattice))
          az (+ (* lz lattice) (mod h2 lattice))
          ground (height-at ax az)]
      (when ground
        (def slope (slope-at-around height-at ax az))
        (def sea (opt opts :sea-level))
        (def ok (and (> ground (+ sea 1))
                     (< ground (opt opts :tree-line))
                     (< slope (opt opts :tree-slope))
                     # An authored clearing suppresses the ANCHOR only. A crown
                     # from an anchor outside may still overhang the glade, and
                     # it does so symmetrically across a chunk border because
                     # both chunks derive the same anchor set. Checked after the
                     # ground is known so an uncovered column is still rejected
                     # first and never pays for a hash.
                     (not (clearing-at? ax az opts))))
        (if ok
          @{:x ax :z az :ground ground :slope slope
            :trunk (+ (opt opts :trunk-min) (mod h4 (opt opts :trunk-span)))}
          nil)))))

(def canopy-radius 3)
(def canopy-depth 6)

(defn candidate-trees
  ``Every tree whose canopy could touch this chunk, in lattice order.

  The margin is the canopy radius, so a trunk one chunk over still contributes
  the leaves that hang into ours. Ordering is by lattice cell, which makes the
  emitted set independent of who generated first.``
  [cx cz height-at opts]
  (def lattice (max 1 (opt opts :lattice)))
  (def bx (* cx world/chunk-x))
  (def bz (* cz world/chunk-z))
  (def r canopy-radius)
  (def x0 (math/floor (/ (- bx r) lattice)))
  (def x1 (math/floor (/ (+ bx world/chunk-x r) lattice)))
  (def z0 (math/floor (/ (- bz r) lattice)))
  (def z1 (math/floor (/ (+ bz world/chunk-z r) lattice)))
  (def out @[])
  (for lz z0 (inc z1)
    (for lx x0 (inc x1)
      (when-let [tree (tree-at lx lz height-at opts)]
        (array/push out tree))))
  out)

(defn- paint-tree
  ``Write one tree's cells that land in this chunk. Cells outside are skipped;
  the neighbouring chunk derives the same tree and writes its own half.``
  [blocks cx cz tree opts]
  (def bx (* cx world/chunk-x))
  (def bz (* cz world/chunk-z))
  (def top-y (dec world/chunk-y))
  (defn put-local [wx y wz id]
    (def lx (- wx bx))
    (def lz (- wz bz))
    (when (and (<= 0 lx) (< lx world/chunk-x)
               (<= 0 lz) (< lz world/chunk-z)
               (<= 0 y) (<= y top-y))
      (def i (world/block-index lx y lz))
      # Leaves never displace wood or terrain: a trunk passing through a crown
      # must stay a trunk.
      (when (or (= id world/block-wood) (= world/block-air (get blocks i)))
        (put blocks i id))))
  (def ax (tree :x))
  (def az (tree :z))
  (def ground (tree :ground))
  (def top (+ ground (tree :trunk)))
  (for y (inc ground) (inc top)
    (put-local ax y az world/block-wood))
  # Tapered tiers: one block at the tip widening to three at the skirt. A cone
  # reads as a conifer at any distance, where a sphere reads as a lollipop.
  (for dy 0 canopy-depth
    (def y (- top dy))
    (def radius (min canopy-radius (inc (math/floor (/ dy 2)))))
    (for dz (- radius) (inc radius)
      (for dx (- radius) (inc radius)
        (when (<= (+ (* dx dx) (* dz dz)) (* radius radius))
          (put-local (+ ax dx) y (+ az dz) world/block-leaves)))))
  (put-local ax (+ top 1) az world/block-leaves))

(defn decorate!
  ``Plant every conifer that reaches this chunk. Run AFTER `fill`.``
  [blocks cx cz height-at opts]
  (each tree (candidate-trees cx cz height-at opts)
    (paint-tree blocks cx cz tree opts))
  blocks)

(defn generate-into
  ``Fill and decorate one chunk in place. Returns `blocks`.

  `blocks` is a `world/chunk-volume` buffer; `height-at` is
  `(fn [wx wz] -> height|nil)` over global coordinates; `opts` is the table
  described by `defaults` and may be empty.

  The chunk's vertical extent is read from `world/chunk-y` at every use, never
  from a literal, so raising the engine to 256 tall needs no change here.``
  [blocks cx cz height-at opts]
  (fill blocks cx cz height-at (or opts {}))
  (decorate! blocks cx cz height-at (or opts {}))
  blocks)
