# Trinecraft -- front door: draw the menu, and turn keys into actions.
#
# The DECISIONS live in `world-menu.janet` as pure state; this module only paints
# that state and translates input into actions. Keeping the split means the menu's
# honesty rules are tested without a window, and this file can be wrong about
# layout without ever being wrong about what a click means.
#
# `rl` is injected rather than imported, so the same code can be driven by a stub
# in a test or by a headless painter later. The module holds no state of its own:
# the caller owns the menu state and this returns the next one.

(import ./world-menu :as menu)

# A TABLE, not a struct literal: with `{:ink [r g b a]}` Janet parses the whole
# form as a struct whose values are tuples, and `(palette :ink)` then compiles to
# tuple indexing instead of a keyword lookup. The mutable-brace form keeps the
# accessor honest and matches the shape `rl` expects for a colour.
(def palette
  @{:bg [14 16 22 255]
   :panel [26 30 40 255]
   :ink [230 234 242 255]
   :dim [138 148 166 255]
   :accent [96 186 255 255]
   :bad [248 113 113 255]
   :good [134 239 172 255]
   :rule [58 66 84 255]
   # Painted over injected artwork only. 215/255 leaves the photograph visible as
   # a texture behind the menu while holding every text colour above WCAG AA
   # against the worst case -- a pure white sky (dim grey reaches 4.82:1, which
   # 205 did not: it landed at 4.19). A lighter scrim looked better on dark art
   # and unreadable on the brighter references.
   :scrim [10 12 16 215]
   # Home keeps its artwork visible: a band behind the menu's own words rather
   # than a wash over the whole poster. The top third only, because that is
   # where this menu writes -- the logo sits above it and the characters below.
   :home-veil [10 12 16 170]
   :stone [74 82 70 255]
   :stone-lit [120 132 110 255]
   # Buttons are translucent panels, not solid blocks: the artwork behind them
   # stays visible, which is the whole reason home avoids a full-frame scrim.
   :button [18 22 18 190]
   # Hover state: the same panel, lifted, so a pointer gives feedback without
   # the button changing shape.
   :button-hot [46 58 42 210]
   # Footer disclaimer. Deliberately low-contrast: it is a factual note, not a
   # warning, and it must not compete with the actions.
   :faint [110 120 132 255]})

#
# --- Text input ---------------------------------------------------------
#

(def max-name 48)
# Bytes, not characters. A custom seed accepts arbitrary text and one emoji is
# four bytes, so a 32-BYTE cap would reject the eighth typed symbol on the field
# whose whole purpose is "type whatever you like". 256 keeps a pasted paragraph
# out of a one-line row while leaving room for a real sentence.
(def max-seed 256)
# Hard ceiling on anything accepted by `insert-text`, independent of the field's
# own limit, so no caller can pass an unbounded limit by accident.
(def max-input-bytes 4096)

(defn utf8-encode
  ``Encode one Unicode scalar value as UTF-8, or nil when it is not representable.

  bender has no `string/from-codepoints`, and `string/from-bytes` is NOT a
  codepoint encoder: it takes byte values and keeps only the low 8 bits, so
  0x1F98B emerges as the lone byte 0x8B. Feeding it raylib's codepoint therefore
  drops every character above U+00FF, which is exactly why a custom seed could
  not contain a butterfly.

  Surrogates (U+D800..U+DFFF) are rejected: they are not valid UTF-8 and exist
  only as UTF-16 pairing halves. Values above U+10FFFF are rejected too. Control
  characters are the caller's decision, because this function is also used to
  re-validate text that already exists.``
  [code]
  (when (and (number? code)
             (>= code 0)
             (< code 0x110000)
             (or (< code 0xD800) (> code 0xDFFF)))
    (cond
      (< code 0x80) (string/from-bytes code)
      (< code 0x800)
      (string/from-bytes (bor 0xC0 (brshift code 6))
                         (bor 0x80 (band code 0x3F)))
      (< code 0x10000)
      (string/from-bytes (bor 0xE0 (brshift code 12))
                         (bor 0x80 (band (brshift code 6) 0x3F))
                         (bor 0x80 (band code 0x3F)))
      true
      (string/from-bytes (bor 0xF0 (brshift code 18))
                         (bor 0x80 (band (brshift code 12) 0x3F))
                         (bor 0x80 (band (brshift code 6) 0x3F))
                         (bor 0x80 (band code 0x3F))))))

(defn utf8-continuation?
  "True for a UTF-8 continuation byte (0b10xxxxxx)."
  [b]
  (and (number? b) (>= b 0x80) (< b 0xC0)))

(defn utf8-valid?
  ``True when `s` is a well-formed UTF-8 byte sequence.

  A field's contents must always be valid UTF-8, because the seed parser hashes
  its bytes: half a character would hash to a world nobody could reproduce by
  typing. Overlong forms and lone continuation bytes are rejected, as are
  surrogates and values above U+10FFFF.``
  [s]
  (def n (length s))
  (var i 0)
  (var ok true)
  (while (and ok (< i n))
    (def b (get s i))
    (def need
      (cond
        (< b 0x80) 0
        (and (>= b 0xC2) (< b 0xE0)) 1
        (and (>= b 0xE0) (< b 0xF0)) 2
        (and (>= b 0xF0) (< b 0xF5)) 3
        true -1))
    (if (neg? need)
      (set ok false)
      (if (> (+ i need) (dec n))
        (set ok false)
        (do
          (for k 1 (+ need 1)
            (when (not (utf8-continuation? (get s (+ i k)))) (set ok false)))
          # Reject the specific overlong and surrogate encodings that a pure
          # continuation-byte check would let through.
          (when (and ok (= need 2))
            (def b1 (get s (+ i 1)))
            (when (or (and (= b 0xE0) (< b1 0xA0))          # overlong
                      (and (= b 0xED) (>= b1 0xA0)))         # surrogate
              (set ok false)))
          (when (and ok (= need 3))
            (def b1 (get s (+ i 1)))
            (when (or (and (= b 0xF0) (< b1 0x90))          # overlong
                      (and (= b 0xF4) (>= b1 0x90)))         # > U+10FFFF
              (set ok false)))
          (set i (+ i need 1))))))
  ok)

(defn utf8-length
  "Number of Unicode scalar values in a valid UTF-8 string."
  [s]
  (var count 0)
  (each b s (when (not (utf8-continuation? b)) (++ count)))
  count)

(defn insert-text
  ``Append `ch` to `s`, refusing the append when it would exceed `limit`.

  The limit is BYTES and is measured after the append, not before. The previous
  version compared the current length against the limit and then appended
  unconditionally, so the field could always overshoot by one whole character.

  A single append is all-or-nothing: if `ch` would cross the limit it is not
  added at all. Truncating mid-character would leave invalid UTF-8, and the seed
  parser hashes these bytes.

  Appending rather than editing at a caret is deliberate: a front door with one
  field per row and no cursor navigation is what the plan says to build first,
  and a caret that exists but cannot be moved is worse than one that is simply
  absent.``
  [s ch limit]
  (def text (or s ""))
  (def add (or ch ""))
  (def cap (min limit max-input-bytes))
  (cond
    (empty? add) text
    (> (+ (length text) (length add)) cap) text
    (not (utf8-valid? add)) text
    true (string text add)))

(defn backspace
  ``Delete the last whole Unicode scalar value from `s`.

  Slicing one byte off would leave the leading bytes of a multi-byte character
  behind, producing invalid UTF-8 that then hashes as garbage. Walk back over the
  continuation bytes to the start of the final character.``
  [s]
  (def text (or s ""))
  (def n (length text))
  (if (< n 1)
    ""
    (do
      (var i (dec n))
      (while (and (> i 0) (utf8-continuation? (get text i)))
        (-- i))
      (string/slice text 0 i))))

(defn drain-chars
  ``Every queued codepoint as a UTF-8 string, consuming the queue.

  A key event and a character event are different in raylib: `IsKeyPressed`
  answers for navigation, `GetCharPressed` answers for text. Reading only the
  former is why a text field can appear not to accept typing at all.

  Invalid codepoints are SKIPPED rather than replaced with U+FFFD: a replacement
  character would silently become part of the seed, changing the world without
  the user seeing what they typed.``
  [rl]
  (def get-ch (rl :char-pressed))
  (def out @"")
  (var ch (get-ch))
  (while (not= ch 0)
    # 32 is space; control characters below it are not text.
    (when (>= ch 32)
      (when-let [encoded (utf8-encode ch)]
        (buffer/push-string out encoded)))
    (set ch (get-ch)))
  (string out))

(defn index-of-id
  "Position of `id` in `ids`, or nil."
  [ids id]
  (var at nil)
  (var i 0)
  (each x ids
    (when (and (nil? at) (= x id)) (set at i))
    (++ i))
  at)

(defn seed-field
  "Normalise a text-field focus value to one of `:name` or `:seed`."
  [focus]
  (if (= focus :seed) :seed :name))

(defn field?
  "Is this focus value one of the two TEXT fields (as opposed to a control)?"
  [focus]
  (or (= focus :name) (= focus :seed) (nil? focus)))

(defn cycle-focus
  ``Advance focus through the editable targets: name, seed, provider, controls.

  Focus is owned by this module rather than inferred by the caller. The previous
  version inferred it from whether the seed field was non-empty -- which meant the
  seed could only be focused once it had text, and it could only get text when
  focused. A field nobody can reach is not a field.

  The PROVIDER is part of the cycle and sits before the controls, because choosing
  a provider changes which controls exist: a player reaching for a slider should
  have passed the thing that decides which sliders there are. Every adjustable
  target is reachable with one key; nothing is reachable by no key.``
  [focus controls]
  (def ids (map |($ :id) controls))
  (cond
    (nil? focus) :name
    (= focus :name) :seed
    (= focus :seed) :provider
    (= focus :provider) (if (pos? (length ids)) (get ids 0) :name)
    (let [at (index-of-id ids focus)]
      (if at
        (if (< at (dec (length ids))) (get ids (inc at)) :name)
        :name))))

(defn other-focus
  "The other TEXT field, kept for the two-field case."
  [focus]
  (if (= (seed-field focus) :seed) :name :seed))

(defn step
  ``One frame of input: returns `{:state s :request r :focus f}`.

  `request` is nil, a create/open request, or a refusal tuple. Returning the
  request rather than performing it keeps the caller in charge of when a world is
  actually made -- which is what lets a save failure stay inside worldgen instead
  of becoming a menu that lied about succeeding.

  FOCUS IS THE MENU'S, not the caller's. Enter on the name field moves to the seed
  field rather than submitting, so both fields are reachable with one key; Enter on
  the seed field submits. Up/Down toggle between them. Tab toggles the random-seed
  mode only while the seed field is focused -- elsewhere it moves focus, because a
  key that does something different depending on invisible state is worse than one
  that always moves you forward.``
  [state rl keys start-focus]
  (var focus start-focus)
  (def typed (drain-chars rl))
  (def screen (state :screen))
  (var s state)
  (def on-new? (= screen :new))
  (def on-load? (= screen :load))
  # Text first: a codepoint typed this frame belongs to whichever field is open.
  (when (and on-new? (not (empty? typed)) (field? focus))
    (case (seed-field focus)
      :seed (set s (menu/step s [:edit-seed
                                 (insert-text (s :seed-input) typed max-seed)]))
      (set s (menu/step s [:edit-name
                           (insert-text (s :name) typed max-name)]))))
  (when (and on-new? ((rl :key-pressed?) (keys :backspace)) (field? focus))
    (case (seed-field focus)
      :seed (set s (menu/step s [:edit-seed (backspace (s :seed-input))]))
      (set s (menu/step s [:edit-name (backspace (s :name))]))))

  # `[` and `]` adjust the FOCUSED control by one declared step. The step is
  # derived from the control's own type: an integer moves by 1, a number by a
  # tenth. A control the provider never declared is never adjusted, because
  # `update-setting` refuses it -- the validation is the same one the menu uses.
  (defn adjust [dir]
    (def control (menu/control-of s (s :provider) focus))
    (when control
      (def current (or (get (s :settings) (control :id)) (control :default) 0))
      (def step-size (if (= (control :kind) :int) 1 0.1))
      (def next-value (+ current (* dir step-size)))
      # Clamp to the declared bounds instead of letting the attempt fail: a player
      # holding `]` should stop at the maximum, not land in an error screen.
      (def lo (or (control :min) next-value))
      (def hi (or (control :max) next-value))
      (set s (menu/step s [:update-setting (control :id)
                           (min hi (max lo next-value))]))))

  # --- Provider selection ---------------------------------------------
  # Left/right choose a provider while the provider field has focus. Unavailable
  # providers are still reachable so their REASON can be read -- selecting one
  # never authorises creation, because `create-request` refuses it and the form
  # says why. Changing provider resets the controls to that provider's declared
  # defaults through `menu/step :change-provider`, so no setting can leak from one
  # provider's controls into another's.
  (def provider-ids (map |($ :id) (s :providers)))
  (defn step-provider [dir]
    (when (and on-new? (= focus :provider) (pos? (length provider-ids)))
      (def at (or (index-of-id provider-ids (s :provider)) 0))
      (def n (length provider-ids))
      (def next-at (mod (+ at dir) n))
      (set s (menu/step s [:change-provider (get provider-ids next-at)]))))

  (var request nil)
  (cond
    ((rl :key-pressed?) (keys :escape))
    (set s (if (= screen :home) s (menu/step s [:back])))

    ((rl :key-pressed?) (keys :up))
    (cond
      on-new? (set focus (cycle-focus focus (menu/control-rows s)))
      on-load?
      (do
        (def rows (menu/visible-worlds s))
        (when (pos? (length rows))
          (def ids (map |($ :id) rows))
          (def at (index-of-id ids (s :selected-world)))
          (set s (menu/step s [:select-world (get ids (max 0 (dec (or at 1))))])))))

    ((rl :key-pressed?) (keys :down))
    (cond
      on-new? (set focus (cycle-focus focus (menu/control-rows s)))
      on-load?
      (do
        (def rows (menu/visible-worlds s))
        (when (pos? (length rows))
          (def ids (map |($ :id) rows))
          (def at (index-of-id ids (s :selected-world)))
          (set s (menu/step s [:select-world
                               (get ids (min (dec (length ids)) (inc (or at -1))))])))))

    ((rl :key-pressed?) (keys :left))
    (step-provider -1)

    ((rl :key-pressed?) (keys :right))
    (step-provider 1)

    ((rl :key-pressed?) (keys :tab))
    (when on-new?
      # Tab CYCLES through every editable target: name, seed, then each control.
      # It never changes a value, so there is exactly one key that moves the
      # caret and it always moves it forward.
      (set focus (cycle-focus focus (menu/control-rows s))))

    ((rl :key-pressed?) (keys :dec))
    (when (and on-new? (not (field? focus))) (adjust -1))

    ((rl :key-pressed?) (keys :inc))
    (when (and on-new? (not (field? focus))) (adjust 1))

    ((rl :key-pressed?) (keys :random))
    (when on-new?
      # F2 toggles the random seed from anywhere on the form, so a player who does
      # not care about a seed never has to find the field first.
      (set s (menu/step s [:random-seed (not (s :seed-random))])))

    ((rl :key-pressed?) (keys :enter))
    (case screen
      :home (set s (menu/step s [(if (pos? (length (s :worlds))) :load :new)]))
      # Enter on the NAME field advances to the seed rather than submitting, so a
      # keyboard-only player can reach both fields with one key. The second Enter
      # submits. Without this the form could only ever be submitted from the name
      # field, and a custom seed was unreachable.
      # Enter on the NAME field advances to the seed; anywhere else it submits.
      # Typing a name and pressing Enter once should not create a world.
      :new (if (= focus :name)
             (set focus :seed)
             (set request (menu/create-request s)))
      :load (set request (menu/open-request s))
      nil)
    nil)
  # Returned RAW: `seed-field` normalises to a text field, which would silently
  # turn a focused control back into the name field after every bracket press.
  {:state s :request request :focus focus})

#
# --- Submit line --------------------------------------------------------
#
# WHAT ENTER WILL DO, SAID OUT LOUD.
#
# The form's footer used to read "[Enter] create" -- a verb with no object. A
# player who never looked down at the provider row pressed Enter and got a
# procedural world with a random seed, having believed they were asking for
# something else. The provider and the seed were both on screen, but neither was
# attached to the action, so nothing on the form disagreed with the player's
# assumption until the terrain arrived.
#
# The fix is a LABEL, not a confirmation step: the footer now names the provider
# that will run and the seed that will be used, derived from the same layout the
# rest of the form draws. No state is added, no provider is switched behind the
# player's back, and no extra keystroke is charged for a world they already
# asked for.
#
# Everything here is pure: it reads the layout and a `measure` function, and it
# returns strings. That is what lets a test pin exactly what a player will read
# without a window, a GPU, or a screenshot.

# A smaller size than the old footer: the line now carries a provider name, and a
# long one ("Terrain Diffusion - Python (temporary)") plus a seed has to stay
# inside the frame at 1280 px.
(def submit-size 14)
# Two lines is the ceiling. The last line stays exactly where the single-line
# footer always sat, so a long label grows UPWARD into empty form space instead
# of walking off the bottom of the window.
(def submit-line-step 18)

(defn utf8-prefix
  ``The first `k` Unicode scalar values of `s`, sliced only at a boundary.

  The seed field accepts arbitrary text, so shortening it has to count
  characters rather than bytes: cutting one byte off would leave a dangling
  leading byte that draws as garbage.``
  [s k]
  (def n (length s))
  (var i 0)
  (var taken 0)
  (while (and (< i n) (< taken k))
    (def b (get s i))
    (var step 1)
    (cond
      (and (>= b 0xC2) (< b 0xE0)) (set step 2)
      (and (>= b 0xE0) (< b 0xF0)) (set step 3)
      (and (>= b 0xF0) (< b 0xF5)) (set step 4))
    (set i (min n (+ i step)))
    (++ taken))
  (string/slice s 0 i))

(defn fit-text
  ``Text when it measures inside `max-width`, otherwise shortened with an ellipsis.

  Shortening is by whole Unicode scalar values, so a seed containing a butterfly
  never contributes half a character to a label someone reads.``
  [s measure size max-width]
  (if (<= (measure s size) max-width)
    s
    (do
      (var keep (utf8-length s))
      (var out (string s "..."))
      # Each pass drops one whole character; the ellipsis is always accounted for,
      # so the loop is bounded by the string itself and cannot spin.
      (while (and (pos? keep) (> (measure out size) max-width))
        (-- keep)
        (set out (string (utf8-prefix s keep) "...")))
      out)))

(defn escape-quoted
  ``Text made safe to sit inside the double quotes the footer uses.

  Only the quote character is escaped. Leaving a bare backslash alone is
  deliberate: doubling it would show a seed's own characters differently from
  what the player typed, and the label's job is to show what will be used.``
  [s]
  (def out @"")
  (each b (string s)
    (if (= b 34) (buffer/push-string out "\\\"") (buffer/push-byte out b)))
  (string out))

(defn provider-submit-label
  ``The provider the footer names, read from the layout's own rows.

  A menu with nothing available reaches here with no selection; it says so rather
  than inventing an id. An unavailable provider is still reachable so its reason
  can be read, so the label carries that too -- the footer must not promise a run
  the form would refuse.``
  [L]
  (def pid (L :selected-provider))
  (if (nil? pid)
    "no provider selected"
    (let [row (first (filter |(= pid ($ :id)) (or (L :providers) @[])))]
      (if row
        (string (escape-quoted (row :label))
                (if (row :available) "" " - unavailable"))
        (escape-quoted pid)))))

(defn seed-submit-label
  ``The seed the footer names, as the form will actually submit it.

  A blank field is a random world -- that is what `main` does with it -- so the
  label says "random" rather than showing an empty string and letting the player
  guess. The text is never parsed here: this is a label, and `"007"` must read as
  `007`, not as the number 7.``
  [L]
  (def typed (or (L :seed-input) ""))
  (if (or (truthy? (L :seed-random)) (empty? typed))
    "random"
    (escape-quoted typed)))

(defn submit-lines
  ``The footer, as one line when it fits and two when it does not.

  Line one names the action and the provider; line two names the seed and the way
  out. They are joined on one line when the join still measures inside
  `max-width`, which is the ordinary case: two lines cost a reader a second look
  for nothing. Every returned line is guaranteed to fit.``
  [L measure max-width]
  (def action (string "[Enter] Create \"" (provider-submit-label L) "\" world"))
  (def rest (string "seed: " (seed-submit-label L) "   [Esc] back"))
  (def line (string action "   " rest))
  (if (<= (measure line submit-size) max-width)
    @[line]
    @[(fit-text action measure submit-size max-width)
      (fit-text rest measure submit-size max-width)]))

#
# --- Painting -----------------------------------------------------------
#

(defn- text [rl s x y size colour] ((rl :draw-text) s x y size colour))

(defn draw
  ``Paint one menu frame. The window is already open and cleared by the caller.

  `art` is an OPTIONAL injected callback, `(art width height)`. When supplied the
  menu calls it to paint the background and then paints its own dark scrim OVER
  the result before any text; when absent the menu is a flat panel on the
  caller's clear colour, which is what a headless test and a no-assets install
  both get.

  The menu deliberately does not know what the artwork is. It is not told about
  textures, paths, slideshows or fallbacks -- it asks a function to fill the
  frame and then guarantees readability on top of whatever came back. That is
  what lets the same presenter instance serve the menu and the loading screen
  without the menu importing it, and it keeps "what the art is" in one module.

  Readability is the menu's responsibility, not the presenter's: `art` may paint
  a white sky, a snowfield, or nothing at all, and the text must still be
  legible.

  On HOME the readability comes from translucent PANELS behind each element,
  never from a full-frame wash. The home artwork is a designed poster with a
  logo, a subtitle and characters baked into it; a 215-alpha full-screen scrim
  turns that poster into a dark rectangle and defeats the reason for showing it.
  So home draws panels, and only the forms (`:new`/`:load`) dim the whole frame,
  because there the artwork has no logo left to protect.``
  [state rl focus &opt keys art]
  (def L (menu/layout state))
  (def W ((rl :screen-width)))
  (def H ((rl :screen-height)))
  (def pad 48)
  (def on-home? (= :home (L :screen)))
  # MEASUREMENT FALLBACK. The menu centres text, which needs a width, which
  # needs `:measure-text`. A caller that has not injected it (or a bare stub)
  # must still render rather than crash on a nil call -- so absent, we estimate
  # at 0.55em, which is close enough to centre a button and never correct for
  # wrapping. This is a FALLBACK, not a supported mode: `rl-adapter` still
  # documents `:measure-text` as required for a real build.
  (def measure (or (rl :measure-text)
                   (fn [t size] (math/floor (* (length (string t)) size 0.55)))))
  # Declared here, not inside the :home branch: `draw` returns these so the
  # loop can hit-test what is actually on screen. Scoped inside the case, the
  # value was discarded and a click could never resolve.
  (def hit-rects @[])
  # The art callback RETURNS truthy when it actually painted something. The menu
  # needs that to decide the header: with a poster behind it, the poster IS the
  # header; with the gradient alone, the menu must supply its own title or the
  # screen says nothing at all.
  (def art-painted? (if art (truthy? (art W H)) false))
  (when art
    # Forms may dim the whole frame; home must not.
    (when (not on-home?)
      ((rl :draw-rectangle) 0 0 W H (palette :scrim))))
  # HOME SKIPS THE GENERIC HEADER ENTIRELY.
  #
  # The home artwork carries its own logo, subtitle and characters. Drawing our
  # `Trinecraft` wordmark at the top-left would put text over a baked logo the
  # designer already placed, and drawing "Choose a world to begin" would add a
  # second subtitle the artwork also already has. So on home the artwork is the
  # header: no title, no subtitle, no rule.
  #
  # The title is NOT lost -- it is the fallback. When no artwork loaded (a fresh
  # clone, or a broken asset) there is nothing behind the menu, so the wordmark
  # comes back and the screen still says what it is.
  (when (or (not on-home?) (not art-painted?))
    (text rl (L :title) pad pad 40 (palette :ink))
    (text rl (case (L :screen)
               :home "Choose a world to begin."
               :new "Describe the world you want."
               :load "Pick a world to continue."
               :error "Something is wrong.")
          pad (+ pad 52) 20 (palette :dim))
    ((rl :draw-rectangle) pad (+ pad 84) (- W (* 2 pad)) 1 (palette :rule)))

  (defn draw-row [y caption value selected? enabled?]
    (when selected?
      ((rl :draw-rectangle) (- pad 8) (- y 6) (- W (* 2 pad) -16) 34 (palette :panel)))
    (text rl caption pad y 22 (if enabled? (palette :ink) (palette :dim)))
    (text rl value (+ pad 300) y 22
          (cond (not enabled?) (palette :dim)
                selected? (palette :accent)
                (palette :ink)))
    (+ y 38))

  (var y (+ pad 120))
  (case (L :screen)
    :home
    (do
      # Stone-framed buttons, centred, under the artwork's subtitle. The sample
      # puts its actions in the 43-60% band, which is below the baked logo and
      # above the characters, so nothing designed is covered.
      (def btn-w 300)
      (def btn-h 54)
      (def btn-x (math/floor (- (/ W 2) (/ btn-w 2))))
      # The sample puts its actions between the baked subtitle (~30%) and the
      # characters (~80%). 0.43 and 0.55 centre two 54px buttons in that clear
      # band at 800px tall, so neither the logo above nor the characters below
      # is covered.
      (var by (math/floor (* H 0.43)))
      # `action` defaults to nil so a caller that paints a button without
      # wiring an action still gets a visible, honest button rather than an
      # arity crash. A button whose click does nothing is a smaller failure
      # than a screen that will not draw at all.
      (defn stone-button [title sub &opt action]
        # A nil action paints the button but registers no hit rectangle, so
        # a click cannot resolve into a transition nobody defined.
        (when action
          (array/push hit-rects @{:action action :x btn-x :y by
                                  :w btn-w :h btn-h}))
        # Frame: dark outer rule, lighter inner, then the translucent panel --
        # the same carved-stone read as the loading bar.
        ((rl :draw-rectangle) (- btn-x 5) (- by 5) (+ btn-w 10) (+ btn-h 10)
         (palette :stone))
        ((rl :draw-rectangle) (- btn-x 2) (- by 2) (+ btn-w 4) (+ btn-h 4)
         (palette :stone-lit))
        ((rl :draw-rectangle) btn-x by btn-w btn-h
         (if (and (rl :mouse-within?) ((rl :mouse-within?) btn-x by btn-w btn-h))
           (palette :button-hot)
           (palette :button)))
        (def lw (measure title 24))
        (text rl title (+ btn-x (math/floor (- (/ btn-w 2) (/ lw 2))))
              (+ by 12) 24 (palette :ink))
        (when sub
          (def sw (measure sub 15))
          (text rl sub (+ btn-x (math/floor (- (/ btn-w 2) (/ sw 2))))
                (+ by 36) 15 (palette :dim)))
        (+ by btn-h 18))
      # New Game is always offered. Load Game is always VISIBLE, and explains
      # itself when there is nothing to load -- a hidden button reads as "the
      # feature is missing", an explained one reads as "no saves yet".
      (set by (stone-button "New Game" nil [:new]))
      # `(L :rows)` holds the fixed action rows, NOT the world list -- the
      # worlds live on the state. Reading rows here made every menu claim there
      # were no saves, which is the kind of bug that looks like a broken
      # catalogue rather than a wrong field.
      (def saved (state :worlds))
      (stone-button "Load Game"
                    (if (pos? (length saved)) nil "No saved worlds yet")
                    [:load])
      # Instructions state what actually works. Mouse click is offered only
      # when the caller injected a pointer, so this line is never a promise the
      # build cannot keep.
      (def foot (if (and (rl :mouse-in?) ((rl :mouse-in?)))
                  "Click a button, or Enter opens   Esc quits"
                  "Enter opens   Esc quits"))
      (def fw (measure foot 18))
      (text rl foot (math/floor (- (/ W 2) (/ fw 2))) (+ H -64) 18 (palette :dim))
      # Small, muted, and factual: the artwork is a presentation image, not a
      # claim about what the engine renders.
      (def note "Artwork is promotional illustration, not in-game footage.")
      (def nw (measure note 13))
      (text rl note (math/floor (- (/ W 2) (/ nw 2))) (+ H -38) 13 (palette :faint))
      nil)

    :new
    (do
      (text rl "Name" pad y 22 (palette :ink))
      (text rl (if (= focus :name) (string (L :name) "_") (L :name))
            (+ pad 300) y 22 (if (= focus :name) (palette :accent) (palette :ink)))
      (set y (+ y 38))
      (text rl "Seed" pad y 22 (palette :ink))
      (text rl (if (L :seed-random) "(random)"
                   (if (= focus :seed) (string (L :seed-input) "_")
                       (if (empty? (L :seed-input)) "(blank = random)" (L :seed-input))))
            (+ pad 300) y 22
            (cond (L :seed-random) (palette :good)
                  (= focus :seed) (palette :accent)
                  (palette :dim)))
      (set y (+ y 38))
      # The hint states the REAL bindings: Tab moves focus, F2 is the mode. A hint
      # that described the previous keys would be worse than none.
      (text rl "Tab moves between fields   F2 random seed   Enter next/confirm"
            pad y 18 (palette :dim))
      (set y (+ y 32))
      (each p (L :providers)
        (text rl (string (p :label)
                         (if (p :available) "" (string "  -- " (or (p :reason) "unavailable"))))
              pad y 20
              (if (and (p :available) (= (p :id) (L :selected-provider)))
                (palette :accent)
                (if (p :available) (palette :ink) (palette :bad))))
        (set y (+ y 28)))
      # --- Generation settings -----------------------------------------
      # Rendered from the provider's OWN control list. When the list is empty this
      # section prints nothing, so an embedder with no knobs gets no empty frame
      # rather than a heading over nothing.
      (def controls (menu/control-rows state))
      (when (pos? (length controls))
        (set y (+ y 10))
        (text rl "Generation" pad y 18 (palette :dim))
        (set y (+ y 26))
        (each c controls
          (def current (c :value))
          (def text-value
            (if (= (c :kind) :int)
              (string (if (nil? current) 0 current))
              (string (if (nil? current) 0 current))))
          # `[` and `]` adjust the FOCUSED control. Only one control is adjusted at
          # a time so `]` never means "increase something" without saying which.
          (def mark (if (= focus (c :id)) "> " "  "))
          (text rl (string mark (c :label))
                pad y 20
                (if (= focus (c :id)) (palette :accent) (palette :ink)))
          (text rl text-value (+ pad 300) y 20
                (if (= focus (c :id)) (palette :accent) (palette :dim)))
          (set y (+ y 26)))
        (text rl "[ and ] adjust the focused setting   Tab cycles fields"
              pad y 16 (palette :dim))
        (set y (+ y 22)))
      # THE SUBMIT LINE SAYS WHAT IT WILL DO. Drawn from the same layout the rest
      # of the form read, so the provider named here is the provider `Enter`
      # would actually send. The LAST line keeps the old footer's y, so a long
      # label grows upward into empty space rather than off the bottom edge.
      (def sub-lines (submit-lines L measure (- W (* 2 pad))))
      (def sub-base (+ H pad -64))
      # Painted TOP-DOWN from a base computed for the last line, so the bottom
      # line never moves: one line sits where the old footer did, and a second
      # line is added above it.
      (var sub-y (- sub-base (* submit-line-step (max 0 (dec (length sub-lines))))))
      (each sub-line sub-lines
        (text rl sub-line pad sub-y submit-size (palette :dim))
        (set sub-y (+ sub-y submit-line-step))))

    :load
    (do
      (def rows (L :rows))
      (if (empty? rows)
        (text rl "No worlds saved yet. Start one with New game." pad y 22 (palette :dim))
        (each w rows
          (set y (draw-row y (w :label) (if (w :selected) "[selected]" "") (w :selected) true))))
      (text rl (string "page " (inc (L :page)) "/" (L :pages)
                       "   [up/down] select   [Enter] open   [Esc] back")
            pad (+ H pad -64) 18 (palette :dim)))

    :error
    (do
      (text rl (or (L :error) "unknown error") pad y 20 (palette :bad))
      (text rl "[Esc] back" pad (+ H pad -64) 18 (palette :dim))))
  # A refusal or a create/open request is the caller's to act on; this frame only
  # shows why nothing happened when the caller declined.
  (when-let [msg (L :message)]
    (text rl msg pad (+ H pad -32) 18 (palette :dim)))
  # What was painted, for hit-testing. draw stays a painter: returning the
  # rectangles keeps input policy in the loop and lets a stub-driven test pin
  # placement without a GPU.
  hit-rects)

#
# --- Live integration ---------------------------------------------------
#
# Everything below connects the pure model to the real window. Kept in this file
# so `main` gains a call, not a menu: the drawing and input rules stay where they
# are tested, and main only decides WHEN a menu is appropriate.

(defn keymap
  ``The keycodes to listen for, taken from the caller's input module.

  Passed in rather than imported: this module must not depend on raylib, or the
  stub-driven tests stop being able to run it at all.``
  [k]
  {:enter (k :enter) :kp-enter (k :kp-enter)
   :escape (k :escape) :backspace (k :backspace)
   :up (k :up) :down (k :down) :tab (k :tab)})

(defn rl-adapter
  ``The injected `rl` table, assembled from explicit functions.

  A Janet module is not a first-class value -- it cannot be indexed as a table --
  so the caller hands in each function by name. SEVEN names are the whole
  surface this module requires, which is also what keeps the stub-driven tests
  honest: anything the view needed beyond these would have to be added here, in
  the open. `measure-text` joined the set when the home screen started centring
  its buttons -- before that it only left-aligned, and never needed to know a
  string's width.``
  [fns]
  # Mouse is OPTIONAL. `(fns :mouse-position)` is nil in every existing caller
  # and in every stub, and the menu then reports `:mouse-in?` as false and shows
  # keyboard instructions only. That keeps a build without pointer injection
  # from advertising a click nobody handles.
  (def pos (fns :mouse-position))
  (def pressed (fns :mouse-pressed?))
  (def within?
    (if pos
      (fn [x y w h]
        (def p (pos))
        (and (>= (get p 0) x) (<= (get p 0) (+ x w))
             (>= (get p 1) y) (<= (get p 1) (+ y h))))
      (fn [& _] false)))
  @{:measure-text (fns :measure-text)
    :mouse-in? (if pos (fn [] true) (fn [] false))
    :mouse-within? within?
    :mouse-clicked? (if pressed (fn [x y w h]
                                  (and (pressed 0) (within? x y w h)))
                        (fn [& _] false))
    :char-pressed (fns :char-pressed)
    :key-pressed? (fns :key-pressed?)
    :draw-text (fns :draw-text)
    :draw-rectangle (fns :draw-rectangle)
    :screen-width (fns :screen-width)
    :screen-height (fns :screen-height)})

(defn control-from-provider
  ``Translate one provider control into the menu's control schema.

  Two vocabularies meet here. The provider registry says `:type :integer|:number`
  and carries `:category`; the menu says `:kind :int|:number|:choice`. Neither is
  wrong -- one is about generation, the other about presentation -- so the
  translation lives in the view, which is the only thing that cares about both.

  A control type this function does not recognise is dropped rather than guessed
  at: a knob the menu cannot validate is one it cannot honestly offer.``
  [c]
  (def kind (case (c :type)
              :integer :int
              :number :number
              :choice :choice
              nil))
  (when kind
    @{:id (c :id)
      :label (or (c :label) (string (c :id)))
      :kind kind
      :min (c :min)
      :max (c :max)
      :choices (c :choices)
      :default (c :default)}))

(defn- declared-version
  ``The settings version a provider DESCRIPTOR declares when nothing is preferred.

  A descriptor that predates versioning declares nothing, and 1 is the contract
  every such provider was written under -- never assume the newest. ``:version`` is
  read only as a fallback for a descriptor that has no ``:settings-versions``, so a
  registry that has not adopted the list still resolves sanely.``
  [p]
  (def declared (p :settings-versions))
  (if (and declared (indexed? declared) (pos? (length declared)))
    (first declared)
    (or (p :version) 1)))

(defn- controls-for-version
  ``The controls a descriptor declares for `version`, or nil when it has none.

  Read from the DESCRIPTOR's own data rather than by calling into the provider
  module: this view must not depend on it, which is the whole reason the registry
  is passed by value. Version 2 reads ``:controls-v2``; version 1 reads
  ``:controls``. An unknown version yields nil so the caller can fall back.``
  [p version]
  (cond
    (= 2 version) (p :controls-v2)
    (= 1 version) (p :controls)
    nil))

(defn- supports-version?
  "Does this descriptor declare `version`? Nil/absent means only version 1."
  [p version]
  (def declared (p :settings-versions))
  (if (and declared (indexed? declared))
    (truthy? (some |(= $ version) declared))
    (= 1 version)))

(defn providers-from-registry
  ``Menu provider rows built from a provider registry.

  Takes the registry by VALUE, not by import: this module must not depend on the
  provider module any more than on raylib, or its tests stop being pure. An
  unavailable provider keeps ITS OWN reason, because the reason is the honest part
  of offering it at all.

  `preferred` selects which settings contract each row advertises. It accepts:

    * nil (the default) -- every row advertises its own DECLARED version, which is
      1 for any descriptor that predates versioning. An existing caller therefore
      gets exactly the controls it always got, and nothing widens silently.
    * a MAP of provider id to version, e.g. ``{:procedural 2}`` -- only the named
      providers move; everything else keeps its declared version. This is the
      form to prefer, because it says per provider which contract is wanted and
      cannot accidentally lift a provider that has no such version.
    * a NUMBER, kept for a caller that has a single-provider registry.

  A requested version the descriptor does not DECLARE is never honoured: the row
  falls back to its declared version and reports that. So a mixed registry -- a
  provider that supports v2 beside one that does not -- produces two rows at two
  versions without error, and the menu can never present a contract a provider
  would refuse.``
  [registry &opt preferred]
  (def overrides
    (cond
      (nil? preferred) @{}
      (or (table? preferred) (struct? preferred)) preferred
      # A scalar applies to the provider that has more than one version, which in
      # this build is procedural. Applying it to every row would make an
      # unrelated provider report a version it does not have.
      true @{:procedural preferred}))
  (def rows @[])
  (each p registry
    (def declared (declared-version p))
    (def wanted (or (get overrides (p :id)) declared))
    (def offered (if (and (supports-version? p wanted)
                          (controls-for-version p wanted))
                   wanted
                   declared))
    (def source (or (controls-for-version p offered) @[]))
    (def controls @[])
    (each c source
      (when-let [converted (control-from-provider c)]
        (array/push controls converted)))
    (array/push rows @{:id (p :id)
                       :label (or (p :label) (string (p :id)))
                       :available (truthy? (p :available))
                       :reason (p :reason)
                       :settings-version offered
                       :controls controls}))
  rows)

(defn default-providers
  ``The providers offered when no registry is supplied.

  Procedural only, and with NO controls: a caller that wants the real knobs must
  pass a registry. This is the fallback for a test or an embedder, not a claim
  that the engine has no settings.

  The unavailable reason says the PIPELINE is unverified, not that no runtime
  exists. A native inference runtime is installed and proven at the graph level;
  what is missing is a verified end-to-end terrain pipeline. Saying "no backend is
  installed" would be false in a way a player could check.``
  []
  @[@{:id :procedural :label "Native procedural" :available true
      :reason nil :controls @[]}
    @{:id :diffusion :label "Terrain Diffusion (native)" :available false
      :reason "native pipeline not verified" :controls @[]}])

(defn worlds-of
  ``Catalogue entries as menu rows.

  The catalogue reports `{:id :status :manifest}`; the menu wants `{:id :name ...}`.
  The adapter is here, in the view, because it is a presentation translation --
  and because it must DROP incompatible entries rather than show them as loadable.
  Sorting by name keeps the list stable between runs; loading one the catalogue
  cannot parse is not a world.``
  [entries]
  (def rows @[])
  (each e entries
    (when (= :ready (e :status))
      (def m (e :manifest))
      (array/push rows @{:id (e :id)
                         :name (or (m :name) "(unnamed)")
                         :provider (m :provider)
                         :seed (get (m :seed) :value)
                         :modified 0})))
  (sort-by |($ :name) rows))

(defn run-menu!
  ``Run the menu until it produces a request, or until the player quits.

  Returns `{:request r :state s}` on a decision, or nil when the window closed or
  the player quit from home. No world is created here and no catalogue is touched:
  this returns WHAT was asked for, and `main` decides how to build it.

  `frame-limit` bounds the loop for a capture, so `--menu-frames N` shows the menu
  without a human. It is a QA affordance, never a timeout on real input.

  `capture` is called with the current frame number AFTER drawing one frame and
  BEFORE it is presented, so a caller can write a screenshot of exactly what is on
  screen. It runs inside the loop because a screenshot written after the window
  closes has nothing left to read.

  Returns `{:request r :state s}`, `{:quit true :state s}` when the loop ended
  without a decision (frame limit reached, or the window closed), or nil.``
  [fns state keys &opt frame-limit capture art]
  (def adapter (rl-adapter fns))
  (def begin (fns :begin-drawing))
  (def finish (fns :end-drawing))
  (def clear (fns :clear-background))
  (def closing? (fns :window-should-close))
  (var s state)
  (var focus :name)
  (var done nil)
  (var frame 0)
  (var captured false)
  (while (and (nil? done)
              (or (nil? frame-limit) (< frame frame-limit))
              (not (closing?)))
    (def out (step s adapter keys focus))
    (set s (out :state))
    (set focus (out :focus))
    (when (out :request) (set done (out :request)))
    (begin)
    (clear (palette :bg))
    (def hits (draw s adapter focus nil art))
    (finish)
    # Mouse, when a pointer was injected. draw returned what it painted, so the
    # hit test uses the rectangles that are actually on screen this frame rather
    # than a second copy of the layout that could drift from the drawing.
    (when (and (array? hits) (nil? done) (adapter :mouse-clicked?))
      (each r hits
        (when ((adapter :mouse-clicked?) (r :x) (r :y) (r :w) (r :h))
          # `menu/step` applies an ACTION to the model; the view's `step` maps
          # keys onto those actions. A button already carries its action, so it
          # goes straight to the model -- the same one the keyboard would send.
          (set s (menu/step s (r :action))))))
    # Capture AFTER EndDrawing, on the last frame the loop will run.
    #
    # This is a correctness requirement, not a preference. The window is created
    # with a 4x MSAA hint, so the default framebuffer is MULTISAMPLED; reading it
    # before the swap returns the resolved-for-nothing buffer -- in practice the
    # clear colour with none of the text. A capture taken there produced a dark
    # rectangle with no UI in it, which is precisely what the QA screenshot showed.
    # Raylib's own guidance is the same: TakeScreenshot after EndDrawing.
    (when (and capture (not captured)
               (or (and (number? frame-limit) (>= (inc frame) frame-limit))
                   (not (nil? done))))
      (capture frame)
      (set captured true))
    (++ frame))
  (cond
    done {:request done :state s}
    # A bounded run that never reached a decision is a QUIT, not a menu that
    # silently fell through into worldgen. The caller must not build a world the
    # player never asked for.
    frame-limit {:quit true :state s :frame frame}
    nil))
