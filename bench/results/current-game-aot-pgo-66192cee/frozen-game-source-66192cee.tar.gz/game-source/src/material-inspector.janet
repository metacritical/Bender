# In-game material editor. No raylib import, filesystem access, or atlas mutation on import.
(import ./material-recipes :as materials)

(def kinds [:grain :noise :voronoi :wave :checker :brick :speckle])
(def block-types [:stone :dirt :grass :sand :water :wood :leaves :masonry :tiles])
(def panel-width 340)

(defn- copy [source]
  (let [out (table)]
    (each [k v] (pairs source) (put out k v))
    out))
(defn- state-with [state key value]
  (let [out (copy state)] (put out key value) out))
(defn- clamp [n lo hi] (max lo (min hi n)))
(defn- quantize [n] (math/floor (+ n 0.5)))
(defn- name-key [name]
  (when (and (string? name) (> (length name) 0)
             (every? (map (fn [c] (or (<= 48 c 57) (<= 65 c 90)
                                       (<= 97 c 122) (= c 45) (= c 95)))
                          (string/bytes name))))
    (keyword name)))

(defn file-revision [path]
  "Capture exact source bytes; nil means the file was absent, not unreadable."
  (let [f (file/open path :rb)]
    (when f
      (try (let [text (string (file/read f :all))] (file/close f) text)
           ([err] (file/close f) (error err))))))

(defn new-state [&opt entries path]
  "Create an editor with the active recipes and the source file's exact baseline."
  (let [path (or path "data/materials.janet")]
    {:entries (or entries materials/recipes) :path path
     :revision (file-revision path)
     :selected :stone :block :stone :mode :play :name "" :message ""
     :draft (get (or entries materials/recipes) :stone) :page :textures
     :scroll 0 :bindings {}}))

(defn transition [state action]
  "Pure transition returning {:state new-state :effect nil|{:type :apply|:save|:reload ...}}.
   Selection edits only draft, never active entries. Apply proposes the named recipe
   and fixed block key; caller commits returned state only after the GPU swap succeeds."
  (let [type (get action :type) draft (get state :draft)]
    (case type
      :mode {:state (state-with state :mode (if (= (get state :mode) :edit) :play :edit)) :effect nil}
      :select (let [key (get action :name) recipe (get (get state :entries) key)]
                (if (materials/validate recipe)
                  {:state (state-with (state-with state :selected key) :draft recipe) :effect nil}
                  {:state state :effect nil}))
      :page (if (some |(= $ (get action :name)) [:textures :values :colors :preview])
              {:state (state-with (state-with state :page (get action :name)) :scroll 0) :effect nil}
              {:state state :effect nil})
      :scroll {:state (state-with state :scroll
                                  (clamp (+ (get state :scroll 0) (get action :delta 0))
                                         0 (get action :max 0))) :effect nil}
      :block (if (some |(= $ (get action :name)) block-types)
               {:state (state-with state :block (get action :name)) :effect nil}
               {:state state :effect nil})
      :name {:state (state-with state :name (get action :value "")) :effect nil}
      :create (let [key (name-key (get state :name))]
                (if (and key (not (get (get state :entries) key)))
                  {:state (state-with (state-with state :selected key) :message "New draft; Apply to bind block") :effect nil}
                  {:state (state-with state :message "Enter a unique alphanumeric name") :effect nil}))
      :kind (let [idx (or (get action :index) 1)
                  old (get draft :kind)
                  pos (or (find-index |(= $ old) kinds) 0)
                  next (get kinds (mod (+ pos idx) (length kinds)))]
              {:state (state-with state :draft (state-with draft :kind next)) :effect nil})
      :adjust (let [field (get action :field) delta (get action :delta 0)
                    limits (case field
                             :brightness [0 2] :grain-density [0 16]
                             :pixel-size [1 64] :scale [0.01 4096]
                             :seed [-1000000 1000000] nil)]
                (if limits
                  (let [n (clamp (+ (get draft field (if (= field :pixel-size) 1 1.0)) delta)
                                 (get limits 0) (get limits 1))
                        n (if (or (= field :pixel-size) (= field :seed)) (quantize n) n)]
                    {:state (state-with state :draft (state-with draft field n)) :effect nil})
                  {:state state :effect nil}))
      :color (let [field (get action :field) channel (get action :channel)
                   delta (get action :delta 0)]
               (if (and (some |(= $ field) [:base :dark :light])
                        (number? channel) (<= 0 channel 3))
                 (let [color (get draft field)
                       updated (tuple # immutable RGBA, preserving all other components
                                 (if (= channel 0) (clamp (+ (get color 0) delta) 0 255) (get color 0))
                                 (if (= channel 1) (clamp (+ (get color 1) delta) 0 255) (get color 1))
                                 (if (= channel 2) (clamp (+ (get color 2) delta) 0 255) (get color 2))
                                 (if (= channel 3) (clamp (+ (get color 3) delta) 0 255) (get color 3)))]
                   {:state (state-with state :draft (state-with draft field updated)) :effect nil})
                 {:state state :effect nil}))
      :apply (if (materials/validate draft)
               (let [entries (copy (get state :entries)) key (get state :selected)
                     block (get state :block) bindings (copy (get state :bindings {}))]
                 (put entries key draft)
                 (put entries block draft)
                 (put bindings block key)
                 {:state state
                  :effect {:type :apply :block block :name key :recipe draft
                           :bindings bindings :entries entries}})
               {:state (state-with state :message "Invalid recipe") :effect nil})
      :save {:state state :effect {:type :save :entries (get state :entries)
                                    :path (get state :path) :revision (get state :revision)}}
      :reload {:state state :effect {:type :reload :path (get state :path)}}
      {:state state :effect nil})))

(defn accept-apply [state effect]
  "Commit the applied revision only after the caller swaps the live atlas."
  (if (= (get effect :type) :apply)
    (state-with (state-with (state-with state :entries (get effect :entries))
                            :bindings (get effect :bindings))
                :message "Applied to every block of this type")
    state))

(defn accept-reload [state entries &opt revision]
  "Call after source load and atlas swap succeed; commit the same source revision."
  (let [key (get state :selected) recipe (get entries key)]
    (state-with (state-with (state-with (state-with state :entries entries)
                                        :draft (if (materials/validate recipe) recipe materials/fallback))
                            :revision revision)
                :message "Reloaded")))

(defn perform [state effect]
  "Guard Save against external edits; Apply and GPU-backed Reload remain caller-owned."
  (case (get effect :type)
    :save (let [path (get effect :path)]
            (when (not= (file-revision path) (get effect :revision))
              (error "material file changed externally; Reload before Save"))
            (materials/save (get effect :entries) path)
            (state-with (state-with state :revision (file-revision path)) :message "Saved"))
    :reload (let [path (get effect :path) revision (file-revision path)
                  entries (materials/load path)]
              (accept-reload state entries revision))
    state))

(defn- inside? [x y left top width height]
  (and (<= left x (+ left width)) (<= top y (+ top height))))
(defn- draw-label [rl text x y color]
  ((get rl :draw-text) (string text) x y 16 color))
(defn- content-label [rl text x y color top bottom]
  (when (and (>= y top) (<= (+ y 16) bottom))
    (draw-label rl text x y color)))
(defn- button [rl text x y w pointer click &opt top bottom]
  (let [visible (or (nil? top) (and (>= y top) (<= (+ y 25) bottom)))
        hover (and visible (inside? (get pointer 0) (get pointer 1) x y w 25))]
    (when visible
      ((get rl :draw-rectangle) x y w 25 (if hover [70 90 115 255] [48 57 72 255]))
      ((get rl :draw-rectangle-lines) x y w 25 [105 123 146 255])
      (draw-label rl text (+ x 5) (+ y 4) [236 240 248 255]))
    (and click hover)))

(defn draw-input [state rl width height]
  "Draw right-docked panel INSIDE BeginDrawing/EndDrawing and process a frame's mouse.
   rl is the imported raylib module; return transition result. Call only while window
   exists. Input outside the panel is untouched. Invoke in edit mode to show controls."
  (let [x (max 0 (- width panel-width)) w (min width panel-width)
        pointer ((get rl :mouse-position))
        click ((get rl :mouse-pressed?) (get rl :mouse-button-left))
        text [235 239 245 255] muted [160 173 191 255]
        active (= (get state :mode) :edit)
        top 139 bottom (max top (- height 80))
        custom (length (filter (fn [[name recipe]]
                                 (not (some |(= $ name) block-types)))
                               (pairs (get state :entries))))
        content-height (case (get state :page :textures)
                         :textures (+ 31 25 26 (* (+ 9 custom) 27) 27)
                         :values 172 :colors 81 :preview 161 0)
        maximum (max 0 (- content-height (- bottom top)))
        wheel (if (and active (inside? (get pointer 0) (get pointer 1)
                                       x top w (- bottom top)) (get rl :mouse-wheel))
                ((get rl :mouse-wheel)) 0)
        scroll (clamp (- (get state :scroll 0) (* wheel 27)) 0 maximum)
        current (if (= scroll (get state :scroll 0)) state
                    (get (transition state {:type :scroll
                                            :delta (- scroll (get state :scroll 0))
                                            :max maximum}) :state))]
    ((get rl :draw-rectangle) x 0 w height [27 33 44 248])
    ((get rl :draw-rectangle-lines) x 0 w height [104 118 138 255])
    (draw-label rl "MATERIAL INSPECTOR" (+ x 12) 12 text)
    (var action nil)
    (when (button rl (if active "EDIT | switch to PLAY" "PLAY | switch to EDIT")
                  (+ x 12) 37 (- w 24) pointer click)
      (set action {:type :mode}))
    (when active
      (let [draft (get current :draft) selected (get current :selected)]
        (draw-label rl (string "Texture: " selected "  Block: " (get state :block)) (+ x 12) 75 text)
        (each [index page] (pairs [:textures :values :colors :preview])
          (when (button rl (string page) (+ x 12 (* index 79)) 99 77 pointer click)
            (set action {:type :page :name page})))
        (var row (- top scroll))
        (case (get state :page :textures)
          :textures (do
        (when (button rl "New named texture" (+ x 12) row (- w 24) pointer click top bottom)
          (set action {:type :create}))
        (set row (+ row 31))
        (content-label rl (string "Name: " (get state :name) " (type letters)") (+ x 12) row muted top bottom)
        (set row (+ row 25))
        (content-label rl "Textures (click to select draft)" (+ x 12) row muted top bottom)
        (set row (+ row 26))
        (each block block-types
          (when (button rl (string block) (+ x 12) row 98 pointer click top bottom)
            (set action {:type :block :name block}))
          (when (button rl (string "select " block) (+ x 115) row (- w 127) pointer click top bottom)
            (set action {:type :select :name block}))
          (set row (+ row 27)))
        (each [name recipe] (pairs (get state :entries))
          (when (and (not (some |(= $ name) block-types))
                     (button rl (string "select " name) (+ x 12) row (- w 24) pointer click top bottom))
            (set action {:type :select :name name}))
          (when (not (some |(= $ name) block-types)) (set row (+ row 27))))
        (when (and (not (get (get state :entries) selected))
                   (button rl (string "New draft: " selected) (+ x 12) row (- w 24) pointer click top bottom))
          (set action {:type :name :value (get state :name)}))
        (when (not (get (get state :entries) selected)) (set row (+ row 27)))
        )
          :values (do
        (when (button rl (string "Kind: " (get draft :kind) " >") (+ x 12) row (- w 24) pointer click top bottom)
          (set action {:type :kind}))
        (set row (+ row 32))
        (each [field step] [[:brightness 0.1] [:grain-density 0.25] [:pixel-size 1] [:scale 1] [:seed 1]]
          (content-label rl (string field ": " (get draft field (if (= field :pixel-size) 1 1.0))) (+ x 12) row text top bottom)
          (when (button rl "-" (+ x (- w 75)) row 24 pointer click top bottom)
            (set action {:type :adjust :field field :delta (- step)}))
          (when (button rl "+" (+ x (- w 43)) row 24 pointer click top bottom)
            (set action {:type :adjust :field field :delta step}))
          (set row (+ row 28)))
        )
          :colors (do
        (each field [:base :dark :light]
          (content-label rl (string field) (+ x 12) row text top bottom)
          (for channel 0 4
            (let [left (+ x 75 (* channel 61)) value (get (get draft field) channel)]
              (when (button rl (string value) left row 56 pointer click top bottom)
                (set action {:type :color :field field :channel channel
                             :delta (if ((get rl :key-down?) (get rl :key-left-shift)) -8 8)}))))
          (set row (+ row 27)))
        )
          :preview (do
        (content-label rl "PREVIEW (draft only)" (+ x 12) row muted top bottom)
        (set row (+ row 22))
        (for py 0 8 (for px 0 16
          (let [y (+ row (* py 16))]
            (when (and (>= y top) (<= (+ y 16) bottom))
              ((get rl :draw-rectangle) (+ x 12 (* px 16)) y 16 16
               (materials/sample draft (* px 2) (* py 2)))))))
        (set row (+ row 139))
        )
          nil)
        (each [title type index] [["APPLY" :apply 0] ["SAVE" :save 1] ["RELOAD" :reload 2]]
          (when (and (>= height 205)
                     (button rl title (+ x 12 (* index 105)) (- height 68) 100 pointer click))
            (set action {:type type})))
        (when (>= height 205)
          (draw-label rl (string "Scroll " (quantize scroll) "/" (quantize maximum)
                                 "  " (get current :message)) (+ x 12) (- height 34) muted))
        (when (and (not action) ((get rl :key-pressed?) (get rl :key-backspace))
                   (> (length (get state :name)) 0))
          (set action {:type :name :value (string/slice (get state :name) 0 -1)}))
        (when (not action)
          (let [char ((get rl :char-pressed))]
            (when (and (<= 33 char 126) (< (length (get state :name)) 24))
              (set action {:type :name :value (string (get state :name) (string/from-bytes char))}))))))
    (if action (transition current action) {:state current :effect nil})))
