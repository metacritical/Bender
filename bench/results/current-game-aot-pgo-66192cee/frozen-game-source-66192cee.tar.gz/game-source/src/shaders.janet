# Trinecraft — GLSL for the voxel chunk material.
#
# Kept as source strings rather than loose .vs/.fs files so the GLSL sits
# beside the Janet that sets its uniforms; the two drift apart otherwise.
#
# Targets GLSL 3.30 core, which is what raylib's desktop GL 3.3 backend uses
# on macOS. The attribute and uniform NAMES are not free: raylib binds
# `vertexPosition`, `vertexTexCoord`, `vertexNormal`, `vertexColor`, `mvp`,
# `matModel` and `texture0` by default (see rlgl.h
# RL_DEFAULT_SHADER_ATTRIB_NAME_*). Renaming any of them silently breaks the
# binding and the mesh renders black or not at all.
#
# This is the foundation Phase 12 builds on: ambient occlusion, coloured
# block light and emissive surfaces all arrive through `vertexColor`, and the
# atmosphere terms through uniforms set per frame.

(def chunk-vertex-shader
  ```
#version 330

in vec3 vertexPosition;
in vec2 vertexTexCoord;
in vec3 vertexNormal;
in vec4 vertexColor;

uniform mat4 mvp;
uniform mat4 matModel;

out vec2 fragTexCoord;
out vec4 fragColor;
out vec3 fragNormal;
out vec3 fragWorldPos;

void main()
{
    fragTexCoord = vertexTexCoord;
    // The mesher bakes directional shading here, and ambient occlusion
    // will join it. Carried through untouched; the fragment stage decides
    // what it means.
    fragColor    = vertexColor;
    fragNormal   = vertexNormal;
    fragWorldPos = (matModel * vec4(vertexPosition, 1.0)).xyz;
    gl_Position  = mvp * vec4(vertexPosition, 1.0);
}
```)

(def chunk-fragment-shader
  ```
#version 330

in vec2 fragTexCoord;
in vec4 fragColor;
in vec3 fragNormal;
in vec3 fragWorldPos;

uniform sampler2D texture0;
uniform vec4 colDiffuse;

// Set per frame from Janet. Defaults chosen so a missing uniform still
// renders something sane rather than a black screen.
uniform vec3  sunDirection;
uniform vec3  sunColor;
uniform vec3  ambientColor;
uniform vec3  fogColor;
uniform vec3  cameraPos;
uniform float fogDensity;
uniform float time;
uniform float underwater;
uniform float causticStrength;
uniform float underwaterTintStrength;

out vec4 finalColor;

// Caustics: the bright shifting filaments cast on a lake bed by a rippling
// surface above. Three rotating sine lattices interfere; taking 1-|v| and
// raising it to a power turns the interference nodes into thin filaments
// rather than soft blobs. World-space, so it does not tile.
float caustics(vec2 p, float t)
{
    float v = 0.0;
    v += sin(p.x * 1.71 + p.y * 0.63 + t * 1.30);
    v += sin(p.x * -0.91 + p.y * 1.43 - t * 1.07);
    v += sin((p.x + p.y) * 1.13 + t * 0.81);
    v /= 3.0;
    float fil = 1.0 - abs(v);
    return pow(clamp(fil, 0.0, 1.0), 7.0);
}

void main()
{
    vec4 texel = texture(texture0, fragTexCoord);
    if (texel.a < 0.01) discard;

    // Lambert term against the sun, lifted so faces turned away are shaded
    // rather than black -- a voxel world with true black undersides reads as
    // broken geometry, not as darkness.
    vec3  n       = normalize(fragNormal);
    float lambert = max(dot(n, normalize(-sunDirection)), 0.0);

    // The ambient cycle owns the baseline: a fixed half-Lambert floor would
    // turn even a weak night sun into broad illumination on shaded faces.
    // Bound the sun contribution by remaining headroom to avoid day clipping.
    vec3 light = ambientColor + (1.0 - ambientColor) * sunColor * lambert;

    // fragColor carries the mesher's baked shade / AO, multiplied in.
    vec3 lit = texel.rgb * colDiffuse.rgb * fragColor.rgb * light;

    // Exponential-squared distance fog gives aerial perspective: far terrain
    // recedes into the sky colour instead of ending at a hard draw boundary.
    float dist = length(fragWorldPos - cameraPos);

    if (underwater > 0.5) {
        // Caustics land on upward-facing surfaces, which is where a real
        // surface above would project them, and fade with depth below.
        float up = max(n.y, 0.0);
        float c  = caustics(fragWorldPos.xz * 0.9, time);
        // Cool filaments on the floor, restrained enough to preserve its
        // texture; they are not white stripes painted on every block.
        lit += vec3(0.42, 0.72, 0.68) * c * up * causticStrength
               * clamp(max(max(ambientColor.r, ambientColor.g), ambientColor.b)
                       + max(max(sunColor.r, sunColor.g), sunColor.b), 0.0, 1.0);

        // Entering water changes the near field immediately; absorption
        // then builds smoothly with view distance instead of leaving nearby
        // sand yellow while only the horizon goes blue.
        vec3  absorb = vec3(0.42, 0.88, 0.95);
        float t      = clamp(dist / 26.0, 0.0, 1.0);
        lit *= mix(vec3(1.0), absorb, t);
        // Preserve a small cool near-field readability floor underwater;
        // fade it with the same distance absorption instead of lighting land.
        lit  = mix(lit, vec3(0.03, 0.17, 0.26), t * underwaterTintStrength);
    } else {
        float f = 1.0 - exp(-pow(dist * fogDensity, 2.0));
        lit     = mix(lit, fogColor, clamp(f, 0.0, 1.0));
    }

    finalColor = vec4(lit, texel.a * colDiffuse.a * fragColor.a);
}
```)

(defn default-atmosphere
  ``Uniform values for a clear day. Phase 12's day/night cycle will drive
  these; for now they are a fixed, readable look.``
  []
  @{:sun-direction [-0.45 -0.78 -0.43]
    :sun-color [0.98 0.95 0.86]
    :ambient-color [0.34 0.38 0.46]
    :fog-color [0.56 0.78 0.94]
    :fog-density 0.0045})

#
# --- Water --------------------------------------------------------------
#
# Deliberately samples NO texture. A tiled atlas tile is what produces the
# repeating grid on a large body of water, and at distance that same tile
# minifies into moire banding. Everything here is a function of world
# position and time instead, so there is no tile to repeat and nothing to
# alias: detail simply fades out with distance.

(def water-vertex-shader
  ```
#version 330

in vec3 vertexPosition;
in vec2 vertexTexCoord;
in vec3 vertexNormal;
in vec4 vertexColor;

uniform mat4 mvp;
uniform mat4 matModel;
uniform float time;

out vec4  fragColor;
out vec3  fragNormal;
out vec3  fragWorldPos;
out float fragWave;

void main()
{
    vec4 local = vec4(vertexPosition, 1.0);
    vec4 world = matModel * local;

    // vertexColor.g marks the surface plane: only the top displaces, so the
    // sides of a water body stay welded to it and no gap opens at the shore.
    float isTop = vertexColor.g;

    // Two travelling swells at unrelated angles and periods. Unrelated
    // matters: harmonically related waves re-synchronise into a visible
    // repeating grid, which is the thing we are avoiding.
    float w1 = sin(world.x * 0.62 + world.z * 0.21 + time * 1.10);
    float w2 = sin(world.x * 0.17 - world.z * 0.74 + time * 0.83);
    float wave = (w1 + w2) * 0.5;

    float displacement = wave * 0.055 * isTop;
    world.y += displacement;
    local.y += displacement;

    fragWave     = wave;
    fragColor    = vertexColor;
    fragNormal   = vertexNormal;
    fragWorldPos = world.xyz;
    // raylib's mvp already includes matModel. Transform local only once.
    gl_Position  = mvp * local;
}
```)

(def water-fragment-shader
  ```
#version 330

in vec4  fragColor;
in vec3  fragNormal;
in vec3  fragWorldPos;
in float fragWave;

uniform vec3  sunDirection;
uniform vec3  sunColor;
uniform vec3  ambientColor;
uniform vec3  fogColor;
uniform vec3  cameraPos;
uniform float fogDensity;
uniform float time;
uniform float underwater;
uniform float waterDetailDistance;
uniform float waterNormalStrength;
uniform float waterSpecularPower;
uniform float waterSpecularStrength;
uniform float waterFresnelStrength;
uniform float waterRippleStrength;
uniform float waterAlphaShallow;
uniform float waterAlphaDeep;
uniform float waterAlphaFresnel;
uniform float waterAlphaCap;

out vec4 finalColor;

// Layered sine ripples in world space. No UVs, so no tiling.
float ripple(vec2 p, float t)
{
    float v = 0.0;
    v += sin(p.x * 1.93 + p.y * 0.71 + t * 1.6);
    v += sin(p.x * -0.83 + p.y * 1.57 - t * 1.2);
    v += sin((p.x + p.y) * 1.21 + t * 0.9);
    return v / 3.0;
}

void main()
{
    vec3  viewVec = cameraPos - fragWorldPos;
    float dist    = length(viewVec);
    vec3  viewDir = viewVec / max(dist, 0.0001);

    // Ripple detail fades out with distance. This is the anti-banding term:
    // high-frequency surface detail at range is exactly what aliases into
    // moire, so it is removed before it can alias rather than filtered after.
    float detailFade = clamp(1.0 - dist / waterDetailDistance, 0.0, 1.0);
    float r  = ripple(fragWorldPos.xz, time) * detailFade;

    // Reference ripple-driven normals; surface mask and distance fade keep
    // side faces flat and remove fine highlights before they alias at range.
    vec3 n = normalize(fragNormal + vec3(r, 0.0, r)
                       * waterNormalStrength * fragColor.g);

    // Depth came from the mesher in the red channel: shallows read light and
    // clear, deep water dark and saturated.
    float depth   = fragColor.r;
    vec3  shallow = vec3(0.21, 0.58, 0.63);
    vec3  deep    = vec3(0.016, 0.13, 0.32);
    vec3  body    = mix(shallow, deep, clamp(depth, 0.0, 1.0));

    // Fresnel: looking straight down you see through it, at a grazing angle
    // it turns to sky. This is most of what makes water read as water.
    float facing  = clamp(dot(n, viewDir), 0.0, 1.0);
    float fresnel = pow(1.0 - facing, 3.0);

    vec3  sunDir   = normalize(-sunDirection);
    float lambert  = max(dot(n, sunDir), 0.0);
    vec3  lit      = body * (ambientColor + (1.0 - ambientColor)
                            * sunColor * lambert);

    // Sharp specular glint, surface only.
    vec3  halfVec = normalize(sunDir + viewDir);
    float spec    = pow(max(dot(n, halfVec), 0.0), waterSpecularPower)
                    * fragColor.g * detailFade * step(0.0, dot(n, sunDir));

    vec3 col = mix(lit, fogColor, fresnel * waterFresnelStrength * fragColor.g);
    col += sunColor * spec * waterSpecularStrength;
    col += ambientColor * vec3(0.05, 0.09, 0.10) * r * fragColor.g * waterRippleStrength;

    // Transparency: clear when looked through, opaque at grazing angles and
    // over depth. Underwater the surface above should stay readable, so it
    // never goes fully opaque there.
    float alpha = mix(waterAlphaShallow, waterAlphaDeep, clamp(depth, 0.0, 1.0));
    alpha = clamp(alpha + fresnel * waterAlphaFresnel, 0.0, waterAlphaCap);
    if (underwater > 0.5) alpha = min(alpha, 0.55);

    // Distance fog, matching the terrain so the waterline recedes with it.
    float f = 1.0 - exp(-pow(dist * fogDensity, 2.0));
    col = mix(col, fogColor, clamp(f, 0.0, 1.0));

    // Ordered dither, +-1/255. Large smooth gradients over a wide water body
    // quantise into visible steps in 8-bit; a sub-LSB dither breaks the step
    // edges without being visible itself.
    float d = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
    col += (d - 0.5) / 255.0;

    finalColor = vec4(col, alpha);
}
```)
