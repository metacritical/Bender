# First-seen block palette with low-bit-first, byte-aligned index packing.
# Every bit operation stays within one byte to avoid Bender's signed i32 overflow.

(defn- index-width [n]
  (cond (<= n 2) 1
        (<= n 4) 2
        (<= n 16) 4
        (<= n 256) 8
        (error "palette exceeds 256 distinct block IDs")))

(defn pack [blocks]
  (let [palette @[]
        indices @[]
        lookup @{}
        count (length blocks)]
    (each block blocks
      (let [index (get lookup block)]
        (if (nil? index)
          (let [next-index (length palette)]
            (when (>= next-index 256)
              (error "palette exceeds 256 distinct block IDs"))
            (put lookup block next-index)
            (array/push palette block)
            (array/push indices next-index))
          (array/push indices index))))
    (let [bits (index-width (length palette))
          per-byte (/ 8 bits)
          bytes (math/ceil (/ count per-byte))
          data (buffer/new-filled bytes 0)]
      (for i 0 count
        (let [byte-index (math/floor (/ i per-byte))
              shift (* (mod i per-byte) bits)]
          (put data byte-index
               (bor (get data byte-index)
                    (blshift (get indices i) shift)))))
      @{:palette palette :bits bits :count count :data data})))

(defn unpack [packed]
  (let [palette (get packed :palette)
        bits (get packed :bits)
        count (get packed :count)
        data (get packed :data)
        per-byte (/ 8 bits)
        mask (- (blshift 1 bits) 1)
        blocks (buffer/new-filled count 0)]
    (for i 0 count
      (let [byte-index (math/floor (/ i per-byte))
            shift (* (mod i per-byte) bits)
            index (band mask (brshift (get data byte-index) shift))]
        (put blocks i (get palette index))))
    blocks))

# In-memory representation: one byte for each first-seen palette ID, plus
# exactly enough data bytes to hold all indices (no container/header overhead).
(defn packed-bytes [packed]
  (+ (length (get packed :palette)) (length (get packed :data))))

(defn compression-ratio [packed]
  (/ (get packed :count) (packed-bytes packed)))
