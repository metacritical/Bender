# Pure sky-cycle sampling. World coordinates are x east, y up, z north.
# (frame elapsed &opt options) accepts seconds and optional keyword table:
# :duration positive seconds (default 1200), :time-offset seconds (default 0),
# :seed integer (default 1), :star-count integer 0..1024 (default 128).
# Noon is phase .25, sunset .5, midnight .75, sunrise 0; phase wraps in [0,1).
# All colors/intensities are linear unit-range values. Directions are unit vectors.
# Returned :stars are deterministic world-space {:direction [x y z] :brightness b}
# records, independent of time; :cloud-offset wraps in [0,1) without accumulating
# state. No clocks, random state, graphics calls, or mutable module globals.

(def pi 3.141592653589793)
(def tau (* 2 pi))
(defn- clamp [x lo hi] (max lo (min hi x)))
(defn- wrap [x] (- x (math/floor x)))
(defn- smooth [x] (let [t (clamp x 0 1)] (* t t (- 3 (* 2 t)))))
(defn- mix [a b t] (+ a (* (- b a) t)))
(defn- rgb [a b t] (map |(mix $0 $1 t) a b))
(defn- unit [x y z]
  (let [r (math/sqrt (+ (* x x) (* y y) (* z z)))]
    [(/ x r) (/ y r) (/ z r)]))

# Avalanche each input independently before combining it with the next one.
# All operands are reduced to signed 32-bit for bender's bit operators. The
# multiplier below is below 2^21, so every product of a 31-bit residue remains
# below 2^52 and is exact even when Janet numbers use double precision.
(def hash-prime 2147483647)
(defn- signed32 [n]
  (let [v (mod n 4294967296)]
    (if (>= v 2147483648) (- v 4294967296) v)))
(defn- avalanche [value]
  (var n (mod value hash-prime))
  (when (neg? n) (set n (+ n hash-prime)))
  (set n (bxor (signed32 n) (brshift (signed32 n) 15)))
  (set n (mod (* (mod n hash-prime) 1597337) hash-prime))
  (set n (bxor (signed32 n) (brshift (signed32 n) 13)))
  (set n (mod (* (mod n hash-prime) 1258291) hash-prime))
  (set n (bxor (signed32 n) (brshift (signed32 n) 16)))
  (mod n hash-prime))
(defn- hash-unit [seed index lane]
  (let [seed-hash (avalanche (+ seed 104729))
        index-hash (avalanche (+ index 15485863))
        lane-hash (avalanche (+ lane 32452843))
        mixed (avalanche (bxor (signed32 seed-hash) (signed32 index-hash)))]
    (/ (avalanche (bxor (signed32 mixed) (signed32 lane-hash)))
       2147483647.0)))

(defn stars
  ``Stable world-space upper-hemisphere star directions for seed and count.
  Count is clamped to 0..1024. Each brightness is in [0,1].``
  [seed count]
  (let [n (clamp (math/floor count) 0 1024)
        out @[]]
    (for i 0 n
      (let [y (+ 0.08 (* 0.92 (hash-unit seed i 0)))
            a (* tau (hash-unit seed i 1))
            h (math/sqrt (- 1 (* y y)))]
        (array/push out {:direction [(* h (math/cos a)) y (* h (math/sin a))]
                         :brightness (+ 0.35 (* 0.65 (hash-unit seed i 2)))})))
    out))

(defn frame
  ``Sample a complete bounded sky frame from elapsed seconds and optional settings.
  Fields: :phase; :sun-direction, :moon-direction; :zenith, :horizon, :fog,
  :ambient-color, :sun-color; :ambient-intensity, :sun-intensity,
  :star-intensity; :cloud-offset; :stars. Invalid nonpositive duration falls
  back to 1200 seconds. Sampling is periodic and has no side effects.``
  [elapsed &opt options]
  (let [opts (or options {})
        requested (get opts :duration 1200)
        duration (if (> requested 0) requested 1200)
        time-offset (get opts :time-offset 0)
        phase (wrap (/ (+ elapsed time-offset) duration))
        angle (* tau phase)
        elevation (math/sin angle)
        # Full continuous east-to-west orbit: elevation approaches the horizon
        # at sunrise/sunset without a direction jump at the cycle seam.
        sun (unit (math/cos angle) elevation (* 0.25 (math/cos angle)))
        daylight (smooth (/ (+ elevation 0.12) 0.32))
        twilight (* (smooth (/ (+ elevation 0.25) 0.28))
                    (- 1 (smooth (/ (- elevation 0.08) 0.35))))
        # Twilight colors stay vertically separated: deep blue overhead,
        # violet lower sky, and orange only at the horizon.
        zenith (rgb (rgb [0.012 0.021 0.06] [0.075 0.085 0.29] twilight)
                    [0.17 0.37 0.76] (* daylight (- 1 twilight)))
        horizon (rgb [0.025 0.035 0.075]
                     (rgb [0.50 0.64 0.88] [1.0 0.34 0.12] twilight) daylight)
        fog (rgb zenith horizon 0.72)
        ambient-color (rgb [0.17 0.22 0.38] [0.72 0.81 1.0] daylight)
        sun-color (rgb [1.0 0.54 0.31] [1.0 0.95 0.82]
                       (smooth (/ elevation 0.5)))
        star-intensity (- 1 (smooth (/ (+ elevation 0.18) 0.3)))
        seed (get opts :seed 1)]
    {:phase phase
     :sun-direction sun
     :moon-direction (map |(- $0) sun)
     :zenith zenith :horizon horizon :fog fog
     :ambient-color ambient-color :sun-color sun-color
     :ambient-intensity (mix 0.13 0.78 daylight)
     :sun-intensity daylight
     :star-intensity star-intensity
     :cloud-offset [(wrap (/ (+ elapsed time-offset) (* duration 2.7)))
                    (wrap (/ (+ elapsed time-offset) (* duration 4.1)))]
     :stars (stars seed (get opts :star-count 128))}))
