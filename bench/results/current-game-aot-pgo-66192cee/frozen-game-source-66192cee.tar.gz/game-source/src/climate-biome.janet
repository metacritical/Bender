# Trinecraft — climate to biome classification. Pure, versioned, no I/O.
#
# OWNERSHIP. This module owns one decision: given the five climate channels, an
# elevation and a sea level, which biome is at a column. It does not read a
# file, does not import the world, the atlas, raylib or any GL, and holds no
# mutable state. It is a pure function plus a fixed vocabulary.
#
# IT IS A LAYER OVER A READER, NOT OVER THE PRODUCER. Its input is the structure
# `src/climate-tile.janet` returns, and it is not integrated into any generator.
# Nothing calls it from `main.janet`, `scene-opts`, `worldgen` or the cache. It
# runs only in its own tests, on synthetic fixtures that stand in for a decoded
# buffer. That is deliberate: the producer does not emit climate today, so a
# wired-in classifier would be classifying nothing.
#
# THE UNITS QUESTION, ANSWERED AS A FLAG.
#
# Channel units are established from source but NOT measured -- see
# `src/climate-tile.janet`'s `unit-basis`. Thresholds in degrees and millimetres
# are therefore provisional. Rather than hide that, every result carries the
# basis it was produced under, and `classify` refuses to answer when the basis is
# not established. A caller checks `verified?` and knows how much weight the
# answer bears.
#
# SEASONALITY IS IN UPSTREAM'S DOCUMENTED x100 FORM. This is the one place a
# naive implementation goes wrong: `minecraft_api.py:196` states "Temperature
# seasonality (std * 100, so 400 = 4C std)". So a threshold of 300 below means
# "a 3C standard deviation", NOT "3 degrees". Reading the stored value as a
# temperature would put every column in one class. The divisor is named
# `seasonality-scale` so the conversion is visible in exactly one place.
#
# THRESHOLDS ARE AUTHORED, NOT MEASURED, and deliberately coarse. They describe a
# small biome set the engine's nine block ids could plausibly express.
# `biome-revision` must be bumped when any number here changes, because a stored
# classification made under different numbers is not the same classification.

(import ./climate-tile :as tile)

(def version 1)

#: Bumped when any threshold, or the rule order, changes.
(def biome-revision 1)

#: `:unknown` is the only answer that means "no climate data". It is never a
#: place on the map.
#:
#: EVERY MEMBER HERE IS SOMETHING `classify` CAN RETURN, and every keyword
#: `classify` can return is a member. `:savanna` was missing while `classify-valid`
#: already returned it for warm wet ground; adding it is a METADATA correction, not
#: a rule change, so `biome-revision` is deliberately NOT bumped: no threshold, no
#: rule order and no classification result moved. Only the vocabulary now admits an
#: answer the classifier was already giving.
(def biomes
  [:unknown :ocean :shore :ice :tundra :taiga
   :temperate-forest :grassland :savanna :desert])

(def biome-set (zipcoll biomes biomes))
(defn biome? [b] (truthy? (get biome-set b)))

#: Divisor converting a stored seasonality value to a standard deviation in
#: degrees C. Upstream documents the stored form as std*100, so 400 -> 4.0.
(def seasonality-scale 100)

#: Authored thresholds, in the units the reader declares.
(def thresholds
  {:frozen-temperature    0.0    # degrees C
   :cold-temperature      6.0    # degrees C
   :warm-temperature     20.0    # degrees C
   :arid-precipitation  250.0    # mm/yr
   :forest-precipitation 700.0   # mm/yr
   :shore-height          3      # blocks above sea level
   :seasonality-high    300.0})  # stored form, i.e. a 3 degrees C std

#
# --- Input validation ---------------------------------------------------
#

(defn- finite? [n]
  (and (number? n) (not (nan? n)) (< -1e308 n) (< n 1e308)))

(defn- climate-keys []
  [:temperature :temperature-seasonality :precipitation
   :precipitation-variability :lapse-rate])

(defn valid-climate?
  ``Are all five channels present and finite?

  Shape and finiteness only. It deliberately does NOT range-check, because no
  measured range exists to check against: an implausible value still classifies,
  landing at the end of whichever axis it belongs to.``
  [climate]
  (and (or (table? climate) (struct? climate))
       (= 5 (length (keys climate)))
       (every? (map (fn [k] (finite? (get climate k))) (climate-keys)))))

(defn source
  ``Where the climate came from: a reader result's status, or `:absent` for nil.

  Exists so a caller can log or branch on provenance without reaching into the
  reader's internals.``
  [result]
  (if (nil? result) :absent (get result :status)))

#
# --- The classifier -----------------------------------------------------
#

(defn- classify-valid
  "Classify known-good inputs. `classify` validates first, so this has no gap arm."
  [climate elevation sea]
  (def temperature (climate :temperature))
  (def precipitation (climate :precipitation))
  # Convert the stored seasonality to a standard deviation in degrees C before
  # comparing it to anything, so the rule below reads in physical terms.
  (def seasonality (/ (climate :temperature-seasonality) seasonality-scale))
  (def frozen (<= temperature (thresholds :frozen-temperature)))
  (def arid (<= precipitation (thresholds :arid-precipitation)))
  # Order is the rule and it is significant: water and ice are decided by
  # position before climate, because a frozen ocean is ice whatever its annual
  # mean, and an ocean column's temperature describes the air above it.
  (cond
    (<= elevation sea) :ocean
    (<= elevation (+ sea (thresholds :shore-height))) :shore
    frozen :ice
    (< temperature (thresholds :cold-temperature))
    (if (> precipitation (thresholds :forest-precipitation)) :taiga :tundra)
    arid :desert
    (>= temperature (thresholds :warm-temperature))
    (if (> precipitation (thresholds :forest-precipitation)) :savanna :grassland)
    (> precipitation (thresholds :forest-precipitation)) :temperate-forest
    # Seasonality separates a strongly seasonal grassland from an even one. Both
    # are :grassland in this vocabulary, which has no separate member; the
    # conversion above is what makes adding one a rule change rather than a
    # units bug. It is computed so the conversion is exercised and tested.
    (do (def _seasonal (> seasonality (/ (thresholds :seasonality-high)
                                         seasonality-scale)))
        :grassland)))

(defn classify
  ``The biome at one column, or the reason there is no answer.

  `climate` is the five-channel structure from a decoded, validated climate
  result. `elevation` and `sea` are both in WORLD BLOCKS -- comparing metres
  against blocks would classify every column as ocean, and the caller owns that.

  Answers:

    * `{:status :classified :biome .. :biome-revision .. :units .. :verified?}`
    * `{:status :unknown :reason :no-climate | :non-finite | :bad-elevation |
                              :bad-sea-level}`
    * `{:status :unavailable :reason :unverified-units}` when the channel units
      are not established well enough to interpret the thresholds

  ONE answer is never given: there is no default biome. A caller that ignores
  `:status` still cannot receive an inhabited biome, because `biome-of` maps
  every non-classification onto `:unknown`.``
  [climate elevation sea]
  (def units tile/unit-basis)
  (cond
    (nil? climate) @{:status :unknown :reason :no-climate
                     :biome-revision biome-revision :units units}
    (not (valid-climate? climate))
    @{:status :unknown
      # A right-shaped table that fails validation can only be non-finite,
      # because `valid-climate?` checks nothing else.
      :reason (if (and (or (table? climate) (struct? climate))
                       (= 5 (length (keys climate))))
                :non-finite :no-climate)
      :biome-revision biome-revision :units units}
    (not (finite? elevation)) @{:status :unknown :reason :bad-elevation
                                :biome-revision biome-revision :units units}
    (not (finite? sea)) @{:status :unknown :reason :bad-sea-level
                          :biome-revision biome-revision :units units}
    (not (tile/units-verified?)) @{:status :unavailable
                                   :reason :unverified-units
                                   :biome-revision biome-revision :units units}
    (let [biome (classify-valid climate elevation sea)]
      @{:status :classified :biome biome
        :biome-revision biome-revision :units units
        :verified? (tile/units-measured?)})))

(defn classified? [r] (= :classified (get r :status)))
(defn unknown? [r] (= :unknown (get r :status)))
(defn unavailable? [r] (= :unavailable (get r :status)))

(defn biome-of
  ``The biome keyword, or `:unknown`. For a caller that wants only the answer.

  The ONLY place a non-classification becomes a keyword, and it becomes
  `:unknown` -- the member meaning "no answer". Never a real biome, so a caller
  ignoring `:status` cannot accidentally receive a fabricated one.``
  [result]
  (if (classified? result) (get result :biome) :unknown))

(defn verified?
  "Did the classification rest on MEASURED units, or only source-derived ones?"
  [result]
  (truthy? (get result :verified?)))
