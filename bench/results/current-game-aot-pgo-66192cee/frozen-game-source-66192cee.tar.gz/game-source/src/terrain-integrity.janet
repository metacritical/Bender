# CRC-32/ISO-HDLC for local terrain-cache and region corruption detection.
# This is not authentication. Generation identities remain Python SHA-256 keys.

(defn- shift-one [n]
  (band (brshift n 1) 2147483647))

(def crc-table
  (tuple ;(map
    (fn [byte]
      (var crc byte)
      (repeat 8
        (set crc (if (= 1 (band crc 1))
                   (bxor (shift-one crc) -306674912) # reflected 0xedb88320
                   (shift-one crc))))
      crc)
    (range 256))))

(defn crc32
  "Unsigned CRC-32 of a string or buffer. Check value: 123456789 -> cbf43926."
  [bytes]
  (unless (or (string? bytes) (buffer? bytes))
    (error "crc32 requires a string or buffer"))
  (var crc -1)
  (for i 0 (length bytes)
    (def index (band (bxor crc (get bytes i)) 255))
    # Signed bitwise operations require a signed operand. This masks an
    # arithmetic shift to implement the unsigned right shift by eight.
    (set crc (bxor (band (brshift crc 8) 16777215) (get crc-table index))))
  (def result (bnot crc))
  (if (< result 0) (+ result 4294967296) result))

(defn crc32-hex [bytes]
  (string/format "%08x" (crc32 bytes)))
