# Trinecraft — the nine shipped block descriptors. Read-only, pure, no init.
# DESCRIBES blocks; registers none. No atlas/GL/fs/world import, so importing
# this file can change no pixel and no saved byte. src/world.janet stays the
# authority for storage and IDs; the tests assert agreement in both directions.
#
# :spawn-ground? is the natural spawn floor, deliberately NARROWER than
# solidity: often you CAN stand on a tree, but spawn must not seat the player in
# a canopy, so wood and leaves are false. This mirrors spawn.janet's own rule
# (stone dirt grass sand snow) rather than the weaker "is it solid".
#
# Planned names carry :available false and NO :id. An unassigned ID is not a
# reservation: IDs are file-format content, so assigning one is a versioned
# contract change, not a table entry.
(def version 1)
(def block-count 9)

# Tuples of struct literals: immutable by construction, so no caller can mutate
# the registry and no freeze is needed. Lookups use find over nine entries,
# which keeps the module free of any mutable state whatsoever.
(def descriptors
  (tuple
    {:id 0 :name :air :solid false :opaque false :spawn-ground? false}
    {:id 1 :name :stone :solid true :opaque true :spawn-ground? true}
    {:id 2 :name :dirt :solid true :opaque true :spawn-ground? true}
    {:id 3 :name :grass :solid true :opaque true :spawn-ground? true}
    {:id 4 :name :sand :solid true :opaque true :spawn-ground? true}
    {:id 5 :name :water :solid false :opaque false :spawn-ground? false}
    {:id 6 :name :wood :solid true :opaque true :spawn-ground? false}
    {:id 7 :name :leaves :solid true :opaque true :spawn-ground? false}
    {:id 8 :name :snow :solid true :opaque true :spawn-ground? true}))

# Roadmap names, unavailable. No :id, no physics, no atlas tile: the 4x4 atlas
# has six free tiles and tile-for has no arm for an unregistered ID.
(def planned
  (tuple
    {:name :topsoil :available false} {:name :clay :available false}
    {:name :sandstone :available false} {:name :limestone :available false}
    {:name :slate :available false} {:name :basalt :available false}
    {:name :iron-ore :available false} {:name :copper-ore :available false}
    {:name :gold-ore :available false} {:name :titanium-ore :available false}
    {:name :titanium :available false}))

(defn by-id [id]
  "The frozen descriptor for a live ID, or nil for anything that is not one."
  (when (and (number? id) (= id (math/floor id)))
    (find (fn [d] (= id (get d :id))) descriptors)))
(defn by-name [name]
  "The frozen descriptor for a live block name, or nil."
  (when (keyword? name)
    (find (fn [d] (= name (get d :name))) descriptors)))
(defn name->id [name]
  "Live ID for a name; nil for unknown and for every planned name."
  (def d (by-name name)) (when d (get d :id)))
(defn id->name [id]
  "Live block name for an ID, or nil."
  (def d (by-id id)) (when d (get d :name)))
(defn spawn-ground? [x]
  "True when the name or descriptor is a natural spawn floor."
  (def d (if (keyword? x) (by-name x) x))
  (and (not (nil? d)) (true? (get d :spawn-ground?))))
(defn planned-name? [name]
  "True for a roadmap name that owns no block ID."
  (and (keyword? name) (not (nil? (find |(= name (get $ :name)) planned)))))
(defn ids [] "Every live block ID, in order." (tuple ;(map |(get $ :id) descriptors)))
(defn valid? []
  "IDs are exactly 0..block-count-1, names unique, planned owns no id."
  (and (= block-count (length descriptors))
       (= (ids) (tuple ;(range 0 block-count)))
       (= (length descriptors) (length (distinct (map |(get $ :name) descriptors))))
       (every? (map |(not (has-key? $ :available)) descriptors))
       (every? (map |(not (has-key? $ :id)) planned))))
