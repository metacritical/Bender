# Screen-space sky; call draw after begin-drawing and BEFORE begin-mode-3d.
# No window, shader, depth buffer, clock, or sky-cycle state is owned here.
(import ./rl :as rl)

(def tau (* 2 math/pi))
(defn- clamp [x lo hi] (max lo (min hi x)))
(defn- byte [x] (math/floor (clamp (+ 0.5 x) 0 255)))
(defn- rgba [rgb alpha]
  # Frame RGB values are normalized 0..1; raylib receives byte RGBA.
  [(byte (* 255 (rgb 0))) (byte (* 255 (rgb 1)))
   (byte (* 255 (rgb 2))) (byte (* 255 alpha))])
(defn- mix [a b t] (+ (* a (- 1 t)) (* b t)))
(defn- sky-field [frame primary alias] (get frame primary (get frame alias)))
(defn- star-direction [star] (if (dictionary? star) (get star :direction) star))
(defn- star-brightness [star]
  (if (dictionary? star) (get star :brightness 1) (get star 3 1)))
(defn- cloud-phase [offset lane]
  # sky-cycle emits two normalized phases; scalar radians remain supported.
  (if (number? offset) offset (* tau (get offset lane 0))))

(defn project
  "Perspective-project [x y z] to [screen-x screen-y] or nil outside view.
  Match player/look-direction: yaw zero faces +X, positive yaw toward +Z,
  positive pitch up; +Y is world up. Camera vertical FOV is 70 degrees;
  horizontal FOV derives from viewport aspect. Width/height are pixels."
  [direction yaw pitch width height]
  (when (and (pos? width) (pos? height))
    (let [x (direction 0) y (direction 1) z (direction 2)
          cy (math/cos yaw) sy (math/sin yaw)
          cp (math/cos pitch) sp (math/sin pitch)
          forward (+ (* cp cy x) (* sp y) (* cp sy z))
          right (+ (* (- sy) x) (* cy z))
          up (+ (* (- sp) cy x) (* cp y) (* (- sp) sy z))
          tan-half (math/tan (* 70 (/ math/pi 360)))
          aspect (/ width height)]
      (when (pos? forward)
        (let [nx (/ right (* forward tan-half aspect))
              ny (/ up (* forward tan-half))]
          (when (and (<= (math/abs nx) 1) (<= (math/abs ny) 1))
            [(* width (+ 0.5 (* 0.5 nx)))
             (* height (- 0.5 (* 0.5 ny)))]))))))

(defn- block [out x y w h color width height]
  (let [left (max 0 (math/floor x)) top (max 0 (math/floor y))
        right (min width (math/ceil (+ x w)))
        bottom (min height (math/ceil (+ y h)))]
    (when (and (< left right) (< top bottom))
      (array/push out [:rect left top (- right left) (- bottom top) color]))))

(defn- disc [out cx cy radius rgb alpha width height]
  # Stepped horizontal strips make discs readable at pixel-art resolutions.
  (let [step (max 2 (math/floor (/ radius 5)))]
    (for row (- radius) (+ radius 1) step
      (let [half (math/sqrt (max 0 (- (* radius radius) (* row row))))]
        (block out (- cx half) (+ cy row) (* 2 half) step
               (rgba rgb alpha) width height)))))

(defn commands
  "Return immutable-input draw commands [:rect x y width height rgba]. `frame`
  takes sky-cycle-compatible :sun-direction, :moon-direction, :stars,
  :zenith, :horizon, :star-intensity, :cloud-offset. Stars are world-space
  {:direction [x y z] :brightness b}; direction triples optionally carrying
  brightness as fourth element are also accepted. RGB and intensity are 0..1.
  Cloud offset is a pair of normalized phases [0..1, 0..1] for layered drift;
  a scalar radian offset is supported for standalone callers. Legacy aliases
  :sky-zenith, :sky-horizon, :night-strength are accepted. Draw after clear
  background, before begin-mode-3d/terrain; no shader or depth state is used."
  [frame yaw pitch width height]
  (def out @[])
  (when (and (pos? width) (pos? height))
    (let [zenith (sky-field frame :zenith :sky-zenith)
          horizon (sky-field frame :horizon :sky-horizon)
          night (clamp (sky-field frame :star-intensity :night-strength) 0 1)
          band (max 1 (math/ceil (/ height 48)))]
      # Invert the 70-degree perspective ray slope, then add camera pitch so
      # the physical horizon tracks the camera rather than a fixed screen row.
      # Saturate by +35 degrees (top of a level viewport); a square-root
      # falloff confines warm sunset color to a narrow band near the horizon.
      (for y 0 height band
        (let [alt (math/atan (* (- 1 (* 2 (/ (+ y (* band 0.5)) height)))
                                (math/tan (* 70 (/ math/pi 360)))))
              world-alt (+ alt pitch)
              t (math/sqrt (clamp (/ world-alt (* 35 (/ math/pi 180))) 0 1))
              rgb [(mix (horizon 0) (zenith 0) t)
                   (mix (horizon 1) (zenith 1) t)
                   (mix (horizon 2) (zenith 2) t)]]
          (block out 0 y width band (rgba rgb 1) width height)))
      # Deterministic star positions: no random generator or elapsed time.
      # Limit visible density and use only tiny square pixels, not long dashes.
      (when (pos? night)
        (var visible-stars 0)
        (each star (get frame :stars)
          (when (and (< visible-stars 96) (pos? ((star-direction star) 1)))
            (when-let [point (project (star-direction star) yaw pitch width height)]
              (let [brightness (clamp (star-brightness star) 0 1)
                    size (if (> brightness 0.88) 2 1)]
                (++ visible-stars)
                (block out (math/floor (point 0)) (math/floor (point 1))
                       size size (rgba [0.82 0.89 1] (* night brightness))
                       width height))))))
      # Jupiter-like planet at a fixed celestial direction with horizontal
      # ochre bands, dark equator, one storm pixel, and two small orbiting moons.
      (when (pos? night)
        (let [planet-dir [0.78 0.42 -0.86]
              p (project planet-dir yaw pitch width height)
              scale (/ (min width height) 800)
              r (max 8 (math/floor (* 22 scale)))]
          (when p
            (disc out (p 0) (p 1) r [0.76 0.58 0.37] night width height)
            (for row (- r) (+ r 1) (max 2 (math/floor (/ r 4)))
              (let [half (math/sqrt (max 0 (- (* r r) (* row row))))
                    shade (if (even? (math/floor (/ (+ row r) (max 2 (/ r 4)))))
                              [0.89 0.74 0.51] [0.59 0.37 0.29])]
                (block out (- (p 0) half) (+ (p 1) row)
                       (* 2 half) (max 2 (math/floor (/ r 5)))
                       (rgba shade night) width height)))
            (block out (+ (p 0) (* r 0.22)) (+ (p 1) (* r 0.27))
                   (max 2 (/ r 3)) (max 2 (/ r 6))
                   (rgba [0.77 0.34 0.26] night) width height)
            (disc out (- (p 0) (* 2.1 r)) (- (p 1) (* 0.6 r))
                  (max 2 (/ r 6)) [0.85 0.83 0.73] night width height)
            (disc out (+ (p 0) (* 2.5 r)) (+ (p 1) (* 0.35 r))
                  (max 2 (/ r 8)) [0.71 0.80 0.88] night width height))))
      (when (pos? ((get frame :moon-direction) 1))
        (when-let [moon (project (get frame :moon-direction) yaw pitch width height)]
          (let [r (max 5 (math/floor (* 14 (/ (min width height) 800))))]
            (disc out (moon 0) (moon 1) r [0.84 0.88 0.91] 1 width height)
            (block out (- (moon 0) (/ r 2)) (- (moon 1) (/ r 3))
                   (max 2 (/ r 3)) (max 2 (/ r 5))
                   (rgba [0.58 0.66 0.76] 0.8) width height))))
      (when (pos? ((get frame :sun-direction) 1))
        (when-let [sun (project (get frame :sun-direction) yaw pitch width height)]
          (let [r (max 8 (math/floor (* 20 (/ (min width height) 800))))]
            (disc out (sun 0) (sun 1) (* r 1.6) [1 0.73 0.33] 0.25 width height)
            (disc out (sun 0) (sun 1) r [1 0.94 0.64] 1 width height))))
      # Cloud patches are stable in angular world space; offset drifts them.
      # Light and shadow blocks overlap to give the banks layered silhouettes.
      (for i 0 13
        (let [offset (get frame :cloud-offset)
              angle (+ (* i 0.53) (cloud-phase offset (mod i 2)))
              elevation (+ 0.12 (* 0.12 (math/sin (* i 2.37))))
              direction [(math/sin angle) elevation (- (math/cos angle))]
              point (project direction yaw pitch width height)
              scale (/ (min width height) 800)]
          (when point
            (let [x (point 0) y (point 1)
                  w (* scale (+ 100 (* 19 (mod i 3))))
                  h (* scale (+ 12 (* 5 (mod i 4))))
                  shadow (rgba [(max 0.10 (* (horizon 0) 0.8))
                                 (max 0.13 (* (horizon 1) 0.8))
                                 (max 0.21 (* (horizon 2) 0.8))] 0.65)
                  light (rgba [(max (* (horizon 0) (mix 1.2 0.9 night)) (* 0.14 night))
                               (max (* (horizon 1) (mix 1.2 0.9 night)) (* 0.18 night))
                               (max (* (horizon 2) (mix 1.2 0.9 night)) (* 0.28 night))] 0.8)]
              (block out (- x (/ w 2)) y w h shadow width height)
              (block out (- x (* w 0.36)) (- y (* h 0.7))
                     (* w 0.56) (* h 0.85) light width height)
              (block out (- x (* w 0.05)) (- y (* h 1.2))
                     (* w 0.39) (* h 1.2) light width height)))))))
  out)

(defn draw
  "Draw sky in 2D after begin-drawing, before begin-mode-3d; caller owns window."
  [frame yaw pitch width height]
  (each command (commands frame yaw pitch width height)
    (rl/draw-rectangle (command 1) (command 2) (command 3)
                       (command 4) (command 5))))
