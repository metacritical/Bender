# Trinecraft — live module reload.
#
# Swap a rewritten source file into the running game WITHOUT restarting and
# without losing the world. This is what turns the socket REPL from "poke at
# state" into an actual development loop: edit, reload, keep playing.
#
# How it works, and why it is done this way:
#
# Janet caches modules, so editing a file and re-`import`ing it yields the same
# stale table. What does work is `dofile`: it always re-reads and re-evaluates a
# file, returning a fresh environment mapping symbol -> binding table. Binding
# tables are mutable, and the live environment holds the SAME table objects, so
# writing a new `:value` into an existing binding is visible to every call site
# immediately. That is the whole trick -- no process restart, no proxy objects.
#
# Scope is deliberately narrow: only `def`/`defn` bindings are adopted. A
# module's TOP-LEVEL side effects (creating a GL texture, opening a socket)
# do not re-run, because they are bound to a live session this code cannot
# reconstruct. That is a feature, not a limitation to paper over: reloading a
# shader string is safe, reloading a GPU texture is not, and guessing would
# corrupt the running game.
#
# Reload is atomic per module: the new source is evaluated in full first, and
# the live environment is only touched if it succeeded. A syntax error in the
# file therefore leaves the running game exactly as it was.

(def reloadable-modules
  "Modules whose behaviour is pure enough to swap at runtime."
  {:world "src/world.janet"
   :worldgen "src/worldgen.janet"
   :mesher "src/mesher.janet"
   :stream "src/stream.janet"
   :palette "src/palette.janet"
   :frustum "src/frustum.janet"
   :raycast "src/raycast.janet"
   :player "src/player.janet"
   :shaders "src/shaders.janet"
   :sky-cycle "src/sky-cycle.janet"
   :sky-render "src/sky-render.janet"
   :material-recipes "src/material-recipes.janet"
   :appearance-settings "src/appearance-settings.janet"
   :region "src/region.janet"
   :atlas "src/atlas.janet"
   :pickaxe "src/pickaxe.janet"
   :edit-pick "src/edit-pick.janet"
   :material-inspector "src/material-inspector.janet"
   :pickaxe "src/pickaxe.janet"})

(defn known? [name] (not (nil? (get reloadable-modules name))))

(defn module-path [name &opt root]
  "Project-relative path of module NAME, or nil when it is not reloadable."
  (def rel (get reloadable-modules name))
  (when rel
    (if root (string root "/" rel) rel)))

(defn- binding-name
  "The symbol a dofile environment entry is keyed by."
  [entry] entry)

(defn merge-into
  ``Adopt fresh definitions from `fresh` into `target`, in place.

  Both are dofile environments: tables of symbol -> @{:value ...}. Writing into
  an EXISTING binding table mutates the object call sites already hold, which
  is what makes the swap visible without re-importing anything.

  Non-binding entries (a dofile environment also carries `:source` and
  `:current-file` metadata) are ignored: adopting them would inject values no
  call site references.

  Returns {:added n :updated n :skipped [names]}.``
  [target fresh]
  (var added 0)
  (var updated 0)
  (def skipped @[])
  (eachp [sym binding] fresh
    (when (and (symbol? sym) (table? binding) (get binding :value))
      (def existing (get target sym))
      (cond
        (nil? existing)
        (do (put target sym @{:value (get binding :value)
                              :doc (get binding :doc)})
            (++ added))
        (table? existing)
        (do
          # Preserve the live binding table's identity: other modules may hold
          # a reference to it, and rebinding the slot would strand those.
          (put existing :value (get binding :value))
          (when (get binding :doc) (put existing :doc (get binding :doc)))
          (++ updated))
        # An immutable non-table slot cannot be updated in place. Replacing it
        # is the only option, and it costs identity the caller never had.
        :else
        (do (put target sym @{:value (get binding :value)
                              :doc (get binding :doc)})
            (++ updated)))))
  (table :added added :updated updated :skipped skipped))

(defn merge-qualified
  ``Update `name/sym` bindings in `target` from the same-named plain entries.

  `fresh` holds unqualified symbols; the environment additionally holds a
  qualified alias for each. Both must move together or a reload appears to do
  nothing at exactly the call sites the game uses.

  Returns {:updated n}.``
  [target fresh module]
  (var updated 0)
  (eachp [sym binding] fresh
    (when (and (symbol? sym) (table? binding) (get binding :value))
      (def qsym (symbol (string module "/" sym)))
      (def existing (get target qsym))
      (cond
        (table? existing)
        (do (put existing :value (get binding :value)) (++ updated))
        # A symbol introduced by this edit has no qualified slot yet. It must
        # be created, otherwise a brand-new definition is reachable only by its
        # plain name and every `module/name` call site still cannot see it.
        (nil? existing)
        (do (put target qsym (table :value (get binding :value)))
            (++ updated)))))
  {:updated updated})

(defn reload
  ``Reload module NAME from ROOT into the live console environment.

  Returns a report table. Raises if the module is unknown or the new source
  fails to compile -- in both cases the live game is untouched, because nothing
  is merged until evaluation has fully succeeded.``
  [con name &opt root]
  (def path (module-path name root))
  (unless path
    (error (string "not a reloadable module: " name
                   " (known: "
                   (string/join (sort (map string (keys reloadable-modules))) " ")
                   ")")))
  (def fresh
    (try (dofile path)
         ([err] (error (string "reload failed for " path ": " err)))))
  (def env (con :env))
  (unless env (error "console has no environment"))
  (def report (merge-into env fresh))
  # A module's definitions are reachable under BOTH the plain name and the
  # qualified `module/name` form, and those are SEPARATE binding tables in the
  # environment -- `worldgen/height-at` and `height-at` are different slots.
  # Updating only the plain name would leave every qualified call site, which
  # is how the game itself refers to modules, pointing at stale code.
  (def qualified (merge-qualified env fresh name))
  (put report :module name)
  (put report :path path)
  (put report :qualified (qualified :updated))
  report)
