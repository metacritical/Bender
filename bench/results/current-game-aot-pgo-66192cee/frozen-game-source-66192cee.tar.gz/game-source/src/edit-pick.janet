# Pure edit-mode cursor picking; coordinates are full-window screen pixels.
(import ./raycast)

(def inspector-width 340)

(defn screen-ray [eye yaw pitch fovy aspect width height mouse]
  ``Unit world ray through a screen position, with vertical FOV in degrees.``
  (assert (and (> width 0) (> height 0) (> aspect 0)
               (> fovy 0) (< fovy 180)) "edit-pick: invalid camera viewport")
  (let [cp (math/cos pitch) sp (math/sin pitch)
        cy (math/cos yaw) sy (math/sin yaw)
        # Forward matches player/look-direction. Right is forward cross world-up.
        fx (* cp cy) fy sp fz (* cp sy)
        rx (- sy) rz cy
        ux (- (* sp cy)) uy cp uz (- (* sp sy))
        slope (math/tan (* fovy (/ math/pi 360)))
        horizontal (* (- (* 2 (/ (get mouse 0) width)) 1) aspect slope)
        vertical (* (- 1 (* 2 (/ (get mouse 1) height))) slope)
        dx (+ fx (* horizontal rx) (* vertical ux))
        dy (+ fy (* vertical uy))
        dz (+ fz (* horizontal rz) (* vertical uz))
        length (math/sqrt (+ (* dx dx) (* dy dy) (* dz dz)))]
    [(/ dx length) (/ dy length) (/ dz length)]))

(defn pick-first-solid [w eye yaw pitch fovy aspect width height mouse max-distance]
  ``Ignore the right inspector (or off-window cursor), otherwise pick first solid.``
  (let [mx (get mouse 0) my (get mouse 1)
        panel-left (max 0 (- width inspector-width))]
    (when (and (> width 0) (> height 0)
               (>= mx 0) (< mx panel-left) (>= my 0) (< my height))
      (let [[dx dy dz] (screen-ray eye yaw pitch fovy aspect width height mouse)]
        (raycast/raycast-first-solid w (get eye 0) (get eye 1) (get eye 2)
                                     dx dy dz max-distance)))))
