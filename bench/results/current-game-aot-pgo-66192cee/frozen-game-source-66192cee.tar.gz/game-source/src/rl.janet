# Trinecraft — raylib 3D binding surface.
#
# This is the ONLY module permitted to touch ffi/struct or ffi/defbind-alias.
# Everything above it sees plain Janet values: tuples for vectors and colors,
# tables for meshes. Follows the pattern proven in ttfx/janet-port/src/gui.janet:
# all raylib calls go through bender's built-in FFI against libraylib directly,
# with no C shim written anywhere. Struct-by-value params marshal as tuples;
# the lazy context resolves symbols at first call, which keeps this module
# compilable as a single thunk (mkimage/AOT) and runnable interpreted.
#
# Verified against raylib 6.2.

(def raylib-candidates
  ["/opt/homebrew/lib/libraylib.dylib"
   "/usr/local/lib/libraylib.dylib"
   "/usr/lib/libraylib.so"
   "libraylib.dylib"])

(defn find-raylib []
  (def env (os/getenv "TRINECRAFT_RAYLIB"))
  (if (and env (not (empty? env)))
    env
    (do
      (var found nil)
      (each c raylib-candidates
        (when (and (nil? found) (= :file (os/stat c :mode)))
          (set found c)))
      (or found "libraylib.dylib"))))

(ffi/context (find-raylib) :lazy true)

#
# --- Struct types ------------------------------------------------------
#
# Layouts transcribed from raylib.h 6.2. ffi/struct computes padding, so
# fields are listed in declaration order and offsets are derived, never
# hardcoded.

(def vec2-type (ffi/struct :float :float))
(def vec3-type (ffi/struct :float :float :float))
(def vec4-type (ffi/struct :float :float :float :float))
(def color-type (ffi/struct :uchar :uchar :uchar :uchar))
(def rect-type (ffi/struct :float :float :float :float))

# Matrix: 16 floats, column-listed as m0,m4,m8,m12 / m1,... in the header,
# but memory order is simply 16 contiguous floats.
(def matrix-type (ffi/struct :float :float :float :float
                             :float :float :float :float
                             :float :float :float :float
                             :float :float :float :float))

# Texture2D { uint id; int width; int height; int mipmaps; int format; }
(def texture-type (ffi/struct :uint :int :int :int :int))
# Image { void *data; int width; int height; int mipmaps; int format; }
(def image-type (ffi/struct :ptr :int :int :int :int))
# Shader { uint id; int *locs; }
(def shader-type (ffi/struct :uint :ptr))
# MaterialMap { Texture2D texture; Color color; float value; }
(def material-map-type (ffi/struct texture-type color-type :float))
# Material { Shader shader; MaterialMap *maps; float params[4]; }
(def material-type (ffi/struct shader-type :ptr :float :float :float :float))
# Camera3D { Vector3 position, target, up; float fovy; int projection; }
(def camera3d-type (ffi/struct vec3-type vec3-type vec3-type :float :int))
# Ray { Vector3 position; Vector3 direction; }
(def ray-type (ffi/struct vec3-type vec3-type))
# BoundingBox { Vector3 min; Vector3 max; }
(def bbox-type (ffi/struct vec3-type vec3-type))

# Mesh, raylib 6.2 field order:
#   int vertexCount; int triangleCount;
#   float *vertices, *texcoords, *texcoords2, *normals, *tangents;
#   unsigned char *colors; unsigned short *indices;
#   int boneCount; unsigned char *boneIndices; float *boneWeights;
#   float *animVertices, *animNormals;
#   unsigned int vaoId; unsigned int *vboId;
(def mesh-type (ffi/struct :int :int
                           :ptr :ptr :ptr :ptr :ptr :ptr :ptr
                           :int :ptr :ptr :ptr :ptr
                           :uint :ptr))

# Field offsets are derived from the struct info, never assumed, so a raylib
# layout change surfaces as a wrong-looking offset rather than memory corruption.
(def mesh-offsets
  (map |($ :offset) ((ffi/struct-info mesh-type) :fields)))

(def mesh-field
  "Symbolic index into mesh-offsets, by raylib field name."
  {:vertex-count 0 :triangle-count 1
   :vertices 2 :texcoords 3 :texcoords2 4 :normals 5 :tangents 6
   :colors 7 :indices 8
   :bone-count 9 :bone-indices 10 :bone-weights 11
   :anim-vertices 12 :anim-normals 13
   :vao-id 14 :vbo-id 15})

(defn mesh-offset
  "Byte offset of a Mesh field, by keyword."
  [field]
  (get mesh-offsets (get mesh-field field)))

#
# --- Window, frame, timing --------------------------------------------
#

(ffi/defbind-alias InitWindow init-window :void [w :int h :int title :string])
(ffi/defbind-alias CloseWindow close-window :void [])
(ffi/defbind-alias WindowShouldClose window-should-close :bool [])
(ffi/defbind-alias IsWindowReady window-ready? :bool [])
(ffi/defbind-alias SetConfigFlags set-config-flags :void [flags :int])
(ffi/defbind-alias SetTargetFPS set-target-fps :void [fps :int])
(ffi/defbind-alias GetFPS get-fps :int [])
(ffi/defbind-alias GetFrameTime get-frame-time :float [])
(ffi/defbind-alias GetTime get-time :double [])
(ffi/defbind-alias GetScreenWidth screen-width :int [])
(ffi/defbind-alias GetScreenHeight screen-height :int [])
(ffi/defbind-alias SetWindowTitle set-window-title :void [t :string])
(ffi/defbind-alias TakeScreenshot take-screenshot :void [name :string])

(ffi/defbind-alias BeginDrawing begin-drawing :void [])
(ffi/defbind-alias EndDrawing end-drawing :void [])
(ffi/defbind-alias ClearBackground clear-background :void [c color-type])
(ffi/defbind-alias BeginMode3D begin-mode-3d :void [cam camera3d-type])
(ffi/defbind-alias EndMode3D end-mode-3d :void [])

#
# --- Input -------------------------------------------------------------
#

(ffi/defbind-alias IsKeyPressed key-pressed? :bool [key :int])
(ffi/defbind-alias IsKeyDown key-down? :bool [key :int])
(ffi/defbind-alias IsKeyReleased key-released? :bool [key :int])
# Text entry. Both drain an internal queue and return 0 when it is empty, so
# each must be called in a loop every frame or keystrokes are lost.
# GetCharPressed yields unicode codepoints and is keyboard-layout aware, so it
# is what text input should use; GetKeyPressed yields raw keycodes, which is
# what editing keys such as Backspace and the arrows need.
(ffi/defbind-alias GetCharPressed char-pressed :int [])
(ffi/defbind-alias GetKeyPressed key-pressed :int [])
# Without this raylib closes the window on ESC, so a console could never use
# ESC to dismiss itself. Pass 0 to disable the exit key entirely.
(ffi/defbind-alias SetExitKey set-exit-key :void [key :int])
(ffi/defbind-alias SetTraceLogLevel set-trace-log-level :void [level :int])
(ffi/defbind-alias IsMouseButtonPressed mouse-pressed? :bool [b :int])
(ffi/defbind-alias IsMouseButtonDown mouse-down? :bool [b :int])
(ffi/defbind-alias GetMousePosition mouse-position vec2-type [])
(ffi/defbind-alias GetMouseDelta mouse-delta vec2-type [])
(ffi/defbind-alias GetMouseWheelMove mouse-wheel :float [])
(ffi/defbind-alias DisableCursor disable-cursor :void [])
(ffi/defbind-alias EnableCursor enable-cursor :void [])
(ffi/defbind-alias IsCursorHidden cursor-hidden? :bool [])

#
# --- Textures and images ----------------------------------------------
#

(ffi/defbind-alias LoadImage load-image image-type [path :string])
(ffi/defbind-alias GenImageColor gen-image-color image-type
  [w :int h :int c color-type])
(ffi/defbind-alias ImageDrawRectangle image-draw-rectangle :void
  [img :ptr x :int y :int w :int h :int c color-type])
(ffi/defbind-alias UnloadImage unload-image :void [img image-type])
(ffi/defbind-alias LoadTextureFromImage load-texture-from-image texture-type
  [img image-type])
(ffi/defbind-alias LoadTexture load-texture texture-type [path :string])
(ffi/defbind-alias UnloadTexture unload-texture :void [t texture-type])
(ffi/defbind-alias SetTextureFilter set-texture-filter :void
  [t texture-type filter :int])
(ffi/defbind-alias SetTextureWrap set-texture-wrap :void
  [t texture-type wrap :int])
(ffi/defbind-alias GenTextureMipmaps gen-texture-mipmaps :void [t :ptr])
# CPU-side downscale for the loading screen: a 2752x1536 source is 16 MB in
# VRAM at full size, and a background is never shown larger than the screen.
# Takes Image* for the same reason ImageDrawRectangle above does.
(ffi/defbind-alias ImageResize image-resize :void [img :ptr w :int h :int])

# The only way to draw a texture. DrawTexturePro carries both halves of what a
# cover-cropped, crossfading background needs in one call: the source rectangle
# selects the crop, and the tint alpha carries the fade. Rectangles and Vector2
# marshal by value as tuples, exactly like Camera3D and Matrix above.
(ffi/defbind-alias DrawTexturePro draw-texture-pro :void
  [t texture-type src rect-type dst rect-type origin vec2-type
   rotation :float tint color-type])
# Vertical gradient without a shader: the fallback background and the scrim
# under the progress bar, both of which must work with no assets at all.
(ffi/defbind-alias DrawRectangleGradientV draw-rectangle-gradient-v :void
  [x :int y :int w :int h :int top color-type bottom color-type])
# Horizontal variant: the left-hand scrim that keeps the title legible over a
# photograph whose bright mass sits on the right.
(ffi/defbind-alias DrawRectangleGradientH draw-rectangle-gradient-h :void
  [x :int y :int w :int h :int left color-type right color-type])

#
# --- Materials and shaders --------------------------------------------
#

(ffi/defbind-alias LoadMaterialDefault load-material-default material-type [])
(ffi/defbind-alias LoadShader load-shader shader-type [vs :string fs :string])
# From source strings rather than files: keeps GLSL in the repo next to the
# code that sets its uniforms, instead of in loose files that can drift.
(ffi/defbind-alias LoadShaderFromMemory load-shader-from-memory shader-type
  [vs :string fs :string])
(ffi/defbind-alias IsShaderValid shader-valid? :bool [s shader-type])
(ffi/defbind-alias GetShaderLocationAttrib shader-attrib-location :int
  [s shader-type name :string])
(ffi/defbind-alias SetShaderValueMatrix set-shader-value-matrix :void
  [s shader-type loc :int m matrix-type])
(ffi/defbind-alias BeginShaderMode begin-shader-mode :void [s shader-type])
(ffi/defbind-alias BeginBlendMode begin-blend-mode :void [mode :int])
(ffi/defbind-alias EndBlendMode end-blend-mode :void [])
# rlgl lives in the same dylib. Translucent geometry must not write depth, or
# one water quad occludes the one behind it and the surface tears into
# visible blocks instead of reading as a single body.
(ffi/defbind-alias rlDisableDepthMask disable-depth-mask :void [])
(ffi/defbind-alias rlEnableDepthMask enable-depth-mask :void [])
(ffi/defbind-alias rlDisableBackfaceCulling disable-backface-culling :void [])
(ffi/defbind-alias rlEnableBackfaceCulling enable-backface-culling :void [])
(ffi/defbind-alias EndShaderMode end-shader-mode :void [])
(ffi/defbind-alias UnloadShader unload-shader :void [s shader-type])
(ffi/defbind-alias GetShaderLocation shader-location :int
  [s shader-type name :string])
(ffi/defbind-alias SetShaderValue set-shader-value :void
  [s shader-type loc :int value :ptr type :int])

#
# --- Mesh upload and draw ---------------------------------------------
#

(ffi/defbind-alias UploadMesh upload-mesh-raw :void [m :ptr dynamic :bool])
(ffi/defbind-alias UpdateMeshBuffer update-mesh-buffer :void
  [m mesh-type index :int data :ptr size :int offset :int])
(ffi/defbind-alias UnloadMesh unload-mesh-raw :void [m mesh-type])
(ffi/defbind-alias DrawMesh draw-mesh :void
  [m mesh-type mat material-type xform matrix-type])
(ffi/defbind-alias DrawMeshInstanced draw-mesh-instanced :void
  [m mesh-type mat material-type transforms :ptr count :int])

#
# --- Debug / immediate draw -------------------------------------------
#

(ffi/defbind-alias DrawGrid draw-grid :void [slices :int spacing :float])
(ffi/defbind-alias DrawCubeWires draw-cube-wires :void
  [pos vec3-type w :float h :float l :float c color-type])
(ffi/defbind-alias DrawLine3D draw-line-3d :void
  [a vec3-type b vec3-type c color-type])
(ffi/defbind-alias DrawFPS draw-fps :void [x :int y :int])
(ffi/defbind-alias DrawText draw-text :void
  [t :string x :int y :int size :int c color-type])
(ffi/defbind-alias DrawRectangle draw-rectangle :void
  [x :int y :int w :int h :int c color-type])
(ffi/defbind-alias DrawRectangleLines draw-rectangle-lines :void
  [x :int y :int w :int h :int c color-type])
(ffi/defbind-alias MeasureText measure-text :int [t :string size :int])

#
# --- Constants ---------------------------------------------------------
#

(def key-escape 256) (def key-space 32) (def key-left-shift 340)
(def key-w 87) (def key-a 65) (def key-s 83) (def key-d 68)
(def key-q 81) (def key-e 69) (def key-f 70) (def key-tab 258)
(def key-one 49) (def key-two 50) (def key-three 51) (def key-four 52)

# Console / text editing keys.
(def key-grave 96)        # the ` / ~ key that toggles the console
(def key-enter 257)
(def key-kp-enter 335)
(def key-backspace 259)
(def key-delete 261)
(def key-right 262)
(def key-left 263)
(def key-down 264)
(def key-up 265)
(def key-page-up 266)
(def key-page-down 267)
(def key-home 268)
(def key-end 269)
# GLFW's function-key block starts at 290. F2 is the menu's random-seed toggle;
# the codes live here so every keycode in the engine has one home.
(def key-f1 290)
(def key-f2 291)
(def key-f3 292)
# Bracket keys, used by the menu to adjust a focused setting.
(def key-left-bracket 91) (def key-right-bracket 93)

(def mouse-button-left 0)
(def mouse-button-right 1)

(def flag-vsync-hint 64)
(def flag-fullscreen-mode 2)
(def flag-window-resizable 4)
(def flag-msaa-4x-hint 32)

(def camera-perspective 0)
(def camera-orthographic 1)

(def texture-filter-point 0)      # nearest-neighbour: mandatory for block atlases
(def texture-filter-bilinear 1)
(def texture-wrap-clamp 1)

(def material-map-albedo 0)

# SetShaderValue uniform types (raylib ShaderUniformDataType).
(def shader-uniform-float 0)
(def shader-uniform-vec2 1)
(def shader-uniform-vec3 2)
(def shader-uniform-vec4 3)
(def shader-uniform-int 4)
(def shader-uniform-sampler2d 8)

# Vertex attribute locations bound by raylib's default shader. The mesher's
# per-vertex colour rides in VERTEX_COLOR, so no custom attribute is needed
# to carry an ambient-occlusion or shade term into GLSL.
(def shader-loc-vertex-position 0)
(def shader-loc-vertex-texcoord01 1)
(def shader-loc-vertex-normal 3)
(def shader-loc-vertex-color 5)

(def blend-alpha 0)
(def blend-additive 1)

(def white [0xff 0xff 0xff 0xff])
(def black [0x00 0x00 0x00 0xff])
(def sky-blue [0x8f 0xc8 0xf0 0xff])
(def red [0xe0 0x30 0x30 0xff])
(def yellow [0xf0 0xd0 0x20 0xff])

(def identity-matrix [1 0 0 0  0 1 0 0  0 0 1 0  0 0 0 1])

(defn translation-matrix
  ``Translation matrix in raylib's memory order.

  raylib declares Matrix as `float m0, m4, m8, m12;` for the FIRST ROW, so the
  16 floats sit in memory as m0,m4,m8,m12, m1,m5,m9,m13, m2,m6,m10,m14,
  m3,m7,m11,m15. The translation components m12/m13/m14 are therefore at
  memory indices 3, 7 and 11 -- NOT 12, 13, 14, which are m3/m7/m11, the
  projective row. Writing the offset there instead produces wildly distorted
  geometry rather than a moved mesh.

  Identity is unaffected because m0/m5/m10/m15 land on indices 0/5/10/15
  either way, so this bug stays invisible until the first non-zero offset.``
  [x y z]
  [1 0 0 x
   0 1 0 y
   0 0 1 z
   0 0 0 1])

#
# --- Mesh helpers ------------------------------------------------------
#
# A Trinecraft mesh is a Janet table holding the packed raylib Mesh struct
# alongside references to the Janet buffers backing it. Holding those
# references matters: raylib keeps raw pointers into them, so if the buffers
# were collected the GPU-side pointers would dangle on any later update.

# Every vboId array raylib has handed us and we have NOT yet freed.
#
# raylib allocates Mesh.vboId itself and UnloadMesh frees it, so freeing one
# twice aborts the process. Guarding per wrapper table is not enough and
# guarding per struct buffer is not enough either: the only thing that
# uniquely identifies the resource is the pointer. Keying on it makes a
# double free impossible however the wrappers are aliased or copied.
#
# Entries are cleared on upload as well as on unload, because malloc reuses
# addresses -- a later mesh can legitimately receive an address we freed
# earlier, and without that clearing we would skip its unload and leak.
(def- live-vbos @{})

(defn- vbo-key [mesh]
  (def p (ffi/read :ptr (mesh :struct) (mesh-offset :vbo-id)))
  (if p (string p) nil))

# Read at CALL time, not module level. In an AOT build the module is executed
# when the image is built, so a top-level os/getenv bakes the build-time value
# into the binary and the runtime environment is ignored entirely.
(defn- mesh-trace? [] (= "1" (os/getenv "TRINEX_MESH_TRACE")))
(var- mesh-seq 0)

(defn- trace-mesh [kind mesh extra]
  (when (mesh-trace?)
    (++ mesh-seq)
    (eprintf "MESH %s seq=%d vao=%d vbo=%p %s" kind mesh-seq
             (ffi/read :uint (mesh :struct) (mesh-offset :vao-id))
             (ffi/read :ptr (mesh :struct) (mesh-offset :vbo-id))
             extra)))

(defn mesh-pack
  ``Pack a raylib Mesh struct into a fresh buffer pointing at caller-owned
  vertex data. `verts` and `norms` are float32 buffers (3 per vertex), `uvs`
  float32 (2 per vertex), `idxs` uint16. Returns a mesh table; the GPU knows
  nothing about it until mesh-upload is called.``
  [vcount tcount verts uvs norms idxs &opt colors]
  (def buf (buffer/new-filled (ffi/size mesh-type) 0))
  (ffi/write :int vcount buf (mesh-offset :vertex-count))
  (ffi/write :int tcount buf (mesh-offset :triangle-count))
  (ffi/write :ptr verts buf (mesh-offset :vertices))
  (ffi/write :ptr uvs buf (mesh-offset :texcoords))
  (ffi/write :ptr norms buf (mesh-offset :normals))
  (ffi/write :ptr idxs buf (mesh-offset :indices))
  # Per-vertex colour reaches GLSL as `vertexColor` at VERTEX_COLOR. The
  # mesher has always produced this channel -- baked directional shading, and
  # ambient occlusion later -- but it was never uploaded, so the work was
  # discarded every frame.
  (when colors (ffi/write :ptr colors buf (mesh-offset :colors)))
  @{:struct buf
    :vertex-count vcount
    :triangle-count tcount
    # keep the backing buffers alive for as long as the mesh is
    :verts verts :uvs uvs :norms norms :idxs idxs :colors colors
    :uploaded false
    :value nil})

(defn mesh-upload
  ``Hand the packed mesh to the GPU. raylib fills vaoId/vboId in place.
  Returns the mesh, with :value holding the by-value struct that DrawMesh
  takes and :vao-id the id the driver assigned (non-zero on success).``
  [mesh &opt dynamic]
  (default dynamic false)
  (upload-mesh-raw (mesh :struct) dynamic)
  (when-let [k (vbo-key mesh)] (put live-vbos k true))
  (trace-mesh "UP" mesh "")
  (put mesh :vao-id (ffi/read :uint (mesh :struct) (mesh-offset :vao-id)))
  (put mesh :value (ffi/read mesh-type (mesh :struct)))
  (put mesh :uploaded true)
  mesh)

(defn mesh-uploaded?
  ``True when the GPU still holds this mesh.

  The authority is the vaoId inside the SHARED struct buffer, not a flag on
  this table. Two wrappers can reference one struct, and a per-table flag
  lets the second one free GPU resources the first already released.``
  [mesh]
  (and (mesh :struct)
       (pos? (ffi/read :uint (mesh :struct) (mesh-offset :vao-id)))))

(defn mesh-draw
  "Draw an uploaded mesh with a material at a world offset."
  [mesh material &opt xform]
  (when (mesh-uploaded? mesh)
    (draw-mesh (mesh :value) material (or xform identity-matrix))))

(def- null-pointer "\0\0\0\0\0\0\0\0")

(def- mesh-data-pointers
  [:vertices :texcoords :texcoords2 :normals :tangents :colors :indices
   :bone-indices :bone-weights :anim-vertices :anim-normals])

(def mesh-unload-enabled
  ``Whether to hand meshes back to raylib's UnloadMesh.

  OFF by default, and that is a known, deliberate leak.

  raylib's UnloadMesh frees Mesh.vboId, which raylib itself allocated. Under
  chunk streaming the engine aborts inside that free with "pointer being
  freed was not allocated" -- reproducibly in the native build, and in an
  isolation test when two wrappers alias one struct. Guarding per table, per
  struct buffer, and finally per vboId pointer each fixed the isolated
  reproduction but not the live game, so the true aliasing path is not yet
  understood and the guard cannot be trusted.

  Leaking GPU buffers is strictly better than aborting a play session: a
  chunk mesh is tens of kilobytes and a long session unloads tens of chunks.
  Turn this on only while hunting the bug.``
  @{:value nil})

(defn set-mesh-unload [on]
  (put mesh-unload-enabled :value (truthy? on))
  (mesh-unload-enabled :value))

(defn mesh-unload
  ``Release a mesh's GPU buffers, when enabled. Always clears the handles in
  the shared struct so no wrapper can later believe the mesh is still live.``
  [mesh]
  (when (mesh-uploaded? mesh)
    (def tracked (let [k (vbo-key mesh)] (or (nil? k) (get live-vbos k))))
    (trace-mesh "DN" mesh (string "tracked=" tracked))
    (when-let [k (vbo-key mesh)] (put live-vbos k nil))
    (def enabled
      (if (nil? (mesh-unload-enabled :value))
        (= "1" (os/getenv "TRINEX_MESH_UNLOAD"))
        (mesh-unload-enabled :value)))
    (when (and enabled tracked)
      (def scratch (buffer/slice (mesh :struct)))
      (each field mesh-data-pointers
        (buffer/blit scratch null-pointer (mesh-offset field)))
      (unload-mesh-raw (ffi/read mesh-type scratch)))
    # Clear the handles regardless, so a stale wrapper can never resubmit
    # them and the mesh reads as unloaded everywhere.
    (ffi/write :uint 0 (mesh :struct) (mesh-offset :vao-id))
    (buffer/blit (mesh :struct) null-pointer (mesh-offset :vbo-id))
    (put mesh :uploaded false)
    (put mesh :vao-id 0)
    (put mesh :value nil))
  mesh)

(defn material-set-shader
  ``Point a material at a custom shader.

  Material's first field is its Shader, so the shader is written at offset 0
  of the material's packed struct. Material is passed by value into DrawMesh,
  so the caller must use the RETURNED material -- mutating a copy would be
  silently discarded.``
  [material shader]
  (def buf (buffer/new-filled (ffi/size material-type) 0))
  (ffi/write material-type material buf 0)
  (ffi/write shader-type shader buf 0)
  (ffi/read material-type buf))

(defn set-uniform-float
  "Set a scalar float uniform by name. Returns false when the name is absent."
  [shader name value]
  (def loc (shader-location shader name))
  (if (neg? loc)
    false
    (do
      (def buf (buffer/new-filled 4 0))
      (ffi/write :float (* 1.0 value) buf 0)
      (set-shader-value shader loc buf shader-uniform-float)
      true)))

(defn set-uniform-vec3
  "Set a vec3 uniform by name. Returns false when the name is absent."
  [shader name x y z]
  (def loc (shader-location shader name))
  (if (neg? loc)
    false
    (do
      (def buf (buffer/new-filled 12 0))
      (ffi/write :float (* 1.0 x) buf 0)
      (ffi/write :float (* 1.0 y) buf 4)
      (ffi/write :float (* 1.0 z) buf 8)
      (set-shader-value shader loc buf shader-uniform-vec3)
      true)))

(defn material-set-texture
  ``Point a material's albedo map at a texture. Material.maps is a pointer to
  a raylib-allocated array of MaterialMap; the albedo map is index 0 and its
  Texture2D sits at offset 0 within it, so the texture is written straight
  into maps[0].

  This writes through a raw pointer into memory raylib owns, so it uses
  unsafe/poke rather than ffi/write -- ffi/write only targets Janet buffers,
  and the maps array is not one.``
  [material texture]
  (def maps-ptr (get material 1))
  (unless maps-ptr
    (error "material has no maps array; was it created before InitWindow?"))
  (unsafe/poke texture-type maps-ptr texture 0)
  material)

(defn camera3d
  "Build a Camera3D tuple: position, target, up, fov in degrees."
  [pos target up fovy]
  [pos target up (* 1.0 fovy) camera-perspective])
