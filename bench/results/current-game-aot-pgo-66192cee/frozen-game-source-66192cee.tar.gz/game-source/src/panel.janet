# Trinecraft — the studio panel registry.
#
# Controls live HERE, in the game, not in Emacs. That direction matters:
#
#   * a control belongs to the thing it controls, so it is added next to the
#     code it drives rather than in a second language in another process;
#   * adding one is a single Janet line, and `g` in the panel shows it -- no
#     Elisp to write and no Emacs restart;
#   * the panel cannot disagree with the game about what exists, because the
#     game is the only list.
#
# Emacs renders whatever this registry publishes. It has no hardcoded controls.
#
# Wire format. The REPL protocol is one line per reply, so a multi-control
# manifest has to survive on one line. Each control becomes a record of
# `id|kind|group|label|form|hint`, records separated by `;`, and every field is
# escaped first (backslash, `|`, `;`, newline) so no delimiter can appear inside
# a value. That is deliberately boring: a delimiter that cannot occur is easier
# to trust than a parser.

(def field-sep "|")
(def record-sep ";")

(defn escape-field
  "Escape one field so no delimiter can appear inside it."
  [s]
  (def out @"")
  (each b (string (or s ""))
    (cond
      (= b 92) (buffer/push-string out "\\\\")   # backslash first
      (= b 124) (buffer/push-string out "\\p")   # |
      (= b 59) (buffer/push-string out "\\s")    # ;
      (= b 10) (buffer/push-string out "\\n")
      (= b 13) (buffer/push-string out "\\r")
      (buffer/push-byte out b)))
  (string out))

(defn encode-record
  ``Encode one control as a `|`-delimited record.

  Ten fields, in this order:
    id, kind, group, label, form, hint, min, max, step, read-form

  The numeric triple is what lets the panel build a real editor for a
  `:number` control instead of only a button: a value with no bounds and no
  increment can only be typed in full, which is exactly the interaction a
  panel exists to avoid. `read-form` says how to display the CURRENT value so
  the panel can show the number it is about to change.``
  [control]
  (def num (fn [k] (when (get control k) (string (get control k)))))
  (string/join
   (map escape-field
        [(get control :id)
         (get control :kind)
         (get control :group)
         (get control :label)
         (get control :form)
         (get control :hint)
         (num :min)
         (num :max)
         (num :step)
         (get control :read-form)])
   field-sep))

#
# --- Registry -----------------------------------------------------------
#

(defn registry-new
  "A fresh, empty control registry."
  []
  @{:controls @[]    # ordered: the panel shows them in declaration order
    :index @{}       # id -> control, for replacement
    :order @[]})     # group order, first seen wins

(defn- remember-group [registry group]
  (unless (find |(= $ group) (registry :order))
    (array/push (registry :order) group))
  registry)

(defn define!
  ``Register or replace a control.

  Kind is one of:
    :action   a button; evaluating :form performs the action
    :readout  :form returns a display string, re-read on every refresh
    :number   :form is a template containing `%%s`; the panel prompts, then
              substitutes the typed number and evaluates
    :text     like :number, but substitutes a quoted string

  `:group` orders and headings controls in the panel. Re-defining an id
  REPLACES it in place, keeping its position, so a module can re-register its
  own controls on reload without the panel reshuffling.``
  [registry id opts]
  (def control @{:id id
                 :kind (or (get opts :kind) :action)
                 :group (or (get opts :group) "general")
                 :label (or (get opts :label) (string id))
                 :form (or (get opts :form) "")
                 :hint (or (get opts :hint) "")
                 :min (get opts :min)
                 :max (get opts :max)
                 :step (get opts :step)
                 :read-form (get opts :read-form)})
  (remember-group registry (control :group))
  (def existing (get (registry :index) id))
  (if existing
    (do
      # Replace in place so a module re-registering its controls on reload does
      # not make the panel reshuffle under the cursor.
      (var pos nil)
      (var i 0)
      (each c (registry :controls)
        (when (and (nil? pos) (= (c :id) id)) (set pos i))
        (++ i))
      (when pos (put (registry :controls) pos control))
      (put (registry :index) id control))
    (do
      (array/push (registry :controls) control)
      (put (registry :index) id control)))
  control)

(defn remove! [registry id]
  (def existing (get (registry :index) id))
  (when existing
    (def kept @[])
    (each c (registry :controls)
      (unless (= (c :id) id) (array/push kept c)))
    (set (registry :controls) kept)
    (put (registry :index) id nil))
  registry)

(defn controls [registry] (registry :controls))
(defn count-of [registry] (length (registry :controls)))

#
# --- Manifest -----------------------------------------------------------
#

(defn manifest
  ``The whole registry as one protocol line.

  Groups are emitted in first-declaration order and controls within a group in
  declaration order, so the panel is stable between refreshes -- a panel that
  reorders itself while you are clicking is worse than one that is wrong.``
  [registry]
  (def parts @[])
  (each group (registry :order)
    (each c (registry :controls)
      (when (= (c :group) group)
        (array/push parts (encode-record c)))))
  (string/join parts record-sep))

(defn readouts
  ``Evaluate every display form and return `id=value` records on one line.

  A `:readout` control displays from `:form`; a `:number` control displays
  from `:read-form` when one is given, because its `:form` is a template for
  SETTING the value rather than reading it.

  Batched deliberately: a panel with ten readouts refreshed every two seconds
  would otherwise cost ten round trips, and each round trip needs a frame to be
  serviced. One form means one trip.

  A readout that throws reports its error in place rather than breaking the
  whole panel -- a readout is diagnostic, so it must not be able to take the
  panel down.``
  [registry evaluate]
  (def parts @[])
  (each c (registry :controls)
    (def display-form
      (cond
        (= (c :kind) :readout) (c :form)
        (= (c :kind) :number) (c :read-form)
        nil))
    (when display-form
      (def value
        (try (string (evaluate display-form))
             ([err] (string "error: " err))))
      (array/push parts (string (escape-field (c :id)) "=" (escape-field value)))))
  (string/join parts record-sep))
