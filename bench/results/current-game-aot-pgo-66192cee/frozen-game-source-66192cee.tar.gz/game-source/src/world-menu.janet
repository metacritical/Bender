# Trinecraft -- front door: the startup menu, as pure state.
#
# No raylib, no GL, no filesystem, no world. This module decides WHAT the menu
# shows and WHAT a click means; a later integration pass draws it and feeds it
# key events. Keeping the decision pure is what makes the honesty rules testable:
# an unavailable provider must be refused, not drawn greyed-out and then accepted.
#
# Three rules shape everything below.
#
#   * THE MENU NEVER INVENTS A WORLD. It builds a REQUEST describing what the
#     player asked for -- name, raw seed text, provider, settings -- and hands it
#     out. Creating a world is the caller's job, so this module cannot start a
#     bake, touch a cache, or claim a provider it does not have.
#
#   * A PROVIDER IS ONLY AS AVAILABLE AS ITS METADATA SAYS. The provider list is
#     INJECTED, each entry carrying `:available` and, when unavailable, `:reason`.
#     A learned provider whose backend is missing must show that reason and must
#     block creation -- a greyed button that still works is a lie with a UI.
#
#   * CONTROLS COME FROM THE PROVIDER. `:controls` is metadata the provider
#     declares: id, kind, bounds. The menu validates against that schema and
#     rejects anything it does not describe, so a setting cannot be smuggled in
#     and a provider cannot be given a knob its author never defined.
#
# Seeds are carried as RAW TEXT, never parsed here. "Random" is an explicit mode,
# not an empty string, because "" and "give me any seed" are different requests
# and a UI that conflates them cannot say which one it sent.

#
# --- State --------------------------------------------------------------
#

(def screens [:home :new :load :error])

(defn- provider-settings-version
  ``The settings version a provider row offers, resolved and VALIDATED.

  The ROW carries it, because the view already resolved which contract it is
  advertising. Two guards make this safe at the state edge:

    * a row that declares nothing is a caller predating versioning, and 1 is the
      contract every such world was made under -- never assume the newest;
    * a row that declares an UNKNOWN version is not trusted either. Only 1 and 2
      exist, and a row advertising a version this build cannot validate would
      produce a form that submits something the provider refuses. Such a row
      falls back to 1 rather than forwarding the value.``
  [providers pid]
  (def found (filter |(= pid ($ :id)) (or providers @[])))
  (if (pos? (length found))
    (do
      (def declared ((get found 0) :settings-version))
      (if (and (number? declared) (or (= 1 declared) (= 2 declared)))
        declared
        1))
    1))

(defn state-new
  ``Fresh menu state.

  `providers` is the injected provider list:
  `[{:id :label :available :reason :controls}]`. `worlds` is the injected
  catalog: `[{:id :name :provider :seed :modified}]`, already bounded and sorted
  by the caller -- this module never reads a directory, so it cannot be tricked
  into listing outside one.

  Everything mutable lives in one table so a transition returns a NEW state
  rather than reaching into a shared one; the UI keeps exactly one value and the
  tests can hold two without them interfering.``
  [providers worlds &opt options]
  (def opts (or options {}))
  (def first-provider (first (map |($ :id) providers)))
  @{:screen (get opts :screen :home)
    :providers (or providers @[])
    :worlds (or worlds @[])
    :selected-world (get opts :selected-world nil)
    :page 0
    :page-size (get opts :page-size 8)
    :name ""
    :seed-input ""
    :seed-random false
    :provider first-provider
    :settings @{}
    # Which settings contract the form submits under. Derived from the chosen
    # provider row's own `:settings-version`, never assumed: a provider that only
    # offers v1 must produce a v1 request even when the menu as a whole was built
    # for v2.
    :settings-version (provider-settings-version providers first-provider)
    :error nil
    :message nil})

(defn provider-of
  "The provider record for `id`, or nil."
  [state id]
  (def found (filter |(= id ($ :id)) (state :providers)))
  (when (pos? (length found)) (get found 0)))

(defn provider-available?
  "Is the named provider able to produce a world right now?"
  [state id]
  (def p (provider-of state id))
  (truthy? (and p (p :available))))

(defn provider-reason
  "Why `id` cannot produce a world, or nil when it can."
  [state id]
  (def p (provider-of state id))
  (when p (p :reason)))

#
# --- Controls -----------------------------------------------------------
#
# A control is provider-declared metadata:
#
#   {:id <keyword> :label <string> :kind :int|:number|:choice
#    :min <n> :max <n> :default <n> :choices [..]}
#
# The menu validates a value against THAT record and nothing else. An unknown id
# is refused even if the caller passes a plausible number, because accepting it
# would mean the UI knows a feature its provider never declared.

(defn control-of
  "The control record `id` for provider `pid`, or nil."
  [state pid id]
  (def p (provider-of state pid))
  (when p
    (def found (filter |(= id ($ :id)) (p :controls)))
    (when (pos? (length found)) (get found 0))))

(defn valid-control-value?
  ``Does `value` satisfy the control's own declared type and bounds?

  `:choice` must be one of the declared `:choices`; `:int` must be an integer
  inside [min,max]; `:number` a finite number inside the same. A control with no
  declared bounds accepts any value of its type -- the provider said so.``
  [control value]
  (when control
    (case (control :kind)
      :choice (truthy? (some (fn [c] (= c value)) (control :choices)))
      :int (and (number? value) (= value (math/floor value))
                (>= value (or (control :min) value))
                (<= value (or (control :max) value)))
      :number (and (number? value) (not (nan? value))
                   (>= value (or (control :min) value))
                   (<= value (or (control :max) value)))
      false)))

(defn default-settings
  "Every declared control's default, for provider `pid`."
  [state pid]
  (def p (provider-of state pid))
  (def out @{})
  (when p
    (each c (p :controls)
      (when (has-key? c :default) (put out (c :id) (c :default)))))
  out)

#
# --- Transitions --------------------------------------------------------
#
# A transition is `(fn [state action] -> new-state)`. Actions are plain data:
#
#   [:new]                     :home -> :new (provider controls default)
#   [:load]                    :home -> :load
#   [:back]                    :any  -> :home
#   [:edit-name <text>]        :new  -> :new
#   [:edit-seed <text>]        :new  -> :new (implies a literal seed)
#   [:random-seed <bool>]      :new  -> :new
#   [:change-provider <id>]    :new  -> :new (settings reset to that provider)
#   [:update-setting <id> <v>] :new  -> :new (validated, or :error)
#   [:select-world <id>]       :load -> :load
#   [:page <n>]                :load -> :load (clamped)
#
# `:create` and `:open` are NOT state changes: they produce a request. A
# transition that returned a new state for "make a world" would have to perform
# the creation, which is exactly what this module must not do.

(defn- copy-of
  "A shallow copy with `settings` copied too, so edits cannot leak."
  [state]
  (def next (table/clone state))
  (put next :settings (table/clone (state :settings)))
  next)

(defn- fail [state reason]
  (def next (copy-of state))
  (put next :screen :error)
  (put next :error reason)
  next)

(defn- clamp-page [state]
  (def n (length (state :worlds)))
  (def size (max 1 (state :page-size)))
  (def pages (max 1 (math/ceil (/ n size))))
  (put state :page (max 0 (min (dec pages) (state :page)))))

(defn step
  ``Apply one action; returns the next state. Never mutates its argument.

  An unrecognised action is ignored rather than raising: a menu that crashes on
  an unknown key is worse than one that does nothing, and the caller's key map
  will drift from this list first.``
  [state action]
  (def kind (get action 0))
  (def arg (get action 1))
  (def next (copy-of state))
  (case kind
    :new
    (do
      (when (or (nil? (next :provider))
                (not (provider-available? state (next :provider))))
        # Pick the first AVAILABLE provider rather than the first. Opening a form
        # whose provider cannot run sets the player up to fail at the last click.
        # When NOTHING is available the selection becomes nil rather than keeping
        # the unavailable one: a form whose provider is unset can say "no provider
        # can generate"; one whose provider is set but unusable looks like a choice
        # the player made.
        (def usable (filter |(truthy? ($ :available)) (state :providers)))
        (put next :provider (if (pos? (length usable))
                              ((get usable 0) :id)
                              nil)))
      (put next :settings-version
           (provider-settings-version (next :providers) (next :provider)))
      (put next :settings (default-settings next (next :provider)))
      (put next :screen :new)
      (put next :error nil)
      next)

    :load
    (do (put next :screen :load)
        (put next :error nil)
        (clamp-page next))

    :back
    (do (put next :screen :home)
        (put next :error nil)
        (put next :message nil)
        next)

    :edit-name (do (put next :name (or arg "")) next)
    :edit-seed (do (put next :seed-input (or arg ""))
                   (put next :seed-random false)
                   next)
    :random-seed (do (put next :seed-random (truthy? arg)) next)

    :change-provider
    (if (provider-of state arg)
      (do (put next :provider arg)
          # The version follows the PROVIDER, not the menu. Switching to a
          # provider that offers only v1 must drop the v2 contract, or the form
          # would submit a settings-version the new provider cannot validate.
          (put next :settings-version
               (provider-settings-version (next :providers) arg))
          (put next :settings (default-settings next arg))
          next)
      (fail next (string "no such provider: " (string arg))))

    :update-setting
    (let [id (get action 1)
          value (get action 2)
          control (control-of state (state :provider) id)]
      (cond
        (nil? control)
        (fail next (string "provider " (string (state :provider))
                           " has no control " (string id)))
        (not (valid-control-value? control value))
        (fail next (string (string id) " rejects " (string value)
                           (if (has-key? control :min)
                             (string " (expected " (control :kind) " "
                                     (control :min) ".." (control :max) ")")
                             (string " (expected " (control :kind) ")"))))
        true (do (put (next :settings) id value) next)))

    :select-world
    (if (some (fn [w] (= (w :id) arg)) (state :worlds))
      (do (put next :selected-world arg) next)
      # A world id the catalog does not contain must not become selected: the UI
      # cannot invent an id, and a stale one is not a world.
      (fail next (string "no such world: " (string arg))))

    :page
    (do (put next :page (or arg 0)) (clamp-page next) next)

    next))

#
# --- Requests -----------------------------------------------------------
#

(defn create-request
  ``The generation request for the current form, or `[:refuse reason]`.

  Returned as `{:kind :create :name ... :seed-input ... :seed-random ...
  :provider ... :settings ...}`. The seed is RAW TEXT: parsing belongs to whoever
  owns the world's seed, and a menu that parsed it would be the second definition
  of it.

  Refused when the provider is unavailable (with ITS reason), when no provider is
  selected, or when the settings no longer satisfy the declared controls -- the
  last case can only happen if a provider changed underneath the form, and
  silently sending invalid settings would push the failure into worldgen.``
  [state]
  (def pid (state :provider))
  (cond
    (nil? pid) [:refuse "choose a generation provider"]
    (not (provider-available? state pid))
    [:refuse (or (provider-reason state pid)
                 (string "provider " (string pid) " is not available"))]
    true
    (let [bad (first (filter
                       (fn [c]
                         (def id (c :id))
                         (not (valid-control-value? c (get (state :settings) id))))
                       (let [p (provider-of state pid)] (if p (p :controls) @[]))))]
      (if bad
        [:refuse (string "setting " (string (bad :id)) " is invalid")]
        @{:kind :create
          :name (state :name)
          :seed-input (state :seed-input)
          :seed-random (state :seed-random)
          :provider pid
          # The version the form was built under, taken from the state rather
          # than re-derived, so the request describes the contract the controls
          # on screen were rendered for. The catalogue validates the settings
          # against exactly this version.
          :settings-version (or (state :settings-version) 1)
          :settings (table/clone (state :settings))}))))

(defn open-request
  "The request to load `selected-world`, or `[:refuse reason]`."
  [state]
  (def id (state :selected-world))
  (if (nil? id)
    [:refuse "select a world to load"]
    (if (some (fn [w] (= (w :id) id)) (state :worlds))
      @{:kind :open :world id}
      [:refuse (string "no such world: " (string id))])))

(defn request?
  "Is `v` a request rather than a refusal?"
  [v]
  (and (table? v) (has-key? v :kind)))

#
# --- Layout -------------------------------------------------------------
#

(defn page-count [state]
  (max 1 (math/ceil (/ (length (state :worlds)) (max 1 (state :page-size))))))

(defn visible-worlds
  ``The catalog page to draw: entries plus their index, not a slice of ids.

  Bounded by `page-size`, which the caller sets, so a thousand worlds cannot turn
  one screen into a thousand rows.``
  [state]
  (def size (max 1 (state :page-size)))
  (def start (* size (state :page)))
  (def all (state :worlds))
  (def out @[])
  (for i start (min (length all) (+ start size))
    (when-let [w (get all i)]
      (array/push out w)))
  out)

(defn provider-rows
  ``Providers to draw, each with the reason it is unusable.

  A row carries `:available` and `:reason` so the view must render the reason --
  the information cannot be dropped by a view that forgot to look it up.``
  [state]
  (map (fn [p]
         @{:id (p :id)
           :label (p :label)
           :available (truthy? (p :available))
           :reason (p :reason)})
       (state :providers)))

(defn control-rows
  ``Controls to draw for the selected provider, each with its current value.

  `:value` is the live setting, so the view never has to join two tables to know
  what to show.``
  [state]
  (def p (provider-of state (state :provider)))
  (if p
    (map (fn [c]
           @{:id (c :id)
             :label (c :label)
             :kind (c :kind)
             :min (c :min)
             :max (c :max)
             :choices (c :choices)
             :value (get (state :settings) (c :id))})
         (p :controls))
    @[]))

(defn layout
  ``A description of what the current screen contains, for a painter to consume.

  Deliberately data, not drawing: the same value can be rendered by raylib, by a
  text console, or asserted in a test, and none of those three gets to decide what
  the menu MEANS. `:focus` is the provider row the user would act on.``
  [state]
  (def screen (state :screen))
  @{:screen screen
    :title (case screen
             :home "Trinecraft"
             :new "New world"
             :load "Load world"
             :error "Cannot continue")
    :error (state :error)
    :message (state :message)
    :rows (case screen
            :home @[@{:action [:new] :label "New game"
                      :enabled (pos? (length (filter |(truthy? ($ :available))
                                                     (state :providers))))}
                    @{:action [:load] :label "Load game"
                      :enabled (pos? (length (state :worlds)))}]
            :new (map (fn [c]
                        @{:kind :control
                          :id (c :id) :label (c :label)
                          :value (c :value) :min (c :min) :max (c :max)
                          :choices (c :choices)})
                      (control-rows state))
            :load (map (fn [w]
                         @{:kind :world
                           :id (w :id) :label (w :name)
                           :selected (= (w :id) (state :selected-world))})
                       (visible-worlds state))
            :error @[@{:action [:back] :label "Back" :enabled true}])
    :providers (if (= screen :new) (provider-rows state) @[])
    :selected-provider (state :provider)
    :page (state :page)
    :pages (page-count state)
    :name (state :name)
    :seed-input (state :seed-input)
    :seed-random (state :seed-random)})
