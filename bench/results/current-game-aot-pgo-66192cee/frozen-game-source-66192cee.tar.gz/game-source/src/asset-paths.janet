# Asset-directory resolution. Pure: no imports beyond the filesystem fact it is
# asked to check, and no cwd assumption for a native binary.
#
# THE PROBLEM. Assets are looked up under `<root>/assets`, and `<root>` used to be
# derived from the SCript path. That is correct when running from the checkout and
# wrong for a shipped binary: a native executable launched from anywhere resolves
# `<its own directory>/assets`, not `<whatever the shell thought the cwd was>`.
#
# THE RULE, in priority order:
#
#   1. :explicit     -- an explicitly configured asset directory wins.
#   2. :environment  -- an environment-configured directory comes next.
#   3. :executable   -- next to the executable: <exe-dir>/assets, then
#                       <exe-dir>/../assets. This is what makes a shipped binary
#                       work: `build/trinecraft-worlds` resolves `./assets` from
#                       the project, which is where the assets actually live.
#   4. :cwd          -- `<cwd>/assets`, the legacy behaviour, last.
#   5. :none         -- nothing found; the caller falls back to a title and menu.
#
# A BAD EXPLICIT OR ENVIRONMENT VALUE RETURNS :none. It does NOT fall through to
# cwd: a caller that pointed the game at a directory is telling us where the assets
# are, and silently loading a different set because the path was mistyped is how a
# broken install looks like a working one with the wrong art.
#
# A RELATIVE executable is IGNORED for candidate 3. A relative path is resolved
# against the cwd, which is exactly the dependency this module exists to remove --
# so a relative exe is treated as "no executable information", not as a hint.
#
# Platform note: separators are "/" throughout, matching the rest of this codebase
# (Linux and macOS). Windows drive letters and backslashes are NOT handled here;
# that would need its own path policy rather than a silent guess.

(def max-path-bytes 4096)

(defn- path-ok?
  "Is this a plausible path string? Length-bounded and free of NUL."
  [value]
  (and (string? value) (<= 1 (length value) max-path-bytes)
       (nil? (string/find "\x00" value))))

(defn- dirname
  "Directory part of `path`, without resolving anything."
  [path]
  (var slash nil)
  (for i 0 (length path)
    (when (= 47 (get path i)) (set slash i)))
  (if (nil? slash)
    "."
    (if (= 0 slash) "/" (string/slice path 0 slash))))

(defn- join [root name] (string root "/" name))

(defn- parent-dir
  "The parent of `dir`, or nil at the root."
  [dir]
  (def up (dirname dir))
  (if (= up dir) nil up))

(defn- default-dir? [path]
  (def info (os/lstat path))
  (truthy? (and info (= :directory (get info :mode)))))

(defn- usable-dir?
  ``Is this path a directory we may serve assets from?

  No canonicalisation policy is attempted: the mode is asked at the given path and
  that is the answer. Existing asset folders are ordinary directories in the tree,
  so plain directory checks are enough.``
  [dir? path]
  (and (path-ok? path) (dir? path)))

(defn- exe-candidates
  ``Asset directories implied by an ABSOLUTE executable path.

  `<exe-dir>/assets` first, because a distribution may ship its assets beside the
  binary; then `<exe-dir>/../assets`, which is the checkout shape where the binary
  lives in `build/` and the assets sit one level up.``
  [executable]
  (def dir (dirname executable))
  (def out @[(join dir "assets")])
  (when-let [up (parent-dir dir)]
    (array/push out (join up "assets")))
  out)

(defn resolve
  ``Find the asset directory. Returns `{:root <dir> :source <keyword>}`.

  `opts` keys, all optional:
    :explicit   an asset directory chosen by configuration
    :env-root   an asset directory chosen by the environment
    :executable the running executable's path, for native installs
    :cwd        the working directory, used only for the legacy fallback
    :dir?       a predicate deciding whether a path is a directory, so tests can
                inject a filesystem instead of creating one

  `:source` says WHY that directory was chosen, so a log line can report it and a
  missing-assets bug is diagnosable from the outside.``
  [&opt opts]
  (def o (or opts {}))
  (def dir? (or (get o :dir?) default-dir?))
  (def explicit (get o :explicit))
  (def env-root (get o :env-root))
  (def executable (get o :executable))
  (def cwd (or (get o :cwd) "."))
  (cond
    # 1. Explicit. A bad value is a refusal, not a hint.
    (not (nil? explicit))
    (if (usable-dir? dir? explicit)
      {:root explicit :source :explicit}
      {:root nil :source :none})

    # 2. Environment. Same rule.
    (not (nil? env-root))
    (if (usable-dir? dir? env-root)
      {:root env-root :source :environment}
      {:root nil :source :none})

    # A source launch belongs to the game script, not the Bender executable.
    (and (path-ok? (get o :script))
         (usable-dir? dir? (join (dirname (get o :script)) "assets")))
    {:root (join (dirname (get o :script)) "assets") :source :script}

    # 3. Beside an ABSOLUTE executable. A relative path would be resolved against
    # the cwd, which is the dependency this exists to remove.
    (and (path-ok? executable) (= 47 (get executable 0)))
    (let [found (first (filter |(usable-dir? dir? $) (exe-candidates executable)))]
      (if found
        {:root found :source :executable}
        (let [candidate (join cwd "assets")]
          (if (usable-dir? dir? candidate)
            {:root candidate :source :cwd}
            {:root nil :source :none}))))

    # 4. Legacy cwd fallback.
    true
    (let [candidate (join cwd "assets")]
      (if (usable-dir? dir? candidate)
        {:root candidate :source :cwd}
        {:root nil :source :none}))))
