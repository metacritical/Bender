# Phase 10 benchmark: the two kernels that bound the engine.
#
# The engine is production-bound, not render-bound -- drawing a chunk costs
# ~0.010 ms while making one costs milliseconds -- so these two numbers decide
# how much of the enchanted look is affordable.
#
# Run BOTH ways, and always with JANET_NO_PROFILE=1: bender collects PGO
# diagnostics on ordinary script runs by default, which inflates interpreted
# timings by 50%+ and would flatter the native build.
#
#   interpreted:  JANET_NO_PROFILE=1 bender bench/kernels.janet
#   native:       bender --aot bench/kernels.janet --native -o build/bench
#                 JANET_NO_PROFILE=1 ./build/bench

(import ../src/world :as world)
(import ../src/worldgen :as worldgen)
(import ../src/mesher :as mesher)
(import ../src/atlas :as atlas)
(import ../src/palette :as palette)
(import ../src/raycast :as raycast)

(def seed 4)

(defn stats [label xs unit]
  (def o (sorted xs))
  (def n (length o))
  (defn p [q] (get o (min (- n 1) (math/floor (* n (/ q 100))))))
  (printf "%-22s p50 %7.3f  p90 %7.3f  max %7.3f  %s" label (p 50) (p 90) (last o) unit)
  (p 50))

(def results @{})

#
# --- Worldgen -----------------------------------------------------------
#
(def w (world/world-new))
(def blocks (buffer/new-filled world/chunk-volume 0))
(for i 0 3 (worldgen/generate-into blocks 0 0 seed))   # warm
(def gen @[])
(for i 0 120
  (def t (os/clock))
  (worldgen/generate-into blocks (% i 16) (math/floor (/ i 16)) seed)
  (array/push gen (* 1000 (- (os/clock) t))))
(put results :worldgen (stats "worldgen/chunk" gen "ms"))

#
# --- Mesher -------------------------------------------------------------
#
(for cz 0 3 (for cx 0 3 (worldgen/generate-chunk w cx cz seed)))
(def ch (world/world-get-chunk w 1 1))
(def m (mesher/mesher-new))
(for i 0 5 (mesher/mesh-chunk m ch w atlas/face-uv))
(def mesh @[])
(for i 0 120
  (def t (os/clock))
  (mesher/mesh-chunk m ch w atlas/face-uv)
  (array/push mesh (* 1000 (- (os/clock) t))))
(put results :mesher (stats "mesh-chunk" mesh "ms"))

#
# --- Raycast ------------------------------------------------------------
#
(def rc @[])
(for i 0 40
  (def t (os/clock))
  (for j 0 2000
    (raycast/raycast-first-solid w 8 50 8 0.3 -1 0.2 64))
  (array/push rc (/ (* 1000000 (- (os/clock) t)) 2000)))
(put results :raycast (stats "raycast" rc "us"))

#
# --- Palette packing ----------------------------------------------------
#
(def pk @[])
(for i 0 60
  (def t (os/clock))
  (palette/pack (ch :blocks))
  (array/push pk (* 1000 (- (os/clock) t))))
(put results :palette (stats "palette pack" pk "ms"))

#
# --- Streaming implication ----------------------------------------------
#
# What the player actually feels: how long a radius-12 world takes to stream
# in, at one chunk's worldgen + mesh per unit of work.
(def per-chunk (+ (results :worldgen) (results :mesher)))
(printf "\nper chunk: %.2f ms (worldgen + mesh)" per-chunk)
(printf "radius 12 (441 chunks): %.1f s to stream in" (/ (* 441 per-chunk) 1000))
(printf "chunks per 16.6 ms frame: %.2f" (/ 16.6 per-chunk))
