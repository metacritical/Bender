# Isolated, headless comparison of synchronous and worker terrain generation.
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender bench/async-worldgen.janet
# os/clock is a wall clock in bender (it advances over os/sleep).
(import ../src/world :as world)
(import ../src/worldgen :as worldgen)
(import ../src/async-worldgen :as worker)

(def seed 4)
(def sizes [32 64 120])
(def warmups 2)
(def rounds 5)
(def capacity 32)

(defn coordinates [n]
  (def coords @[])
  (for i 0 n
    (array/push coords [(- (* (% i 11) 7) 35)
                        (+ (* (math/floor (/ i 11)) 9) (% (* i 3) 7) -21)]))
  coords)

(defn checksum [blocks]
  (var sum 0)
  (for i 0 world/chunk-volume
    (set sum (% (+ (* sum 33) (get blocks i) i) 2147483647)))
  sum)

(defn verify [actual expected coord]
  (assert (= (length actual) world/chunk-volume) "wrong chunk volume")
  (assert (= (checksum actual) (checksum expected)) (string "checksum mismatch " coord))
  (for i 0 world/chunk-volume
    (assert (= (get actual i) (get expected i))
            (string "block mismatch " coord " index " i))))

(defn quantile [samples p]
  (def ordered (sorted samples))
  (get ordered (min (- (length ordered) 1)
                    (math/floor (* (length ordered) (/ p 100))))))

(defn describe [name samples]
  (printf "%-20s p50 %.3f p90 %.3f p99 %.3f max %.3f ms"
          name (quantile samples 50) (quantile samples 90)
          (quantile samples 99) (last (sorted samples))))

(defn reference [coords]
  (def expected @[])
  (each coord coords
    (def blocks (buffer/new-filled world/chunk-volume 0))
    (worldgen/generate-into blocks (get coord 0) (get coord 1) seed)
    (array/push expected blocks))
  expected)

(defn synchronous [coords expected latencies]
  (def started (os/clock))
  (for i 0 (length coords)
    (def coord (get coords i))
    (def blocks (buffer/new-filled world/chunk-volume 0))
    (def stamp (os/clock))
    (worldgen/generate-into blocks (get coord 0) (get coord 1) seed)
    (array/push latencies (* 1000 (- (os/clock) stamp)))
    (verify blocks (get expected i) coord))
  (* 1000 (- (os/clock) started)))

(defn asynchronous [coords expected latencies]
  (def scheduler (worker/new {:concurrency 2 :capacity capacity}))
  (def started (os/clock))
  (def outcome
    (try
      (do
        # Submit no more than capacity before each blocking drain.
        (for batch 0 (math/ceil (/ (length coords) capacity))
          (def first (* batch capacity))
          (def submitted @{})
          (for i first (min (+ first capacity) (length coords))
            (def coord (get coords i))
            (def stamp (os/clock))
            (def ticket (worker/submit scheduler (get coord 0) (get coord 1) seed))
            (put submitted ticket [i stamp]))
          (def results (worker/drain scheduler))
          (assert (= (length results) (length submitted)) "missing worker results")
          (each result results
            (def entry (get submitted (result :sequence)))
            (assert entry "unexpected worker result")
            (def i (get entry 0))
            (def payload (result :result))
            (assert (not (payload :error)) (string "worker failed: " (payload :error)))
            (array/push latencies (* 1000 (- (os/clock) (get entry 1))))
            (verify (payload :blocks) (get expected i) (get coords i))))
        (* 1000 (- (os/clock) started)))
      ([err] err)))
  # Always join/close even when a result or correctness assertion fails.
  (worker/teardown scheduler)
  (if (= (type outcome) :number) outcome (error outcome)))

(defn benchmark [n]
  (def coords (coordinates n))
  (def expected (reference coords))
  (def sync-batches @[])
  (def async-batches @[])
  (def sync-latencies @[])
  (def async-latencies @[])
  (for i 0 warmups
    (synchronous coords expected @[])
    (asynchronous coords expected @[]))
  (for i 0 rounds
    (array/push sync-batches (synchronous coords expected sync-latencies))
    (array/push async-batches (asynchronous coords expected async-latencies)))
  # Repeat both paths, not only the synchronous reference.
  (def repeated (reference coords))
  (for i 0 n (verify (get repeated i) (get expected i) (get coords i)))
  (asynchronous coords repeated @[])
  (printf "\n%d chunks; seed %d; %d measured rounds" n seed rounds)
  (describe "sync batch" sync-batches)
  (describe "async batch" async-batches)
  (describe "sync chunk" sync-latencies)
  (describe "async submit->result" async-latencies)
  (printf "sync %.2f chunks/s; async %.2f chunks/s"
          (/ (* 1000 n) (quantile sync-batches 50))
          (/ (* 1000 n) (quantile async-batches 50))))

(each n sizes (benchmark n))
