# Async worldgen headless benchmark (Phase 11b)

From the repository root, run:

```sh
JANET_NO_PROFILE=1 ../../janet/build/bender bench/async-worldgen.janet
```

This compares synchronous terrain generation with the committed persistent-proc-lane worker at HEAD `a740be7` (worker implementation `d13978a`, safety fix `38ea46e`). Fixed seed 4; 32, 64, and 120 chunks; two warmups and five measured rounds per workload; concurrency 2 and queue capacity 32. The benchmark verifies each complete 16,384-byte chunk against synchronous output (including a checksum), repeats reference generation, creates and tears down schedulers, and runs headlessly without a GUI/window, native build, or AOT. Timing uses `os/clock` wall time with profiling disabled.

One run at `a740be7` (milliseconds; p90/p99 are order statistics from only five batch rounds):

| Chunks | Sync batch p50 / p90 / max | Lanes batch p50 / p90 / max | Sync / lanes chunks/s | Batch p50 speedup |
| ---: | ---: | ---: | ---: | ---: |
| 32 | 241.294 / 243.755 / 243.755 | 149.570 / 157.683 / 157.683 | 132.62 / 213.95 | 1.61× |
| 64 | 519.884 / 635.007 / 635.007 | 306.173 / 416.003 / 416.003 | 123.10 / 209.03 | 1.70× |
| 120 | 909.817 / 919.802 / 919.802 | 579.984 / 594.355 / 594.355 | 131.89 / 206.90 | 1.57× |

| Chunks | Sync chunk p50 / p90 / p99 / max | Lanes submit-to-result p50 / p90 / p99 / max |
| ---: | ---: | ---: |
| 32 | 5.388 / 5.514 / 12.137 / 12.153 | 119.261 / 143.448 / 153.541 / 155.469 |
| 64 | 5.532 / 7.796 / 16.029 / 17.570 | 130.359 / 187.939 / 232.166 / 238.385 |
| 120 | 5.385 / 5.764 / 11.756 / 14.688 | 115.105 / 146.758 / 157.760 / 160.616 |

**Go/no-go:** GO for an isolated CPU-throughput prototype. NO for gameplay integration yet: proc lanes are process-global and their ownership/teardown across game mount lifecycles is not proven, nor is frame latency under gameplay load. The benchmark does not establish either requirement.

After the tagged dispatch-error fix `691fb3c`, a second full-block-verified five-round run measured 120-chunk sync p50 985.885 ms versus lanes p50 609.280 ms (121.72 versus 196.95 chunks/s, 1.62×); lanes p90 was 637.571 ms. The 120-chunk batch tail in the earlier run is 594.355 ms; another observed run at `38ea46e` reported roughly 678 ms. Treat both as run-dependent wall-clock observations, not a guaranteed latency bound. Likewise, the ~114–115 ms submit-to-result median in 120-chunk runs includes queueing and each capacity-sized blocking `drain`, not per-chunk compute time or game latency. Batch times include submission, worker scheduling, waiting, result collection, and full-block verification; synchronous times include the same correctness verification. The global proc lanes belong to the worker runtime and must be shut down by its teardown path; this benchmark exercises that ownership but does not integrate worker generation into gameplay. Five rounds on one host are illustrative rather than statistically robust, and no frame-time responsiveness, GUI behavior, native/AOT performance, or cross-machine speedup is claimed. Earlier measurements at `dc6feff` used `thread/new`, not persistent lanes, and are not directly attributable to this worker.
