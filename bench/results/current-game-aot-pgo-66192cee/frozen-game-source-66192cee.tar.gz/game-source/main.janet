# Trinecraft -- a voxel engine on bender + raylib.
#
# Run:  ./build/bender examples/trinecraft/main.janet
#       ./build/bender examples/trinecraft/main.janet --screenshot out.png
#
# Controls: WASD move, mouse look, Space jump (or ascend when flying),
#           Shift sprint, Q descend when flying, F toggle fly/walk,
#           left click break, right click place, 1-4 select block, Esc quit.
#
# Wires the pieces together: worldgen fills chunks with block ids, the mesher
# turns each chunk into one GPU mesh, and the frame loop issues a single
# DrawMesh per visible chunk. The engine never draws a block -- FFI call
# overhead forbids it -- so a chunk of thousands of blocks costs one call.

(import ./src/rl :as rl)
(import ./src/world :as world)
(import ./src/worldgen :as worldgen)
(import ./src/mesher :as mesher)
(import ./src/atlas :as atlas)
(import ./src/player :as player)
(import ./src/raycast :as raycast)
(import ./src/console :as console)
(import ./src/stream :as stream)
(import ./src/frustum :as frustum)
(import ./src/region :as region)
(import ./src/shaders :as shaders)
(import ./src/appearance-settings :as appearance-settings)
(import ./src/pickaxe :as pickaxe)
(import ./src/material-recipes :as recipes)
(import ./src/material-inspector :as inspector)
(import ./src/edit-pick :as edit-pick)
(import ./src/sky-cycle :as sky-cycle)
(import ./src/sky-render :as sky-render)
(import ./src/dev-server :as dev-server)
(import ./src/reload :as reload)
(import ./src/panel :as panel)
(import ./src/terrain-cache :as tcache)
(import ./src/terrain-identity :as terrain-identity)
(import ./src/terrain-integrity :as terrain-integrity)
(import ./src/loading-screen :as loading-screen)
(import ./src/asset-paths :as asset-paths)
(import ./src/spawn :as spawn)
(import ./src/scenic-worldgen :as scenic)
(import ./src/scenic-climate :as scenic-climate)
(import ./src/world-menu :as menu)
(import ./src/world-menu-view :as menu-view)
(import ./src/world-catalog :as catalog)
(import ./src/world-seed :as world-seed)
(import ./src/world-provider :as provider)
(import ./src/generation-job :as generation-job)

(def spawn-radius 2)         # generated synchronously so the player has ground
(def default-stream-radius 6)
(def unload-margin 2)        # hysteresis: see src/stream.janet
(def default-budget-ms 6)    # per-frame ceiling on worldgen + meshing
(var seed 4)                 # verification may choose a different fixed seed
# What the front door chose. Declared here rather than inside `main` because the
# catalogue save (which runs long after the menu) needs them, and a `def` inside a
# deeply nested branch is not reachable from there.
(var menu-seed-record nil)
(var menu-seed-kind nil)     # :numeric | :text | :random, as the seed module named it
(var world-name "")          # the display name the player typed
(var active-slot nil)        # catalogue id, once this world has been saved
# The generation settings this session runs with. Canonical and complete, or nil
# for a CLI launch that never involved the menu -- in which case generation takes
# the shipped path unchanged, byte for byte.
(var world-settings nil)
# Which provider this session generates with. :procedural is the default so a CLI
# launch keeps its exact behaviour; the menu sets it from the player's choice.
(var new-provider :procedural)
(var python-runtime-probe nil)
(def generation-slot @{:job nil})
# nil in an interactive run: the child decides when it is done. A number only for
# scripted QA, where an unbounded wait would hang the capture. Set from
# `--generation-frames`, which is how a cancel test bounds a fake provider that
# never finishes.
(var generation-frame-budget nil)
# The world seed the player chose, kept when a generated artifact records a
# different MODEL seed. nil means the two were the same.
(var world-seed-authoritative nil)
# The validated artifact metadata for a generated map, or nil. Carries :identity,
# :digest, :model-seed and the bounds; reused for the catalogue save so main does
# not recompute a digests the catalogue already produced.
(var generated-artifact nil)
# True when this session's map came from the Python provider. Such a session runs
# NO terrain worker: the artifact is complete and one producer already answered.
(var generated-cache? false)
(def reach 6.0)              # how far the player can break/place
# Worker invocation is resolved from the repository root, not the cwd, so a
# launch from anywhere (the editor launcher does exactly that) still finds the
# backend.
(def default-terrain-python "tmp/terrain-runtime/venv/bin/python")
(def terrain-worker-script "tools/terrain_backend.py")
(def look-speed 0.0032)      # radians per pixel of mouse movement

(def placeable
  [world/block-stone world/block-dirt world/block-wood world/block-leaves])

#
# --- Arguments ----------------------------------------------------------
#

(defn arg-value [flag]
  ``The value after `flag`, or nil.

  A following token that starts with "--" is another OPTION, not a value. Without
  that rule `--scenic-view --scenic-preload` reads "--scenic-preload" as the view
  name, which then silently misplaces the camera and prints a misleading summary
  -- exactly what happened on the first full-map capture. A real negative number
  is unaffected: `--camera-pitch -0.35` is a single "-" and a digit, never a
  doubled dash.``
  (var found nil)
  (def args (dyn :args))
  (for i 0 (length args)
    (when (and (= (get args i) flag) (< (+ i 1) (length args)))
      (def next (get args (+ i 1)))
      (unless (and (string? next) (> (length next) 1)
                   (= "--" (string/slice next 0 2)))
        (set found next))))
  found)

(defn arg-flag? [flag]
  (var found false)
  (each a (dyn :args) (when (= a flag) (set found true)))
  found)

(defn arg-number [flag fallback]
  (def v (arg-value flag))
  (if v (scan-number v) fallback))

(def screenshot-path (arg-value "--screenshot"))
# Reproducible visual QA viewpoints; only used with --screenshot. Keep
# ordinary gameplay and benchmark runs on the same spawn/camera path.
(def water-qa-view (arg-value "--water-view"))
# Deterministic visual QA: --sky-phase 0.25/0.5/0.75 holds noon/sunset/night.
(def sky-qa-phase (arg-number "--sky-phase" nil))
(def sky-qa-view (arg-value "--sky-view"))
# Explicit scenic viewpoint. `--camera-x/y/z` is the EYE position (the pixel the
# render is taken from, which is what a screenshot means); yaw and pitch are
# radians, matching `player/look-direction`: 0=+X, pi/2=+Z, pi=-X, -pi/2=-Z.
#
# Two named presets exist because the interesting camera on a scenic map is a
# property of THAT map, and typing five floats from memory is how a capture ends
# up aimed at a slope. The presets name positions measured against the shipped
# watershed; explicit `--camera-*` still overrides any field they leave open.
# `--scenic-view` takes an OPTIONAL preset name. Bare `--scenic-view` means "use
# the explicit --camera-* flags I passed"; `--scenic-view valley` means "start
# from that preset". A flag with no value would otherwise make the whole camera
# block inert, silently ignoring an operator's explicit coordinates.
(def scenic-view (if (arg-value "--scenic-view")
                     (arg-value "--scenic-view")
                     (if (arg-flag? "--scenic-view") "explicit" nil)))
# `--hide-hud` and `--clean-view` are one request under two names, because one
# reads as "photograph the world" and the other as "remove the interface". A
# named scenic viewpoint implies it too: the point of naming a viewpoint is to
# photograph the map, not the debug overlay on top of it. `--hud` asks for the
# interface back, which is what a diagnostic run needs.
(def clean-view
  (if (arg-flag? "--hud")
    false
    (truthy? (or (arg-flag? "--clean-view") (arg-flag? "--hide-hud")))))
# Is this an INTERACTIVE scenic launch -- a person at the controls rather than a
# capture? That is `--scenic-view` without `--screenshot`. The distinction decides
# two things: an interactive run keeps the HUD and the held tool (they are how you
# play), and it must still be placed at the viewpoint, because "launch me on the
# map" is the whole request. A screenshot run is the opposite on both counts.
(def scenic-interactive
  (truthy? (or (and scenic-view (nil? screenshot-path))
               (= "grounded" scenic-view))))

(defn camera-view-applies?
  ``Should the CLI camera be applied in this run?

  True for a capture, and true for an interactive scenic launch. It used to be
  `--screenshot` only, which meant `--scenic-view valley` did nothing at all when
  launched without one: the preset was parsed, then never used, and the player
  spawned at the map centre instead of the valley.``
  [screenshot? view interactive?]
  (truthy? (and view (or screenshot? interactive?))))
# Two viewpoints, chosen for different jobs.
#
# `valley` is the interactive start: standing on the map's own ground looking west
# down the valley, so a player launches INTO the scene rather than at a detached
# overview. It carries NO :y on purpose -- the ground decides the feet and the
# preset must not be able to demand a height the terrain does not have, which is
# exactly how an earlier version left the player hovering at y175 over a floor at
# y68. A capture that wants an explicit eye still passes --camera-y.
#
# `aerial` is the overview: back far enough that summit, west ridge and valley
# hold together in one frame. Its yaw is `atan2(dz, dx)` toward the summit column
# at (-256,-96) h=231 -- derived, not guessed, because an earlier pair pointed
# away from the massif and two renders came back with no snow in frame.
(def scenic-presets
  # Ground-ish prospect: south-east of the massif, looking north-west and slightly
  # up, so the snowfield fills the upper third.
  # `grounded` exists so a capture can exercise the interactive seating without a
  # mouse: it is the same dry-land placement, and naming it makes "prove the
  # player is on the ground" a one-flag test rather than a live run.
  {:grounded {:x -24 :z -37 :yaw 0 :pitch -0.1}
   :valley {:x -24 :z -37 :yaw 0 :pitch -0.1}
   # High overview: back far enough to hold summit, west ridge and valley together.
   :aerial {:x 60 :y 250 :z 140 :yaw -2.500 :pitch -0.05}})

(defn scenic-preset
  ``The named preset `view`, or nil when it is not one (including absent).

  Returned as a plain table so a caller can merge it with explicit flags without
  knowing which fields came from where. An unknown name is not an error here: the
  caller reports it, because "no preset" and "a typo" need different messages.``
  [view]
  (when (and (string? view) (not (empty? view)))
    (get scenic-presets (keyword view))))

(defn scenic-preset-name?
  "Is `view` a preset this build knows?"
  [view]
  (not (nil? (scenic-preset view))))

(defn static-qa-view?
  ``Is this run photographing a FIXED viewpoint rather than simulating play?

  The sky, water and scenic presets all mean the same thing to the frame loop:
  the operator named an exact eye and orientation, so nothing may move it and
  nothing may edit the world underneath it. They were already written as three
  copies of `(or water-qa-view sky-qa-view scenic-view)` at each guard, which is
  one copy per guard per future view type. This is that expression, once, so a
  fourth preset cannot inherit three guards and miss the fourth.

  An INTERACTIVE scenic launch is not this: the viewpoint is where the player
  STARTS, not where the camera is pinned. Treating it as static would freeze a
  person who asked to be placed on the map, which is the opposite of the
  request.``
  []
  (truthy? (or water-qa-view sky-qa-view
                (and screenshot-path
                     (or active-slot world-seed-authoritative))
                (and scenic-view (or screenshot-path (not scenic-interactive))))))
# Load the WHOLE finite map before the first frame. A scenic map is complete on
# disk, so there is nothing to wait for: streaming it a few chunks per frame
# means a capture has to guess a frame budget and hope the far edge arrived in
# time. Preloading makes "the map is loaded" a state rather than a schedule, and
# costs one bounded pass (1024 chunks ~ 13 s generation plus meshing) instead of
# a 3000-frame walk. Ignored for every session without a map.
(def scenic-preload (arg-flag? "--scenic-preload"))
# The front door. It is the default for an interactive launch, and it is bypassed
# by everything that already names a world: a terrain cache, a scenic map, a QA
# capture, `--verify-pgo`, or a scripted headless run. Those runs are deterministic
# by design, and a menu would make them wait for a human who is not there.
(def no-menu (arg-flag? "--no-menu"))
(def menu-qa (arg-flag? "--menu-qa"))
(def menu-frames (arg-number "--menu-frames" nil))
(def world-slot (arg-value "--world-slot"))
# Deterministic entry points, for CI and for a GPU-less machine where a human
# cannot click. They produce the SAME request the menu produces and then run the
# same code, so the create path exercised here is the create path a player uses --
# not a second one. Never offered as a shipped feature: the front door stays the
# default, and these only fill in what the menu would have said.
(def qa-new-world (arg-value "--new-world"))
(def qa-world-seed (arg-value "--world-seed"))
# Which provider `--new-world` uses. Absent means procedural, so every existing
# QA invocation is unchanged. This is the ONE way to exercise the Python provider
# through the real create path without a menu, which is how a controlled real run
# is requested without a human clicking.
(def qa-world-provider (arg-value "--world-provider"))
# Map size for a learned QA create. Validated by the provider like any other
# setting, so a bad value refuses the create rather than reaching the model.
(def qa-world-size (arg-number "--world-size" nil))
# Bounds a generation by FRAMES, for cancel tests with a fake provider that never
# finishes. nil -- the default -- means an interactive run waits for the child,
# because a generation that takes minutes is not a failure.
(def qa-generation-frames (arg-number "--generation-frames" nil))
(set generation-frame-budget qa-generation-frames)
(def qa-menu-screen (arg-value "--menu-screen"))
(def world-root (or (arg-value "--world-root") "worlds-v1"))

(defn ensure-world-root!
  ``Create the catalogue root if it is not there.

  `create-slot` requires an existing directory, so a first launch has to make one
  -- but only when a world is actually going to be written. Making it at startup
  would put a directory on disk for a player who only ever ran `--verify-pgo`.``
  [root]
  (when (nil? (os/stat root))
    (def parent (last (string/split "/" root)))
    (unless (or (= parent root) (nil? (os/stat parent)))
      (os/mkdir parent))
    (os/mkdir root))
  root)
# Chunks around the spawn prepared BEFORE an interactive scenic launch hands over
# control. 9 chunks of radius shows a real clearing in every direction, which is
# what stops the first frame from being a hole; the stream takes over from there.
(def scenic-prepare-radius 9)
# Scene lines are AUTHORED and overridable per run. The defaults are the measured
# watershed values; the flags exist so a capture can test a different line without
# rebuilding, which is the only way to settle "is the snow where I think it is"
# against a real render rather than against an argument.
(def snow-line-arg (arg-number "--scenic-snow-line" nil))
(def tree-line-arg (arg-number "--scenic-tree-line" nil))
(def rock-slope-arg (arg-number "--scenic-rock-slope" nil))
(def tree-slope-arg (arg-number "--scenic-tree-slope" nil))
(def density-arg (arg-number "--scenic-density" nil))
(def lattice-arg (arg-number "--scenic-lattice" nil))
# Authored clearings, for an A/B against a uniform-forest scene. The unit is the
# engine's OWN: an integer PERCENT of coarse cells in 0..100, passed through
# unchanged. There is deliberately no fraction form and no scaling anywhere --
# `src/scenic-worldgen.janet` asserts an integer percent and would raise on a
# fraction, so a CLI that spoke 0..1 would need a conversion that silently
# rewrites the operator's number. A diagnostic must mean exactly what it says.
#
# It is a FREQUENCY over cells, not a percentage of cleared ground: one disk of
# radius 10 covers 317 of a cell's 1024 blocks, so 25 does not clear 25% of the
# area. Any label written from this must say "cell selection", never "area %".
#
# Read through `arg-value` rather than `arg-number`, deliberately: `arg-number`
# returns its fallback for unparseable text, so `--scenic-clearing-density abc`
# would silently mean "absent" and a typo would produce a normal-looking render.
# Presence has to be observable in order to reject it.
(def clearing-density-arg (arg-value "--scenic-clearing-density"))
(defn scenic-clearing-density-ok?
  ``Is `value` a usable authored clearing density?

  Accepted form is an INTEGERS percent in 0..100 -- the engine's unit, unchanged
  (`src/scenic-worldgen.janet` asserts exactly this and raises otherwise). A
  fraction such as 0.25 is REFUSED, not rescaled: converting it would quietly
  replace the number the operator typed with a different one, and nothing in the
  resulting image would reveal that it happened.

  NaN and infinities are rejected, never clamped. A clamp turns a typo into "a
  plausible forest with no clearings", which is precisely the failure this
  diagnostic exists to expose. Pure, so the rule is testable without a window.``
  [value]
  (and (number? value)
       (<= 0 value 100)                      # NaN fails this comparison
       (= value (math/floor value))))

(def camera-x (arg-number "--camera-x" nil))
(def camera-y (arg-number "--camera-y" nil))
(def camera-z (arg-number "--camera-z" nil))
(def camera-yaw (arg-number "--camera-yaw" nil))
(def camera-pitch (arg-number "--camera-pitch" nil))
(def sky-seconds (arg-number "--day-seconds" 1200))
# Headless benchmarking controls: a 90-frame capture cannot stream a large
# radius to steady state, so the frame count and radius must be settable.
(def bench-frames (arg-number "--frames" nil))
(def verify-pgo (arg-flag? "--verify-pgo"))
(def verify-seed (arg-number "--verify-seed" 4))
# `--scenic-radius` is the same knob under the name a scenic capture reaches for.
# Both spell it, because `--radius` is the general engine control and a scene
# operator should not have to know that it also sets map coverage.
(def forced-radius (or (arg-number "--scenic-radius" nil)
                       (arg-number "--radius" nil)))
# Capture readiness. A `--screenshot` run otherwise photographs whatever frame 89
# happens to hold, which on a preloaded finite map is a mesh queue still ~800
# chunks deep -- the picture then shows holes that are a SCHEDULING fact, not a
# terrain one. Opt-in because it changes how long a capture runs: with it the
# frame bound becomes a FLOOR and the run continues until the resident set is
# actually on screen. Bounded by a wall clock, because "not ready yet" must never
# mean "wait forever" in CI.
(def capture-ready (arg-flag? "--capture-ready"))
(def capture-timeout-arg (arg-number "--capture-timeout" 180))
# Diffusion terrain: an identity directory of precomputed height tiles produced
# by the Python backend. Absent, the shipped procedural generator runs and
# nothing about this file changes. The dir's manifest fixes the generation
# digest and its seed, so a cache baked for another seed is refused BEFORE a
# window opens instead of silently serving terrain from another world.
# VAR: a session that generates its own map points this at the new artifact, so
# every later reader sees one cache root rather than a special case.
(var terrain-cache-dir (arg-value "--terrain-cache"))
(def explicit-seed (arg-value "--seed"))
# Loading-stage QA controls. `--loading-frames N` runs exactly N loading frames
# and exits with one status line, so a capture or a test can observe the
# responsive window without waiting for a bake; `--loading-screenshot` captures
# during that stage; `--loading-timeout` bounds the wait where nobody can press
# Esc. `--terrain-python` overrides the worker interpreter for autolaunch.
(def loading-frames-arg (arg-number "--loading-frames" nil))
(def loading-screenshot (arg-value "--loading-screenshot"))
(def loading-timeout-arg (arg-number "--loading-timeout" nil))
(def terrain-python (or (arg-value "--terrain-python") default-terrain-python))
# Autolaunch is the default because a cold cache otherwise waits forever for a
# worker nobody started. Suppressing it is a real QA need: a deterministic test
# of "missing tiles" must not be rescued by a background bake, which would make
# the observed state depend on how fast inference happens to be.
(def no-terrain-worker (arg-flag? "--no-terrain-worker"))
# Explicit loading backdrops. Absent, the presentation module discovers images
# under `<root>/assets` itself -- so an install with the shipped art works with
# no flag at all, and a QA run can point at one specific image.
(defn arg-list [flag]
  (def out @[])
  (def args (dyn :args))
  (for i 0 (length args)
    (when (and (= (get args i) flag) (< (+ i 1) (length args)))
      (array/push out (get args (+ i 1)))))
  out)
(def loading-background-paths
  (let [paths (arg-list "--loading-background")]
    (if (empty? paths) nil paths)))
(defn valid-seed? [v]
  (and (number? v) (not (nan? v)) (= v (math/floor v)) (<= 0 v) (<= v 1000000)))
(when explicit-seed
  (def parsed (scan-number explicit-seed))
  (unless (valid-seed? parsed)
    (error (string "--seed expects an integer 0..1000000, got " explicit-seed)))
  (set seed parsed))
# This mode retains the ordinary game's rendering, generation, meshing and
# raycasting, but makes the simulation and stream schedule independent of clocks.
# Only the final state line is written to stdout for AOT PGO parity.
(when verify-pgo
  (when (or (and (arg-value "--verify-seed")
                 (or (not (number? verify-seed)) (< verify-seed 0)
                     (> verify-seed 1000000)
                     (not= verify-seed (math/floor verify-seed))))
            (and (arg-value "--frames") (or (not (number? bench-frames))
                                  (< bench-frames 1) (> bench-frames 1500)
                                  (not= bench-frames (math/floor bench-frames))))
            (and (arg-value "--radius") (or (not (number? forced-radius))
                                   (< forced-radius 2) (> forced-radius 12)
                                   (not= forced-radius (math/floor forced-radius)))))
    (error "--verify-pgo requires integer --frames 1..1500, --radius 2..12 and --verify-seed 0..1000000"))
  (when (or (arg-flag? "--dev") (arg-flag? "--fullscreen")
            (arg-value "--screenshot") (arg-value "--water-view")
            (arg-value "--sky-view") (arg-value "--sky-phase")
            (arg-value "--scenic-view")
            (arg-value "--day-seconds"))
    (error "--verify-pgo cannot combine with dev, fullscreen or visual QA options"))
  # The PGO parity path is a byte-exact procedural workload; cached terrain
  # would change what it generates, so the combination is refused outright
  # rather than quietly altering the baseline it exists to protect.
  (when terrain-cache-dir
    (error (string "--verify-pgo cannot combine with --terrain-cache: the "
                   "verification workload pins the procedural generator, while "
                   "--terrain-cache replaces it with baked tiles")))
  (when explicit-seed
    (error "--verify-pgo selects its seed with --verify-seed; --seed is not allowed")))
(when verify-pgo (set seed verify-seed))
(defn timing-printf [format & args]
  (apply (if verify-pgo eprintf printf) format args))

# Keep each update exact in IEEE double (< 2^53 before modulo), and hash
# sorted chunk coordinates plus every block, not pointer/GC/GPU identities.
(defn pgo-hash-step [hash value]
  (% (+ (* hash 33) value) 2147483647))
# Uncapped drops both vsync and the 60 FPS target. With vsync on, every frame
# that fits inside the refresh interval reports ~16.7 ms regardless of how
# much headroom is left, so the cap hides the engine's real cost. Phase 8
# needs the unclamped number.
(def uncapped (arg-flag? "--uncapped"))
(def fullscreen (arg-flag? "--fullscreen"))
# Development socket REPL. OFF unless asked for, and that gate is the entire
# production story: an eval port is remote code execution for anything that can
# reach it, so a shipped build must not merely hide the socket, it must never
# open one. No default port, no autostart, no "convenience" fallback.
(def dev-mode (arg-flag? "--dev"))
(def dev-port (arg-number "--dev-port" 0))
(def headless-frames
  (cond bench-frames bench-frames
        verify-pgo 1500
        screenshot-path 90
        nil))

# `--capture-ready` changes what a capture MEANS, so a run that names no output
# file would silently do nothing, which reads as a broken flag. Refuse the
# combinations outright instead: this mode is scheduling evidence, and
# `--verify-pgo` is byte-exact PGO parity evidence that a longer, differently
# ordered frameloop would corrupt.
(def capture-timeout-cap 3600)
(defn capture-timeout-ok?
  ``Is `seconds` usable as the wall-clock ceiling on a readiness wait?

  Kept pure and shared between the CLI gate and the tests rather than letting
  the flag site re-derive the rule. Three conditions: it is a number, it is
  strictly positive, and it is bounded. A zero or negative budget would expire
  before the first frame was drawn and would read as "meshing is broken"; nil and
  NaN are not durations at all.

  The UPPER bound is `capture-timeout-cap` (one hour). Having no upper bound was
  the earlier position and it was wrong for exactly the reason this gate exists:
  a capture that never becomes ready is a hang, and an operator-supplied infinity
  is that same hang with a flag's blessing. An hour is far past any real capture
  -- a 1024-chunk map meshes in tens of seconds -- while still guaranteeing the
  process terminates with a diagnostic instead of occupying CI overnight.``
  [seconds]
  # A bounded range check, not a chain of predicates: Janet has no `finite?`, and
  # NaN and infinity must both be excluded. (`< 0 nan`) is false while
  # (`< 0 inf`) is true, so only an explicit upper bound rejects infinity.
  (and (number? seconds)
       (< 0 seconds (+ 1 capture-timeout-cap))))

(when capture-ready
  (unless screenshot-path
    (error "--capture-ready requires --screenshot: it gates which frame the PNG is taken on"))
  (when verify-pgo
    (error "--capture-ready cannot combine with --verify-pgo: the verification workload fixes its frame count"))
  (unless (capture-timeout-ok? capture-timeout-arg)
    (error (string "--capture-timeout expects a number of seconds in 0.."
                   capture-timeout-cap ", got " capture-timeout-arg))))

#
# --- Terrain tile cache (diffusion) -------------------------------------
#
# The cache is a READ-ONLY baked artifact: this file never runs inference, and
# nothing on the frame path may block on the backend. The only channel is the
# filesystem -- `request` publishes a marker, `poll` observes tiles that
# appeared. A missing tile is therefore a normal, expected state: the chunk is
# skipped and asked for, never filled from noise, because noise terrain that
# looks plausible is worse than a visible hole: it silently contradicts the
# world the player is standing in.
#
# Spawning is the one place demanding completeness. The player needs collision
# ground under their feet from frame one, so all 25 spawn tiles are required
# BEFORE the window opens. If they are missing the run refuses to start and
# says what to do; it never waits for inference inside a frame loop.

# Radius (in columns) of the dry-land search. Bounded so a genuinely all-ocean
# world fails with a clear message instead of searching forever; 32 columns is
# wider than the spawn area, so ordinary coastal terrain always yields land.
(def spawn-search-radius 32)

(defn scenic-ground-block?
  ``Is this block something a player can STAND ON as terrain?

  Deliberately narrower than `world/block-solid?`, which counts wood and leaves
  because they are obstacles. A canopy is an obstacle that is empty underneath:
  treating it as ground seats the player in a treetop, which reads as the camera
  floating and is the bug this predicate exists to prevent. Terrain surfaces are
  grass, dirt, stone, sand and snow; nothing else is floor.``
  [id]
  (or (= id world/block-grass)
      (= id world/block-dirt)
      (= id world/block-stone)
      (= id world/block-sand)
      (= id world/block-snow)))

(defn scenic-ground-y
  ``Feet height on the map's own terrain at column (x,z), or nil.

  Scans down from the build ceiling for the first position where the player BOX
  fits: solid support under it, air through the body. That is the same question
  `spawn` asks, answered against the live world, so a scenic start uses the voxels
  that were actually generated rather than a height tile that may not have been
  filled yet. Water is not ground -- a start standing in the sea is the failure
  this exists to prevent -- so it is rejected explicitly rather than treated as a
  support block.``
  [w x z]
  (var y (- world/chunk-y 3))
  (var found nil)
  (while (and (nil? found) (> y 1))
    (def below (world/world-get-block w x (- y 1) z))
    (def here (world/world-get-block w x y z))
    # The feet cell must be AIR, not merely non-colliding. Without that test the
    # scan walks straight DOWN THROUGH a water surface and stops on the seabed
    # beneath it, so a sea column reports a feet height and the player starts
    # underwater -- the exact failure this function exists to prevent. Water is
    # neither support nor standing room.
    (when (and (= world/block-air here)
               (scenic-ground-block? below)
               (not (player/box-collides? w (+ x 0.5) y (+ z 0.5))))
      (set found y))
    (-- y))
  found)

(defn scenic-seat!
  ``Place the player standing on dry ground near (x,z), or report why not.

  Returns `[feet-y source]` where source is `:requested`, `:searched` (the map
  under the requested column was water or blocked, so a nearby column was used) or
  `:none`. The search is bounded by `spawn-search-radius`, and it never invents
  ground: if the whole neighbourhood is water or unloaded, the caller is told and
  the player keeps the fallback position.``
  [w p x z]
  (defn seat-at [fx fy fz source]
    (put (p :pos) 0 fx)
    (put (p :pos) 1 fy)
    (put (p :pos) 2 fz)
    [fy source])
  (def direct (scenic-ground-y w x z))
  (if direct
    (seat-at (+ x 0.5) direct (+ z 0.5) :requested)
    # The seabed of a broad search is the wrong tool here: `spawn/find-dry-spawn`
    # asks whether a block is SOLID, and a canopy is solid, so it can hand back a
    # treetop. This walks the nearby columns itself and applies the same terrain
    # rule as `scenic-ground-y`, so a fallback seat is ground for exactly the same
    # reason a direct one is. The bound matches the spawn search's own radius.
    (do
      (var best nil)
      (def r (min 32 spawn-search-radius))
      (for dz (- r) (+ r 1)
        (when (nil? best)
          (for dx (- r) (+ r 1)
            (when (nil? best)
              (def gx (+ x dx))
              (def gz (+ z dz))
              (when-let [gy (scenic-ground-y w gx gz)]
                (set best [gx gy gz]))))))
      (if best
        (seat-at (+ (get best 0) 0.5) (get best 1) (+ (get best 2) 0.5) :searched)
        [:none :none]))))


(def cache-capacity 64)      # bounded pending requests, matches the consumer
(def poll-limit 4)           # coordinates probed per frame: a few stats
# Attempts per frame against not-yet-loaded coordinates in diffusion mode. A
# miss costs a tile stat plus, on first sight, a request stat pair, and it does
# NOT consume the mesh budget the way a hit does -- so without this bound the
# generation loop would walk the entire wanted set every frame while terrain is
# absent, which is O(wanted) synchronous filesystem work per frame regardless
# of poll-limit. Every attempt (hit or miss) counts here.
(def diffusion-attempts-per-frame 8)
# Preflight probes are stat-only and run ONCE, but they are still bounded to a
# fixed number per pass so a larger spawn radius cannot turn startup into an
# unbounded filesystem walk. At the shipped spawn-radius of 2, the 25 tiles fit
# in a single budget; the cap is what keeps that a property of the code rather
# than of the constant.
(def preflight-probe-budget 25)

# Opened at preflight, before raylib initialises. nil means procedural.
(var terrain-cache nil)

#
# --- Scenic map (TDS3) --------------------------------------------------
#
# A scenic cache is ONE finite, offline map: a rectangle of chunks with a
# declared inclusive `[cx0 cz0 cx1 cz1]` and a height band of 4..252 instead of
# the streaming product's 4..60. Three consequences shape everything below, and
# each one is a refusal rather than a convenience.
#
#   * THE MAP IS FINITE. Coordinates outside the bounds are never requested,
#     never generated, and never filled with noise. A map edge is a real edge:
#     looking past it shows sky, because a plausible-looking invented cliff would
#     be indistinguishable from data that is actually there.
#
#   * NO WORKER. A scenic artifact is complete when it is written. There is no
#     bake to wait for and nothing to ask, so the Python worker is never
#     autostarted for one -- a backend that answers `:out-of-bounds` for every
#     coordinate would only burn cycles proving the map has edges.
#
#   * ONE HEIGHT FIELD. Both the terrain fill and the tree decoration read the
#     SAME height callback, backed by the map's own tiles through a small memo.
#     Decoration therefore cannot place a tree above ground the terrain does not
#     have, and neither can invent a column the map does not cover.
#
# The legacy TDH2 and procedural paths never enter any of this: `scenic-opts`
# stays nil and `fill-tile-into!` calls exactly the generator it always did.

# Authored presentation of the selected watershed, not inferred model climate.
# The format ceiling is a safety bound, NOT the map's measured snowline.
(def scenic-snow-line 170)   # 27% of the measured watershed lies above this
(def scenic-tree-line 150)
(def scenic-density 45)      # percent of lattice cells that grow a conifer
(def scenic-lattice 5)       # anchor spacing in blocks
(def scenic-rock-slope 6)
(def scenic-tree-slope 4)
# Widest streaming radius a finite map may choose on its own. The shipped
# watershed is 32x32 chunks, so 20 reaches 320 of its 512 blocks from the centre
# -- enough to include the western peaks from a centre-ish camera, but NOT from a
# camera parked at the east edge. 24 is the parent's requested ceiling; larger
# maps still clamp here, because each ring is quadratic in meshes.
(def scenic-radius-cap 24)
# A finite map's default view distance. Half its span is usually smaller, so this
# is a floor: a small map still gets a radius that reaches past its own edge, and
# a large one starts at a radius that shows real terrain rather than a clearing.
(def scenic-default-radius 16)
# A finite map's horizon is meant to be seen: the streaming default (0.0045) is
# tuned to hide the edge of an unbounded world and would fog a vista to grey.
(def scenic-fog-density 0.0015)
(def scenic-memo-capacity 2048) # loaded height tiles retained (bounded)
(def scenic-json-max-bytes 65536)

# nil means "not a scenic session". Every scenic helper below is inert while
# these are nil, so the legacy path cannot reach one by accident. The cache is
# held here rather than read from `terrain-cache` because the scenic path must be
# driven by the artifact it was set up from: a helper that reached for whichever
# cache happened to be open would be one assignment away from reading tiles out
# of a different map than the bounds it is bounding.
(var scenic-cache nil)
(var scenic-opts nil)
(var scenic-memo nil)
(var scenic-missing nil)
(var scenic-errors nil)
# The chunk the spawn ring is centred on: the map's own centre for a scenic
# cache, the origin for every other session.
(var spawn-origin [0 0])
# The same point in BLOCK columns. Deliberately 0,0 for every session without a
# map, which is exactly what the procedural spawn search and start position used
# before this file grew a scenic path -- so their behaviour cannot shift.
(var spawn-block-origin [0 0])

(defn scenic-cache?
  "Is this open cache the finite scenic product (TDS3) rather than streaming TDH2?"
  [cache]
  (and cache (= :scenic (tcache/cache-profile cache))))

(defn scenic-reset!
  ``Forget the active map and return every scenic branch to inert.

  The one exit from the scenic path. `main` never calls it -- a session has one
  map for its lifetime -- but a headless test that drives several maps in one
  process must be able to put the module back exactly as it found it, or the
  first map would silently govern the rest.``
  []
  (set scenic-cache nil)
  (set scenic-opts nil)
  (set scenic-memo nil)
  (set scenic-missing nil)
  (set scenic-errors nil)
  (set spawn-origin [0 0])
  (set spawn-block-origin [0 0])
  true)

(defn scenic-bounds
  "Inclusive `[cx0 cz0 cx1 cz1]` for a scenic cache, or nil."
  [cache]
  (if (scenic-cache? cache) (tcache/cache-bounds cache) nil))

(defn scenic-spawn-chunk
  ``The map's own centre chunk: deterministic, always inside the bounds, and
  the one place a session's spawn ring can be centred without inventing a
  coordinate the map does not cover.``
  [cache]
  (def b (scenic-bounds cache))
  (unless b
    (error "a scenic cache must declare :bounds; without them the map is undecidable"))
  [(math/floor (/ (+ (get b 0) (get b 2)) 2))
   (math/floor (/ (+ (get b 1) (get b 3)) 2))])

(defn scenic-spawn-block
  ``The map-centre chunk expressed in BLOCK columns.

  `spawn/search-new` walks block columns, not chunk coordinates -- passing a
  chunk index here would search a 32-block square 100 000 blocks away from the
  map, find only unloaded holes, and report "no dry land" for a map made of
  nothing but land. The half-chunk offset lands on a column centre, which is
  where a body actually stands.``
  [cache]
  (def c (scenic-spawn-chunk cache))
  [(+ (* (get c 0) world/chunk-x) (math/floor (/ world/chunk-x 2)))
   (+ (* (get c 1) world/chunk-z) (math/floor (/ world/chunk-z 2)))])

(defn scenic-map-span
  "`[chunks-x chunks-z]` the map covers, or `[0 0]` without one."
  [cache]
  (def b (scenic-bounds cache))
  (if b
    [(+ 1 (- (get b 2) (get b 0))) (+ 1 (- (get b 3) (get b 1)))]
    [0 0]))

(defn scenic-radius-for-map
  ``Streaming radius that shows a finite map from its own centre.

  A scenic map is already on disk, so the only reason to load less than all of it
  is cost. Half the larger span reaches the far edge from the centre, which is the
  smallest radius that cannot show a truncated map; it is capped at
  `scenic-radius-cap` because a large artifact would otherwise turn startup into
  a multi-second mesh pass. `--radius` still overrides this outright.``
  [cache]
  (def s (scenic-map-span cache))
  (def span (max (get s 0) (get s 1)))
  # A PRELOADED map is fully resident and must STAY resident. Half-span from the
  # centre leaves the corners outside the unload ring, so the stream would drop
  # 492 of the 1024 chunks it had just built -- paying the whole preload cost and
  # then throwing half of it away. The radius therefore covers the map's own
  # diagonal span, which is the smallest circle containing the rectangle.
  (def reach (if scenic-preload span (math/ceil (/ span 2))))
  (max (if scenic-preload 2 scenic-default-radius)
       (min (if scenic-preload (+ span 2) scenic-radius-cap) reach)))

(defn scenic-in-bounds?
  ``Does the ACTIVE map cover this chunk? True for every session without one, so
  the procedural and legacy paths answer true rather than special-casing.``
  [cx cz]
  (def b (scenic-bounds scenic-cache))
  (if (nil? b)
    true
    (and (<= (get b 0) cx (get b 2)) (<= (get b 1) cz (get b 3)))))

(defn- read-text-capped
  "At most `cap` bytes of `path` as text, or nil when it cannot be opened."
  [path cap]
  (def f (try (file/open path :rb) ([err] nil)))
  (when f
    (def data (try (file/read f cap) ([err] nil)))
    (file/close f)
    (when data (string data))))

(defn- parse-int-from
  ``The integer beginning at or after `from` in `text`, or nil.

  Written by hand rather than with `scan-number` on a slice, because the
  surrounding JSON is arbitrary: `scan-number` on `"64, \"x\": 1"` returns nil,
  and a nil sea level would silently become the legacy waterline.``
  [text from]
  (var i from)
  (while (and (< i (length text))
              (let [c (get text i)] (or (= c 32) (= c 9) (= c 10) (= c 13))))
    (++ i))
  (def start i)
  (when (and (< i (length text)) (= 45 (get text i))) (++ i))
  (while (and (< i (length text)) (<= 48 (get text i) 57)) (++ i))
  (when (> i start)
    (def n (scan-number (string/slice text start i)))
    (if (number? n) (math/floor n) nil)))

(defn scenic-sea-level
  ``The map's declared `sea_level`, or nil when the record does not state one.

  Read from the map record beside the twin -- the file `tcache/scenic-json-path`
  names, currently `provenance.json` -- which the cache has already bound to
  `manifest.janet` by exact size and CRC-32. So this is a bounded read of bytes
  known to be the ones the manifest names, not a second opinion about them.

  The scan itself is deliberately narrow: `"sea_level"` followed by an integer.
  It is not a JSON parser and does not try to be, because the cache has already
  proved these bytes are the record it validated -- but a regex over a record
  that may legitimately contain a nested `sea_level` elsewhere must take the
  FIRST colon after the key, which is what this does.
  Returning nil lets the caller fall back to the module default rather than to a
  guessed waterline.``
  [dir]
  (def text (read-text-capped (tcache/scenic-json-path dir) scenic-json-max-bytes))
  (when text
    (def at (string/find "\"sea_level\"" text))
    (when at
      (def colon (string/find ":" text at))
      (when colon (parse-int-from text (+ colon 1))))))

(defn scenic-scene-opts
  ``Scene options for one map: the artifact's sea level plus authored vista lines.

  The sea level comes from the MAP (falling back to the module default only when
  the record states none), because the waterline is a property of the elevation
  transfer that produced the heights -- a hardcoded 28 would flood a map
  quantized around sea 60 and still look like plausible terrain.

  The snow and tree lines are AUTHORED constants, not derived from the format
  ceiling. `:height-max` bounds what a tile may legally contain (252); it says
  nothing about where THIS watershed's snowline is, and deriving from it put snow
  on a 170-metre ridge because the artifact happened to permit 212. Those lines
  are chosen against the measured relief of the selected map.

  `:seed` is the manifest's, which the cache already checked against this
  session, so decoration is reproducible per artifact rather than per run.``
  [cache sea]
  (scenic/scene-opts
    (if (number? sea) {:sea_level sea} {})
    {:seed (cache :seed)
     :snow-line (or snow-line-arg scenic-snow-line)
     :tree-line (or tree-line-arg scenic-tree-line)
     :rock-slope (or rock-slope-arg scenic-rock-slope)
     :tree-slope (or tree-slope-arg scenic-tree-slope)
     :density (or density-arg scenic-density)
     :lattice (or lattice-arg scenic-lattice)}))

(defn- scenic-key [cx cz] (world/chunk-key cx cz))

(defn scenic-tile-heights
  ``The decoded heights for one map chunk, or nil when the map has no tile there.

  Memoised because a single chunk's fill and decoration ask for the same 18x18
  neighbourhood hundreds of times, and each miss would be a `stat` on the frame
  path. The memo is cleared wholesale at `scenic-memo-capacity`: retaining it
  forever would make memory a function of how far the session has looked. A
  corrupt tile is reported once and treated as ABSENT -- it cannot become noise,
  but it must not abort a frame that can still show the rest of the map.``
  [cx cz]
  (def k (scenic-key cx cz))
  (def known (get scenic-memo k ::absent))
  (if (not= known ::absent)
    known
    (if (get scenic-missing k)
      nil
      (let [hs (try (tcache/read-height-tile scenic-cache cx cz)
                    ([err]
                     (put scenic-missing k true)
                     (unless (get scenic-errors k)
                       (put scenic-errors k true)
                       (eprint (string "warning: scenic tile (" cx "," cz
                                       ") failed: " err)))
                     nil))]
        (when hs
          (when (>= (length scenic-memo) scenic-memo-capacity)
            (table/clear scenic-memo))
          (put scenic-memo k hs))
        hs))))

(defn scenic-height-at
  ``Height at a GLOBAL column, or nil when the map does not cover it.

  nil is the whole contract: `scenic/fill` leaves the column as air and
  `scenic/decorate!` plants nothing there, so a map edge renders as an edge. A
  column outside the declared bounds is answered without touching the filesystem
  at all -- that is what keeps a vista from walking out of the map.``
  [wx wz]
  # A world POSITION belongs to the block that contains it, so the column is the
  # floor of each axis. This is not cosmetic: `world-to-local-coord` on a
  # fractional coordinate yields a fractional offset, and `get` on a buffer with a
  # fractional index SILENTLY returns nil rather than raising. A camera eye at
  # x=59.99985 (which `(+ 60 (* (cos yaw) d))` produces for a yaw meant to be
  # exactly north) therefore reported the whole map as ABSENT -- the
  # never-invent-terrain rule firing in the opposite direction, hiding real
  # terrain instead of fabricating it. Flooring here makes any position inside a
  # block read that block's height.
  (def cx (world/world-to-chunk-coord (math/floor wx)))
  (def cz (world/world-to-chunk-coord (math/floor wz)))
  (when (scenic-in-bounds? cx cz)
    (def hs (scenic-tile-heights cx cz))
    (when hs
      (def lx (world/world-to-local-coord (math/floor wx)))
      (def lz (world/world-to-local-coord (math/floor wz)))
      (get hs (+ lx (* world/chunk-x lz))))))

(defn scenic-setup!
  ``Install the height field, scene options and spawn origin for one map.

  Called once, at preflight, after the cache validated. It writes nothing: the
  artifact is read-only and this only fixes which callbacks the session uses.``
  [cache]
  (set scenic-cache cache)
  (set scenic-memo @{})
  (set scenic-missing @{})
  (set scenic-errors @{})
  (def sea (scenic-sea-level (cache :dir)))
  (set scenic-opts (scenic-scene-opts cache sea))
  # Diagnostic opt-in only: no saved generation identity changes silently.
  (when (arg-flag? "--climate-surfaces")
    (assert (and scenic-view screenshot-path (nil? world-slot) (nil? qa-new-world))
            "--climate-surfaces requires a scenic screenshot, not a saved/new world")
    (def climate (scenic-climate/load! cache))
    (assert (= :attached (climate :status)) "requested climate surfaces but artifact has no climate")
    (put scenic-opts :surface-policy :v1)
    (put scenic-opts :climate-at (climate :sampler))
    (print "scenic climate: attached; authored surface policy v1; source-derived, not calibrated"))
  # Authored clearings, same guard as the climate surfaces: a diagnostic A/B on a
  # scenic screenshot, never a saved or newly created world. A world that is
  # written to disk carries a generation identity, and changing how its scenery is
  # decorated without versioning that identity would make two different maps claim
  # the same one. Absent, `scenic-opts` gains no `:clearing-density` key at all,
  # so the scene renders exactly as before and existing CRCs are unchanged.
  (when clearing-density-arg
    (assert (and scenic-view screenshot-path (nil? world-slot) (nil? qa-new-world))
            "--scenic-clearing-density requires a scenic screenshot, not a saved/new world")
    (def value (scan-number clearing-density-arg))
    (assert (scenic-clearing-density-ok? value)
            (string "--scenic-clearing-density expects an integer percent in 0..100"
                    " (e.g. 25 = a quarter of coarse cells), got "
                    clearing-density-arg))
    (put scenic-opts :clearing-density value)
    (printf (string "scenic clearings: authored %d%% of coarse cells selected"
                    " (diagnostic; not persisted)")
            value))
  (set spawn-origin (scenic-spawn-chunk cache))
  (set spawn-block-origin (scenic-spawn-block cache))
  (def b (scenic-bounds cache))
  (printf (string "scenic: finite map chunks [%d %d %d %d]"
                  "  spawn chunk (%d,%d)  sea %s  snow %d  tree %d  band %d..%d")
          (get b 0) (get b 1) (get b 2) (get b 3)
          (get spawn-origin 0) (get spawn-origin 1)
          (if (number? sea) (string sea) "unstated (default)")
          (scenic-opts :snow-line) (scenic-opts :tree-line)
          (cache :height-min) (cache :height-max))
  cache)

(defn scenic-generate-into!
  ``Fill and decorate one map chunk from the map's own heights.

  Fill and decoration share `scenic-height-at`, so the trees stand on exactly the
  ground the terrain wrote. Both write only inside this chunk, and neither
  invents a column the map does not cover.

  `scenic-height-at` takes world coordinates and Janet has no partial
  application here, so the callback is built once per call site rather than
  stored: a stored closure would be a second identity for the same function,
  which is exactly the kind of seam that drifts.``
  [blocks cx cz]
  (def height-at (fn [wx wz] (scenic-height-at wx wz)))
  (scenic/fill blocks cx cz height-at scenic-opts)
  (scenic/decorate! blocks cx cz height-at scenic-opts)
  blocks)

(defn fill-tile-into!
  ``The one generation seam: fill `blocks` for one chunk from its height tile.

  Legacy and scenic differ only in HOW a chunk becomes blocks, never in who calls
  it -- so the four generation sites (startup, wanted walk, poll adopt, loading
  stage) share one dispatcher instead of four branches that could drift apart.
  A legacy tile goes through the unchanged 4..60 adapter; a scenic chunk is
  filled and decorated from the map itself.``
  [blocks cx cz heights]
  (if scenic-opts
    (do
      # Prime the memo with the tile the caller already decoded, so the fill's
      # own reads are hits and the chunk cannot be built from two different
      # reads of the same coordinate.
      (when (and scenic-memo heights)
        (put scenic-memo (scenic-key cx cz) heights))
      (scenic-generate-into! blocks cx cz))
    (worldgen/generate-from-heights blocks cx cz heights)))

(defn fill-new-chunk!
  "Create a chunk from a height tile through `fill-tile-into!`, or nil."
  [cx cz heights]
  (when heights
    (def ch (world/chunk-new cx cz))
    (fill-tile-into! (ch :blocks) cx cz heights)
    ch))

(defn request-tile!
  ``Ask the backend for one coordinate, unless this session has no backend.

  A finite scenic map has nothing to ask: every coordinate it declares is either
  already on disk or genuinely absent, and a request marker would be a stray file
  written into a read-only artifact that no worker will ever read. Returning
  `:no-backend` keeps that fact visible to the caller instead of pretending a
  request was published. Every other session calls through to the cache
  unchanged.``
  [cache cx cz]
  (if scenic-opts
    :no-backend
    (tcache/request cache cx cz)))

(defn scenic-wanted-chunks
  ``Every chunk of the active map, nearest the map's centre first.

  The resident set of a FINITE artifact is the RECTANGLE the manifest declares,
  not a disc around the player. A disc is the right shape for an endless world,
  where "what is near" is the only meaningful question; for a 32x32 map it is the
  wrong shape twice over -- it leaves the far corners unresident while they are
  still inside the artifact, and it makes the loaded world depend on where the
  player happens to stand. Driven from the bounds, the set is a property of the
  map and cannot shrink by walking.``
  []
  (def b (scenic-bounds scenic-cache))
  (def c (scenic-spawn-chunk scenic-cache))
  (def out @[])
  (for cz (get b 1) (+ (get b 3) 1)
    (for cx (get b 0) (+ (get b 2) 1)
      (array/push out @[cx cz (stream/chunk-distance2 cx cz
                                                      (get c 0) (get c 1))])))
  (sort-by |($ 2) out))

(defn wanted-chunks
  ``Chunks the stream should hold around `(pcx,pcz)`, nearest first.

  For a scenic session this is the map's whole rectangle, independent of the
  player: a finite artifact is either loaded or it is not, and a disc around the
  player would silently drop preloaded chunks as they walked off centre. Every
  other session gets exactly the radius list it always got.``
  [pcx pcz radius]
  (if scenic-opts
    (scenic-wanted-chunks)
    (stream/chunks-in-radius pcx pcz radius)))

(defn surplus-chunks-for
  ``Loaded chunks the stream should drop, given where the player is.

  A scenic session drops NOTHING. Its resident set is the manifest rectangle, so
  every in-bounds chunk is wanted no matter how far the player has walked, and no
  out-of-bounds chunk can exist to be dropped. Applying the radius+margin rule
  here was the bug that evicted 449 of 1024 preloaded chunks the moment the player
  stepped off centre. Every other session keeps the hysteresis rule unchanged.``
  [pcx pcz radius margin loaded]
  (if scenic-opts
    @[]
    (stream/surplus-chunks pcx pcz radius margin loaded)))

(defn scenic-preload!
  ``Fill EVERY chunk of the finite map before the first frame.

  Returns how many chunks were built. A scenic map is complete on disk, so the
  only question is when to spend the work: streaming it a few chunks per frame
  makes a capture guess a frame budget and hope the far edge arrived, while a
  preload makes "the map is loaded" a state. The pass is deliberately blocky
  because it happens once, before the window shows anything worth looking at,
  and each chunk is the same `fill-tile-into!` the stream uses -- so a preloaded
  chunk and a streamed chunk are identical by construction, not by agreement.

  Outside a scenic session this does nothing: an unbounded world has no "whole
  map" to load, and inventing one would turn an endless exploration into a
  fixed-cost startup.``
  [w &opt radius progress]
  (unless (and scenic-opts (or scenic-preload scenic-interactive))
    (break nil))
  (def b (scenic-bounds scenic-cache))
  # `radius` bounds the work to a square around the map's centre so an
  # INTERACTIVE launch waits for a playable clearing rather than for all 1024
  # chunks. nil keeps the whole-map behaviour a capture wants. The bound is
  # deliberately applied here rather than by a second function: one fill seam,
  # one loop, one place where "which chunks does startup own" is decided.
  (def r (if (number? radius) (max 0 (math/floor radius)) nil))
  (def c (scenic-spawn-chunk scenic-cache))
  (def cx0 (if r (max (get b 0) (- (get c 0) r)) (get b 0)))
  (def cx1 (if r (min (get b 2) (+ (get c 0) r)) (get b 2)))
  (def cz0 (if r (max (get b 1) (- (get c 1) r)) (get b 1)))
  (def cz1 (if r (min (get b 3) (+ (get c 1) r)) (get b 3)))
  (def t0 (os/clock))
  (var built 0)
  (var done 0)
  (def total (* (inc (- cx1 cx0)) (inc (- cz1 cz0))))
  (for cz cz0 (+ cz1 1)
    (for cx cx0 (+ cx1 1)
      (when (and progress (not (progress done total)))
        (error "scenic preparation cancelled"))
      (unless (world/world-get-chunk w cx cz)
        (def heights (scenic-tile-heights cx cz))
        (unless heights (error (string "scenic tile missing during preparation: " cx "," cz)))
        (def ch (world/chunk-new cx cz))
        (fill-tile-into! (ch :blocks) cx cz heights)
        (world/world-put-chunk w ch)
        (++ built))
      (++ done)))
  (when progress (progress done total))
  (printf "scenic: preloaded %d map chunks in %.0f ms%s"
          built (* 1000 (- (os/clock) t0))
          (if r (string " (radius " r ")") " (whole map)"))
  built)

(defn menu-required?
  ``Should this run open the front door?

  Only when nothing else has already decided the world. A terrain cache, a scenic
  map, `--verify-pgo`, `--no-menu` or any scripted/headless run names its own
  world or is byte-exact evidence -- inserting a menu would break the first kind
  and hang the second. `--menu-qa` forces it on for a capture, which is the one
  case where a headless run DOES want the menu drawn.``
  []
  (and (not (truthy? no-menu))
       # A direct entry point has already said which world this is; opening a menu
       # over it would ask a question the flags just answered.
       (nil? qa-new-world)
       (or (truthy? menu-qa)
           (and (nil? terrain-cache-dir)
                (nil? explicit-seed)
                (nil? world-slot)
                (not verify-pgo)
                (nil? headless-frames)
                (not scenic-view)))))

(defn menu-providers
  ``The providers this build can offer, from the REAL registry.

  The view translates the registry's control vocabulary into its own; this
  function only decides which registry to read. Falling back to the view's static
  list when the registry is missing would hide a broken import behind a menu that
  looks fine, so a failure here is allowed to surface.``
  [] (menu-view/providers-from-registry
        (provider/providers-for-runtime python-runtime-probe) 2))

(defn menu-worlds
  ``Catalogue rows for the menu, or an empty list when nothing is saved yet.

  A MISSING directory is "no worlds", not an error: a first launch has no
  catalogue and must show an empty Load screen rather than a failure. Anything the
  catalogue refuses to parse is dropped by `worlds-of`, so a corrupt slot cannot
  appear as loadable.``
  [root]
  (if (os/stat root)
    (menu-view/worlds-of (catalog/list-slots root))
    @[]))

(defn maybe-start-worker-allowed?
  ``May this session start the Python terrain worker?

  Extracted so the one rule that matters is testable without a window: a finite
  scenic map is a COMPLETE offline artifact, so there is nothing for a worker to
  produce and no request it could answer. Starting one would only spend a process
  proving the map has edges. `--no-terrain-worker` still suppresses a legacy
  worker, and a legacy session still starts one -- so this function is the whole
  decision, not a scenic-only special case beside it.``
  [no-worker? has-map? custom-settings?]
  (and (not (truthy? has-map?))
       (not (truthy? no-worker?))
       # A worker generates DIFFUSION terrain from tiles with its own rules; it
       # knows nothing about this session's height scale, offset, sea level or
       # forest density. Streaming from it into a configured world would mix two
       # terrains in one landscape, which reads as corrupt chunks rather than a
       # missing branch. A configured session therefore runs single-threaded on
       # the configured path.
       (not (truthy? custom-settings?))))

(defn spawn-tile-coords
  ``The spawn ring's chunk coordinates, CLIPPED to the active map's bounds.

  A coordinate outside a scenic map is simply not required: nothing will ever
  produce it, and asking for it would turn "the map ends here" into "the bake is
  incomplete". Every session without a map keeps the exact 25-tile ring it had.``
  []
  (def ocx (get spawn-origin 0))
  (def ocz (get spawn-origin 1))
  (def out @[])
  (for cz (- ocz spawn-radius) (+ ocz spawn-radius 1)
    (for cx (- ocx spawn-radius) (+ ocx spawn-radius 1)
      (when (scenic-in-bounds? cx cz)
        (array/push out [cx cz]))))
  out)

(defn cache-open
  ``Validate and open one identity directory, or raise before any window.

  `tcache/cache-new` reads `manifest.janet`, refuses a malformed or missing
  manifest, and refuses a cache baked for a different seed -- so a cache whose
  identity cannot be established never reaches gameplay. Nothing is written
  here: opening must not touch a read-only baked artifact.

  The directory NAME must also be the manifest's identity. That is not
  cosmetic: the identity directory is the addressing scheme (`<root>/<digest>/`
  is how a cache root holds many generations), so a manifest sitting in a
  directory named anything else means either a copied or renamed tree. Both
  are ways to serve one generation's tiles under another's name, and the
  digest is the only thing that makes the tiles attributable.``
  [dir]
  (unless (string? dir)
    (error "--terrain-cache requires an identity directory path"))
  # A SCENIC MAP'S SEED BELONGS TO THE ARTIFACT. The session seed is what the
  # procedural generator samples with; a scenic map is already sampled, and its
  # manifest records the seed its export was baked from (12345 for the first real
  # watershed, against this file's default of 4). Demanding they match made every
  # real artifact unopenable, and ignoring the manifest would decorate the terrain
  # with a different seed than the map was built with. So the manifest is read
  # first, and a scenic artifact adopts its own seed for the session -- decoration
  # then reproduces per artifact rather than per invocation. A legacy cache keeps
  # the exact check it always had.
  (def manifest (tcache/load-manifest dir))
  (def scenic? (= :scenic (manifest :profile)))
  (def expected (if scenic? (manifest :seed) seed))
  (when (and scenic? explicit-seed (not= seed expected))
    (printf "scenic: --seed %d is the procedural seed; this map was baked at %d and governs"
            seed expected))
  (def cache (tcache/cache-new dir expected cache-capacity))
  (def named (last (string/split "/" dir)))
  (when (and (string? named) (not (empty? named)) (not= named (cache :identity))
             (not (and generated-artifact
                       (= (get generated-artifact :identity) (cache :identity)))))
    (error (string "terrain cache directory " dir " is named \"" named "\" but its "
                   "manifest.janet identifies the generation as "
                   (cache :identity) ". Rename the directory to the identity (or "
                   "rebake into it): a cache root addresses generations by "
                   "directory name, so a mismatch means the tiles are not "
                   "attributable to the generation they claim.")))
  (when scenic? (set seed (or world-seed-authoritative expected)))
  cache)

(defn spawn-tile-status
  ``Probe one spawn coordinate: `[:ready heights]`, `[:missing]` or
  `[:corrupt reason]`.

  A miss and a broken tile are different failures and must not be conflated:
  a miss means the bake has not produced that coordinate yet (ask for it and
  stop), while a present-but-undecodable tile means the cache is damaged and
  asking again cannot help. `read-height-tile` returns nil for the first and
  raises for the second, so probing is one stat per coordinate.``
  [cache cx cz]
  (def got (try (tcache/read-height-tile cache cx cz)
                ([err] [::corrupt (string err)])))
  (if (and (indexed? got) (= ::corrupt (get got 0)))
    [:corrupt (get got 1)]
    (if got [:ready got] [:missing])))

(defn spawn-tiles-missing
  ``One BOUNDED probe pass over the spawn tiles.

  Returns `[missing corrupt]`, each holding only what this pass examined, plus
  the count of coordinates it did not reach. The bound exists because this is
  filesystem work: unbounded it would grow with `spawn-radius`, and a caller
  that re-passes until the remainder is empty keeps total work linear in the
  tile count instead of depending on how many passes happen to run. At the
  shipped radius all 25 fit in one pass.

  A coordinate already known failed is reported as missing rather than being
  re-stat'ed every pass -- the consumer records terminal failures, so asking
  again cannot change the answer.``
  [cache &opt budget from]
  (def limit (or budget preflight-probe-budget))
  (def coords (spawn-tile-coords))
  (def start (or from 0))
  (def missing @[])
  (def corrupt @[])
  (def examined @[])
  (var i start)
  (var probed 0)
  (while (and (< i (length coords)) (< probed limit))
    (def coord (get coords i))
    (def cx (coord 0))
    (def cz (coord 1))
    # Skip work the consumer has already settled terminally: it will never
    # deliver, so re-probing it would spend the budget on a known answer.
    (if (tcache/failed? cache cx cz)
      (array/push missing coord)
      (do
        (++ probed)
        (array/push examined coord)
        (def status (spawn-tile-status cache cx cz))
        (case (get status 0)
          :corrupt (array/push corrupt [cx cz (get status 1)])
          :missing (array/push missing coord)
          :ready nil)))
    (++ i))
  [missing corrupt (- (length coords) i) examined])

(defn request-spawn-tiles
  ``Publish a request for every unresolved spawn coordinate.

  Returns `@[@@[cx cz outcome] ...]` so the caller can tell a published request
  from one the cache REFUSED. `request` distinguishes `:requested` / `:suppressed`
  (answered: on the queue, or terminally failed) from `:queued` (capacity full)
  and `:error` (requests directory unwritable). Collapsing those into "asked"
  is how a preflight message ends up telling the operator to wait for a worker
  that was never told what to bake, so the outcomes are kept and reported.``
  [cache missing]
  (def outcomes @[])
  (each coord missing
    (def cx (coord 0))
    (def cz (coord 1))
    (def outcome (try (request-tile! cache cx cz)
                      ([err] [::threw (string err)])))
    (array/push outcomes [cx cz outcome]))
  outcomes)

(defn request-failure-summary
  ``Human summary of the request outcomes that did NOT reach the queue, or nil.

  `:queued` is not a failure of the request itself -- the capacity is a bounded
  resource, not an error -- but it does mean this coordinate was never announced,
  so it is reported as a distinct, explicit condition rather than folded into
  "requested".``
  [outcomes cache]
  (def queued @[])
  (def errored @[])
  (def threw @[])
  (each o outcomes
    (def cx (get o 0))
    (def cz (get o 1))
    (def outcome (get o 2))
    (cond
      (= outcome :queued) (array/push queued [cx cz])
      (and (indexed? outcome) (= ::threw (get outcome 0)))
      (array/push threw [cx cz (get outcome 1)])
      (= outcome :error) (array/push errored [cx cz])
      # :requested and :suppressed both mean "the cache now knows about it".
      true nil))
  (when (or (pos? (length queued)) (pos? (length errored))
            (pos? (length threw)))
    (string
      (if (pos? (length errored))
        (string " " (length errored) " request(s) could not be written (the requests"
                " directory is unwritable);") "")
      (if (pos? (length threw))
        (string " " (length threw) " request(s) raised, first: "
                (get (get threw 0) 2) ";") "")
      (if (pos? (length queued))
        (string " " (length queued) " coordinate(s) were NOT requested because the"
                " pending queue is full (" (cache :capacity) ");") ""))))

(defn preflight-spawn
  ``Require every spawn tile, or refuse to start with an actionable message.

  Probing is BOUNDED per pass and repeated until every spawn coordinate has
  been examined, so startup filesystem work stays linear in the tile count
  rather than unbounded in one loop. Requests are published for whatever is
  missing, and a request the cache could not accept is reported as its own
  condition: a message that says "requested" when the queue was full or the
  requests directory unwritable would send the operator to wait on nothing.
  Nothing here waits for an answer, and nothing here falls back to noise. A
  corrupt tile is a separate, harder error: no amount of waiting repairs it.``
  [cache]
  (def expected (length (spawn-tile-coords)))
  (def missing @[])
  (def corrupt @[])
  (var from 0)
  # Each pass examines at most `preflight-probe-budget` coordinates; `from`
  # advances by what was examined, so this terminates in
  # ceil(total / budget) passes and cannot loop forever on a short read.
  (while (< from expected)
    (def [pass-missing pass-corrupt remaining examined]
      (spawn-tiles-missing cache preflight-probe-budget from))
    (each m pass-missing (array/push missing m))
    (each c pass-corrupt (array/push corrupt c))
    (set from (+ from (max 1 (length examined))))
    (when (zero? (length examined)) (set from expected)))
  (when (pos? (length corrupt))
    (def first (get corrupt 0))
    (when (> (length corrupt) 1)
      (eprint (string "warning: terrain cache has " (length corrupt)
                      " damaged spawn tiles; reporting the first")))
    (error (string "terrain cache " (cache :dir) " has a damaged spawn tile at ("
                   (get first 0) "," (get first 1) "): " (get first 2)
                   ". Delete it and rerun the terrain worker/bake for this identity."
                   " (No procedural fallback is used: noise terrain would silently"
                   " contradict the baked world.)")))
  (when (pos? (length missing))
    (def outcomes (request-spawn-tiles cache missing))
    (def problems (request-failure-summary outcomes cache))
    (def listed
      (string/join (map (fn [c] (string "(" (c 0) "," (c 1) ")"))
                        (array/slice missing 0 (min 8 (length missing))))
                   " "))
    (error (string "terrain cache " (cache :dir) " is missing " (length missing)
                   " of " expected " spawn tiles; asked for: "
                   listed (if (> (length missing) 8) " ..." "") "."
                   (or problems "")
                   (if (scenic-cache? cache)
                     (string " A scenic map is a COMPLETE offline artifact: no"
                             " worker can produce these tiles, so the export that"
                             " wrote this identity is incomplete. Re-run the scenic"
                             " importer for it, then relaunch.")
                     " Run the terrain worker/bake for this identity, then relaunch.")
                   " (No procedural fallback is used: noise terrain would silently"
                   " contradict the baked world.)")))
  cache)

(defn spawn-preflight
  ``Open the cache before `rl/init-window`, WITHOUT requiring its tiles.

  This is the identity gate only: `cache-new` parses `manifest.janet` and checks
  the seed, which is bounded file metadata -- no payload hashing, no tile
  decoding. An invalid identity can therefore still refuse before a window
  opens, while a merely INCOMPLETE cache no longer does: waiting for tiles is
  what the loading stage is for, and blocking before the window makes a slow
  bake look like a hang.

  Returns the cache, or nil for a procedural session.``
  []
  (when terrain-cache-dir
    (set terrain-cache (cache-open terrain-cache-dir))
    (if (scenic-cache? terrain-cache)
      (scenic-setup! terrain-cache)
      (printf "terrain: diffusion cache %s (identity %s, seed %d)"
              terrain-cache-dir (terrain-cache :identity) seed)))
  terrain-cache)

#
# --- Loading state core -------------------------------------------------
#
# The window opens BEFORE the spawn tiles are ready, so every step between
# "cache opened" and "playable world" is a state this module can be asked
# about without a window or a GL context. The state is plain data and the
# transitions are pure, which is what makes ready / missing / failed / cancelled
# testable without launching a game.
#
# Truthfulness rules, which are the whole point:
#
#   * A tile counts as READY only when its 256 heights have been decoded. A
#     `stat` hit is not readiness: the file may still be truncated, and the
#     backend publishes by rename precisely because partial files are possible.
#   * `heights` is keyed by coordinate, so observing the same tile twice cannot
#     inflate the count. `seen` tracks every coordinate a probe has touched.
#   * A failed coordinate is terminal and reported; it never becomes noise.

(def loading-states [:probe :await :build-world :find-spawn :build-meshes :ready])
(def loading-terminal-states [:failed :cancelled :timed-out])

(defn loading-new
  ``Fresh loading state for a diffusion startup.

  `coords` is the spawn set to require (25 at radius 2). The state starts in
  `:probe`, and carries only what a frame driver needs: which coordinates are
  required, what has been validated, and what has failed.``
  [cache coords]
  @{:cache cache
    :state :probe
    :coords coords
    :total (length coords)
    :heights @{}      # coord key -> decoded heights (READY, exactly once)
    :pending @{}      # coord key -> true, requested but not yet validated
    :failed @{}       # coord key -> reason (terminal)
    :probed @{}       # coord key -> true, touched at least once by a probe
    :reason nil       # terminal explanation for :failed
    :worlds 0         # chunks built so far
    :meshes 0         # chunks meshed so far
    :frame 0})        # loading frames rendered, for QA determinism

(defn loading-key [cx cz] (world/chunk-key cx cz))

(defn loading-ready-count [st] (length (st :heights)))
(defn loading-pending-count [st] (length (st :pending)))
(defn loading-failed-count [st] (length (st :failed)))

(defn loading-terminal? [st]
  "Is the loading stage finished, successfully or not?"
  [st]
  (or (= :ready (st :state)) (some |(= $ (st :state)) loading-terminal-states)))

(defn loading-valueless?
  ``Has the state failed for a reason that needs no tile?

  A cancelled or timed-out load still needs a screen; a failed one needs the
  reason it failed. Kept separate so a caller never renders ":failed" with a
  nil message.``
  [st]
  (= :failed (st :state)))

(defn loading-enter [st next]
  (put st :state next)
  st)

(defn loading-fail [st reason]
  (put st :reason reason)
  (loading-enter st :failed))

(defn loading-cancel [st]
  (loading-enter st :cancelled))

(defn loading-timeout [st]
  (loading-enter st :timed-out))

(defn loading-record-tile
  ``Absorb one `poll` result. Returns the state.

  `[:ready cx cz heights]` validates the coordinate: its heights are stored
  once, and a duplicate observation is ignored rather than counted again.
  `[:error cx cz reason]` is terminal for that coordinate and moves the whole
  stage to `:failed`, because a spawn tile that will never arrive cannot be
  waited out and must never be replaced by noise.``
  [st result]
  (def kind (get result 0))
  (def cx (get result 1))
  (def cz (get result 2))
  (def key (loading-key cx cz))
  (case kind
    :ready
    (do
      (put (st :probed) key true)
      (put (st :pending) key nil)
      # Store ONCE: a re-observed tile must not change the ready count.
      (unless (get (st :heights) key)
        (put (st :heights) key (get result 3)))
      st)
    :error
    (do
      (put (st :pending) key nil)
      (put (st :failed) key (get result 3))
      (loading-fail st (string "tile (" cx "," cz ") failed: " (get result 3))))
    st))

(defn loading-needs
  ``Coordinates still worth acting on: not validated, not failed.

  A validated coordinate is excluded even if it is still queued locally, and a
  failed one is excluded because asking again cannot help. Order follows
  `coords`, so the nearest-first spawn order is preserved.``
  [st]
  (def out @[])
  (each coord (st :coords)
    (def key (loading-key (coord 0) (coord 1)))
    (unless (or (get (st :heights) key) (get (st :failed) key))
      (array/push out coord)))
  out)

(defn loading-outstanding
  ``How many required coordinates are not yet validated.``
  [st]
  (- (st :total) (length (st :heights))))

(defn loading-progress-text
  ``One honest line for the loading screen.

  Says only what is known: how many tiles are decoded, how many are still being
  waited for, how many failed. It never claims a percentage of work the stage
  has not done, and it never implies per-tile latency -- a backend answers one
  query with many tiles, so a predicted ETA would be fiction.``
  [st]
  (def ready (loading-ready-count st))
  (def pending (loading-pending-count st))
  (def failed (loading-failed-count st))
  (def parts @[(string ready "/" (st :total) " tiles ready")])
  (when (pos? pending) (array/push parts (string pending " requested")))
  (when (pos? failed) (array/push parts (string failed " failed")))
  (when (pos? (st :worlds))
    (array/push parts (string "building " (st :worlds) "/" (st :total))))
  (when (pos? (st :meshes))
    (array/push parts (string "meshing " (st :meshes) "/" (st :total))))
  (string/join parts "  "))

(defn loading-describe
  ``Human description of a terminal state, or nil while it is still running.``
  [st]
  (case (st :state)
    :failed (or (st :reason) "the terrain cache could not supply the spawn tiles")
    :cancelled "cancelled"
    :timed-out "timed out waiting for spawn tiles"
    nil))

(defn loading-stage-required?
  ``Does this run need the interactive loading stage?

  Three separate inputs, which is why this is a named predicate rather than an
  inline `cond`:

  * a diffusion cache must exist at all;
  * `--verify-pgo` is a byte-exact procedural workload and must never enter it;
  * scripted headless runs (`--frames`, `--screenshot`) normally take the
    deterministic immediate build, so their frame accounting stays exact.

  The third point needs an exception. A QA run that explicitly asks to observe
  the loading stage -- `--loading-frames`, `--loading-screenshot` or
  `--loading-timeout` -- has said it WANTS the stage even though it is also
  scripted. Without this, `--loading-screenshot` on a 24/25 cache fell through
  to `preflight-spawn` and died on "missing 1 of 25" before drawing anything,
  which is the opposite of what the flag asks for.``
  [has-cache? verify? headless? loading-qa? &opt preload?]
  (and (truthy? has-cache?)
       (not (truthy? verify?))
       # A PRELOADED finite map meshes 1024 chunks. That is far past the point
       # where a single blocking `build-meshes` pass is acceptable -- it froze the
       # window for ~12 s with no progress and no Esc -- so a preload run takes
       # the incremental path even when it is scripted. The stage also draws the
       # meshing progress, which is the only honest answer to "is it working?".
       (or (not (truthy? headless?)) (truthy? loading-qa?)
           (truthy? preload?))))

(defn loading-budget-from-frames
  ``The loading-frame cap, or nil for "no frame cap".

  ONLY an explicit `--loading-frames` caps loading. Gameplay frames are a
  separate budget and must never bound startup: a `--frames 90` run once turned
  into a ~1.5-second loading deadline, so a 2-second publisher was never seen
  and the run failed on a cache that was about to be complete. A 100-second
  inference query with a 90-gameplay-frame capture must still be able to wait.
  `headless?` is accepted and deliberately ignored, so no caller can reintroduce
  the coupling by accident.``
  [explicit-loading-frames _headless]
  explicit-loading-frames)

(defn loading-timeout-for
  ``The wall-clock startup deadline in seconds, or nil when there is none.

  Only an explicit `--loading-timeout` sets one. There is deliberately NO
  implicit default: slow inference legitimately takes minutes, and a finite
  default would abort work that was about to succeed. `scripted?` is accepted
  and ignored for the same anti-coupling reason as above.``
  [_scripted explicit-timeout]
  explicit-timeout)

(defn loading-qa-requested?
  ``Did this run explicitly ask to observe the loading stage?

  Any of the three loading flags is such a request. Computed once at module
  level so the stage, the entry gate and the meshing gate cannot disagree about
  it -- the drift that made a QA run enter the stage and then mesh in one
  blocking pass.``
  []
  (and terrain-cache
       (or loading-frames-arg loading-screenshot loading-timeout-arg)))

(defn loading-advance
  ``The state transition this frame should make, as data.

  Returns `[:await needs]`, `[:build-world]`, `[:build-meshes]`, `[:ready]` or
  `[:hold]`. Pure, so the ordering rules are testable without a window:

  * all spawn tiles validated  -> `:build-world`
  * all chunks built           -> `:build-meshes`
  * all chunks meshed          -> `:ready`
  * otherwise                  -> stay in the current phase

  A terminal state always yields `[:hold]`: nothing advances past failure, and
  in particular nothing falls through to a playable world.``
  [st]
  (if (loading-terminal? st)
    [:hold]
    (case (st :state)
      # A probe that already found every tile ready (a warm cache) skips the
      # wait entirely: there is nothing to await.
      :probe (if (zero? (loading-outstanding st))
               [:build-world]
               [:await (loading-needs st)])
      :await (if (zero? (loading-outstanding st))
               [:build-world]
               [:await (loading-needs st)])
      :build-world (if (>= (st :worlds) (st :total)) [:find-spawn] [:build-world])
      # A found position is required before meshing/entering: landing in water
      # is the exact outcome this stage exists to prevent.
      :find-spawn (if (st :spawn) [:build-meshes]
                      (if (st :spawn-exhausted) [:hold] [:find-spawn]))
      :build-meshes (if (>= (st :meshes) (st :total)) [:ready] [:build-meshes])
      :ready [:ready]
      [:hold])))

(defn loading-step-probe
  ``One bounded probe pass over the coordinates still needed.

  `probe` is called with `(cx cz)` and returns `[:ready heights]`, `[:missing]`
  or `[:corrupt reason]` -- the shape `spawn-tile-status` produces. At most
  `budget` coordinates are touched, so a loading frame cannot stall on 25
  synchronous reads.

  A coordinate is NEVER retired for being seen once. That was a real hang: the
  backend only enqueues a coordinate locally when IT writes the request marker,
  so a marker left by a previous session makes `request` answer `:suppressed`
  and adds nothing to the poll queue -- and a probe that had already "checked"
  the coordinate would then never look again, leaving the loading stage waiting
  forever for a tile nothing was watching. Probing therefore rotates through
  every still-needed coordinate, so each one is re-examined every
  `ceil(needed / budget)` passes, which also covers tiles that arrive without
  ever having been requested (a bake running beside the game).

  Validated and failed coordinates drop out of `loading-needs`, so they are not
  re-examined; that is the only retirement, and it is based on a decoded tile
  or a terminal error, never on having looked.``
  [st probe budget]
  (def needs (loading-needs st))
  (def count (length needs))
  (when (pos? count)
    (def start (mod (or (st :probe-cursor) 0) count))
    (def take (min budget count))
    (for offset 0 take
      (def coord (get needs (mod (+ start offset) count)))
      (def cx (coord 0))
      (def cz (coord 1))
      (def key (loading-key cx cz))
      (put (st :probed) key true)
      (def status (probe cx cz))
      (case (get status 0)
        :ready
        (unless (get (st :heights) key)
          (put (st :heights) key (get status 1))
          (put (st :pending) key nil))
        :corrupt
        (do (put (st :failed) key (get status 1))
            (loading-fail st (string "tile (" cx "," cz ") is damaged: "
                                    (get status 1))))
        # :missing -- stays in `needs` and is probed again on a later pass.
        nil))
    (put st :probe-cursor (mod (+ start take) count)))
  st)


(defn session-sea-level
  "Waterline for spawn selection; saved poses are applied separately."
  []
  (or (get scenic-opts :sea-level)
      (get world-settings :sea-level)
      worldgen/sea-level))

(defn loading-step-find-spawn
  ``Advance the dry-land search by one bounded slice.

  Never fabricates terrain and never falls back to the water column at the
  origin: `spawn/search-step` only reports a position that has solid support at
  all four footprint corners and full body air above sea level, or reports
  `:exhausted` once its bounded region is used up.

  When the search has walked its whole radius and found nothing, `:requiredchunks`
  names the neighbouring chunks whose absence prevented a verdict. Those are the
  coordinates worth requesting -- asking for MORE COVERAGE is legitimate; asking
  for the same tiles again, or lowering the bar to "the block at the origin is
  solid", is not.``
  [st w budget]
  (def search (or (st :spawn-search)
                  (do (def s (spawn/search-new
                               {:origin-x (get spawn-block-origin 0)
                                :origin-z (get spawn-block-origin 1)
                                :radius spawn-search-radius
                                 :sea-level (session-sea-level)}))
                      (put st :spawn-search s)
                      s)))
  (spawn/search-step search w budget)
  (case (search :status)
    :found (do (put st :spawn (search :position))
               (put st :spawn-examined (search :examined))
               st)
    :exhausted
    (do
      (put st :spawn-exhausted true)
      (put st :spawn-examined (search :examined))
      # Coordinates the search could not judge, because their footprint chunks
      # are not loaded. Empty when every column was judged and all were
      # genuinely wet/blocked -- then more request markers cannot help.
      (put st :spawn-required (keys (search :requiredchunks)))
      st)
    (do (put st :spawn-examined (search :examined)) st)))

(defn loading-step-build-world
  ``Generate up to `limit` spawn chunks from already-validated tiles.

  Returns the number built. `build` is called with `(cx cz heights)`; the
  caller owns world mutation, so this stays testable with a stub that only
  counts. A coordinate with no validated heights is skipped and NOT counted --
  that is what keeps the progress number honest.``
  [st limit build]
  (def coords (st :coords))
  (var built 0)
  # `:worlds` is the index of the next coordinate to build, so it doubles as
  # the count of what has been built. Progress and position stay one number.
  (while (and (< (st :worlds) (length coords)) (< built limit))
    (def coord (get coords (st :worlds)))
    (def key (loading-key (coord 0) (coord 1)))
    (def heights (get (st :heights) key))
    (if heights
      (do (build (coord 0) (coord 1) heights)
          (++ built))
      # Unvalidated coordinates cannot occur after :await completes. If one
      # somehow does, advance past it rather than stall the whole stage --
      # and do not count it as built.
      nil)
    (++ (st :worlds)))
  built)

#
# --- World and meshes ---------------------------------------------------
#
#
# --- World and meshes ---------------------------------------------------
#
#
# --- World and meshes ---------------------------------------------------
#

#
# --- World and meshes ---------------------------------------------------
#

(defn generate-chunk-from-cache
  ``Fill one chunk from its baked height tile, or return nil when it is absent.

  Returns `[chunk]` on success so a legitimately empty chunk result is still
  distinguishable from a miss. A tile that exists but is malformed THROWS: that
  is a broken cache, not a tile that has not arrived, and continuing would hide
  permanently-ungeneratable terrain. A backend error file is reported once per
  coordinate by the caller, not per frame.``
  [w cache cx cz]
  (def heights (tcache/read-height-tile cache cx cz))
  (when heights
    (def ch (world/chunk-new cx cz))
    (fill-tile-into! (ch :blocks) cx cz heights)
    (world/world-put-chunk w ch)
    [ch]))

(defn gen-chunk-world!
  ``Generate one procedural chunk into the world, honouring this session's settings.

  THE SINGLE SEAM. Both generation sites -- the startup spawn pass and the
  streaming pass -- call this, so there is one place where "does this session have
  custom settings" is decided. A site that called `worldgen/generate-chunk`
  directly would produce default terrain in an otherwise configured world, and the
  mixture would look like corrupt chunks rather than a missed branch.

  With no settings this is exactly the shipped call, so a CLI launch keeps its
  bytes and its timing.``
  [w cx cz seed]
  (if world-settings
    (let [ch (world/chunk-new cx cz)]
      (provider/generate-into! :procedural (ch :blocks) cx cz seed world-settings)
      (world/world-put-chunk w ch)
      ch)
    (worldgen/generate-chunk w cx cz seed)))

(defn player-pose
  ``The four fields the catalogue persists about a player.

  Exactly what `player-record` validates: position, yaw, pitch, flying. The live
  player carries velocity, ground state and other session fields, and the
  catalogue rejects extra keys -- so the pose is built here, explicitly, rather
  than by passing a table that happens to contain the right ones today.``
  [p]
  (def pos (p :pos))
  @{:pos @[(get pos 0) (get pos 1) (get pos 2)]
    :yaw (p :yaw)
    :pitch (p :pitch)
    :flying (truthy? (p :flying))})

(defn new-slot-options
  ``Canonical catalogue options for one New Game create.

  THE ONE OPTIONS FACTORY. The production create path and its test both call this,
  so "the slot records the settings version the form was built under" is a
  property of one function rather than of a literal in `main` that a test can only
  imitate. Omitting `:settings-version` here is exactly the bug this exists to
  prevent: the catalogue then defaults to version 1, where a v2 control is an
  unknown key, and a v2 world with clearings would fail to save while still
  generating cleared terrain.

  The version comes from the FORM when it states one, because that is the contract
  the player's controls were rendered for. Only when it is absent is it inferred
  from the settings themselves, and that inference is the provider's own
  (`settings-version-for`), never repeated here.

  This VALIDATES NOTHING. `provider/validate-settings` has already canonicalised
  the settings at the create boundary, and the catalogue validates again on save.
  A third copy here would be a second definition of the same contract.``
  [choice seed world pose &opt name]
  (def pid (or (get choice :provider) :procedural))
  (def s (or (get choice :settings) @{}))
  @{:name (let [n (or name (get choice :name) "")]
            (if (empty? n) "New world" n))
    :seed seed
    :provider pid
    :settings-version (or (get choice :settings-version)
                          (provider/settings-version-for pid s))
    # A settings value may arrive as a table OR a struct -- a form holds a table,
    # while a literal written in code is a struct -- and `table/clone` refuses a
    # struct. The options must stay MUTABLE because the create path puts the
    # artifact keys into them afterwards, so a struct is copied into a table
    # rather than passed through.
    :settings (if (table? s) (table/clone s) (table ;(mapcat identity (pairs s))))
    :world world
    :player pose})

(defn apply-pose!
  ``Restore a saved pose onto the live player.

  Used by the load path so a restored world continues where it was left, instead
  of dropping the player at the spawn column. A missing or malformed pose leaves
  the player alone rather than erroring: a world that loads but starts at spawn is
  better than one that refuses to load because its pose record is odd.``
  [p pose]
  # A restored pose arrives as a struct with TUPLE fields (it was parsed from the
  # manifest), so the position test must accept both array and tuple -- checking
  # only `array?` silently skipped every restore, leaving the player at spawn
  # while reporting success.
  (when (and (or (table? pose) (struct? pose))
               (or (array? (pose :pos)) (tuple? (pose :pos))))
    (def pos (pose :pos))
    (when (= 3 (length pos))
      (put (p :pos) 0 (get pos 0))
      (put (p :pos) 1 (get pos 1))
      (put (p :pos) 2 (get pos 2)))
    (when (number? (get pose :yaw false)) (put p :yaw (pose :yaw)))
    (when (number? (get pose :pitch false)) (put p :pitch (pose :pitch)))
    (when (boolean? (get pose :flying false)) (put p :flying (pose :flying))))
  p)

(defn session-identity
  ``What this session generates with, as one comparable value.

  Every load and save is gated against it, so a region can never be adopted by
  a generator that would have produced different terrain. A diffusion session
  carries the cache's opaque digest AND the seed: the digest fixes the
  generation, the seed fixes which sample of it.``
  [cache seed]
  (if cache
    (terrain-identity/diffusion-identity (cache :identity) seed)
    (terrain-identity/noise-identity seed)))

(defn decode-region-bytes
  ``Decode TRCR `bytes` into chunks, WITHOUT reading the file again.

  `region/load-region` takes a PATH and re-reads it, so calling it after
  validating a buffer means the bytes that were gated and the bytes that are
  decoded are two different reads -- a file replaced in between (or a directory
  swapped under the path) passes the identity gate on the old content and
  installs the new. `region/inspect` validates the index and
  `region/decode-chunk` decodes one payload, both over an in-memory value, so
  composing them decodes exactly the bytes the caller already checked.

  Every record is decoded before anything is returned, so the caller can still
  fail with the live world untouched.``
  [bytes]
  (def entries (region/inspect bytes))
  (def chunks @[])
  (each item entries
    (def blocks (region/decode-chunk
                  (region/slice-bytes bytes (get item :offset)
                                      (get item :length))))
    (def ch (world/chunk-new (get item :cx) (get item :cz)))
    (put ch :blocks blocks)
    (array/push chunks ch))
  chunks)

(defn save-permitted?
  ``May `path` be written by this session? Returns `[:ok]` or `[:refuse reason]`.

  Three cases, and only the middle one is subtle:

  - the file does not exist   -> `:ok`, a first save creates its own provenance
  - it exists and its sidecar -> `:ok` only on `:match`; anything else means the
    pins the same identity    bytes belong to another generation (or to none
    recorded), and overwriting them would relabel them
  - it exists with no usable -> `:refuse`, EXCEPT in one narrow case: a noise
    sidecar                      session that loaded those very bytes from that
                                 very path. Writing them back changes none of
                                 their provenance, and refusing would make a
                                 legacy world read-only. `loaded-from` carries
                                 that fact, so an unread legacy file is still
                                 protected from a blind overwrite.

  Kept separate from the save verb so the rule can be tested without a window.
  `crc` is the CRC of the bytes on disk. `unknown?` marks a session whose own
  contents have unknown provenance: it writes NO sidecar, so overwriting an
  existing path would leave that path's sidecar describing bytes that no longer
  exist (:stale) -- the region and its identity record would disagree with
  nobody left to repair them. Such a session may therefore only save where
  there is no sidecar to leave behind.``
  [region-path identity crc &opt loaded-from unknown?]
  (if (nil? (os/stat region-path))
    [:ok]
    (let [sidecar (terrain-identity/sidecar-path region-path)]
      # Unknown provenance writes no sidecar, so it must not overwrite a path
      # that HAS one: the pinned identity would survive the write and describe
      # bytes that no longer exist from that moment on. Checked before the
      # gate, because the gate can pass (:match) precisely in the case that
      # creates the staleness.
      (if (and unknown? (not (nil? (os/stat sidecar))))
        [:refuse (string "this session's contents have unknown provenance, so it"
                         " writes no identity sidecar; overwriting " region-path
                         " would leave its existing sidecar describing bytes that"
                         " no longer exist")]
        (let [decision (try (terrain-identity/gate region-path identity crc)
                            ([err] @{:status :unreadable :reason (string err)}))
              status (get decision :status)]
          (cond
            (= :match status) [:ok]
            # Same bytes this session itself read: the origin is unchanged by a
            # rewrite. No sidecar is written in this case (see the save verb),
            # so nothing is claimed either.
            (and (= :unverifiable status) (= region-path loaded-from)) [:ok]
            true [:refuse (or (get decision :reason) (string status))]))))))

(defn cursor-slice
  ``Up to `limit` indices to examine this pass, starting at `cursor`, plus the
  cursor to resume from. Wraps by modulo, so a pass near the end continues at
  the front instead of stopping.

  This is the whole anti-starvation rule, kept pure so it can be tested without
  a running game. The defect it prevents: restarting at 0 every pass means an
  already-pending coordinate is indistinguishable from a fresh one, so the same
  few entries are retried forever and the tail is never reached. Rotating makes
  `ceil(count / limit)` passes cover every index exactly once.``
  [count cursor limit]
  (when (pos? count)
    (def take (max 0 (min limit count)))
    (def indices @[])
    (for offset 0 take
      (array/push indices (mod (+ cursor offset) count)))
    [indices (mod (+ cursor take) count)]))

(defn wanted-key-set
  ``Membership set of a `chunks-in-radius` result, keyed by chunk coordinate.

  Rebuilt from the cached wanted list rather than from the world, because the
  question a resolved tile must answer is "does the player still want this",
  not "does some chunk have this coordinate". Interning through
  `world/chunk-key` keeps the tuples value-compared, as everywhere else.``
  [wanted]
  (def set @{})
  (each e wanted (put set (world/chunk-key (e 0) (e 1)) true))
  set)

(defn capture-required-keys
  ``The distinct chunk keys a capture must find resident before it is ready.

  `wanted` is the stream's request list, and a request list is not a promise:
  it may name coordinates OUTSIDE a finite map's bounds, or the same coordinate
  twice. Either would corrupt a readiness test in a different direction -- an
  out-of-bounds entry can never be resident, so demanding it turns "the map is
  loaded" into a guaranteed timeout, while a duplicate inflates the required
  count past what any loader could supply.

  So the requirement is derived, not counted: filter to coordinates `in-bounds?`
  admits, de-duplicate by `world/chunk-key`, and return the surviving keys. An
  empty result means nothing is required, which is a state the caller must treat
  as NOT ready rather than as vacuously satisfied.``
  [wanted in-bounds?]
  (def seen @{})
  (def keys @[])
  (each e wanted
    (def cx (e 0))
    (def cz (e 1))
    (when (in-bounds? cx cz)
      (def key (world/chunk-key cx cz))
      (unless (get seen key)
        (put seen key true)
        (array/push keys key))))
  keys)

(defn capture-wanted-count
  ``How many distinct in-bounds chunks this session's resident set demands.

  The capture gate needs a number that agrees with `capture-ready?`, and the
  `scene:` line historically did not: it counted a disc around the ORIGIN, so a
  scenic run logged `wanted 797` while the loop actually wanted the map's whole
  1024-chunk rectangle. Two `wanted` numbers in one log, contradicting each
  other, is how a correct gate gets read as a broken one. Derived through the
  same clipping as the gate, so the two can never disagree again -- and taking
  the bounds predicate explicitly for exactly the same reason, so a caller (or a
  test) says which map it is asking about instead of inheriting global state.``
  [wanted &opt in-bounds?]
  (length (capture-required-keys wanted (or in-bounds? (fn [_ _] true)))))

(defn capture-ready?
  ``Is the resident set actually on screen, so a screenshot would show terrain
  rather than a hole?

  Counts alone cannot answer this, and that is the defect this exists to close.
  The 1700-frame valley capture reported `loaded 1024  wanted 797` and still
  photographed gaps, because "loaded" counts chunks in the world map while a hole
  is a chunk that is loaded but NOT YET MESHED -- and because a count comparison
  cannot tell a wanted coordinate that is resident from one that is not. So the
  decision is MEMBERSHIP over `wanted`: every wanted coordinate must be present in
  the world, and the mesh queue must be empty.

  `loaded`/`dirty-count` are accepted, but only as a cheap lower-bound reject
  before the membership walk: a dirty queue is never ready, and world chunk count
  below the required count cannot possibly contain them all.

  Clipping is intrinsic, not the caller's job. The requirement is
  `capture-required-keys`, which drops out-of-bounds coordinates and duplicates,
  so a request list that names terrain this map does not have cannot turn "the
  map is fully loaded" into a guaranteed timeout. An EMPTY requirement is
  refused rather than vacuously satisfied -- "there is nothing to show" is a
  session that has not decided what it wants, and photographing it would produce
  exactly the empty frame the frame-count guess produced.

  An empty queue plus a fully loaded map is the strongest statement available
  here, and it is sufficient: every loaded key was meshed by `upload-chunk-all`
  when it was drained, and a chunk with no faces legitimately has no drawable.
  Holes therefore cannot survive a drained queue.

  Kept pure, taking the world's chunk MAP rather than a live world, so it is
  testable without a window, a GPU or a running game. The bounds predicate is an
  explicit argument for the same reason: it used to be read from the module-level
  `scenic-cache`, which meant a session's answer depended on global state the
  caller never passed and a test could not control. A world with no map passes a
  predicate that is always true.``
  [chunks wanted loaded dirty-count &opt in-bounds?]
  (def inside (or in-bounds? (fn [_ _] true)))
  (def required (capture-required-keys wanted inside))
  (and (number? loaded)
       (number? dirty-count)
       (zero? dirty-count)
       (pos? (length required))
       (>= loaded (length required))
       (every? (map |(not (nil? (get chunks $))) required))))

(defn capture-loop-continues?
  ``Should the frame loop keep running, given what the frame bound and the
  capture gate each want?

  Three rules, in the order they bind:

  1. An unbounded session (`bound` nil) runs until the window closes.
  2. Below the bound, every session runs -- this is the historical behaviour and
     it is what every existing 90-frame capture and benchmark relies on.
  3. AT OR PAST the bound only a pending `--capture-ready` capture continues,
     and only while it has neither shot nor timed out.

  Rule 3 is the whole safety story. Turning a frame bound into a floor is exactly
  the kind of change that produces a CI job that never returns, so the floor is
  scoped to the one mode that asked for it and is terminated by two independent
  conditions: `done` (the PNG was written) and `failed` (the wall clock expired).
  A capture that is neither done nor failed keeps going -- that is the point --
  but it cannot reach that state without `armed`, which is only true when the
  flag was given. Kept pure and free of clock reads so the policy is testable
  without a window: the caller owns the deadline.``
  [bound frame armed done failed]
  (cond
    (nil? bound) true
    (< frame bound) true
    (and armed (not done) (not failed)) true
    false))

(defn footprint-loaded?
  ``Would a player box centred on `(x, z)` stand entirely over loaded chunks?

  The collision footprint is the player's half-width on X and Z; heights are
  irrelevant, because a loaded column is loaded for every Y. All four corners
  AND the centre are tested: a body straddling a corner can be inside four
  chunks at once, and checking only the centre lets the box hang over an
  unloaded diagonal neighbour -- a hole the player then falls through.

  This is the void guard's decision, kept pure so it can be tested without a
  window: the frame loop snapshots the position, steps physics, and restores
  the snapshot when this returns false.``
  [w x z]
  (def loaded? (fn [wx wz]
                 (not (nil? (world/world-get-chunk
                              w (world/world-to-chunk-coord wx)
                              (world/world-to-chunk-coord wz))))))
  (def x0 (- x player/half-width))
  (def x1 (+ x player/half-width))
  (def z0 (- z player/half-width))
  (def z1 (+ z player/half-width))
  (var ok true)
  (each [px pz] [[x0 z0] [x1 z0] [x0 z1] [x1 z1] [x z]]
    (unless (loaded? px pz) (set ok false)))
  ok)

(defn build-world
  ``Generate only the spawn area up front. Everything else streams in, so
  startup no longer scales with view distance -- the old behaviour generated
  the entire view volume before the first frame, which is why raising the
  radius used to mean a multi-second freeze.

  Diffusion sessions fill the same spawn area from baked tiles instead of the
  procedural generator; preflight has already proved all 25 tiles are present
  and decodable, so this loop cannot miss.``
  []
  (def w (world/world-new))
  (put w :seed seed)
  (def t0 (os/clock))
  (each coord (spawn-tile-coords)
    (def cx (coord 0))
    (def cz (coord 1))
    (if terrain-cache
      (generate-chunk-from-cache w terrain-cache cx cz)
      (gen-chunk-world! w cx cz seed)))
  (timing-printf "worldgen: %d spawn chunks in %.0f ms%s"
          (world/world-chunk-count w) (* 1000 (- (os/clock) t0))
          (if terrain-cache " (tile cache)" ""))
  w)

(defn upload-chunk
  ``Mesh one chunk and hand it to the GPU, replacing any mesh it already had.
  Returns the drawable, or nil when the chunk has no visible geometry.``
  [m w ch]
  (def geo (mesher/mesh-chunk m ch w atlas/face-uv))
  # Invalidate the old handle. GPU release is disabled by default pending
  # investigation of the existing UnloadMesh invalid-free crash.
  (when (ch :mesh)
    (rl/mesh-unload (ch :mesh))
    (put ch :mesh nil))
  (put ch :dirty false)
  (when geo
    (def mesh (rl/mesh-pack (get geo :vertex-count) (get geo :triangle-count)
                            (get geo :verts) (get geo :uvs)
                            (get geo :norms) (get geo :idxs)
                            (get geo :colors)))
    (rl/mesh-upload mesh)
    (when (rl/mesh-uploaded? mesh)
      (put ch :mesh mesh))))

(defn- upload-water [m w ch]
  (def geo (mesher/mesh-water m ch w atlas/face-uv))
  (when (ch :water-mesh)
    (rl/mesh-unload (ch :water-mesh))
    (put ch :water-mesh nil))
  (when geo
    (def mesh (rl/mesh-pack (get geo :vertex-count) (get geo :triangle-count)
                            (get geo :verts) (get geo :uvs)
                            (get geo :norms) (get geo :idxs)
                            (get geo :colors)))
    (rl/mesh-upload mesh)
    (when (rl/mesh-uploaded? mesh) (put ch :water-mesh mesh))))

(defn upload-chunk-all
  ``Mesh a chunk into its opaque and translucent halves and return a
  drawable, or nil when it has no geometry at all.``
  [m w ch]
  (upload-chunk m w ch)
  (upload-water m w ch)
  (put ch :dirty false)
  (when (or (ch :mesh) (ch :water-mesh))
    @{:mesh (ch :mesh)
      :water (ch :water-mesh)
      :chunk ch
      :xform (rl/translation-matrix (* (get ch :cx) world/chunk-x) 0
                                    (* (get ch :cz) world/chunk-z))}))

(defn build-meshes [m w]
  ``Mesh every chunk after the whole world exists, so each sees its real
  neighbours and no interior seam faces are emitted between adjacent chunks.``
  (def drawables @{})
  (var verts 0)
  (def t0 (os/clock))
  (each ch (values (get w :chunks))
    (when-let [d (upload-chunk-all m w ch)]
      (when (d :mesh) (+= verts (get (d :mesh) :vertex-count)))
      (put drawables (world/chunk-key (ch :cx) (ch :cz)) d)))
  (timing-printf "mesher:   %d meshes, %d vertices in %.0f ms"
          (length drawables) verts (* 1000 (- (os/clock) t0)))
  drawables)

(defn mesh-one-chunk
  ``Mesh ONE chunk into `drawables` and return the drawable, or nil.

  Extracted so the interactive startup can mesh incrementally while the window
  keeps drawing, instead of blocking on a single 25-chunk pass. It is the same
  `upload-chunk-all` the batch path uses, so there is no second meshing
  routine to drift.``
  [m w drawables ch]
  (def key (world/chunk-key (ch :cx) (ch :cz)))
  (def d (upload-chunk-all m w ch))
  (put drawables key d)
  d)

(defn build-meshes-incremental
  ``Mesh every chunk `per-frame` at a time, drawing a loading frame between
  batches. Returns the drawables table.

  `build-meshes` is a single blocking pass: ~300 ms on a 25-chunk spawn area,
  during which the window exists but nothing is drawn -- the exact freeze the
  loading stage is supposed to remove. This keeps the same per-chunk work and
  the same result, but gives the event loop and the screen a frame between
  batches, so the window stays responsive and `meshes` counts only chunks that
  were really meshed.

  Chunks are taken in the world's own key order, so the pass is deterministic
  for a given world -- a QA capture is reproducible, and the count published to
  the loading screen is a fact rather than an estimate.

  Returns the number meshed, or NIL when the run was cancelled. A 1024-chunk
  preload takes seconds; refusing Esc for that long turns a responsive window into
  a hang, and quitting INTO a half-built game is worse than not starting, so the
  caller treats nil as "stop, do not enter play".

  Cancellation is OPT-IN through `cancellable?`, because it can only be honoured
  where a raylib window exists. A headless test drives this batcher with a stub
  world and no context, where `window-should-close` has nothing to answer; asking
  unconditionally stopped those passes at chunk zero. The default is therefore the
  old behaviour, and the frame loop opts in.``
  [m w drawables per-frame draw &opt cancellable?]
  (def keys (sorted (keys (get w :chunks))))
  (var done 0)
  (var cancelled false)
  (each key keys
    (when (and cancellable? (not cancelled))
      (when (or (rl/window-should-close) (rl/key-pressed? rl/key-escape))
        (set cancelled true)))
    (unless cancelled
      (when-let [ch (world/world-get-chunk w (key 0) (key 1))]
        (mesh-one-chunk m w drawables ch)
        (++ done))
      (when (and draw (zero? (% done (max 1 per-frame))))
        (draw done (length keys)))))
  (if cancelled
    nil
    (do (when draw (draw done (length keys)))
        done)))

(defn remesh-around
  ``Re-mesh the chunk containing a block, plus any neighbour that shares the
  seam it sits on. Editing a block on a chunk edge changes the neighbour's
  culling too, so re-meshing only the touched chunk leaves a visible hole or
  a stale face at the boundary.``
  [m w drawables wx wz]
  (def cx (world/world-to-chunk-coord wx))
  (def cz (world/world-to-chunk-coord wz))
  (def lx (world/world-to-local-coord wx))
  (def lz (world/world-to-local-coord wz))
  (def targets @[[cx cz]])
  (when (= lx 0) (array/push targets [(- cx 1) cz]))
  (when (= lx (- world/chunk-x 1)) (array/push targets [(+ cx 1) cz]))
  (when (= lz 0) (array/push targets [cx (- cz 1)]))
  (when (= lz (- world/chunk-z 1)) (array/push targets [cx (+ cz 1)]))
  (each t targets
    (when-let [ch (world/world-get-chunk w (get t 0) (get t 1))]
      (def key (world/chunk-key (get t 0) (get t 1)))
      (def d (upload-chunk-all m w ch))
      (if d (put drawables key d) (put drawables key nil)))))

#
# --- Input --------------------------------------------------------------
#

(defn apply-look [p]
  (def d (rl/mouse-delta))
  (put p :yaw (+ (p :yaw) (* (get d 0) look-speed)))
  (put p :pitch (- (p :pitch) (* (get d 1) look-speed)))
  # Clamp just short of vertical so the view never flips over.
  (def limit 1.55)
  (when (> (p :pitch) limit) (put p :pitch limit))
  (when (< (p :pitch) (- limit)) (put p :pitch (- limit))))

(defn movement-input [p]
  ``Desired horizontal direction in world space, from WASD relative to yaw.``
  (def yaw (p :yaw))
  (def fx (math/cos yaw))
  (def fz (math/sin yaw))
  # Right is forward rotated 90 degrees in the XZ plane.
  (def rx (- fz))
  (def rz fx)
  (var mx 0) (var mz 0)
  (when (rl/key-down? rl/key-w) (+= mx fx) (+= mz fz))
  (when (rl/key-down? rl/key-s) (-= mx fx) (-= mz fz))
  (when (rl/key-down? rl/key-d) (+= mx rx) (+= mz rz))
  (when (rl/key-down? rl/key-a) (-= mx rx) (-= mz rz))
  # Normalise so diagonals are not faster than the cardinals.
  (def len (math/sqrt (+ (* mx mx) (* mz mz))))
  (if (> len 0.0001) [(/ mx len) (/ mz len)] [0 0]))

#
# --- Main ---------------------------------------------------------------
#

#
# --- Worker process -----------------------------------------------------
#
# The backend samples tiles; this module only starts it and stops it. Liveness
# is deliberately NOT derived from reaping the process, because `:return-code`
# is populated solely by `os/proc-wait` (`src/core/os.c:1092`), and under
# JANET_EV that call SUSPENDS the calling fiber -- it hands the reap to a
# threaded job that only completes when the event loop is pumped. The game's
# frame loop never yields to `ev` (there is not a single `ev/` reference in this
# file or src/rl.janet), so `proc-wait` here would block the frame forever and a
# watcher fiber would never run. Verified with a probe: a watcher suspended on
# `proc-wait` never resumed across 40 busy iterations.
#
# So liveness is judged from the artifacts the backend publishes itself: its
# status file (identity + pid + state). `kill` is used only on the process
# object we spawned, never on a pid we merely read from a file.

(defn spawning-root
  ``Repository root, derived from the script path rather than the cwd.

  `(dyn :current-file)` is the path as invoked (`main.janet` from the repo, or
  an absolute path for the AOT image), so its directory is the root. A cwd-
  relative lookup would break the moment the game is launched from elsewhere,
  which the editor launcher does.``
  [script-path]
  (def path (or script-path "main.janet"))
  (def parts (string/split "/" path))
  (if (<= (length parts) 1)
    "."
    (string/join (array/slice parts 0 (- (length parts) 1)) "/")))

(def max-status-bytes 16384)   # the backend's own bridge cap

(defn worker-argv
  ``Command line for the backend worker over one identity directory.

  `--from-identity` takes the FULL identity directory and re-verifies every
  generation parameter from it, so the launcher cannot drift into serving a
  different cache than the game opened. Nothing else about generation is passed.

  `--owner-token` is a per-launch nonce. The child records it in its launch
  receipt, which is how this session proves a REUSED worker is the one it just
  started rather than any process whose stale status file happens to be lying
  around.``
  [root python identity-dir &opt owner-token]
  (def base @[(if (string/has-prefix? "/" python) python (string root "/" python))
              (string root "/" terrain-worker-script)
              "worker" "--from-identity" identity-dir])
  (when owner-token
    (array/push base "--owner-token")
    (array/push base owner-token))
  base)

(defn launch-token
  ``A nonce unique to one launch attempt.

  PID and clock together: the PID separates two launches in different
  processes, and the clock separates two in the same process (a cancel then a
  retry). The token only has to be unique, not unguessable -- it identifies our
  own child, it does not authorise anything.``
  []
  (string "L" (os/getpid) "-" (math/floor (* 1000000 (os/clock)))))

(defn worker-receipt-path
  ``This launch's own receipt: ``worker-launch-<token>.janet``.

  Per launch, never a shared file. Two launches racing must not overwrite each
  other's outcome, and a launcher reads only the path it named -- no directory
  scan, and nothing to collide on.``
  [identity-dir token]
  (string identity-dir "/worker-launch-" token ".janet"))

(defn read-launch-receipt
  ``This launch's receipt, or nil. Inert data, bounded read.

  The child writes it BEFORE it validates anything, so it is the only on-disk
  trace that a launch was even attempted -- and on a launch that fails early it
  is the only place the reason appears.``
  [identity-dir token]
  (def path (worker-receipt-path identity-dir token))
  (def stat (os/stat path))
  (when (and stat (<= (get stat :size) max-status-bytes))
    (def f (file/open path :rb))
    (if (nil? f)
      nil
      (do
        (def text (try (file/read f :all) ([err] nil)))
        (file/close f)
        (def r (if text (try (parse (string text)) ([err] nil)) nil))
        (if (or (table? r) (struct? r))
          @{:pid (get r :worker-pid)
            :launcher-pid (get r :launcher-pid)
            :state (get r :state)
            :identity-digest (get r :identity-digest)
            :owner-token (get r :owner-token)
            :message (get r :message)}
          nil)))))

(defn worker-status-path [identity-dir]
  (string identity-dir "/worker-status.janet"))

(defn read-worker-status
  ``The backend's own status record, or nil when there is none or unusable.

  Parsed as inert data and never evaluated. Read length is capped, because this
  runs on the frame path and a runaway file must not become a frame stall.
  Every field is treated as optional: a record written by another backend
  version must not crash a frame. Returns
  `@{:pid :state :identity-digest :completed}` or nil.``
  [identity-dir]
  (def path (worker-status-path identity-dir))
  (def stat (os/stat path))
  (when (and stat (<= (get stat :size) max-status-bytes))
    (def f (file/open path :rb))
    (if (nil? f)
      nil
      (do
        (def text (try (file/read f :all) ([err] nil)))
        (file/close f)
        (def r (if text (try (parse (string text)) ([err] nil)) nil))
        (if (or (table? r) (struct? r))
          @{:pid (get r :pid)
            :state (get r :state)
            :identity-digest (get r :identity-digest)
            :completed (get r :completed 0)}
          nil)))))

(defn live-worker-status
  ``Did THIS launch end up with a worker serving the cache? Returns
  `@{:pid :state :reused}` or nil.

  The receipt is the authority, not the status file. A status record with a
  positive pid proves nothing -- the backend writes `:idle` on its way out, so a
  stale record from a previous session is indistinguishable from a running one.

  Crucially, `:worker-pid` in the receipt is the pid that actually SERVES, which
  on a contention loss is the EXISTING OWNER, not the child this launch spawned.
  Comparing the child's own pid against the status record could therefore never
  succeed when a second launch found a live worker already running -- so the
  receipt's worker pid is what is compared, and the receipt must name our token
  and our identity.

  Receipt states: `:started` and `:reused` mean a worker is serving; `:launched`
  means the child is up but has not acquired the cache yet; `:failed` means this
  launch produced nothing, and its `:message` is the reason.``
  [identity-dir identity token]
  (def receipt (read-launch-receipt identity-dir token))
  (when (and receipt
             token
             (= token (receipt :owner-token))
             (= identity (receipt :identity-digest))
             (number? (receipt :pid))
             (pos? (receipt :pid)))
    (case (receipt :state)
      :started @{:pid (receipt :pid) :state :started :reused false}
      :reused @{:pid (receipt :pid) :state :reused :reused true}
      # The child is up but has not reported owning the cache yet. That is not
      # a failure; the await loop keeps watching the receipt.
      :launched @{:pid (receipt :pid) :state :launched :reused false}
      nil)))

(defn launch-failed-reason
  ``If this launch reported `:failed`, the actionable reason; otherwise nil.

  This is how an early backend failure -- a rejected identity, a missing
  sampler, a lost lock with no owner -- reaches the loading screen instead of
  becoming an indefinite wait on a cache nobody is filling.``
  [identity-dir identity token]
  (def receipt (read-launch-receipt identity-dir token))
  (when (and receipt
             (= token (receipt :owner-token))
             (= identity (receipt :identity-digest))
             (= :failed (receipt :state)))
    (or (get receipt :message) "the terrain worker reported a failure")))

(defn worker-start
  ``Spawn the backend for `identity-dir`, or return a reason it could not.

  Returns `@{:process p :argv argv}` on success or `@{:error reason}`. The
  caller owns the process and must `worker-stop` it; nothing here waits.
  `os/spawn` is asked for no pipes: the worker writes files and a status
  record, and a pipe nobody drains would eventually block the child.``
  [root python identity-dir &opt owner-token]
  (def argv (worker-argv root python identity-dir owner-token))
  (def python-path (get argv 0))
  (cond
    (nil? (os/stat python-path))
    @{:error (string "no worker interpreter at " python-path
                     " (pass --terrain-python to override)")}

    (nil? (os/stat (get argv 1)))
    @{:error (string "no terrain backend script at " (get argv 1))}

    true
    (let [r (try [true (os/spawn argv :p)]
                 ([err] [false (string err)]))]
      (if (get r 0)
        @{:process (get r 1) :argv argv}
        @{:error (get r 1)}))))

(def default-stop-grace-ms 1000)

(defn worker-stop
  ``Stop a worker THIS session spawned, giving it a real chance to exit.

  The backend's SIGTERM handler only sets a flag it checks between indivisible
  inference queries, and its `finally` releases the advisory locks and closes
  the sampler. Sending TERM and SIGKILL back to back therefore defeats the
  whole graceful path: it can interrupt a tile mid-write and skip cleanup. This
  waits `grace-ms` first.

  That wait is NOT a blocking `proc-wait`. It pumps the window event loop
  (`rl/window-should-close` + `get-frame-time`) so the window stays alive, and
  it bounds the whole thing to `grace-ms` -- roughly one second by default --
  so a wedged child costs a predictable delay rather than a hang. A cancelled
  or failed load uses a shorter grace because the user is already waiting to
  get out.

  Sequence: TERM, bounded pump, KILL, reap, close. Reaping matters because a
  killed child otherwise sits in state `Z` and KEEPS ITS PID -- measured with
  `/bin/ps -o stat`, which is exactly what "child PID exists after stop" sees.
  Waiting on an ALREADY-KILLED child returns in tens of microseconds, so the
  reap after the kill is cheap; it is waiting on a LIVE child that would
  suspend, which is why the loop above is a timed pump instead.

  Returns the worker table: `:reaped` records the reap, `:graceful` whether the
  child exited during its grace period.``
  [worker &opt grace-ms]
  (when (and worker (worker :process))
    (def p (worker :process))
    (def grace (or grace-ms default-stop-grace-ms))
    # Whether the child ever published a status decides if its disappearance
    # can be read as "exited cleanly".
    (when (worker :dir)
      (put worker :had-status? (not (nil? (read-worker-status (worker :dir))))))
    (try (os/proc-kill p false :term) ([err] nil))
    # Timed, event-pumping grace. Bounded in time, not in iterations, so a slow
    # frame cannot stretch it into a long stall.
    (var graceful false)
    (when (pos? grace)
      (def deadline (+ (os/clock) (/ grace 1000)))
      # `rl/window-should-close` is true when NO window exists either (verified:
      # it reports true headless), so it must only be consulted while there is
      # one -- otherwise a headless stop would skip its grace entirely.
      (while (and (not graceful) (< (os/clock) deadline)
                  (not (and (rl/window-ready?) (rl/window-should-close))))
        # A real sleep, not a spin on the frame clock. Spinning here would burn
        # a core and -- measured -- returned in under a tenth of a millisecond,
        # giving the child no grace at all. The window is pumped by the caller's
        # next frame; this wait only has to be short and bounded.
        (os/sleep 0.01)
        # The status record is removed on a clean exit, so its disappearance is
        # the cheapest observable "it finished" signal. Only meaningful when the
        # child ever published one: with no status file at all we cannot know,
        # so the full grace is always spent rather than declaring success on the
        # absence of a file that was never going to exist. The PID probe is
        # deliberately NOT used -- signalling a stranger is worse than waiting.
        (def dir (worker :dir))
        (when (and dir (worker :had-status?))
          (when (nil? (read-worker-status dir))
            (set graceful true)))))
    (put worker :graceful graceful)
    # Whatever happened, the child must not survive: SIGKILL, then reap.
    (try (os/proc-kill p false :kill) ([err] (try (os/proc-kill p) ([e2] nil))))
    (put worker :reaped (try (do (os/proc-wait p) true) ([err] false)))
    (try (os/proc-close p) ([err] nil))
    (put worker :process nil)
    (put worker :stopped true))
  worker)

#
# --- Loading frame driver ----------------------------------------------
#
# Renders the loading stage. Every frame here is a real frame: `begin-drawing`,
# text and `end-drawing` need no material, atlas or shader, which is what lets
# the window appear before any asset work has happened.

# Unsigned bytes, matching rl's color-type: the fog colour, so the loading
# screen and the world it becomes do not flash between two different blues.
(def loading-bg [8 43 66 255])

(defn no-autolaunch?
  ``Is this session NOT starting a worker itself?

  A one-line indirection so the wording follows a single source of truth and can
  be overridden by the model for tests.``
  [&opt override]
  (if (nil? override) no-terrain-worker (truthy? override)))

(defn loading-lines [st]
  (def line (loading-progress-text st))
  (case (st :state)
    :probe ["checking the terrain cache" line]
    :await [(if (no-autolaunch?)
              "waiting for external worker"
              "waiting for the terrain worker") line]
    :build-world ["building the world" line]
    :find-spawn ["finding dry land" line]
    :build-meshes ["meshing the world" line]
    :ready ["ready" line]
    (if-let [why (loading-describe st)] ["loading failed" line why] [line])))

(defn loading-hint [st]
  (case (st :state)
    :failed (string (loading-describe st)
                    "  --  press Esc to quit, or rebake this identity and relaunch")
    :cancelled "cancelled -- press Esc to quit"
    :timed-out "timed out -- press Esc to quit, or rebake this identity and relaunch"
    "Esc quits"))

(defn loading-view
  ``The presentation model `loading-screen/draw` consumes.

  Only facts the stage actually has: the state as `:stage`, a short human
  `:detail`, the validated count out of the spawn total, and the mesh count
  once meshing has really happened. A stage with no counts reports none --
  `loading-screen` renders a missing count as absent rather than as zero, and
  that distinction is the point.

  `:error` is set only from the stage's own terminal reason, so a failure block
  can never appear for a merely slow load.``
  [st &opt external-override]
  (def external? (no-autolaunch? external-override))
  (def view @{:stage (st :state)
              :total (st :total)
              :ready (loading-ready-count st)})
  (def detail
    (case (st :state)
      :await
      (let [pending (loading-pending-count st)]
        # With autolaunch disabled the game is NOT generating anything -- it is
        # waiting for something else to. Saying "generating" there would claim
        # work this process never started, so the wording follows who is
        # actually responsible.
        (if external?
          (string "waiting for an external worker ("
                  pending "/" (st :total) " requested)")
          (string pending " requested")))
      :build-world (string (st :worlds) "/" (st :total) " chunks")
      :find-spawn (string "searching " (or (st :spawn-examined) 0) " columns")
      # Meshing runs after the stage; report it only once it has begun, so the
      # screen never shows a meshing count of zero as if it were progress.
      :build-meshes (if (pos? (st :meshes))
                      (string (st :meshes) "/" (st :total) " chunks") nil)
      :ready (if (pos? (st :meshes))
               (string (st :meshes) "/" (st :total) " chunks") "world ready")
      nil))
  (when detail (put view :detail detail))
  (when (= :failed (st :state))
    (put view :error (or (loading-describe st) "the terrain could not be prepared")))
  view)


(defn loading-frame!
  ``Run one loading frame, but ONLY when the GPU context is actually usable.

  `BeginDrawing` on a window that never initialised does not fail politely: it
  dereferences raylib's context and takes the process down with a null access on
  the main thread, several frames into startup, where nothing in the log says
  "the window failed". The first frame of a launch is drawn by the readiness
  probe pump, so a display-less or GL-refused launch crashed before the code that
  could have reported the real problem.

  Readiness is ASKED, never assumed, and it is checked BEFORE `begin` runs. When
  it is false this is a refusal, not a silent no-op: it returns false and calls
  NONE of `begin`, `draw` or `end`, so a caller can fail startup honestly instead
  of spinning on frames that cannot exist.

  Taking the four functions as arguments rather than reading `rl` directly is
  what makes the guard testable without a GPU: a test injects a readiness that
  is false and spies that must stay untouched.``
  [ready? begin draw end]
  (if (ready?)
    (do (begin) (draw) (end) true)
    false))

(defn require-ready-window!
  ``Fail the launch, ONCE, at the moment the window should have opened.

  Called immediately after `InitWindow`, before the target FPS, the artwork, the
  readiness probe or any asset work. Without it a failed window is discovered
  later as a null dereference inside `BeginDrawing`, which reads like a renderer
  bug and hides the actual cause -- no display, no GL, or a driver that refused
  the context.

  The message names what failed and what did NOT happen ("Nothing was generated
  and no world was loaded"), so a crash report is actionable on its own.``
  [ready?]
  (when (not (ready?))
    (error (string "window initialization failed: the GPU context could not be"
                   " created (no display, or GLFW/OpenGL refused the context)."
                   " Nothing was generated and no world was loaded."))))

(defn draw-loading-screen
  ``Draw one loading frame through the presentation module.

  `screen` may be nil (a session that has not constructed one yet), in which
  case a minimal fallback is drawn so the window is never blank. This is the
  only place `loading-screen/draw` is called, so the begin/end pair stays owned
  here: the screen is documented to draw INSIDE an existing frame.

  EVERY call sits inside the guarded frame -- the clear, the size query and the
  screen draw, not just the paint -- so a closed or never-opened window reaches
  `BeginDrawing` zero times. Returns whether a frame was actually drawn.``
  [screen view]
  (loading-frame!
    rl/window-ready?
    rl/begin-drawing
    (fn []
      (rl/clear-background loading-bg)
      (def width (rl/screen-width))
      (def height (rl/screen-height))
      (if screen
        (loading-screen/draw screen view width height)
        # Fallback: no presentation module available. Keep the frame truthful
        # rather than painting a decorative shell over nothing.
        (do (rl/draw-text "Trinecraft" 40 60 30 rl/white)
            (rl/draw-text (or (get view :detail) "") 40 130 20 rl/white))))
    rl/end-drawing))

(defn generation-progress-label
  ``A human label for the LAST progress record, or nil.

  The provider writes append-only JSON lines and reports only stages it REACHED --
  there is no percentage, because a fraction of an unknown cost is a fabricated
  number. This reads the stage name out of the last line and never synthesises a
  count it was not given.

  Deliberately a SCAN rather than a JSON decode: this repository has no JSON
  parser (the cache layer validates JSON bytes by CRC instead of parsing them), and
  adding one to show a status line would be a large dependency for a small label.
  The record shape is fixed and machine-written, so finding `"stage":"<name>"` and
  an optional `"message":"<text>"` is enough -- and if the shape ever changes, the
  label degrades to nil rather than lying.``
  [text]
  (when (and (string? text) (pos? (length text)))
    (defn last-line []
      (var found nil)
      (each line (string/split "\n" text)
        (def trimmed (string/trim line))
        (when (pos? (length trimmed)) (set found trimmed)))
      found)
    (defn field [line name]
      (def needle (string "\"" name "\":\""))
      (def at (string/find needle line))
      (when at
        (def start (+ at (length needle)))
        (def stop (string/find "\"" line start))
        (when (and stop (> stop start)) (string/slice line start stop))))
    (def line (last-line))
    (when line (or (field line "message") (field line "stage")))))

(defn generation-argv
  ``The exact argv for one generation run.

  Extracted so a test can assert the SEED it carries without spawning anything.
  `world-seed` here is the world seed the player chose -- the provider maps world
  seed 0 to a model seed itself, so a caller that pre-mapped would map twice and
  lose the original.``
  [python script out-root settings world-seed progress-path]
  (def argv @[python "-u" script "--out" out-root
              "--seed" (string world-seed)
              "--size" (string (settings :size))
              "--sea-level" (string (settings :sea-level))
              "--profile" (settings :profile) "--progress" progress-path])
  (when-let [device (arg-value "--terrain-device")]
    (assert (some |(= device $) ["cpu" "mps" "cuda"]) "unsupported terrain device")
    (array/push argv "--device" device))
  argv)

(defn generated-artifact-directory
  "Find exactly one completed identity directory; catalogue inspection validates it."
  [root]
  (def found @[])
  (each name (os/dir root)
    (var valid (= 64 (length name)))
    (for i 0 (length name)
      (unless (string/find (string/from-bytes (get name i)) "0123456789abcdef")
        (set valid false)))
    (when valid (array/push found (string root "/" name))))
  (assert (= 1 (length found)) "generation must produce exactly one artifact")
  (first found))

(defn run-python-generation
  ``Own, display and collect one temporary Python generation; never substitute
  terrain.

  `draw` and `cancel-pressed?` are PARAMETERS, not direct raylib calls, so this
  loop can be driven headless with a fake provider. A generation loop that could
  only run with a GPU was untestable, and the one thing worth testing -- that it
  owns and reaps exactly one child -- is not a graphics question.

  Returns `@{:ok true :out <identity-dir> :metadata m}` on a verified artifact,
  `[:cancelled]` when the player left, or `[:failed reason]` otherwise.``
  [settings world-seed out-root script python &opt draw cancel-pressed?]
  (def progress-path (string out-root "/stage.janet"))
  # The WORLD seed goes on the command line. The provider performs the world->model
  # mapping itself, so passing a pre-mapped value would map twice and lose the
  # original -- which is exactly how seed 0 stops being reproducible.
  (def argv (generation-argv python script out-root settings world-seed
                             progress-path))
  (var artifact nil)
  (def slot generation-slot)
  (def job
    (generation-job/start
      (string "generate " (or world-name "world")) argv
      {:slot slot :progress-path progress-path
       :validate (fn [owned]
                   (def directory (generated-artifact-directory out-root))
                   (def metadata (catalog/inspect-artifact directory world-seed))
                   (set artifact @{:out directory :metadata metadata})
                   true)}))
  (printf "generation: owned Python PID=%v" (job :pid))
  (var outcome nil)
  (var frame 0)
  # Set once when the player asks to leave, so the cancel signal is sent ONE time
  # and the loop then polls through `:cancelling` until the child is reaped.
  (var cancel-requested false)
  (def attempted
    (protect
      (while (nil? outcome)
        (def current (generation-job/poll job))
        (def progress (current :progress))
        (when draw
          (draw @{:stage :generating
                  :detail (or (get progress :message)
                              (when (get progress :stage)
                                (string (get progress :stage)))
                              "starting the model")
                  :hint "Esc cancels   one Python process"}))
        (++ frame)
        (cond
          (= :succeeded (current :phase))
          (set outcome @{:ok true :out (artifact :out) :metadata (artifact :metadata)})
          (= :cancelled (current :phase)) (set outcome [:cancelled])
          (= :failed (current :phase))
          (set outcome [:failed (or (current :error) "generation failed")])
          # Esc or a closed window asks to leave, but `cancel` only SENDS TERM:
          # the child keeps running until the watcher reaps it, and the slot is
          # released by that watcher. Exiting here would abandon an owned process
          # mid-generation, so cancellation is REQUESTED and the loop keeps
          # polling through the `:cancelling` phase until the job reports a
          # terminal state.
          (and cancel-pressed? (cancel-pressed?))
          (do (unless cancel-requested
                (set cancel-requested true)
                (generation-job/cancel job)))
          # Cancelling still counts toward the QA frame budget: a cancel that
          # never completes is a hung child, and the budget is what turns that
          # into a reportable failure instead of a frozen window.
          (and generation-frame-budget (= :cancelling (current :phase))
               (>= frame generation-frame-budget))
          (set outcome [:failed "cancellation did not complete in the frame budget"])
          (and generation-frame-budget (>= frame generation-frame-budget))
          (do (generation-job/cancel job)
              (set outcome [:failed "generation exceeded its QA frame budget"]))
          nil))))
  # Cleanup runs even if rendering, progress parsing or artifact validation throws.
  (def closed (protect (generation-job/close job)))
  (cond
    (not (get closed 0)) [:failed (string "generation cleanup failed: " (get closed 1))]
    (not (get attempted 0)) [:failed (string (get attempted 1))]
    outcome outcome
    [:failed "generation ended without a result"]))

(defn draw-meshing-frame
  ``Draw one frame while meshing the spawn chunks.

  Its own model rather than a whole stage, because meshing runs AFTER the stage
  has settled: reporting it through `:stage` would claim the load is still
  progressing when it is finished. The count shown is chunks actually meshed.``
  [screen done total]
  (draw-loading-screen screen
                      @{:stage :meshing
                        :detail (string done "/" total " chunks")
                        :total total
                        :ready total
                        :mesh-ready done
                        :hint "Esc quits"}))

(defn draw-loading-frame
  ``Draw one loading frame from a stage, with an explicit hint line.

  Kept as the narrow entry the stage uses; `:hint` is passed through the model
  so the presentation module can render it, and the text-only path stays
  available if no screen exists.``
  [screen st]
  (def view (loading-view st))
  (when-let [hint (loading-hint st)] (put view :hint hint))
  (draw-loading-screen screen view))


(defn loading-stage
  ``Run the interactive loading stage and return a playable world.

  Bounded work per frame in every phase: 4 tile probes, at most 25 requests,
  one poll, then 2 chunks of generation and 1 of meshing. Each frame is drawn,
  so the window stays responsive and Esc is honoured throughout. Returns the
  world; on failure, cancellation or timeout it exits the process explicitly
  rather than falling through into a half-built game.

  The presenter is PASSED IN, not built here. The front door shows the same
  artwork before this stage runs, and two instances would mean two decodes, two
  slideshow clocks and a visible jump at the handoff -- the art would restart
  exactly when it should look continuous. nil is legal and means the text
  fallback, which is what a machine with no art gets.
  `` [&opt screen]
  (def coords (spawn-tile-coords))
  (def st (loading-new terrain-cache coords))
  (def w (world/world-new))
  (put w :seed seed)
  (def loaded @{})              # actual tile heights, used by :await batch path

  # Worker ownership. A live worker for this identity is reused and never
  # killed; one we spawn is ours to stop, on exit or on cancel.
  (def identity (terrain-cache :identity))
  (def root (spawning-root (dyn :current-file)))   # worker launch root

  # The presenter is OWNED BY MAIN and arrives as an argument. Building it here
  # split one slideshow into two -- two decodes, two clocks, and a jump at the
  # handoff -- and disposing it here would destroy textures the menu was still
  # drawing with.
  (put st :screen screen)
  (def worker @{:process nil :spawned false :error nil})
  (var started-worker? false)

  (defn maybe-start-worker []
    (unless started-worker?
      (set started-worker? true)
      (cond
        # A scenic map is a COMPLETE offline artifact: there is nothing to bake
        # and nothing to ask. Starting a backend for it would contradict the one
        # guarantee the product makes -- that the map on disk is the whole map.
        (truthy? scenic-opts)
        (print "terrain: scenic map is finite and complete; no worker is started")
        no-terrain-worker
        (print "terrain: --no-terrain-worker, so no worker is started")
        # A session whose map was produced by the Python provider already has its
        # whole artifact on disk and one producer answered for it. Starting a
        # worker would be a second producer racing a finished answer.
        generated-cache?
        (print "terrain: generated map is complete; no worker is started")
        # A configured world generates on the provider path in this process. The
        # worker knows nothing about these settings, so letting it stream chunks
        # would put two terrains in one landscape.
        world-settings
        (printf "terrain: custom world settings active; generating in-process")
        true
        (do
          # ALWAYS launch. A status file with a positive pid is not evidence of
          # a live worker: the backend writes :idle on its way out, so a stale
          # record from a previous session is indistinguishable from a running
          # one, and trusting it would suppress this launch and wait forever.
          # The child writes a receipt carrying OUR per-launch token, so reuse
          # is confirmed by that token rather than inferred from a pid.
          (def token (launch-token))
          (def started (worker-start root terrain-python terrain-cache-dir token))
          (if (get started :error)
            (do
              # A launch that never happened is not a slow load. With no worker
              # and no external publisher nothing will ever produce the tiles,
              # so the stage fails immediately with the real reason rather than
              # waiting on a screen that can only ever say "0 ready". An
              # external publisher is a supported setup, so this is reported as
              # the reason the LAUNCH failed, not as a fatal terrain error.
              (put worker :error (get started :error))
              (loading-fail
                st
                (string "could not start the terrain worker: " (get started :error)
                        ". Either install it, pass --terrain-python, or run an"
                        " external publisher for this identity, then relaunch.")))
            (do
              (put worker :process (get started :process))
              (put worker :dir terrain-cache-dir)
              (put worker :token token)
              (put worker :spawned true)
              (def adopted (live-worker-status terrain-cache-dir identity token))
              (if adopted
                (do
                  (put worker :state (adopted :state))
                  # A confirmed worker means this launch SUCCEEDED. Recording
                  # that separately matters because the receipt can later be
                  # removed by the child on a clean exit -- and a missing
                  # receipt must not then be read as "the launch failed".
                  (put worker :confirmed true)
                  (printf "terrain: worker serving (pid %d, %s)"
                          (adopted :pid) (adopted :state)))
                # The receipt is written before validation, so its absence just
                # means the child has not reached that point yet. The await loop
                # keeps reading it, and fails the stage if it reports :failed.
                (put worker :state :started))))))))

  # Bounded probe: at most 4 tiles per frame, and only tiles not already known.
  (defn probe [cx cz]
    (def key (loading-key cx cz))
    (def cached (get loaded key))
    (if cached
      [:ready cached]
      (spawn-tile-status terrain-cache cx cz)))

  # Requests are re-published periodically, not once. `request` is idempotent
  # (one marker per coordinate), so re-issuing costs a stat and nothing else --
  # but doing it only once means a worker that becomes ready AFTER the first
  # pass is never told what is missing, and a marker consumed by an earlier
  # session is never replaced. Every `request-every-frames` loading frames is
  # enough to cover a slow launch without spending filesystem time each frame.
  (def request-every-frames 30)
  (var last-request-frame -1000000)
  (defn ensure-requested [force?]
    (maybe-start-worker)
    (when (or force?
              (>= (- (st :frame) last-request-frame) request-every-frames))
      (set last-request-frame (st :frame))
      (each coord (loading-needs st)
        (def key (loading-key (coord 0) (coord 1)))
        (def outcome (try (request-tile! terrain-cache (coord 0) (coord 1))
                          ([err] :error)))
        # `:requested` and `:suppressed` both mean the cache now knows about
        # this coordinate -- suppressed is an EXISTING marker from an earlier
        # session, which is still a live request. `:queued` (capacity full) and
        # `:error` are NOT on the queue, so they must not be counted: the
        # screen would then claim work that no worker was ever told about.
        (if (or (= :requested outcome) (= :suppressed outcome))
          (put (st :pending) key true)
          (put (st :pending) key nil)))))

  (defn build-one [cx cz heights]
    (put loaded (loading-key cx cz) heights)
    (def ch (world/chunk-new cx cz))
    (fill-tile-into! (ch :blocks) cx cz heights)
    (world/world-put-chunk w ch))

  # Meshing needs the mesher and atlas materials, which arrive later in startup
  # (they need a live GL context). The loading stage therefore stops after
  # :build-world and hands a completed world back; meshing then proceeds through
  # the normal budgeted stream path rather than a blocking 25-at-once pass.
  # Capture target, cleared once taken so one screenshot means one file.
  (var pending-shot loading-screenshot)
  (var last-state nil)
  (var quit-loading false)

  # `--loading-frames` is the precise cap and always wins.
  #
  # `--frames` must NOT cap loading: it counts GAMEPLAY frames, and borrowing it
  # here would abort a real 100-second model query after 90 frames -- exactly
  # the failure the opt-in was meant to avoid.
  #
  # No automatic deadline: slow inference may take minutes. Only explicit QA
  # flags cap loading; --frames remains a separate gameplay-only budget.
  (def loading-frame-cap (loading-budget-from-frames loading-frames-arg headless-frames))
  (def loading-timeout-effective (loading-timeout-for headless-frames loading-timeout-arg))
  (def loading-started-at (os/clock))
  (defn still-loading? []
    (if loading-frame-cap
      (< (st :frame) loading-frame-cap)
      (not (loading-terminal? st))))
  (while (and (not quit-loading) (still-loading?))
    (when (or (rl/window-should-close) (rl/key-pressed? rl/key-escape))
      (loading-cancel st)
      (set quit-loading true))
    (unless quit-loading
      (def dt (rl/get-frame-time))
      (case (st :state)
        :probe
        (do
          (loading-step-probe st probe 4)
          (when (zero? (loading-outstanding st))
            (loading-enter st :build-world))
          (when (and (pos? (loading-outstanding st))
                     (>= (length (st :probed)) (st :total))
                     (zero? (loading-pending-count st)))
            (loading-enter st :await)))

        :await
        (do
          # A finite scenic map has no backend at all, so waiting here would wait
          # forever: no worker is started, no marker is written, and the missing
          # tiles can never arrive. The honest outcome is a failure that says the
          # artifact is incomplete -- there is nothing to retry and nobody to ask.
          # This is reported once, on the first await frame that finds the ring
          # short, rather than left to a timeout that would blame the operator.
          (if scenic-opts
            (when (pos? (loading-outstanding st))
              (def missing (map (fn [c] (string "(" (c 0) "," (c 1) ")"))
                                (loading-needs st)))
              (loading-fail
                st
                (string "scenic map " (terrain-cache :dir) " is missing "
                        (loading-outstanding st) " of " (st :total)
                        " required tiles: "
                        (string/join (array/slice missing 0
                                                  (min 8 (length missing))) " ")
                        ". A scenic artifact is a complete offline map, so no"
                        " worker can produce these: re-run the scenic importer for"
                        " this identity, then relaunch. (No procedural fallback is"
                        " used: noise terrain would silently contradict the map.)")))
            (ensure-requested false))
          # An early backend failure (rejected identity, missing sampler, lost
          # lock with no owner) leaves no tile and no process to observe. The
          # receipt is the only trace, so the await loop reads it: without this
          # the stage would wait out the entire session on a cache nobody is
          # filling. Only OUR token's receipt is consulted.
          # Only a launch that NEVER confirmed a worker can fail the stage this
          # way. Once a worker was serving, a vanished receipt means it exited
          # cleanly, not that the launch was bad.
          (when (and (worker :token)
                     (not (worker :confirmed))
                     (nil? (worker :failure-reported?)))
            (when-let [reason (launch-failed-reason terrain-cache-dir identity
                                                   (worker :token))]
              (put worker :failure-reported? true)
              (loading-fail st (string "the terrain worker failed to start: "
                                       reason))))
          # Collect whatever the backend published since the last frame. This
          # is the authoritative readiness path: a tile is ready only when its
          # heights decode here.
          (each result (tcache/poll terrain-cache poll-limit)
            (loading-record-tile st result)
            (when (= :ready (get result 0))
              (put loaded (loading-key (get result 1) (get result 2))
                   (get result 3))))
          # Also probe a few coordinates directly: a worker may publish a tile
          # whose request marker was consumed before this session started.
          (unless (loading-terminal? st)
            (loading-step-probe st probe 4))
          (when (zero? (loading-outstanding st))
            (loading-enter st :build-world))
          # Bounded wait, for capture and for CI where nobody can press Esc.
          (when (and loading-timeout-effective
                     (>= (- (os/clock) loading-started-at) loading-timeout-effective))
            (loading-timeout st)))

        :build-world
        (do
          (loading-step-build-world st 2 build-one)
          (when (>= (st :worlds) (st :total))
            (loading-enter st :find-spawn)))

        :find-spawn
        (do
          # Bounded slice per frame: the radius-32 search is up to ~4400
          # columns, and examining them all at once would freeze the very
          # window this stage exists to keep alive.
          (loading-step-find-spawn st w 256)
          (cond
            (st :spawn) (loading-enter st :build-meshes)
            (st :spawn-exhausted)
            (do
              # The search used its whole radius without a verdict. Requesting
              # the chunks whose absence BLOCKED a verdict is more coverage;
              # it is bounded by the cache's own pending capacity, so this
              # cannot become an unbounded ring of demand. Then the stage
              # fails: an all-ocean world must say so, never spawn the player
              # in water or invent an island.
              (def required (st :spawn-required))
              (each coord required
                (request-tile! terrain-cache (coord 0) (coord 1)))
              (loading-fail
                st
                (string "no dry land found within " spawn-search-radius
                        " blocks of the origin"
                        (if (pos? (length required))
                          (string " (" (length required)
                                  " footprint chunk(s) were not loaded; more"
                                  " coverage may help)")
                          " (the whole searched area is ocean)"))))
            true nil))

        :build-meshes
        # Meshing happens in `main` after the mesher, atlas and shaders exist,
        # because they need a live GL context that is built later in startup.
        # The stage therefore finishes here WITHOUT claiming meshes it did not
        # perform: setting `:meshes` to `:total` would make the loading screen
        # report work that had not happened, which is exactly the dishonesty
        # this core exists to avoid. `:ready` means "the world is built and
        # playable"; the first frames mesh through the normal budgeted stream.
        (loading-enter st :ready)

        :ready nil
        nil)

      # Reference `last-state` so a state change is observable in a QA run
      # without a progress bar implying a rate.
      (when (not= last-state (st :state)) (set last-state (st :state)))

      (draw-loading-frame screen st)
      (++ (st :frame))

      # A capture is taken on the last frame the loop will run, so it holds a
      # representative loading screen rather than an arbitrary instant.
      # With --loading-frames the capture belongs on the LAST frame the loop
      # runs, so a long QA run photographs the settled screen rather than
      # whatever instant the stage happened to finish. Without it, the first
      # settled frame is the only sensible moment (nothing more will be drawn).
      (def capture-now?
        (if loading-frames-arg
          (>= (st :frame) loading-frames-arg)
          (or (= (st :state) :ready) (loading-terminal? st))))
      (when (and pending-shot capture-now?)
        (rl/take-screenshot pending-shot)
        (set pending-shot nil))))

  # --- Leaving the loading stage ---
  (def outcome (st :state))

  # QA mode: one status line, then exit. The gameplay `frame` counter has not
  # been touched, so this cannot be confused with a gameplay frame count.
  (when loading-frames-arg
    (printf "loading frames=%d state=%p ready=%d/%d failed=%d"
            (st :frame) outcome (loading-ready-count st) (st :total)
            (loading-failed-count st))
    (when pending-shot (rl/take-screenshot pending-shot))
    (when worker :process (worker-stop worker))
    (when screen (loading-screen/dispose screen))
    (rl/close-window)
    (os/exit (if (= outcome :ready) 0 1)))

  # A search that ran out of radius is a refusal, not a spawn: landing the
  # player in water (or fabricating an island) would silently violate the one
  # guarantee this stage makes.
  (when (and (= outcome :ready) (st :spawn-exhausted) (nil? (st :spawn)))
    (def required (st :spawn-required))
    (def advice
      (if (pos? (length required))
        (string " " (length required) " footprint chunk(s) were not loaded, so"
                " more coverage may help: bake those tiles or widen the search.")
        (string " The whole searched area is ocean, so no amount of waiting for"
                " tiles will produce land here.")))
    (eprint (string "error: no dry land found within " spawn-search-radius
                    " blocks of the origin (examined "
                    (or (st :spawn-examined) 0) " columns)." advice))
    (when worker :process (worker-stop worker))
    (when screen (loading-screen/dispose screen))
    (rl/close-window)
    (os/exit 1))

  (if (= outcome :ready)
    (do
      (when (= 0 (world/world-chunk-count w))
        (eprint "error: no spawn chunk produced geometry")
        (when worker :process (worker-stop worker))
        (when screen (loading-screen/dispose screen))
        (rl/close-window)
        (os/exit 1))
      # The screen and worker travel WITH the world: meshing runs after this
      # stage but on the same screen, and the worker must outlive the stage so
      # the stream can keep pulling tiles during play. Disposing here would
      # leak the second half of startup's display and stop the bake early.
      @{:world w :screen screen :worker worker :spawn (st :spawn)})
    (do
      # Never fall through into a half-built world: say what happened, stop the
      # worker we own, and exit with a failure status.
      (eprint (string "loading " outcome ": "
                      (or (loading-describe st) "spawn tiles did not arrive")))
      # Hold the final frame briefly so the reason is readable before the
      # window closes, since a silent vanish looks like a crash.
      (var hold 0)
      (while (and (< hold 90) (not (rl/window-should-close)))
        (draw-loading-frame screen st)
        (++ hold))
      (when worker :process (worker-stop worker))
      (when screen (loading-screen/dispose screen))
      (rl/close-window)
      (os/exit 1))))

(defn save-on-exit!
  "Save an ordinary session before teardown; return an observable outcome."
  [root slot w pose settings verify? scripted?]
  (if (or (nil? slot) verify? scripted?)
    :skipped
    (try
      (do (catalog/save-slot root slot w pose
                            (if settings @{:settings settings} @{}))
          :saved)
      ([err] [:failed (string err)]))))

(defn main [&]
  (when (arg-flag? "--trace-world-creation")
    (printf "creation-trace new=%p provider=%p root=%p seed-input=%p"
            qa-new-world qa-world-provider world-root qa-world-seed))
  # The front door runs BEFORE the cache is opened, because the menu is what
  # decides which world this session is: a create request sets the seed, and a load
  # request names an existing slot. Opening the cache first would commit to an
  # identity the player has not chosen yet.
  #
  # It also runs after `rl/init-window`, so the menu draws in the SAME window the
  # game will use. No second process, no re-exec, no handoff: this is one session
  # that starts at a menu and continues into the world it chose.
  (rl/set-config-flags
    (bor rl/flag-msaa-4x-hint
         (if uncapped 0 rl/flag-vsync-hint)
         (if fullscreen rl/flag-fullscreen-mode 0)))
  # Verification drops INFO only; WARNING and errors remain visible.
  (when verify-pgo (rl/set-trace-log-level 4))
  (rl/init-window 1280 800 "Trinecraft - bender + raylib")
  # THE WINDOW IS ASKED, NOT ASSUMED. Immediately after the call that should have
  # created it, and BEFORE the target FPS, the artwork decode, the readiness
  # probe or any asset work. `InitWindow` does not raise on failure -- it leaves
  # raylib without a context, and the first `BeginDrawing` (drawn by the
  # readiness pump a few milliseconds later) then dies on a null access, which
  # reads as a renderer bug rather than "no display".
  #
  # `error` is deliberate: it ends the launch once, through the same path every
  # other fatal startup condition already takes, with the cause in the message.
  # Continuing would mean pumping frames at a context that cannot exist.
  (require-ready-window! rl/window-ready?)
  (rl/set-target-fps (if uncapped 0 60))

  # --- Front door ------------------------------------------------------
  # `menu-choice` is nil for a run that names its own world; otherwise it holds
  # the request the player made. `loaded-world` carries a slot already read from
  # disk, so a load does not generate a world it was told to restore.
  (var menu-choice nil)
  (var loaded-world nil)
  (when (arg-flag? "--trace-world-creation")
    (printf "creation-trace initialized new=%p provider=%p root=%p"
            qa-new-world qa-world-provider world-root))

  # --- Direct entry points ---------------------------------------------
  # These build the request a menu WOULD have built, then fall through into the
  # same create/load code below. That is the point: the path exercised by
  # `--new-world` is the path a player's Enter takes, so a CI run proves the real
  # pipeline rather than a parallel one.
  (when qa-new-world
    (when (arg-flag? "--trace-world-creation") (print "creation-trace entered create request"))
    # Accepts the provider's real id AND a short alias, because a caller reading
    # the registry will type the id and a caller reading the docs may type the
    # alias. Both name the same provider; neither is guessed.
    (def provider-id
      (case qa-world-provider
        "terrain-diffusion-python" :terrain-diffusion-python
        "terrain-diffusion-native" :terrain-diffusion-native
        "python" :terrain-diffusion-python
        "native" :terrain-diffusion-native
        "procedural" :procedural
        nil :procedural
        (do (eprint (string "unknown --world-provider: " qa-world-provider
                            " (expected procedural, terrain-diffusion-python,"
                            " or terrain-diffusion-native)"))
            (os/exit 2))))
    (set menu-choice
      @{:kind :create
        :name qa-new-world
        :seed-input (or qa-world-seed "")
        :seed-random (empty? (or qa-world-seed ""))
        :provider provider-id
        # Settings default to the provider's own declared values, so a QA create
        # asks for exactly what a player gets by pressing Enter. --world-size
        # overrides one of them, and the provider validates it like any other.
        :settings (let [d (provider/provider-defaults provider-id)]
                    (if (and (number? qa-world-size) (has-key? d :size))
                      (do (put d :size qa-world-size) d)
                      d))}))
  # `--world-slot` was parsed but never used: it suppressed the menu and then
  # generated a fresh world, which is the opposite of loading the slot asked for.
  (when (and world-slot (nil? menu-choice))
    (set menu-choice @{:kind :open :world world-slot}))

  (when (arg-flag? "--trace-world-creation")
    (printf "creation-trace request=%p root=%p" menu-choice world-root))
  # --- Loading artwork, owned here -------------------------------------
  # ONE presenter for the whole startup: the front door paints it as a backdrop,
  # and the loading stage draws into the SAME instance after the menu closes.
  # That is the difference between the art continuing and the art restarting, and
  # it also means one decode, one slideshow clock and one texture set instead of
  # two of each. It is constructed BEFORE the menu because the menu is the first
  # thing to show it, and disposed EXACTLY ONCE, on every path that can end
  # startup: quit from the menu, a failed create, or the handoff into play.
  (def startup-assets
    (asset-paths/resolve {:explicit (arg-value "--asset-root")
                          :env-root (os/getenv "TRINEXRAFT_ASSET_ROOT")
                          :script (dyn :current-file)
                          :executable (dyn :executable)
                          :cwd (os/cwd)}))
  (def artwork-root (get startup-assets :root))
  (printf "startup artwork: %p %p" (get startup-assets :source) artwork-root)
  (def startup-screen
    (try (loading-screen/new {:asset-dir artwork-root
                              :main-art (if artwork-root
                                          (string artwork-root "/Trinexraft_main.png") "")
                              :paths loading-background-paths})
         ([err] (eprint (string "warning: loading screen: " err
                                "; using the text fallback"))
                nil)))
  # Readiness is checked offline with the same single owned process slot used
  # for generation. Saved-world loads never need Python or a model package.
  (when (or (menu-required?)
            (and menu-choice (= :terrain-diffusion-python (get menu-choice :provider))))
    (set python-runtime-probe
      (provider/python-readiness-new
        {:python terrain-python
         :script (or (arg-value "--terrain-python-script") "tools/terrain_new_game.py")
         :slot generation-slot}))
    (provider/python-readiness-start! python-runtime-probe)
    (while (and (get python-runtime-probe :job)
                (not= :failed (get (get python-runtime-probe :job) :phase)))
      (provider/python-readiness-poll! python-runtime-probe)
      (draw-loading-screen startup-screen
        @{:stage :checking :detail (get python-runtime-probe :reason)
          :hint "Checking local dependencies; no model inference"})
      (when (or (rl/window-should-close) (rl/key-pressed? rl/key-escape))
        (provider/python-readiness-cancel! python-runtime-probe))
      ))
  (var screen-disposed? false)
  # Set when a create request produced a world, so the retry loop stops.
  (var generation-done nil)
  # Only an actual menu request may retry. A direct CLI request is one-shot, and
  # legacy scripted runs without a request bypass this loop entirely.
  (var retry-state nil)
  (var retry-error nil)
  (var retry-request nil)
  (var startup-pending (or menu-choice (menu-required?)))
  (defn dispose-startup-screen []
    # Shutdown collection may block briefly; never do it inside a drawing frame.
    (when (and python-runtime-probe (get python-runtime-probe :job))
      (provider/python-readiness-close! python-runtime-probe))
    (when (and startup-screen (not screen-disposed?))
      (set screen-disposed? true)
      (loading-screen/dispose startup-screen)))

  # RETRYABLE FRONT DOOR. A cancelled or failed generation returns to the menu
  # with the reason shown, so a player can change a setting or pick a different
  # provider. Exiting the process would throw away their session for a failure
  # that says nothing about the game. The loop ends when the player makes a
  # decision that actually produces a world, or quits from home.
  (while (and startup-pending (nil? loaded-world) (nil? generation-done))
    (when (menu-required?)
      (set menu-choice nil)
    # A TABLE literal, not a struct: `{...}` in Janet is a compile-time constant
    # form and refuses a `def` value like `rl/key-enter`, which fails with the
    # unhelpful "unknown symbol rl" rather than naming the real problem.
    (def keys @{:enter rl/key-enter :kp-enter rl/key-kp-enter
                :escape rl/key-escape :backspace rl/key-backspace
                :up rl/key-up :down rl/key-down :tab rl/key-tab
                :left rl/key-left :right rl/key-right
                :random rl/key-f2
                # `[` and `]`: GLFW 91 and 93. Adjust the focused setting.
                :dec rl/key-left-bracket :inc rl/key-right-bracket})
    # The initial screen is reached through the SAME transition a keypress would
    # take, never by writing `:screen` directly. Setting the field alone left the
    # form's provider unset and its settings empty, so the screen drew a title over
    # controls with no values -- a state the real menu can never be in. Going
    # through `menu/step` means a QA capture photographs a screen a player can
    # actually reach.
    (def started
      (if retry-state
        (let [restored (table/clone retry-state)]
          (put restored :settings (table/clone (retry-state :settings)))
          (put restored :screen (if (= (retry-request :kind) :create) :new :load))
          (put restored :message retry-error)
          restored)
        (let [home (menu/state-new (menu-providers) (menu-worlds world-root))
              target (if (and menu-qa
                              (some |(= $ qa-menu-screen) ["new" "load"]))
                       qa-menu-screen nil)]
          (if (and target (= "new" target))
            (menu/step home [:new])
            (if (and target (= "load" target))
              (menu/step home [:load])
              home)))))
    # raylib functions are handed over by name: a Janet module cannot be indexed
    # as a table, so passing `rl` itself would be an unhelpful "unknown symbol".
    (def rl-fns
      @{:char-pressed rl/char-pressed
        :key-pressed? rl/key-pressed?
        :draw-text rl/draw-text
        :draw-rectangle rl/draw-rectangle
        :screen-width rl/screen-width
        :screen-height rl/screen-height
        :begin-drawing rl/begin-drawing
        :end-drawing rl/end-drawing
        :clear-background rl/clear-background
        :window-should-close rl/window-should-close
        :mouse-position rl/mouse-position
        :mouse-pressed? rl/mouse-pressed?})
    # THE BACKDROP SEAM. The view clears the frame by calling `:clear-background`;
    # handing it a function that paints the loading artwork instead of a flat
    # colour puts the art behind the menu with no view change at all. One painter
    # owns both screens, so the slideshow does not restart when the menu opens.
    #
    # THE MENU PAINTS THROUGH THE VIEW'S OWN `art` HOOK, not by hijacking the
    # clear colour. The view calls `(art width height)` and then paints its own
    # scrim and text over the result, so readability and layout stay inside the
    # view that owns them and this file only decides WHICH artwork a menu gets.
    #
    # The menu is not the loading screen and does not get its slideshow. The home
    # backdrop is ONE designed poster -- logo, subtitle and characters at fixed
    # positions -- so rotating it through the loading photographs would move a
    # logo the artwork deliberately placed, and a fade would cross-dissolve a
    # title with a landscape. The loading stage keeps `paint-background`.
    #
    # nil means "no art": the view then renders a flat panel on the clear colour,
    # which is what a machine with no assets gets. No art is a missing backdrop,
    # never a missing menu.
    (def menu-art
      (when startup-screen
        (fn [width height]
          (loading-screen/paint-main-background startup-screen width height))))
    # The capture writes INSIDE the loop, after the last frame is drawn. Writing
    # it after `run-menu!` returned would photograph a closed window -- the
    # framebuffer is gone the moment the window is, which is exactly why the
    # first QA attempt produced no file.
    (def shot (and menu-qa screenshot-path))
    (def out (menu-view/run-menu! rl-fns started keys menu-frames
                                  (when shot (fn [_frame]
                                               (rl/take-screenshot shot)))
                                  menu-art))
    (when (or (nil? out) (out :quit))
      # No decision: the window was closed, the player quit from home, or a
      # bounded QA run reached its frame limit. Leaving is the honest outcome --
      # there is no world to fall through to, and building one the player never
      # asked for would turn a menu timeout into a world.
      #
      # The presenter's textures are GL objects nothing collects, so they are
      # released while the context is still alive.
      (dispose-startup-screen)
      (rl/close-window)
      (os/exit 0))
    (set retry-state (out :state))
    (set retry-request menu-choice)
    (set retry-error nil)
    (set menu-choice (out :request)))
  (when (and (menu/request? menu-choice) (= :open (menu-choice :kind)))
    (def slot (menu-choice :world))
    (def loaded-slot (try (catalog/load-slot world-root slot)
                          ([err] (eprint (string "cannot open world: " err)) nil)))
    (if loaded-slot
      (do
        # The saved seed and provider govern the session BEFORE any generation
        # or cache identity is computed. Without this the session would keep the
        # default seed and regenerate terrain that disagrees with the chunks it
        # just loaded.
        (def m (loaded-slot :manifest))
        (when-let [saved-seed (get m :seed)]
          (when (number? (get saved-seed :value))
            (set seed (get saved-seed :value))
            (set menu-seed-kind (get saved-seed :kind))))
        (set world-name (or (get m :name) ""))
        # A loaded world generates with the settings it was SAVED with. The
        # manifest's identity gate has already proven these match the descriptor,
        # so re-validating here cannot silently upgrade them.
        (set new-provider (get m :provider))
        (when-let [saved (get m :settings)]
          (set world-settings (provider/validate-settings new-provider saved)))
        (when (= new-provider :terrain-diffusion-python)
          (set world-seed-authoritative seed)
          (set generated-artifact (get m :artifact))
          (set terrain-cache-dir (get loaded-slot :artifact-dir))
          (set seed (get generated-artifact :model-seed))
          (set terrain-cache (cache-open terrain-cache-dir))
          (set seed world-seed-authoritative)
          (set generated-cache? true))
        (set active-slot slot)
        (set loaded-world @{:slot slot :world (loaded-slot :world)
                            :player (loaded-slot :player)
                            :manifest m}))
      (if (menu-required?)
        (do (set retry-error (string "world " slot " could not be opened"))
            (set menu-choice nil))
        (do (eprint (string "world " slot " could not be opened; no replacement world was created"))
            (dispose-startup-screen)
            (rl/close-window)
            (os/exit 1)))))
  # A create request resolves its seed HERE, before the cache identity is
  # computed, because the seed is part of that identity. `seed` is a `var` for
  # exactly this reason; nothing downstream needs to know a menu chose it.
  (when (and (menu/request? menu-choice) (= :create (menu-choice :kind)))
    # A failed attempt must never inherit a previous attempt's provider/cache.
    (set new-provider :procedural)
    (set world-settings nil)
    (set generated-artifact nil)
    (set generated-cache? false)
    (set world-seed-authoritative nil)
    (set terrain-cache-dir nil)
    (set terrain-cache nil)
    (def resolved
      (try
        (if (menu-choice :seed-random)
          (world-seed/random-identity)
          (if (empty? (menu-choice :seed-input))
            # A blank field means "pick one": the model says so, and
            # `parse-seed-input` raises on blank, which is the wrong answer for
            # a player who simply did not care.
            (world-seed/random-identity)
            (world-seed/parse-seed-input (menu-choice :seed-input))))
        ([err] (eprint (string "seed: " err)) nil)))
    (if resolved
      (do (set seed (world-seed/seed-of resolved))
          (set menu-seed-record resolved)
          (set menu-seed-kind (get resolved :kind))
          (set world-name (or (menu-choice :name) ""))
          # The PROVIDER the player chose, not a hardcoded one. Falling back to
          # procedural on a provider error is the failure this branch exists to
          # prevent: a player who asked for a learned world would get a different
          # one and only find out by looking at the terrain.
          (set new-provider (or (menu-choice :provider) :procedural))
          # Settings are validated ONCE, here, against THAT provider's own schema.
          # Anything out of range or unknown refuses the create rather than
          # generating terrain that disagrees with what the menu displayed.
          (def chosen (try (provider/validate-settings new-provider
                                                       (menu-choice :settings))
                           ([err] (eprint (string "settings: " err)) nil)))
          (if chosen
            (do (set world-settings chosen)
                (printf "menu: new world \"%s\" seed %d (%s) provider %s settings %s"
                        world-name seed (string (get resolved :kind))
                        (string new-provider) (string chosen)))
            (do (set retry-error "invalid provider settings")
                (set menu-choice nil))))
      (do (set retry-error "invalid world seed")
          (set menu-choice nil))))

  # --- Temporary Python provider --------------------------------------
  # Run BEFORE preflight, because this provider produces its own complete map: the
  # session then continues as a scenic one over that artifact, exactly as if the
  # map had always been on disk. Preflight would otherwise demand tiles from a
  # cache this session is about to create.
  #
  # A failure returns the player to the menu: it does NOT fall back to procedural.
  # Falling back would hand someone who asked for a learned world a different
  # world, and they would only discover it by looking at the terrain.
  (when (and menu-choice (= new-provider :terrain-diffusion-python)
             (nil? loaded-world))
    # WORLD SEED vs MODEL SEED. The artifact's twin records the MODEL seed (the
    # value upstream sampled with), not the world seed the player chose and the
    # catalogue persists. World seed 0 maps to model seed 2147483647, so adopting
    # the artifact's seed blindly would silently replace the authoritative 0 with
    # a different number in every later record. The world seed stays the session's
    # seed; the model seed belongs to the artifact and is reproduced from it.
    (set world-seed-authoritative seed)
    # The GENERATION gate, distinct from the schema validation above: this is the
    # moment a provider must actually be able to run. A saved world skips this
    # entirely, which is why loading never depends on the Python environment.
    (provider/assert-generatable new-provider python-runtime-probe)
    # A developer override for exercising failure and cancellation without a
    # model: point the provider at a script that exits early or hangs. It is the
    # SAME argv slot the real script occupies -- no shell, no extra machinery, and
    # nothing about the generation path changes, which is what makes a fake run
    # evidence about the real one.
    (def python-script (or (arg-value "--terrain-python-script")
                           "tools/terrain_new_game.py"))
    (def python-bin terrain-python)
    (ensure-world-root! world-root)
    (def out-root (string world-root "/.generating-" (os/getpid) "-"
                          (get (world-seed/random-identity) :canonical)))
    (printf "generation: starting the Python provider (one process, pid follows)")
    (def outcome
      (run-python-generation world-settings seed out-root python-script python-bin
                             (fn [view] (draw-loading-screen startup-screen view))
                             (fn [] (or (rl/window-should-close)
                                        (rl/key-pressed? rl/key-escape)))))
    (cond
      (and (table? outcome) (outcome :ok))
      (do
        # Validate and capture owned metadata BEFORE anything reads the map. The
        # inspect returns the model seed the artifact was sampled with, so the
        # session can open the cache with the identity the TWIN records rather than
        # the world seed the player chose -- they differ for world seed 0.
        (def artifact-meta (catalog/inspect-artifact (outcome :out) seed))
        (set generated-artifact artifact-meta)
        (set terrain-cache-dir (outcome :out))
        # The cache identity the twin carries is the MODEL seed. `cache-open`
        # adopts a scenic map's own seed, so this must be the value it will find
        # or the identity check would refuse a map this session just generated.
        (set seed (get artifact-meta :model-seed))
        (set terrain-cache (cache-open (outcome :out)))
        (set generated-cache? true)
          # `cache-open` adopts the artifact's own seed, which is the MODEL seed.
          # Restore the world seed the player chose, so every later record -- the
          # catalogue, the console status, a reload -- carries the authoritative
          # value rather than a derived one.
          (when (and world-seed-authoritative
                     (not= seed world-seed-authoritative))
            (printf "generation: world seed %d, model seed %d"
                    world-seed-authoritative seed)
            (set seed world-seed-authoritative))
          (printf "generation: artifact ready at %s" (outcome :out))
          (set generation-done true))
      # Cancelled or failed: tell the player and go back to the form. The menu
      # still owns the window, the presenter still owns its textures, and nothing
      # was written -- so the only thing to discard is this attempt, not the whole
      # session.
      (= :cancelled (get outcome 0))
      (if (menu-required?)
        (do (set retry-error "generation cancelled")
            (set menu-choice nil))
        (do (eprint "generation: cancelled; no world was created")
            (dispose-startup-screen)
            (rl/close-window)
            (os/exit 0)))
      true
      (if (menu-required?)
        (do (set retry-error (string "generation: " (or (get outcome 1) "failed")))
            (set menu-choice nil))
        (do (eprint (string "generation: " (or (get outcome 1) "failed")
                           " -- no world was created"))
            (dispose-startup-screen)
            (rl/close-window)
            (os/exit 1)))))
  # A procedural create produces its world by generation, not by the Python
  # provider, so nothing above set the sentinel. Without this the loop would ask
  # the same question forever.
  (when (and (menu/request? menu-choice) (= :create (menu-choice :kind))
             (not= :terrain-diffusion-python new-provider))
    (set generation-done true))
  (when (and retry-error (not (menu-required?)))
    (eprint (string "world creation: " retry-error))
    (dispose-startup-screen)
    (rl/close-window)
    (os/exit 1)))
  # An unresolved request must not reach procedural worldgen on any path.
  (when (and startup-pending (nil? loaded-world) (nil? generation-done))
    (dispose-startup-screen)
    (rl/close-window)
    (error "world creation ended without a ready world"))

  # Identity only, before any world: a cache whose manifest cannot be parsed or
  # whose seed disagrees with this session refuses here, because an unusable
  # identity is a configuration error, not something to wait out. Tile
  # COMPLETENESS is deliberately NOT checked here -- that is the loading stage's
  # job, and blocking on it before the window makes a slow bake look like a hang.
  (spawn-preflight)

  # --- Loading stage ---------------------------------------------------
  # The window is already up, so everything below can draw. Diffusion sessions
  # wait for their spawn tiles HERE rather than before the window; procedural,
  # verification and scripted-headless runs build immediately and skip this
  # entirely, keeping their frame counts and timing exactly as they were.
  (def loading-qa? (loading-qa-requested?))
  (def loaded (if (loading-stage-required? terrain-cache verify-pgo
                                           headless-frames loading-qa?
                                           (or scenic-preload scenic-interactive))
           (loading-stage startup-screen)
           # Immediate path: procedural, --verify-pgo, and scripted headless
           # runs. A complete cache still needs no waiting, and a scripted run
           # must not turn its frame budget into a wait budget -- preflight has
           # always required the tiles here and still does.
           (do (when terrain-cache
                 (def [missing corrupt _ _] (spawn-tiles-missing terrain-cache))
                 (when (or (pos? (length missing)) (pos? (length corrupt)))
                   (preflight-spawn terrain-cache)))
               # A table in both branches, so every downstream consumer reads
               # one shape. The immediate path has no screen and no worker:
               # nothing was displayed and nothing was spawned.
               @{:world (build-world) :screen nil :worker nil})))

  # `w` and `found-spawn` are VAR: a load request swaps in the catalogue's world
  # before meshing, and clears the spawn search so the saved pose wins.
  (var w (get loaded :world))
  # The SAME presenter the menu painted, handed through the stage. Main owns its
  # lifetime: the stage never disposes on a successful return, and the teardown
  # below disposes exactly once.
  (def loading-screen-inst (get loaded :screen))
  (def terrain-worker (get loaded :worker))
  (var found-spawn (get loaded :spawn))

  # A LOADED world replaces the generated one outright, and does so BEFORE any
  # meshing: the chunks come from the catalogue, so meshing must see the restored
  # set or the first frame would draw the wrong terrain and then correct itself.
  # `found-spawn` is cleared so the pose below is the authority on where the
  # player stands -- a saved position that silently lost to a spawn search would
  # look like the load had half worked.
  (when loaded-world
    (set w (loaded-world :world))
    (set found-spawn nil))

  # The atlas and every mesh need a live GL context, so they come after the
  # window exists.
  (var material-recipes
    (try (recipes/load)
         ([err] (eprint (string "warning: material recipes: " err
                                "; using built-in defaults"))
                recipes/recipes)))
  (var texture (atlas/load-atlas-texture material-recipes))
  (var material (rl/load-material-default))
  (rl/material-set-texture material texture)

  # Custom chunk shader. If compilation fails raylib returns an invalid
  # shader; fall back to the default material rather than rendering a black
  # world, and say so, because a silent fallback looks like a shader bug.
  (def chunk-shader
    (rl/load-shader-from-memory shaders/chunk-vertex-shader
                                shaders/chunk-fragment-shader))
  (def shader-ok (rl/shader-valid? chunk-shader))
  (if shader-ok
    (set material (rl/material-set-shader material chunk-shader))
    (eprint "warning: chunk shader failed to compile; using default material"))

  (def water-shader
    (rl/load-shader-from-memory shaders/water-vertex-shader
                                shaders/water-fragment-shader))
  (def water-ok (rl/shader-valid? water-shader))
  (var water-material (rl/load-material-default))
  (rl/material-set-texture water-material texture)
  (if water-ok
    (set water-material (rl/material-set-shader water-material water-shader))
    (eprint "warning: water shader failed to compile; using textured water fallback"))

  # File edits and inspector edits converge here: validate/load first, build
  # a replacement on the GPU, switch both material maps, then retire the old
  # texture. If validation fails, the current visible atlas stays intact.
  (defn use-materials [replacement]
    (def next-texture (atlas/load-atlas-texture replacement))
    (def old-texture texture)
    (rl/material-set-texture material next-texture)
    (rl/material-set-texture water-material next-texture)
    (set texture next-texture)
    (set material-recipes replacement)
    (rl/unload-texture old-texture)
    :applied)

  (defn reload-materials [] (use-materials (recipes/load)))

  (var appearance (try (appearance-settings/source)
                       ([err] (eprint (string "warning: appearance settings: " err
                                              "; using reference defaults"))
                              {:path "data/appearance.janet"
                               :settings appearance-settings/defaults})))
  (def atmosphere (shaders/default-atmosphere))
  # A finite map's horizon is meant to be VISIBLE, so a scenic session thins the
  # atmosphere once, before the first frame. The sky's own fog colour is still
  # synced every frame; only the density is fixed here, and only for a map. Every
  # procedural, legacy and verification run keeps the shipped 0.0045 exactly.
  (when scenic-opts (put atmosphere :fog-density scenic-fog-density))
  (var day-duration (if (and (number? sky-seconds)
                             (<= 30 sky-seconds) (<= sky-seconds 86400))
                        sky-seconds 1200))
  (var day-paused (not (nil? sky-qa-phase)))
  (var day-held (* day-duration (or sky-qa-phase 0.25)))
  (var day-clock day-held)
  (defn sky-frame []
    (sky-cycle/frame (if day-paused day-held day-clock)
                     {:duration day-duration :seed seed :star-count 160}))
  (defn sync-sky-atmosphere [sky]
    (def intensity (sky :sun-intensity))
    (def ambient (sky :ambient-color))
    (def sun (sky :sun-color))
    (put atmosphere :sun-direction (map |(- $) (sky :sun-direction)))
    (put atmosphere :sun-color (map |(* $ intensity) sun))
    (put atmosphere :ambient-color
         (map |(* $ (sky :ambient-intensity)) ambient))
    (put atmosphere :fog-color (sky :fog)))
  (defn push-atmosphere [sh eye t under water?]
    (def sd (atmosphere :sun-direction))
    (def sc (atmosphere :sun-color))
    (def ac (atmosphere :ambient-color))
    (def fc (atmosphere :fog-color))
    (rl/set-uniform-vec3 sh "sunDirection" (sd 0) (sd 1) (sd 2))
    (rl/set-uniform-vec3 sh "sunColor" (sc 0) (sc 1) (sc 2))
    (rl/set-uniform-vec3 sh "ambientColor" (ac 0) (ac 1) (ac 2))
    (rl/set-uniform-vec3 sh "fogColor" (fc 0) (fc 1) (fc 2))
    (rl/set-uniform-vec3 sh "cameraPos" (eye 0) (eye 1) (eye 2))
    (rl/set-uniform-float sh "fogDensity" (atmosphere :fog-density))
    (rl/set-uniform-float sh "time" t)
    (rl/set-uniform-float sh "underwater" (if under 1 0))
    (def look (appearance-settings/current appearance))
    (if water?
      (each [key name] [[:water-detail-distance "waterDetailDistance"]
                        [:water-normal-strength "waterNormalStrength"]
                        [:water-specular-power "waterSpecularPower"]
                        [:water-specular-strength "waterSpecularStrength"]
                        [:water-fresnel-strength "waterFresnelStrength"]
                        [:water-ripple-strength "waterRippleStrength"]
                        [:water-alpha-shallow "waterAlphaShallow"]
                        [:water-alpha-deep "waterAlphaDeep"]
                        [:water-alpha-fresnel "waterAlphaFresnel"]
                        [:water-alpha-cap "waterAlphaCap"]]
        (rl/set-uniform-float sh name (look key)))
      (do (rl/set-uniform-float sh "causticStrength" (look :caustic-strength))
          (rl/set-uniform-float sh "underwaterTintStrength"
                                (look :underwater-tint-strength)))))

  # `--scenic-preload` fills the REST of the finite map here, before the first
  # frame and before meshing, so the whole map is one coherent world: the spawn
  # ring is already built, and every remaining chunk is the same fill seam. This
  # is why it must run BEFORE `build-meshes` -- meshing afterwards then sees
  # every neighbour and emits no interior seams, which a per-frame stream could
  # never guarantee for chunks that arrive later.
  # A bounded clearing is the FALLBACK for an interactive launch, never the
  # preference: `--scenic-preload` loads the whole map first and wins whenever it
  # is given, and the launcher gives it. The bounded path exists only so a launch
  # without the flag still shows terrain immediately instead of an empty frame.
  (when (and scenic-opts (or scenic-preload scenic-interactive))
    (try
      (scenic-preload! w (if scenic-preload nil scenic-prepare-radius)
        (fn [done total]
          (unless (or (rl/window-should-close) (rl/key-pressed? rl/key-escape))
            (draw-loading-screen loading-screen-inst
              @{:stage :build-world :detail (string "Preparing saved terrain: " done "/" total " chunks")
                :total total :ready done :hint "Esc quits"})
            true)))
      ([err]
        (eprint err)
        (when loading-screen-inst (loading-screen/dispose loading-screen-inst))
        (rl/close-window)
        (os/exit 1))))

  (def m (mesher/mesher-new))
  (var drawables @{})
  # Interactive sessions mesh incrementally and keep drawing, so the ~300 ms
  # one-shot pass cannot freeze a window that is already on screen. Scripted
  # and verification runs keep the single deterministic `build-meshes` call:
  # they have no viewer to stay responsive for, and their frame accounting
  # must not gain extra draws.
  # The SAME predicate as the loading stage, so a run that opted into loading
  # also keeps drawing while it meshes. Hardcoding `(not headless-frames)` here
  # left the two gates disagreeing: a QA run would enter the stage, then mesh in
  # one blocking pass with the window frozen -- the very freeze the incremental
  # path exists to remove.
  (if (loading-stage-required? terrain-cache verify-pgo
                               headless-frames loading-qa?
                               (or scenic-preload scenic-interactive))
    (let [meshed (build-meshes-incremental
                   m w drawables 4
                   (fn [done total]
                     (put m :last-meshed done)
                     (draw-meshing-frame loading-screen-inst done total))
                   # Only a run with a live window can be interrupted; that is the
                   # same condition that put it on this path.
                   true)]
      # nil = the operator pressed Esc (or closed the window) mid-pass. Leaving
      # is the honest outcome: entering play with a partial world would look like
      # a terrain bug, and the work already done is thrown away either way.
      (when (nil? meshed)
        (printf "mesher:   cancelled after %d of %d chunks"
                (or (m :last-meshed) 0) (world/world-chunk-count w))
        (when terrain-worker :process (worker-stop terrain-worker))
        (when loading-screen-inst (loading-screen/dispose loading-screen-inst))
        (rl/close-window)
        (os/exit 0)))
    (set drawables (build-meshes m w)))
  (when (empty? drawables)
    (eprint "error: no spawn chunk produced geometry")
    (when terrain-worker :process (worker-stop terrain-worker))
    (when loading-screen-inst (loading-screen/dispose loading-screen-inst))
    (rl/close-window)
    (os/exit 1))

  # Player placement. With a searched position the player starts on dry land
  # with a clear body; `drop-to-ground` is only the procedural fallback, and
  # even that is replaced by a search when the origin is not dry.
  # The unsearched start column is the spawn chunk's centre: the origin for every
  # procedural/legacy session (unchanged), and the MAP's own centre for a scenic
  # one, because the origin of a finite map is wherever its export began and is
  # frequently outside the loaded rectangle entirely.
  (def start-x (+ (get spawn-block-origin 0) 0.5))
  (def start-z (+ (get spawn-block-origin 1) 0.5))
  (def p (player/player-new start-x 40 start-z))
  (put p :yaw 0.9)
  (put p :pitch -0.35)
  (put p :flying false)
  (if found-spawn
    (do (put (p :pos) 0 (get found-spawn 0))
        (put (p :pos) 1 (get found-spawn 1))
        (put (p :pos) 2 (get found-spawn 2))
        (put p :on-ground true))
    (do
      (player/drop-to-ground p w)
      # A procedural session normally starts on dry land at the origin, but the
      # generator can put the origin in ocean for some seeds. Landing the player
      # underwater is the same failure the diffusion path refuses, so an unsafe
      # origin is searched outward here too. `--verify-pgo` is excluded: its
      # whole point is a byte-identical fixed workload.
      (when (not verify-pgo)
        (def origin-pos (p :pos))
        (def origin-block (world/world-get-block w start-x (get origin-pos 1)
                                                start-z))
        (when (or (< (get origin-pos 1) (+ (session-sea-level) 1))
                  (= world/block-water origin-block))
          (def found (spawn/find-dry-spawn
                       w {:origin-x (get spawn-block-origin 0)
                          :origin-z (get spawn-block-origin 1)
                          :radius spawn-search-radius
                           :sea-level (session-sea-level)}))
          (when found
            (put (p :pos) 0 (get found 0))
            (put (p :pos) 1 (get found 1))
            (put (p :pos) 2 (get found 2))
            (put p :on-ground true))
          (unless found
            (eprint (string "warning: the origin is not dry land and no dry land"
                            " was found within " spawn-search-radius " blocks;"
                            " starting at the spawn column")))))))
  (when (and screenshot-path sky-qa-view)
    (put p :pos @[16.5 65.0 40.5])
    (put p :flying true)
    (put p :yaw (cond (= sky-qa-view "sun") 3.1
                      (= sky-qa-view "planet") -0.85
                      0.4))
    (put p :pitch (if (= sky-qa-view "planet") 0.30 0.0)))
  (when (and screenshot-path water-qa-view)
    (cond
      (= water-qa-view "shore")
      (do (put p :pos @[16.5 30.0 40.5])
          (put p :yaw 0.4) (put p :pitch -0.35)
          (put p :flying true))
      (= water-qa-view "bay")
      (do (put p :pos @[-32.5 29.5 0.5])
          (put p :yaw 0.0) (put p :pitch -0.2449786631)
          (put p :flying true))
      (= water-qa-view "underwater")
      (do (put p :pos @[-23.5 25.0 0.5])
          (put p :yaw 0.65) (put p :pitch -0.65)
          (put p :flying true))
      (= water-qa-view "floor")
      (do (put p :pos @[8.5 31.38 32.5])
          (put p :yaw 0.7853981634) (put p :pitch -0.8911225079)
          (put p :flying true))))
  # A scenic viewpoint is placed AFTER the world exists and after any drop-to-
  # ground, so the map's own terrain decides the default height. It never
  # fabricates ground: an eye inside the loaded map sees the loaded map, and an
  # eye outside it sees whatever the map actually covers (sky).
  # `--camera-y` is the EYE height, which is what a capture is actually taken
  # from. `:pos` is the player's FEET and the renderer adds `eye-height` (1.62)
  # on top, so writing the eye value straight into `:pos` put the camera 1.62
  # blocks above where the operator aimed -- enough to clear a ridge that was
  # meant to fill the frame, or to sink one that was meant to clear it. The
  # conversion happens once, here, where the CLI contract meets the player model.
  (when (camera-view-applies? screenshot-path scenic-view scenic-interactive)
    # A preset supplies defaults for whichever fields the operator did not pass,
    # so `--scenic-view valley` alone works while `--scenic-view valley
    # --camera-y 240` overrides just the height. An unknown name still places the
    # camera at the map centre's default rather than refusing to render: a
    # capture with a slightly wrong viewpoint is more useful than none, and the
    # preset names are printed in the error-free path below.
    (def preset (or (scenic-preset scenic-view) {}))
    (def px (if (number? camera-x) camera-x (get preset :x)))
    (def pz (if (number? camera-z) camera-z (get preset :z)))
    (def py (if (number? camera-yaw) camera-yaw (or (get preset :yaw) 0.0)))
    (def pp (if (number? camera-pitch) camera-pitch (or (get preset :pitch) 0.0)))
    # INTERACTIVE means the player stands on the map, so a preset's :y is an EYE
    # height to be honoured but not a licence to hover: the feet are dropped onto
    # the ground under (px,pz) and the body is checked for clearance. Flying is
    # only entered when the operator explicitly asked for it (--fly) or when the
    # viewpoint is a capture, which has no body to obstruct it.
    (def seat
      (if scenic-interactive (scenic-seat! w p px pz) nil))
    (def ground-y (if (and seat (number? (get seat 0))) (get seat 0) nil))
    (when scenic-interactive
      (print (string "scenic: start "
                     (cond (= :searched (get seat 1)) "on nearby dry land"
                           (= :requested (get seat 1)) "on dry land"
                           "NOT grounded (no dry land within search radius)")
                     (if ground-y (string " at y " ground-y) ""))))
    (def eye-y (if (number? camera-y) camera-y
                  (or (get preset :y)
                      (if ground-y (+ ground-y player/eye-height)
                          (+ (get (p :pos) 1) 20)))))
    (when (and (not= "explicit" scenic-view)
               (not (scenic-preset-name? scenic-view)))
      (eprint (string "warning: --scenic-view \"" scenic-view "\" is not a known"
                      " preset; using explicit --camera-* flags (known: valley,"
                      " aerial)")))
    (printf "scenic: view %s  eye (%.1f %.1f %.1f)  yaw %.2f  pitch %.2f"
            scenic-view
            (if (number? px) px (+ (get spawn-block-origin 0) 0.5)) eye-y
            (if (number? pz) pz (+ (get spawn-block-origin 1) 0.5)) py pp)
    # An interactive start keeps the seat's feet; a capture is placed exactly at
    # the requested eye. Writing `eye-y - eye-height` for an interactive run would
    # override the grounded feet with the preset's declared height and put the
    # player back in the air, which is the defect this change removes.
    (def feet (if (and scenic-interactive ground-y)
                 ground-y
                 (- eye-y player/eye-height)))
    (put p :pos @[(if (number? px) px (+ (get spawn-block-origin 0) 0.5))
                  feet
                  (if (number? pz) pz (+ (get spawn-block-origin 1) 0.5))])
    (put p :on-ground (truthy? (and scenic-interactive (not (nil? ground-y)))))
    (put p :yaw py)
    (put p :pitch pp)
    # Flying only when asked for: a capture has no body to obstruct it, and an
    # operator can force it with --fly. An interactive valley start walks.
    (put p :flying (truthy? (or (arg-flag? "--fly")
                                (not scenic-interactive)))))

  # --- Catalogue (new worlds only) -------------------------------------
  # A LOADED world already has a slot; only a newly created one is written here.
  # The save happens AFTER the world and player exist, because `create-slot`
  # persists the world it is handed -- called earlier it would store an empty one
  # and the slot would be a promise the game could not keep.
  #
  # A failure is reported and survived: the player is already standing in a
  # working world, and losing that to a directory problem would be worse than a
  # world that is not yet saved.
  (when (and menu-choice (= :create (menu-choice :kind)) (nil? loaded-world))
    # `try` takes ONE body form; the `def`s live inside a `do` so the catch still
    # covers them -- a `def` directly under `try` is read as a second clause and
    # fails with a macro arity error rather than anything useful.
    (try
      (do
        (def resolved (or menu-seed-record
                          (world-seed/parse-seed-input (string seed))))
        (ensure-world-root! world-root)
        # A generated map publishes its ARTIFACT into the slot; a procedural one
        # has no artifact and copies nothing. Passing `:artifact-dir` only when
        # there is one keeps a single create path rather than two.
        # THERE IS ONE OPTIONS FACTORY, and it is `new-slot-options`. Building the
        # table here instead would put the settings-version handoff back into a
        # literal that no headless test can drive, which is precisely how a v2
        # world came to generate clearings and then fail to save.
        (def create-opts
          (new-slot-options menu-choice resolved w (player-pose p) world-name))
        (when (and generated-artifact terrain-cache-dir)
          # The SAME directory the session is reading, with the metadata that was
          # already validated -- the catalogue re-verifies on copy rather than
          # trusting this map, so pointing at it cannot smuggle bad tiles in.
          (put create-opts :artifact-dir terrain-cache-dir)
          (put create-opts :artifact generated-artifact))
        (set active-slot (catalog/create-slot world-root create-opts))
        (printf "catalogue: saved world as %s" active-slot))
      ([err] (eprint (string "warning: world not saved: " err)))))

  # A restored world resumes where it was left. Applied AFTER player creation and
  # after any spawn search, so the saved pose is the last word rather than a
  # suggestion the default placement can override.
  (when (and loaded-world (loaded-world :player)
             (not (and scenic-view (number? camera-y))))
    (apply-pose! p (loaded-world :player)))
  (when (arg-flag? "--trace-world-creation")
    (printf "creation-trace seated=%p stored=%p static=%p"
            (player-pose p) (when loaded-world (loaded-world :player)) (static-qa-view?)))

  (unless headless-frames (rl/disable-cursor))

  (var frame 0)
  (var editor (inspector/new-state material-recipes))
  (def panel-rl
    {:draw-text rl/draw-text :draw-rectangle rl/draw-rectangle
     :draw-rectangle-lines rl/draw-rectangle-lines
     :mouse-position rl/mouse-position :mouse-pressed? rl/mouse-pressed?
     :mouse-button-left rl/mouse-button-left :key-pressed? rl/key-pressed?
     :key-backspace rl/key-backspace :key-down? rl/key-down?
     :key-left-shift rl/key-left-shift :char-pressed rl/char-pressed})
  (var worst 0)
  # A wall-clock spike can mean two very different things: the frame really
  # took that long to compute, or the process was descheduled (backgrounded
  # window, App Nap, sleep, another app monopolising the GPU). Wall time alone
  # cannot distinguish them, and the difference decides whether there is a bug
  # to fix. So each frame also tracks CPU time consumed inside it: a 2.8 s
  # frame that burned 2.8 s of CPU is a stall; the same frame burning 20 ms
  # was not running at all.
  (var worst-cpu 0)
  (var worst-frame 0)
  (var worst-queue 0)
  # Steps rejected because they would leave the loaded terrain (diffusion only).
  # Reported so a frozen player reads as "waiting for tiles", not as broken input.
  (var void-guard-hits 0)
  # Tiles that arrived for coordinates the player no longer wants. Counted
  # rather than silently ignored: a climbing number explains a world that is
  # smaller than the sum of what the backend delivered.
  (var stale-tile-drops 0)
  (var stall-frames @[])
  (var selected 0)
  (var edits 0)
  # raylib's own ESC-to-quit is disabled (set-exit-key 0) so the console can
  # use ESC to dismiss itself; quitting is handled explicitly below.
  (var quit false)
  (var spikes 0)
  (var show-fps false)
  (var total-time 0)
  (var best 1e9)
  # --- Capture readiness state -------------------------------------------
  # `capture-done` is what makes the gate idempotent: one run writes exactly one
  # PNG. `capture-deadline` is a WALL-CLOCK bound, not a frame count, because the
  # failure this guards against is "meshing never converges" -- a frame budget
  # expresses time, so the ceiling on waiting must too.
  (var capture-done false)
  # Set only when the wall-clock deadline expired with the set still incomplete.
  # Kept separate from `capture-done` so "wrote nothing" is a distinct outcome
  # from "wrote a picture", and the process exit status can say which happened.
  (var capture-failed false)
  # Armed lazily, at the FIRST frame of the loop -- not here. `--scenic-preload`
  # fills and meshes the whole map above this point, which on a 1024-chunk map is
  # tens of seconds of legitimate one-time work; starting the clock here would
  # spend the operator's entire wait budget before a single frame was drawn and
  # then report "meshing never converged" about a workload that had not started.
  # The budget must measure what it names: the FRAME LOOP's wait for readiness.
  (var capture-deadline nil)
  # The frame at which readiness was confirmed, or nil. Reported so a reader can
  # tell "ready at frame 1712" from "ready at the bound": the former is the ramp
  # finishing, the latter is the gate doing nothing because the world was already
  # complete. Also the evidence that the floor past `headless-frames` was real.
  (var capture-ready-frame nil)

  (defn eye-underwater? [eye]
    (= world/block-water
       (world/world-get-block w (math/floor (eye 0)) (math/floor (eye 1))
                              (math/floor (eye 2)))))

  (defn apply-atmosphere [eye t under]
    (when shader-ok (push-atmosphere chunk-shader eye t under false))
    (when water-ok (push-atmosphere water-shader eye t under true)))

  #
  # --- Chunk streaming --------------------------------------------------
  #
  # A scenic session defaults to the WHOLE map: it is finite and already on
  # disk, so a radius smaller than the map would leave a vista hole that no
  # amount of waiting could fill. `--radius` still wins, because a QA capture may
  # deliberately want a partial view.
  (var stream-radius
    (or forced-radius
        (if scenic-opts (scenic-radius-for-map terrain-cache) default-stream-radius)))
  (var work-budget-ms default-budget-ms)
  (var last-player-chunk nil)
  (var wanted @[])               # cached chunks-in-radius for the current cell
  (def dirty-mesh @{})           # chunk key -> [cx cz] awaiting a re-mesh
  (var streamed-in 0)
  (var streamed-out 0)
  # Steady state = the stream has caught up. Averaging across the ramp
  # understates the cost of a full scene, because most of those frames were
  # drawing a half-built world.
  (var culling true)
  (var drawn-count 0)
  (var steady-frame nil)
  (var steady-time 0)
  (var steady-frames 0)
  # Measured cost of each job type, so the budget can refuse work that will
  # not fit rather than discovering it afterwards. Seeded from the known
  # interpreted costs and corrected from the first real sample onward.
  (def gen-cost (stream/ema-new 5.5))
  (def mesh-cost (stream/ema-new 6.0))
  # Coordinates whose tile already failed, so a wedged backend logs one line
  # per coordinate instead of one per frame.
  (def reported-tile-errors @{})
  # Diffusion walk position into `wanted`. Without it the generation loop
  # restarted at index 0 every frame, so the SAME first few coordinates were
  # re-probed forever: an already-pending miss looks identical to a fresh one,
  # and everything past the attempt limit never got queued at all. The queue's
  # capacity was never the constraint -- arrival order was.
  #
  # Reset whenever the wanted list is rebuilt, because the indices then refer to
  # different coordinates and a stale offset would skip real work.
  (var diffusion-cursor 0)

  (defn gen-from-wanted
    ``Diffusion generation for one wanted coordinate. Returns true only when a
    chunk was actually produced.

    A missing tile is not a failure: the coordinate is requested (bounded and
    idempotent) and the chunk is skipped this frame. The procedural generator
    is never consulted here -- mixing noise into a baked world would place
    plausible-looking terrain that disagrees with its neighbours.

    A tile that turns corrupt raises from `read-height-tile`; that is reported
    once as a failed coordinate and the build continues, because one damaged
    file must not kill a session that can still show the rest.
    ``
    [cx cz]
    (def key (world/chunk-key cx cz))
    (def result (try
                  [(tcache/read-height-tile terrain-cache cx cz)]
                  ([err] [::tile-error (string err)])))
    (if (and (= 2 (length result)) (= ::tile-error (get result 0)))
      (do
        (unless (get reported-tile-errors key)
          (put reported-tile-errors key true)
          (eprint (string "warning: terrain tile (" cx "," cz ") failed: "
                          (get result 1))))
        nil)
      (let [heights (get result 0)]
        (if heights
          (do
            (def ch (world/chunk-new cx cz))
            (fill-tile-into! (ch :blocks) cx cz heights)
            (world/world-put-chunk w ch)
            true)
          # Miss: ask, then skip. `request` is capacity-bounded, so a burst of
          # misses cannot grow the queue without bound -- and for a finite map
          # the answer is `:out-of-bounds`, which writes nothing at all.
          (do
            (request-tile! terrain-cache cx cz)
            nil)))))

  (defn mark-dirty [cx cz]
    (when (world/world-get-chunk w cx cz)
      (put dirty-mesh (world/chunk-key cx cz) [cx cz])))

  (defn drop-chunk [cx cz]
    (def key (world/chunk-key cx cz))
    (when-let [d (get drawables key)]
      # Invalidate handles for both streams. GPU release is still disabled
      # by default because UnloadMesh has an unresolved native invalid-free.
      (when (d :mesh) (rl/mesh-unload (d :mesh)))
      (when (d :water) (rl/mesh-unload (d :water))))
    (put drawables key nil)
    (world/world-remove-chunk w cx cz)
    (++ streamed-out)
    (each nb (stream/seam-neighbours cx cz) (mark-dirty (nb 0) (nb 1))))

  (defn stream-step []
    (def pos (p :pos))
    (def pcx (stream/chunk-coord-of (get pos 0)))
    (def pcz (stream/chunk-coord-of (get pos 2)))

    # Recompute the wanted set only when the player crosses a chunk boundary.
    # chunks-in-radius sorts every candidate and costs ~1.7 ms at radius 12,
    # which would be a quarter of the frame budget spent deciding what to do
    # rather than doing it.
    (when (not= [pcx pcz] last-player-chunk)
      (set last-player-chunk [pcx pcz])
      (set wanted (wanted-chunks pcx pcz stream-radius))
      # The list is new, so every remembered index now points somewhere else.
      (set diffusion-cursor 0)
      (each e (surplus-chunks-for pcx pcz stream-radius unload-margin
                                  (keys (get w :chunks)))
        (drop-chunk (e 0) (e 1))))

    # Diffusion: collect the tiles that arrived since the last frame. Bounded
    # by poll-limit coordinates, so this is a handful of stats on the frame
    # path, never a directory scan and never a wait. A tile that resolves here
    # is generated immediately so the player sees terrain the frame it lands.
    (when terrain-cache
      # `poll` returns whatever resolved from the pending queue, and that queue
      # outlives the player's position: a tile requested three chunks ago can
      # land after the player walked away, and a coordinate can also be
      # resolved while it is already resident. Neither is wanted. Adopting
      # them unconditionally grows the world without bound and, worse, can
      # resurrect a chunk `surplus-chunks` just dropped -- so every resolved
      # coordinate is checked against the CURRENT wanted set and skipped when
      # it is not there.
      (def wanted-keys (wanted-key-set wanted))
      (each result (tcache/poll terrain-cache poll-limit)
        (case (get result 0)
          :ready
          (let [cx (get result 1)
                cz (get result 2)
                heights (get result 3)
                key (world/chunk-key cx cz)]
            (cond
              (world/world-get-chunk w cx cz) nil
              (not (get wanted-keys key)) (++ stale-tile-drops)
              true
              (do
                (def ch (world/chunk-new cx cz))
                (fill-tile-into! (ch :blocks) cx cz heights)
                (world/world-put-chunk w ch)
                (++ streamed-in)
                (mark-dirty cx cz)
                (each nb (stream/seam-neighbours cx cz) (mark-dirty (nb 0) (nb 1))))))
          :error
          (let [cx (get result 1)
                cz (get result 2)
                reason (get result 3)
                key (world/chunk-key cx cz)]
            # Once per coordinate: a wedged backend must not print a line every
            # frame for the rest of the session.
            (unless (get reported-tile-errors key)
              (put reported-tile-errors key true)
              (eprint (string "warning: terrain tile (" cx "," cz ") failed: "
                              reason)))))))

    (def budget (if verify-pgo nil (stream/budget-new work-budget-ms)))
    (when budget (stream/budget-begin budget))
    # Two generation jobs and two mesh jobs per verification frame. Preserve
    # the same generation/meshing functions and nearest-first wanted order.
    (var gen-jobs 0)
    (var mesh-jobs 0)

    # Generate missing chunks nearest-first, until the budget runs out.
    #
    # Diffusion walks a PERSISTENT rotating cursor over `wanted` instead of
    # always starting at index 0. Starting at 0 was the whole defect: a
    # coordinate whose tile is still pending looks exactly like one nobody has
    # asked for, so the first few entries were re-probed every frame while
    # everything past the attempt limit was never reached -- the queue's
    # capacity sat unused and the prefetch frontier starved. The cursor makes
    # successive frames cover different coordinates, so a long wanted list is
    # traversed in `/limit` frames rather than only its head ever being tried.
    #
    # Walk order stays nearest-first: the cursor only decides where a pass
    # STARTS, and the traversal then continues to the end of the list before
    # wrapping to the front.
    (def wanted-count (length wanted))
    (var diffusion-attempts 0)
    (if (and terrain-cache (pos? wanted-count))
      (do
        (def [indices next-cursor]
          (cursor-slice wanted-count diffusion-cursor diffusion-attempts-per-frame))
        (each idx indices
          (when (and (< diffusion-attempts diffusion-attempts-per-frame)
                     (not (stream/budget-exhausted? budget)))
            (def e (get wanted idx))
            (def cx (e 0))
            (def cz (e 1))
            # `failed?` is an in-memory set, not a stat: a coordinate the
            # consumer already gave up on must not consume a probe, and it must
            # not stall the cursor either.
            (when (and (not (world/world-get-chunk w cx cz))
                       (not (tcache/failed? terrain-cache cx cz))
                       (stream/budget-allows? budget (gen-cost :value)))
              (++ diffusion-attempts)
              (def t0 (os/clock))
              (when (gen-from-wanted cx cz)
                (stream/ema-update gen-cost (* 1000 (- (os/clock) t0)))
                (++ gen-jobs)
                (++ streamed-in)
                (mark-dirty cx cz)
                (each nb (stream/seam-neighbours cx cz)
                  (mark-dirty (nb 0) (nb 1)))
                (stream/budget-note budget)))))
        # Resume after the slice, not after the successes: a miss is progress.
        (set diffusion-cursor next-cursor))
      # Procedural (and verify-pgo) keep the original nearest-first loop with
      # its two-job cap: no cursor is involved because generation cannot miss.
      (do
        (var i 0)
        (while (and (< i wanted-count)
                    (if verify-pgo (< gen-jobs 2)
                        (not (stream/budget-exhausted? budget))))
          (def e (get wanted i))
          (def cx (e 0))
          (def cz (e 1))
          (when (and (not (world/world-get-chunk w cx cz))
                     (or verify-pgo
                         (stream/budget-allows? budget (gen-cost :value))))
            (def t0 (if verify-pgo 0 (os/clock)))
            (gen-chunk-world! w cx cz seed)
            (unless verify-pgo
              (stream/ema-update gen-cost (* 1000 (- (os/clock) t0))))
            (++ gen-jobs)
            (++ streamed-in)
            (mark-dirty cx cz)
            # A new chunk changes its neighbours' seams, so they must re-mesh too.
            (each nb (stream/seam-neighbours cx cz) (mark-dirty (nb 0) (nb 1)))
            (when budget (stream/budget-note budget)))
          (++ i))))

    # Then spend whatever budget remains on meshing and uploading.
    (each key (if verify-pgo (sorted (keys dirty-mesh)) (keys dirty-mesh))
      (when (if verify-pgo (< mesh-jobs 2)
                (stream/budget-allows? budget (mesh-cost :value)))
        (def e (get dirty-mesh key))
        (put dirty-mesh key nil)
        (when-let [ch (world/world-get-chunk w (e 0) (e 1))]
          (def t0 (if verify-pgo 0 (os/clock)))
          (put drawables key (upload-chunk-all m w ch))
          (unless verify-pgo (stream/ema-update mesh-cost (* 1000 (- (os/clock) t0))))
          (++ mesh-jobs)
          (when budget (stream/budget-note budget))))))

  #
  # --- Persistence identity ---------------------------------------------
  #
  # `session-identity` is defined at module scope (above) so the load/save
  # rules can be tested without a window; what lives here is the state those
  # rules maintain.
  #
  # :known      every chunk came from this session's generator (or a region
  #             whose sidecar matched it), so a save may claim the identity.
  # :unknown    a region with NO sidecar was loaded. Its provenance is a fact
  #             nobody recorded; the blocks on screen may belong to a different
  #             generation, so this must never be re-labelled with our seed.
  (var provenance :known)
  # The path this session last loaded, when that region had unknown provenance.
  # Only that exact file may be re-saved without a sidecar.
  (var provenance-path nil)

  #
  # --- Developer console ------------------------------------------------
  #
  # raylib closes the window on ESC by default, which would make ESC unusable
  # for dismissing the console. Disable the exit key and handle quitting
  # explicitly instead.
  (rl/set-exit-key 0)

  (def con (console/console-new))

  # The studio panel's controls belong to the game, not to Emacs: declaring one
  # here is all it takes for it to appear in the editor's panel.
  (def controls (panel/registry-new))

  # Evaluate one form against the console's own environment. Readouts and panel
  # actions both go through this, so a control has the REPL's power and no more.
  (defn run-form [form]
    (def r (console/evaluate con form))
    (if (r :ok) (r :value) (string "error: " (r :error))))

  # Declared before the console env is built so a `(dev-status)` verb can see
  # it. Constructed below, once the console exists to share its environment.
  (var dev nil)

  (defn remesh-all []
    (each ch (values (get w :chunks))
      (def key (world/chunk-key (ch :cx) (ch :cz)))
      (def d (upload-chunk-all m w ch))
      (put drawables key d))
    (length drawables))

  # The console inherits this module's environment, so everything imported
  # here -- world/, worldgen/, mesher/, player/, raycast/, atlas/, rl/ -- is
  # callable from the prompt, not just the values injected below.
  (console/bind! con
    @{'world w
      'panel controls
      'player p
      'drawables drawables
      'mesher m
      'material material
      'seed seed
      'con con

      'help
      (fn help []
        (print "values:  world player drawables mesher material seed")
        (print "         every engine module is imported: world/ worldgen/")
        (print "         mesher/ player/ raycast/ atlas/ rl/")
        (print "verbs:   (tp x y z)         move the player")
        (print "         (where)            current position")
        (print "         (set-block x y z id)  edit and re-mesh")
        (print "         (fill x y z r id)  fill a cube of radius r")
        (print "         (regen)            re-mesh every chunk")
        (print "         (reload-materials)  reload data/materials.janet live")
        (print "         (save-materials)    save applied material recipes")
        (print "         (save-appearance)   persist current water look")
        (print "         (dev-status)        the Emacs socket REPL port")
        (print "         (reload-module :mesher) live-reload one source module")
        (print "         (reload-appearance) reload water look from disk")
        (print "         (edit-mode)        open the material editor [Tab]")
        (print "         (play-mode)        return to Object/Play mode")
        (print "         (time-of-day .5)   hold sunset (0 dawn, .25 noon, .75 night)")
        (print "         (sky-pause false)  resume celestial motion")
        (print "         (day-length 1200) full cycle duration in seconds")
        (print "         (fly) (walk)       movement mode")
        (print "         (stats)            world and frame stats")
        (print "         (blocks)           block id table")
        (print "         (clear)            clear the scrollback")
        :ok)

      'tp
      (fn tp [x y z]
        (def pos (p :pos))
        (put pos 0 (* 1.0 x)) (put pos 1 (* 1.0 y)) (put pos 2 (* 1.0 z))
        (put (p :vel) 1 0)
        [x y z])

      'where (fn where [] (tuple ;(p :pos)))

      'set-block
      (fn set-block [x y z id]
        (world/world-set-block w x y z id)
        (remesh-around m w drawables x z)
        (++ edits)
        id)

      'fill
      (fn fill [x y z r id]
        (var n 0)
        (for dy (- r) (+ r 1)
          (for dz (- r) (+ r 1)
            (for dx (- r) (+ r 1)
              (world/world-set-block w (+ x dx) (+ y dy) (+ z dz) id)
              (++ n))))
        # One bulk re-mesh rather than one per block: a radius-4 fill touches
        # 729 blocks, and re-meshing per block would stall for seconds.
        (remesh-all)
        (+= edits n)
        n)

      'regen (fn regen [] (remesh-all))
      'reload-materials
      (fn reload-materials-verb []
        (def path (editor :path))
        (def revision (inspector/file-revision path))
        (def replacement (recipes/load path))
        (when (not= revision (inspector/file-revision path))
          (error "material file changed during Reload; retry"))
        (use-materials replacement)
        (set editor (inspector/accept-reload editor replacement revision))
        :reloaded)
      'save-materials
      (fn save-materials-verb []
        (set editor (inspector/perform editor
                         (get (inspector/transition editor {:type :save}) :effect)))
        :saved)
      'edit-mode
      (fn edit-mode []
        (when (not= (editor :mode) :edit)
          (set editor (get (inspector/transition editor {:type :mode}) :state)))
        (put p :flying true)
        (rl/enable-cursor)
        :edit)
      'play-mode
      (fn play-mode []
        (when (= (editor :mode) :edit)
          (set editor (get (inspector/transition editor {:type :mode}) :state)))
        (when (not (con :open)) (rl/disable-cursor))
        :play)
      'fly (fn fly [] (put p :flying true) :flying)
      'walk (fn walk [] (put p :flying false) :walking)

      'blocks
      (fn blocks []
        {:air world/block-air :stone world/block-stone :dirt world/block-dirt
         :grass world/block-grass :sand world/block-sand
         :water world/block-water :wood world/block-wood
         :leaves world/block-leaves})

      'stats
      (fn stats []
        {:chunks (world/world-chunk-count w)
         :draws (length drawables)
         :fps (rl/get-fps)
         :frame-ms (* 1000 (rl/get-frame-time))
         :worst-ms worst
         :edits edits
         :pos (tuple ;(p :pos))
         :flying (p :flying)
         :seed seed})

      'show-fps
      (fn show-fps-verb [&opt on]
        # Toggles by default; (show-fps true) / (show-fps false) force it.
        (set show-fps (if (nil? on) (not show-fps) (truthy? on)))
        {:showing show-fps :fps (rl/get-fps)
         :frame-ms (* 1000 (rl/get-frame-time))
         :worst-ms worst :spikes spikes
         :capped (not uncapped)})

      'fps
      (fn fps-verb []
        {:fps (rl/get-fps)
         :frame-ms (* 1000 (rl/get-frame-time))
         :best-ms (if (< best 1e8) best nil)
         :worst-ms worst
         :spikes spikes
         :frames frame
         :average-fps (if (pos? total-time) (/ (- frame 10) total-time) nil)
         :capped (not uncapped)})

      'radius
      (fn radius-verb [&opt n]
        (when n
          (set stream-radius (max 1 (min 24 n)))
          # Force the wanted set to be rebuilt on the next frame.
          (set last-player-chunk nil))
        {:radius stream-radius
         :chunks-wanted (length (stream/chunks-in-radius 0 0 stream-radius))
         :loaded (world/world-chunk-count w)})

      'quit
      (fn quit-verb []
        (set quit true)
        :quitting)

      'save
      (fn save-verb [&opt path]
        # A world created from the front door belongs to a CATALOGUE SLOT. Saving
        # it to a bare .trcr would fork its identity -- two files claiming the
        # same generation -- so the catalogue is the destination whenever there
        # is one, and the .trcr path is only the fallback for a session that has
        # no slot. `(save <slot-id>)` is still honoured if the player names one.
        (when (and (nil? path) active-slot)
          (def chosen (if (and menu-choice (menu-choice :settings))
                        (menu-choice :settings) @{}))
          (def m (catalog/save-slot world-root active-slot w (player-pose p)
                                    @{:settings chosen}))
          (return
            {:saved (world/world-chunk-count w) :slot active-slot
             :name (get m :name)
             :bytes (os/stat (string world-root "/" active-slot) :size)
             :catalogue true}))
        (def target (or path "world.trcr"))
        (def t0 (os/clock))
        (def identity (session-identity terrain-cache seed))
        (def existed? (not (nil? (os/stat target))))
        # An EXISTING file may only be rewritten when its sidecar proves it
        # holds this very generation. Unknown provenance (no sidecar) is
        # refused: writing it would either mislabel the old bytes or replace a
        # world whose origin nobody recorded.
        (when existed?
          # The CRC of the bytes NOW on disk, not of bytes about to be written:
          # `gate` compares this against the sidecar, and without it every
          # sidecar reads :stale and re-saving your own region would be
          # refused. The load side recomputes its own CRC the same way.
          (def existing-crc (terrain-integrity/crc32 (region/read-file target)))
          (def unknown? (= :unknown provenance))
          (def verdict
            (save-permitted? target identity existing-crc
                             (if unknown? provenance-path nil) unknown?))
          (when (= :refuse (get verdict 0))
            (error (string "refusing to overwrite " target ": " (get verdict 1)
                           ". Save to a new path instead."))))
        (def n (region/save-world target w))
        # Region FIRST, sidecar second: a crash between them leaves a CRC
        # disagreement (:stale) rather than a sidecar labelling bytes it never
        # accompanied.
        (def crc (terrain-integrity/crc32 (region/read-file target)))
        (def claimed
          (if (= :unknown provenance)
            # This session loaded a region whose provenance nobody recorded.
            # The blocks on screen may not be this generation's, so no sidecar
            # is written and the session keeps saying so.
            (do (eprint (string "warning: " target " saved WITHOUT an identity "
                                "sidecar: its contents have unknown provenance"))
                :skipped)
            (do (terrain-identity/write-atomic target identity crc)
                :written)))
        (when (= :written claimed)
          (set provenance :known)
          (set provenance-path nil))
        {:saved n :path target
         :bytes (os/stat target :size)
         :identity (terrain-identity/describe identity)
         :sidecar claimed
         :provenance provenance
         :ms (* 1000 (- (os/clock) t0))})

      'load
      (fn load-verb [&opt path]
        (def target (or path "world.trcr"))
        (def t0 (os/clock))
        (def identity (session-identity terrain-cache seed))
        # Validate and gate BEFORE anything in the live world changes: read the
        # bytes, check its CRC against the sidecar, and decide whether this
        # session may adopt them at all.
        (def bytes (region/read-file target))
        (def crc (terrain-integrity/crc32 bytes))
        (def decision (terrain-identity/gate target identity crc))
        (def status (get decision :status))
        (unless (or (= status :match) (= status :unverifiable))
          (error (string "refusing to load " target ": "
                         (or (get decision :reason) (string status))
                         ". The current world is unchanged.")))
        # Decode the SAME bytes the gate approved. Re-reading the path here
        # would let a file replaced between the two reads pass the identity
        # check on its old content and then install its new content; decoding
        # from `bytes` makes the gated bytes and the adopted bytes identical by
        # construction rather than by timing. Every record decodes before
        # anything is returned, so a truncated payload still fails with the
        # live world intact.
        (def tmp (world/world-new))
        (each ch (decode-region-bytes bytes) (world/world-put-chunk tmp ch))
        # Only now is replacement safe: free every old drawable, then swap the
        # chunk table wholesale rather than mutating it entry by entry.
        (eachp [key d] drawables
          (when d
            (when (d :mesh) (rl/mesh-unload (d :mesh)))
            (when (d :water) (rl/mesh-unload (d :water)))))
        (each key (keys drawables) (put drawables key nil))
        (put w :chunks (get tmp :chunks))
        (set provenance (if (= status :match) :known :unknown))
        (set provenance-path (if (= status :match) nil target))
        # Everything must re-mesh, and the stream must rebuild its view.
        (each key (keys (get w :chunks))
          (put dirty-mesh key [(key 0) (key 1)]))
        (set last-player-chunk nil)
        {:loaded (world/world-chunk-count w) :path target
         :identity (terrain-identity/describe identity)
         :provenance provenance
         :ms (* 1000 (- (os/clock) t0))})

      'region-info
      (fn region-info-verb [&opt path]
        (region/region-info (or path "world.trcr")))

      'atmosphere (fn atmosphere-verb [] atmosphere)
      'time-of-day
      (fn time-of-day-verb [&opt phase]
        # Phase 0 sunrise, .25 noon, .5 sunset, .75 midnight.
        (when (not (nil? phase))
          (unless (and (number? phase) (<= 0 phase) (< phase 1))
            (error "time-of-day expects a phase from 0 up to 1"))
          (set day-held (* day-duration (- phase (math/floor phase))))
          (set day-clock day-held)
          (set day-paused true))
        {:phase ((sky-frame) :phase) :paused day-paused
         :duration-seconds day-duration})
      'day-length
      (fn day-length-verb [&opt seconds]
        (when (not (nil? seconds))
          (unless (and (number? seconds) (>= seconds 30) (<= seconds 86400))
            (error "day-length expects 30..86400 seconds"))
          (set day-duration seconds))
        {:duration-seconds day-duration :phase ((sky-frame) :phase)})
      'sky-pause
      (fn sky-pause-verb [&opt on]
        (def phase ((sky-frame) :phase))
        (set day-paused (if (nil? on) (not day-paused) (truthy? on)))
        (if day-paused
          (set day-held (* day-duration phase))
          (set day-clock (* day-duration phase)))
        {:paused day-paused :phase ((sky-frame) :phase)})

      'sun
      (fn sun-verb [&opt r g b]
        (when r (put atmosphere :sun-color [r (or g r) (or b r)]))
        (atmosphere :sun-color))

      'ambient
      (fn ambient-verb [&opt r g b]
        (when r (put atmosphere :ambient-color [r (or g r) (or b r)]))
        (atmosphere :ambient-color))

      'fog
      (fn fog-verb [&opt density r g b]
        (when density (put atmosphere :fog-density density))
        (when r (put atmosphere :fog-color [r (or g r) (or b r)]))
        {:density (atmosphere :fog-density) :color (atmosphere :fog-color)})

      'sun-dir
      (fn sun-dir-verb [&opt x y z]
        (when x (put atmosphere :sun-direction [x y z]))
        (atmosphere :sun-direction))

      'shader (fn shader-verb [] {:valid shader-ok})

       'save-appearance
       (fn save-appearance-verb []
         (appearance-settings/save (appearance-settings/current appearance)
                                   (appearance :path)))
       'reload-appearance
       (fn reload-appearance-verb []
         (set appearance (appearance-settings/reload appearance))
         (appearance-settings/current appearance))

      'cull
      (fn cull-verb [&opt on]
        (set culling (if (nil? on) (not culling) (truthy? on)))
        {:culling culling :drawn drawn-count :loaded (length drawables)})

      'budget
      (fn budget-verb [&opt ms]
        (when ms (set work-budget-ms (max 0 ms)))
        {:budget-ms work-budget-ms})

      'streaming
      (fn streaming-verb []
        {:radius stream-radius
         :budget-ms work-budget-ms
         :loaded (world/world-chunk-count w)
         :loaded-meshes (length drawables)
         :drawn drawn-count
         :culling culling
         :pending-mesh (length dirty-mesh)
         :streamed-in streamed-in
         :streamed-out streamed-out
         :gen-ms (gen-cost :value)
         :mesh-ms (mesh-cost :value)
         :terrain (if terrain-cache :diffusion :procedural)
         :tile-cache (if terrain-cache (tcache/status terrain-cache) nil)
         :void-guards void-guard-hits
         :stale-tile-drops stale-tile-drops})

      'dev-status (fn dev-status-verb [] (dev-server/status dev))
      'reload-module
      (fn reload-module-verb [name]
        (reload/reload con name))
      'colour-text
      (fn colour-text-verb [tbl key]
        (def v (get tbl key))
        (if (indexed? v)
          (string/format "%.2f,%.2f,%.2f" (get v 0) (get v 1) (get v 2))
          (string v)))

      'atmosphere-phase
      (fn atmosphere-phase-verb [] ((sky-frame) :phase))

      'panel-add
      (fn panel-add-verb [id opts]
        (def c (panel/define! controls id opts))
        (string (c :id) " registered"))

      'panel-remove
      (fn panel-remove-verb [id]
        (panel/remove! controls id)
        :removed)

      'panel-controls
      (fn panel-controls-verb []
        (panel/manifest controls))

      'panel-values
      (fn panel-values-verb []
        (panel/readouts controls (fn [form] (run-form form))))

      'clear (fn clear [] (console/clear-scrollback con) :cleared)}
    (curenv))

  # Built-in studio controls. These are ordinary panel declarations, which is
  # the point: they use exactly the API a developer would, so if a new control
  # does not work through it, the API is what is broken.
  (defn- register-control [id kind group text form &opt hint extra]
    (panel/define! controls id
                   (merge {:kind kind :group group :label text
                           :form form :hint (or hint "")}
                          (or extra {}))))

  (register-control "time-hold" :number "world" "Hold time of day"
       "(do (time-of-day %s) (atmosphere-phase))"
       "0 dawn, .25 noon, .5 sunset, .75 night"
       {:min 0 :max 0.99 :step 0.05 :read-form "(atmosphere-phase)"})
  (register-control "time-resume" :action "world" "Resume day cycle" "(sky-pause false)")
  (register-control "regen" :action "world" "Re-mesh everything" "(do (regen) :remeshed)")
  (register-control "save-materials" :action "materials" "Save materials" "(save-materials)")
  (register-control "reload-materials" :action "materials" "Reload materials"
       "(reload-materials)")
  (register-control "save-appearance" :action "materials" "Save water appearance"
       "(save-appearance)")
  (register-control "reload-appearance" :action "materials" "Reload water appearance"
       "(reload-appearance)")
  (register-control "reload-module" :text "development" "Reload module" "(reload-module %s)"
       "a keyword, for example :mesher")
  (register-control "fps" :readout "performance" "FPS" "(get (stats) :fps)")
  (register-control "frame-ms" :readout "performance" "Frame (ms)"
       "(string/format \"%.2f\" (get (stats) :frame-ms))")
  (register-control "worst-ms" :readout "performance" "Worst frame (ms)"
       "(string/format \"%.1f\" (get (stats) :worst-ms))")
  (register-control "chunks" :readout "performance" "Chunks loaded"
       "(length (get world :chunks))")
  (register-control "pending" :readout "performance" "Pending meshes"
       "(get (stats) :pending-mesh)")
  (register-control "sun" :readout "atmosphere" "Sun colour" "(colour-text (atmosphere) :sun-color)")
  (register-control "fog" :readout "atmosphere" "Fog colour" "(colour-text (atmosphere) :fog-color)")
  (register-control "phase" :readout "atmosphere" "Day phase" "(atmosphere-phase)")

  (unless verify-pgo (console/greet con))

  # The dev socket shares this console's environment, so `(+ 1 2)` typed in
  # Emacs and typed at `~` are the same REPL over the same live game tables.
  # Constructed only under --dev; a nil server means every pump is a no-op,
  # so the production path costs one nil test per frame and opens no socket.
  (when dev-mode
    (def opened (dev-server/server-new con "127.0.0.1" dev-port))
    (when opened
      (set dev (dev-server/start opened))
      (printf "dev-server: listening on 127.0.0.1:%d" (dev-server/bound-port dev)))
    (unless opened
      (eprint "warning: --dev given but the socket could not be opened")))

  (while (capture-loop-continues? headless-frames frame capture-ready
                                  capture-done capture-failed)
    # Arm the wall clock on the FIRST frame the loop actually runs, so the budget
    # covers frame-loop waiting and not the one-time preload/mesh work above.
    # Guarded by `capture-ready` because a capture is the only mode that waits.
    (when (and capture-ready (nil? capture-deadline))
      (set capture-deadline (+ (os/clock) capture-timeout-arg))
      # Remove any file already at the output path. A readiness timeout then
      # leaves NO PNG rather than last run's PNG under this run's name -- the
      # difference between "the evidence is missing" and "the evidence is a
      # picture of another map", which no reader could detect afterwards.
      (when (os/stat screenshot-path)
        (try (os/rm screenshot-path) ([err] nil))))
    (unless (and (not quit) (not (rl/window-should-close)))
      (break))
    # Two different numbers, deliberately. `raw-dt` is what the frame actually
    # cost and is what instrumentation must report. `dt` is clamped so a stall
    # cannot teleport the player through geometry in one step.
    #
    # Measuring the worst frame from the CLAMPED value silently saturates the
    # metric: every spike at or beyond the clamp reports exactly 50.0 ms, which
    # hides how bad a stall really was -- the opposite of what a frame-budget
    # investigation needs.
    (def raw-dt (if verify-pgo (/ 1 60) (rl/get-frame-time)))
    (def dt (min raw-dt 0.05))
    (def frame-cpu0 (os/clock :cputime))
    # One bounded slice of dev-socket work. Idle cost is a few microseconds,
    # measured, which is why this belongs in the frame loop rather than a
    # second thread fighting raylib for the main thread's GL context.
    (when dev (dev-server/pump dev))
    (unless day-paused (+= day-clock dt))

    # --- Console ---
    # The console owns the keyboard while it is open: game input is skipped
    # entirely, so typing `(fill ...)` cannot also walk the player forward.
    (def console-rows (console/rows-for-height (/ (rl/screen-height) 2)))
    (unless headless-frames
      (if (con :open)
        (when (= :closed (console/pump-input con console-rows))
          (when (= (editor :mode) :play) (rl/disable-cursor)))
        (when (rl/key-pressed? rl/key-grave)
          (console/toggle! con)
          # Drop the keystroke that opened the console, or the ` lands in the
          # input line as the first character typed.
          (console/drain-input)
          (rl/enable-cursor))))

    # Headless runs cannot type, so drive the console directly. This is what
    # proves the overlay renders over the live world and that evaluation
    # reaches real game state -- neither of which the unit tests can show.
    (when (and headless-frames (not bench-frames) (not (static-qa-view?))
               (= frame 55))
      (set (con :open) true)
      (each line ["(shader)"
                  "(show-fps)"
                  "(atmosphere)"
                  "(tp 8 46 8)"]
        (buffer/clear (con :input))
        (buffer/push (con :input) line)
        (set (con :cursor) (length (con :input)))
        (console/submit con))
      (buffer/push (con :input) "(fill 8 44 8 1 ")
      (set (con :cursor) (length (con :input))))

    (def console-open (and (con :open) (not headless-frames)))

    (if (and headless-frames (not (static-qa-view?)))
      # Deterministic sweep for ordinary screenshots, independent of mouse position.
      # A scenic viewpoint is the opposite: the caller named one exact eye and
      # orientation, so sweeping it here would animate away the very frame the
      # capture is meant to show -- which is exactly what it did before this
      # exclusion (three different --camera-pitch values produced identical
      # pixels).
      (do (put p :yaw (+ 0.9 (* frame 0.004)))
          (put p :pitch (+ -0.5 (* frame 0.004))))
      (unless (or headless-frames console-open (= (editor :mode) :edit)) (apply-look p)))

    (when (and screenshot-path (= water-qa-view "editor") (= frame 5))
      (set editor (get (inspector/transition editor {:type :mode}) :state)))

    (unless (or headless-frames console-open)
      (when (rl/key-pressed? rl/key-tab)
        (set editor (get (inspector/transition editor {:type :mode}) :state))
        (if (= (editor :mode) :edit)
          (do (put p :flying true) (rl/enable-cursor))
          (rl/disable-cursor))))

    (unless (or headless-frames console-open (= (editor :mode) :edit))
      (when (rl/key-pressed? rl/key-escape) (set quit true))
      (when (rl/key-pressed? rl/key-f)
        (put p :flying (not (p :flying))))
      (each [i key] (pairs [rl/key-one rl/key-two rl/key-three rl/key-four])
        (when (rl/key-pressed? key) (set selected i))))

    (def vertical
      (cond (or console-open (= (editor :mode) :edit)) 0
            (rl/key-down? rl/key-space) 1
            (rl/key-down? rl/key-q) -1
            0))
    # Physics still runs with the console open -- gravity should not pause
    # mid-fall just because someone is typing -- but all input reads as zero.
    # The position and velocity are snapshotted first so the void guard below
    # can put the player back exactly where they were before the step.
    (def guard-pos [(get (p :pos) 0) (get (p :pos) 1) (get (p :pos) 2)])
    (def guard-vel [(get (p :vel) 0) (get (p :vel) 1) (get (p :vel) 2)])
    (player/update-physics p w dt
                           (if (or headless-frames console-open (= (editor :mode) :edit))
                             [0 0]
                             (movement-input p))
                           (and (not console-open) (= (editor :mode) :play)
                                (rl/key-down? rl/key-space))
                           (and (not console-open) (= (editor :mode) :play)
                                (rl/key-down? rl/key-left-shift))
                           vertical)
    (when (and (arg-flag? "--trace-world-creation") (= frame 0))
      (printf "creation-trace after-physics=%p dt=%p" (player-pose p) dt))

    # --- Void guard ---
    # A diffusion world has visible holes where tiles have not arrived. Walking
    # or flying into one would put the player inside an empty chunk and drop
    # them through the floor of the world, so a step that ends over unloaded
    # ground is rejected and the velocity that pushed them there is zeroed. The
    # camera and input keep running: the player is frozen at the edge of the
    # loaded terrain, not trapped in a menu.
    # Skipped for scripted QA viewpoints: those deliberately place the camera
    # outside the loaded area to photograph the sky or the water, so restoring
    # their position would defeat the capture. `guard-vel` is kept because the
    # snapshot is also the statement of what a rejected step rolls back to.
    (when (and terrain-cache
               (not (and screenshot-path
                         (static-qa-view?))))
      (def pos (p :pos))
      (unless (footprint-loaded? w (get pos 0) (get pos 2))
        (put (p :pos) 0 (get guard-pos 0))
        (put (p :pos) 1 (get guard-pos 1))
        (put (p :pos) 2 (get guard-pos 2))
        # Horizontal velocity returns to what the step started with, so walking
        # into the edge keeps pressing against it and resumes the instant the
        # tile lands. Vertical velocity is zeroed instead of restored: keeping
        # an accumulating fall speed would add a metre-per-second per frame
        # while the player is held, then drop them the moment ground appears.
        (put (p :vel) 0 (get guard-vel 0))
        (put (p :vel) 1 0)
        (put (p :vel) 2 (get guard-vel 2))
        (put p :on-ground false)
        (++ void-guard-hits)))

    # Stream before targeting so a chunk that arrives this frame can be hit
    # by the ray immediately.
    (stream-step)

    # --- Targeting ---
    (def eye (player/eye-position p))
    (def dir (player/look-direction p))
    (def hit
      (if (and (= (editor :mode) :edit) (not (con :open)) (not headless-frames))
        (edit-pick/pick-first-solid w eye (p :yaw) (p :pitch) 70
                                    (/ (rl/screen-width) (max 1 (rl/screen-height)))
                                    (rl/screen-width) (rl/screen-height)
                                    (rl/mouse-position) reach)
        (raycast/raycast-first-solid w (get eye 0) (get eye 1) (get eye 2)
                                     (get dir 0) (get dir 1) (get dir 2)
                                     reach)))
    # In headless mode drive the same break/place code paths on a schedule, so
    # a screenshot run actually exercises editing and incremental re-meshing
    # rather than just proving the renderer compiles.
    (when (and headless-frames (not (static-qa-view?)) hit)
      (when (and (>= frame 20) (< frame 40) (zero? (% frame 4)))
        (world/world-set-block w (hit :x) (hit :y) (hit :z) world/block-air)
        (remesh-around m w drawables (hit :x) (hit :z))
        (++ edits))
      (when (and (>= frame 50) (< frame 70) (zero? (% frame 4)) (hit :face))
        (world/world-set-block w (hit :px) (hit :py) (hit :pz)
                               world/block-wood)
        (remesh-around m w drawables (hit :px) (hit :pz))
        (++ edits)))

    (unless (or headless-frames console-open (= (editor :mode) :edit))
      (when (and hit (rl/mouse-pressed? rl/mouse-button-left))
        (world/world-set-block w (hit :x) (hit :y) (hit :z) world/block-air)
        (remesh-around m w drawables (hit :x) (hit :z))
        (++ edits))
      (when (and hit (hit :face) (rl/mouse-pressed? rl/mouse-button-right))
        # Refuse to place a block inside the player's own box.
        (def px (hit :px)) (def py (hit :py)) (def pz (hit :pz))
        (def saved (world/world-get-block w px py pz))
        (world/world-set-block w px py pz (get placeable selected))
        (if (player/box-collides? w (get (p :pos) 0) (get (p :pos) 1)
                                  (get (p :pos) 2))
          (world/world-set-block w px py pz saved)
          (do (remesh-around m w drawables px pz) (++ edits)))))

    # --- Draw ---
    (def cam (rl/camera3d eye
                          [(+ (get eye 0) (get dir 0))
                           (+ (get eye 1) (get dir 1))
                           (+ (get eye 2) (get dir 2))]
                          [0 1 0] 70))
    (def under (eye-underwater? eye))
    (def celestial (sky-frame))
    (sync-sky-atmosphere celestial)
    (apply-atmosphere eye (if verify-pgo day-clock (rl/get-time)) under)
    (rl/begin-drawing)
    # Clear to the fog colour so terrain fading into the distance meets a sky
    # of the same colour rather than a visible seam at the draw boundary.
    (def fc (if under [0.03 0.17 0.26] (atmosphere :fog-color)))
    (rl/clear-background [(math/floor (* 255 (fc 0))) (math/floor (* 255 (fc 1)))
                          (math/floor (* 255 (fc 2))) 255])
    (unless under
      (sky-render/draw celestial (p :yaw) (p :pitch)
                       (rl/screen-width) (rl/screen-height)))
    (rl/begin-mode-3d cam)
    # One frustum per frame, then a cheap AABB test per chunk. At radius 16
    # that is 797 draw calls reduced to whatever is actually in view -- the
    # test costs ~0.6 us and saves a full DrawMesh.
    (def view
      (when culling
        (frustum/frustum-from-camera
          eye
          [(+ (get eye 0) (get dir 0))
           (+ (get eye 1) (get dir 1))
           (+ (get eye 2) (get dir 2))]
          [0 1 0] 70
          (/ (rl/screen-width) (max 1 (rl/screen-height)))
          0.1 1000)))
    (set drawn-count 0)
    (def visible @[])
    (eachp [key d] drawables
      (when (and d (or (nil? view)
                       (frustum/chunk-visible? view (key 0) (key 1))))
        (array/push visible d)
        (when (d :mesh)
          (++ drawn-count)
          (rl/mesh-draw (d :mesh) material (d :xform)))))

    # Translucent pass, strictly after every opaque surface, so water blends
    # against the terrain behind it rather than against whatever happened to
    # be drawn first. Depth writes are disabled for the same reason within
    # the pass itself: one water quad must not occlude the next, or a body of
    # water tears into visible per-block facets.
    (do
      (rl/begin-blend-mode rl/blend-alpha)
      (rl/disable-depth-mask)
      # Water is a thin surface; seen from below it should still be there.
      (rl/disable-backface-culling)
      (each d visible
        (when (d :water)
          (rl/mesh-draw (d :water) water-material (d :xform))))
      (rl/enable-backface-culling)
      (rl/enable-depth-mask)
      (rl/end-blend-mode))
    # Outline the targeted block. DrawCubeWires centres on the position, so
    # the centre of block (x,y,z) is (x+0.5, y+0.5, z+0.5).
    (when (and hit (or (= (editor :mode) :edit) (not (con :open))))
      (rl/draw-cube-wires [(+ (hit :x) 0.5) (+ (hit :y) 0.5) (+ (hit :z) 0.5)]
                          1.002 1.002 1.002 rl/black))
    (rl/end-mode-3d)
    # Hand-held pickaxe lives in screen space so it follows the camera
    # without occupying a world block or interfering with depth testing.
    (when (and (not clean-view) (not (con :open)) (= (editor :mode) :play))
      (pickaxe/draw (rl/screen-width) (rl/screen-height)))

    (def ms (* 1000 raw-dt))
    (when (and (> frame 10) (> ms worst))
      (set worst ms)
      (set worst-frame frame)
      (set worst-cpu (* 1000 (- (os/clock :cputime) frame-cpu0)))
      (set worst-queue (length dirty-mesh)))
    (when (and (> frame 10) (> ms 33.3)) (++ spikes))
    # Keep the worst few stalls, not just the single worst: one outlier tells
    # you a number, three tell you whether they share a cause.
    (when (and (> frame 10) (> ms 100))
      (array/push stall-frames
                  {:frame frame
                   :ms ms
                   :cpu-ms (* 1000 (- (os/clock :cputime) frame-cpu0))
                   :queue (length dirty-mesh)
                   :chunks (world/world-chunk-count w)}))
    (when (> frame 10)
      (+= total-time raw-dt)
      (when (< ms best) (set best ms)))
    (when (and (nil? steady-frame) (> frame 10)
               (empty? dirty-mesh)
               (>= (world/world-chunk-count w) (length wanted))
               (pos? (length wanted)))
      (set steady-frame frame))
    (when (and steady-frame (> frame (+ steady-frame 30)))
      (+= steady-time raw-dt)
      (++ steady-frames))
    # The HUD is hidden while the console is up: they occupy the same corner
    # and the translucent console let HUD text bleed through its scrollback,
    # making both unreadable. (stats) reports the same numbers on demand.
    (when (and (arg-flag? "--trace-world-creation") (< frame 2))
      (printf "creation-trace drawing frame=%p pos=%p" frame (p :pos)))
    (unless (or clean-view (con :open))
    (rl/draw-rectangle 8 8 360 (if terrain-cache 130 108) [0 0 0 140])
    (rl/draw-text (string/format "%d FPS  %.1f ms (worst %.1f)"
                                 (rl/get-fps) ms worst)
                  16 16 20 rl/white)
    (rl/draw-text (string/format "%d chunks  %d draws  %d edits"
                                 (world/world-chunk-count w)
                                 (length drawables) edits)
                  16 40 18 rl/white)
    (rl/draw-text (string/format "x %.1f y %.1f z %.1f  %s"
                                 (get (p :pos) 0) (get (p :pos) 1)
                                 (get (p :pos) 2)
                                 (if (p :flying) "fly" "walk"))
                  16 62 18 rl/white)
    (rl/draw-text (string/format "holding: %p   [F] fly  [1-4] block  [~] console"
                                 (world/block-name (get placeable selected)))
                  16 84 18 rl/white)
    # Diffusion only: the pending/failed counts are the honest answer to "why
    # is there a hole in front of me", and the void-guard tally proves the
    # player is being held at the terrain edge rather than losing input.
    (when terrain-cache
      (rl/draw-text (string/format "terrain: tiles pending %d  failed %d  held %d"
                                   (length (terrain-cache :pending))
                                   (length (terrain-cache :failed))
                                   void-guard-hits)
                    16 106 18 rl/white)))
    # Crosshair is for the captured mouse in Play mode, not panel editing.
    (when (and (not clean-view) (not (con :open)) (= (editor :mode) :play))
      (def cx (/ (rl/screen-width) 2))
      (def cy (/ (rl/screen-height) 2))
      (rl/draw-rectangle (- cx 8) (- cy 1) 16 2 rl/white)
      (rl/draw-rectangle (- cx 1) (- cy 8) 2 16 rl/white))
    # GIMP-style docked material workspace: pointer controls only in Edit
    # mode. Its pure transition returns a requested effect; selecting or
    # changing a draft never changes blocks until explicit Apply.
    (when (and (= (editor :mode) :edit) (not (con :open)))
      (def outcome (inspector/draw-input editor panel-rl (rl/screen-width) (rl/screen-height)))
      (def effect (outcome :effect))
      (set editor (outcome :state))
      (when (= (editor :mode) :play) (rl/disable-cursor))
      (when effect
        (try
          (case (effect :type)
            :apply (do (use-materials (effect :entries))
                       (set editor (inspector/accept-apply editor effect)))
            :save (set editor (inspector/perform editor effect))
            :reload (let [path (effect :path)
                         revision (inspector/file-revision path)
                         replacement (recipes/load path)]
                      (when (not= revision (inspector/file-revision path))
                        (error "material file changed during Reload; retry"))
                      (use-materials replacement)
                      (set editor (inspector/accept-reload editor replacement revision))))
          ([err] (put editor :message (string "Material error: " err))))))
    # The console overlays everything, including the HUD.
    (console/draw con (rl/screen-width) (math/floor (/ (rl/screen-height) 2)))
    # Drawn last so it stays visible over the console: the point of the
    # readout is watching the frame rate respond to what you type.
    (when show-fps
      (def readout (string/format "%d FPS  %.2f ms%s"
                                (rl/get-fps) ms (if uncapped "  uncapped" "")))
      (def tw (rl/measure-text readout 20))
      (rl/draw-rectangle (- (rl/screen-width) tw 20) 8 (+ tw 12) 28
                         [0 0 0 170])
      (rl/draw-text readout (- (rl/screen-width) tw 14) 12 20
                    (cond (< ms 18) [0x90 0xf0 0x90 0xff]
                          (< ms 33) [0xf0 0xd8 0x60 0xff]
                          [0xff 0x90 0x80 0xff])))
    (rl/end-drawing)

    # --- Screenshot emission ---------------------------------------------
    # Two modes, deliberately different.
    #
    # WITHOUT `--capture-ready` this is the historical behaviour, unchanged byte
    # for byte: photograph the last frame the bound allows. Every existing 90-frame
    # capture test depends on that exact frame index, so it must not gain a
    # readiness test.
    #
    # WITH it, the frame bound becomes a FLOOR. The PNG is taken on the first
    # frame at or past the bound where `capture-ready?` says the resident set is
    # actually on screen -- every wanted chunk resident and the mesh queue
    # drained. The decision is membership, not counts, because that is the
    # difference between "1024 chunks loaded" (true at frame 1133 with 828 still
    # queued) and "what I asked for is being drawn".
    (if (not capture-ready)
      (when (and screenshot-path (= frame (- headless-frames 1)))
        (rl/take-screenshot screenshot-path))
      (when (not capture-done)
        (def dirty-count (length dirty-mesh))
        (def loaded-count (world/world-chunk-count w))
        (def ready-now
             (capture-ready? (get w :chunks) wanted loaded-count dirty-count
                             scenic-in-bounds?))
        (cond
          ready-now
          (when (>= frame (- headless-frames 1))
            (rl/take-screenshot screenshot-path)
            (set capture-ready-frame frame)
            (set capture-done true))
          # Bounded failure. An expired deadline does NOT write the PNG: an absent
          # file is unambiguous evidence the capture never became ready, while a
          # stale or half-built image is a picture that will be mistaken for the
          # map, and the next reader has no way to tell the difference.
          (and capture-deadline (>= (os/clock) capture-deadline))
          (do
            (set capture-failed true)
            (set quit true)))))
    (++ frame))

  (timing-printf (string "frames: %d  avg %.1f FPS (%.2f ms)  best %.2f ms  "
                  "worst %.1f ms  spikes >33ms: %d (%.2f%%)  edits: %d  %s")
          frame
          (if (pos? total-time) (/ (- frame 10) total-time) 0)
          (if (pos? total-time) (* 1000 (/ total-time (- frame 10))) 0)
          (if (< best 1e8) best 0)
          worst spikes
          (if (> frame 10) (* 100 (/ spikes (- frame 10))) 0)
          edits
          (if uncapped "uncapped" "vsync+60fps cap"))
  # Scene size is not optional context: a frame rate without the chunk count
  # it was achieved at says nothing. An unfinished stream looks fast simply
  # because there is little to draw.
  # The worst frame is reported with the CPU it actually burned. Wall time and
  # CPU time diverging is the signature of descheduling, not of a slow frame:
  # a stall is work this process did, while a suspension is time it was not
  # allowed to run. Reporting both is the difference between chasing a bug that
  # does not exist and knowing to look at the environment.
  (when (> worst 0)
    (timing-printf "worst frame: #%d  %.1f ms wall, %.1f ms CPU (%.0f%% busy), mesh queue %d"
            worst-frame worst worst-cpu
            (if (pos? worst) (* 100 (/ worst-cpu worst)) 0)
            worst-queue))
  (when (pos? (length stall-frames))
    (timing-printf "stalls >100ms: %d" (length stall-frames))
    (var shown 0)
    (each s stall-frames
      (when (< shown 8)
        (timing-printf "  frame %d: %.0f ms wall, %.0f ms CPU, queue %d, chunks %d"
                (s :frame) (s :ms) (s :cpu-ms) (s :queue) (s :chunks))
        (++ shown))))
  (when (pos? steady-frames)
    (timing-printf "steady: %.1f FPS (%.2f ms) over %d frames, reached at frame %d"
            (/ steady-frames steady-time) (* 1000 (/ steady-time steady-frames))
            steady-frames steady-frame))
  (timing-printf "scene:  radius %d  loaded %d  drawn %d  wanted %d  streamed in %d out %d%s"
          stream-radius (world/world-chunk-count w) drawn-count
          # The session's ACTUAL resident set, not a disc around the origin. A
          # scenic run wants the map rectangle (1024 on the valley map), so this
          # line used to print `wanted 797` -- a number no loader was ever trying
          # to satisfy -- while the capture gate correctly demanded the whole map.
          # `drawn` stays separate: it is frustum-culled draws, never a target.
          (capture-wanted-count wanted scenic-in-bounds?)
          streamed-in streamed-out
          (if culling "  (frustum culled)" "  (no culling)"))
  # The capture decision, stated in numbers. `ready` is whether a PNG was
  # written; `ready-frame` is WHEN readiness held, which separates "the gate
  # waited for the ramp" from "the world was already complete at the bound";
  # `queue` is the mesh backlog at the end. A capture log that does not carry
  # these cannot be distinguished from the frame-count guess this flag exists to
  # replace, so they are printed on the success path too.
  #
  # `wanted` is the CLIPPED requirement -- the count `capture-ready?` actually
  # tested -- never the raw request list, so these counters agree with the
  # `scene:` line by construction.
  (when capture-ready
    (printf "capture: ready=%s ready-frame=%s queue=%d loaded=%d wanted=%d frames=%d path=%s"
            (if capture-done "true" "false")
            (if capture-ready-frame (string capture-ready-frame) "none")
            (length dirty-mesh) (world/world-chunk-count w)
            (capture-wanted-count wanted scenic-in-bounds?) frame
            (or screenshot-path "none"))
    (when capture-failed
      (eprint (string "error: --capture-ready expired after " capture-timeout-arg
                      "s with " (length dirty-mesh) " mesh job(s) queued and "
                      (world/world-chunk-count w) " of "
                      (capture-wanted-count wanted scenic-in-bounds?)
                      " required chunk(s) resident; NO screenshot written to "
                      screenshot-path))))
  (when verify-pgo
    (assert (= frame headless-frames) "verification ended before its frame bound")
    (assert (>= (world/world-chunk-count w) 25) "verification lost spawn chunks")
    (var hash 5381)
    (var blocks 0)
    (var vertices 0)
    (def chunks (get w :chunks))
    (each key (sorted (keys chunks))
      (def ch (get chunks key))
      (when ch
        (set hash (pgo-hash-step hash (+ 1024 (key 0))))
        (set hash (pgo-hash-step hash (+ 1024 (key 1))))
        (def data (ch :blocks))
        (assert (= (length data) world/chunk-volume) "invalid verification chunk")
        (for i 0 (length data)
          (set hash (pgo-hash-step hash (get data i)))
          (++ blocks))))
    (each key (sorted (keys drawables))
      (when-let [d (get drawables key)]
        (when (d :mesh)
          (def n (get (d :mesh) :vertex-count))
          (set hash (pgo-hash-step hash n))
          (+= vertices n))))
    (each coord (p :pos)
      (set hash (pgo-hash-step hash (+ 1000000 (math/floor (* coord 1000))))))
    (set hash (pgo-hash-step hash edits))
    (set hash (pgo-hash-step hash frame))
    (printf "verify-pgo frames=%d seed=%d radius=%d chunks=%d blocks=%d vertices=%d edits=%d hash=%d"
            frame seed stream-radius (world/world-chunk-count w) blocks vertices edits hash))
  # Close the listener explicitly rather than relying on process exit: a dev
  # session that is restarted from the editor should not have to wait for the
  # old socket to time out.
  (when dev
    (printf "dev-server: served %d form(s)"
            ((dev-server/status dev) :served))
    (dev-server/close dev))
  # Session teardown, in the order that leaves nothing behind:
  #   1. the loading screen's textures are GL objects nothing collects, so they
  #      are released while the context is still alive;
  #   2. the worker WE spawned is killed and reaped -- a worker started by
  #      someone else is left running, because it is not ours to stop;
  #   3. the window closes last.
  # Save before anything is torn down, and while the world and player are still
  # alive. A quitting session that kept its terrain in memory only would lose
  # every edit the player made, and the catalogue's whole point is that a slot
  # survives the process.
  #
  # Skipped for a session with no slot (a CLI launch) and for scripted/verify runs,
  # whose bytes and timing are evidence: writing a snapshot from a --verify-pgo run
  # would mutate the tree its output describes.
  (def exit-save
    (save-on-exit! world-root active-slot w (player-pose p) world-settings
                   verify-pgo (not (nil? headless-frames))))
  (case exit-save
    :saved (printf "catalogue: saved %s on exit" active-slot)
    :skipped nil
    (eprint (string "warning: could not save on exit: " (get exit-save 1))))
  (when loading-screen-inst (loading-screen/dispose loading-screen-inst))
  (when terrain-worker :process (worker-stop terrain-worker))
  (rl/close-window)
  # Non-zero ONLY for the readiness timeout. A capture that never became ready
  # produced no file, and a CI step that ran it must fail rather than pass on the
  # absence of an image. Every other outcome keeps its existing status.
  (when capture-failed (os/exit 1)))
