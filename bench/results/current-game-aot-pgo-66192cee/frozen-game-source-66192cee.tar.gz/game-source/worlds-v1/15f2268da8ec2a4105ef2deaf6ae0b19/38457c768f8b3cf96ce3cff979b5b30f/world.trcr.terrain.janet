# Terrain generation identity for the region file beside this sidecar.
# Inert data: parsed, never evaluated. Delete this file to make the
# region's provenance unknown rather than silently assumed.
{
 :version 2
 :generation :diffusion
 :seed 12345
 :height 256
 :volume 65536
 :digest "6e97877c869b250e5ce1f7bbce60697d2bea239568e7dd53c1e57c5d12742372"
 :region-crc 391204424
}
