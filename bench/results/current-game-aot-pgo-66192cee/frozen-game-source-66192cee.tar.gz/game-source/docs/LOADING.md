# Terrain loading screen

## Behaviour

A diffusion session opens its window before waiting for spawn terrain. It displays the user's local images from `assets/`, cycles every eight seconds with a one-second fade, and shows actual decoded spawn-tile readiness, elapsed time and stage text. Images are concept-art backgrounds, not screenshots or promises about the generated world.

**There is no automatic generation timeout**, for interactive or scripted loading. Slow inference may take minutes. Esc cancels. Confirmed launch/model errors are shown instead of silently substituting noise. `--loading-timeout SECONDS` and `--loading-frames N` are explicit QA controls only; `--frames N` counts gameplay frames separately and never bounds a model query.

The loading path probes a bounded number of coordinates per frame and builds chunks incrementally. Once height tiles are validated, it searches loaded terrain for dry support and body clearance, then renders progress between mesh batches. Final scenic placement remains deferred until biomes and features exist. An ocean-only search can fail clearly; it never knowingly spawns underwater or manufactures an island.

## Launch

From the project root, with the pinned upstream assets installed as described in `TERRAIN_DIFFUSION.md`:

```sh
./run.sh \
  --terrain-cache tmp/terrain-final-real/1d1867a350d3786f84f902b6335242aae0850dfa4d5c761d103789277944c7cf \
  --seed 12345
```

The game takes the **full identity directory**. If spawn tiles are missing, it starts the Python trial worker with `worker --from-identity <directory>` and a launch nonce. Python recomputes pinned identity and acquires identity/device locks; another owner is joined via an explicit per-launch result, not inferred from stale `:idle` status. Only the child this game spawned is stopped/reaped on exit. A reused external owner is not killed.

Use `--terrain-python /path/to/python` to override the local trial interpreter. That interpreter needs the original model/runtime dependencies. `--no-terrain-worker` disables autolaunch and waits for an external publisher; the UI says so. `--loading-background /path/to/image` can be repeated to override discovery.

Models are not embedded in the native executable. The current supported path is original Python/PyTorch inference plus Janet voxel consumption. Native Janet orchestration/model runtime or a remote terrain provider are production follow-ups. Model acquisition must remain an explicit, pinned, integrity-checked setup step.

## Local artwork

The current local `assets/` directory has four Gemini-generated PNGs, including the forest/ruins and cave/adventure backgrounds inspected during QA. They are locally supplied and git-ignored, not committed redistributable assets. No licence beyond their local availability is asserted. Missing or corrupt images fall back to a gradient. Texture decode/upload is incremental, and owned textures are released on success, failure and cancellation.

## Verification record

- Default Janet suites, including loading-screen and spawn tests, passed after the explicit-only timeout fix.
- Python terrain suites: 230 tests passed for lock contention, recomputed identity, staged status, per-launch receipts and related cache checks.
- Real raylib rendering inspected at `tmp/loading-cycle-a.png` and `tmp/loading-cycle-b.png`: first forest, then cave after an actual timed wait. `tmp/loading-integrated-cycle-final.png` shows the second backdrop in the integrated missing-tile stage.
- A synthetic 24/25-tile fixture with an existing request marker received its final tile after 2.5 seconds, completed loading and then ran **90 gameplay frames**. Both `tmp/loading-transition-ready.png` and `tmp/loading-transition-game.png` were opened and inspected. This specifically catches accidental reuse of the gameplay frame budget for loading.
- An isolated copy of the actual pinned cache, `tmp/loading-real-trial/1d1867a350d3786f84f902b6335242aae0850dfa4d5c761d103789277944c7cf`, deliberately lacked `0_0.tdh`. The original cache was untouched. An autostarted worker generated that missing tile, reached gameplay, continued serving requests, and stopped on session exit. Log: `tmp/loading-real-no-timeout.log`.
- Real trial outcome: **76 tiles published, zero worker errors**; cache grew from 25 existing tiles to 101. The game loaded 96 chunks and streamed in 71 during its 60-frame run. Twelve request markers remained when the bounded gameplay QA session ended. These are finite-run results, not unlimited-world or cross-device determinism claims.
- Actual real loading and gameplay screenshots were opened and inspected: `tmp/loading-real-ready-no-timeout.png`, `tmp/loading-real-game-no-timeout.png`.
- Real gameplay trial mean 24.89 ms/frame, worst 50.1 ms, 11 spikes above 33 ms while meshing/streaming. This is **not a smoothness or 60 FPS guarantee**. Inference and raylib share MPS/GPU resources.

An earlier explicit-timeout trial failed prematurely because code multiplied accumulated frame count by the current frame delta. That was not elapsed time. The final code has no implicit deadline; an explicitly requested QA timeout uses a clock difference. No claim that the earlier failed trial generated terrain is retained.

## Remaining limits

A hard-killed worker can leave a stale status snapshot. Receipts describe observed ownership/outcomes, not perpetual liveness. If a worker crashes without a terminal error during an unbounded wait, Esc remains the escape; stronger live-process monitoring is a follow-up rather than a fabricated inactivity deadline.

Local filesystem operations are synchronous even though file sizes and per-frame counts are bounded. Shared-MPS smoothness, long-traversal behaviour and the historical legacy-cache discrepancy remain unresolved. See `TERRAIN_VALIDATION.md` for earlier terrain integration evidence and `WORLD_GENERATION_STAGES.md` for the next climate/biome foundation.
