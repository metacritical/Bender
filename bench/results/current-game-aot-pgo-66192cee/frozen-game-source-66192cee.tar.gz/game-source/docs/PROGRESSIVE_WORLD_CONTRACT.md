# Progressive world contract (`tds4-progressive/1`) — design, not yet shipped

**Status: contract design plus a model-free validator. Nothing is integrated.**
No game session reads this, no worker produces it, no tile is written under this
contract, and no existing artifact changes. `tools/progressive_world.py` is a
pure module: standard library only, no torch, no numpy, no subprocess, no GPU.

The problem it addresses: a **TDS3** scenic map is a *finite* artifact. It has
edges, and `main.janet` deliberately refuses to start a terrain worker for one
(`maybe-start-worker-allowed?` returns false whenever a map is open), because
streaming diffusion tiles into a configured world would mix two terrains in one
landscape. Travelling beyond the initial footprint therefore needs a different
product, not a bigger TDS3 map.

## What this contract is and is not

It **is** a named, versioned, hashed description of a world that can grow by
patches, plus the state machine and the validation rules a future scheduler must
satisfy to publish one.

It is **not** a runtime worker, a scheduler, a persistent process, a Janet
integration, a new package, or a change to any existing producer or format. TDS3
and TDH2 identities, tiles, manifests and saved worlds are untouched: this
contract owns its own `contract` string and its own digest, so nothing here can
be mistaken for an existing artifact.

## 1. Identity

Two digests, deliberately different in scope.

### `world_identity` — what world this is

A canonical SHA-256 over a record that is **frozen at creation** and never
depends on where the player has travelled:

| Field | Why it is pinned |
|---|---|
| `contract` | `"tds4-progressive/1"`: a different contract is a different world |
| `seed` | the model seed actually sampled with (never a random draw) |
| `model{repo, revision, config_sha256, configset_sha256, weightset_sha256, stats_sha256}` | weights, configs and the frozen conditioning table are the world's physical law |
| `query{strategy, origin_pixels, window_chunks, window_pixels, max_samples, pixels_per_voxel}` | the exact window geometry the backend samples; a different window is a different terrain |
| `mapping{meters_per_voxel, sea_level, baseline_elevation_m, height_min, height_max}` | the global elevation transfer; must equal the `HeightMapping` the world quantizes with |
| `climate{policy_version, container_version}` | which climate policy may ever attach; a policy change is a new world |

**No coordinate, request, batch, timestamp or player position appears here.** A
patch far from the origin cannot change the world identity, and neither can
request order. That property is the whole point: identity must not encode the
query plan.

The mapping is checked against the `terrain_cache.HeightMapping` actually used,
so a world cannot claim one transfer and quantize with another. Canonical JSON
and the SHA-256 come from `terrain_cache` (`_canonical_json`, `identity_digest`);
this module does not write a second hasher or a second manifest format.

### `patch_identity` — what one patch is

A canonical SHA-256 over `{contract, world_identity, cx, cz, staging}` where
`cx`/`cz` are **signed int32 chunk coordinates** validated by
`terrain_cache._require_chunk_coord`, and `staging` fixes the window geometry and
halo used to produce it.

A patch identity **must not** vary with which other patches were requested
alongside it, their order, or the batch boundary. Two runs that request patch
`(0,0)` alone and inside a 5×5 batch must compute the same `patch_identity`,
exactly as `sample_chunks` already guarantees a chunk's heights are
batch-independent.

## 2. Canonical anchors — corrected

Patches are anchored to the global signed grid by **floor** division:

```
anchor(c) = (c // window_chunks) * window_chunks
```

Floor is what keeps negative coordinates on the same lattice as positive ones.
The consequence is *not* that neighbouring chunks share an anchor at zero:

| chunk | anchor (w=4) |
|---|---|
| `-9` | `-12` |
| `-5` | `-8` |
| `-4` | `-4` |
| `-1` | `-4` |
| `0`  | `0` |
| `3`  | `0` |
| `4`  | `4` |

So `-1` and `0` **do not** share a window: `-1 → -4` and `0 → 0`. An earlier
audit note in this repository claimed they did; `test/test_progressive_world.py`
pins the real behaviour, including the negative cases and the exact `-4`/`-1`
pairing, so the wrong claim cannot silently return.

This also means a world's window grid has a **seam at chunk 0** that a naive
"anchor everywhere" reading hides. Any future scheduler must treat it as a real
boundary, not assume window continuity across the origin.

## 3. Bounds and staging halo

Every patch is bounded at declaration time:

- `window_chunks` — chunks per axis in one patch window;
- `max_samples` — the hard cap the existing `Query` already enforces
  (`window_pixels = window_chunks * 16 * pixels_per_voxel` must be
  `<= max_samples`);
- `halo` — the staging overlap, in chunks, sampled but **not published**. The
  halo exists so adjacent patches are produced from overlapping model input
  rather than abutting ones.

The halo is recorded, not assumed. Nothing in this contract claims the halo
makes seams invisible — see §6.

## 4. Queue and state machine

One inference owner per world identity. A patch moves through exactly:

```
queued → inflight → validated → published
                  ↘ failed
         ↘ cancelled
```

- **queued** — declared, bounded, no model work started.
- **inflight** — one owner holds the patch. Two owners for the same
  `patch_identity` is a contract violation, not a race to win.
- **validated** — every tile of the patch decoded and passed the band and
  shape checks. **Nothing is released to readers yet.**
- **published** — the patch is visible. Publication is atomic at the patch
  granularity: either every tile in the patch is released or none is. A
  partially written patch is never observable as published.
- **failed** — terminal, carrying a reason. Note in particular the ocean case:
  a patch whose whole elevation range lies below the supported band is
  `failed`/`all_clipped`, exactly as the one-shot producer already refuses a
  clipped map. It is **not** silently clamped into a flat seabed world and it is
  not evidence about another seed.
- **cancelled** — terminal, ownership released, nothing published.

Ownership carries a `revision` epoch. A patch produced under a stale revision is
discarded rather than published, so a restarted owner cannot resurrect work that
was cancelled while it was inflight.

## 5. Climate

`climate.policy_version` is part of the world identity. A world that pins no
policy is a world where climate is inert, which is the current state: the
`f7dd22c`/`b478538` container and the loader's `load!` exist, but nothing
attaches climate in a running scene. **Enabling climate surfaces in a world is a
new world identity, not a setting on an existing one**, and it requires a
verified generation-profile revision.

A progressive patch carries climate only if the world pins a policy. The
container itself is unchanged: `climate.f32` plus its declared block, exactly as
the finite TDS3 path writes it.

## 6. Seam verification — stated, not proven

What is actually established today:

- A chunk's heights are a pure function of `(query, global voxel)`, and windows
  are fetched whole, so a chunk is identical whether requested alone or inside a
  batch (`sample_chunks`, `window_payloads`). This is pinned by existing tests.
- Upstream produces overlapping tiles internally (`TILE_STRIDE = TILE_SIZE - 16`)
  and blends them; the blend is upstream's, not this project's.

What is **not** established, and what this contract therefore does not claim:

- that two adjacent patches join without a visible seam;
- that the upstream overlap blend is exact at a chunk boundary;
- that a halo of any particular size makes a seam unobservable.

A future scheduler must earn that claim with a **real adjacent-patch test**: bake
a chunk alone, bake the same chunk as part of its neighbour's batch, and compare
the published tiles byte for byte. Until that test exists and passes, no surface
may state seam determinism. This contract supplies the identities that test
would compare; it does not substitute for it.

## 7. Tests in this change

`test/test_progressive_world.py` is model-free and covers:

- floor-division anchors including negatives, and that `-1`/`0` are distinct;
- world identity is stable under request order, batch size and player position,
  and changes when seed, mapping, query geometry or climate policy changes;
- patch identity ignores batch composition but changes with coordinates;
- the `max_samples` / `window_pixels` bound is enforced, not hoped for;
- signed int32 coordinates are required, so an out-of-range coordinate cannot
  alias a valid one;
- the state machine rejects illegal transitions (publishing an unvalidated
  patch, double ownership, publishing after cancel);
- the world identity digest matches `terrain_cache`'s own canonical hashing, so
  a second hasher has not appeared.

## 8. Deliberately not in this change

No worker, no queue runner, no persistent process, no model load, no GPU, no
Janet scheduler, no `main.janet` edit, no new package, no tile writer, no change
to TDS3 or TDH2 identity, no change to compiler pin `c07042a7`.
