# Reference-led startup artwork verification

## Asset roles

- `assets/Trinexraft_main.png`: dedicated static title-screen poster. Its baked logo, subtitle and characters remain visible; New Game and Load Game are real menu controls drawn over it.
- `assets/trineraft_main_loader_sampel.png`: visual reference only, not a live loading backdrop. Its baked loading bar is not displayed as progress.
- Four existing `assets/Gemini_Generated_Image_*.png` files: bounded loading slideshow. Actual progress, state and tips are drawn over these backgrounds.

The presenter owns the main poster separately from slideshow textures, is shared across menu/loading, and releases textures on quit or handoff. Missing artwork retains the functional menu and gradient fallback. Artwork is promotional presentation, not an in-game terrain preview.

## Native captures inspected

All paths below are local QA artifacts, not committed images:

- `tmp/trinexraft-main-poster.png`: dedicated artwork, unobstructed baked title/subtitle and centered stone-framed New Game / Load Game controls. Load remains visible with an explanation when no slots exist.
- `tmp/trinexraft-new-art.png`: creation form and four generation controls remain readable over the dimmed main artwork.
- `tmp/trinexraft-load-art.png`: saved-world list remains readable over the dimmed main artwork.
- `tmp/trinexraft-loader-final.png`: loading slideshow background, stone/moss frame, cyan/purple illuminated progress fill, real completion state and contextual tip. The capture used an existing ready cache and reported `ready=25/25`, not model inference.

The loading design emulates the sample's framed bottom progress bar, luminous cyan/purple fill and tip placement; it does not claim pixel-identical reproduction or sample-only gameplay abilities.

## Verification

- Compiled `build/trinecraft-worlds` successfully with the final presentation changes.
- Ran the complete default `./run.sh test` suite successfully; log: `tmp/trinexraft-final-art-tests.log`.
- Inspected each native capture listed above rather than accepting stub-only rendering checks.
- Connected native mouse-position/button functions to the title-screen hit-testing adapter in `1207fff`. Keyboard navigation remains supported. Automated adapter tests cover mouse hit-testing; a physical mouse interaction was not independently verified.
- A ready-state capture does not by itself prove an entire slideshow cycle. Timing, fallback and texture ownership are covered by the loading/menu tests.

## Launch-directory-independent discovery

Startup artwork now resolves in this order: `--asset-root DIR`,
`TRINEXRAFT_ASSET_ROOT`, assets beside an absolute executable, assets one level
above it (the checkout build layout), then the legacy cwd/assets fallback.
`DIR` is the assets directory itself. An invalid explicit/environment override
does not silently choose another directory; the menu remains functional without art.

The native binary was launched by absolute path with cwd `/tmp`.
`tmp/round5-outside-cwd-title.png` was opened and inspected: the dedicated title
poster and New/Load controls rendered correctly. No model inference ran.
Resolver fixture checks include paths with spaces and refusal of invalid overrides.
This asset resolver currently handles macOS/Linux slash paths, not Windows drive
syntax. Terrain runtime/model discovery remains a separate contract.

## Reproduce

```sh
./run.sh build build/trinecraft-worlds
./build/trinecraft-worlds --menu-qa --menu-frames 90 --screenshot tmp/title.png
./build/trinecraft-worlds --menu-qa --menu-screen new --menu-frames 60 --screenshot tmp/new.png
./build/trinecraft-worlds --menu-qa --menu-screen load --world-root tmp/worlds-shipping-qa --menu-frames 60 --screenshot tmp/load.png
```

A normal `./build/trinecraft-worlds` launch opens the interactive title menu without QA frame limits.

Native learned generation remains unavailable pending complete model-pipeline verification and packaging; these presentation changes do not alter that gate.
