# Terrain diffusion integration validation

## Scope

This is a Python/PyTorch inference integration with the Janet/Bender game, **not a native Janet port of the neural inference stack**. Actual pretrained terrain feeds gameplay. Procedural noise remains the default unless `--terrain-cache` is selected.

## Reproducible local configuration

- Upstream code: `e8dcb4b1a834ab2f6b1a6f5256ed7c9f2f3e8230`.
- Model: `xandergos/terrain-diffusion-30m`, revision `9ef8030cb805b433b98ec25c5dddefbac07a9e26`.
- Device/dtype: Apple M2 Pro MPS / fp32; seed 12345.
- Frozen official conditioning table canonical SHA-256: `528754ea8203928364cccd931686ec87612b1eefba44ef7956293f33a68bdbe3`.
- Global native-pixel origin: `[100000, 100000]`; one pixel per voxel.
- Canonical query: four chunks / 64 native pixels per axis; decoder 512/384; T=2.
- All three safetensors, all four model configs, upstream source and local FastNoiseLite binary are checked and bound into the identity. The FastNoiseLite build is bespoke; official binary parity is not claimed.
- Final identity: `1d1867a350d3786f84f902b6335242aae0850dfa4d5c761d103789277944c7cf`.
- Cache directory: `tmp/terrain-final-real/1d1867a350d3786f84f902b6335242aae0850dfa4d5c761d103789277944c7cf`.

The local interpreter is `tmp/terrain-runtime/venv/bin/python`. Assets and generated caches are ignored artifacts, not committed model weights.

## Actual learned evidence

1. A final bake published all 25 spawn tiles, chunks `[-2,3) × [-2,3)`. Python independently decoded every tile with CRC-32 and SHA-256; Janet independently read all 25 through its TDH2 consumer. Heights are 50–60, all land.
2. The final 25 payloads are byte-identical to an independent earlier fully weight-bound run with identical numerical settings. Adding the config-content commitment changed identity metadata, not the model inputs.
3. A fresh process sampled negative chunk `(-1,-1)` and matched its batched payload byte for byte (256 heights); measured load + sample time was 108.08 s.
4. A persistent request worker consumed `requests/3_0.req`, generated one tile outside the spawn bake, removed the request, and reported `ticks=1, tiles=1, errors=0`. The final tile is byte-identical to an independent prior worker result and its earlier positive-coordinate batch result.
5. Adjacent spawn tile border heights differed by at most one voxel in the inspected inland bakes. Border samples are adjacent columns, not duplicate samples; this is a continuity check, not proof that arbitrary terrain must be flat at boundaries.
6. A fresh persistent pipeline sampled `(0,0)`, `(-1,-1)`, `(0,-1)`, `(-1,0)`, then `(-1,-1)` again. **All five payloads matched the independently baked cache byte for byte** (0 differing heights), despite a different window order and warm-cache reuse. First query: 101.94 s; subsequent queries: 0.013–0.017 s; total including model load: 111.77 s. Evidence: `tmp/terrain-real-order-test.log`.

An older pre-weight-binding cache (`33f07baf…`) has 573 one-voxel differences across 12 negative-coordinate tiles relative to later runs. Its mixed generation history was not established, so it is **not** used as determinism evidence or as the supported continuation cache. This historical discrepancy is not silently treated as resolved. The final independent repeat and selected positive/negative checks above passed; they do not establish cross-device bit equality.

## Game and build

Fresh native build:

```sh
CPATH=/Users/pankajdoharey/Development/Projects/janet/src/conf \
JANET_NO_PROFILE=1 ./run.sh build build/trinecraft-terrain
```

Actual learned-cache capture (not a synthetic fixture):

```sh
./build/trinecraft-terrain \
  --terrain-cache tmp/terrain-final-real/1d1867a350d3786f84f902b6335242aae0850dfa4d5c761d103789277944c7cf \
  --seed 12345 --frames 120 --screenshot tmp/terrain-final-real-game.png \
  --sky-view terrain --uncapped
```

The image was opened and inspected: grass-covered voxel hills with a height-clamped plateau and finite loaded-world edges. This is not a vast scenic terrain demo. The QA viewpoint is an existing sky camera preset; it does not change model terrain.

Final capture: 120 frames, **6.79 ms mean, 225.6 ms worst**, one wall-time stall (about 4 ms CPU during that frame), 25 loaded chunks, 113 wanted, 64 pending requests, no worker errors. Its cause was not proven. These numbers do **not** establish stutter-free play or cold-inference performance. An earlier real-cache capture measured 5.75 ms mean / 17.7 ms worst, but used the earlier build and fewer reachable tiles; do not substitute it for the final result.

The consumer performs synchronous local filesystem I/O with bounded counts and byte reads. Inference runs in a separate serial process; no cold model call occurs on the render thread. Unavailable terrain is not replaced by noise, and movement is guarded against missing chunk columns.

## Checks run

- `JANET_NO_PROFILE=1 ./run.sh test`: all default suites pass, including height adapter, CRC, sidecar, consumer and main integration suites.
- `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s test -p 'test_terrain*.py' -q`: **194 tests pass** at `b55ba01` — 114 backend, 80 cache. Includes rejection of empty pin tables and rejection of a drifted official-stats constant.
- Native build and actual learned-cache game capture: exit 0.
- Wrong-seed native invocation: exit 1 before display initialization.
- Corrupt/missing tiles, bounded polling, queue rotation, stale results, invalid requests and worker load failures have focused tests.
- Saves validate the generator and region CRC; loads decode the exact gated buffer before mutating the world. Unknown legacy provenance is preserved rather than labelled with a guessed seed.
- Ripwire does not index the Janet files here, so its Janet test gate is unavailable; actual Janet suites and native compilation are the verification. Python structural checks flag size/parameter/test-duplication debt; no claim of a clean maintainability score is made.

## Operational limits

Cold inference is approximately 100–110 s for the measured regions on this machine; a spawn bake takes minutes. MPS emitted `ImpactingInteractivity` warnings in some successful runs too. Earlier runs stopped by the operator are not evidence of a model crash or proof that a particular query size is unsupported. Do not run inference concurrently with interactive visual QA on this shared GPU.

Use one exact flag set for `init`, `bake` and `worker`. `worker` requires an existing identity and refuses flag drift. Older identities can still be read by the game but cannot be extended using a newly strengthened identity. Do not rename a cache or rewrite its manifest to force a match.
