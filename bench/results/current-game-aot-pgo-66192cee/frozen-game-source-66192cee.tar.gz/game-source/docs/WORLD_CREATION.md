# World creation — what the front door actually does

This page describes the New Game / Load Game feature **as it is implemented
today**. It is not a roadmap; the plan lives in `docs/PLAN.md`.

## Launching it

```sh
./run.sh                          # normal launch: the menu is the front door
./run.sh build build/trinecraft-worlds
./build/trinecraft-worlds         # the binary opens New Game / Load Game
```

A plain launch with no world-naming flag opens the menu at its home screen
(`main.janet:968-990`, `src/world-menu-view.janet:368`). The menu is deliberately
**bypassed** by every run that already named its own world: a
`--terrain-cache`, a scenic map (`--scenic-view`), `--verify-pgo`, `--no-menu`,
`--new-world`, `--world-slot`, or any scripted/headless run. Those are
deterministic by design, and a menu would make them wait for a human who is not
there.

## Screens

`src/world-menu.janet` owns the state machine (`:home`, `:new`, `:load`,
`:error`); `src/world-menu-view.janet` paints it. Nothing in the menu decides
what a world *means* — it emits a request which the game then executes.

**Home** (`src/world-menu.janet:375-379`): *New game* and *Load game*. *New
game* is enabled only when an available provider exists; *Load game* only when
the catalogue has at least one world.

**New** (`:new`): a name field, a seed field, and the generator settings for the
selected provider. *New world* is procedural-only today.

**Load** (`:load`): the catalogue, paginated, one row per world.

## Keys

| Key | Effect |
|---|---|
| `Tab` | Cycle focus: name → seed → each setting |
| `↑` / `↓` | Move focus (or the selected world on Load) |
| `[` / `]` | Decrease / increase the focused setting |
| `F2` | Toggle random seed, from anywhere on the form |
| `Enter` | Open / confirm; on the name field it advances to the seed |
| `Esc` | Back one screen; quit from home |

Text entry goes to the focused field. `Tab` never changes a value, so there is
exactly one key that moves the caret (`src/world-menu-view.janet:317-336`).

Settings are adjusted with **square brackets**, not the arrow keys: the menu binds
`:dec`/`:inc` to `rl/key-left-bracket` and `rl/key-right-bracket` (GLFW 91 and
93) at `main.janet:2883`, and the view only calls them when focus is not a text
field (`src/world-menu-view.janet:324-328`). The arrows move focus.

## Seeds

`src/world-seed.janet` is the whole contract, version 1.

- **Input** is arbitrary **UTF-8 text**, or ASCII decimal, or a random draw. It
  is trimmed of outer ASCII whitespace first.
- **Numeric** means an optional `+`/`-` and one or more ASCII digits and nothing
  else. Leading zeros are the same number: `00042` is `42`. `1e5`, `0x10`,
  `12.0` are **text**, not numbers.
- **Everything else is text**, hashed over its UTF-8 bytes with CRC-32 under the
  domain tag `text-v1:`. The tag keeps a text seed from colliding with the
  numeric reduction of the same characters.
- **Unicode is not normalised.** `é` as U+00E9 and as `e`+U+0301 are different
  worlds by explicit design — a normalisation form would have to be versioned
  and stored to be safe.
- **Blank is not a seed.** It is an error; "random" is its own affordance, so an
  empty field can never silently mean zero.
- **Random** draws 4 bytes from `os/cryptorand`, assembles them big-endian, and
  drops the top bit rather than masking it modulo 2^31 (which would bias low
  values). The entropy bytes are stored, so a random world can be described down
  to the bytes that made it.

Every path ends at **one unsigned 31-bit integer, `0..2147483647`**
(`src/world-seed.janet:46-47`). That range is not a UI convenience: the
generator reduces every seed through `worldgen/i32` and mixes it modulo
2^31−1, so a wider value would be silently re-wrapped anyway. **31 bits means
collisions are inherent** — roughly 2^31 distinct worlds, and two different seed
strings can name the same world. The catalogue stores the resolved integer as
authoritative and never re-hashes saved text on load, so a future hash revision
cannot make an existing world unopenable or silently change its terrain
(`src/world-catalog.janet:81-86`).

## Settings

Four generation controls, defined once in `src/world-provider.janet:8-18`:
`height-scale` (relief scale, 0.5–2.0), `height-offset` (−16–64), `sea-level`
(0–128), `forest-density` (0–100). They belong to a versioned provider
descriptor; the default settings reproduce the shipped generator's bytes
exactly.

## Providers, and what is honest about them

`src/world-provider.janet:19-24` registers two providers:

| Provider | State |
|---|---|
| `:procedural` *Native procedural* | **available** |
| `:terrain-diffusion-native` *Terrain Diffusion (native)* | **`available false`, version 0, no controls** |

The learned provider is **deliberately disabled**. It is not hidden and it is not
faked: it appears in the registry as `available false`, `validate-settings`
refuses it (`src/world-provider.janet:35`), and the catalogue refuses any slot
whose `:provider` is not `:procedural` (`src/world-catalog.janet:129-132`). There
is **no silent fallback** from a learned world to a procedural one.

What *is* true natively: the three pinned ONNX graphs each run a forward pass
through ONNX Runtime via FFI with no Python in the call path
(`native/proof/README.md` §1), and a native pipeline runs end to end — 20
DPM-Solver++ steps, conditioning standardisation, and coordinate-seeded noise
verified bit-exact against `gaussian_noise_patch` on three seeds and all six
channels (`d3f02ae`).

What is **not** true is the geometry. An earlier "within 8 % of upstream"
agreement was **retracted** (`29b8599`): the oracle behind it was a hand
reimplementation, not upstream. At origin `100000`, seed `12345`, the real
`WorldPipeline.get()` returns elevation **+1081 … +1785 m**, while the native
pipeline produces **−1290 … −695 m** — opposite sign and a different surface,
not a rounding difference. The source conditioning and window geometry are
therefore still wrong, and real oracle hooks plus an independent geometry review
are ongoing. The provider stays unavailable until that is resolved and the
runtime is packageable.

## Saving and the catalogue

`src/world-catalog.janet`. Root is `worlds-v1` by default (`--world-root`
overrides). Layout:

```
<root>/<32 lowercase hex slot id>/manifest.janet      inert, parsed never evaluated
<root>/<slot>/<32 hex snapshot id>/world.trcr         the region
<root>/<slot>/<snapshot>/world.trcr.terrain.janet     identity sidecar
```

A new slot is built in a hidden staging directory and published by one rename. An
update writes the region and sidecar first and moves the **manifest pointer
last**, so a crash leaves the previous snapshot intact. Only `current` and
`previous` snapshots are retained — pruning touches only 32-hex directories
holding exactly those two known files, never anything it did not create.

**A session saves on exit.** When the window closes, `main.janet:4611-4619`
writes the slot through `catalog/save-slot` before any teardown, while the world
and player are still alive, and reports `catalogue: saved <id> on exit`. So a
created world is not frozen at its creation snapshot: edits made while playing
survive the process without anyone typing `(save)`. The automatic save is
**skipped** for a session with no slot (a plain CLI launch) and for scripted or
`--verify-pgo` runs, whose bytes and timing are evidence and must not be
mutated. `(save)` from the console still works, and takes precedence for an
explicit destination.

`manifest.janet` is **strict**: an exact key set, exact dimensions
(`:height 256`, `:volume 65536`), the region's CRC-32, a canonicalised settings
block, and a `:settings-identity` string that is recomputed and compared. A
mismatch refuses the load. There is no managed migration path.

**These are integrity checks, not authentication.** CRC-32 detects accidental
corruption and a region/sidecar pair that no longer match; it does not prevent a
deliberate edit. There are no signatures anywhere in this format.

## Region format

`world.trcr` is **TRCR v2**: a 20-byte header (`magic`, `version=2`, `count`,
`height=256`, `volume=65536`), a 16-byte-per-chunk index, and palette-compressed
payloads (`src/region.janet:1-20`).

**v1 is refused, never migrated.** A v1 file raises
`legacy TRCR v1 uses 64-high chunks; migration required, refusing to pad old
world` (`src/region.janet:99-100`). Old saves cannot be loaded by this build;
there is no automatic conversion, and the refusal is deliberate rather than a
missing feature.

## QA entry points

These exist for CI and for a machine where nobody can click. They **build the
same request the menu builds and then run the same code**, so the path they
exercise is the player's path — not a parallel one (`main.janet:2859-2872`).

```sh
./build/trinecraft-worlds \
  --new-world "Native QA custom seed" \
  --world-seed "Valley ! 🦋 42" \
  --world-root tmp/worlds-shipping-qa \
  --frames 60 --screenshot tmp/out.png
```

`--world-slot <id>` is the load counterpart. Note precisely what this is: a
**scripted controller request, not keyboard QA**. Nobody pressed Tab or typed
into a field; the flags supplied the answers the menu would have supplied.

## What was actually verified, and what was not

Verified by running it:

- The menu renders its home screen with the correct title
  (`tmp/worlds-home.png`).
- The **New Game form renders correctly in the fresh native build**
  (`tmp/worlds-new-final.png`, 1280×800, opened and inspected). It shows the
  Name and Seed fields with their `F2` random toggle and the `Tab`/`Enter`
  affordances; the *Native procedural* provider marked available and *Terrain
  Diffusion (native)* marked unavailable; and the Generation settings — Relief
  scale `1`, Elevation offset `0`, Sea level `28`, Authored forest density `0`.
- The **Load Game catalogue renders with a real entry**
  (`tmp/worlds-load-list.png`, 1280×800, opened and inspected): the created world
  appears as a `Native QA custom seed` row, with `Enter` to open and `Esc` to go
  back.
- `--new-world` + a UTF-8 seed (`Valley ! 🦋 42`) created slot
  `b3b1a5f72746ff8036eb8ae88b0dfc7d` under `tmp/worlds-shipping-qa`, resolving
  to seed **95677243**, with 25 chunks written and a TRCR v2 header at height
  256 (`manifest.janet` on disk).
- `--world-slot b3b1a5f7…` reloaded that world successfully.
- The shipped binary is an **AOT image**, not compiled game logic: it embeds
  Janet bytecode and still loads raylib through FFI at runtime
  (`run.sh:67-68`). A whole-game build reports **six lowered kernels**; the
  smaller seed-parity probe reports **zero**, because it exercises different
  code paths. `docs/PLAN.md:201` records the `native-lib 0 kernels` line from
  that probe-era measurement and must not be read as the whole game's count.
- `./run.sh test` runs **27 suites** (`run.sh:48`), including `world-seed`,
  `world-catalog`, `world-session`, `world-provider`, `world-menu` and
  `world-menu-view`; the parent reports them green.
- Capture provenance, recorded so the two images are not confused: an earlier
  `tmp/worlds-new.png` came out blank and is **superseded**. The cited New Game
  evidence is `tmp/worlds-new-final.png`. A capture-ordering change (screenshot
  after `EndDrawing`, the window carrying a 4× MSAA hint) landed in `b54785b`; whether
  it explains the blank frame is **not asserted** — that was not proven from a
  diff-and-rerun.

**Not verified, and not claimed:**

- The 7-edit scripted QA run persisted nothing — but because a scripted run
  (`--frames`) deliberately skips the exit save, not because saving is absent.
  Interactive play does save on exit.
- No human has completed a keyboard-driven create-and-play session end to end.
  The form's layout and key labels are visually confirmed; the keys themselves
  are exercised by the suite, not by a recorded hand-driven run.

## Interaction with everything else

Existing command-line use is unchanged: `--terrain-cache` and the scenic path
still bypass the menu and generate exactly what they did before. The catalogue is
additive — a raw `.trcr` outside `worlds-v1` is not listed by Load game, and is
neither modified nor deleted. A previous-era save that is not a TRCR v2 region
simply cannot be opened from this catalogue; there is no path that upgrades it
automagically.
