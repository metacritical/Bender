# Scenic map — the delivered artifact and how to rebuild it

One hand-built map from the pinned model, plus the exact commands that reproduce
it. This page describes **what was actually produced**. It is not a general guide
to scenic terrain; see [`TERRAIN_DIFFUSION.md`](TERRAIN_DIFFUSION.md) for the
streaming backend, which is a separate product and is unchanged by any of this.

## The delivered artifact

```
tmp/scenic-valley/27d25d28e4c2931106b2ee86ea3be45232a91dff92dc32e80369e039102a19c9/
  manifest.janet            264 B, 12 keys   the twin the game parses
  manifest.json                              same, as canonical JSON
  provenance.json          2573 B            CRC-bound map record
  summary.json                              import report
  tiles/                    1024 files       <cx>_<cz>.tdh, 308 B each
```

| Property | Value |
|---|---|
| Map identity | `27d25d28e4c2931106b2ee86ea3be45232a91dff92dc32e80369e039102a19c9` |
| Format | **3** (`TDS3`), band `4..252`, 308-byte tile, 256-byte payload |
| Tiles | **1024**, contiguous 32 × 32 chunks |
| Bounds (inclusive) | `[-16 -16 15 15]` |
| World origin (voxels) | `[-256 -256]` |
| Sampling origin (pixels) | `[100000 100000]` |
| Mapping | `meters_per_voxel 5.0`, `baseline 750.0`, `sea_level 28`, profile `alpine-watershed-v1` |
| Heights in the map | **37 .. 231** (0 clamped at either end) |

**Validation, run as one batch:** all 1024 tiles decoded through
`read_scenic_tile` — magic, payload length, coordinates, CRC-32, SHA-256 and
band — `1024 OK, 0 failures`. The map also round-trips through the real Janet
reader: `cache-new` accepts it and `read-height-tile` decodes `(0,0)`, `(-1,-1)`,
`(-16,-16)`, `(15,15)` and `(3,7)`.

## Raw sample vs. delivered grid — this distinction matters

| | Raw scout | Delivered map |
|---|---|---|
| Grid | **128 × 128** real model samples | **512 × 512** blocks |
| Cell size | 1 sample/pixel | **4 blocks per sample**, bilinear |
| Relief | **971.69 m** (793.77 – 1765.46) | 970.88 m |
| Climate | **not sampled** (`with_climate` False) | none |

The map is **bilinearly interpolated 4×**. It is real terrain, but it is 128 real
samples spread across 512 blocks — interior values are linear blends of real
neighbours, not new model output. The artifact records this explicitly:

```json
"grid_transform": {"operation":"bilinear","mode":"target-shape",
  "source_shape":[128,128],"output_shape":[512,512],
  "source_span_pixels":[127,127],"output_span_blocks":[511,511],
  "endpoint_preserving":true,"invents_detail":false}
```

First and last source samples land on the first and last output samples, so the
output covers exactly the sampled rectangle. `972 m` of relief over `128` samples
is a steep, watershed-scale mountain region — that is real, not an artifact of
interpolation.

## Rebuild: three Python commands

Run from the repository root with the project venv. Inputs are the **original
128 raw scout**, not the upscaled one.

```python
import sys; sys.path.insert(0, "tools")
import scenic_terrain as st

PROV = {
    "identity_digest": "c210cb74999dc4c45f66238018f56251bd2f82276ba6239d2693fc26b8ce20c0",
    "sampled_by": "WorldPipeline.get(i1,j1,i2,j2) via load_sampler",
    "sampled_with_climate": False,
    "origin_pixels": [100000, 100000],
    "seed": 12345,
    "pixels_per_voxel": 1,
    "source_pixels": 128,
    "decoder_geometry": [512, 384],
    "model": "xandergos/terrain-diffusion-30m",
    "model_revision": "9ef8030cb805b433b98ec25c5dddefbac07a9e26",
    "snapshot": "pinned local snapshot, verified by verify_snapshot",
    "quantized": False,
}

# 1) re-verify the raw scout, then upsample 128 -> 512
st.adopt_raw("tmp/scenic-raw-scout.npz", "tmp/scenic-raw-adopted.npz",
             target_shape=(512, 512), provenance=PROV)

# 2) bake the scenic cache
st.import_raw("tmp/scenic-raw-adopted.npz", "tmp/scenic-valley",
              meters_per_voxel=5, baseline_elevation_m=750.0, sea_level=28,
              profile="alpine-watershed-v1", height_max=252,
              world_origin_voxels=(-256, -256))
```

Verified: re-running these from the stored scout reproduces the npz digest
`1bf450f8c7fde2681446f110430fe3c288ab9a79a7a07ecd23ae950b1fb4ec7f` and the
identity `27d25d28…` exactly.

`adopt_raw` re-hashes its input and refuses if the digest in the accompanying
`.json` does not match, so step 1 cannot silently consume different data.

## The raw sample itself

The scout script is **not versioned** — it lived at `tmp/raw_scout.py`
(sha256 `056bb1eb65a2c27c90bf22127d7b84e6037385f748b3d2e06f9e8ffe17047e5e`)
and is preserved here because it is the provenance of the raw data. This is the
whole of what it did:

```python
raw_scout_root = "tmp/raw-scout"
digest = os.environ["SCOUT_IDENTITY"]          # c210cb74…, created by `init`
layout = tb.Layout.open(raw_scout_root, digest)
stored = tb._require_manifest(layout)["identity"]
sampler = tb.load_sampler(stored, layout)       # re-verifies pins before torch
try:
    x0 = z0 = ORIGIN                            # 100000
    x1 = z1 = ORIGIN + PIXELS                   # +128
    matrix = tb._fetch(sampler, x0, z0, x1, z1)  # ONE query, rows=z cols=x
finally:
    sampler.close()
# written straight to float32 metres, before any quantization
np.savez_compressed(OUT_NPZ, elevation_m=raw,
                    origin_pixels=[ORIGIN, ORIGIN], seed=[SEED],
                    pixels_per_voxel=[1])
```

The identity it ran against must exist first, created with the same pins:

```sh
tmp/terrain-runtime/venv/bin/python tools/terrain_backend.py init \
  --cache-root tmp/raw-scout --stats-json /tmp/pd.json \
  --seed 12345 --pixels-per-voxel 1 --origin-x 100000 --origin-z 100000 \
  --window-chunks 4 --max-samples 128 --decoder-tile 512 --decoder-stride 384
```

**The 256 × 256 attempt failed** with
`kIOGPUCommandBufferCallbackErrorImpactingInteractivity` inside a single
`pipeline.get(..., with_climate=True)` and wrote nothing. Whether `with_climate`
contributed is **suspected, not proven** — no trace established it, and no claim
is made here.

## Presentation constants that are authored, not measured

These are choices layered on top of the data. They are **not** model output and
must not be described as such:

| Constant | Value | Meaning |
|---|---|---|
| snow line | **170** | world Y at or above which snow renders |
| tree line | **150** | world Y at or above which trees stop |
| rock layer | **6** | blocks of rock below the surface |
| sea level | **28** | voxel offset in the quantization transfer **only** |

Heights **are** world Y, so a Y threshold is used directly — `sea_level` is a
quantization constant and must **not** be added to the snow or tree line.

## Launching it

Compile the current native game and launch directly into the generated valley:

```sh
./run.sh build build/trinecraft-scenic
./run-scenic.sh
```

`run-scenic.sh` selects the finite map, seed 12345 and a grounded interactive
valley start, without starting Python inference. The character starts in walking
mode on validated dry terrain with clear body space, rather than at the aerial
photography height. The launcher requests `--scenic-preload`: the bounded saved
map is converted to chunks and meshes before control begins, with real progress
on the artwork loading screen. Esc cancels; there is no implicit timeout.

The inspected walking-height start is an open ridge shoulder at `(-24,-37)`,
feet Y `160` on the map's actual grass surface (not suspended at an arbitrary
camera height). Yaw `0` radians looks east down the valley, pitch `-0.1`.
`tmp/scenic-grounded-open.png` shows this view. That native capture reported
1024 resident chunks, zero streaming in/out, zero edits and an empty mesh queue;
all terrain was prepared before its 30 gameplay frames. The final default
launcher uses this same grounded preset. Its absolute Y reflects the mountain
slope elevation, not flight above the ground.

This is loading and voxel/mesh construction, not another model generation.
Preloaded finite-map chunks stay resident instead of being discarded behind the
player. This policy is specific to this small saved map, not a promise to preload
an unbounded world. Explicit aerial and screenshot camera options remain available.

The launcher resolves assets from the project root even if launched from
elsewhere. The original `./run.sh` remains the procedural launch path; it does
not select this map automatically.

`--seed` must match the cache (`12345`); a mismatch is refused before the window
opens.

The reference frame's camera, as one runnable command:

```sh
./build/trinecraft-scenic \
  --terrain-cache tmp/scenic-valley/27d25d28e4c2931106b2ee86ea3be45232a91dff92dc32e80369e039102a19c9 \
  --seed 12345 \
  --screenshot tmp/scenic-hero.png --scenic-view hero \
  --camera-x 70 --camera-y 175 --camera-z -20 \
  --camera-yaw 3.14159265358979 --camera-pitch -0.16 \
  --frames 1700
```

Three details that are easy to get wrong:

- **`--scenic-view` is required.** It applies the requested camera both
  interactively and in screenshot mode. `valley` selects the known mountain
  viewpoint; explicit camera coordinates can override it. `--screenshot` alone
  does not select a scenic viewpoint.
- **`--camera-y` is the eye height**, and the player's `eye-height` is subtracted
  internally, so the value here is where the operator aims, not the camera's
  final Y.
- **`--camera-yaw` takes a number**, so PI is written out; an expression is not
  evaluated.

**Native build and visual capture verified.** `build/trinecraft-scenic` was
rebuilt after `269a76a` and run with the same map and camera arguments above.
`tmp/scenic-valley-final-native.png` was opened and inspected: a full snow-capped
peak above the forested watershed, with no HUD or held tool. This is actual
voxel terrain, not loading artwork. The earlier all-sky/downward views came from
live mouse input leaking into scripted captures; the headless guard now keeps
the requested camera orientation fixed. No FFI/runtime defect was established.

The final 1700-frame native run loaded 718 chunks, with 693 streamed in. Mean
frame time was 25.81 ms, worst 69.2 ms; 422 frames exceeded 33 ms. Its measured
post-meshing window averaged 17.69 ms (56.5 FPS). These are finite-run results,
not a smoothness guarantee. Log: `tmp/scenic-valley-final-native.log`.

## Save compatibility

`TRCR` save format is now **v2**, and this is a deliberate, explicit break:

- v2 requires engine chunk height **256** and volume **65536**
  (`src/region.janet:20`), which is what `world.janet` now declares;
- a **v1** file (64-high chunks) is **refused** with
  *"legacy TRCR v1 uses 64-high chunks; migration required, refusing to pad old
  world"* (`src/region.janet:100`);
- **there is no migration path.** Old worlds are not padded, converted, or
  loaded partially. Existing save files remain on disk untouched — nothing
  deletes them — but they cannot be opened by this build.

The taller world is a compatibility break for every pre-existing saved world, not
a silent upgrade.

## Reproducibility — the exact claim

The artifact's SHA-256 is exact and recorded. The **transform** is reproducible:
re-running the three commands above in a fresh process reproduced a byte-identical
npz (`1bf450f8…`) and the identical identity `27d25d28…`.

Because the identity hashes `raw_sha256`, identity reproducibility is
**conditional on byte-identical npz output**. That held here, across processes,
for this numpy/zlib build — whose zip members carry the fixed `1980-01-01`
timestamp rather than wall-clock. It is **not proven** across a different numpy
or zlib version, another platform, or another GPU: deflate output and the zip
`create_version` field are writer-dependent, and the raw elevations themselves
are untested on other hardware.

## Test state

- `test_*terrain*.py` — **277 tests green**, combined.
- `test_scenic_terrain.py` — **47 tests**, including interpolation and adoption.
- The import-time library check was moved into a fresh subprocess
  (`f874fd3`); asserting on the running process's `sys.modules` made it depend on
  test order, and the scenic tests legitimately import numpy.

## Not done, deliberately

- No 512-sample model query. The delivered map is 128 samples, upscaled.
- No climate data was sampled, so forest/snow bands are authored constants, not
  derived from the model's climate tensor.
- The scout script is not versioned in the repo; only this excerpt is.
