# Bender compiler tasks — moved

The brief now lives in the bender repo, where the work happens:

**`/Users/pankajdoharey/Development/Projects/janet/docs/internals/trinexraft-workload-tasks.md`**

It was briefly kept here, which was the wrong home: an agent working on the
compiler is in the janet repo and would never have found it.

## TrineXraft's role

This project is the **acceptance workload**, not a bystander. Any change
proposed there is measured here:

```sh
JANET_NO_PROFILE=1 bender bench/kernels.janet            # interpreted
bender --aot bench/kernels.janet --native -o build/b
JANET_NO_PROFILE=1 ./build/b                             # native
./run.sh test                                            # twelve suites
```

`JANET_NO_PROFILE=1` on both sides is mandatory; default PGO collection
inflates interpreted timings 50-75% and manufactures a fake speedup.

## The finding in one line

Phase 10 measured 1.3-2.9% from `--aot --native`, because the build emits
nothing in **either** tier for this game: `native-names.txt` and
`native-executors.txt` are both empty. The mesher's inner loop is buffer
`get`/`put` and `ffi/write`, which Tier B treats as explicit VM boundaries,
so there is no arithmetic left between them to fuse.

Full reasoning and the measurements are in `docs/PLAN.md` under Phase 10.
