# TrineXraft multiplayer — peer-to-peer design study

**Status: design only.** No networking code exists in the game yet, and this
document does not change that. It answers one question: can TrineXraft be
played by 2–5 friends, and by open worlds, with no server for anyone to
administer, no VPN, and no LAN?

Short answer: **yes — with one honest exception.** Gameplay data can travel
peer-to-peer and never touch a server. *Finding* the other peer on the open
internet cannot be fully serverless; it needs a rendezvous that is tiny,
expendable, and interchangeable. That is the same shape Tailscale, ZeroTier,
Syncthing, BitTorrent and libp2p all have, and it is what people already mean
by "peer to peer".

---

## 1. The thing to get straight first

There are four separate planes. Conflating them is how P2P designs go wrong.

| Plane | Question | Can it be serverless? |
|---|---|---|
| **Discovery** | how do two machines learn each other's live address? | No. Needs a rendezvous, but a dumb one. |
| **Connectivity** | how does a packet get from A to B through NAT? | Mostly. Direct for ~70–90%, relay for the rest. |
| **Authority** | whose world state is the truth? | Yes. Elect one player's machine. |
| **Content** | what is the world? | Yes. Terrain is seed-derived; only edits ship. |

Everything the player experiences — movement, edits, chat, the world — lives
in the bottom two rows and is genuinely peer-to-peer. Only the top row needs
infrastructure, and it holds no game data, no accounts, and no world state.

### Why not Bitcoin-style gossip or a blockchain

Bitcoin's gossip solves a problem TrineXraft does not have: reaching
*consensus among mutually unknown, mutually hostile* parties without any of
them being trusted. Your friends are not hostile strangers, the group is
2–5 people, and there is a natural authority — whoever is hosting.

A blockchain would buy Sybil resistance at the price of:

- minutes of confirmation latency for a *block placement*;
- unbounded storage growth for a voxel world that changes constantly;
- proof-of-work or staking costs for a five-person LAN game;
- every peer still needing a full node or a light client.

That is a bad trade. What *is* worth stealing from that world is the
**content-addressing and capability-token** vocabulary, and the *gossip
transport* — a DHT or rendezvous network is the right tool. Consensus is not.

---

## 2. Reality check on NAT traversal

The uncomfortable number: hole punching is good, not perfect.

- libp2p's DCUtR (Direct Connection Upgrade through Relay) is the modern
  measurement standard. Large-scale measurement puts **conditional hole-punch
  success at ~70% ± 7.1%** aggregated across NAT types, *given* that relay
  reservation and public-address discovery already succeeded. See
  [the DCUtR measurement report](https://github.com/probe-lab/dcutr-project/blob/main/docs/dcutr-final-report.md)
  and [the paper](https://arxiv.org/pdf/2604.12484).
- WebRTC ICE does the same job with STUN, and needs TURN for symmetric NAT and
  hostile corporate firewalls. Every WebRTC deployment in existence keeps TURN
  as a fallback; none of them claims 100% direct.

So: **a fraction of pairs — realistically one in five to one in three, worse
in some countries and on some mobile networks — cannot connect directly at
all.** No protocol removes that. Anyone promising "zero server, always direct"
is either not measuring or not shipping.

### Who can be the relay

**Any peer whose machine is publicly reachable can relay.** A relay is not a
special kind of server; it is just a peer that happens to have an address
strangers can dial. That is exactly how libp2p's Circuit Relay v2 and DCUtR are
specified: *any* publicly reachable node may accept reservations from NATed
nodes and coordinate their simultaneous dial. The relay holds no world state
and needs no account.

Practical consequence: **in a group of friends there is usually no relay at
all, and when there is one it is usually the best-connected member's box.**
Concretely:

| Situation | Relay needed |
|---|---|
| Everyone on one LAN | none — mDNS + direct |
| One peer with a public IP or a working UPnP mapping | that peer |
| Everyone behind CGNAT/symmetric NAT | one outside box (cheap VPS, homelab, friend with fibre) |
| Open world with strangers | a relay pool, by whoever runs it |

The relay must also be **reachable by everyone in the group**, which is why the
unusual case is the hard one: if all five players are on carrier-grade NAT, no
player can host the relay for the others, and the only way out is a machine
outside all five networks. That machine can be a $4/month VPS, or a friend's
always-on home server with a port forward — but it cannot be a player.

### The realistic design: opportunistic relay election

Do not hardcode a relay. On group formation, every peer advertises what it
knows about itself:

- a public address it has had confirmed by a STUN-like echo, or
- a successful UPnP/NAT-PMP mapping it obtained on its own router, or
- neither (sym-NAT / CGNAT).

Peers that answer "yes" become **relay candidates**, ranked by measured RTT.
The group tries direct connections first; any pair that fails falls back to the
lowest-RTT reachable candidate. If no candidate exists, the group prompts for
one outside volunteer. This is a 100-line policy over the transport, not
infrastructure — and it means the common case of "five friends, one has fibre"
requires literally nothing from anybody.

**UPnP is worth attempting but must never be required.** Verified on this
machine: Janet can do SSDP discovery (`net/address` + `net/send-to` on an
unconnected UDP listener) against the gateway, fetch its description over plain
`net/connect` HTTP, and call SOAP `GetExternalIPAddress` — so the same
primitives reach `AddPortMapping`. But the probe also returned a private
address (`192.168.1.2`) as the gateway's "external" IP, which is the signature
of **double NAT** — router behind router, or a carrier gateway. On such a
network UPnP on the inner router accomplishes nothing, because the outer
NAT has to be punched or mapped too. Treat UPnP as a *bonus that sometimes
eliminates the relay*, never as a load-bearing step, and always fall back to
hole punching.

Note also that adding a port mapping is a **router-state mutation**. It must be
opt-in, explicitly confirmed in the UI, bounded in lifetime (renew the lease
rather than leave a permanent hole), and reversible on quit.

The design answer is not to deny the relay; it is to make the relay
*disposable and small*:

- It relays **only** for the pairs that need it, and only until a direct path
  is found — DCUtR promotes a relayed connection to a direct one in place.
- It sees **ciphertext only**. The session key is established end-to-end
  (X25519 + ChaCha20-Poly1305), so a relay operator cannot read the world,
  cannot join, and cannot alter state.
- It is **anyone's to run** — you, a friend, a homelab, a $5 VPS, a public
  relay. Losing it degrades to "that pair plays relayed", never "the world is
  lost".

That last property is the actual difference from a game server: **the relay
is not the authority and does not hold the world.** Kill it mid-session and
the game continues on direct links.

---

## 3. The recommended stack

Four layers, each replaceable.

```
L3  world authority     host election + append-only edit log + snapshots
L2  session             Noise-style handshake, AEAD channels, capability tokens
L1  connectivity        ICE/DCUtR hole punching, QUIC or UDP, relay fallback
L0  discovery           DHT / rendezvous / mDNS on LAN / invite hint
```

**L0 — Discovery.** Four interchangeable mechanisms, tried in order, because
no single one covers every case:

1. **Invite hint** — the invite carries the host's last known address(es) and
   a relay reservation. Most private games never need anything else.
2. **LAN mDNS** — automatic local discovery, zero infrastructure, instant.
3. **A rendezvous point** — libp2p rendezvous, a DHT put/get, or a
   BitTorrent-style tracker: "publish `world_id` → my addresses". Small enough
   that a static page and a SQLite file run it.
4. **Public index** — only for open worlds that ask to be listed.

**L1 — Connectivity.** Do not invent this. Use an existing, measured
implementation:

- **libp2p** (QUIC + Circuit Relay v2 + DCUtR) if you want the whole L0/L1
  stack with one dependency and a battle-tested hole punch.
- **WebRTC/ICE** if you would rather use OS-level stacks; it is the most
  deployed NAT traversal in the world, at the cost of a signalling server and
  needing TURN.

For TrineXraft specifically, libp2p is the better fit: it is a library, not a
service, it already ships relay-plus-upgrade, and it has a real DHT for the
public/index case.

**L2 — Session.** Every peer has a long-lived **ed25519 identity key**.
Sessions are X25519 + ChaCha20-Poly1305 (or Noise `XX`), transport-encrypted
end to end, independent of the relay. Authentication is by *pinned group key*,
not by username.

**L3 — Authority.** Section 5.

---

## 4. Identity, invites, and private membership

This is the part that most determines whether it *feels* like "my friends and
me, no setup".

### The invite is a capability, not a password

An invite is a short signed blob, shared however friends already talk — a
link, a QR code, a 6-word phrase, an email:

```
trinexraft://join/<base64>
  world_id     32 bytes   content hash of world config + seed
  host_pubkey  32 bytes   ed25519
  group_key    32 bytes   symmetric, encrypts the world log
  epoch        u32
  expiry       timestamp
  relay_hints  [multiaddr...]     optional
  seal         signature by group_key
```

Properties that matter:

- **It carries no password to type and no account to create.** Paste it and
  you are in; the client does the rest.
- **It works offline-first.** The hint list means the guest does not need a
  working DHT — it dials the last known addresses directly.
- **It is revocable, cheaply.** Membership is `(member_pubkey, epoch)`. Kicking
  someone increments `epoch`, mints a new `group_key`, and re-issues invites.
  A kicked peer keeps ciphertext it already had — this is not retroactive
  secrecy — but every subsequent log entry and every new session is closed to
  it. That is the honest guarantee, and it is enough for a friends game.
- **A 6-word phrase is fine for LAN, weak on the open internet.** For remote
  invites, prefer a link/QR carrying the full 32-byte group key. If a spoken
  phrase must be enough, use a PAKE (SPAKE2), which is exactly what
  [Magic Wormhole](https://github.com/magic-wormhole/magic-wormhole) does —
  short human code, cryptographic strength, and a rendezvous mailbox that
  never sees plaintext.

### Two world modes, one code path

- **Private** — invites only. `world_id` is never published anywhere. Nothing
  is discoverable by anyone who was not handed a capability. This is the
  default, and it should be the only mode that exists for a long time.
- **Open** — the host opts in to publishing `world_id` + live addresses to the
  public index. Anyone may then dial and request entry; the host's policy
  (allow-list, max players, rate limit, greeting) decides.

The open mode is where all the abuse risk lives, so it is deliberately the
*last* thing built and is off by default.

---

## 5. Authority: one host, a log, and no consensus

Two supporting facts make this cheap in TrineXraft as it stands today.

### The world is already mostly free

Worldgen is pure and coordinate-derived: `hash2` and `value-noise-2d` in
`src/worldgen.janet:23,50` use only multiplies, adds, and `math/floor` on
IEEE-754 doubles — **no transcendentals, no platform-dependent branches**.
`height-at` (`src/worldgen.janet:124`) and `column-block` (`:140`) are pure
functions of `(seed, x, y, z)`. So every peer generates *byte-identical*
terrain from the seed alone.

Therefore multiplayer never ships terrain. It ships **edits**, as sparse
`(x, y, z, block_id)` operations against a seed everyone already shares. A
session's traffic is a few kilobytes where a naive design would be megabytes.

Physics is the opposite: `src/player.janet:252` uses `math/sin`/`math/cos`,
which are libm and may differ by an ULP across machines. So do **not** try to
lockstep remote avatars. Each peer owns its own avatar and transmits it; the
host validates it (see below).

### The authority model

**Host = one elected peer.** Not a quorum, not a chain.

- The host owns the canonical world: an **append-only edit log** plus periodic
  **snapshots** (a `TRCR` file, as `src/region.janet:165` already produces).
- Every edit is a signed, sequenced record: `(seq, epoch, author, x, y, z, id)`.
  `seq` gives total order without any distributed agreement.
- Applying an edit is a `world/world-set-block` on the host
  (`src/world.janet:80`), which is already the game's only mutation path, then
  broadcast to peers.
- Peers render optimistically and reconcile against the host's stream. Two
  people placing a block in the same spot in the same tick is a 2-packet
  conflict resolved by `seq` order, not a philosophical problem.

**Host migration.** When the host leaves, survivors elect the peer with the
longest log prefix that is confirmed by the group key, then that peer becomes
`host` for the next epoch. Because the log is authenticated and totally
ordered, a survivor can always prove which history is legitimately newer.
A monotonic `epoch` in the log header prevents a returning old host from
resurrecting a dead branch — its writes are simply outside the current epoch
and get replayed as a rejoining *guest*.

**Continue alone.** Everyone keeps a local copy of their own confirmed log
prefix. If the whole group disappears, a player can keep building and merge
back later, exactly as two Git branches reconcile: replay by `seq`. This is the
property a lockstep or a single-server design cannot give you.

**Why not per-block CRDTs.** A voxel world is a last-write-wins register per
coordinate, and CRDT machinery for that is a lot of complexity to buy conflict
resolution for edits that are already serialized by `seq`. Skip it. If
concurrent-building *smoothness* ever becomes a complaint, an LWW map keyed by
`(x,y,z)` with `seq` as the clock is a drop-in upgrade that changes no wire
format.

**Why not deterministic lockstep.** It requires bit-exact floats forever, on
every platform, and one desync is an unrecoverable save fork. For 5 players,
bandwidth is not the constraint; robustness is. Authoritative host wins.

### Movement trust

Movement is the one place cheat resistance actually matters, and the honest
scope is *casual* anti-cheat:

- Client sends `(pos, vel, yaw, pitch, input_summary)` at ~20 Hz; host
  interpolates remote avatars.
- Host rejects positions that fail `box-collides?` against its world
  (`src/player.janet:71`) or imply speed above a tolerance.
- Do not attempt full server-side re-simulation. It is real work for a threat
  model ("my friend flies") that a friends-only game does not have. Keep the
  collision and speed checks; drop the rest.

---

## 6. Joining, rejoining, and catch-up

**First join**

1. Parse invite; verify the seal against `group_key`; check `epoch` and expiry.
2. Dial hints → LAN mDNS → rendezvous → open index.
3. Attempt direct; if hole punching fails, reserve a relay and upgrade.
4. Handshake (X25519 + AEAD). Prove membership by presenting a member key that
   the host's `epoch` list authorizes.
5. Host sends: `world_id`, seed, epoch, `seq` high-water mark, and a snapshot
   if the guest's log prefix is too far behind.
6. Guest generates terrain locally from the seed (it already can) and applies
   the snapshot's diffs. Typical time-to-play: a few hundred ms after connect.

**Rejoin** is the same call with a known `seq` — the host streams only the
missing log suffix. No snapshot needed unless the gap is huge.

**Late join while others build** — snapshot + suffix replay, then live log
tail. No world freeze is required because edits are commutative-with-order and
the guest applies them in `seq` order.

---

## 7. Security and anti-abuse

| Risk | Mitigation |
|---|---|
| Stranger joins a private world | Impossible without `group_key`; all traffic is AEAD under a key derived from it. |
| Relay operator reads or alters play | Sees ciphertext only; session keys are E2E; the relay is never the authority. |
| Kicked member returns | `epoch` bump + fresh `group_key`; old credentials are dead. |
| Griefing in an open world | Host policy: allow-list, player cap (small — 5–8), per-peer rate limit on edit packets, kick by key. |
| Malformed or hostile packets | Every inbound packet is length-checked and type-checked before use — the same discipline `src/region.janet` already applies to files (`fail`/`valid-i32?` at `:18`). |
| Replay old edits | `seq` must strictly increase per author; anything outside the current epoch is discarded. |
| DoS / address-flooding | Reputation is out of scope; rely on invite-only default and a cap on pending handshakes. |
| Save corruption by a malicious peer | Only the host writes the durable save; guests' logs are advisory. |

Explicitly **out of scope**: anonymity, censorship resistance, retroactive
secret deletion, and anti-cheat for competitive play. Adding a blockchain would
only pretend to solve the first three.

---

## 8. What it costs to operate

- **Private game, two peers on friendly NATs:** zero infrastructure. LAN mDNS
  or the invite hint's addresses suffice.
- **Private game, someone behind symmetric NAT:** one relay, and the relay is
  normally **a player's own machine**, not a rented server. It is elected from
  whichever peer has a public address or a successful UPnP mapping. It carries
  bytes that pair cannot get direct and holds no world state.
- **Private game where nobody is reachable (all on CGNAT):** the one case that
  genuinely needs a box outside all the players' networks — a $5 VPS, a homelab,
  or a friend with a public IP. This is a fallback, not the default, and it
  still sees ciphertext only.
- **Open world:** a rendezvous/index process, plus a relay pool. This is the
  only genuinely server-shaped component, and it belongs to whoever wants to
  run an open world — not to every player.

Failure modes are all graceful: relayed → direct upgrade when possible;
rendezvous down → cached hints still work; host gone → migration; group gone →
local continuation and later merge.

---

## 9. Implementation phases (feeds roadmap Phase 22)

The roadmap's Phase 22 currently reads *"Local split-screen first;
server-authoritative networking later"* (`docs/PLAN.md:423`). This design
refines "server-authoritative" into *host-authoritative among peers*, which
preserves its reason for existing — one authority means reproducibility — while
removing the dedicated server. Suggested ordering:

**22a — Deterministic world contract (no networking).**
Make the seed, block ids, worldgen, and materials an explicit versioned
"world contract" hash. Two clients with the same hash are guaranteed to
generate identical terrain. Cheap, testable headless, and a hard prerequisite.
Also add the small crypto dependency this all needs — verified today that
Bender's Janet exposes `net/listen`, `net/connect`, `net/datagram`, `ev/select`
and `os/cryptorand`, but **no `crypto/sha256` or `crypto/md5`**, so hashing/AEAD
must come from an FFI to libsodium/libcrypto or a small vendored C file.

**22b — Loopback two-player session.** One process, two worlds, an in-memory
transport. Proves the log, the snapshot, join/rejoin and reconciliation with
zero networking risk. This is where the bugs actually are.

**22c — LAN.** `net/listen`/`net/connect` over TCP or UDP plus mDNS. Real
peers, no infrastructure, no NAT problems. This is the milestone that makes it
*feel* like the LAN game the concept asks for.

**22d — Invites and crypto.** ed25519 identities, group key, capability blob,
epochs and revocation, AEAD channel. LAN-only proves the membership model
before the internet is involved.

**22e — Internet direct.** libp2p (or WebRTC) with QUIC/UDP, STUN/DCUtR hole
punching, relay fallback, and relay→direct upgrade.

**22f — Peer relay election.** Self-probe (public-address echo, optional
opt-in UPnP/NAT-PMP mapping), advertise reachability, elect the lowest-RTT
reachable peer as relay, and re-elect on departure. This is the step that makes
"no server" true for the ordinary five-friends case, and it is small because
the transport already supports relaying.

**22g — Open worlds.** Public index, host policy, rate limiting, moderation
tools. Last, and behind a non-default flag.

**22h — Host migration and local continuation.** The properties that make this
architecture worth having; also the easiest to defer and then regret deferring.

Split-screen (the roadmap's existing first step) is untouched by all of this
and remains a valid earlier deliverable.

---

## 10. Test plan

Most of this is testable without a second machine, which is the point of
putting the log at L3 rather than in the transport.

**Determinism (headless, today's test style)**
- Same `(seed, x, z)` → identical chunk bytes on two independently constructed
  worlds; assert on a chunk hash, not on individual blocks.
- World-contract hash changes when seed, block ids, worldgen constants, or
  recipe semantics change, and not otherwise.

**Log and authority**
- Concurrent edits from three authors converge to the same final world under
  any arrival order.
- Replayed packets, out-of-order `seq`, and stale `epoch` are all rejected.
- Snapshot + suffix replay reconstructs exactly the live world.
- Host migration from the longest valid prefix yields the same final world as
  no migration.
- Local continuation then merge equals the never-disconnected timeline.

**Membership**
- Invite seal verifies; tampering with any byte fails closed.
- Expired invite rejected; kicked member's session and edits rejected after
  the epoch bump; existing members unaffected.
- A member cannot forge another author's edits (signature check per record).

**Transport**
- Loopback transport: 200-lossy channel, reordering, and 2 s stalls — no
  divergence, no unbounded memory growth.
- Relay-only path produces identical state to direct; promotion to direct is
  idempotent and does not reset the session.
- Malformed/truncated/hostile packets fail closed without crashing.

**Manual QA**
- Two machines, one behind a symmetric NAT: relayed session, `--stats` shows
  the relay path, then a direct upgrade.
- Relay election: peer with a public address is chosen automatically; kill it
  and the group re-elects without dropping the world.
- Pull the relay mid-session: play continues.
- Guest joins mid-build: sees the current world within a second.

---

## 11. What I would not build

- **A blockchain or token.** No problem here that it solves.
- **Deterministic lockstep.** Float-exact forever, for a 5-player game.
- **A per-block CRDT from the start.** `seq` ordering is enough; LWW-map is the
  cheap upgrade if concurrent building ever feels bad.
- **Full server-side movement re-simulation.** Keep collision and speed checks;
  skip the rest for a friends-only game.
- **An open public mode before invites are rock solid.** Open worlds are where
  every abuse path lives.
- **A custom NAT-traversal implementation.** Use libp2p or ICE; both are
  measured, and the measurement says ~30% of pairs need a relay.
- **Requiring UPnP.** It works on some routers and is silently useless behind
  double NAT or CGNAT (both observed in practice). Attempt it, never depend on
  it, never write a mapping without explicit consent and a lease.
- **A dedicated relay server as the default.** Build the peer election first;
  a rented box is the fallback for the all-CGNAT group, not the design.

---

## 12. The one-line answer

Yes: run one player's game as the authority, ship only block edits because the
terrain is seed-derived, let the group elect whichever member is actually
reachable as its relay, and gate entry with an invite capability instead of an
account. That is a genuine peer-to-peer world with no server to administer — the
same architecture as Tailscale and
Syncthing, which people already describe as "LAN over the internet, without the
LAN".
