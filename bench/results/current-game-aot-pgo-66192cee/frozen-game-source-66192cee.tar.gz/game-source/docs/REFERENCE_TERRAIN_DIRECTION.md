# Reference terrain direction — what to aim at, and what we can actually turn

Status: research only. No source changed. This document records what the parent
observed in the user-attached reference images, what five established Minecraft
worldgen projects do (and what their licences permit), and which of those ideas
Trinecraft has a real control for today. It does **not** claim Trinecraft matches
any of them.

## 0. What this document stands on — and two retractions

**§1 is the parent's observations of images the user attached to the
conversation.** It is not the result of this agent looking at files: the agent
has no image input, and the eight local files in `~/Screenshots` could not be
mapped with confidence to the attached images. The parent is the source for §1.
Where this document describes visual content, it is relaying that reading.

**The reference images are of unknown provenance.** They are not asserted to be
model-generated and not asserted to come from any named Minecraft mod. Nothing
here should be read as "this is Terralith" or "this is diffusion output". They
are pictures a person looked at and said "more like this", and nothing more.

### Retraction 1 — the percentage table is withdrawn

An earlier version of this document reported per-image
"sky / water / vegetation / rock" percentages ("rock 7.4–42%") as if they
measured the references. They did not. They were rough heuristics over colour
classification: a pixel counted as "rock" if it was low-saturation and mid-dark,
which also catches shadowed terrain, grey cloud and parts of water. Water was
counted by blue dominance, which catches sky.

Those figures are **retracted and removed**. They were never ground truth, are
not reproducible against an unspecified file, and quoting them invites decisions
built on an artefact of my classifier. Any quantitative claim about the
references must come from someone looking at them, or from a stated method
applied to a named file.

### Retraction 2 — "absent" was the wrong test

An earlier version called climate, rivers, waterfalls, ores, strata and fauna
"absent" on the strength of greps returning zero hits. That reasoning was wrong
twice:

- **`grep` for a word is not evidence about a capability.** Zero hits for "fauna"
  says only that nobody typed the word. Worse, a later re-check found scattered
  hits for "entity" that were all the word *identity* in `src/rl.janet:320,332`
  — a false positive in the other direction.
- **For climate the grep was actively misleading.** The producer *does* carry
  climate data: `tools/scenic_terrain.py:163` accepts a `climate` array,
  `:188-192` validates it against the elevation grid and stores it, and `:212`
  records `has_climate`. `tools/terrain_backend.py:1697` requests
  `with_climate=False`.

§3 now separates three things that "absent" collapsed together: **data that
exists**, **data the pipeline requests**, and **a feature that consumes it**.
Climate is the first and not the third — the producer can supply it, nothing
requests it, no generator reads it. That names the real gap (a consumer) instead
of erasing a capability that is half-built.

The list of genuinely absent things in §3 is now supported by capability
evidence — block IDs, subsystem absence — not by grep counts.

## 1. What the references show (parent's observations)

**Reference A — wide biome mosaic.** A broad coastal vista: blue water at the
edge, white/arid sand, orange badlands mesas with layered red terracotta, green
forest patches, pink blossom trees. Channels and lakes thread through the
terrain. The organising idea is *adjacency*: several materially different biomes
visible in one frame, each with its own surface and its own vegetation.

**Reference B — warm desert, mesa and lake under a heavy sky.** Warm desert with
mesas beside a lake, under a cloudy sky that reads as volumetric. Ground of
grass and flowers; a river running through it; sunset mist. The organising idea
is *atmosphere doing compositional work* — the sky is an element, not a backdrop.

**Reference C — mountain valley.** Conifers plus round broadleaf trees plus pink
flowering trees; clearings; ground cover; a long massif on the horizon. The
organising idea is *tree variety inside one biome*: three silhouettes in the same
valley, not one tree repeated.

**Reference D — birch forest with water.** A pond and a waterfall with droplets;
birch-like trunks. The organising idea is *water as a focal feature* — small,
placed, with an edge, not a plane at a fixed level.

### What these imply, as properties rather than numbers

- **Biome adjacency within one view.** Two or more materially different surfaces
  (sand, terracotta, grass, snow) in a single frame, with a transition that reads
  as terrain rather than as a colour boundary.
- **Water as a placed feature.** Channels, ponds, lakes, a waterfall — water with
  an edge. "Some fraction of the frame is blue" is not the target and was a bad
  proxy for it.
- **Three tree silhouettes minimum**, distinguishable at distance.
- **Layered surface materials.** Terracotta strata and sand make a cliff
  readable as a cliff; the material is doing structural work.
- **Sky and mist as composition.** Cloud volume and atmospheric depth carry as
  much of Reference B as the terrain does.

None of these is reachable by turning one knob, which is the point of §5.

## 2. What the reference projects actually do

Researched via public sources; **no code, assets, or data were copied**, and the
licence column is the operative constraint on what could ever be borrowed
conceptually.

| Project | What it is | Capability caught here | Licence posture |
|---|---|---|---|
| **[Terralith](https://modrinth.com/project/8oi3bsk5)** (Stardust Labs) | Datapack + mod, 85–95 new biomes, tall mountains, canyons, shattered biomes, deep ocean trenches | Biome *density* and terrain *variety* as the product; transitions designed to feel natural rather than banded | **All rights reserved.** Includes an express prohibition on use as AI training data. Read for ideas only; nothing mirrored |
| **[Tectonic](https://modrinth.com/project/lWDHr9jE)** (Apollo) | Terrain-shaping mod; continents spanning thousands of blocks, mountains near build limit, deep ocean | Explicit control surface: vertical/horizontal scale, min/max height, **continentalness, erosion, ridges**, ocean skew, smoothing | Open source (GitHub `Apollounknowndev/tectonic`); code readable, but we reuse only the *vocabulary* of knobs |
| **[William Wythers' Overhauled Overworld](https://modrinth.com/project/II7t6llZ)** | Overhauls vanilla biomes into sub-biomes; ~190 biomes in some versions | Sub-biome granularity — the idea that "forest" is a family, not a category | Mod licence per project page; conceptual reference only |
| **[Biomes O' Plenty](https://modrinth.com/project/HXF82T3G)** | 50+ biomes plus their trees, flowers, plants, building blocks | Biomes arrive *as a package with their flora and materials*, not as a colour swap | Mod licence; conceptual reference only |
| **[Distant Horizons](https://www.curseforge.com/minecraft/mc-mods/distant-horizons)** (James Seibel) | LOD renderer: simplified distant terrain far beyond normal render distance, up to ~256 chunks | **The distinction the user asked about**: this is a *renderer*, not worldgen. It changes how far you can *see* what already exists, not what is generated | Mod licence; the lesson is architectural, not code |

### The renderer/generator distinction, stated plainly

Distant Horizons is repeatedly described as "seeing distant terrain without the
performance cost of fully rendering those chunks". It does **not** generate new
land, new biomes, or new water — it draws existing terrain at lower detail.
Confusing the two leads to a specific planning error we should avoid: assuming a
vista problem is a worldgen problem. Ours currently **is** a worldgen problem
(§5), because our map is a single 512×512 watershed and the horizon it can offer
is small regardless of LOD.

### What is worth taking from each, as *ideas*

- From Terralith: biome transitions should be gradients, not borders; variety is
  a design budget, not an accident.
- From Tectonic: landform knobs decompose into **continentalness** (how much
  land vs ocean), **erosion** (how worn), and **ridges** (where the peaks are).
  These three are separable and independently tunable — a genuinely useful
  decomposition we can adopt without copying anything.
- From WWOO: a "forest" is a family (dense/sparse/alpine/riparian), which is a
  content-axis we currently lack entirely.
- From BOP: biomes must ship with their vegetation and materials or they read as
  tinted grass.
- From Distant Horizons: LOD is a later answer to vista, and only once there is
  something worth seeing at distance.

## 3. Capability status — data, request, consumer

Three different things get collapsed by the word "absent". This table keeps them
apart, because the difference decides whether a feature is a week of work or a
subsystem:

- **Data** — can the pipeline carry it at all?
- **Requested** — does anything ask for it today?
- **Consumed** — does a generator or renderer read it and change the world?

| Content | Data | Requested | Consumed | Capability evidence |
|---|---|---|---|---|
| Multiscale landforms | yes — one height field | yes | yes | `src/worldgen.janet:124` `height-at` |
| **Climate** | **yes** — producer accepts and validates a climate array | **no** — `with_climate=False` | **no** | `tools/scenic_terrain.py:163,188-192,212`; `tools/terrain_backend.py:1697` |
| Biome mosaic | no | no | no | no biome concept anywhere; `src/scenic-worldgen.janet:131` `top-block` picks surface per column from height and slope |
| Rivers, lakes | no | no | no | water is a sea-level fill; no flow, no basin |
| Coasts | partial | yes | yes | sand within the shoreline band, `top-block` |
| Waterfalls | no | no | no | never placed; needs flow plus a drop rule |
| Soils | yes | yes | yes | 9 block IDs, `src/world.janet:8-16` |
| Rock strata | no | no | no | stone is undifferentiated (`src/world.janet:9`) |
| Ores | **no — and cannot be expressed** | no | no | the block table is 9 entries deep; there is no ore ID to place |
| Vegetation | yes | yes | yes | one type: conifer trunk + opaque canopy, `paint-tree` |
| Fauna / entities | **no subsystem** | no | no | no entity, actor or creature system exists; the only "entity" strings in the tree are the word *identity* in `src/rl.janet` |
| Clouds | yes | yes | yes | screen-space bands, not volumetric (`src/sky-cycle.janet:101`) |
| Atmosphere | yes | yes | yes | sun/ambient/fog uniforms plus day cycle (`src/shaders.janet:141`) |

**Reading the climate row.** This is the one that changed. The producer can
emit a climate tensor and validate it against the elevation grid; nothing
requests it and nothing reads it. So "we have no climate" is wrong and "we have
climate" is misleading. What we have is **a dataset with no consumer** — the gap
is a generator that reads it, not a pipeline that carries it.

**Reading the ores row.** Absence here is structural, not editorial: block IDs
are a fixed 9-entry table, so there is no value an ore could take. That is
capability evidence, and it is why ores are a subsystem rather than a phase.

**Fauna** remains genuinely absent as a system. It is listed because the brief
asked for it, not because a control could reach it.

## 4. The three layers, kept strictly separate

### 4a. MODEL-SUPPORTED — things the generator genuinely reads today

These are real, wired, and verifiable in source:

| Control | Where | Range / default | Effect |
|---|---|---|---|
| `:seed` | `scenic-worldgen.janet:37` | any int, default 0 | tree anchor hashes |
| `:sea-level` | `:38` | int, default 28 | waterline + shoreline sand |
| `:snow-line` | `:39` | int, default 52 | snow at or above |
| `:tree-line` | `:40` | int, default 48 | no trees at or above |
| `:lattice` | `:41` | ≥1, default 5 | anchor spacing |
| `:density` | `:42` | 0–100, default 45 | % of lattice cells with a tree |
| `:rock-slope` | `:43` | int, default 4 | block delta that reads as cliff |
| `:tree-slope` | `:44` | int, default 2 | steeper than this, no tree roots |
| `:trunk-min`, `:trunk-span` | `:45-46` | 6, 5 | conifer height |
| height tile | `worldgen.janet:212` `generate-from-heights-scenic` | 4..252 (scenic band) | the landform itself |
| engine sea level | same function, `&opt opts {:sea-level N}` | default 28 | waterline on the *engine* fill path |
| vertical extent | `src/world.janet:4` `chunk-y` | 256 | world height |

That is the complete list. **Everything else on the user's wishlist is not
model-supported**, and no slider should be shown for it.

### 4b. AUTHORED — deliberate choices, not derived from data

- **Snow line 170, tree line 150** for the current watershed. These are scene
  decisions made after looking at the raw profile, not climate model output.
  The source comments say so explicitly and should keep saying so.
- **Rock slope 6** — chosen from the measured slope distribution (median 2, p90
  6, max 10) so rock lands at ~9% rather than 35%.
- **Camera presets** (`--scenic-view`): authored viewpoints, not procedural.

### 4c. GRAPHICS SETTINGS — change how it looks, never what exists

- Water: `src/appearance-settings.janet:3-9` — twelve real, ranged controls
  (detail distance, normal strength, specular, fresnel, alphas, caustic,
  underwater tint). These are genuinely tunable with validated ranges.
- Fog density `0.0045` and fog colour: `src/shaders.janet:149`.
- Render distance: `default-stream-radius 6`, clamped `1..24`
  (`main.janet:45`, `:3516`).
- Stars, cloud offset: `src/sky-cycle.janet`.

**What is NOT in any of these three layers** — and must not appear in a UI as
if it were: rivers, waterfalls, biome assignment, ore or strata placement,
fauna, and volumetric/3D clouds. No amount of fog or render distance produces a
river.

Climate is a special case and is **not** a slider either: the producer can carry
it, but nothing consumes it, so a UI control for "climate" would do nothing. It
belongs to §3 as a missing consumer, not here as a setting.

## 5. The gap, and what it implies

The current map is a **128×128 raw sample bilinearly resampled to 512×512** at
origin (100000, 100000). After the fixed transform `round((m-750)/5)+28` the
heights are **37..231** — that part is arithmetic on the real npz and is
reproducible.

What follows from it:

- **Relief is sufficient** for a valley composition. Reference C's "long massif
  on the horizon" needs vertical range and we have 194 levels of it.
- **Water is unreachable at sea 28.** The minimum height (37) exceeds the sea
  level, so no column floods and no shoreline exists. Reference D's pond and
  waterfall, and Reference B's lake, are not reachable on this map at this sea
  level — not because the feature is missing (it is), but because even plain
  water would not appear.
- **The map is one watershed, not a continent.** 512×512 blocks is a single
  valley. Reference A's biome mosaic needs several materially different regions
  adjacent in one view; one tile cannot supply that regardless of styling.
- **Surfaces are 9 block IDs deep.** Reference A's terracotta strata and
  Reference B's mesa layering have no block to occupy.

So the honest summary: **the map can support a good valley; it cannot support a
biome mosaic, and it cannot show water.** Those are coverage and content gaps,
not tuning gaps.

## 6. Next planned settings — priority, given "world provider first"

The parent's goal is a world provider, so the ordering below puts *what the
world contains* before *how it is dressed*. Each item is small enough to ship
alone, and each names what already exists.

**1. Water — one value, two call sites.**
`generate-from-heights-scenic` now takes `&opt opts {:sea-level N}`
(`worldgen.janet:212`); `scene-opts` already reads `sea_level` from the mapping
and accepts both spellings. Passing a raised sea (≈40) to **both** is the whole
change. This is first because without it the world has no water at all, and
three of the four references are fundamentally about water.

**2. A second and third tree silhouette.**
Reference C shows conifer + round broadleaf + flowering tree in one valley;
Reference D shows birch. Today there is exactly one tree. A broadleaf variant —
shorter trunk, wider canopy — is contained entirely inside
`scenic-worldgen.janet` using the existing wood/leaves IDs. This is the single
highest-impact change for "does this read as a world rather than a test scene",
and it needs no new blocks.

**3. Surface variety beyond height.**
Today `top-block` picks surface from height and slope alone, so every cliff is
uniform stone and every shore is uniform sand. Reference A/B want *material
adjacency*: sand, terracotta, grass in one view. This needs either more block
IDs (a content decision) or a second surface rule (a generator change). Flagged
as the first item that crosses from tuning into content.

**4. Regional rock/vegetation balance.**
`:rock-slope 6` is global. A second band (rock above 6, mixed 4–6) would produce
the transitional ground the references show. Cheap, and improves the valley
read immediately.

**5. Map coverage — the real blocker for "world provider".**
Everything above improves one 512×512 valley. A world provider implies more than
one valley. This is a producer-side question (larger raw footprint, or multiple
tiles) and should be scoped before Phase 17 content work runs out of map.
**Distant Horizons-style LOD is not the answer to this** and should not be
started here.

**6. Climate — name the consumer or drop it.**
The producer can emit climate; nothing reads it. Either a generator consumes it
(biome selection would be the natural first use) or the capability stays
documented-but-unused. Do not build a control for it in the meantime.

**Explicitly not in Phase 17**: rivers with flow routing, waterfalls, ores,
strata, fauna. Each is a subsystem, and the first three would need block IDs and
generator stages that do not exist.

## 7. Capture comparison protocol

So that "it looks better" becomes checkable, every comparison capture should
follow the same procedure — and be honest about what it does *not* prove.

**Procedure**

1. **Same viewpoint, same seed, same time of day.** Camera from a named preset;
   record seed, sea level, snow/tree lines, and the five other scene options in
   the capture's filename or a sidecar. A comparison without the options is not
   reproducible.
2. **Same clean-view state** (`--clean-view`): no HUD, no crosshair, cursor
   captured. A debug overlay in one of two frames invalidates the pair.
3. **Same image geometry.** Crop or letterbox both to identical aspect before
   comparing; never compare a 3624x2042 reference to an uncropped capture.
4. **Compare against the parent's description, not against invented numbers.**
   This document no longer carries per-image percentages (§0, retraction 1), and
   a comparison must not reintroduce them by measuring one image with an
   unstated classifier. If a comparison wants numbers, it must publish the
   classifier — thresholds, colour model, what counts as "rock" — so the same
   script can be run on both images. An unpublished classifier compared against
   nothing is not evidence.
5. **Read the pair side by side and write down what differs**, in words, before
   touching any knob. If the difference is "our rock is one flat grey", that is
   a material finding, not a terrain finding.

**What this protocol cannot establish**

- It does not show that Trinecraft *matches* a reference, and no capture should
  be described that way. Different block resolution, different art, different
  scale: matching composition is the realistic bar.
- It cannot evaluate atmosphere or motion from a still — clouds, fog behaviour
  and the day cycle need a short recording, not frames.
- A pixel classifier is insensitive to *arrangement* and to *meaning*. Two
  images with identical surface fractions can look completely different, and a
  classifier counts shadowed terrain and grey cloud as "rock". Numbers can gate
  a claim; they cannot make one.
- It cannot confirm the references' provenance. They are of unknown origin; a
  comparison shows resemblance, never derivation.

## 7a. Making §7 runnable — fixed conditions and proposed targets

§7 says what a comparison must hold equal. This section makes it executable. It
reports **no measurements** and revives **none** of the withdrawn percentages
(§0 retraction 1). Every number below is a **proposed threshold** or a **fixed
setting**, never an observation about Trinecraft or a reference.

### The reference must be identified before anything is measured

**A comparison starts with the pair, not with a number.** Before any metric is
recorded, the sidecar names both halves: the reference asset by **filename and
SHA-256** with its **normalized crop** (same aspect, same region, stated in
pixels), and the game capture by **seed, provider, size, preset, sky phase and
bounds**. If the reference cannot be tied to an actual file that way, the pair is
**UNSCORABLE and no percentage is reported** — the current described images are of
unknown provenance exactly like that.

A comparison needs a **named asset**: file path, **SHA-256**, pixel dimensions and
a short image ID, recorded in the capture sidecar. Without that identity the
reference is of **unknown provenance**, and the pair is scored **UNSCORABLE** —
not "passing by default", and not compared against a remembered impression.

This document's own §8 caveat applies: the local files in `~/Screenshots` could
not be mapped to the images described in §1 with confidence. Until a SHA-256 ties
one file to one described composition, **no local file qualifies as a reference
target**, and any comparison run today is UNSCORABLE by construction.

### Fixed conditions

Both captures in a pair hold all of these, recorded beside the images (filename or
a `.txt` sidecar):

| Condition | Hold at | Source |
|---|---|---|
| Reference asset identity | path + SHA-256 + dimensions + ID | sidecar, required |
| Camera FOV | **70°** | `main.janet:4842-4845` (literal `70`) |
| Viewpoint | one named preset, unchanged between captures | `scenic-presets`, `main.janet:192-201` |
| Day phase | one fixed `--sky-phase` (`0.25` noon, `0.5` sunset, `0.75` night) | `main.janet:134-135` |
| HUD | off (`--clean-view`) | `main.janet:157-160` |
| World settings | same seed, sea level, profile, and offset/scale | provider registry + slot manifest |
| World extent | same finite bounds; the camera **inside** them | artifact `bounds_inclusive` |

**Water animation is not controllable yet.** The water shader's `time` uniform
comes from the wall clock (`rl/get-time`, `main.janet:4850`), so wave phase differs
between captures taken at different moments. `--verify-pgo` substitutes a fixed
clock, but that is a parity mode, not a capture mode. Until a fixed-time override
exists, a comparison must **crop water out or accept uncontrolled wave phase**, and
no claim about water can rest on a still.

**Never a hero frame.** A camera outside the generated bounds photographs the
world's edge, not the world.

### View set

| View | Composition | Preset |
|---|---|---|
| grounded | eye-level ground filling the lower two thirds | `:grounded` |
| mid-valley | ridge and valley floor together | *authored — does not exist yet* |
| overview | summit, mid-slope and valley floor | `:aerial` |

`:grounded` and `:valley` are currently the **same** preset
(`main.janet:196-197`). A comparison wanting both grounded and mid-valley must
author the middle view; this document does not pretend it exists.

### Two metrics

**C1 — foreground relief, in voxel steps.** Voxel height is not comparable to a
reference's metres: the reference's physical scale is **unknown**, its vertical
exaggeration is **unknown**, and the model's metres pass through a fixed
`meters_per_voxel` (`25.0` in the artifact summary). Converting one to the other
would manufacture a comparison.

So the measurable form is **foreground vertical step range**: count the voxel
steps between the lowest and highest surface the camera can see in the foreground
band, read off the blocky silhouette (each step is exactly one voxel row, visible
by construction in this renderer). Report it as `N steps`, with the rectangle and
the view named.

**Its target is set manually after a reference is chosen** — there is no number
here, because choosing one before naming the reference is exactly the inference
§0 retracted.

**C2 — coverage, annotated by hand on a fixed grid.** Overlay a **16 × 9 grid**
(144 cells) on the fixed-aspect crop and record **two labels per cell**, not one:

1. **`surface`** — `forest`, `clearing`, `exposed rock`, `water`, `cloud`, `sky`,
   `structure`, or **`ambiguous`**.
2. **`ground-present`** — `yes` / `no`: is at least **a quarter of the cell**
   visibly terrain (occluded ground behind canopy still counts as present)?

The centre cell is the composition subject and is labelled first.

Rules that keep the annotation honest:

- **`ambiguous` is a legal answer and is excluded from every fraction**, with its
  count reported (`n ambiguous`) rather than folded into a neighbour.
- **Blue is not automatically water** and grey is not automatically rock. **Cloud
  is its own label**, never folded into sky or into terrain.
- Exposed rock is told from water by position in frame and edge behaviour, not hue.
- `structure` (trunks, built forms) is **not counted** in the coverage fraction;
  it is reported separately.
- There is **no catch-all label**. Anything not confidently labellable is
  `ambiguous`, and `ambiguous` never counts — so nothing an entity might be can
  slip into the numbers.

**The one published fraction — "projected scene coverage", not land coverage:**

```
forest fraction = forest cells / (forest + clearing + exposed rock)
```

This measures how much of the **projected scene** is forest out of the counted
terrain classes. It is **not** land coverage and not an area measurement.

Sky, cloud, water, structure and ambiguous cells are all **excluded from the
denominator**. Water is excluded deliberately: folding blue water into the
denominator would make a lake read as land, and would credit a map with forest it
does not have. If a comparison ever wants water counted, the denominator becomes
terrain + water and the result is reported as *projected scene coverage including
water* — a differently named figure, never silently mixed with this one. If the
denominator is **0**, the fraction is not 0 % — it is **UNSCORABLE**.

**Occupancy is a separate count.** `ground-present yes` cells give a second,
independent figure: how much of the frame is terrain at all, including canopy over
ground. This is deliberately not folded into `surface`, because "forest covering
ground" and "forest replacing sky" are different observations.

**The grid is not an area measurement.** 144 coarse cells labelled by eye are a
**manual proxy**, not a pixel-accurate percentage, and must never be quoted as one.
It is precise enough to detect "dense forest with no clearing" versus "half
clearing", and nothing finer than that.

### Acceptance — one proposed threshold

**Coverage acceptance is: within ±10 percentage points of the manually annotated
reference capture.** That is a **proposed threshold, not a measurement**, and it
cannot be evaluated until a reference is named and annotated (§ above).

No coverage ranges are published in this document. Ranges like "25–55 % forest"
were invented before any reference had been measured and are **withdrawn** for the
same reason as §0's percentages: a number nobody measured is a wish with a
decimal point.

**Baseline, stated honestly.** What exists is a **128-pixel learned map** — small,
with **dense forest and a finite edge**. Nothing here is upsampled to 512 to look
bigger. Reference quality has **not** been achieved, and Phase 17 remains a broad
plan that is **still pending**, not complete.

### Which controls can actually move the terrain

| Layer | Real controls | Moves learned relief? |
|---|---|---|
| Python provider (learned) | `size` 16–512 step 16, `sea-level` 0–128, `profile` (`alpine` only) | **No** — no relief control, and `profile` has one value |
| Procedural provider | `height-scale` 0.5–2.0, `height-offset` −16–64, `sea-level`, `forest-density` 0–100 | Yes, procedural only |
| Renderer | shadows, AO, volumetric light | **Not implemented as settings** |

So the **learned relief cannot be tuned from the menu**; `profile: alpine` is a
label, not a dial. Any implied learned "relief" or "biome" slider describes a
control that is not there.

### Outside this protocol

- **Flowing water, rivers, waterfalls** — no flow model, no basin; a separate
  subsystem.
- **Fauna and entities** — no creature system is known to exist in the inspected
  modules. Stated as **not validated / unimplemented, known modules only**, not as
  a proof of absence: the claim is limited to what was read.
- **Titanium, ores and strata** — an ore has no block ID to occupy in the current
  table; material roadmap, pending.
- **Climate and biome controls** — the producer can carry climate, nothing
  consumes it.
- **Shadows, AO and volumetric light** — renderer work, not exposed as settings.

### The worksheet — copy this and fill it in

One row per metric. **`actual` stays empty until somebody runs it**, and a row
whose `reference` column is empty is **UNSCORABLE**, not passing. Expected values
are **proposed**, never measured.

| # | Metric | Provenance (how it is obtained) | Expected (proposed) | Actual | Status |
|---|---|---|---|---|---|
| M1 | Reference asset identity | filename + SHA-256 + normalized crop, plus capture seed/provider/size/preset/phase/bounds | a named, hashable file | — | **UNSCORABLE — no reference named** |
| M2 | Capture conditions held | sidecar lists FOV 70, preset, sky phase, `--clean-view`, seed, bounds | all six present | — | not run |
| M2b | Ground occupancy | `ground-present yes` count over 144 cells | reported, not folded into M4–M6 | — | not run |
| M3 | Foreground relief step range | voxel steps between lowest and highest visible foreground surface | set after M1 | — | not run |
| M4 | Forest coverage | forest / (forest + clearing + rock), ambiguous and sky/cloud/water/structure excluded | ±10 pp of reference | — | not run |
| M5 | Clearing coverage | the same denominator as M4 | ±10 pp of reference | — | not run |
| M6 | Exposed rock coverage | the same denominator, rock by position/edges not hue | ±10 pp of reference | — | not run |
| M6b | Denominator usability | forest + clearing + rock cell count | > 0, else UNSCORABLE | — | not run |
| M7 | Cloud vs sky separation | same grid, `cloud` labelled separately | both labels present if either is in frame | — | not run |
| M8 | Ambiguous cells | count of `ambiguous`, excluded from every fraction | count reported | — | not run |
| M9 | World edge in frame | visual inspection of the capture | absent | — | not run |
| M10 | Clipping | artifact `summary.json`: `clamped_at_min`, `clamped_at_max` | both `0` | — | not run |

### One real artifact exists, and it is not a comparison result

A learned world **was** generated (`seed 12345`, `size 128`, `profile alpine`) and
its `summary.json` reports **no clipping**. That is the only populated evidence
available today:

- it says the relief landed inside the engine's band, which is a **M10-style fact
  about one map**;
- it says nothing about M1–M9, because **no reference has been named** and no
  annotated grid has been applied to any capture;
- it is **not** evidence of reference quality, and it must not be read as a pass.

So the honest summary of this worksheet is one line: **one artifact exists, zero
rows are scorable.** Filling M1 is the gate on everything else.

## 8. References

Accessed for this document; no content reproduced.

- Terralith — [Modrinth](https://modrinth.com/project/8oi3bsk5), [Stardust Labs](https://www.stardustlabs.net/terralith), [licence text](https://modrinth.com/project/8oi3bsk5/license)
- Tectonic — [Modrinth](https://modrinth.com/project/lWDHr9jE), [GitHub](https://github.com/Apollounknowndev/tectonic)
- William Wythers' Overhauled Overworld — [Modrinth](https://modrinth.com/project/II7t6llZ)
- Biomes O' Plenty — [Modrinth](https://modrinth.com/project/HXF82T3G)
- Distant Horizons — [CurseForge](https://www.curseforge.com/minecraft/mc-mods/distant-horizons)

The visual descriptions in §1 come from the parent's inspection of images the
user attached to the conversation. They are **not** a reading of the eight local
files in `~/Screenshots`, which could not be mapped to the attached images with
confidence, and they are not a claim about those files' contents.
