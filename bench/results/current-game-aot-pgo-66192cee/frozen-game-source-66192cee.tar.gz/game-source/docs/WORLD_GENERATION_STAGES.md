# World generation: staged roadmap and next slice

## Direction

Use the original Terrain Diffusion Python implementation for the initial trial. A future Janet/native model runtime or remote terrain provider is a separate production decision. Further scenic spawn-location selection is deferred until biome and world-feature information exists; keep current dry-land safety, without inventing terrain to force a spawn.

Generate requested chunks lazily. Initial loading prepares the surroundings needed for play, **not an entire 30-million-block world**. A seed defines a coordinate-addressable world; it does not require eager allocation of that world.

## Existing implementation

- Voxel chunks are 16 × 64 × 16, with stone/dirt/grass/sand/water and bedrock rules.
- Both legacy procedural heights and cached learned heights feed voxel construction. Diffusion currently supplies elevation only.
- The learned cache binds model weights, four configs, upstream source, frozen conditioning, local noise implementation and numerical/query settings into a SHA-256 identity.
- Chunk requests, bounded polling, persistence provenance and region CRC checks exist. Legacy procedural identities do not explicitly version future generation stages.
- Climate/biomes, caves, ores, biome vegetation and seeded structures are not implemented as game-generation stages yet.

The current 64-block height constrains vertical variety but does not prohibit shallow caves, ores or climate metadata. Sectioned chunks and region v2 remain Phase 13 work, not silently completed prerequisites. Likewise remaining lighting and streaming-performance work stays on the roadmap.

## Stage contract

Each stage needs a named version, explicit inputs and units, deterministic global-coordinate addressing, bounded requested-chunk work, and a persistence/identity policy **before it changes generated blocks**.

1. **World seed and base terrain identity.** Retain current seed validation; a full 64-bit/text seed interface needs an exact encoding and separate implementation, not conversion through a floating-point parser.
2. **Base elevation/density.** Existing diffusion or explicitly selected procedural generator. Never normalize each height tile independently.
3. **Climate metadata and biome classification.** Prefer upstream-coherent climate for diffusion worlds. Missing metadata is `unknown`, not silently plains or unrelated noise climate.
4. **Surface rules.** Explicit biome-to-material rules, adopted only under a composed generation revision. Existing caches and saves must not be relabelled.
5. **Subsurface features.** Deterministic cave carving and ore placement within the available vertical volume. A true below-zero/deepslate layer requires defining the world's vertical coordinate range first; current chunks have no negative Y.
6. **Vegetation.** Global feature anchors and stable per-feature seed derivation, with overlap rules so adjacent chunks agree regardless of generation order.
7. **Structures.** Region-level candidates, deterministic exclusion/priority rules and chunk-local projection. No overwriting persisted player edits when a neighbour is generated later.

Metadata can be optional without changing blocks. Once a stage affects voxel contents, its version and parameters must be included in a composed world-generation identity; the current diffusion model hash alone does **not** automatically identify newly added Janet surface/feature code.

## Next proposed slice: upstream climate projection, metadata first

The pinned upstream `WorldPipeline.get(..., with_climate=True)` already offers elevation and five climate channels. Current `PipelineSampler.get` requests `with_climate=False`, so this information is discarded today.

Source references:

- `terrain_diffusion/inference/world_pipeline.py`, `_compute_climate` and `get` (pinned checkout).
- `terrain_diffusion/inference/minecraft_api.py`, `_compute_climate_vars` and its biome classifier.

Channel interpretation from that source: elevation-adjusted mean temperature (degrees C), temperature seasonality (source standard deviation ×100), annual precipitation (mm/year), precipitation variability (coefficient of variation, percent), and an elevation-temperature correction coefficient (degrees C/metre). The fifth channel is **not humidity**. Derived aridity or moisture measures need their own documented formula/version.

### Bounded implementation sequence

1. Specify the climate projection contract: exact channel order/units, coordinate sampling, finite-value validation, storage format and capability binding to the height tile and inference identity. Do not select unmeasured fixed-point scales. Float32 metadata is a reasonable first candidate (five × 256 × four bytes = 5120 bytes per chunk).
2. Add an explicit opt-in producer path sampling climate and elevation together in the same canonical query windows. Measure the extra inference/transfer cost and value ranges on a small serial real-model query.
3. Add a bounded, validated Janet metadata reader. A separate versioned sidecar is a candidate to preserve existing TDH2 height tiles; a combined format is an alternative requiring an explicit migration/read-compatibility design. **Neither layout is selected or implemented yet.**
4. Classify a small documented biome set from the climate values, elevation and water state. Reusing the pinned upstream classifier is an option, but it is private upstream API and still needs range and compatibility checks.
5. Only then adopt surface changes under an explicit composed generation revision, with old saves remaining identifiable and player edits authoritative.

An independent native climate field may be useful for explicitly selected procedural worlds. It must not silently substitute for unavailable diffusion climate.

### Verification requirements

- Exact producer → encoded bytes → Janet round trip; CRC/identity/capability mismatches fail closed.
- Finite values, missing channels, wrong shapes and absent metadata handled explicitly.
- Positive/negative coordinates, adjacent windows, overlapping queries, isolated/batched/reordered requests, fresh process and warm-cache comparisons.
- Temperature/elevation coupling tested against the actual returned elevation, not an independently resampled height field.
- Default legacy procedural output and PGO hash unchanged while the new stage is off.
- Existing height-only cache and saved regions unchanged; new block-affecting stages cannot masquerade as old generation identities.
- No claim that finite tests establish cross-device bit equality or unlimited traversal stability.

## Roadmap ordering

Finish loading/worker verification first. The next world-generation slice is the climate metadata contract and a small optional projection/reader trial, not an immediate full biome/structure generator. This does not mark Phase 12 lighting, Phase 13 sectioning, later gameplay systems or Phase 17 world content complete. Final spawn scenery is revisited after those data sources exist.
