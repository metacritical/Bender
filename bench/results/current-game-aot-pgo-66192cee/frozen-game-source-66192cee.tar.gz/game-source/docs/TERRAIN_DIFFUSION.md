# Terrain Diffusion — verified status, and how to run it

Real pretrained terrain reaches gameplay through a file cache. `init` → `bake` →
308-byte TDH2 tiles → the game reads them. No model runs on a frame.

## The current pin

```
identity  1d1867a350d3786f84f902b6335242aae0850dfa4d5c761d103789277944c7cf
cache     tmp/terrain-final-real/1d1867a3…      (26 tiles, 0 errors)
pins      stats 528754ea…68bdbe3 · weights 0c898776…6d01f0 · configs 1f85c6c5…
geometry  seed 12345 · origin [100000,100000] · ppv 1 · window 4
          max_samples 64 · decoder 512/384 · T 2 · dtype fp32 · device mps
```

It holds the complete 25-tile (−2..2)² spawn box plus one worker tile at `(3,0)`.
Pins and geometry are hashed: change any and you get a **different identity
directory** rather than a corrupted one.

| Cache | Tiles | Pins | Use |
|---|---|---|---|
| `tmp/terrain-final-real/1d1867a3…` | 26 | stats + weights + configs | **play or continue from this** |
| `tmp/terrain-inland-spawn/5c23492e…` | 25 | stats + weights | same payloads, no config pin |
| `tmp/terrain-cache-inland/33f07baf…` | 41 | stats only | **legacy**, excluded from claims |

## Commands

Every command below runs with `PY=tmp/terrain-runtime/venv/bin/python`.
`doctor`, `descriptor`, `init` and `bake --dry-run` are **standard-library only** —
no torch, no GPU.

### Answering the game (the command that matters)

`--cache-root` takes the **cache root**, not the identity directory (passing
`…/terrain-final-real/1d1867a3…` double-nests and finds nothing). Root plus the
bake flags is what resolves to `1d1867a3…`:

```sh
PY=tmp/terrain-runtime/venv/bin/python

$PY tools/terrain_backend.py worker \
  --cache-root tmp/terrain-final-real \
  --stats-json /tmp/pd.json \
  --seed 12345 --pixels-per-voxel 1 \
  --origin-x 100000 --origin-z 100000 \
  --window-chunks 4 --max-samples 64 \
  --decoder-tile 512 --decoder-stride 384
```

The game's `--terrain-cache` is the opposite: that one **does** want the full
identity directory, e.g.
`--terrain-cache tmp/terrain-final-real/1d1867a3…`.

Leave it running; the game drops `<cx>_<cz>.req` markers and the worker turns them
into tiles. **It requires an existing identity** — it refuses an absent one rather
than creating a cache, so `init`/`bake` must have run first — and it refuses
drifted flags without inventing a second directory. One inference process at a
time.

### Building a cache (from empty)

```sh
PY=tmp/terrain-runtime/venv/bin/python
F="--cache-root tmp/terrain-final-real --stats-json /tmp/pd.json \
   --seed 12345 --pixels-per-voxel 1 --origin-x 100000 --origin-z 100000 \
   --window-chunks 4 --max-samples 64 --decoder-tile 512 --decoder-stride 384"

$PY tools/terrain_backend.py init $F              # once; creates the identity
$PY tools/terrain_backend.py bake $F --chunks -2 -2 3 3
```

`doctor` runs six checks (`snapshot`, `config`, `upstream`, `stats`, `noise_lib`,
`cache`), exiting 0 only if all pass.

## Setup

1. **Python** 3.14.2 with `torch` 2.13.0 and `numpy` 2.5.1 present, in a venv
   created `--system-site-packages` so torch is not reinstalled:
   `python3.14 -m venv --system-site-packages tmp/terrain-runtime/venv`
2. **Dependencies** (verified importing): `diffusers 0.42.1`, `ema-pytorch 0.8.3`,
   `infinite-tensor 0.4.0`, `numba 0.68.1`+`llvmlite 0.50.0`, `scipy 1.18.1`,
   `h5py 3.16.0`, `rasterio 1.5.2`, `scikit-image 0.26.0`, `matplotlib 3.11.2`,
   `torchvision 0.28.0` (`--no-deps`, it pins `torch==2.13.0`), `safetensors 0.8.0`,
   `huggingface-hub 2.3.0`, `Pillow`, `flask`, `click`, `tqdm`.
3. **`pyfastnoiselite`** is a hard import dependency and the pinned 0.0.6 does not
   build on 3.14 (removed symbol `_PyDict_SetItem_KnownHash`; `ld: library 'c++'
   not found`). The venv's binary is a **hand-built replacement** with no
   `dist-info`; `doctor` reports its digest and the note `bespoke build; not
   claimed bit-identical to PyPI 0.0.6`. Its numerics feed the noise quantiles.
4. **Weights** — fetch the pinned snapshot once, never a moving Hub id:

   ```sh
   huggingface-cli download xandergos/terrain-diffusion-30m \
       --revision 9ef8030cb805b433b98ec25c5dddefbac07a9e26 \
       --include "*.json" "*.safetensors" --local-dir <snapshot>
   ```

   All four configs and three safetensors are pinned by SHA-256 **and** size, size
   first so a truncated download fails in ms (≈0.73 s on the real 1.1 GB
   snapshot). `load_sampler` re-checks both before importing torch.
5. **Frozen conditioning stats** — the world definition:

   ```sh
   curl -sSL -o /tmp/pd.json \
     "https://huggingface.co/xandergos/terrain-diffusion-30m-onnx/resolve/ad2df557eca5645f588766101cf3bc3682455c3e/pipeline_data.json"
   ```

   `stats_sha256` = **`528754ea…68bdbe3`** is enforced inside
   `extract_frozen_stats`, the single route from bytes to an identity, so every
   command refuses another table — no opt-out, and a missing or extra key fails
   there too. `fetch-stats --out <path>` does the same download.
6. **Never regenerate the table.** Upstream recomputes it from ETOPO + WorldClim
   rasters that are not shipped, and a local recompute does not match: channel-0
   quantiles differ by up to **69.1 m**. `_compute_map_stats` is a raiser.

## Pins

| What | Pin |
|---|---|
| Code | [xandergos/terrain-diffusion](https://github.com/xandergos/terrain-diffusion) `e8dcb4b1a834ab2f6b1a6f5256ed7c9f2f3e8230` (MIT) |
| Tensor lib | `infinite-tensor` 0.4.0 (MIT) |
| Weights | [`terrain-diffusion-30m`](https://huggingface.co/xandergos/terrain-diffusion-30m) `9ef8030cb805b433b98ec25c5dddefbac07a9e26` |
| Frozen stats | [`terrain-diffusion-30m-onnx`](https://huggingface.co/xandergos/terrain-diffusion-30m-onnx) `ad2df557eca5645f588766101cf3bc3682455c3e` |

Weights are MIT, ungated, F32, ≈1 137 682 120 B.

**Why the 30 m model.** It is upstream's standard released checkpoint and the
only one pinned here. The 90 m weights are a *different world*, not a rescaled
30 m one — the same seed and origin do not describe the same terrain, so the two
share no cache, identity or comparison. Upstream publishes other variants; none
were evaluated or chosen, and no claim here transfers to them. Switching
resolution means a new pin, stats table, identity and bake — not a flag. Do not
download a model to "try" one: `verify_weights`/`verify_configs` refuse an
unpinned checkpoint, which is exactly what the pin table is for.

## Hashed query geometry

Every query is a **canonical window**: chunk-aligned, anchored as
`floor(cx / window_chunks) * window_chunks`, always fetched whole. The pixels the
model sees depend only on the window index, never on what else was in the batch:

```
isolated chunk / 5×5 batch / reordered batch → get(0, 0, 64, 64)
```

Negative chunks stay on that grid: `anchor(-1) = -4`, `anchor(-5) = -8`.

The identity hashes `{strategy, origin_pixels, window_chunks, window_pixels,
max_samples, pixels_per_voxel}`, the decoder pair and `weights_sha256`:

- `--pixels-per-voxel` 2/4/8 needs a matching `--max-samples` (e.g. `4` with
  `256`); at the default 64 the window check refuses and names the flag.
- `--max-samples` changes the digest without changing a query, so **use one flag
  set for `init`, `bake` and `worker`** (creation rules are under *Commands*).
- `--decoder-tile 256 --decoder-stride 384` is refused; the pair is `512/384` or
  `256/192`.
- **Pins only accumulate, and each addition retires older caches.** A *new*
  identity with the full pin set is writable, but an identity stored under an
  older schema is refused — its manifest predates pins this code now requires, so
  `bake`/`worker` reject it rather than extend it. Of the caches on disk,
  `1d1867a3…` is the current one; the rest are read-only legacy. Regenerate
  rather than extend, never rewrite a manifest to force a match, and do not
  migrate an old tree forward assuming unchanged output.

## What the cache looks like

Under `<cache_root>/<identity_digest>/`: `manifest.json` (identity),
`manifest.janet` (bridge the game reads), `stats.json`, `identity.json`,
`requests/<cx>_<cz>.req`, `tiles/<cx>_<cz>.tdh`, `errors/<cx>_<cz>.txt`, plus the
producer's own `worker-status.janet`, `worker-launch-<token>.janet` and
`.worker.lock` (never written by the game).

Tiles are 308 bytes, `payload index = x + 16*z`. Sampling is a point lattice —
voxel `(x,z)` reads pixel `((cx*16+x)*ppv, (cz*16+z)*ppv)` — so a column's
elevation is a pure function of its global pixel coordinate. Request markers must
be canonical `<int32>_<int32>`; anything else is reported in `invalid_markers` and
skipped, never fatal, never aliased.

## Game integration (`main.janet`)

- `--terrain-cache <identity-dir>` selects the cache (the **full** dir, unlike the
  worker's `--cache-root`); absent, the procedural path runs byte-identically.
- Preflight probes the 25 spawn tiles **before** any window or GL context; a miss
  requests them and exits naming the coordinates, never falling back to noise.
- **A seed mismatch is refused before the window opens** — `--seed 4` (the
  default) against this `12345` bake exits 1 with no window, verified. Otherwise
  the game would serve another world.
- The directory name must equal the manifest identity: the identity directory *is*
  the addressing scheme, so a mismatched name is refused.
- `stream-step` polls and generates from tiles; the noise generator is unreachable
  from the cache branch. The void guard tests all four collision-box corners and
  the centre, restoring the position snapshot on a miss.
- **Persistence gate:** load reads bytes → CRC → identity gate; only
  `:match`/`:unverifiable` proceed, and decoding uses **the exact gated buffer**,
  not a second read. Saves gate on the CRC on disk; an unknown-provenance session
  is refused when overwriting a path that has a sidecar.

## What it looks like

`tmp/terrain-final-real-game.png` — aerial `--sky-view`, 120 frames, no edits,
**inspected**: grass hills with a flat clamped plateau. A **small world, not a
beautiful vast one** — the data, not the renderer: heights 50–60, 52.8 % at
the ceiling.

```
frames: 120  avg 147.2 FPS (6.79 ms)  worst 225.6 ms  spikes >33ms: 1
worst frame: #21  225.6 ms wall, 4.0 ms CPU (2% busy), mesh queue 0
scene: radius 6  loaded 25  drawn 3  wanted 113  streamed in 0 out 0
```

**Not a 60 FPS guarantee.** The one 226 ms wall stall is four lost frames at
60 Hz, it burned only 4 ms of CPU, and the cause is **unexplained** — so
recurrence cannot be ruled out. All the capture supports is: on this machine,
over a fully baked spawn box with the model idle, steady state is ~6.8 ms.

`loaded 25 drawn 3 wanted 113` says it plainly: the spawn box and its edges, not
a wide-world screenshot.

## Evidence

Full record with proof commands and caveats:
[`docs/TERRAIN_VALIDATION.md`](TERRAIN_VALIDATION.md). Reproduced on this machine:

- the 25-tile spawn batch repeats **byte for byte** across two fresh releases;
- **order does not matter**: one fresh pipeline queried `(0,0)`, `(−1,−1)`,
  `(0,−1)`, `(−1,0)`, `(−1,−1)` and **all five matched the independently baked
  cache, 0 differing heights** — 101.94 s cold, then 0.013–0.017 s warm, 111.77 s
  total. Reordered and repeated queries hit the same bytes, not just the same
  shape (`tmp/terrain-real-order-test.log`);
- the worker served one request end to end (`ticks 1, tiles 1, errors 0`), and
  `(3,0)` matches `5c23492e…` and `33f07baf…`; no seam exceeds **1** step.

A **whole-batch repeat on one machine**, not a universal determinism proof: no
larger region has been baked twice, and nothing is claimed for another GPU or
another `pyfastnoiselite` build.

**`33f07baf…` stays unresolved.** Its positive quadrant and `(3,0)` match every
later identity, and only negative-coordinate tiles diverge — all `+1`, none down —
which narrows where a cause could live without naming one. The passing order check
does not retroactively explain that cache's history, and no hypothesis about it is
stated as fact.

### Verification commands

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s test \
    -p 'test_terrain*.py' -q            # 194 tests

tmp/terrain-runtime/venv/bin/python tools/terrain_backend.py descriptor \
    --seed 12345 --origin-x 100000 --origin-z 100000 \
    --window-chunks 4 --max-samples 64 --pixels-per-voxel 1 \
    --stats-json test/fixtures/pipeline_data.json   # → 1d1867a3…

./run.sh test                            # the Janet side
```

`test/fixtures/pipeline_data.json` is the official table, committed so the pin is
tested against the real file rather than skipped. The native build
(`build/trinecraft-terrain`) is built from `main` at `ffa78f8`.

## Measured cost (M2 Pro, 16 GiB)

| Measurement | Value |
|---|---|
| `from_pretrained` + `to("mps")` + `bind()` | 5.2 s (cached weights) |
| cold 64×64 region, far coordinate | **≈105 s** (101.94 s observed) |
| repeat query of the same region | 0.00 s |
| device memory | 4.47 GB of 12.71 GB (post-hoc, not a peak) |

**Playing a baked cache costs no GPU** — the model process is idle, which is why
6.79 ms is a *cached* figure. Cold generation is ~105 s per region and a 25-tile
bake takes minutes, so generation always runs ahead of play; a worker asked for a
tile past the baked area pays that in the background, not in a frame.

### MPS: experimental

Upstream targets CUDA, falls back to CPU, and never selects MPS; `torch.compile`
is force-disabled without CUDA, so Apple runs are eager-mode. Two observations,
**neither with a proven cause**:

- `kIOGPUCommandBufferCallbackErrorImpactingInteractivity` warnings recur under
  unthrottled inference — non-fatal in both completed bakes, so not a failure
  signature on their own.
- Two earlier attempts were killed by the operator to protect the GPU, with no
  Python traceback in either log. Since then the 25-tile batch has completed twice
  cleanly; anything **larger** is unproven.

Run **one** inference process, never beside interactive QA; prefer
`--decoder-tile 256 --decoder-stride 192` if the watchdog appears. No claim that
two Apple GPUs produce identical bytes.

## Integration, not a port

The inference stack is **Python and stays Python**: `diffusers`, `torch` and the
pinned `terrain_diffusion` checkout run in `tools/terrain_backend.py`. Janet has
no UNet, scheduler or decoder, and this page claims none.

What *is* integrated is the boundary: Janet owns the 308-byte wire format, verifies
CRC-32 and payload digests itself, drives the file queue, and builds chunks from
tile heights with no procedural fallback. So "integration" means **real pretrained
terrain reaches gameplay through a cache contract both sides verify.** Porting the
model to Janet is a different project, not planned here.

## Limitations

- 26 tiles exist; the game wants 113 chunks, so most of the view is unbaked.
- The spawn box is ceiling-clamped (heights 50–60, 52.8 % at 60): hills and a
  plateau, not mountains.
- `33f07baf…`'s 573 one-voxel diffs are **unresolved**; no cause is asserted.
- Cold cost ~105 s per region, ~60× the paper's 512²-in-1.72 s; scattered queries
  are inefficient and long-range search is unsupported. `T=2` can leave artifacts.
- Older caches cannot be extended: their identities predate one or more pins.
- `world_pipeline.py` imports matplotlib, scikit-image and rasterio at import
  scope; never import it where it is not needed.

## Next

1. Bake beyond the 26 tiles so the 113-chunk view is real.
2. Pick an origin/seed whose height distribution is not ceiling-clamped.
3. Bake a second, larger region twice to extend the repeat claim past 25 tiles.

Already done: the batch repeats byte for byte, a worker served `(3,0)` outside
it, and Janet reads all 25 real tiles through its TDH2 consumer — both decoders
agree on real payloads, not only fixtures. Proven end to end on a real spawn; the
world is not yet big or varied enough to be a place.
