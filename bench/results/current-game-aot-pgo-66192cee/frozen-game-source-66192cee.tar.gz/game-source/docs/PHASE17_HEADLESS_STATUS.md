# Phase 17 headless implementation status

Phase 17 is **incomplete**. This record distinguishes shipped paths, opt-in foundations and open acceptance gates. It does not replace the 22-phase roadmap.

## Delivered and exercised headlessly

- **Authored clearings:** connected seeded disks suppress tree anchors consistently across chunk boundaries and negative coordinates. Default zero preserves the pinned pre-change chunk baseline. Density is cell-selection frequency, not measured cleared-area percentage.
- **Versioned creation settings:** procedural settings v2 carry clearing density through provider validation, New Game form state, request, identity and save/load tests. Legacy settings v1 remain supported without silently widening their four-key contract. Python generation retains its separate controls.
- **Material descriptions:** nine existing block IDs remain unchanged. World block names derive from the frozen registry with drift guards. Hot collision predicates retain existing unknown-ID behavior. Planned soils, strata and ores, including titanium, have no active IDs or textures.
- **Optional climate reader/cache:** bounded producer-compatible bytes and explicit attachment, origin and integer scale. Exact map coverage is required; no guessed projection, resampling or sidecar discovery occurs. Cache data is owned and immutable to callers. Missing climate remains unavailable and does not change height access.
- **Authored biome policy:** pure classification and existing-ID surface choices; scenic fill has an explicit opt-in surface policy. Synthetic tests exercise the actual reader → attachment → world-coordinate cache query → fill chain, including desert sand, missing climate, negative coordinates and seams. Default terrain remains unchanged. Thresholds and surface choices are authored, not learned model output.
- **Static drainage:** bounded deterministic downhill routing and accumulation over an owned finite height grid. No-data cells carry no flow and river eligibility requires drainage. This is analysis, not terrain carving or water simulation.
- **Spawn safety:** the search receives the session/map sea level rather than hardcoded 28. The default waterline remains 28; a corrected inclusive boundary permits dry supported feet exactly at `sea + 1`, so a newly selected pose can differ at that edge. Generic search bounds follow build height, not the procedural UI's 128 limit. Tests cover low/high waterlines, invalid settings and decorated conifer chunks. Existing loaded player poses are not replaced by a new spawn search.
- **Production save handoff:** `new-slot-options` now passes the selected settings version into catalogue creation. A headless regression calls this same production builder and creates/reloads a v2 slot from disk, pinning clearing density, identity and chunk retention. This fixes a missing-version bug that direct catalogue tests alone did not catch.

## Open production and acceptance gates

1. **Climate availability:** current saved artifacts are not automatically populated or attached with climate by a session. A real owned export/load path, projection provenance and integrity contract are needed before climate-driven surfaces can be offered as a production generation profile. Existing worlds must not silently change.
2. **Biome surfaces in sessions:** the opt-in fill path is proven with synthetic climate, not selected by the ordinary creation/session pipeline. Persist its policy revision before enabling it. No rendered biome acceptance is claimed.
3. **Vegetation:** current authored forest is conifers plus clearings. Varied trees, shrubs, flowers and ground cover are not implemented or visually accepted.
4. **Materials and underground content:** new soils, strata, ores/titanium, caves and negative-Y design remain unfinished. Registry descriptions are not new blocks.
5. **Hydrology:** rivers, lakes, coast handling and waterfalls are not produced by the drainage-analysis module. Flowing water remains separate.
6. **Features and spawn:** structures and richer features still need implementation and identity versioning; final scenic acceptance must run after those exist.
7. **Reference quality:** accepted named reference assets and scored comparisons remain open. Undefined references are UNSCORABLE.
8. **Learned runtime:** native learned generation stays unavailable. Capture tooling/arithmetic improvements are not full numerical equivalence, packaging, rights review or Python-free new/save/load acceptance.
9. **Display-dependent checks:** interactive retry, terrain appearance, seam visibility and visual/performance acceptance cannot be claimed from these headless runs. No game window should be launched while the monitor is off.

## Reproducible headless gates

```sh
./run.sh test
./run.sh test-native-arithmetic
./run.sh test-capture-contract
```

The default harness includes climate, biome surface, static drainage, material compatibility and the actual scenic-climate integration test. Other suites retain save, provider, loading-screen and world compatibility checks. Model-free arithmetic/capture commands are separate and do not perform inference.

Compiler: keep `/Users/pankajdoharey/Development/Projects/janet` pinned at `c07042a7`. Preserve existing worlds, model artifacts, the full 22-phase tree and the stopped gameplay-cache agent. Do not restart old queued inference assignments.
