# The temporary Python terrain provider

Trinecraft can generate a **learned** New Game world today, from the real pinned
Terrain Diffusion model, by running a Python process once per world.

**This is a temporary dependency, authorized by the user for the New Game
milestone. It is not the shipping runtime and it is not goal completion.** The
end state is native generation with no Python at all
(`docs/NATIVE_GENERATION_AUDIT.md`); until that is verified, the learned *native*
provider stays `available false` in the provider registry.

## What runs

`tools/terrain_new_game.py` loads the pinned upstream `WorldPipeline` — the same
snapshot, weights, submodel configs and frozen conditioning table the offline
backend binds — samples one bounded rectangle, and exports a **scenic format-3**
(TDS3) cache the existing Janet reader already consumes. It reimplements no
inference and invents no second artifact format.

Interpreter: `tmp/terrain-runtime/venv/bin/python`, the project venv — not a bare
`python3`. `--terrain-python` overrides it for another machine.

`--terrain-python-script` is a **developer override**: it points the same argv slot
at another script so failure and cancellation paths can be exercised without a
model. It is not a feature and changes nothing about the generation path, which is
what lets a fake run be evidence about the real one.

## One owned process, and nothing else

Generation is a single child process, owned by the game for its whole life
(`src/generation-job.janet`):

- **No other workers.** New Game does not start a second process, a shell, or a
  detached worker.
- **Cancel is TERM, then KILL after a 5 s grace** (`cancel-grace-seconds`). The
  child sets a flag checked between stages; a call inside the model's C code
  cannot be interrupted, so the hard bound is the group kill.
- **The PID is recorded and reaped.** A failed teardown that could leave a live,
  unreapable child is itself an error, not a warning.
- **Logs and progress** are files, not a pipe: the provider's JSON goes to
  stderr, and the pollable channel is an inert Janet sidecar
  (`{:version 1 :stage :sample :completed 1 :total 8 …}`). Nothing blocks a frame
  reading it.

Every read is bounded and every write is atomic, so a poller never sees half a
record.

## Seeds

A world seed is an integer in **0 … 2147483647** (31 bits), the same range the
procedural generator reduces to.

**Seed 0 is remapped, deliberately and visibly.** Upstream treats a falsy seed as
"draw a random world", so a world recorded as seed 0 would not describe its own
terrain. The provider maps world seed 0 to model seed 2147483647 under
`seed-mapping-version 1` (`src/world-provider.janet:44-61`), and records that
remap in the slot's provenance.

The consequence is stated rather than hidden: **world seed 0 and world seed
2147483647 generate identical terrain.** That is a recorded collision, not
aliasing — a reader of the manifest can rediscover the rule instead of guessing.

## Settings in New Game

The form opens on the **procedural** provider. Reaching the Python provider is a
keyboard sequence, not a default:

1. `Tab` cycles focus **name → seed → provider → each setting**, and back to name.
2. With **provider** focused, `←` / `→` change the selection
   (`src/world-menu-view.janet:314-326`, `main.janet:3131-3134`).
3. With a **setting** focused, `[` / `]` decrease and increase it.

Changing provider resets the settings to that provider's own defaults, so no
value leaks between providers (`src/world-menu-view.janet:320`). An unavailable
provider stays reachable so its reason can be read — selecting one never
authorises creation, because the create request refuses it.

The Python provider exposes three controls (`src/world-provider.janet:28-35`):

| Control | Range | Default |
|---|---|---|
| `Map size (px)` | 16 … 512, step 16 | **128** |
| `Sea level` | 0 … 128 | **28** |
| `Generation profile` | `alpine` (the only value) | `alpine` |

The provider row reads **`Terrain Diffusion - Python (temporary)`**. It is an
ASCII hyphen, not an em dash — verified in the source, because that string is
what a capture has to match.

`tmp/python-provider-new-menu.png` (1280×800, opened and inspected) shows the
form with the Python row **white and marked available** and the native row **red
and marked unverified**. That proves the row is **visible and correctly labelled**
in the real UI. It is not proof that a player selected it: the click path itself
is covered by the unit suite, not by that capture.

**The map is 128 voxels across, and that is the real size.** It is a finite map,
not a 512-wide world with the extra space faked by upsampling. `--size` may be
raised toward 512, but the default generates exactly what it says.

## Command line

```sh
./build/trinecraft-worlds \
  --new-world "Learned QA" \
  --world-provider python \
  --world-seed 12345 \
  --world-size 128 \
  --terrain-device mps \
  --world-root worlds-v1 \
  --frames 10
```

`--frames` is a **QA-only** mode: it runs a fixed number of frames and skips the
save-on-exit. Run the same command **without** `--frames` and the session saves on
a normal exit, as any other world does.

## Saving and reloading

The generated artifact is saved into the slot the catalogue owns. Reloading that
world **runs no Python**: the artifact is data on disk, read by the existing
reader. So a generated world is playable offline, and the model is only involved
in the moment of creation.

## No downloads, no surprises

- **Nothing is auto-downloaded.** Weights, configs and the conditioning table must
  already be present; readiness is checked locally and reported.
- `--check` reports readiness and **writes nothing**, so a probe can never be
  mistaken for a run.
- Exit codes are distinct: `0` artifact ready, `2` refused preconditions, `3`
  generation failed, `130` cancelled.

## A clipped map is refused, not shipped

Height is quantized into the engine's band. If the model's output lands entirely
outside it — **100 % of samples clipped** — the run writes **no `READY` marker**
and reports that the map is not a world. The artifact stays on disk as a
diagnostic and is explicitly not marked ready.

The user is then told to **choose another seed**. There is **no procedural
fallback**: a learned world that failed does not quietly become a noise world
under the same name.

## QA status — real runs

A learned world generated, saved and reloaded with **no Python at load time**.

| | |
|---|---|
| Seed | **12345** (world seed = model seed; no remap) |
| Size | **128** px, origin the known-land point `100000` |
| Device | **MPS** |
| Artifact | **64 tiles**, identity `6e97877c…` |
| Raw source range | **793.7702 … 1765.4589 m** |
| Clamping | `clamped_at_min 0`, `clamped_at_max 0` — nothing hit a band edge |
| Stored band | `height_min 4`, `height_max 252`; `sea_level 28` |
| Geometry | `meters_per_voxel 25.0`, 16 384 voxels total |
| Saved slot | `e6b4ce90e2e87b771531371e313a0dbb`, root `tmp/python-learned-land-qa` |

Every figure above is read from the artifact's `summary.json` or the slot's
`manifest.janet`. The clamp counts matter most: a map that clipped nothing is a
map whose relief actually landed inside the engine's band.

**Reload was proven without the model.** A later run reopened the saved slot with
`--terrain-python` pointed at a **nonexistent** interpreter and succeeded. The
artifact is data; the saved world does not need Python to exist on the machine.

### What the fixes were

- **The old spawn Y 90 was not underground.** It was **standing on leaves** —
  the canopy enclosed the view, which is what made the screenshots look like the
  camera was buried. A parent trace showed the seat at 90 both before and after
  physics. (The "y 50 underground" reading was a misread of the font, not a
  separate bug.)
- **Spawn selection was fixed** (`2411321`) to put a future world on natural
  ground rather than in a tree.
- This QA-only slot's pose was repaired through the **normal catalogue save** to
  `[40.5, 86, 40.5]`, which retains the previous snapshot rather than editing it.

### Evidence

- `tmp/python-learned-land-natural-spawn.png` — **inspected, passes**: real grass
  on a mountain slope under forest and a tree. This is the image that shows the
  terrain is valid ground.
- `tmp/python-learned-land-high-view.png` — a high view from beyond the bounds,
  showing a cliff and the finite edge of the world. Useful for showing the world
  ends; **not** a hero image.
- `tmp/python-learned-land-qa.png` — the **first** capture, with the camera inside
  the canopy. It is *not* evidence of terrain quality, and it is not cited as such.

### What this does and does not establish

It establishes that learned New Game produces a finite world of valid terrain
that saves and reloads without Python.

It does **not** establish visual quality. The inspected images show dense forest
and a finite edge — **not** a reference-looking scenic beauty shot, and this page
does not claim one has been achieved.

### Failure history

The **first** real seed 4 run happened **before** the clipping refusal existed.
It stored an all-clipped map, and its artifact was preserved as a **debug
artifact — not a usable world**. The refusal landed afterwards (`0984aa1`), and
that commit's test **replays** the condition and refuses it. So the guard was
proven by a replay, not by that run — the early run was a failure that shipped a
debug artifact, and calling it "correctly refused" would backdate a guard that
did not exist yet.

### Operational state

- **No latency figure is claimed.** A CPU run was once noted at roughly fifteen
  minutes and an MPS run finished within a couple of minutes, but no elapsed time
  was recorded, so neither is a measurement.
- All model PIDs from these runs (`58134`, `58155`) were **reaped**, and `ps`
  shows none.
- Final verification after the spawn fix passed: all 30 default suites, 85
  Python provider tests, the actual generation-loop tests, and the real-child
  synthetic-provider integration tests. Logs are `tmp/temporary-python-delivery-*.log`.
- The existing native executable `build/trinecraft-worlds` was rebuilt successfully
  with the temporary provider and the spawn fix; build log:
  `tmp/temporary-python-default-build.log`.

## Availability, stated precisely

Python availability is now computed from a **per-session offline readiness check**.
The static registry fails closed until that check succeeds. `--check` validates
local pinned snapshot/config/weight/stat/source files without loading a model or
performing inference, and writes no generated output.

The check and generation share the same owned process slot. A timeout,
cancellation, missing interpreter, or unsuccessful check leaves the provider
unavailable; a late exit cannot reverse a cancelled result. Saved-world loading
does not perform this check or require Python. Short single-line menu reasons
retain their full diagnostic in the readiness record.

**New Game with the Python provider requires the pinned runtime files to be
present locally.** If they are missing, generation fails with an explicit error
rather than silently substituting procedural terrain. Nothing is downloaded
automatically.

The **native** provider remains `available false`, and the Python provider is
deprecated — removed — once generation is Python-free.

## Readiness and ordinary-exit acceptance

- `tmp/round4-readiness-menu.png`: native menu inspected after the real offline
  package check; Python enabled, native learned pipeline still unavailable.
- `tmp/round4-missing-python-readable.png`: native menu inspected with
  `--terrain-python /nonexistent/python`; Python unavailable with a readable reason.
- A normal native procedural session (no `--frames`) was edited through its local
  development console, teleported, then exited with `(quit)`. The same quit flag
  as Esc runs normal teardown. The log records `catalogue: saved ... on exit`.
- Reloading that QA slot confirmed the edited block and final physics-adjusted
  pose persisted. This is actual ordinary-session teardown evidence, not a claim
  that a human clicked the window-close button.
- Interactive provider cancellation/failure now returns to the retained form;
  direct QA requests still exit explicitly. Recovery control flow was reviewed,
  but the interactive failure-to-retry path has not been visually exercised.

## Event-loop compatibility verification

The process supervisor now uses the current interpreter's cooperative
`ev/sleep 0` yield instead of the unavailable `ev/pump` extension. This is not
a no-op fallback: the real two-child smoke test checks that polling a live
`/bin/sleep` child returns within a frame budget, then observes successful exit
and TERM cancellation with both children reaped.

After this change all 32 game suites passed again
(`tmp/round13-restored-game-tests.log`), and `build/trinecraft-worlds` rebuilt
successfully (`tmp/round13-native-build.log`). No model inference was required.

## Related

- `docs/NATIVE_GENERATION_AUDIT.md` — the native route and what remains.
- `docs/PLAN.md` §17f — this milestone, marked in progress.
- `docs/TERRAIN_DIFFUSION.md` — the pinned model, identity and cache contract.
