# TrineXraft — an enchanted voxel world that tells its own stories

**This file is the canonical plan.** Repo `ML/trinecraft/`.
`./run.sh` runs it, `./run.sh test` twelve suites, `./run.sh repl` a headless
REPL, `--uncapped --frames N --radius N` for benchmarking.

## Naming

TrineXraft, Trinecraft and Trinexcraft are the same project; the spelling has
drifted and none of it matters. The repository directory stays `trinecraft`,
the game is **TrineXraft**.

## Minecraft is the starting point, not the goal

What runs today is a Minecraft-shaped voxel engine, and that is deliberate.
TrineXraft needs an editable voxel world underneath it, so the engine had to
exist and be measured first. Everything built so far — chunk store, worldgen,
mesher, streaming, culling, persistence, the dev console — is **foundation**.
None of it is the game.

The phases below convert that foundation into TrineXraft. Nothing in the
current build is precious: where the game needs something different, the
engine changes.

## The target

Not "Minecraft with AI-generated quests" but **Minecraft with an evolving
fantasy mythology and an AI Dungeon Master**, where Trine-like adventures
arise naturally from the world itself.

Three pillars:

1. **Editable voxel world** — blocky, Minecraft-recognisable geometry.
   (The concept text once floated "organically shaped" terrain; the settled
   direction, confirmed by the art notes, is *clearly square blocks*. Our
   per-voxel mesher is therefore correct and marching cubes is out.)
2. **Trine's enchanted look** — volumetric light, glowing crystals, coloured
   magic, waterfalls, fog; three co-op classes. The camera is **both 2.5D and
   3D at different orientations**, switching during play: a side-on
   Trine-style framing for platforming and puzzles, free third-person 3D for
   exploration and building. One world, several ways of looking at it.
3. **A world with its own history and mythology**, interpreted by an AI
   Dungeon Master, populated by NPCs with memory and motivation.

**The player must never be obliged to engage.** Minecraft freedom is
sacred: ignore the mystery and the world keeps evolving without you — the
forest spreads, a rival faction finds the artifact first, villagers leave.

## The architecture the concept actually specifies

An explicit hierarchy. Note how little of it is an LLM:

| System | Technology | When it runs |
|---|---|---|
| World generation | deterministic procedural algorithms | creation + exploration |
| History simulation | rules + agent simulation | world creation |
| Narrative director | capable LLM | creation + major events |
| Quest planner | constrained planner + LLM | when adventures are needed |
| **NPC behaviour** | **conventional game AI** | **continuously** |
| Dialogue | small LLM or cached | during interactions |
| World memory | structured database / event log | on meaningful events |

**NPC behaviour is conventional game AI, not an LLM.** An earlier draft of
this plan had LLMs driving NPC behaviour broadly; that is the expensive,
incoherent design the concept explicitly rejects. LLMs are for *dialogue* and
*narrative direction*. Bodies are moved by the engine.

### Narrative compilation — the central idea

The LLM never controls the game. It emits a **structured adventure
specification**, which the engine validates and builds from existing assets:

```json
{"adventure":"The Forgotten Moonheart","origin":"ancient_kingdom_collapse",
 "location":"ruined_tower_17","characters":["elder_mira","guardian_04"],
 "stages":["discover_ancient_tablet","investigate_ruined_tower",
           "solve_light_reflection_puzzle","recover_moonheart_fragment"],
 "consequences":{"restore":"forest_corruption_decreases",
                 "destroy":"guardian_faction_hostile"}}
```

The engine guarantees the locations, characters, objects and puzzles exist
and that objectives are achievable. Generation is grounded in structured
facts, never free text.

### World-generation pipeline (approach C: world *and* history together)

Dwarf Fortress's precedent — simulate centuries, then record what happened:

```
seed -> geography/biomes/caves -> civilisation simulation -> historical
simulation (wars, betrayals, vanished cities) -> AI narrative generation
(legends, mysteries, arcs) -> world realisation (castles, ruins, artifacts)
-> living adventure (player actions feed back)
```

### Reproducibility — a hard invariant

Seed-based simulation is deterministic; LLM output is not. So the narrative
layer is **generated once and saved as structured records**. A castle must
not acquire a different history on reload. The narrative layer may be
regenerated deliberately while terrain is retained, if validated against
existing structures.

### Content budget (design targets, not demonstrated capacity)

1–3 major world conflicts; 10–20 regional arcs; 50–100 discoverable
mysteries; hundreds of small encounters. Generated lazily, never upfront.
Content is renewable because *the simulation keeps producing situations*, not
because an LLM can emit infinite text.

## Where the engine stands (measured, `JANET_NO_PROFILE=1`)

| | |
|---|---|
| Steady frame, radius 12, culled | 1.65 ms (605 FPS), ~10x headroom |
| Per drawn chunk | ~0.010 ms → ceiling ~1500 chunks, radius 30+ |
| Mesher / worldgen | 5.5 / 5.4 ms per chunk |
| Full `gccollect` | 0.50 ms median |
| Region compression | ~2.5x mean (2.0–4.0) |

**Production-bound, not render-bound.** Drawing a chunk is cheap; making one
is not. AO, lighting and sectioned chunks all multiply the mesher.

## Phase 10 — RE-MEASURED. The first verdict was wrong: the tier was compiled out.

### The error

The original Phase 10 measurement (1.3-2.9%) was taken against a `bender`
built with a plain `make`. The loop/leaf executor tier is **opt-in at BOTH
build and run time**, and the Makefile says so explicitly (`Makefile:64-71`):

> *"Without the compile-time define the tier is inert: every registration is
> refused ... so any measurement taken against a plain `make` build measures
> the interpreter only."*

So the verdict "AOT does not pay" was measuring a binary with the only tier
that can compile loops switched off. **Two flags are required:**

```sh
make NATIVE_EXECUTORS=1                      # compile the tier in (needs make clean first;
                                             # make does not notice a CFLAGS change)
JANET_NATIVE_EXECUTORS=1 bender --aot app.janet --native -o app
```

The second is needed **at AOT build time**, not at run time — it decides
whether executors are emitted into `native.c`. Once emitted they are always
active, which is why toggling the variable when *running* the binary changed
nothing and briefly looked like the tier was inert.

### The result, with buffer admission (bender `02b32d24`)

| kernel (p50, 3 runs) | interpreted | native, no tier | native + executors | vs interpreted |
|---|---|---|---|---|
| **mesh-chunk** | 5.47-5.55 | 5.38-5.46 | **4.28-4.38** | **21% faster** |
| worldgen/chunk | 5.14-5.20 | 5.19-5.22 | 5.39-5.65 | **4-8% slower** |
| palette pack | 1.81 | — | 2.22 | **23% slower** |
| raycast | 11.4 us | — | 11.6 us | flat |

Tail improvement on the mesher is larger than the median gain:
p90 8.85 -> 4.37 ms, max 28.4 -> **4.43 ms**, a 6.4x better worst case.

In the game: 32 executors emitted (`mesh-chunk`, `generate-into`,
`count-faces`, `box-collides?`, `raycast`), spawn meshing 169 -> **140 ms**.
Steady-state FPS is unchanged at ~1215, as expected — the engine is
render-bound once chunks are loaded and production-bound only while streaming.
All twelve suites pass.

### The regressions are the interesting part

`worldgen` and `palette pack` got **slower** with executors. This is the risk
`aot-loop-codegen-feasibility.md` names directly: a region that pays its guard
and then deopts is worse than no fusion at all.

The likely cause is call density. `generate-into` calls `height-at` ->
`fbm-signed-2d` -> `value-noise-2d` -> `hash2` per column, and calls are
explicit VM boundaries, so the region exits constantly. The mesher's inner
loop is mostly buffer reads with arithmetic between them, which is exactly the
shape fusion wants — hence 21% there and -8% in worldgen.

That is actionable feedback for the compiler work, not a reason to disable the
tier: net per chunk is 10.67 -> 9.68 ms, still a win.

### Standing conclusion

AOT **does** pay now, for mesher-shaped code. The earlier claim that
parallelism is the only lever was based on a measurement of the wrong binary.

Same benchmark compiled both ways, `JANET_NO_PROFILE=1` on both sides:

| kernel | interpreted | native | gain |
|---|---|---|---|
| worldgen / chunk | 5.240 ms | 5.173 ms | 1.3% |
| mesh-chunk | 5.530 ms | 5.372 ms | 2.9% |
| raycast | 11.18 us | 10.80 us | 3.4% |
| palette pack | 1.872 ms | 1.967 ms | none |

**Zero throughput gain, because zero of our code was compiled:**

```
native-lib 0 kernels
native-skip 0 block-index  types not proven: params [? ? ?] ret ?
native-skip f-for / f-while / f-hinted-while
    loop requires resumable VM quantum polls
```

Two candidate causes were tested separately. **Type hints are not the
blocker** — an unhinted arithmetic function lowered fine. **Loops are.**
`for`, `while` and hinted-`while` were all refused; only loop-free functions
compiled. That is why ttfx's RNG kernels are unrolled limb by limb: a
workaround, not a style choice.

The mesher and worldgen are nested loops by nature, so today AOT buys:
- a standalone binary (1.5 MB, builds in 1.3 s),
- native FFI alias stubs for all 60 raylib bindings,
- materially tighter tail latency (mesher max 17.1 ms -> 5.7 ms),
- **but no throughput.**

Native steady-state in the real game is healthy regardless: 1,264 FPS
(0.79 ms) at radius 8 with 197 chunks loaded, 20,000 frames clean.

### What this forces

The Trine look multiplies mesher cost — AO roughly doubles it, light
propagation adds more, 16x16x16 sections multiply volume — and **there is no
5x waiting in the compiler**. Three options, in rough order of expected value:

1. **Parallelise meshing across bender lanes.** Meshing is embarrassingly
   parallel per chunk; four workers beats a 2.9% gain decisively. Shares the
   spike work already planned as 11b.
2. **Unroll the hot kernels** ttfx-style so they become eligible. Proven
   precedent, but generated, ugly code — and it would finally measure whether
   native is fast *once* eligible, which is still unknown.
3. **Loop lowering in bender.** A compiler feature this workload arguably
   justifies; the largest payoff and the longest path.

Nothing after this phase should assume native speed-ups that do not exist.

## OPEN BUG — raylib UnloadMesh double free (unresolved)

Chunk streaming aborts inside raylib's `UnloadMesh` with "pointer being freed
was not allocated". `UnloadMesh` frees `Mesh.vboId`, which raylib allocated,
so freeing it twice aborts.

**Status: worked around, not fixed.** `mesh-unload` is disabled by default
(`rl/set-mesh-unload` re-enables it), which leaks GPU buffers — tens of KB per
chunk, tens of chunks per session — and is strictly better than aborting.

Three guards were written and all three failed the same way: per wrapper
table, per struct buffer (`vaoId`), and keyed on the `vboId` pointer itself.
Each fixed the isolation test; none fixed the live game. **Three green
reproductions and three live crashes mean the reproduction does not capture
the real aliasing path.**

Known for certain:
- Not a native-only fault. The isolation case (two wrappers aliasing one
  struct) aborts identically interpreted and native, which clears the AOT FFI
  path that the first crash report appeared to implicate.
- The interpreted build survived 104,808 frames with 48 chunk unloads, so the
  path is reachable but not deterministic.

### Instrumented, and the answer changed

`TRINEX_MESH_TRACE=1` logs every upload and unload with its `vboId`;
`TRINEX_MESH_UNLOAD=1` re-enables freeing. Both are read at CALL time, not at
module level -- in an AOT build a top-level `os/getenv` is evaluated when the
image is BUILT, so the first attempt baked both flags false and silently
traced nothing.

Walking 146 traced events from a crashing native run:

```
uploads=129  unloads=17
vboIds freed more than once ............ 0
vboIds freed but never uploaded ........ 0
UnloadMesh called on a non-live pointer  0
UploadMesh returned a STILL-LIVE pointer 1   <-- seq 122, live since seq 118
```

**Every free is unique and legitimate.** The engine is not double-freeing, so
the three guards were fixing a bug that was not there -- the original
diagnosis was wrong.

The single anomaly is the opposite shape: at seq 122 raylib's `UploadMesh`
returned `vboId = 0x...4720`, a pointer still outstanding from seq 118, with
no free in between and no raylib "already loaded" warning. The VAO was
created normally (ID 95). `malloc` cannot return a live pointer, so either
that allocation was freed by something outside our tracing, or the value read
back from the `Mesh` struct is not what raylib wrote.

That points at the FFI boundary -- `UploadMesh(Mesh *)` write-back, or
marshalling of the 120-byte `Mesh` by value into `UnloadMesh` -- rather than
at engine logic. **Not proven**, and it is equally consistent with a raylib
or driver fault, so it should not be reported upstream as a bender bug until
reproduced without the game.

Next step: reproduce outside TrineXraft with a minimal loop that uploads and
unloads meshes while tracing `vboId`, in both a plain C program and through
the FFI. If C is clean and the FFI is not, it is a bender bug; if both show
it, it is raylib.

## Language constraint: 32-bit bit operations

bender's bitwise operators work on **signed 32-bit** operands and reject
anything outside that range — `(band x 0xFFFFFFFF)` raises, because the mask
itself exceeds int32. `blshift` wraps, `brshift` is arithmetic, `brushift`
refuses negatives.

A 64-bit path exists via the boxed `int/u64` / `int/s64` types, and it is
fully correct — `(blshift (int/u64 1) 40)` and wrapping u64 multiply both
work. It is simply expensive:

| approach | cost | range |
|---|---|---|
| int32 bit ops | 36.7 ns/op | +-2^31 |
| plain arithmetic (`*`, `%`, `math/floor`) | 35.6 ns/op | exact to 2^53 |
| boxed `int/u64` bit ops | **332.1 ns/op (9x)** | full 64-bit |

**Arithmetic is exactly as fast as bit operations and reaches 2^53.** That is
the important result: for anything between 2^31 and 2^53 there is no reason to
reach for bit twiddling at all. This is why worldgen's hash uses Lehmer rounds
modulo 2^31-1 rather than the xorshift-and-mask it started as — the mask
version raised on its own constant.

Working rules:
- Keep bitfield packing within 31 bits.
- Use arithmetic, not bit ops, for 32-53 bit values.
- Reserve `int/u64` for cold paths; 9x makes it unusable in a mesher loop.

Consequences already visible: `horizon` packs palette indices into **u64**
words (`paletted.rs:11-72`), and copying that directly would land us on the
boxed path. Our palette module uses arithmetic instead, which is the right
call for bender. Phase 12's light packing (4 bits x 4 channels = 16 bits) and
Phase 13's section indices both fit comfortably inside int32. Anything
wanting 64-bit hashes or Morton codes in a hot loop does not, and should be
redesigned rather than boxed.

## Phases

**10 — AOT/native [GATE] — DONE, see above.** Measure mesher+worldgen interpreted vs native.
Decides how much of the rest is affordable. ttfx precedent; its
`bin/ttfx-gui.janet:3-8` recipe is stale — follow its README.

## Phase 11a — DONE. Custom GLSL reaches the GPU.

The first shader in this project, and the gate on all of Phase 12.

- `LoadShaderFromMemory` + `IsShaderValid` + uniform setters bound in
  `src/rl.janet`; GLSL lives in `src/shaders.janet` as source strings so it
  sits beside the Janet that sets its uniforms.
- **No custom vertex attribute was needed.** raylib binds `vertexColor` at
  `SHADER_LOC_VERTEX_COLOR` by default, so the mesher's existing per-vertex
  channel carries shade today and ambient occlusion in Phase 12.
- **Fixed a long-standing dead path:** the mesher had always produced vertex
  colours and `mesh-pack` never uploaded them, so baked directional shading
  was computed and discarded every frame. It now reaches GLSL, and the
  bright-top / dark-side shading is visible for the first time.
- Lighting is half-lambert wrapped and normalised so ambient + sun cannot
  exceed 1.0. The first version added them directly (0.38 + 0.98 = 1.44),
  which clipped lit surfaces to white and crushed the baked shade out.
- Exponential-squared distance fog, with the background cleared to the fog
  colour so terrain meets the sky instead of ending at a visible boundary.
- Fails safe: an invalid shader falls back to the default material and says
  so on stderr, rather than rendering a black world.

Verified live, not inferred: `(sun 1.0 0.25 0.15)` and
`(ambient 0.10 0.05 0.12)` typed at the console turned the whole world
sunset-red mid-run, which proves uniforms set from Janet reach the GPU.
Console gains `atmosphere`, `sun`, `ambient`, `fog`, `sun-dir`, `shader` —
the tuning surface Phase 12 needs.

Cost: ~0.2 ms/frame at radius 6 (16.7 -> 16.9 ms, still vsync-bound). Twelve
suites pass.

**11 — Spikes.** (a) custom GLSL via raylib FFI — **DONE**, see 11a above; it
was the gate on 12, and 12 rests on it. (b) async LLM call off the frame thread
via bender lanes — never attempted; gates 19-21.

### 11c — Bliss shader port — AUDIT COMPLETE, port not started

**Audit complete; port pending permission.** The [compatibility and licence
ledger](BLISS_PORT_AUDIT.md) inspects the pinned
[X0nk/Bliss-Shader revision](https://github.com/X0nk/Bliss-Shader/tree/81e403ed308141039a09d792a36f8eb328898a60)
and the existing renderer's requirements. It contains no copied shader source,
GPU compilation, runtime cost measurement, or implemented Bliss port. Upstream
rights are not granted by its public repository: obtain written permission for
relevant contributed portions before translating or vendoring any Bliss code.
The proposed original voxel AO experiment is likewise unimplemented and must
not be counted as a Bliss port. The portable-renderer choice remains open.

Non-goals: no vendoring, no wholesale replacement of `src/shaders.janet`, and no
effect switched on by default before it is measured. Any port must fail safe
exactly as 11a does — an invalid shader falls back to the default material
rather than rendering a black world.

**11d — Portable renderer decision — EVALUATION ONLY.** [Decision ledger](PORTABLE_RENDERER_DECISION.md)
compares WebGPU/WGSL (Dawn and wgpu-native), Sokol/shdc, bgfx/shaderc and the
existing raylib baseline; a bounded native/pass/ABI spike must precede backend
selection. Multiple shader sources and licensed pack adapters are requirements,
not a promise that arbitrary shaderpacks drop in. No renderer rewrite is authorized.

**12 — Light and atmosphere.** AO baked to vertex colour; coloured flood-fill
sky/block light; emissive blocks; shadow maps; god rays; water; fog; bloom
and tonemapping; day/night.

Two capabilities belong to this phase and are **planned, not done**:

- **Named render presets.** A preset is a named, stored combination of the
  atmosphere parameters the console already exposes (`sun`, `ambient`, `fog`,
  `atmosphere`, `sun-dir`), so a look can be selected, reproduced and compared
  instead of retuned by hand. Presets are versioned data, not code paths.
- **Reference-capture comparison.** A fixed viewpoint, a fixed frame count and a
  fixed sky phase, so two builds or two presets are compared frame-for-frame
  rather than by impression. The existing `--screenshot`, `--sky-view` and
  `--sky-phase` controls are the starting point; what does not exist is a mode
  that reports the difference instead of producing two images for a human to
  eyeball.

Reference material for that comparison: the user's own captures under
`/Users/pankajdoharey/Screenshots`, and <https://github.com/X0nk/Bliss> as the
port reference. Those captures are **reference material, not validated ground
truth** — they state what the user wants to see, not what the engine currently
produces. **No comparison has been run**, and none of the above is implemented
or measured.

**13 — Sectioned chunks.** 16³ × N stacked, empty sections skipped. Caves,
tall castles and floating islands cannot coexist in one 16×64×16 chunk.

**14 — Characters, camera, classes.** Voxel rig and animation; third-person
follow camera; **2.5D↔3D transition**; wizard / knight / rogue.

**15 — Voxel physics and abilities.** Falling and collapsing blocks; debris;
wizard telekinesis; rogue grapple; swinging platforms and weight plates.
These *are* the puzzle primitives, so they precede the mechanics library.

**16 — Combat and creatures.** Melee, ranged, spells; skeletons; damage and
feedback. After physics, because the concept's combat is environmental.

**17 — World content.** Biomes; villages, ruins, castles, dungeons; floating
islands; vegetation. The raw material the Dungeon Master arranges.

Everything in this section is **planned and not started**. It expands the
sentence above; it does not record work.

### 17a — New Game / Load Game front door

A menu stage that runs before any world is created or loaded, so the choices
that decide a world are made visible instead of implied by command-line flags.

- **Provider selection is shown honestly.** The procedural provider is offered
  and always works. A learned provider is listed with its real availability:
  **disabled and marked unavailable when no native runtime is present**, and it
  must **never silently fall back** to procedural generation — a player who
  chose the learned world must be told it is unavailable, not handed a different
  world under the same name.
- **Seeds.** An arbitrary **UTF-8 text seed**, with a **random numeric** option,
  normalised to one canonical seed value that is displayed, stored and reused.
  The canonical form is what the terrain identity and the save sidecar record, so
  a world cannot be reopened with a seed that means something else.
  **64-bit precision is a stated requirement** for the canonical seed. The
  current `--seed` path accepts only an integer `0..1000000`, so it does not meet
  that requirement — a **known gap**, not working behaviour. Widening it is not
  a one-line change: the seed is also bounded as an int32 on the worldgen path,
  and the terrain identity carries the seed as an integer.
- **Safe saves.** A versioned settings/world record for the front door's
  choices, written so a corrupt or older file is refused or migrated
  deliberately rather than half-read. Save identity continues to be gated the way
  it is today: a region is never adopted by a generator that would have produced
  different terrain.

### 17f — Temporary Python provider — **IN PROGRESS, not done**

The one part of 17 that is being built now, and it is being built the honest
way: a real provider, labelled temporary, that is removed once native
generation is verified.

**What exists.** `tools/terrain_new_game.py` runs the real pinned upstream
`WorldPipeline` in a Python child process — the same snapshot, weights, submodel
configs and frozen conditioning table the offline backend already binds — and
exports a scenic format-3 cache the existing Janet reader already consumes. It
reimplements no inference and invents no second artifact format
(`a2edc68`).

**Why it is allowed.** The user has authorized a Python dependency for New Game
during this milestone. That is a time-boxed decision, not a change of the goal:
the temporary provider is a **named dependency**, it is **not** part of the
shipping gate, and it is **not** evidence of completion. It is deleted when
native generation is verified.

**Contract properties**, each checkable rather than asserted:

- `--check` reports offline readiness and writes nothing, so a readiness probe
  can never be mistaken for a run.
- Stages are discrete and `READY` is written only after the written artifact is
  re-read and every tile decodes under the manifest's band. No synthetic
  percentage, no interpolated ETA.
- Progress is an **inert Janet sidecar** (`a5139c2`): the provider's JSON went to
  stderr, which a supervisor cannot poll without blocking on a pipe, and Janet
  has no JSON parser. A failure or cancellation publishes `failed`/`cancelled`
  and leaves no `READY`.
- One **directly owned child**, cancellable, sole writer, with a bounded
  progress reader and strict reaping (`src/generation-job.janet`).

**Limits, stated rather than smoothed over:**

- **Finite, not infinite.** `--size` defaults to 128 and caps at 512: one
  bounded rectangle, one `get`, one export. It does not claim to be the
  infinite generator.
- The default origin `(100000, 100000)` is a location **known to be land** — a
  chosen point, not a guarantee about the world.
- **Seed mapping is a recorded collision.** Upstream substitutes a random world
  for a falsy seed, so world seed 0 maps to model seed 2147483647 under
  `SEED_MAPPING_VERSION = "nonzero-v1"`. World seeds 0 and 2147483647 therefore
  sample identical terrain. That is deliberate and versioned, not aliasing.

**Not yet true.** No real generation has been run through the New Game path end
to end. The safety module, the catalogue wiring and the `main.janet`
integration are in progress under separate owners
(`src/generation-job.janet`, catalogue `d9`, `main.janet` WIP), and until they
land the provider is a contract and a reader, not a feature.

### Native provider — unchanged, and currently paused

The learned native provider stays **`available false`**. Exact coarse-stage and
solver mismatches remain unresolved, and **native inference is paused**: it was
stopped after the user closed three rogue processes. It does not resume until
there is **one owned, cancellable job** with strict PID reaping and bounded
concurrency, so that no inference can run unwatched again.

### 17b — Biomes, vegetation, hydrology

- **Biomes**: a rich set, with surface materials, vegetation and terrain shape
  coupled to the same classification — not a paint pass over the heights.
- **Vegetation**: trees and ground cover as world content, not decoration.
- **Hydrology**: rivers, lakes, coastlines and waterfalls as distinct features,
  with **flowing versus still fluid** distinguished as a real block/update
  property, because flow is what the puzzle library in Phase 18 manipulates.
- For biomes to be assigned, climate metadata must exist. That metadata is
  **not** the same thing as sectioned chunks or tall terrain, and Phase 13 is
  **not** a prerequisite for it, nor for ores or caves inside the existing
  64-block band.

### 17c — Blocks, ores, materials

Extends the current eight-block set (stone, dirt, grass, sand, water, wood,
leaves): soils, rocks, and ores **including titanium**. New block ids are not a
free change — the atlas is 4×4 with eight tiles in use, and a palette entry, a
material recipe and a `block-name` entry must exist together, or the block
renders with a fallback rect.

### 17d — Fauna and entities

Planned scope only: no creature, animal or entity system exists today, and no
design is committed here. Phase 16 (combat and creatures) is where bodies and
damage live; this entry records that the world is meant to be inhabited.

### 17e — Sky effects

Atmospheric and celestial effects layered on Phase 12's day/night and fog —
clouds, weather, celestial bodies. **No sky effect beyond the existing sun
direction and sky phase exists today.**

### Ordering

Anything that needs vertical room above 64 blocks — tall structures, floating
islands, deep caverns — is ordered **after Phase 13 sectioning**, because
`16×64×16` is a hard storage limit, not a preference. Biome assignment is
ordered **after the climate metadata stage**, because biome selection needs
climate, not sectioning. Phase 17 does not begin until both foundations exist;
neither is implemented.

**18 — Adventure mechanics library.** 30–40 reusable puzzle systems: light
reflection, water flow, gravity manipulation, gears, weight platforms,
magical growth, portals, elemental reactions, structural construction. The AI
composes *situations* from mechanics the engine already understands; it never
invents a mechanic. **Digging around a puzzle must always remain a legitimate
solution.**

**19 — History simulation.** Deterministic, seeded, no LLM: civilisations,
settlements, factions, wars, betrayals, lost artifacts, migration — centuries
of it, recorded as a structured event log. This is the ground truth every
later story is interpreted *from*.

**20 — Narrative director and quest planner.** Capable LLM reads world and
history state and emits validated adventure specs (above). Constrained
planner guarantees reachability and solvability. Three narrative kinds: world
legends, discoverable adventures, emergent personal stories. Persist every
record for reproducibility.

**21 — NPC minds.** Conventional AI for continuous behaviour (schedules,
work, movement, combat). Memory: episodic + semantic, retrieval by relevance
and recency. Small/cached LLM for dialogue, large model only for
consequential conversation. Relationships and reputation. Offstage NPCs
advance on cheap rules and are promoted on approach. Token budgets, rate
limits, shared world-fact cache.

**22 — Co-op.** Local split-screen first; server-authoritative networking
later, since reproducibility demands one authority.

## Cross-phase shipping gate — shippable new worlds

A separate gate, not a phase. "Shippable new worlds" means one thing concretely:
a new world is created from the front door, seeded canonically, generated by a
provider that is named and honest about itself, and saved with provenance that
survives a reload. Nothing in this section is achieved today.

**Native learned inference without Python: NOT PROVEN.** Running the learned
pipeline without a Python process — an FFI export of the sampler into the game,
plus the packaging and distribution story that would make it shippable — is
**under active audit, not implemented**. There is no exported sampler, no
packaged runtime, and no evidence that the model can run inside the game's
process or as a self-contained dependency. Until that audit closes, the learned
provider is offered as **unavailable** by the front door and must not be
described as working.

**Final generation is Python-free.** That is the gate, and it is why the
temporary provider in 17f does not satisfy it. 17f is a deliberately authorized,
named dependency for the New Game milestone: it may be used, it may be visible,
and it is scheduled for removal. It does not count as a shippable new world,
and a build that still needs it cannot pass this gate.

**The existing learned cache is genuine, and is not a production provider.**
The baked cache is real model output: a 128→512 unclipped interpolation over
fixed tiles, useful for reference, comparison and visual QA. It is **fixed
data**, bounded to the tiles that were baked, and cannot serve a new world at an
arbitrary seed — so it cannot satisfy this gate. It is evidence that learned
terrain reaches gameplay; it is not evidence that a learned world ships.

**PGO parity is the byte-exact oracle.** Any generator change that moves the
`--verify-pgo` hash must be re-pinned deliberately, as a recorded decision, not
silently absorbed.

Blocking questions the gate will not answer by assertion: whether climate
metadata is deterministic across the tensor boundary; whether an arbitrary
UTF-8 seed survives canonicalisation into a 64-bit value on every path that
consumes it; and whether a saved world reloads under the same provider and seed.
Each needs tests, and none exists.

## MVP, as the concept defines it

Not infinite worlds or hundreds of agents. **One small fantasy sandbox:**
a procedural forest valley with a village, castle ruins and caverns; editable
voxel terrain and crafting; three Trine abilities; an AI-generated history
with a single major mystery; five to ten interrelated adventures each with
multiple solutions; a narrative director that remembers and reacts.

That MVP spans phases 12–21 at reduced scope. Prefer depth on one valley over
breadth across many.

## Risks

- **Playability, not prose, is the hard problem.** An LLM can describe a
  cursed castle; guaranteeing the castle is fun, the puzzle solvable, and the
  story coherent after a player tunnels through a wall is the real work. The
  mechanics library plus spec validation exist for this.
- **Latency and cost at population scale** — answered by the hierarchy:
  most NPC-seconds must cost zero tokens.
- **Determinism** — memories and lore are data, never transcripts.
- **Physics in an interpreted language** — Phase 10 decides.
- **Scope** — multi-year. Ordering keeps something playable at every step.

## Deferred

Greedy meshing (LOD only); far-field LOD; mods; audio.