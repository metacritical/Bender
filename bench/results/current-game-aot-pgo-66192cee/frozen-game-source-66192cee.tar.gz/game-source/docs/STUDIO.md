# The Emacs development studio

Emacs drives the running game. No Unity, no Unreal, no engine editor — the
studio is your editor talking to a live game over a socket.

## Why this shape

The obvious alternative was floating tool windows built from the game itself.
That was rejected for a concrete reason: raylib is single-window GLFW with no
multi-window API, so native tool windows would mean adding a second GUI
toolkit and writing the controls in C bindings. Emacs already *is* a windowing
toolkit with an editor attached.

The in-game inspector predated this and solved a different problem — it was a
*player settings* UI. The panel here is a *developer* UI. Both can exist; the
panel is the one you use while building the game.

## Quick start

Add to your `init.el`:

```elisp
(load "/Users/you/Development/Projects/ML/trinecraft/editor/trinexraft-keys.el")
```

Then:

| Key | Action |
|---|---|
| `C-c t l` | Launch the game with `--dev`, in the background |
| `C-c t r` | Open the REPL buffer |
| `C-c t p` | Open the live control panel |
| `C-c t m` | Live-reload a module |
| `C-c t e` | Evaluate a form you type |
| `C-c t R` | Restart |
| `C-c t k` | Stop |

`C-c t` on its own opens the studio: connects, then shows the panel and REPL.

## The REPL

`C-c t r`, then:

- `C-c C-c` — evaluate the form at point
- `C-c C-r` — evaluate the region
- `C-c C-b` — evaluate the buffer

This is the *same* REPL as the in-game `~` console: same evaluator, same
environment, same live tables. `(world/world-get-block world 0 40 0)` works
identically in both.

Every engine module is reachable, so you can poke at anything:

```janet
(stats)                     # fps, chunks, edits, worst frame
(world/world-get-block world 0 40 0)
(player/eye-position player)
(atmosphere)                # current sun, ambient, fog
(worldgen/height-at 4 100 100)
```

Errors are contained. A bad form returns `err` and the game keeps running —
the evaluator runs inside an error-trapping fiber, so no REPL input can kill
your session.

## The control panel

`C-c t p` opens a buffer of live readouts and actions:

```
performance            atmosphere
  fps      157           sun      1.00,0.95,0.82
  frame    6.23 ms       ambient  0.56,0.63,0.78
  worst    69.84 ms      fog      0.41,0.56,0.85
  chunks   113
```

Keys in the panel:

| Key | Action |
|---|---|
| `g` | refresh now |
| `c` | hold the time of day (prompts for a phase) |
| `t` | resume the day cycle |
| `m` | reload materials from disk |
| `M` | save applied materials |
| `w` | save water appearance |
| `W` | reload water appearance |
| `R` | force a full re-mesh |
| `i` | insert a form to evaluate with `C-c C-c` |

Every button sends one Janet form through the same `trinexraft-eval` the REPL
uses. There is no second protocol and no mirrored state — the panel reads real
game state, so it cannot drift from the truth it displays.

## The control panel

`C-c t p` opens a floating child frame beside your editor. It is built entirely
from what the game publishes, so it has no built-in controls of its own.

### Declaring a control — one line

Controls live **in the game**, next to the code they drive:

```janet
(panel/define! controls "fog-density"
  {:kind :number :group "atmosphere" :label "Fog density"
   :form "(do (fog-density %s) (atmosphere-phase))"
   :min 0 :max 0.02 :step 0.001
   :read-form "(fog-density)"})
```

Or live, from the REPL, with no restart:

```janet
(panel-add "warp" {:kind :action :group "custom" :label "Warp to spawn"
                   :form "(tp 0.5 40 0.5)"})
```

Press `g` in the panel and it is there. **No Elisp was written.**

### Kinds

| Kind | Panel shows | `RET` does | `C-up`/`C-down` |
|---|---|---|---|
| `:action` | `[ Label ]` | evaluates `:form` | — |
| `:readout` | label + live value | — | — |
| `:number` | label + value + bounds | prompts for a value | steps by `:step` within bounds |
| `:text` | label | prompts for a string, fills `%s` | — |

Fields: `:id`, `:kind`, `:group`, `:label`, `:form`, `:hint`, and for
`:number` also `:min`, `:max`, `:step`, `:read-form`.

`:form` is what to evaluate. For `:number` and `:text` it is a template and
`%s` is replaced with the value. `:read-form` is how to *display* the current
value — needed for `:number` because its `:form` is for setting, not reading.

### The contract, and why it is drawn there

**The game declares WHAT exists. Emacs decides HOW to present and manipulate it.**

`editor/trinexraft-panel.el` contains no knowledge of any particular control.
It parses the manifest and derives behaviour from `:kind`. That is what makes
the one-line `panel-add` above work with no Elisp change.

The consequence worth being explicit about: **stepping is Elisp's judgement.**
`C-up` on a number is Emacs deciding that a bounded number should move by
`:step` and clamp to `:min`/`:max` — the bounds themselves are the game's
declaration. Move the panel to another editor and the controls still work;
change how numbers feel and no Janet changes.

Neither side hardcodes the other's business. The contract is the manifest.

### Wire format

One line per reply, so a multi-control manifest must survive on one line.
Each control is `id|kind|group|label|form|hint|min|max|step|read-form`,
records separated by `;`, every field escaped first (`\|` → `\p`, `;` → `\s`,
newline → `\n`, backslash first). A delimiter that cannot occur is easier to
trust than a parser, and `test/panel-test.janet` asserts that a label
containing both delimiters still yields exactly one record of exactly ten
fields.

Readouts are batched: `(panel-values)` evaluates every display form in one
round trip. Ten separate requests would cost ten frames of latency, because
each needs the game's frame loop to service it. A readout that throws reports
its error in place rather than breaking the panel.

### Keys

| Key | Action |
|---|---|
| `RET` / click | activate the control at point |
| `S-up` / `S-down` | step a numeric control |
| `M-up` / `M-down`, `+` / `-` | the same, for keyboards where Shift-arrow is taken |
| `g` | refresh |
| `i` | insert a form to evaluate with `C-c C-c` |
| `C-c C-c` | evaluate the form at point |
| `C-c t P` | toggle floating / docked |

Shift-arrow rather than plain arrows so cursor movement still works normally —
the panel is a buffer you may want to navigate and copy from. Ctrl-arrow is
deliberately avoided: macOS claims it for Mission Control, so the binding never
reaches Emacs at all.

## The development loop

This is the part that changes how the work feels:

1. Edit `src/mesher.janet` in a buffer.
2. `C-c t m`, choose `mesher`.
3. Keep playing. The world is still there.

Verified against a running game: a function introduced by an edit became
callable while 113 chunks stayed loaded and terrain was unchanged.

**What a reload does and does not do.** It re-evaluates the file and merges the
new `def`/`defn` bindings *in place*, so call sites holding a binding table see
the new code without re-importing. Top-level side effects — creating a GL
texture, opening a socket — do **not** re-run, because they are bound to a live
session the reload cannot reconstruct. Reloading a shader *string* is safe;
reloading a GPU texture is not.

**Atomicity.** The new source is evaluated in full before anything is merged.
A syntax error leaves the running game exactly as it was.

**Both name forms are updated.** A module's functions are reachable as both
`height-at` and `worldgen/height-at`, and those are *separate* binding tables.
Reload updates both; updating only one would leave the game's own qualified
calls — which is how the game refers to modules — on stale code. That bug was
real and is now covered by tests.

## Launching

`C-c t l` starts `run.sh --dev --uncapped` asynchronously, so Emacs stays
usable. Output goes to `*trinexraft-game*` if you need to read it.

The port is discovered automatically from the running process's command line,
so reconnecting after a restart needs no bookkeeping. Pass `--dev-port N` if
you want a fixed one; `--dev` alone picks a free port.

## Production

The gate is a single startup flag: **no listener exists without `--dev`**. A
shipped build does not hide the socket, it never opens one. That matters
because an eval port is remote code execution for anything that can reach it.

The `~` console stays in the game — it is the in-world equivalent, and it is
genuinely useful when you are standing in the world you want to poke at.

## Layout

| File | Role |
|---|---|
| `src/dev-server.janet` | the socket; bounded per-frame pump, no blocking |
| `src/reload.janet` | live module reload |
| `editor/trinexraft.el` | REPL, evaluation, launch/restart |
| `editor/trinexraft-panel.el` | the control panel |
| `editor/trinexraft-keys.el` | keybindings, single load entry |
| `test/dev-server-test.janet` | protocol, safety, bounded work |
| `test/reload-test.janet` | merge semantics, failure containment |

## Two implementation notes worth knowing

Both were discovered the hard way and are easy to reintroduce:

**Fibers only run when the main fiber yields.** A render loop never suspends,
so the acceptor was created and never executed — the socket listened and served
nothing. `pump` does one `ev/sleep 0` per frame: a zero-duration suspension
costing ~1.8 µs of CPU.

**A timed `net/accept`/`ev/read` arms a *global* timeout signal**, and it
escapes into unrelated work — it crashed the game with `timeout` thrown out of
`stream/in-radius?` during ordinary chunk streaming. All waiting now happens in
dedicated fibers, and the frame loop only uses `ev/try-take`, which never
suspends.
