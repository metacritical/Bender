# Native geometry contract — infinite_tensor windows

Derived from **source**, not reconstructed. Every bound in this document was computed
by instantiating the real `infinite_tensor.TensorWindow` classes and calling the real
`get_bounds`. No formula here is guessed.

**Why this document exists.** A previous native port reimplemented the pipeline's
window arithmetic by hand and produced elevation `-1290 .. -695 m`. The real
`WorldPipeline.get(100000, 100000, 100064, 100064)` produces
**`1081.17 .. 1784.95 m`, mean `1427.45`** (`native/proof/fixtures/oracle/meta.json`).
The reconstruction was wrong; only calling the real pipeline is trustworthy. This page
records the *actual* geometry so native code can match it without guessing.

## 1. The one formula

`TensorWindow.get_bounds` — `infinite_tensor/tensor_window.py:152-190`:

```
start = window_coord * stride + offset
stop  = window_coord * stride + size   + offset
```

with **per-output-dim** `stride`, `size`, `offset`. `dimension_map`, when set, picks
which window-space dim feeds each output dim (`None` ⇒ `slice(0,1)`); **no window in
this pipeline sets it**, so `mapped_coords == window_index`.

Window enumeration (`intersecting_windows`, `:106-148`) uses **floor division**, which is
what makes negative coordinates work:

```
numerator = start - offset - size + 1
low  = ceil(numerator / stride)      # implemented as -(-n//s)
high = (stop - 1 - offset) // stride
```

## 2. The window specs, as constructed

| Stage | Source | size | stride | offset |
|---|---|---|---|---|
| coarse | `world_pipeline.py:1080-1083` | `(7, 64, 64)` | `(7, 32, 32)` | `(0, 0, 0)` |
| latent out | `:1244` | `(6, 64, 64)` | `(6, 32, 32)` | `(0, 0, 0)` |
| latent cond | `:1245` | `(7, 4, 4)` | `(7, 1, 1)` | `(0, -1, -1)` |
| decoder out | `:1357` | `(2, 512, 512)` | `(2, 384, 384)` | `(0, 0, 0)` |
| decoder in | `:1358` | `(6, 64, 64)` | `(6, 48, 48)` | `(0, 0, 0)` |

Constants: `TILE_SIZE=64`, `TILE_STRIDE=32` (`:1233-1234`),
`decoder_tile_size=512`, `decoder_tile_stride=384` (`:313-314`),
`latent_compression=8` (`:299`), `coarse_pooling=1` (`:303`).

**The cond offset `(0,-1,-1)` is the one non-obvious term** — it makes cond window `i`
cover `i-1 .. i+3`, i.e. one unit of context *before* and three after. Omitting it is a
silent one-block shift.

## 3. Verified `get_bounds` values

Computed by running the real class:

| window idx | coarse / latent start..stop | decoder start..stop | decoder_in start..stop | cond start..stop |
|---|---|---|---|---|
| 0 | 0 .. 64 | 0 .. 512 | 0 .. 64 | **-1** .. 3 |
| 7 | 224 .. 288 | 2688 .. 3200 | 336 .. 400 | 6 .. 10 |
| 259 | 8288 .. 8352 | 99456 .. 99968 | 12432 .. 12496 | 258 .. 262 |
| 386 | 12352 .. 12416 | 148224 .. 148736 | 18528 .. 18592 | 385 .. 389 |

Oracle-captured contexts reproduce exactly:

```
coarse  (0,7,7) -> y 224..288, x 224..288     (matches observed [(0,7,7)…(0,8,8)])
latent  (0,386,386) -> 12352..12416
cond    (0,386,386) -> 385..389
decoder (0,259,259) -> 99456..99968
decoder_in(0,259,259) -> 12432..12496
cond_img shape (7,4,4) — the 4x4 comes from cond size (7,4,4)
```

## 4. Why the observed indices are what they are

The query is **not** the window. `_compute_elev` (`:1375-1385`; called at `:1476`) pads it first:

```
sigma = 5 ; kernel = 11 ; pad_lr = 11//2 + 1 = 6 ; pad_hr = 6 * 8 = 48
```

so `(100000,100000,100064,100064)` becomes residual range **`99952 .. 100112`**
(latent `12494 .. 12514`). Enumerating decoder windows over *that* range yields
**four**, not one:

```
(0,259,259) (0,259,260) (0,260,259) (0,260,260)
```

The oracle captured only `(0,259,259)` because the stage hooks store the **first batch**
they see. **A native port must compute all four and blend them**, not assume one window
per query — this is the most likely source of a systematic offset.

Likewise a 64-px query at 100000 un-padded intersects only `(0,260,260)`, while the
padded query starts at `259`. Both are correct; they answer different ranges.

## 5. Negative coordinates

Floor division is what preserves correctness. Verified:

| query px | decoder windows | bounds[0] |
|---|---|---|
| -1 | -1 .. 1 | -384 |
| -64 | -1 .. 1 | -384 |
| -100000 | -261 .. -260 | -100224 |
| -100064 | -261 .. -260 | -100224 |

`(0,-1,-1)` for a decoder window legitimately returns `slice(-384, 128)` — a window
straddling the origin. Native code must use **floor** division (`//`, and `-((-a)//b)`
for ceil), never truncation toward zero, or negatives shift by one window.

## 6. Overlap and blending

Stride is half of size at every stage except `decoder_in` (48 of 64 = 3/4):

- coarse / latent: **2× overlap** (size 64, stride 32).
- decoder: size 512, stride 384 — **128 px overlap**, 384 advances.

Overlap exists so `linear_weight_window` (`:117`) can blend seams. `_decoder_inference`
returns `torch.cat([sample[0] * weight_window[None], weight_window[None]], dim=0)`
(`:1340`) — weighted sample and weight stacked as two channels — and the consumer
divides them: `residual_init[0] / residual_init[1]` (`:1399`). So a correct port
**accumulates weighted values and weights separately, then divides**. Averaging
overlapping windows equally will not match.

## 7. What this does not establish

Everything above is *geometry*. It says nothing about numerics: the RNG, the EDM
solver, the model weights, or `laplacian_denoise`. A native port matching every bound
here can still produce wrong elevations. The only accepted verification remains
comparison against `native/proof/fixtures/oracle/elevation_m.f32`, and the only
trustworthy generator of that is the live `WorldPipeline.get`.

Ambiguity left explicitly unresolved: the oracle hook records `cap["coarse"]` as a
*list* (all coarse contexts) but `cap["dec"]`/`cap["lat"]` only the **first** call. So
the captured coarse set is complete while latent/decoder are samples of the batch. Any
stage-by-stage comparison must account for that asymmetry rather than treating the
captured indices as the full work set.
