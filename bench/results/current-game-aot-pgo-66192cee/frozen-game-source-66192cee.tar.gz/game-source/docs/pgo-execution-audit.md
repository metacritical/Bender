# PGO release delivery and actual executor audit

Runtime25ca7fd3 includes GCfix7a7d7623. Game executable sourcef5c3fe0; documentation-only revision e6e0f9f describes existing application build commands. Both runtime and game changed: runtime major scheduling fixed; game ordinary launch disables implicit profiling and verification mode supplies deterministic PGO parity. The game has no Makefile. `make NATIVE_EXECUTORS=1 build/bender build/libjanet.a` in the sibling Janet checkout builds the runtime; `./run.sh build OUT --pgo ARGS`, then `./run.sh build OUT --release`, builds the application. No new compiler flags or framework were needed.

## Delivered application-local artifacts

- `build/trinexraft-pgo`: freshly trained and released via run.sh into this directory, not merely copied from /tmp.
- `build/trinexraft-pgo-diagnostic`: retained original trained companion, with work telemetry enabled.
- `build/trinexraft-pgo-exhaustive`: separately labeled reporter-only diagnostic rebuild, emitting all46generated executor rows including zero-entry rows.
- `build/pgo-evidence/`: raw commands, stdout/stderr, work JSON, stack sample and diagnostic analysis. `build/pgo-cache/`: application-local verified profile cache.

Original build/trinexraft-fresh is preserved. Run from the game directory for relative data paths. App training and release each exited0 and parity passed. Application-local release completed6000uncapped frames:183.3FPS average/5.46ms,189.0FPS steady/5.29ms, worst19.5ms, zero>33ms spikes. Single-trial measurements are not a matched speedup estimate.

## Generated does not mean executed

Exhaustive diagnostic6000frame run completed0. Exactly20of46generated executor IDs had nonzero entry counters:

|ID|name|entries|native ops|generated VM exits|
|--:|--|--:|--:|--:|
|21|mesh-unload|332|2310|90|
|108|generate-into|38510|46521532|113|
|112|fbm-signed-2d|261366|4774133|57856|
|115|mesh-water|542835|43677155|12327|
|116|mesh-chunk|4722718|311269445|132|
|121|paint-tile|4117|29893|2046|
|122|build-atlas-image|19|144|3|
|127|box-collides?|179109|1289742|12019|
|137|raycast|271647|3565072|32083|
|144|draw|6000|6000|6000|
|161|bind!|207|420|206|
|162|emit|10|65|6|
|186|aabb-visible?|3667392|122478877|3653566|
|222|draw|20919567|105856117|10359924|
|261|stars|6732000|42294000|966000|
|262|draw|5081220|108098202|4926127|
|263|commands|43902928|263182563|14595026|
|290|define!|48|1135|16|
|298|arg-value|19|473|10|
|299|arg-flag?|8|137|4|

Zero entries in THIS workload:85find-raylib,95chunk-empty?,111fbm-2d,117count-faces,141drain-input,143pump-input,154submit,177missing-chunks,188point-inside?,190slice-bytes,191region-info,192copy-bytes,193load-world,196save-world,198decode-chunk,199inspect,202load-region,268escape-reply,273pump,283merge-into,284merge-qualified,287escape-field,288remove!,289manifest,488unpack,551copy. This is not a claim that those functions never run in other workloads or cannot attach.

Totals:4279210348 interpreted dispatches,1053047415native ops,86330052native entries,85961253global VM exits,34623554generated-boundary exits,0chained calls. These units are NOT interchangeable and yield no defensible native coverage/time percentage. Entries include repeated native region entry/resumption rather than unique function calls. Tick counts may precede rejected guards. The diagnostic retains telemetry while release compiles it out.

Reporter provenance: copied generated native C from the original PGO build, inserted all_executor_rows only, verified removing inserted block restores the source byte-for-byte. Executor bodies/descriptors/selection unchanged; recompiled telemetry-enabled diagnostic with matching generated game image/current static library. Deterministic1500frame oracle byte-matches original verified expected.out: hash1651036173,113chunks,1851392blocks,358528opaque vertices,3edits. This corroborates companion behavior, not direct counters from telemetry-free release.

## Time: sampled bounds, not invented fallback percentage

Original retained trained companion sampled by macOS sample over15seconds at5ms interval. Main-thread root2603samples; exclusive-node self values computed by subtracting direct-child counts sum to2603. Other threads excluded. Sampling can include blocked/waiting stacks: this is NOT13seconds of pure on-CPU time.

- run_vm self954samples=36.7%: interpreter dispatch plus inlined helpers/native-dispatch machinery; NOT exact VM-fallback time.
- separately symbolized native-related self180=6.9% includes helpers/structural attachment checks, NOT6.9% of useful compiled kernels.
- GC-related self207=8.0%; blocked waits317=12.2%.
- run_vm inclusive94.7% includes native/FFI/rendering/GC descendants and must NOT be called94.7% interpreter fallback.

Exact time spent exclusively executing fallback bytecode cannot be recovered from these counters or coarse symbols. A timed PC/dispatch attribution facility or higher-resolution controlled profiler would be required. Report the36.7% self sample bucket as an imperfect proxy only; it may contain inlined native helpers and excludes VM-called C work. No86%fallback or native-time complement is claimed.

Raw evidence is currently in ignored application build/pgo-evidence rather than source-controlled binaries. Stable source documentation and reproducible commands are committed; build outputs can be regenerated. Failed earlier nondeterministic training evidence remains /tmp/game-fixed-pgo-25ca7fd3, isolated from this verified cache. Late unauthorized delegate changes were preserved as late-unverified-main.patch there and restored to the verified game source; they did not enter this build.
