# Native Generation Feasibility Audit

**Question:** can Trinecraft ship *learned* terrain generation inside the native
Janet/bender game, with **no Python at runtime** on New Game?

**Answer: yes, conditionally** — but not by porting the Python inference stack, and
not by any route that keeps `terrain_diffusion` in the loop. The learnable part is
three ordinary convolutional U-Nets. The hard part is the ~3,100 lines of
orchestration around them, which is plain arithmetic and can be ported. Upstream has
already published ONNX exports of all three nets, which makes the export question
settled rather than speculative.

Everything below is evidence read from this checkout and the pinned snapshot at
`~/.cache/huggingface/hub/models--xandergos--terrain-diffusion-30m/snapshots/9ef8030cb805b433b98ec25c5dddefbac07a9e26`.
No inference was run, nothing was downloaded, nothing was installed, and no
production file was modified for this audit.

---

## 1. What actually has to be shipped

| Component | Identity | Evidence |
|---|---|---|
| Code | `xandergos/terrain-diffusion` `e8dcb4b1…` | `tmp/terrain-runtime/repo` (91 `.py` files), MIT (`LICENSE`) |
| Weights | `terrain-diffusion-30m` `9ef8030c…` | snapshot on disk, MIT (`README.md` front-matter `license: mit`) |
| Frozen stats | `terrain-diffusion-30m-onnx` `ad2df557…` | already pinned in `docs/TERRAIN_DIFFUSION.md`, `stats_sha256 = 528754ea…` |

### The three nets (measured, not estimated)

Safetensors headers parsed directly — every tensor is F32, no quantization:

| Net | File bytes | Tensors | Dtypes | Config |
|---|---|---|---|---|
| coarse | 11,200,936 | 54 | F32 ×54 | 128 ch, mults `[1]`, 11→6, no attn |
| base | 1,014,772,076 | 174 | F32 ×174 | 192 ch, mults `[1,2,3,4]`, 5→5, attn@8,16, `layers_per_block=3` |
| decoder | 111,709,108 | 171 | F32 ×171 | 64 ch, mults `[1,2,3,4]`, 5→1, no attn |

Base dominates: 1.01 GB of the 1.14 GB total. `image_size` is declared 512 in
`base_model/config.json` and `decoder_model/config.json`; coarse declares 16.
`latent_compression = 8`, `native_resolution = 30` from `config.json`.

## 2. Operator inventory — the nets are exportable

Exhaustive set of operations reachable from the three U-Net forward paths
(`mp_layers.py`, `unet_block.py`, `edm_unet.py`):

```
conv2d  conv_transpose2d  linear  embedding  dropout(eval: identity)
scaled_dot_product_attention  einsum  softmax  interpolate(bilinear)
add  mul  div  sqrt  square  clip  exp  log  sigmoid  cos  sin  tan  cat  stack
linalg.vector_norm  reduce/mean/sum/max
```

Every one of these is standard ONNX opset 17. **There is no custom kernel, no
CUDA extension, no fused op, and no autograd trick in the weights path.**

Two things that look like custom ops and are not:

- **`MPConv` is not a fused op.** It is `conv2d` with the weight renormalized at
  forward time (`mp_layers.py:202-218`): `normalize(w)` then
  `w * gain / sqrt(w[0].numel())`. Since weights are already normalized after
  training (`norm_weights`), and inference runs in `eval` mode where
  `self.training` is false, the normalization is a **pure function of the
  constant weights** and can be folded offline into a plain conv weight. This is
  the single most important simplification for any native port: after folding,
  the graphs are vanilla CNNs.
- **`resample` is the one genuine exporter hazard.** Upstream's own exporter
  documents it (`onnx/export.py:31-50`): the original builds a convolution kernel
  from `x.shape[1]` at runtime, which breaks ONNX shape inference. The provided
  fix is numerically equivalent but uses static-shape ops — stride-2 slicing for
  `down`, `repeat_interleave` for `up`, `F.interpolate` for `up_bilinear`.

`MPFourier` (`mp_layers.py:109-131`) is a fixed `freqs`/`phases` buffer plus
`cos` — trivially expressible everywhere.

Confirmed MPS execution of the full graph earlier in this effort: coarse, base and
decoder all produce finite outputs on `torch 2.13.0` with no CPU fallback.

### The genuine non-exportable residue

These are **not** in the ONNX graphs and must be reimplemented in any native path:

| Component | Location | Size | Nature |
|---|---|---|---|
| DPM-Solver++ multistep scheduler | `scheduler/dpmsolver.py` | 762 lines | Pure arithmetic on 20 steps; port-friendly |
| Laplacian encode/decode/denoise | `data/laplacian_encoder.py` | 137 lines | `gaussian_blur`, `resize`; torchvision dependency |
| Canonical-noise field | `inference/portable_rng.py` | 89 lines | PCG64 + Marsaglia polar, numba-jitted |
| Perlin conditioning map | `inference/synthetic_map.py` + `perlin_transform.py` | 314 lines | `pyfastnoiselite` (FastNoiseLite C++) |
| Infinite-tensor tiling | `infinite_tensor` 0.4.0 | 1,071 lines | Window math, weights, LRU cache |
| Pipeline glue | `inference/world_pipeline.py` | 1,482 lines | Coarse/latent/decoder orchestration |

Total orchestration ≈ **3,100 lines of Python plus 1,071 lines of tile library** —
all of it deterministic arithmetic, none of it requiring a neural runtime.

## 3. Export routes assessed

### ONNX — proven, and already published by upstream

Upstream ships a working exporter: `terrain_diffusion/onnx/export.py` (250 lines),
invoked as `python -m terrain_diffusion.onnx.export <model> --verify`. It handles
all three known hazards explicitly (resample patching, 1-element padding tuples,
list-of-conditioning-inputs flattened to positional args), exports at opset 17
with dynamic batch, and verifies against `onnxruntime` when present.

**Stronger evidence still:** upstream publishes pre-exported artifacts at
`xandergos/terrain-diffusion-30m-onnx` revision `ad2df557`:

```
2,029,994,361  base_model.onnx
  223,854,143  decoder_model.onnx
   22,497,125  coarse_model.onnx
       12,226  pipeline_data.json
          774  world_pipeline_config.json
```

That is a ~2.3 GB export (roughly 2× the F32 weights — ONNX duplicates
initializers in places). It is **not cached locally**; obtaining it requires a
download, which this audit did not perform.

`torch.onnx.export` is available in the existing venv (`torch 2.13.0`, `dynamo=False`
path used by the exporter). `onnx` / `onnxruntime` are **absent** and would need
installing before any export or verification can run.

### CoreML — plausible, unproven

`coremltools` is absent. The operator set is within CoreML's conv/matmul support,
and the A-series/M-series ANE would be a natural home. Not attempted, so not
claimed. Risk: the `einsum` in the attention path (see below) may decompose
poorly, and attention only exists in base.

### LibTorch / torch C++ — works but defeats the objective

Would keep ~1 GB of Torch runtime inside a game binary. It is not Python, but it is
also not a shipping win on a 16 GB M2 and contradicts the "native" premise.

### ggml — native conv exists, verified; the importer does not

Present on this machine: `libggml.dylib`, `libggml-base.0.27.0.dylib`,
`libllama.dylib` (Homebrew, ggml 0.27.0 / llama.cpp 0.7.0).

Conv support is **not assumed — it is exported**:

```
$ nm -gU /opt/homebrew/lib/libggml-base.dylib | grep conv_2d
T _ggml_conv_2d          T _ggml_conv_2d_direct
T _ggml_conv_2d_dw       T _ggml_conv_2d_dw_direct
T _ggml_conv_2d_s1_ph
```

matching `ggml.h:2146,2200,2213,2219`. So the 470-odd convolutions in these nets
have a real native primitive underneath them.

**Caveat, stated plainly:** ggml is a *tensor library*, not an ONNX consumer. There
is no ONNX→ggml importer for this graph, and llama.cpp ships no conv-net frontend.
Adopting ggml means writing a graph loader that reads the ~174+171+54 tensors and
replays the UNet structure in C. That is real work, not a format conversion.

### The attention path is the single biggest operator risk

**Verified against the exported artifact after this section was first written.**
`base_model.onnx` (2,029,994,361 B, sha256 `543de788...`) contains **3 `Einsum`
nodes**, 38 `Transpose`, 38 `MatMul` and 1 `Softmax` — so `Einsum` does **not**
lower away as predicted below. Any runtime must implement `Einsum`. The equations
are `i,j->ij` (outer product, from `MPFourier`) plus the attention pair
`nhcq,nhck->nhqk` and `nhqk,nhck->nhcq`. ONNX Runtime runs all three graphs;
see `native/proof/README.md`. Keep the analysis below as the reason the risk was
flagged, but the measured outcome is that Einsum survives.

This is the one place where the exporter does **no** special handling
(`grep einsum|attention|attn terrain_diffusion/onnx/export.py` → no matches; the
exporter relies on generic tracing).

`unet_block.py:102-107`, and only this block is live — the
`scaled_dot_product_attention` variant beneath it is dead code after the `return`:

```python
w = torch.einsum('nhcq,nhck->nhqk',
        q, k / torch.sqrt(torch.tensor(q.shape[2], dtype=q.dtype, device=q.device))
     ).softmax(dim=3)
y = torch.einsum('nhqk,nhck->nhcq', w, v)
```

Two properties make this tractable, both confirmed:

- `q.shape[2]` is the **head dimension**, and `channels_per_head = 64` is fixed
  (`unet_block.py:21,67`). It is a traced Python `int`, so it folds to the constant
  8 at trace time — the same trick the exporter already uses for `resample`. It is
  not a dynamic-shape escape hatch.
- `einsum` has two operands with no repeated batch/free index conflict, so ONNX
  lowers it to `MatMul` + `Transpose` + `Softmax`. No `Einsum` op survives.

Attention runs only at resolutions 8 and 16 in base. Sequential tokens at those
resolutions are small (64 and 256 tokens respectively), so this is not a
quadratic-explosion situation.

## 4. Pure Janet vs. library FFI — the distinction that decides the design

These are different products and should not be conflated.

**Pure Janet/bender would mean** reimplementing ~400M parameter 2-D convolutions
in a dynamically-typed interpreter. There is no BLAS binding in bender, no vector
types, and bender's FFI (`ffi/struct`, `ffi/defbind-alias`) is a *struct/layout*
facility, not a compute-backend facility. `src/rl.janet:3` already records the
project rule that FFI is confined to one module that talks to raylib. Running a
1 GB CNN through FFI-called scalar ops would be orders of magnitude too slow and
is not worth prototyping.

**Library FFI is therefore mandatory** for the learned part. The realistic shape:

```
Janet (game)  ──request──▶  thin C ABI  ──▶  ONNX Runtime / CoreML / ggml
    │                          │
    └── orchestration ─────────┘  (scheduler, laplacian, noise, tiling)
```

Two sub-decisions, kept separate:

1. **Where does orchestration live?** Recommended in Janet: the scheduler is 20
   steps of arithmetic, noise is PCG64, laplacian is a blur and a resize. Porting
   these removes Python entirely and keeps the world definition auditable in the
   game's own identity descriptor.
2. **Where does convolution run?** A mature library, reached through one narrow
   C ABI. Do not write convolutions.

### The FFI mechanism already ships in this repo

This is not a proposal — it is the pattern `src/rl.janet` already uses for raylib,
and it is worth being precise about why it transfers.

```
src/rl.janet:20    (ffi/context (find-raylib) :lazy true)
src/rl.janet:39    (def vec2-type (ffi/struct :float :float))
src/rl.janet:104   (ffi/defbind-alias InitWindow init-window :void [w :int h :int title :string])
src/rl.janet:55    (def image-type (ffi/struct :ptr :int :int :int :int))
```

`ffi/context` opens an arbitrary dylib by path at runtime; `ffi/defbind-alias`
binds symbols with typed signatures including raw `:ptr`; and `unsafe/poke`
(`src/rl.janet:541`) writes through a struct pointer. That is sufficient to:

- open `libonnxruntime.dylib` or `libggml.dylib`,
- declare `CreateSession` / `Run` / `ggml_conv_2d` with `:ptr` arguments,
- hand the library a float buffer and read results back.

The `:lazy true` flag matters for shipping: it resolves symbols on first call, so
`./run.sh build` (which compiles `main.janet` AOT via `bender --aot --native`) is
not broken by the binding merely existing.

**What does *not* transfer:** bender's FFI is a struct/layout facility. It does not
give Janet vectors, BLAS, or an autograd-free conv primitive. That is exactly why
the split above is mandatory rather than a preference. `src/rl.janet:3` already
enforces the one-module rule; a native generation binding should follow the same
convention so exactly one module owns the ML library handle.

**Redistribution licensing** — read from the actual license files on disk, not from
memory:

| Artifact | License | Evidence |
|---|---|---|
| Upstream code | MIT | `repo/LICENSE`, "Copyright (c) 2025 Alexander Goslin" |
| Weights | MIT | snapshot `README.md` front-matter `license: mit` |
| ONNX export | MIT | same repo, same license declaration |
| `infinite-tensor` | MIT | `docs/TERRAIN_DIFFUSION.md` pin table |
| ggml 0.27.0 | MIT | `/opt/homebrew/Cellar/ggml/0.27.0/LICENSE`, "Copyright (c) 2023-2026 The ggml authors" |
| llama.cpp 0.7.0 | MIT | `/opt/homebrew/Cellar/llama.cpp/0.7.0/LICENSE`, same holder |
| ONNX Runtime | MIT | upstream project license (not present on this machine) |
| coremltools | BSD-3-Clause | upstream project license (not present on this machine) |

The first six are verified on this disk. The last two are **not verified here** —
they are not installed, and this audit did not download them. Treat those two rows
as "expected MIT/BSD, must be confirmed at adoption time", not as evidence.

No copyleft, no attribution-in-UI obligation, and no gated weights were encountered.

## 5. Blockers, ranked

1. **OnnxRuntime / CoreML / ggml import path for this graph does not exist yet.**
   ONNX artifact exists; the native consumer does not. This is the whole
   engineering task, and it is a graph-replay problem, not a research problem.
2. **2.3 GB ONNX vs 1.14 GB safetensors.** Export roughly doubles footprint.
   F16 would halve it, but changes numerics and therefore the world identity —
   which is a correctness decision, not an optimization.
3. **Orchestration must be ported and must reproduce bit-identically**, or the
   native path and any baked cache disagree. `docs/TERRAIN_DIFFUSION.md` already
   records that a locally recomputed stats table drifts channel-0 quantiles by up
   to **69.1 m** — the project has already been burned by exactly this class of
   divergence. The frozen table must ship as data, never be recomputed.
4. **Perlin conditioning** depends on `pyfastnoiselite` (FastNoiseLite). Either
   port FastNoiseLite (small, MIT, single-header C++) or freeze the conditioning
   map. Porting is the cleaner option.
5. **Memory.** Decoder at 512×512 peaks 3.39 GB of a 12.71 GB MPS budget
   (measured earlier). A native path needs the same tiling discipline, not a
   different one.

## 6. Honest scope statement

- The claim **"these three nets export cleanly and upstream already did it"** is
  evidence-backed.
- The claim **"a native ONNX- or CoreML-backed generator can ship"** is a
  *design conclusion*, not a measured result. Nothing was exported or run here.
- The claim **"pure Janet inference is viable"** is **false** and should not be
  pursued.
- Nothing in this audit should be read as saying the current producer works. It
  does not: baked tiles are flat sea level (256 × value 28) while the same
  pipeline sampled directly yields −1095…−619 m. That defect is orthogonal to
  native feasibility and belongs to the producer owner.

## 7. Bounded proof proposal (recommended next step)

Smallest experiment that converts export plausibility into evidence. **Read-only
w.r.t. production files; all output under `tmp/`.**

**Step 1 — export the coarse model only (≈30 min).**
Install `onnx` and `onnxruntime` into the *existing* `tmp/terrain-runtime/venv`
(this is the only install, and it is confined to a gitignored venv), then:

```sh
tmp/terrain-runtime/venv/bin/python -m terrain_diffusion.onnx.export \
    <snapshot> --output tmp/terrain-runtime/onnx --models coarse_model \
    --opset 17 --verify
```

Coarse is 11 MB and 2.8 M parameters — the whole risk of the exporter
(resample patching, padding tuples, conditioning flattening) is exercised on a
small model. **Success criterion:** `max |diff| < 1e-4` versus PyTorch, and the
`.onnx` file loads in `onnxruntime` at all. Do not proceed until coarse verifies.

**Step 2 — export base and decoder (≈1–2 h).**
Same command without `--models`. Base is the one with attention, so this is where
`einsum`/`softmax` portability is actually proven rather than assumed. Verify each.

**Step 3 — decide the runtime from measured numbers.**
Compare, for the base net at 64×64: ONNX Runtime CPU latency, ONNX Runtime CoreML
EP latency, and peak RSS. That comparison — not a licensing argument — picks the
runtime.

**Step 4 — prove the FFI seam with a trivial symbol (≈30 min).**
Before any orchestration is ported, prove the Janet→native call works at all.
Add a throwaway scratch module under `tmp/` (never `src/`) that:

1. `(ffi/context "<path to libonnxruntime or libggml>")`,
2. binds one symbol with `:ptr` in its signature via `ffi/defbind-alias`,
3. allocates a float buffer, passes it, reads a result back.

**Success criterion:** a value round-trips and `./run.sh build` still produces a
working AOT binary — the `:lazy true` claim is then evidenced, not trusted. This
is the step that converts "Janet can call a tensor library" from design assertion
to fact, and it is cheap enough to do before committing to a runtime.

**Step 5 — only if steps 1–4 pass**, port the *orchestration* to a small C ABI in
isolation (scheduler + laplacian + noise, no conv), and diff its output against
the Python path on a fixed seed for bit-identity. This is where "no Python at
runtime" is actually won or lost.

**Explicitly deferred:** JavaScript/WebGPU, F16 quantization, ANE-specific
conversion, and any inversion of the frozen-stats decision. None are needed to
answer feasibility.

**Kill criteria:** if coarse fails to verify, or base fails on the attention path,
the ONNX route is dead and ggml-by-hand becomes the only native option — a
substantially larger project that should be re-costed before any code is written.
If step 4 cannot round-trip a buffer, the whole native premise is in doubt
regardless of which model format is chosen.

## 8. Generation UI: unavailable until the native proof passes

The **native** learned-generation provider must remain unavailable until the
complete pipeline is verified. The user separately authorized the explicitly
temporary Python provider described in `PYTHON_TERRAIN_PROVIDER.md`; it calls the
real upstream model and is not a procedural substitute or final shipping runtime.
The earlier blanket restriction below is superseded by that named exception.
For the final native provider:

- Do not imply the native provider is shipping from successful graph forwards
  alone, and never label a procedural/flat substitute as learned terrain.
- The temporary Python producer is not the Python-free shipping solution. Its
  verified seed-12345 land query produced 64 tiles without clipping and saved and
  reloaded without Python. Fully clipped maps are now refused; the earlier
  all-ocean debug result is not representative proof of usable terrain.
- When the proof passes, the honest UI state changes from "unavailable" to
  "available", gated on the identity check already used by the cache — the same
  discipline the rest of this codebase applies to pinned artifacts.

The truthful player-facing distinction is native procedural, temporary Python
learned (when offline readiness passes), and native learned still unavailable.

## 9. Arithmetic-only proof follow-up

No model forwards or generation were launched in this follow-up. The pure
`test-scheduler.janet` and `test-scheduler-tensor.janet` checks pass: the tensor
path advances state once and agrees with scalar updates on fixed synthetic
outputs. This does not establish complete coarse-model trajectory equivalence.

The native Laplacian encoder was found to blur before downsampling, unlike the
pinned upstream implementation, which downsamples before blurring. That ordering
was corrected with arithmetic regressions. Gaussian-kernel width/centering and
negative-index reflection are now corrected and covered by analytic impulse and
symmetry checks. Extrapolated denoise decoding now matches upstream one-ring
linear padding, resize/crop geometry and Python ties-to-even rounding, with
boundary ramps, constants and singleton fixtures. Ordinary decode retains its
previous non-extrapolated default.

Downsampling antialiasing is now integrated into the native encoder. CPU-only torchvision 0.28.0 /
Torch 2.13.0 array-transform goldens are now captured in
`native/proof/fixtures/resize-aa.json`, with an inert Janet companion. A separable
scale-widened triangular-filter helper matches six small downsample fixtures
within the recorded float32 tolerance, including corner-edge renormalization
and two checkerboard phases. No model weights, forwards or GPU are involved.

The encoder selects the antialias helper for shrinking grids. The helper
rejects axis growth rather than claiming untested mixed shrink/grow support. The integrated
8×8-to-4, sigma-1 encoder was compared against the captured full upstream encode
baseline in `resize-aa-addendum.{json,janet}`: maximum absolute error was
7.29e-7 over 64 residual values and 3.98e-7 over 16 low-resolution values, below
the 2e-6 arithmetic-test bound. Janet fixtures retain the JSON precision and
record their paired JSON SHA. Existing upsample behavior remains unchanged.
These small-array checks are not bit-identity or full model-pipeline proof.
Run `./run.sh test-native-arithmetic` for the fixed model-free allowlist:
geometry, scalar scheduler, tensor scheduler, Laplacian filtering, and antialias
resize checks. The command works outside the checkout when invoked by absolute
path, rejects extra arguments, and never discovers future tests by glob. It is
not a model-forward or generation command and passing it is not native-provider
readiness. `./run.sh test-capture-contract` separately runs the three
standard-library capture-tool suites in isolated Python processes; it requires
no Bender, tensor libraries or model assets. Isolation matters because producer
unit tests mock import state, while the contract suite asserts that importing
its helpers loads neither NumPy nor Torch. Both commands work when invoked by
absolute path from outside the checkout. Normal `./run.sh test` remains the game
regression gate.

The native provider stays unavailable until these pieces and an explicitly owned
end-to-end numerical comparison pass. Missing first-divergence captures must not be replaced with
rescaling output until it looks plausible.

## 10. Existing coarse capture authority check

Do not infer model stage from a filename alone. `tools/terrain_stage_capture.py`
labels its first three forward calls coarse/base/decoder by global call ordinal,
but upstream runs multiple coarse forwards before entering the base model. In
`fixtures/stage2/stage-meta.json`, the record named base has coarse shapes
(11 input channels, 6 output channels) and the next coarse noise label.

The physical `stage2/base_x.f32` is not that recorded tensor: it is 81,920 bytes
(5×64×64 floats), while the metadata shape requires 180,224 bytes; its SHA256
starts `452fb2fa`, not recorded `34e274dd`. Do not use it as step-1 evidence.
In contrast, `stage2/coarse_x.f32` and `coarse_out.f32` match their recorded
byte counts and SHA256 values (`bb77526a...` and `63bc0a15...`).

Before another numerical conclusion, validate every capture against shape and
SHA. `python3 tools/validate_stage_capture.py <capture-dir>` now performs those
checks without importing tensor libraries. The existing stage2 bundle fails;
its files have not been changed or silently relabeled.

The producer now names calls by actual model object identity and per-model
index: first calls retain coarse/base/decoder filenames, subsequent calls use
labels such as coarse-step-0001. Metadata records stage and call indices.
Output-directory reuse is refused so different captures cannot silently mix.
These behaviors are covered by standard-library fake-object tests. A shared
`tensor_payload` / `write_payload` path now also permits a real writer-to-validator
contract test without NumPy or Torch: valid ten-tensor bundles (including five conditioning tensors) pass; same-size
byte corruption, missing files, wrong shape/size, changed noise bytes and missing
metadata fail. Per-call filenames are derived from the complete capture label,
not the bare model stage. The capture-tool test group passes 53 tests.
No new model capture has been run using the corrected producer.
These observations neither prove a new model mismatch nor resolve the coarse
trajectory divergence.

## 11. Native artifact inventory is not a shipping claim

`python3 tools/native_artifact_inventory.py ROOT SPEC.json` inventories only
caller-listed files, with no library/model loading. The bounded version-1 spec
lists `artifacts`, each with a `role`, relative `path`, relative `notice` file,
and optional `expected_sha256`. Paths must stay within ROOT and regular files
are required. Output records observed byte counts and SHA256; an expected digest
is checked when supplied. Missing notices and invalid paths fail closed.

This does not interpret license permissions, distribute a bundle or validate
numerical output. Numeric readiness remains false. The proof still uses
checkout-relative, gitignored runtime/model files; selecting distributable
platform-relative assets and confirming rights/notice completeness remain
separate shipping gates. No capture or model forward was rerun for this audit.
