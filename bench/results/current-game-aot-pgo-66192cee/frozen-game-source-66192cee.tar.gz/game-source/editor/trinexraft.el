;;; trinexraft.el --- Emacs development studio for TrineXraft  -*- lexical-binding: t; -*-

;;; Commentary:
;;
;; The TrineXraft studio: drive the running game from Emacs.
;;
;; The game exposes a line-oriented REPL socket under `--dev' (see
;; src/dev-server.janet).  One line of Janet source in, one line back:
;;
;;     ok <printed output> => <value>
;;     err <printed output> => <error>
;;
;; This file is deliberately small and has no dependencies beyond Emacs
;; itself.  Three things it does:
;;
;;   `trinexraft-eval'    evaluate a form against the live game
;;   `trinexraft-mode'    a REPL buffer bound to the game, `C-c C-c' on a form
;;   `trinexraft-launch'  start the game with `--dev' without blocking Emacs
;;
;; Design note: there is ONE way to talk to the game -- send a form and read a
;; reply.  The REPL buffer, the region evaluation, and every control-panel
;; button all funnel through `trinexraft-eval'.  A UI that invented its own
;; second path would drift from the REPL and become a second thing to debug.
;;
;; Why not an in-game GUI: raylib is single-window, so floating tool windows
;; would mean adding a whole second toolkit.  Emacs already is a windowing
;; toolkit with an editor attached, so the studio lives here and the game
;; stays a game.

;;; Code:

(require 'cl-lib)
(require 'subr-x)

(defgroup trinexraft nil
  "Emacs development studio for TrineXraft."
  :group 'tools)

(defcustom trinexraft-project-dir
  (let ((candidate (expand-file-name "~/Development/Projects/ML/trinecraft")))
    (if (file-directory-p candidate) candidate nil))
  "Directory containing the TrineXraft checkout."
  :type '(choice directory (const nil))
  :group 'trinexraft)

(defcustom trinexraft-launch-args '("--dev" "--dev-port" "7888" "--uncapped")
  "Arguments passed to run.sh when launching from Emacs.

`trinexraft-launch' runs the INTERPRETER (`run.sh` execs bender against
main.janet); it does not compile anything.  That is deliberate for the
development loop: source edits are live on the next launch, and there is no
build step to forget.  A native executable is only for distribution and for
measurement -- build one with `trinexraft-build-native'.

The port is stated explicitly and deliberately.  The game defaults `--dev-port'
to 0, which asks the OS for a free port -- correct for ad-hoc use, useless for
discovery, because the port then exists only in the game's stdout.  Reconnecting
after a restart is a normal part of the loop, so the port is pinned here and
`trinexraft--discover-port' can read it back from the process command line."
  :type '(repeat string)
  :group 'trinexraft)

(defcustom trinexraft-reply-timeout 10
  "Seconds to wait for a reply before reporting the game as unresponsive."
  :type 'number
  :group 'trinexraft)

(defvar trinexraft--process nil
  "Live socket process to the game, or nil.")
(defvar trinexraft--port nil
  "Port of the current dev session.")
(defvar trinexraft--pending nil
  "Alist of (marker . callback) for in-flight requests.")
(defvar trinexraft--buffer "")

;;
;; --- Connection ---------------------------------------------------------
;;

(defun trinexraft--port-from-process ()
  "Read a pinned --dev-port from a running game's command line, or nil."
  (when-let* ((dir (or trinexraft-project-dir default-directory)))
    (when (file-directory-p dir)
      (with-temp-buffer
        (when (zerop (call-process "pgrep" nil t nil "-fl" "main\\.janet"))
          (goto-char (point-min))
          (when (re-search-forward "--dev-port[ =]+\\([0-9]+\\)" nil t)
            (let ((port (string-to-number (match-string 1))))
              ;; --dev-port 0 means "any free port"; the real one is in stdout.
              (unless (zerop port) port))))))))

(defun trinexraft--port-from-listening-socket ()
  "Find the dev port by asking the OS which loopback port the game listens on.

Needed for a game started OUTSIDE Emacs -- `./run.sh --dev' in a terminal --
where there is neither a command-line port to read back nor a process buffer to
inspect.  `lsof' reports the truth regardless of how the game was started,
which guessing at a range of ports cannot do (the OS hands out arbitrary
high ports when --dev-port is 0)."
  (when-let* ((pid (with-temp-buffer
                     (when (zerop (call-process "pgrep" nil t nil
                                                "-f" "bender.*main\\.janet"))
                       (goto-char (point-min))
                       (when (re-search-forward "\\([0-9]+\\)" nil t)
                         (string-to-number (match-string 1)))))))
    (with-temp-buffer
      (when (zerop (call-process "lsof" nil t nil "-nP" "-a" "-p"
                                 (number-to-string pid)
                                 "-iTCP" "-sTCP:LISTEN"))
        (goto-char (point-min))
        ;; Only loopback: the dev server never binds a public interface, and
        ;; refusing anything else keeps a stray match from being dialled.
        (when (re-search-forward "127\\.0\\.0\\.1:\\([0-9]+\\) (LISTEN)" nil t)
          (string-to-number (match-string 1)))))))

(defun trinexraft--port-from-game-buffer ()
  "Read the port the game announced on its own stdout, or nil.

Covers a launch that left `--dev-port' unset: the game picks a free port and
prints `dev-server: listening on 127.0.0.1:NNNN'.  Reading it back is what
makes discovery work regardless of how the game was started."
  (when (and (boundp 'trinexraft--game-process)
             (processp trinexraft--game-process)
             (buffer-live-p (process-buffer trinexraft--game-process)))
    (with-current-buffer (process-buffer trinexraft--game-process)
      (save-excursion
        (goto-char (point-min))
        (when (re-search-forward
               "dev-server: listening on [0-9.]+:\\([0-9]+\\)" nil t)
          (string-to-number (match-string 1)))))))

(defun trinexraft--discover-port ()
  "Find the dev port of a running game, or nil.

Two sources, because the game supports both launch shapes: the explicit
`--dev-port' on the command line (fast, works for any process), and the port
the game printed to its own buffer (the only place a port of 0 is knowable)."
  (or (trinexraft--port-from-process)
      (trinexraft--port-from-game-buffer)
      (trinexraft--port-from-listening-socket)))

(defun trinexraft--game-process-running-p ()
  "Non-nil when a game subprocess started here is still alive."
  (and (boundp 'trinexraft--game-process)
       (processp trinexraft--game-process)
       (process-live-p trinexraft--game-process)
       t))

(defun trinexraft-connected-p ()
  "Non-nil when the socket to the game is live."
  (and trinexraft--process (process-live-p trinexraft--process) t))

(defun trinexraft-disconnect ()
  "Close the connection to the game."
  (interactive)
  (when trinexraft--process
    (delete-process trinexraft--process)
    (setq trinexraft--process nil
          trinexraft--pending nil
          trinexraft--buffer ""))
  (message "TrineXraft: disconnected"))

(defun trinexraft--filter (_proc chunk)
  "Accumulate CHUNK and dispatch every complete reply line."
  (setq trinexraft--buffer (concat trinexraft--buffer chunk))
  (let (line)
    (while (string-match "\n" trinexraft--buffer)
      (setq line (substring trinexraft--buffer 0 (match-beginning 0)))
      (setq trinexraft--buffer (substring trinexraft--buffer (match-end 0)))
      (trinexraft--dispatch line))))

(defun trinexraft--dispatch (line)
  "Deliver one reply LINE to the oldest pending request."
  (let ((entry (pop trinexraft--pending)))
    (when entry
      (condition-case err
          (funcall (cdr entry) line)
        (error (message "TrineXraft: reply handler failed: %S" err))))))

(defun trinexraft-connect (&optional port)
  "Connect to the game's dev socket on PORT, or discover it."
  (interactive)
  (when (trinexraft-connected-p) (trinexraft-disconnect))
  (let ((port (or port (trinexraft--discover-port))))
    (unless port
      (user-error
       (if (trinexraft--game-process-running-p)
           "Game is running but exposes no dev socket --- launch it with --dev"
         "No running game; start one with \\[trinexraft-launch]")))
    (setq trinexraft--port port)
    (setq trinexraft--process
          (make-network-process
           :name "trinexraft"
           :host "127.0.0.1"
           :service port
           :nowait nil
           :coding 'no-conversion
           :filter #'trinexraft--filter
           :sentinel (lambda (_proc event)
                       (unless (string-prefix-p "open" event)
                         (setq trinexraft--process nil)
                         ;; A deliberate disconnect should not look like a
                         ;; failure: report only unexpected terminations.
                         (unless (string-prefix-p "deleted" event)
                           (message "TrineXraft: connection lost (%s)"
                                    (string-trim event)))))))
    (setq trinexraft--buffer "")
    (message "TrineXraft: connected on port %d" port)
    port))

(defun trinexraft--ensure-connection ()
  "Return a live process, connecting if needed."
  (unless (trinexraft-connected-p)
    (trinexraft-connect))
  trinexraft--process)

;;
;; --- Evaluation ---------------------------------------------------------
;;

(defun trinexraft--parse-reply (line)
  "Split one reply LINE into a plist with :ok, :output and :value/:error.

Parsing is deliberately total: a malformed reply becomes an error record
rather than a signal, because a protocol surprise should be visible in the
REPL, not thrown out of whatever command happened to be running."
  (cond
   ((string-prefix-p "ok " line)
    (let* ((body (substring line 3))
           (split (string-match " => " body))
           (output (if split (substring body 0 split) body))
           (value (if split (substring body (+ split 4)) "")))
      (list :ok t :output (trinexraft--unescape output) :value value)))
   ((string-prefix-p "err " line)
    (let* ((body (substring line 4))
           (split (string-match " => " body))
           (output (if split (substring body 0 split) body))
           (err (if split (substring body (+ split 4)) "")))
      (list :ok nil :output (trinexraft--unescape output) :error (trinexraft--unescape err))))
   (t (list :ok nil :output "" :error (format "unparseable reply: %S" line)))))

(defun trinexraft--unescape (s)
  "Undo the newline and backslash escaping the server applies."
  (let ((out (make-string 0 ?\s)) (i 0) (n (length s)))
    (while (< i n)
      (let ((c (aref s i)))
        (cond
         ((and (= c ?\\) (< (1+ i) n))
          (let ((next (aref s (1+ i))))
            (setq out (concat out (cond ((= next ?n) "\n")
                                        ((= next ?r) "\r")
                                        ((= next ?\\) "\\")
                                        (t (char-to-string next)))))
            (setq i (+ i 2))))
         (t (setq out (concat out (char-to-string c)))
            (setq i (1+ i))))))
    out))

(defun trinexraft-eval (form &optional callback)
  "Send FORM to the game.

With CALLBACK, call it with the parsed reply plist asynchronously and return
nil.  Without it, block for the reply and return the plist -- convenient from
`M-:' and from Lisp that genuinely needs the value."
  (let ((proc (trinexraft--ensure-connection)))
    (if (not proc)
        (let ((reply (list :ok nil :output "" :error "not connected")))
          (when callback (funcall callback reply))
          reply)
      (process-send-string
       proc (concat (replace-regexp-in-string "\n" " " form) "\n"))
      (if callback
          (progn
            (setq trinexraft--pending
                  (append trinexraft--pending (list (cons nil callback))))
            nil)
        ;; Synchronous: wait for our own reply specifically, so a background
        ;; request cannot steal it.
        (let ((result nil)
              (deadline (+ (float-time) trinexraft-reply-timeout)))
          (setq trinexraft--pending
                (append trinexraft--pending
                        (list (cons nil (lambda (line)
                                          (setq result (trinexraft--parse-reply line)))))))
          (while (and (null result) (< (float-time) deadline))
            (accept-process-output proc 0.05))
          (or result
              (list :ok nil :output "" :error "timeout waiting for the game")))))))

(defun trinexraft-value-string (reply)
  "Return REPLY's value as a plain string, stripping Janet quoting.

Values arrive as `%q' output, so a Janet string comes back as `\"text\"'
with escaped inner quotes. For readouts we want the text itself."
  (when (plist-get reply :ok)
    (let ((v (plist-get reply :value)))
      (when (stringp v)
        (setq v (string-trim v))
        (when (and (>= (length v) 2)
                   (string-prefix-p "\"" v)
                   (string-suffix-p "\"" v))
          (setq v (substring v 1 -1)))
        (replace-regexp-in-string "\\\\\"" "\"" v)))))

(defun trinexraft-eval-print (form)
  "Evaluate FORM and echo the result -- the interactive entry point."
  (interactive "sTrineXraft: ")
  (let* ((reply (trinexraft-eval form))
         (out (plist-get reply :output)))
    (when (and out (not (string-empty-p out)))
      (message "%s" (string-trim out)))
    (if (plist-get reply :ok)
        (message "=> %s" (plist-get reply :value))
      (message "error: %s" (plist-get reply :error)))))

;;
;; --- Launch and restart -------------------------------------------------
;;

(defvar trinexraft--game-process nil
  "The game subprocess started from Emacs, or nil.")

(defun trinexraft-launch (&optional args)
  "Start the game with ARGS (default `trinexraft-launch-args').

Async on purpose: a launch that blocked Emacs would make the editor
unusable for exactly as long as the game runs."
  (interactive)
  (unless trinexraft-project-dir
    (user-error "Set `trinexraft-project-dir' to the TrineXraft checkout"))
  (when (and trinexraft--game-process
             (process-live-p trinexraft--game-process))
    (user-error "Game already running; use M-x trinexraft-restart"))
  (let ((default-directory trinexraft-project-dir)
        (args (or args trinexraft-launch-args)))
    (setq trinexraft--game-process
          (make-process
           :name "trinexraft-game"
           :buffer "*trinexraft-game*"
           :command (cons (expand-file-name "run.sh" trinexraft-project-dir) args)
           :sentinel (lambda (_proc event)
                       (unless (string-prefix-p "open" event)
                         (setq trinexraft--game-process nil)
                         (message "TrineXraft: game exited (%s)"
                                  (string-trim event))))))
    (message "TrineXraft: launched %s" (mapconcat #'identity args " "))
    ;; The socket is not up the instant the process exists: the game generates
    ;; spawn chunks and initialises GL first, which takes a second or two.
    ;; Connect on a short retry loop rather than making every command after a
    ;; launch fail with "no game running" until the user manually reconnects.
    (trinexraft--connect-when-ready)))

(defun trinexraft--connect-when-ready (&optional tries delay)
  "Poll for the game's dev socket, then connect.

TRYS attempts DELAY seconds apart.  A background timer rather than a sleep, so
Emacs stays usable during the wait -- the whole point of an async launch.

Waiting is necessary because the socket is not up the instant the process
exists: the game generates spawn chunks and initialises GL first.  Without this,
every command after a launch fails with \"no game running\" until the developer
manually reconnects."
  (trinexraft--connect-attempt (or tries 40) (or delay 0.25)))

(defun trinexraft--connect-attempt (remaining delay)
  "One connection attempt, rescheduling itself while REMAINING is positive."
  (cond
   ((trinexraft-connected-p)
    (message "TrineXraft: connected on port %d" trinexraft--port))
   ((not (trinexraft--game-process-running-p))
    (message "TrineXraft: game exited before the socket opened (see *trinexraft-game*)"))
   ((zerop remaining)
    (message "TrineXraft: no dev socket appeared; see *trinexraft-game*"))
   (t
    (condition-case nil
        (progn
          (trinexraft-connect)
          (message "TrineXraft: connected on port %d" trinexraft--port))
      (error
       (run-at-time delay nil #'trinexraft--connect-attempt
                    (1- remaining) delay))))))

(defun trinexraft-build-native (&optional output)
  "Compile a native AOT executable, synchronously, reporting the result.

Deliberately separate from `trinexraft-launch': these are different tools.  A
launch runs the interpreter so edits take effect immediately; a build produces
a binary that must be re-made after every source change and is only worth doing
for distribution or for measuring native speed.

Synchronous because a build that reported success before finishing would be a
lie, and because the caller almost always wants to run the result next."
  (interactive)
  (unless trinexraft-project-dir
    (user-error "Set `trinexraft-project-dir' to the TrineXraft checkout"))
  (let* ((default-directory trinexraft-project-dir)
         (args (append '("build") (when output (list output))))
         (buffer (get-buffer-create "*trinexraft-build*")))
    (with-current-buffer buffer (erase-buffer))
    (message "TrineXraft: building (native AOT)...")
    (let ((status (apply #'call-process
                         (expand-file-name "run.sh" trinexraft-project-dir)
                         nil buffer t args)))
      (if (zerop status)
          (progn
            (message "TrineXraft: build finished")
            (pop-to-buffer buffer))
        (pop-to-buffer buffer)
        (user-error "TrineXraft: build failed (see %s)" (buffer-name buffer))))))

(defcustom trinexraft-native-path "build/trinexraft-fresh"
  "Path, relative to the project, of the compiled native executable."
  :type 'string
  :group 'trinexraft)

(defun trinexraft-launch-native ()
  "Launch the COMPILED executable instead of the interpreter.

Fails with a clear message when no build exists, because the fix -- run
`trinexraft-build-native' -- is not obvious from a bare "no such file"."
  (interactive)
  (unless trinexraft-project-dir
    (user-error "Set `trinexraft-project-dir' to the TrineXraft checkout"))
  (let ((exe (expand-file-name trinexraft-native-path trinexraft-project-dir)))
    (unless (file-executable-p exe)
      (user-error "No native build at %s; run M-x trinexraft-build-native first"
                  exe))
    (when (and trinexraft--game-process
               (process-live-p trinexraft--game-process))
      (user-error "Game already running; use M-x trinexraft-restart"))
    (let ((default-directory trinexraft-project-dir))
      (setq trinexraft--game-process
            (make-process
             :name "trinexraft-game"
             :buffer "*trinexraft-game*"
             :command (list exe "--dev" "--dev-port" "7888" "--uncapped")
             :sentinel (lambda (_proc event)
                         (unless (string-prefix-p "open" event)
                           (setq trinexraft--game-process nil)
                           (message "TrineXraft: game exited (%s)"
                                    (string-trim event))))))
      (message "TrineXraft: launched %s" trinexraft-native-path)
      (trinexraft--connect-when-ready))))

(defun trinexraft-stop ()
  "Stop the game started from Emacs."
  (interactive)
  (when (and trinexraft--game-process
             (process-live-p trinexraft--game-process))
    (delete-process trinexraft--game-process))
  (setq trinexraft--game-process nil)
  (trinexraft-disconnect)
  (message "TrineXraft: stopped"))

(defun trinexraft-restart ()
  "Stop and relaunch the game."
  (interactive)
  (trinexraft-stop)
  (sleep-for 0.3)
  (trinexraft-launch))

;;
;; --- REPL mode ----------------------------------------------------------
;;

(defvar trinexraft-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-c C-c") #'trinexraft-eval-defun-at-point)
    (define-key map (kbd "C-c C-r") #'trinexraft-eval-region)
    (define-key map (kbd "C-c C-b") #'trinexraft-eval-buffer)
    (define-key map (kbd "C-c C-z") #'trinexraft-repl)
    map)
  "Keymap for `trinexraft-mode'.")

(defun trinexraft--send-and-report (form)
  "Send FORM and print its result into the current buffer."
  (let ((reply (trinexraft-eval form)))
    (goto-char (point-max))
    (insert (propertize (concat form "\n") 'face 'font-lock-keyword-face))
    (let ((out (plist-get reply :output)))
      (when (and out (not (string-empty-p out)))
        (insert out)))
    (if (plist-get reply :ok)
        (insert (propertize (format "=> %s\n" (plist-get reply :value))
                            'face 'font-lock-string-face))
      (insert (propertize (format "error: %s\n" (plist-get reply :error))
                          'face 'error)))))

(defun trinexraft-eval-region (start end)
  "Evaluate the Janet source between START and END."
  (interactive "r")
  (let ((form (string-trim (buffer-substring-no-properties start end))))
    (when (string-empty-p form) (user-error "Nothing to evaluate"))
    (trinexraft--send-and-report form)))

(defun trinexraft-eval-defun-at-point ()
  "Evaluate the top-level form at point."
  (interactive)
  (let ((form (or (thing-at-point 'defun t)
                  (buffer-substring-no-properties (point-min) (point-max)))))
    (unless form (user-error "No form at point"))
    (trinexraft--send-and-report (string-trim form))))

(defun trinexraft-eval-buffer ()
  "Evaluate the whole buffer."
  (interactive)
  (trinexraft-eval-region (point-min) (point-max)))

(define-derived-mode trinexraft-mode prog-mode "TrineXraft"
  "Major mode for editing Janet against a live TrineXraft session."
  (setq-local comment-start "#")
  (setq-local comment-start-skip "#+ *"))

;;;###autoload
(defun trinexraft-repl ()
  "Open a REPL buffer bound to the live game.

Opens in an ordinary window: unlike the panel, the REPL is a place you type,
and typing is what the current window is for."
  (interactive)
  (let ((buf (get-buffer-create "*trinexraft-repl*")))
    (with-current-buffer buf
      (unless (derived-mode-p 'trinexraft-mode)
        (trinexraft-mode))
      (goto-char (point-max)))
    (pop-to-buffer buf)
    (unless (trinexraft-connected-p)
      (trinexraft-connect))
    (let ((inhibit-read-only t))
      (goto-char (point-max))
      (insert (propertize
               (format ";; TrineXraft REPL — port %s.  C-c C-c evaluates the form at point.\n"
                       trinexraft--port)
               'face 'font-lock-comment-face)))
    buf))

(provide 'trinexraft)
;;; trinexraft.el ends here
