;;; trinexraft-panel.el --- live control panel for TrineXraft  -*- lexical-binding: t; -*-

;;; Commentary:
;;
;; The studio's control surface: a live view of the running game and the
;; widgets that change it.
;;
;; THE DIVISION OF RESPONSIBILITY, which is the whole design:
;;
;;   The GAME declares what exists. A control is a record with an id, a kind, a
;;   group, a label, the Janet form to evaluate, and -- for numeric controls --
;;   a minimum, maximum, step and a display form. That declaration lives next to
;;   the code it drives (src/panel.janet, and the `panel-add' verb).
;;
;;   EMACS decides how to present and manipulate it. This file contains no
;;   knowledge of any particular control: it renders whatever the manifest
;;   describes, and its keys do whatever the control's kind implies. An
;;   increment key on a number control is Elisp's judgement about how a bounded
;;   number should feel; the bounds themselves are the game's declaration.
;;
;; Adding a control therefore needs no Elisp at all, and changing how numeric
;; controls are edited needs no Janet. Neither side hardcodes the other's
;; business -- the contract is the manifest, not a shared list of names.
;;
;; There is one path to the game: every widget sends one form through
;; `trinexraft-eval'. A button and the same typed form are the same operation.

;;; Code:

(require 'cl-lib)
(require 'trinexraft)

(defgroup trinexraft-panel nil
  "Live control panel for TrineXraft."
  :group 'trinexraft)

(defcustom trinexraft-use-floating-panel t
  "When non-nil, open the panel in a floating child frame.

The frame is undecorated and parented to the window you are editing in, so it
sits beside the work like a tool palette rather than displacing it. A terminal
Emacs cannot draw child frames and falls back to a normal window."
  :type 'boolean
  :group 'trinexraft-panel)

(defcustom trinexraft-panel-frame-width 56
  "Width, in columns, of the floating panel frame."
  :type 'integer
  :group 'trinexraft-panel)

(defcustom trinexraft-panel-frame-height 28
  "Height, in lines, of the floating panel frame."
  :type 'integer
  :group 'trinexraft-panel)

;;
;; --- Protocol decoding ---------------------------------------------------
;;
;; The game escapes its delimiters so no field can contain one; decoding mirrors
;; that exactly. Getting it wrong would silently split a control in two, so it
;; is done once, here.
;;

(defun trinexraft-panel--unescape (s)
  "Undo the server's field escaping in S."
  (let ((out "") (i 0) (n (length (or s ""))))
    (while (< i n)
      (let ((c (aref s i)))
        (if (and (= c 92) (< (1+ i) n))
            (progn
              (setq out (concat out (trinexraft-panel--unescape-one (aref s (1+ i)))))
              (setq i (+ i 2)))
          (setq out (concat out (char-to-string c)))
          (setq i (1+ i)))))
    out))

(defun trinexraft-panel--unescape-one (code)
  "Expand one escaped CODE point."
  (cond ((= code ?p) "|")
        ((= code ?s) ";")
        ((= code ?n) "\n")
        ((= code ?r) "\r")
        ((= code 92) "\\")
        (t (char-to-string code))))
(defun trinexraft-panel--number-or-nil (s)
  "S as a number, or nil when it is empty or not numeric."
  (when (and s (not (string-empty-p s)))
    (string-to-number s)))

(defun trinexraft-panel--parse-controls (manifest)
  "Parse MANIFEST into a list of control plists.

Field order is fixed by src/panel.janet: id, kind, group, label, form, hint,
min, max, step, read-form."
  (let ((out nil))
    (dolist (record (split-string (or manifest "") ";" t))
      (let ((f (split-string record "|" nil)))
        (when (>= (length f) 6)
          (push (list :id (trinexraft-panel--unescape (nth 0 f))
                      :kind (intern (concat ":"
                                            (trinexraft-panel--unescape (nth 1 f))))
                      :group (trinexraft-panel--unescape (nth 2 f))
                      :label (trinexraft-panel--unescape (nth 3 f))
                      :form (trinexraft-panel--unescape (nth 4 f))
                      :hint (trinexraft-panel--unescape (nth 5 f))
                      :min (trinexraft-panel--number-or-nil (nth 6 f))
                      :max (trinexraft-panel--number-or-nil (nth 7 f))
                      :step (trinexraft-panel--number-or-nil (nth 8 f))
                      :read-form (trinexraft-panel--unescape (nth 9 f)))
                out))))
    (nreverse out)))

(defun trinexraft-panel--parse-values (payload)
  "Parse `id=value' PAYLOAD into an alist."
  (let ((out nil))
    (dolist (record (split-string (or payload "") ";" t))
      (let ((eq (string-search "=" record)))
        (when eq
          (push (cons (trinexraft-panel--unescape (substring record 0 eq))
                      (trinexraft-panel--unescape (substring record (1+ eq))))
                out))))
    (nreverse out)))

;;
;; --- Talking to the game -------------------------------------------------
;;

(defun trinexraft-panel--request (form)
  "Evaluate FORM and return its value string, or nil on failure."
  (let ((reply (trinexraft-eval form)))
    (if (plist-get reply :ok)
        (trinexraft-value-string reply)
      (message "TrineXraft error: %s" (plist-get reply :error))
      nil)))

(defun trinexraft-panel--send (form)
  "Evaluate FORM for its effect, reporting failure."
  (trinexraft-panel--request form) nil)

(defun trinexraft-panel--controls ()
  "The control list the game currently publishes."
  (trinexraft-panel--parse-controls
   (trinexraft-panel--request "(panel-controls)")))

(defun trinexraft-panel--values ()
  "The current display values as an alist."
  (trinexraft-panel--parse-values
   (trinexraft-panel--request "(panel-values)")))

;;
;; --- Control behaviour ---------------------------------------------------
;;
;; Behaviour is derived from `:kind`, never from a control's id. That is exactly
;; what makes a newly declared control work with no Elisp change.
;;

(defun trinexraft-panel--clamp (value control)
  "Clamp VALUE to CONTROL's declared bounds."
  (let ((lo (plist-get control :min))
        (hi (plist-get control :max)))
    (cond ((and lo hi) (max lo (min hi value)))
          (lo (max lo value))
          (hi (min hi value))
          (t value))))

(defun trinexraft-panel--format-number (value)
  "Format VALUE for a form, without scientific notation or trailing zeros."
  (let* ((s (format "%.6f" (float value)))
         (trimmed (replace-regexp-in-string "\\.?0+$" "" s)))
    (if (string-empty-p trimmed) "0" trimmed)))

(defun trinexraft-panel--apply-number (control value)
  "Evaluate CONTROL's form with VALUE substituted for its `%s' placeholder."
  (let ((form (plist-get control :form)))
    (if (string-search "%s" form)
        (trinexraft-panel--send
         (replace-regexp-in-string "%s" (trinexraft-panel--format-number value)
                                   form t t))
      (message "TrineXraft: control %s has no %%s to fill"
               (plist-get control :id)))))

(defun trinexraft-panel--current-value (control)
  "CONTROL's current value, falling back to its minimum or zero."
  (let ((cached (cdr (assoc (plist-get control :id)
                            trinexraft-panel--values-cache))))
    (or (and cached (not (string-empty-p cached)) (string-to-number cached))
        (plist-get control :min)
        0)))

(defun trinexraft-panel--step-value (control direction)
  "Move CONTROL's value one step in DIRECTION (+1 or -1).

The current value is re-read from the game rather than taken from the cache:
after a step the cache is stale by one, so consecutive presses would all
compute from the same starting value and the control would appear stuck."
  (let* ((step (or (plist-get control :step) 1))
         (id (plist-get control :id))
         (fresh (cdr (assoc id (trinexraft-panel--values))))
         (current (if (and fresh (not (string-empty-p fresh)))
                      (string-to-number fresh)
                    (trinexraft-panel--current-value control)))
         (next (trinexraft-panel--clamp (+ current (* direction step)) control)))
    (when (/= next current)
      (trinexraft-panel--apply-number control next))
    next))

(defun trinexraft-panel--activate (control)
  "Do the default action for CONTROL."
  (pcase (plist-get control :kind)
    (:action (trinexraft-panel--send (plist-get control :form)))
    (:number
     (let* ((current (trinexraft-panel--current-value control))
            (input (read-string (format "%s [%s..%s step %s]: "
                                        (plist-get control :label)
                                        (or (plist-get control :min) "-")
                                        (or (plist-get control :max) "-")
                                        (or (plist-get control :step) "-"))
                                (trinexraft-panel--format-number current))))
       (trinexraft-panel--apply-number control (string-to-number input))))
    (:text
     (let ((input (read-string (format "%s: " (plist-get control :label)))))
       (trinexraft-panel--send
        (replace-regexp-in-string "%s" input (plist-get control :form) t t))))
    (_ (trinexraft-panel--send (plist-get control :form))))
  (trinexraft-panel-refresh))

;;
;; --- Rendering -----------------------------------------------------------
;;

(defvar-local trinexraft-panel--controls-cache nil
  "Controls shown in this buffer, for key dispatch.")
(defvar-local trinexraft-panel--values-cache nil
  "Display values shown in this buffer, as an alist.")

(defconst trinexraft-panel--value-face
  '(:background "grey18" :foreground "tan1" :box (:line-width 1 :color "grey35"))
  "Face for a live value.

A live number has to look different from a label at a glance: the panel is read
while you are thinking about something else.")

(defun trinexraft-panel--insert-value (text)
  "Insert TEXT styled as a live value."
  (insert (propertize (format " %s " text) 'face trinexraft-panel--value-face)))

(defun trinexraft-panel--insert-control (control value)
  "Insert one line for CONTROL showing VALUE."
  (let ((start (point)))
    (pcase (plist-get control :kind)
      (:readout
       (insert (format "  %-22s" (plist-get control :label)))
       (trinexraft-panel--insert-value (or value "?")))
      (:number
       (insert (format "  %-22s" (plist-get control :label)))
       (trinexraft-panel--insert-value (or value "?"))
       (insert (format "   %s..%s step %s"
                       (or (plist-get control :min) "-")
                       (or (plist-get control :max) "-")
                       (or (plist-get control :step) "-"))))
      (:action
       (insert (format "  [ %s ]" (plist-get control :label))))
      (_
       ;; Any kind this client does not know yet still appears, with its raw
       ;; kind visible, so a newer game can add kinds without breaking an
       ;; older panel.
       (insert (format "  <%s> %s"
                       (substring (format "%s" (plist-get control :kind)) 1)
                       (plist-get control :label)))))
    (insert "\n")
    ;; The control travels with the text, so keys act on what the cursor is
    ;; actually on and cannot hit the wrong control after a refresh.
    (add-text-properties start (point)
                         (list 'trinexraft-control control
                               'mouse-face 'highlight))
    (when (plist-get control :hint)
      (insert (propertize (format "    %s\n" (plist-get control :hint))
                          'face 'shadow)))))

(defun trinexraft-panel-refresh ()
  "Re-read the manifest and values, then redraw the panel."
  (interactive)
  (unless (derived-mode-p 'trinexraft-panel-mode)
    (user-error "Not in a TrineXraft panel buffer"))
  (let* ((controls (trinexraft-panel--controls))
         (values (trinexraft-panel--values))
         (inhibit-read-only t)
         (groups nil))
    (setq trinexraft-panel--controls-cache controls
          trinexraft-panel--values-cache values)
    (erase-buffer)
    (insert (propertize "TrineXraft studio\n" 'face 'bold))
    (insert (propertize
             (format "port %s · %s · %d controls\n"
                     (or trinexraft--port "none")
                     (if (trinexraft-connected-p) "live" "down")
                     (length controls))
             'face 'shadow))
    (dolist (control controls)
      (let ((group (or (plist-get control :group) "general")))
        (unless (member group groups)
          (push group groups)
          (insert (propertize (format "\n%s\n" group) 'face 'bold))))
      (trinexraft-panel--insert-control
       control
       (cdr (assoc (plist-get control :id) values))))
    (insert "\n"
            (propertize
             (concat "RET/click: activate · "
                     "S-up/S-down or +/-: adjust a number · "
                     "g: refresh · C-c C-c: eval here\n")
             'face 'shadow))
    (goto-char (point-min))))

;;
;; --- Commands ------------------------------------------------------------
;;

(defun trinexraft-panel-control-at-point ()
  "The control the cursor is on, or signal."
  (or (get-text-property (point) 'trinexraft-control)
      (user-error "No control at point")))

(defun trinexraft-panel-activate ()
  "Activate the control at point."
  (interactive)
  (trinexraft-panel--activate (trinexraft-panel-control-at-point)))

(defun trinexraft-panel-increment (&optional direction)
  "Adjust the numeric control at point by one step.

DIRECTION is +1 (default) or -1. The increment is Elisp's decision about feel;
the bounds and step size are the game's declaration."
  (interactive)
  (let* ((control (trinexraft-panel-control-at-point))
         (dir (or direction 1)))
    (unless (eq (plist-get control :kind) :number)
      (user-error "Not a numeric control"))
    (trinexraft-panel--step-value control dir)
    (trinexraft-panel-refresh)))

(defun trinexraft-panel-increment-up ()
  "Step the numeric control at point up."
  (interactive)
  (trinexraft-panel-increment 1))

(defun trinexraft-panel-increment-down ()
  "Step the numeric control at point down."
  (interactive)
  (trinexraft-panel-increment -1))

(defun trinexraft-panel-insert-form ()
  "Insert a form into the panel buffer to evaluate with C-c C-c."
  (interactive)
  (let ((form (read-string "Janet form: ")))
    (save-excursion
      (goto-char (point-max))
      (insert "\n" form "\n"))))

(defvar trinexraft-panel-mode-map
  (let ((map (make-sparse-keymap)))
    (set-keymap-parent map special-mode-map)
    (define-key map (kbd "RET") #'trinexraft-panel-activate)
    (define-key map [mouse-1] #'trinexraft-panel-activate)
    ;; Shift-arrow, not C-arrow: macOS claims Ctrl+arrow for Mission Control,
    ;; so the binding never reaches Emacs. Both are accepted -- Option-arrow is
    ;; the other common macOS alternative -- with +/- as unambiguous fallbacks
    ;; that survive any keyboard remapping.
    (define-key map (kbd "S-<up>") #'trinexraft-panel-increment-up)
    (define-key map (kbd "S-<down>") #'trinexraft-panel-increment-down)
    (define-key map (kbd "M-<up>") #'trinexraft-panel-increment-up)
    (define-key map (kbd "M-<down>") #'trinexraft-panel-increment-down)
    (define-key map (kbd "+") #'trinexraft-panel-increment-up)
    (define-key map (kbd "-") #'trinexraft-panel-increment-down)
    (define-key map (kbd "g") #'trinexraft-panel-refresh)
    (define-key map (kbd "i") #'trinexraft-panel-insert-form)
    (define-key map (kbd "C-c C-c") #'trinexraft-eval-defun-at-point)
    map)
  "Keymap for `trinexraft-panel-mode'.")

(define-derived-mode trinexraft-panel-mode special-mode "TrineXraft-Panel"
  "Major mode for the TrineXraft control panel.

The panel renders whatever the game's registry publishes; it holds no
built-in knowledge of any control.")

;;
;; --- Floating child frames ---------------------------------------------
;;
;; The panel belongs in a floating tool window beside the game, not in a split
;; of the window you are editing code in. Emacs child frames do exactly this:
;; an undecorated frame parented to the current one, positioned by Lisp, which
;; the window manager does not manage separately.
;;
;; It is a capability, not a guarantee. A terminal Emacs cannot draw one, so
;; every path here falls back to a normal buffer view rather than failing.

(defvar trinexraft-panel--frame nil
  "The floating panel frame, when one exists.")

(defun trinexraft--childframes-supported-p ()
  "Non-nil when this Emacs can draw a child frame."
  (and (display-graphic-p)
       (fboundp 'make-frame-invisible)
       (fboundp 'frame-parent)))

(defun trinexraft--frame-alive-p (frame)
  "Non-nil when FRAME exists and is not deleted."
  (and (framep frame) (frame-live-p frame) t))

(defun trinexraft--float-buffer (buf &optional name)
  "Show BUF in a floating child frame, or fall back to a window.

The frame is reused when it already exists, so repeated invocations raise the
same tool window instead of spawning frames until the screen fills."
  (if (not (trinexraft--childframes-supported-p))
      (progn
        (pop-to-buffer buf '((display-buffer-reuse-window display-buffer-same-window)))
        (message "TrineXraft: no graphic display for a floating frame; panel shown in a window")
        buf)
    (if (trinexraft--frame-alive-p trinexraft-panel--frame)
        (progn
          (set-window-buffer (frame-root-window trinexraft-panel--frame) buf)
          (make-frame-visible trinexraft-panel--frame)
          (raise-frame trinexraft-panel--frame)
          trinexraft-panel--frame)
      (let* ((parent (selected-frame))
             ;; Place it at the parent's right edge: this is a tool panel, and
             ;; the eye expects it beside the work, not on top of it. The width
             ;; can read 0 on a frame that is not mapped yet, so the position is
             ;; only computed when there is something to measure.
             (parent-width (frame-pixel-width parent))
             (char-w (frame-char-width parent))
             (left (if (and (> parent-width 0) (> char-w 0))
                       (max 0 (- parent-width
                                 (* trinexraft-panel-frame-width char-w) 40))
                     nil))
             (frame (make-frame
                     `((parent-frame . ,parent)
                       (name . ,(or name "trinexraft-panel"))
                       (minibuffer . nil)
                       (undecorated . t)
                       (no-other-frame . t)
                       (width . ,trinexraft-panel-frame-width)
                       (height . ,trinexraft-panel-frame-height)
                       ,@(when left `((left . ,left)))
                       (top . 48)
                       (internal-border-width . 2)
                       (tool-bar-lines . 0)
                       (menu-bar-lines . 0)
                       (vertical-scroll-bars . nil)
                       (horizontal-scroll-bars . nil)
                       (font . ,(frame-parameter parent 'font))))))
        (setq trinexraft-panel--frame frame)
        (set-window-buffer (frame-root-window frame) buf)
        frame))))

(defun trinexraft-panel-undock ()
  "Show the panel in a floating child frame, or raise it if it exists."
  (interactive)
  (let ((buf (get-buffer-create "*trinexraft-panel*")))
    (with-current-buffer buf
      (unless (derived-mode-p 'trinexraft-panel-mode)
        (trinexraft-panel-mode))
      (trinexraft-panel-refresh))
    (trinexraft--float-buffer buf "trinexraft-panel")
    buf))

(defun trinexraft-panel-dock ()
  "Close the floating panel frame, leaving the buffer open."
  (interactive)
  (when (trinexraft--frame-alive-p trinexraft-panel--frame)
    (delete-frame trinexraft-panel--frame))
  (setq trinexraft-panel--frame nil)
  (message "TrineXraft: panel docked"))

(defun trinexraft-panel-toggle-frame ()
  "Toggle the panel between a floating frame and a normal window."
  (interactive)
  (if (trinexraft--frame-alive-p trinexraft-panel--frame)
      (trinexraft-panel-dock)
    (trinexraft-panel-undock)))

;;;###autoload
(defun trinexraft-panel ()
  "Open the TrineXraft control panel.

The contents come entirely from the game's registry, so this is the same
command whether the panel shows four controls or forty."
  (interactive)
  (if (and trinexraft-use-floating-panel
           (trinexraft--childframes-supported-p))
      (trinexraft-panel-undock)
    (let ((buf (get-buffer-create "*trinexraft-panel*")))
      (with-current-buffer buf
        (unless (derived-mode-p 'trinexraft-panel-mode)
          (trinexraft-panel-mode))
        (trinexraft-panel-refresh))
      (pop-to-buffer buf))))

(provide 'trinexraft-panel)
;;; trinexraft-panel.el ends here
