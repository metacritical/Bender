;;; trinexraft-keys.el --- studio keybindings and startup entry  -*- lexical-binding: t; -*-

;;; Commentary:
;;
;; One file to load in your init: binds the studio keys and provides the
;; entry command.  Nothing here is required for the studio to work -- the
;; other files are self-contained -- so this is convenience, not a dependency.
;;
;; Add to your init.el:
;;
;;     (load "/Users/you/Development/Projects/ML/trinecraft/editor/trinexraft-keys.el")
;;     (global-set-key (kbd "C-c t") #'trinexraft-studio)
;;
;; The map below is C-c t <key>, a prefix that will not collide with normal
;; editing.

;;; Code:

(require 'trinexraft)
(require 'trinexraft-panel)

(defvar trinexraft-studio-map
  (let ((map (make-sparse-keymap)))
    ;; Session
    (define-key map (kbd "l") #'trinexraft-launch)
    (define-key map (kbd "k") #'trinexraft-stop)
    (define-key map (kbd "R") #'trinexraft-restart)
    (define-key map (kbd "B") #'trinexraft-build-native)
    (define-key map (kbd "N") #'trinexraft-launch-native)
    (define-key map (kbd "c") #'trinexraft-connect)
    (define-key map (kbd "d") #'trinexraft-disconnect)
    ;; Windows
    (define-key map (kbd "r") #'trinexraft-repl)
    (define-key map (kbd "p") #'trinexraft-panel)
    (define-key map (kbd "P") #'trinexraft-panel-toggle-frame)
    ;; Evaluation, from anywhere
    (define-key map (kbd "e") #'trinexraft-eval-print)
    (define-key map (kbd "b") #'trinexraft-eval-buffer)
    ;; Native build (for distribution and speed measurement, not the dev loop)
    ;; Development loop
    (define-key map (kbd "m") #'trinexraft-reload-module)
    (define-key map (kbd "s") #'trinexraft-status)
    map)
  "Prefix map for the TrineXraft studio, bound at C-c t.")

(defun trinexraft-status ()
  "Echo the connection and game status."
  (interactive)
  (let ((reply (trinexraft-eval "(dev-status)")))
    (message "TrineXraft: %s"
             (if (plist-get reply :ok)
                 (plist-get reply :value)
               (plist-get reply :error)))))

(defconst trinexraft-modules
  '("world" "worldgen" "mesher" "stream" "palette" "frustum" "raycast"
    "player" "shaders" "sky-cycle" "sky-render" "material-recipes"
    "appearance-settings" "region" "atlas" "pickaxe" "edit-pick"
    "material-inspector")
  "Modules the game will live-reload.

Mirrors the registry in src/reload.janet. The game validates the name it
receives, so a stale entry here produces a clear error rather than a wrong
reload.")

(defun trinexraft-reload-module (name)
  "Live-reload module NAME (a keyword such as :mesher)."
  (interactive
   (list (intern (concat ":" (completing-read
                              "Module: " trinexraft-modules nil t)))))
  (let ((reply (trinexraft-eval (format "(reload-module %s)" name))))
    (if (plist-get reply :ok)
        (message "TrineXraft: reloaded %s — %s" name (plist-get reply :value))
      (message "TrineXraft: reload failed — %s" (plist-get reply :error)))))

;;;###autoload
(defun trinexraft-studio ()
  "Open the studio: connect, then show the panel and the REPL."
  (interactive)
  (unless (trinexraft-connected-p)
    (condition-case err
        (trinexraft-connect)
      (error (user-error "TrineXraft: %s (start it with C-c t l)"
                         (error-message-string err)))))
  (trinexraft-panel)
  (trinexraft-repl))

(global-set-key (kbd "C-c t") trinexraft-studio-map)

(provide 'trinexraft-keys)
;;; trinexraft-keys.el ends here
