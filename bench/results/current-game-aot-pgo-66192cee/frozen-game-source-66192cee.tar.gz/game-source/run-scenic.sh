#!/usr/bin/env bash
# Launch the generated mountain valley, not the default procedural world.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
map="$here/tmp/scenic-valley/27d25d28e4c2931106b2ee86ea3be45232a91dff92dc32e80369e039102a19c9"
bin="$here/build/trinecraft-scenic"
if [[ ! -f "$map/manifest.janet" ]]; then
  echo "error: generated scenic map is missing: $map" >&2
  echo "See docs/SCENIC_MAP.md to recreate the map; this launcher never starts inference." >&2
  exit 1
fi
if [[ ! -x "$bin" ]]; then
  echo "error: compile the scenic executable first: ./run.sh build build/trinecraft-scenic" >&2
  exit 1
fi
# Assets and material recipes are resolved relative to the project root.
cd "$here"
export JANET_NO_PROFILE=1
exec "$bin" --terrain-cache "$map" --seed 12345 \
  --scenic-view grounded --scenic-preload --no-terrain-worker "$@"
