"""A stand-in owner process for the two-process reuse test.

Run as a subprocess: acquires the real producer locks, publishes a status naming
its own pid, then waits on stdin. Kept deliberately tiny -- it is a lock holder,
not a worker, so no pipeline is ever loaded.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "tools"))

import terrain_backend as tb  # noqa: E402


def main():
    directory, token = sys.argv[1], sys.argv[2]
    cache_root, name = os.path.split(directory)
    layout = tb.Layout.open(cache_root, name)
    identity_lock, device_lock = tb.acquire_producer_locks(layout, "mps")
    tb.StatusWriter(layout, name, owner_token=token).write(
        "generating", 4, "owner alive"
    )
    print(os.getpid(), flush=True)
    try:
        sys.stdin.readline()
    finally:
        device_lock.release()
        identity_lock.release()
    return 0


if __name__ == "__main__":
    sys.exit(main())
