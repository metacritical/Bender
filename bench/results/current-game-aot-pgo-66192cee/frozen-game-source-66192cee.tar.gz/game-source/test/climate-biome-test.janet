# Headless tests for the climate-to-biome classifier.
#
# Pure: no GL, no window, no model, no inference, no subprocess, no filesystem.
# The module holds no state and reads nothing, so this suite cannot change a
# saved world.
#
# THE FIXTURES ARE SYNTHETIC AND STAND IN FOR A DECODED BUFFER. They are not
# model output and no claim is made that they are: the producer does not emit
# climate today. What they prove is that the RULES and the UNIT CONVERSION behave
# as documented over the values the reader would hand over.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/climate-biome-test.janet

(import ../src/climate-biome :as bio)
(import ../src/climate-tile :as tile)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

#
# --- Fixtures -----------------------------------------------------------
#

# A mutable table, because several checks add or remove a channel to prove the
# classifier refuses rather than categorises a partial input.
(defn climate [&opt opts]
  (def o (or opts {}))
  @{:temperature (get o :temperature 12.0)
    # STORED FORM: std * 100. The default of 200 is a 2 degrees C std.
    :temperature-seasonality (get o :temperature-seasonality 200.0)
    :precipitation (get o :precipitation 900.0)
    :precipitation-variability (get o :precipitation-variability 30.0)
    :lapse-rate (get o :lapse-rate -0.006)})

(def sea 28)

(defn biome-at [c elev &opt s]
  (bio/biome-of (bio/classify c elev (or s sea))))

#
# --- Vocabulary ---------------------------------------------------------
#

(print "\nvocabulary:")

(check "the vocabulary contains :unknown"
       (truthy? (some |(= :unknown $) bio/biomes)))
(check "the vocabulary is closed: biome? accepts every member"
       (every? (map bio/biome? bio/biomes)))
(check "biome? rejects a non-member" (not (bio/biome? :plains)))
(check "biome? rejects a misspelling" (not (bio/biome? :temperate-forrest)))
(check "there is no plains fallback"
       (nil? (some |(= :plains $) bio/biomes)))
(check "no member is duplicated"
       (= (length bio/biomes) (length (distinct bio/biomes))))
(check "the vocabulary is at most ten (what nine block ids could express)"
       (<= (length bio/biomes) 10))

# THE VOCABULARY ADMITS EVERY ANSWER THE CLASSIFIER GIVES. `classify` has always
# returned :savanna for warm wet ground; the keyword was simply missing from
# `biomes`, which made a real answer look like a non-member. These pin the fix in
# both directions so it cannot silently regress.
(check "the vocabulary contains :savanna"
       (truthy? (some |(= :savanna $) bio/biomes)))
(check "biome? accepts :savanna" (bio/biome? :savanna))
(check "an actual classified :savanna is a vocabulary member"
       (let [r (bio/classify (climate {:temperature 25.0 :precipitation 900.0})
                             60 sea)]
         (and (bio/classified? r)
              (= :savanna (bio/biome-of r))
              (bio/biome? (bio/biome-of r)))))

#
# --- Seasonality is the x100 stored form --------------------------------
#
# The single most likely implementation error: treating the stored seasonality as
# a temperature. These pin the divisor, so a future edit that drops it fails.
#

(print "\nseasonality scale:")

(check "the documented x100 scale is declared" (= 100 bio/seasonality-scale))
(check "the high-seasonality threshold is in STORED form, above the std it means"
       (= 3.0 (/ (bio/thresholds :seasonality-high) bio/seasonality-scale)))

# A stored 400 is a 4 degrees C std -- a real, seasonal climate -- and must not be
# read as 400 degrees.
(check "a stored 400 is interpreted as a 4 degree std, and still classifies"
       (bio/classified? (bio/classify (climate {:temperature-seasonality 400.0})
                                      60 sea)))

(check "seasonality does not change the answer while the vocabulary has one grassland"
       (and (= (biome-at (climate {:temperature-seasonality 50.0}) 60)
               (biome-at (climate {:temperature-seasonality 900.0}) 60))))

#
# --- Classification rules -----------------------------------------------
#

(print "\nclassification:")

(check "cold-adapted forest above the forest line is taiga"
       (= :taiga (biome-at (climate {:temperature 2.0 :precipitation 800.0}) 60)))
(check "cold dry ground is tundra"
       (= :tundra (biome-at (climate {:temperature 2.0 :precipitation 300.0}) 60)))
(check "frozen ground is ice even where wet"
       (= :ice (biome-at (climate {:temperature -5.0 :precipitation 900.0}) 60)))
(check "exactly at the freezing point is ice (0 C is a REAL value, not a gap)"
       (= :ice (biome-at (climate {:temperature 0.0 :precipitation 900.0}) 60)))
(check "one degree above freezing is not ice"
       (not= :ice (biome-at (climate {:temperature 0.1 :precipitation 900.0}) 60)))
(check "temperate wet ground is forest"
       (= :temperate-forest (biome-at (climate {}) 60)))
(check "temperate dry ground is grassland"
       (= :grassland (biome-at (climate {:precipitation 400.0}) 60)))
(check "arid warm ground is desert"
       (= :desert (biome-at (climate {:temperature 25.0 :precipitation 100.0}) 60)))
(check "warm adequately-wet ground is savanna"
       (= :savanna (biome-at (climate {:temperature 25.0
                                       :precipitation 900.0}) 60)))
(check "a classified savanna is not merely reachable but admitted by biome?"
       (bio/biome? (biome-at (climate {:temperature 25.0
                                       :precipitation 900.0}) 60)))
(check "a column at sea level is ocean" (= :ocean (biome-at (climate {}) sea)))
(check "a column above the shore band is land"
       (not= :ocean (biome-at (climate {}) (+ sea 4))))
(check "the last shore block is shore" (= :shore (biome-at (climate {}) (+ sea 3))))
(check "water is decided before climate: a frozen ocean is ocean"
       (= :ocean (biome-at (climate {:temperature -20.0}) sea)))

#
# --- :unknown never becomes a biome ------------------------------------
#

(print "\nunknown:")

(def no-climate (bio/classify nil 60 sea))

(check "absent climate is :unknown" (bio/unknown? no-climate))
(check "absent climate carries no biome key" (nil? (get no-climate :biome)))
(check "absent climate reports :no-climate" (= :no-climate (no-climate :reason)))
(check "biome-of on absent climate is :unknown, never plains"
       (= :unknown (bio/biome-of no-climate)))

(check "a non-finite channel is :unknown with :non-finite"
       (= :non-finite ((bio/classify (climate {:temperature (/ 0 0)}) 60 sea)
                       :reason)))
(check "an infinite channel is :unknown"
       (bio/unknown? (bio/classify (climate {:precipitation (/ 1 0)}) 60 sea)))
(check "one bad channel is enough for the whole answer to be :unknown"
       (bio/unknown? (bio/classify (climate {:lapse-rate (/ 0 0)}) 60 sea)))
(check "a missing channel is :unknown, not partly classified"
       (let [c (climate {})] (put c :lapse-rate nil)
         (bio/unknown? (bio/classify c 60 sea))))
(check "an extra channel is :unknown, not ignored"
       (let [c (climate {})] (put c :humidity 50.0)
         (bio/unknown? (bio/classify c 60 sea))))
(check "a non-table climate is :unknown"
       (bio/unknown? (bio/classify 12.0 60 sea)))
(check "a missing elevation is :unknown with :bad-elevation"
       (= :bad-elevation ((bio/classify (climate {}) nil sea) :reason)))
(check "a missing sea level is :unknown with :bad-sea-level"
       (= :bad-sea-level ((bio/classify (climate {}) 60 nil) :reason)))
(check "the reason names the FIRST failing input"
       (and (= :no-climate ((bio/classify nil nil nil) :reason))
            (= :bad-elevation ((bio/classify (climate {}) nil nil) :reason))))

#
# --- The units flag -----------------------------------------------------
#

(print "\nunits flag:")

(check "every result carries the unit basis it ran under"
       (= tile/unit-basis ((bio/classify (climate {}) 60 sea) :units)))

(check "a classification reports whether its units were MEASURED"
       (false? (bio/verified? (bio/classify (climate {}) 60 sea))))

(check "the units are source-derived today, so classification is licensed"
       (= :source-derived tile/unit-basis))

(check "every result carries a biome revision"
       (= bio/biome-revision ((bio/classify (climate {}) 60 sea) :biome-revision)))

(check "source reports a reader result's status"
       (= :unavailable (bio/source {:status :unavailable})))
(check "source reports nil as :absent" (= :absent (bio/source nil)))

#
# --- Determinism and purity ---------------------------------------------
#

(print "\ndeterminism:")

(def c1 (climate {:temperature 8.0 :precipitation 650.0}))

(check "the same input classifies identically every time"
       (every? (map (fn [_] (deep= (bio/classify c1 55 sea)
                                   (bio/classify c1 55 sea)))
                    (range 20))))

(check "classification does not depend on table key order"
       (let [pairs [[:temperature 8.0] [:temperature-seasonality 200.0]
                    [:precipitation 650.0] [:precipitation-variability 30.0]
                    [:lapse-rate -0.006]]
             forward (zipcoll (map |($ 0) pairs) (map |($ 1) pairs))
             reversed (zipcoll (map |($ 0) (reverse pairs))
                               (map |($ 1) (reverse pairs)))]
         (deep= (bio/classify forward 55 sea) (bio/classify reversed 55 sea))))

(check "classify does not mutate its input"
       (let [c (climate {}) before (string/format "%q" c)]
         (bio/classify c 60 sea)
         (= before (string/format "%q" c))))

#
# --- Boundaries ---------------------------------------------------------
#

(print "\nboundaries:")

(check "exactly at the arid line is desert"
       (= :desert (biome-at (climate {:precipitation 250.0}) 60)))
(check "one mm above the arid line is not desert"
       (not= :desert (biome-at (climate {:precipitation 251.0}) 60)))
(check "one mm below the forest line is not forest"
       (not= :temperate-forest (biome-at (climate {:precipitation 699.0}) 60)))
(check "one mm above the forest line is forest"
       (= :temperate-forest (biome-at (climate {:precipitation 701.0}) 60)))

#
# --- Agreement with the reader -----------------------------------------
#
# The one coupling between the two new modules, asserted rather than assumed: a
# renamed channel in either would otherwise be a silent nil.
#

(print "\nwith the reader:")

(defn- f32-bytes [v]
  (def (frac e) (math/frexp (math/abs v)))
  (def m (math/floor (* frac 16777216)))
  (def sign (if (< v 0) (blshift 1 31) 0))
  (def raw (bor sign (blshift (+ e 126) 23) (- m 8388608)))
  (def bits (if (< raw 0) (+ raw 4294967296) raw))
  [(mod bits 256) (mod (math/floor (/ bits 256)) 256)
   (mod (math/floor (/ bits 65536)) 256)
   (mod (math/floor (/ bits 16777216)) 256)])

(def one-grid
  (let [b (buffer/new 0)
        sample [12.0 200.0 900.0 30.0 -0.006]]
    (each v sample (each byte (f32-bytes v) (buffer/push-byte b byte)))
    b))

(def climate-read (tile/read one-grid [1 1 5] @{:has_climate true}))
(def sampled (tile/sample climate-read 0 0))

(check "the reader and the classifier use the same five channel names"
       (deep= (sort (map string tile/channels))
              (sort (map string [:temperature :temperature-seasonality
                                 :precipitation :precipitation-variability
                                 :lapse-rate]))))

(check "a sampled cell carries exactly the channels the classifier validates"
       (bio/valid-climate? (sampled :values)))

(check "a sampled cell classifies"
       (bio/classified? (bio/classify (sampled :values) 60 sea)))

(check "the sampled temperature is the value the producer wrote"
       (= 12.0 (get (sampled :values) :temperature)))

(check "an absent read yields :unknown, never a biome"
       (let [absent (tile/read nil nil @{:has_climate false})]
         (and (bio/unknown? (bio/classify (get absent :values) 60 sea))
              (= :unknown (bio/biome-of (bio/classify nil 60 sea))))))

#
# --- Summary ------------------------------------------------------------
#

(if (zero? failures)
  (print "\nclimate biome tests: pass")
  (do (printf "\n%d check(s) failed" failures)
      (error "climate biome tests failed")))
