# Headless dry spawn safety and bounded search checks.
(import ../src/world :as world)
(import ../src/worldgen :as worldgen)
(import ../src/player :as player)
(import ../src/spawn :as spawn)
(import ../src/scenic-worldgen :as scenic)
(import ../src/world-provider :as provider)

(defn flat [cx cz surface water?]
  (let [ch (world/chunk-new cx cz)]
    (for z 0 16 (for x 0 16
      (for y 0 world/chunk-y
        (world/chunk-set ch x y z
          (cond (<= y surface) world/block-stone
                (and water? (<= y 28)) world/block-water
                world/block-air)))))
    ch))

(defn check-position [w position]
  (assert position "expected safe position")
  (let [x (position 0) y (position 1) z (position 2)]
    (assert (> y 29) "spawn feet must stand above sea")
    (assert (not (player/box-collides? w x y z)) "player overlaps solid")
    (let [hw player/half-width
          x0 (math/floor (- x hw)) x1 (math/floor (+ x hw))
          z0 (math/floor (- z hw)) z1 (math/floor (+ z hw))]
      (for bx x0 (+ x1 1)
        (for bz z0 (+ z1 1)
          (assert (world/world-get-chunk w (world/world-to-chunk-coord bx)
                                            (world/world-to-chunk-coord bz))
                  "footprint must be loaded")
          (assert (world/block-solid? (world/world-get-block w bx (- y 1) bz))
                  "whole footprint needs support")
          (for by (math/floor y) (+ (math/floor (+ y player/player-height)) 1)
            (assert (= (world/world-get-block w bx by bz) world/block-air)
                    "body must contain only air")))))))

(let [w (world/world-new)]
  (world/world-put-chunk w (flat 0 0 20 true))
  (assert (nil? (spawn/find-dry-spawn w {:radius 2})) "ocean must exhaust")
  (let [s (spawn/search-new {:radius 2})]
    (spawn/search-step s w 1)
    (assert (= (s :examined) 1) "one step examines one candidate")
    (assert (= (s :status) :searching) "ocean must not fabricate land")
    (spawn/search-step s w 12)
    (assert (= (s :status) :exhausted) "bounded ocean search must finish")
    (assert (= (s :examined) 13) "radius two has 13 candidates")))
(print "ocean exhaustion: ok")

# Exactly one visit per Manhattan-grid coordinate, including the lower half.
(let [w (world/world-new)
      s (spawn/search-new {:radius 3})
      seen @{}]
  (while (= (s :status) :searching)
    (let [dx (s :dx)
          ring (s :ring)
          dz (* (if (get s :lower) -1 1) (- ring (math/abs dx)))
          key [dx dz]]
      (assert (not (get seen key)) "duplicate ring candidate")
      (put seen key true)
      (spawn/search-step s w 1)))
  (assert (= (s :examined) 25) "radius three has 25 unique candidates")
  (for dz -3 4
    (for dx -3 4
      (when (<= (+ (math/abs dx) (math/abs dz)) 3)
        (assert (get seen [dx dz]) "missing Manhattan ring candidate")))))
(print "Manhattan rings cover all signed coordinates: ok")

(let [w (world/world-new)
      ch (flat 0 -1 30 false)]
  (world/world-put-chunk w ch)
  # The only loaded dry column lies directly south of the origin.
  (assert (nil? (spawn/candidate-safe? w 0 0)) "origin is unloaded")
  (let [position (spawn/find-dry-spawn w {:radius 1})]
    (check-position w position)
    (assert (= (position 2) -0.5) "south-only land must be found")))
(print "negative-Z-only land: ok")

(let [w (world/world-new)
      ch (flat 0 0 30 false)]
  (world/world-put-chunk w ch)
  # At the shoreline x=0 supports an entire box only if the neighbouring
  # column is also dry. Put water at x=1 and force the search to that centre.
  (for z 0 16
    (for y 21 29 (world/chunk-set ch 1 y z world/block-water))
    (for y 29 31 (world/chunk-set ch 1 y z world/block-air)))
  (assert (nil? (spawn/candidate-safe? w 1 8)) "shore column has no support")
  (check-position w (spawn/candidate-safe? w 2 8))
  (assert (nil? (spawn/candidate-safe? w 16 8)) "unloaded seam cannot be safe"))
(print "shoreline and missing chunks: ok")

(let [w (world/world-new)
      ch (flat 0 0 30 false)]
  (world/world-put-chunk w ch)
  # Obstruct the column at every possible feet height; an adjacent column
  # remains a valid deterministic alternative.
  (for y 31 world/chunk-y (world/chunk-set ch 0 y 0 world/block-stone))
  (assert (nil? (spawn/candidate-safe? w 0 0))
          "obstruction cannot be treated as clear headroom")
  (check-position w (spawn/find-dry-spawn w {:radius 1})))
(print "headroom and alternative: ok")

# A clear space above leaves is not a playable ground spawn. If leaves occupy
# the ground-level headroom too, the search must move to a nearby grass column.
(let [w (world/world-new)
      ch (flat 0 0 40 false)]
  (world/world-put-chunk w ch)
  (world/chunk-set ch 8 42 8 world/block-leaves)
  (world/chunk-set ch 8 43 8 world/block-leaves)
  (assert (nil? (spawn/candidate-safe? w 8 8))
          "canopy cannot count as ground or clear body space")
  (let [s (spawn/find-dry-spawn w {:origin-x 8 :origin-z 8 :radius 2})]
    (check-position w s)
    (assert (= 41 (get s 1)) "fallback feet must stand on grass")
    (assert (not (and (= 8.5 (get s 0)) (= 8.5 (get s 2))))
            "search must step around obstructed tree"))
  (world/chunk-set ch 8 42 8 world/block-air)
  (world/chunk-set ch 8 43 8 world/block-air)
  (world/chunk-set ch 8 48 8 world/block-wood)
  (assert (= 41 (get (spawn/candidate-safe? w 8 8) 1))
          "a walkable grass floor wins over a high wood support")
  (world/chunk-set ch 8 48 8 world/block-leaves)
  (assert (= 41 (get (spawn/candidate-safe? w 8 8) 1))
          "a walkable grass floor wins over a high leaf support"))
(print "tree canopy never becomes spawn ground: ok")

(let [w (world/world-new)]
  (world/world-put-chunk w (flat -1 0 31 false))
  (world/world-put-chunk w (flat 0 0 31 false))
  (check-position w (spawn/candidate-safe? w -1 0))
  (check-position w (spawn/candidate-safe? w 0 0))
  (let [a (spawn/find-dry-spawn w {:origin-x -1 :radius 2})
        b (spawn/find-dry-spawn w {:origin-x -1 :radius 2})]
    (assert (= (tuple; a) (tuple; b)) "search order must be deterministic")
    (assert (= (a 0) -0.5) "origin should be first candidate")))
(print "negative seam and deterministic order: ok")

(let [w (world/world-new)]
  (for cz -2 3 (for cx -2 3 (worldgen/generate-chunk w cx cz 4)))
  (check-position w (spawn/find-dry-spawn w {:radius 24})))
(print "seed-4 procedural spawn: ok")

#
# --- Configured sea level ------------------------------------------------
#
# The waterline is OPTIONAL and defaults to the shipped 28, so every case above
# still describes a session that names no sea level at all. Everything below
# changes only the option, never the voxels: one fixture, two waterlines.
# Nothing here may fabricate land -- a waterline moves the band a player may be
# seated in, it does not create ground.

(defn check-position-above
  ``The same guarantees as `check-position`, against a CONFIGURED waterline.
  The existing checker is deliberately left at sea level 28: it describes the
  default path, which this option must not disturb.``
  [w position sea]
  (assert position "expected safe position")
  (let [x (position 0) y (position 1) z (position 2)]
    # sea+1 is INCLUSIVE: the generator fills water only where the ground is
    # BELOW the waterline, so a column whose surface sits exactly at sea level is
    # dry sand and its feet are legal at sea+1.
    (assert (>= y (+ 1 sea)) "feet must stand at or above the configured waterline")
    (assert (not (player/box-collides? w x y z)) "player overlaps solid")
    (let [hw player/half-width
          x0 (math/floor (- x hw)) x1 (math/floor (+ x hw))
          z0 (math/floor (- z hw)) z1 (math/floor (+ z hw))]
      (for bx x0 (+ x1 1)
        (for bz z0 (+ z1 1)
          (assert (world/world-get-chunk w (world/world-to-chunk-coord bx)
                                            (world/world-to-chunk-coord bz))
                  "footprint must be loaded")
          (def support (world/world-get-block w bx (- y 1) bz))
          # The spawn-ground rule is not "solid": a canopy and a trunk are solid.
          (assert (or (= support world/block-stone) (= support world/block-dirt)
                      (= support world/block-grass) (= support world/block-sand)
                      (= support world/block-snow))
                  "whole footprint needs non-tree support")
          (for by (math/floor y) (+ (math/floor (+ y player/player-height)) 1)
            (assert (= (world/world-get-block w bx by bz) world/block-air)
                    "body must contain only air")))))))

# A low, DRY world: surface 20 is real land, just below the shipped waterline.
# The default is what rejects it -- passing :sea-level 0 admits the same voxels.
(let [w (world/world-new)]
  (world/world-put-chunk w (flat 0 0 20 false))
  (assert (nil? (spawn/candidate-safe? w 0 0))
          "default waterline rejects a surface below it")
  (assert (nil? (spawn/find-dry-spawn w {:radius 2}))
          "the default search reports no dry land on a low dry world")
  (assert (nil? (spawn/find-dry-spawn w {:radius 2 :sea-level 28}))
          "an explicit 28 must equal the default exactly")
  (let [p (spawn/find-dry-spawn w {:radius 2 :sea-level 0})]
    (check-position-above w p 0)
    (assert (= 21 (get p 1)) "feet must stand on the surface, not above it")
    (assert (= (tuple; p) (tuple; (spawn/find-dry-spawn w {:radius 2 :sea-level 0})))
            "an explicit waterline must stay deterministic")))
(print "low sea level admits dry low terrain the default rejects: ok")

# The same contract at the LOWEST legal waterline, on a flat surface of 5 -- a
# world a negative height-offset can actually produce. sea 0 admits it (feet 6:
# one block above the surface, which is itself above the waterline of 0), and
# the default 28 refuses it because the whole column is underwater terrain.
(let [w (world/world-new)]
  (world/world-put-chunk w (flat 0 0 5 false))
  (assert (nil? (spawn/find-dry-spawn w {:radius 2}))
          "the default 28 rejects a surface of 5")
  (assert (nil? (spawn/find-dry-spawn w {:radius 2 :sea-level 28}))
          "an explicit 28 rejects a surface of 5 exactly as the default does")
  (let [p (spawn/find-dry-spawn w {:radius 2 :sea-level 0})]
    (check-position-above w p 0)
    (assert (= 6 (get p 1)) "feet stand one block above a surface-5 floor")
    (assert (= [0.5 6 0.5] [(get p 0) (get p 1) (get p 2)])
            "the origin column is found first")
    (assert (= (tuple; p) (tuple; (spawn/find-dry-spawn w {:radius 2 :sea-level 0})))
            "a surface-5 world must stay deterministic")))
(print "sea level 0 admits a surface of 5; the default 28 does not: ok")

# A RAISED waterline excludes a floor at or below it. Surface 40 means the only
# possible feet height is 41, so 38 admits and 40 must not -- the boundary is
# worth pinning because an off-by-one here seats the player in the waterline.
(let [w (world/world-new)]
  (world/world-put-chunk w (flat 0 0 40 false))
  (let [admitted (spawn/find-dry-spawn w {:radius 1 :sea-level 38})]
    (check-position-above w admitted 38)
    (assert (= 41 (get admitted 1)) "feet stand one block above the surface"))
  # A floor exactly AT the waterline is DRY: `worldgen/column-block` tests the
  # height arm before the water arm, so ground at sea level is sand and the feet
  # one block above it are legal. This is the boundary the inclusive bound fixes.
  (assert (= 41 (get (spawn/candidate-safe? w 0 0 40) 1))
          "ground at the waterline is dry, so feet at sea+1 are legal")
  (assert (= 41 (get (spawn/find-dry-spawn w {:radius 1 :sea-level 40}) 1))
          "the search seats the player one block above a waterline-level floor")
  # One higher and the same voxels are underwater terrain: nothing to stand on.
  (assert (nil? (spawn/find-dry-spawn w {:radius 1 :sea-level 41}))
          "a waterline above the terrain finds no dry land")
  (assert (nil? (spawn/find-dry-spawn w {:radius 1 :sea-level 60}))
          "a waterline above the terrain finds nothing rather than inventing land")
  # Arrays compare by identity, so the default and the explicit 28 are compared
  # as values: the same position, not merely two equal-looking ones.
  (assert (= (tuple; (spawn/candidate-safe? w 0 0))
             (tuple; (spawn/candidate-safe? w 0 0 28)))
          "the optional argument must default to 28"))
(print "waterline boundary is inclusive at sea+1: ok")

# A REAL decorated chunk, not a hand-placed canopy: fill and `decorate!` the
# same way the engine does, then require the search to keep its rules against
# actual conifers -- no canopy floor, no trunk floor, no obstructed footprint.
(defn decorated [cx cz seed]
  (let [ch (world/chunk-new cx cz)]
    # DENSITY 100 is the production maximum: every lattice cell that passes the
    # slope/tree-line gates grows a conifer, so the fixture is the WORST case for
    # spawn rather than a lucky half-empty forest.
    (scenic/generate-into (ch :blocks) cx cz (fn [wx wz] 40)
                          {:seed seed :sea-level 28 :density 100})
    ch))

(let [w (world/world-new)]
  (for cz -1 2 (for cx -1 2 (world/world-put-chunk w (decorated cx cz 7))))
  (def ch (world/world-get-chunk w 0 0))
  # The fixture is only worth asserting against if it really grew a forest.
  (var leaves 0)
  (for z 0 world/chunk-z
    (for x 0 world/chunk-x
      (when (not= world/block-air (world/chunk-get ch x 41 z))
        (++ leaves))))
  (assert (pos? leaves) "the decorated fixture must obstruct ground-level headroom")
  # No column whose 41 layer is canopy may be reported with feet at 41.
  (for z 0 world/chunk-z
    (for x 0 world/chunk-x
      (when (not= world/block-air (world/chunk-get ch x 41 z))
        (def p (spawn/candidate-safe? w x z))
        (assert (or (nil? p) (not= 41 (get p 1)))
                "canopy must never be a spawn floor"))))
  (let [p (spawn/find-dry-spawn w {:radius 3})]
    (check-position-above w p 28)
    (assert (= (tuple; p) (tuple; (spawn/find-dry-spawn w {:radius 3})))
            "decorated search must stay deterministic")))
(print "decorated conifer chunks keep the spawn rules: ok")

# The option is validated ONCE, at construction, so a bad waterline fails
# immediately instead of halfway through a bounded search.
(defn raises? [thunk]
  (not (get (protect (thunk)) 0)))

(let [w (world/world-new)]
  (world/world-put-chunk w (flat 0 0 40 false))
  (assert (raises? (fn [] (spawn/search-new {:sea-level 28.5})))
          "a fractional waterline must be refused")
  (assert (raises? (fn [] (spawn/search-new {:sea-level -1})))
          "a negative waterline must be refused")
  (assert (raises? (fn [] (spawn/search-new {:sea-level (/ 0 0)})))
          "a NaN waterline must be refused")
  (assert (raises? (fn [] (spawn/search-new {:sea-level (/ 1 0)})))
          "an infinite waterline must be refused")
  (assert (raises? (fn [] (spawn/search-new {:sea-level (+ 1 spawn/sea-level-max)})))
          "a waterline above the physical search ceiling must be refused")
  (assert (= (- world/chunk-y 2) spawn/sea-level-max)
          "generic spawn bounds follow build height")
  (assert (= 129 ((spawn/search-new {:sea-level 129}) :sea-level))
          "imported maps may exceed the procedural UI waterline limit")
  (assert (raises? (fn [] (spawn/search-new {:sea-level "28"})))
          "a non-numeric waterline must be refused")
  (assert (raises? (fn [] (spawn/find-dry-spawn w {:radius 1 :sea-level 28.5})))
          "find-dry-spawn must validate the option it forwards")
  (assert (raises? (fn [] (spawn/candidate-safe? w 0 0 28.5)))
          "the optional argument must be validated too")
  # The edges of the accepted band are accepted, not merely tolerated.
  (assert (= 0 ((spawn/search-new {:sea-level 0}) :sea-level))
          "0 is a legal waterline")
  (assert (= spawn/sea-level-max
             ((spawn/search-new {:sea-level spawn/sea-level-max}) :sea-level))
          "the scan ceiling itself is a legal waterline"))
(print "invalid sea levels are refused at construction: ok")

# sea level 0 is the LOWEST legal waterline, so its inclusive lower bound is the
# bottom of the world: feet at 1 above a floor of 0 must be admissible. Built
# through the real generator, not a synthetic column, so the water rule that the
# bound depends on is the one the engine actually applies.
(let [w (world/world-new)
      ch (world/chunk-new 0 0)
      h (buffer/new-filled 256 0)]
  (for i 0 256 (put h i 4))          # the terrain band's minimum height
  (worldgen/generate-from-heights-scenic (ch :blocks) 0 0 h {:sea-level 0})
  (world/world-put-chunk w ch)
  (def p (spawn/candidate-safe? w 0 0 0))
  (assert p "sea level 0 must admit the lowest terrain band")
  (assert (= 5 (get p 1)) "feet stand one block above minimum-height ground")
  (check-position-above w p 0)
  # And the floor of the world itself is still never a spawn: feet at 1 needs
  # ground at 0, which the generator only produces as bedrock under real terrain.
  (assert (>= (get p 1) 1) "feet may never sit below y=1"))
(print "sea level 0 admits the lowest terrain band: ok")

#
# --- The OPT-IN ranked view policy --------------------------------------
#
# `:enclosed-v1` exists so a NEW game can open inside a valley looking outward,
# instead of at whichever dry column the ring walk reached first. It is opt-in
# precisely because the default search is what every existing world already
# spawned with: changing it silently would move players in saves they already
# have.
#
# Everything below is synthetic terrain built column by column, so each
# assertion says what shape was measured rather than what a generator happened to
# emit that day. No window, no GPU, no model.
#
(print "\nranked view policy:")

(defn ensure-chunk! [w x z]
  # Only when ABSENT: a fresh chunk overwrites one already holding columns, which
  # would erase every earlier write and make a "bowl" a blank world.
  (def cx (world/world-to-chunk-coord x))
  (def cz (world/world-to-chunk-coord z))
  (unless (world/world-get-chunk w cx cz)
    (world/world-put-chunk w (world/chunk-new cx cz))))

# One column filled to `top`: water below the waterline, solid up to `top`, air
# above -- the generator's own layering, so the waterline rule applies here too.
(defn column! [w x z top &opt sea]
  (def sea-y (or sea 0))
  (ensure-chunk! w x z)
  (for y 0 world/chunk-y
    (world/world-set-block w x y z
      (cond
        (< y sea-y) world/block-water
        (<= y top) world/block-grass
        world/block-air))))

# A bowl: flat floor inside `r0`, walls rising outward -- the valley case.
(defn bowl! [w cx cz r0 rise &opt sea]
  (for dz -34 35
    (for dx -34 35
      (def d (math/sqrt (+ (* dx dx) (* dz dz))))
      (def top (if (<= d r0) 30 (+ 30 (* rise (math/floor (/ (- d r0) 2))))))
      (column! w (+ cx dx) (+ cz dz) (min top 200) sea))))

# A ridge: one wall along +x, everything else open. Enclosure must be REFUSED.
(defn ridge! [w cx cz &opt sea]
  (for dz -34 35
    (for dx -34 35
      (column! w (+ cx dx) (+ cz dz) (if (>= dx 10) (+ 60 dx) 30) sea))))

# A flat plate: safe, walkable and open in every direction.
(defn plate! [w cx cz &opt sea]
  (for dz -34 35
    (for dx -34 35
      (column! w (+ cx dx) (+ cz dz) 30 sea))))

(defn view-world [build]
  (def w (world/world-new))
  (build w)
  w)

(let [w (view-world |(bowl! $ 0 0 12 3))
      r (spawn/view-spawn w {:origin-x 0 :origin-z 0 :radius 6
                             :sea-level 0 :view-policy :enclosed-v1})]
  (assert r "a valley must produce a seat")
  (assert (r :enclosure?) "the bowl must be reported as enclosing")
  (assert (not (r :fallback?)) "an enclosed seat is not a fallback")
  (assert (> ((r :evidence) :rising) 4) "most azimuths must rise inside a bowl")
  (assert (number? (r :yaw)) "the seat must carry a measured yaw")
  (assert (< (r :pitch) 0) "the opening view looks slightly down")
  (print "a bowl is reported as enclosing: ok"))

# The seat is inside the bowl, not on its rim: a ranked search must not pick a
# safe column on the ridge just because the ring walk reached it first.
(let [w (view-world |(bowl! $ 0 0 12 3))
      r (spawn/view-spawn w {:origin-x 0 :origin-z 0 :radius 6
                             :sea-level 0 :view-policy :enclosed-v1})
      pos (r :position)
      d (math/sqrt (+ (math/pow (- (get pos 0) 0.5) 2)
                      (math/pow (- (get pos 2) 0.5) 2)))]
  (assert (< d 7) "the ranked seat stays on the valley floor")
  (print "the ranked seat is on the floor, not the rim: ok"))

(let [w (view-world |(ridge! $ 0 0))
      r (spawn/view-spawn w {:origin-x 0 :origin-z 0 :radius 6
                             :sea-level 0 :view-policy :enclosed-v1})]
  (assert r "a ridge still yields a safe seat")
  (assert (not (r :enclosure?)) "a one-sided ridge is NOT a valley")
  (assert (r :fallback?) "an unenclosed seat is reported as a fallback")
  (print "a ridge is seated but never called enclosed: ok"))

(let [w (view-world |(plate! $ 0 0))
      r (spawn/view-spawn w {:origin-x 0 :origin-z 0 :radius 4
                             :sea-level 0 :view-policy :enclosed-v1})]
  (assert (and r (not (r :enclosure?)) (r :fallback?))
          "flat open ground is safe, unenclosed and honest about it")
  (print "open ground falls back rather than claiming a valley: ok"))

# UNKNOWN IS NOT FLAT. One chunk of plate surrounded by nothing: a seat near the
# unloaded edge must be refused, because "no chunk" is not evidence of open ground.
(let [w (world/world-new)]
  (for z 0 16 (for x 0 16 (column! w x z 30 0)))
  (def r (spawn/view-spawn w {:origin-x 8 :origin-z 8 :radius 4
                              :sea-level 0 :view-policy :enclosed-v1
                              :min-edge 2}))
  (assert (nil? r) "an unloaded edge must refuse the seat, not assume flatness")
  (print "unloaded terrain is unknown, never air: ok"))

# Narrow peak: one raised column with everything falling away is emphatically not
# an enclosed seat.
(let [w (view-world (fn [w] (plate! w 0 0) (column! w 0 0 90 0)))
      r (spawn/view-spawn w {:origin-x 0 :origin-z 0 :radius 3
                             :sea-level 0 :view-policy :enclosed-v1})]
  (assert (or (nil? r) (not (r :enclosure?)))
          "a narrow peak is never an enclosed seat"))
(print "a narrow peak is refused or unenclosed: ok")

# Ocean: no safe column at all, so the answer is nil -- never a fabricated seat.
(let [w (world/world-new)]
  (for z 0 16 (for x 0 16 (column! w x z 10 28)))
  (assert (nil? (spawn/view-spawn w {:origin-x 8 :origin-z 8 :radius 3
                                     :view-policy :enclosed-v1}))
          "ocean yields no seat under the ranked policy either")
  (print "ocean still exhausts under the policy: ok"))

# DETERMINISM AND BUDGET. The same world sliced differently must reach the same
# seat: the cursor only advances on a COMPLETE candidate, so the answer cannot
# depend on where a frame boundary fell.
(let [w (view-world |(bowl! $ 0 0 10 3))
      opts {:origin-x 0 :origin-z 0 :radius 5 :sea-level 0
            :view-policy :enclosed-v1}
      whole (do (def s (spawn/search-new opts))
                (spawn/search-step s w 65536)
                s)
      sliced (do (def s (spawn/search-new opts))
                 # Awkward slices, including ones too small to score a single
                 # candidate: those must spend nothing and advance nothing.
                 (each b [1 7 33 100 5 1 1000 65536]
                   (spawn/search-step s w b))
                 s)]
  # Janet arrays compare by IDENTITY, so the components are compared: a test that
  # used `=` here would fail on two equal positions, which says nothing about
  # determinism.
  (assert (deep= (whole :position) (sliced :position))
          "the same world yields the same seat under any slicing")
  (assert (= (whole :yaw) (sliced :yaw)) "and the same yaw")
  (assert (= (whole :examined) (sliced :examined))
          "and examined the same columns")
  (print "ranked search is slicing-independent: ok"))

# A slice smaller than one candidate's cost cannot buy a candidate, and must not
# half-score one either. But it MUST make eventual progress: a caller feeding the
# smallest possible budget used to spin forever with `examined = 0`, which reads
# exactly like "still working". The carry is what turns 1-per-call into progress.
(let [w (view-world |(plate! $ 0 0))
      s (spawn/search-new {:origin-x 0 :origin-z 0 :radius 4 :sea-level 0
                           :view-policy :enclosed-v1})]
  (def cost (spawn/candidate-cost s))
  (assert (= 41 cost) "the default candidate cost is reported honestly")
  (spawn/search-step s w 1)
  (assert (zero? (s :examined))
          "a sub-candidate budget must not consume a column")
  (assert (= :searching (s :status)) "and must not finish the search")
  # ONE UNIT AT A TIME, FOREVER: the exact starvation case. It must advance.
  (for _i 0 (+ cost 2) (spawn/search-step s w 1))
  (assert (pos? (s :examined))
          "budget 1 per call must eventually examine a column, never starve")
  (print "a sub-candidate budget still makes progress: ok"))

# The carry is CAPPED, so a thousand calls of 1 cannot bank a thousand units and
# then spend them in one frame: the budget still bounds the work each call does.
(let [w (view-world |(plate! $ 0 0))
      s (spawn/search-new {:origin-x 0 :origin-z 0 :radius 4 :sea-level 0
                           :view-policy :enclosed-v1})
      cost (spawn/candidate-cost s)]
  (for _i 0 500 (spawn/search-step s w 1))
  (assert (<= (s :credit) cost)
          "the carried credit never exceeds one candidate")
  (def before (s :examined))
  (spawn/search-step s w 1)
  (assert (<= (- (s :examined) before) 1)
          "one unit of budget cannot buy more than one carried candidate")
  (print "the carried credit is capped at one candidate: ok"))

# Option validation fails at construction, before the loader walks a column.
(assert (try (do (spawn/search-new {:view-policy :nonsense}) false)
             ([e] true))
        "an unknown view policy is refused")
(assert (try (do (spawn/search-new {:view-policy :enclosed-v1
                                    :min-edge 0}) false)
             ([e] true))
        "a zero edge cushion is refused")
(assert (try (do (spawn/search-new {:view-policy :enclosed-v1
                                    :sight-radii @[]}) false)
             ([e] true))
        "an empty sight-radius list is refused")
(print "bad view options are refused at construction: ok")

# THE LEGACY PATH IS UNTOUCHED by any of the above: no policy means no extra
# keys, and the same first-safe seat the old walk produced.
(let [w (view-world |(plate! $ 0 0))
      plain (spawn/search-new {:origin-x 0 :origin-z 0 :radius 4 :sea-level 0})]
  (assert (nil? (plain :view-policy)) "no policy is stored by default")
  (assert (nil? (plain :yaw)) "and no yaw is invented for legacy callers")
  (spawn/search-step plain w 100)
  (assert (= :found (plain :status)) "the legacy walk still finds a seat")
  (assert (nil? (plain :fallback?)) "and reports no fallback flag")
  (print "the legacy search is unchanged: ok"))

# FEET STAND ON MEASURED GROUND. The ranked policy compares neighbouring ground
# against `feet - 1`, so that identity has to hold for a real seat: the block under
# the seeded feet must be supporting ground, and the block AT the feet must be air.
# A ranking computed against a wrong base would accept a wall and call it a floor.
(let [w (view-world |(bowl! $ 0 0 12 3))
      r (spawn/view-spawn w {:origin-x 0 :origin-z 0 :radius 6
                             :sea-level 0 :view-policy :enclosed-v1})
      pos (r :position)
      fx (math/floor (get pos 0))
      fy (get pos 1)
      fz (math/floor (get pos 2))]
  (assert (world/block-solid? (world/world-get-block w fx (- fy 1) fz))
          "the feet must stand on solid ground")
  (assert (= world/block-air (world/world-get-block w fx fy fz))
          "the block at the feet must be air")
  (assert (not (player/box-collides? w (get pos 0) fy (get pos 2)))
          "and the body above it must be clear")
  (print "the ranked seat stands on measured ground: ok"))

# EVIDENCE IS COUNTED, NOT DECLARED. A seat that scored has observed every sample
# it reports on, so `:unknown` is exactly the number of unreadable samples -- zero
# for a filled world -- and `:rising` cannot exceed the azimuth count.
(let [w (view-world |(bowl! $ 0 0 12 3))
      r (spawn/view-spawn w {:origin-x 0 :origin-z 0 :radius 6
                             :sea-level 0 :view-policy :enclosed-v1})
      ev (r :evidence)]
  (assert (= 0 (ev :unknown)) "a fully observed candidate reports zero unknowns")
  (assert (<= (ev :rising) (ev :azimuths))
          "rising azimuths cannot exceed the azimuth count")
  (assert (= 8 (ev :azimuths)) "all eight directions are scored")
  (print "evidence counts are real measurements: ok"))

# FAR-FIELD BOUNDS. A sight radius reaching past the loaded world must make those
# samples UNKNOWN, which refuses the candidate -- it must never be read as flat or
# as sea. This is the case a "bounds clone" would silently fake.
(let [w (world/world-new)]
  (for z 0 16 (for x 0 16 (column! w x z 30 0)))
  (def short (spawn/view-spawn w {:origin-x 8 :origin-z 8 :radius 2
                                  :sea-level 0 :view-policy :enclosed-v1
                                  :sight-radii @[2] :min-edge 1}))
  # The single-chunk plate is fully loaded across 16x16, so a 2-column reach
  # from the middle is observed -- the seat is safe, simply not enclosed.
  (assert (and short (not (short :enclosure?)))
          "a short fully-observed reach seats honestly")
  (def far (spawn/view-spawn w {:origin-x 8 :origin-z 8 :radius 2
                                :sea-level 0 :view-policy :enclosed-v1
                                :sight-radii @[40] :min-edge 1}))
  (assert (nil? far)
          "a sight radius past the loaded world refuses the seat, never fakes it")
  (print "far-field samples outside the loaded world are unknown: ok"))

# BUDGET IS CHARGED IN SAMPLES. One candidate costs at least `view-cost`, so a
# budget of exactly that advances exactly one column -- the property that keeps a
# per-frame slice a real bound on block reads.
(let [w (view-world |(plate! $ 0 0))
      s (spawn/search-new {:origin-x 0 :origin-z 0 :radius 4 :sea-level 0
                           :view-policy :enclosed-v1
                           :sight-radii @[1] :min-edge 1})]
  (spawn/search-step s w 16)          # 1 + 8 + 8 + 8*1 = 25 > 16
  (assert (zero? (s :examined)) "a budget below one candidate does nothing")
  (spawn/search-step s w 25)
  (assert (= 1 (s :examined)) "a budget of exactly one candidate advances one")
  (print "the budget is charged per column sample: ok"))

# THE FIRST FRAME FACES RISING GROUND. The yaw used to point at the LOWEST
# horizon, which is the intuition for a valley mouth and wrong for an opening
# frame: the lowest horizon can be open sky, a step down to a beach, or the loaded
# edge of a finite map -- the least terrain in the view. The direction that ROSE
# the most is the one backed by the most terrain.
#
# This fixture makes the two rules disagree decisively: a tall ridge to the NORTH
# (+z, ground at 90) against an open mouth to the SOUTH (-z, dropping to 20).
# Lowest-horizon faces the mouth at the sky; highest-relief must face the ridge.
(let [w (world/world-new)]
  (for dz -40 41
    (for dx -40 41
      (def d (math/sqrt (+ (* dx dx) (* dz dz))))
      (def top
        (cond
          (<= d 12) 30                              # valley floor
          (and (>= dz 16) (< (math/abs dx) 7)) 90   # N: a tall ridge
          (and (<= dz -16) (< (math/abs dx) 7)) 20  # S: the open mouth
          true 45))                                 # uniform walls
      (column! w dx dz top 0)))
  (def r (spawn/view-spawn w {:origin-x 0 :origin-z 0 :radius 6
                              :sea-level 0 :view-policy :enclosed-v1}))
  (assert r "the ridge-and-mouth bowl must produce a seat")
  (assert (r :enclosure?) "it is enclosed")
  (def yaw (r :yaw))
  (assert (> (math/sin yaw) 0.9)
          "the yaw must face the tall +z ridge, not the open -z mouth")
  (assert (pos? ((r :evidence) :focus-rise))
          "the faced direction must rise above the seat, not be sky")
  (print "the first frame faces rising ground, not the open mouth: ok"))

# The property bought here is "the opening view is backed by real terrain", NOT
# "the sightline is blocked beyond the sample distance". A bounded horizon of 32
# columns cannot promise that, and claiming so would be the kind of guarantee
# nobody verified. `:focus-rise` is the evidence the claim rests on.
(let [w (view-world |(bowl! $ 0 0 12 3))
      r (spawn/view-spawn w {:origin-x 0 :origin-z 0 :radius 6
                             :sea-level 0 :view-policy :enclosed-v1})]
  (assert (> ((r :evidence) :focus-rise) 0)
          "the opening view is backed by measured relief")
  (print "the opening view is backed by measured relief: ok"))

(print "spawn tests: all passed")
