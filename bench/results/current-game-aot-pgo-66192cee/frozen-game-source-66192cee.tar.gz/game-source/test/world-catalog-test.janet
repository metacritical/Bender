# Standalone, headless safe-slot persistence tests.
(import ../src/world :as world)
(import ../src/world-seed :as seed)
(import ../src/world-catalog :as catalog)
(import ../src/region :as region)
(import ../src/terrain-cache :as terrain-cache)
(import ../src/terrain-integrity :as integrity)
(import ../src/terrain-runtime :as runtime)
(import ../src/world-provider :as provider)

(def root "/tmp/trinecraft-world-catalog-tests")
(defn reject [f fragment]
  (def message (try (do (f) nil) ([e] (string e))))
  (assert message)
  (assert (string/find fragment message) message))
(defn write-raw [path text]
  (def f (file/open path :wb))
  (assert f)
  (file/write f text)
  (file/close f))
(defn read-raw [path]
  (def f (file/open path :rb))
  (assert f)
  (def text (file/read f :all))
  (file/close f)
  text)
(defn replace-once [path old new]
  (def raw (string (read-raw path)))
  (assert (string/find old raw))
  (write-raw path (string/replace old new raw)))
(defn remove-tree [path]
  (when (= :directory (os/lstat path :mode))
    (each child (os/dir path) (remove-tree (string path "/" child))))
  (os/rm path))
(defn prepare-root []
  (when (os/lstat root) (remove-tree root))
  (os/mkdir root))
(prepare-root)
(def world (world/world-new))
(def parsed (seed/parse-seed-input "mountains"))
(put world :seed (get parsed :value))
(def ch (world/chunk-new -2 5))
(world/chunk-set ch 15 252 15 world/block-grass)
(world/world-put-chunk world ch)
(def player {:pos [3.25 253.0 -7.5] :yaw 0.5 :pitch -0.25 :flying false})
(def options {:name "Alpine 🌲" :seed parsed :world world :player player :settings {}})
(def id (catalog/create-slot root options))
(assert (catalog/safe-id? id))
(assert (= 32 (length id)))
(assert (= 1 (length (catalog/list-slots root))))
(def dir (string root "/" id))
(def manifest-path (string dir "/manifest.janet"))
(defn region-path-of [m]
  (string dir "/" (get m :snapshot) "/world.trcr"))
(def region-path (region-path-of (catalog/load-manifest root id)))
(reject (fn [] (catalog/create-slot root {:name "Empty" :seed parsed :player player}))
        "built world")
(def blank (world/world-new))
(put blank :seed (get parsed :value))
(reject (fn [] (catalog/create-slot root {:name "Empty" :seed parsed :player player
                                          :world blank})) "built world")
(assert (= :file (os/lstat manifest-path :mode)))
(assert (= 2 (get (region/region-info region-path) :version)))
(def loaded (catalog/load-slot root id))
(assert (= (get parsed :value) (get (get loaded :world) :seed)))
(assert (= "mountains" (get (get (get loaded :manifest) :seed) :input)))
(assert (= "Alpine 🌲" (get (get loaded :manifest) :name)))
(assert (= 253.0 (get (get (get loaded :player) :pos) 1)))
(assert (= world/block-grass
           (world/chunk-get (world/world-get-chunk (get loaded :world) -2 5)
                            15 252 15)))
(assert (= 1 (get (get loaded :manifest) :settings-version)))
(assert (= {:height-scale 1.0 :height-offset 0 :sea-level 28 :forest-density 0}
           (get (get loaded :manifest) :settings)))
(assert (string/find "procedural:v1:h256" (get (get loaded :manifest) :settings-identity)))
(print "catalogue create/load and 256-high chunk: passed")

# Loading a slot is independent of current random or text seed and must never
# change its saved seed. Saving edits preserves the slot identity.
(world/chunk-set ch 1 200 2 world/block-water)
(def first-snapshot (get (catalog/load-manifest root id) :snapshot))
(def updated (catalog/save-slot root id world player {}))
(assert (not= first-snapshot (get updated :snapshot)))
(assert (= :file (os/lstat region-path :mode)))
(assert (= :file (os/lstat (region-path-of updated) :mode)))
(def region-path (region-path-of updated))
(assert (= id (get updated :id)))
(assert (= world/block-water
           (world/chunk-get (world/world-get-chunk
                             (get (catalog/load-slot root id) :world) -2 5)
                            1 200 2)))
(assert (= :ready (get (get (catalog/list-slots root) 0) :status)))
(def other-seed (seed/random-identity "\x01\x02\x03\x04"))
(def other (world/world-new))
(put other :seed (get other-seed :value))
(reject (fn [] (catalog/save-slot root id other player {})) "seed")
# Simulate a failed publication after a complete new snapshot was staged.
# A directory left behind without a manifest pointer must never replace the
# known-good generation; neither load nor catalogue discovery follows it.
(def interrupted (string dir "/0123456789abcdef0123456789abcdef"))
(os/mkdir interrupted)
(write-raw (string interrupted "/world.trcr") "partial")
(assert (= (get updated :snapshot) (get (catalog/load-manifest root id) :snapshot)))
(assert (= world/block-water
           (world/chunk-get (world/world-get-chunk
                             (get (catalog/load-slot root id) :world) -2 5)
                            1 200 2)))
(os/rm (string interrupted "/world.trcr"))
(os/rm interrupted)
# A manifest pointer to an unfinished snapshot must fail, not adopt old data
# under a new label or silently fall back to an unverifiable generation.
(def latest-manifest (read-raw manifest-path))
(replace-once manifest-path (get updated :snapshot) "0123456789abcdef0123456789abcdef")
(reject (fn [] (catalog/load-slot root id)) "directory")
(write-raw manifest-path latest-manifest)
(assert (= world/block-water
           (world/chunk-get (world/world-get-chunk
                             (get (catalog/load-slot root id) :world) -2 5)
                            1 200 2)))
# Repeated successful saves retain exactly current and immediately previous.
(var preceding (get updated :snapshot))
(for turn 0 4
  (def next (catalog/save-slot root id world player {}))
  (def live (get next :snapshot))
  (assert (not= preceding live))
  (assert (= :directory (os/lstat (string dir "/" live) :mode)))
  (assert (= :directory (os/lstat (string dir "/" preceding) :mode)))
  (assert (<= (length (filter catalog/safe-id? (os/dir dir))) 2))
  (set preceding live))
(def updated (catalog/load-manifest root id))
(def region-path (region-path-of updated))
# Unrecognized files and linked snapshot dirs are never deletion targets.
(def foreign (string dir "/0123456789abcdef0123456789abcdef"))
(os/mkdir foreign)
(write-raw (string foreign "/user-notes.txt") "keep")
(def linked-snapshot (string dir "/fedcba9876543210fedcba9876543210"))
(os/symlink (string dir "/" first-snapshot) linked-snapshot)
(catalog/save-slot root id world player {})
(assert (= "keep" (string (read-raw (string foreign "/user-notes.txt")))))
(assert (= :link (os/lstat linked-snapshot :mode)))
(os/rm linked-snapshot)
(os/rm (string foreign "/user-notes.txt"))
(os/rm foreign)
(def updated (catalog/load-manifest root id))
(def region-path (region-path-of updated))
(print "published snapshots bounded; foreign paths untouched: passed")
(print "interrupted snapshot preserves previous known-good world: passed")
(reject (fn [] (catalog/save-slot root id world player
                    {:settings {:sea-level 45}})) "cannot change generation settings")
(assert (= (get updated :snapshot) (get (catalog/load-manifest root id) :snapshot)))
(def custom-settings {:height-scale 1.5 :height-offset 8
                      :sea-level 45 :forest-density 20})
(def custom-id (catalog/create-slot root {:name "Custom" :seed parsed
                                          :world world :player player
                                          :settings custom-settings}))
(assert (= custom-settings (get (get (catalog/load-slot root custom-id) :manifest) :settings)))
(assert (not= (get (get (catalog/load-slot root custom-id) :manifest) :settings-identity)
              (get updated :settings-identity)))
(reject (fn [] (catalog/save-slot root custom-id world player {:settings {}}))
        "cannot change generation settings")
(print "custom provider controls persist and reject midworld changes: passed")
(remove-tree (string root "/" custom-id))
# Seed identity is part of save metadata, not reconstructed from the decimal
# seed. A text input and numeric input can resolve to the SAME :value yet retain
# distinct origin/kind for the UI. Random records retain exact entropy bytes.
(each [typed expected] [["+00000042" :numeric] ["spruce 世界" :text]]
  (def input-seed (seed/parse-seed-input typed))
  (def seed-world (world/world-new))
  (put seed-world :seed (get input-seed :value))
  (world/world-put-chunk seed-world (world/chunk-new 0 0))
  (def seed-id (catalog/create-slot root {:name "Seed roundtrip"
                                           :seed input-seed :world seed-world
                                           :player player}))
  (def recorded (get (get (catalog/load-slot root seed-id) :manifest) :seed))
  (assert (= 1 (get recorded :version)))
  (assert (= expected (get recorded :kind)))
  (assert (= typed (get recorded :input)))
  (assert (= (get input-seed :value) (get recorded :value)))
  (assert (= (get input-seed :canonical) (get recorded :canonical)))
  (remove-tree (string root "/" seed-id)))
(def random-seed (seed/random-identity "\x01\x02\x03\x04"))
(def random-world (world/world-new))
(put random-world :seed (get random-seed :value))
(world/world-put-chunk random-world (world/chunk-new 0 0))
(def random-id (catalog/create-slot root {:name "Random roundtrip"
                                           :seed random-seed :world random-world
                                           :player player}))
(def random-record (get (get (catalog/load-slot root random-id) :manifest) :seed))
(assert (= 1 (get random-record :version)))
(assert (= :random (get random-record :kind)))
(assert (nil? (get random-record :input)))
(assert (= "\x01\x02\x03\x04" (get random-record :entropy)))
(assert (= (get random-seed :value) (get random-record :value)))
(assert (= (get random-seed :canonical) (get random-record :canonical)))
(remove-tree (string root "/" random-id))
# Catalogue and menu count UTF-8 bytes, not code points. Both accept 256 bytes.
(each accepted [(string/repeat "a" 200) (string/repeat "a" 256)
                (string/repeat "🌲" 64)]
  (def accepted-seed (seed/parse-seed-input accepted))
  (def accepted-world (world/world-new))
  (put accepted-world :seed (get accepted-seed :value))
  (world/world-put-chunk accepted-world (world/chunk-new 0 0))
  (def accepted-id (catalog/create-slot root {:name "Bounded seed"
                                               :seed accepted-seed :world accepted-world
                                               :player player}))
  (assert (= accepted (get (get (get (catalog/load-slot root accepted-id) :manifest) :seed) :input)))
  (remove-tree (string root "/" accepted-id)))
(each rejected [(string/repeat "a" 257) (string/repeat "🌲" 65)]
  (def rejected-seed (seed/parse-seed-input rejected))
  (def rejected-world (world/world-new))
  (put rejected-world :seed (get rejected-seed :value))
  (world/world-put-chunk rejected-world (world/chunk-new 0 0))
  (reject (fn [] (catalog/create-slot root {:name "Too long"
                                              :seed rejected-seed :world rejected-world
                                              :player player})) "seed contract"))
(print "numeric, text, random and 256-byte seed metadata roundtrip: passed")
(print "catalogue save and identity pin: passed")

(each bad ["../traversal" "../../world" ".hidden" "G" "abc" "0000000000000000000000000000000/"]
  (assert (not (catalog/safe-id? bad)))
  (reject (fn [] (catalog/load-slot root bad)) "id"))
(reject (fn [] (catalog/create-slot root {:name "Learned" :seed parsed :world world
                                          :player player :provider :learned})) "provider")
(reject (fn [] (catalog/create-slot root {:name "" :seed parsed :world world
                                          :player player})) "name")
(reject (fn [] (catalog/create-slot root {:name "Bad" :seed parsed :world world
                                          :player {:pos [0 1 0] :yaw 0 :pitch 0 :flying "no"}})) "player")
(print "IDs, unavailable provider, and invalid metadata: passed")

(def saved-manifest (read-raw manifest-path))
(each [old new reason] [[":version 1" ":version 99" "version"]
                        [":height 256" ":height 64" "dimensions"]
                        [":profile :v2h256" ":profile :old" "provider"]
                        [":region-crc " ":unknown-key 1 :region-crc " "keys"]]
  (replace-once manifest-path old new)
  (reject (fn [] (catalog/load-slot root id)) reason)
  (write-raw manifest-path saved-manifest))
(write-raw manifest-path "{:version 1 :evil (do (os/rm \"/tmp/never\"))}")
(reject (fn [] (catalog/load-slot root id)) "keys")
(write-raw manifest-path "{} {}")
(reject (fn [] (catalog/load-slot root id)) "one inert form")
(write-raw manifest-path (string (buffer/new-filled 16385 65)))
(reject (fn [] (catalog/load-slot root id)) "oversized")
(write-raw manifest-path saved-manifest)
(replace-once manifest-path ":sea-level 28" ":sea-level 29")
(reject (fn [] (catalog/load-slot root id)) "identity")
(write-raw manifest-path saved-manifest)
(replace-once manifest-path ":settings-version 1" ":settings-version 99")
(reject (fn [] (catalog/load-slot root id)) "settings version")
(write-raw manifest-path saved-manifest)
(replace-once manifest-path ":forest-density 0" ":forest-density 101")
(reject (fn [] (catalog/load-slot root id)) "world setting")
(write-raw manifest-path saved-manifest)
(replace-once manifest-path ":height-scale 1" ":height-scale 0/0")
(reject (fn [] (catalog/load-slot root id)) "syntax")
(write-raw manifest-path saved-manifest)
(print "inert bounded manifest and future versions: passed")

(def saved-region (read-raw region-path))
(write-raw region-path "corrupt")
(reject (fn [] (catalog/load-slot root id)) "CRC")
(write-raw region-path saved-region)
(def sidecar (string region-path ".terrain.janet"))
(def sidecar-text (read-raw sidecar))
(write-raw sidecar "{:version 1}")
(reject (fn [] (catalog/load-slot root id)) "identity")
(write-raw sidecar sidecar-text)
(os/rm sidecar)
(reject (fn [] (catalog/load-slot root id)) "identity")
(write-raw sidecar sidecar-text)
(print "CRC and provenance fail closed: passed")

# Symlinked slot/root/manifest/region must never be traversed or interpreted.
(def linked (string root "/0123456789abcdef0123456789abcdef"))
(os/symlink dir linked)
(assert (= :incompatible (get (get (filter |(= "0123456789abcdef0123456789abcdef" (get $ :id))
                                     (catalog/list-slots root)) 0) :status)))
(reject (fn [] (catalog/load-slot root "0123456789abcdef0123456789abcdef")) "symlink")
(os/rm linked)
(os/rm manifest-path)
(os/symlink (string root "/nothing") manifest-path)
(reject (fn [] (catalog/load-slot root id)) "linked")
(os/rm manifest-path)
(write-raw manifest-path saved-manifest)
(os/rm region-path)
(os/symlink (string root "/nothing") region-path)
(reject (fn [] (catalog/load-slot root id)) "linked")
(os/rm region-path)
(write-raw region-path saved-region)
(print "symlinked slot and files rejected: passed")

(assert (= :ready (get (get (catalog/list-slots root) 0) :status)))
(assert (= world/block-grass
           (world/chunk-get (world/world-get-chunk (get (catalog/load-slot root id) :world) -2 5)
                            15 252 15)))
# Temporary Python learned-world artifact: a complete one-tile TDS3 fixture.
# No Python/GPU/model is involved: publication reads the existing wire protocol.
(def learned-src (string root "/learned-source"))
(os/mkdir learned-src)
(os/mkdir (string learned-src "/tiles"))
(def learned-ident (string/repeat "c" 64))
(def learned-provenance "{\"provider\": \"python-terrain-diffusion\", \"temporary\": true}\n")
(write-raw (string learned-src "/provenance.json") learned-provenance)
(write-raw (string learned-src "/manifest.janet")
           (string "{:format 3 :magic \"TDS3\" :identity \"" learned-ident
                   "\" :seed " (get parsed :value)
                   " :payload-bytes 256 :tile-bytes 308 :height-min 4 :height-max 252"
                   " :bounds [0 0 0 0] :origin [100000 100000]"
                   " :json-bytes " (length learned-provenance)
                   " :json-crc32 " (integrity/crc32 learned-provenance) "}"))
(write-raw (string learned-src "/manifest.json") "{\"format\": 3}\n")
(write-raw (string learned-src "/summary.json") "{\"tiles\": 1}\n")
(write-raw (string learned-src "/READY")
           (string "{\"ready\": true, \"temporary\": true, \"identity\": \""
                   learned-ident "\", \"tiles\": 1}\n"))
(def learned-tile (buffer/new-filled terrain-cache/tile-bytes 0))
(for i 0 4 (put learned-tile i (get "TDS3" i)))
(defn- put-le32 [buf offset value]
  (for i 0 4
    (put buf (+ offset i) (% (math/floor (/ value (math/pow 256 i))) 256))))
(put-le32 learned-tile 12 256)
(def learned-heights (buffer/new-filled 256 40))
(put-le32 learned-tile 16 (integrity/crc32 (string learned-heights)))
(for i 0 256 (put learned-tile (+ 52 i) (get learned-heights i)))
(write-raw (string learned-src "/tiles/0_0.tdh") learned-tile)
(def learned-world (world/world-new))
(put learned-world :seed (get parsed :value))
(def learned-ch (world/chunk-new 0 0))
(world/chunk-set learned-ch 0 40 0 world/block-grass)
(world/world-put-chunk learned-world learned-ch)
(def learned-opts {:name "Temporary Alpine" :seed parsed :world learned-world
                   :player player :provider :terrain-diffusion-python
                   :settings {:size 16 :sea-level 28 :profile "alpine"}
                   :artifact-dir learned-src})
(def inspected (catalog/inspect-artifact learned-src (get parsed :value)))
(assert (= learned-ident (get inspected :identity)))
(assert (= (get parsed :value) (get inspected :model-seed)))
(assert (= [0 0 0 0] (get inspected :bounds)))
(assert (= (runtime/sha256-file (string learned-src "/provenance.json"))
           (get inspected :provenance-sha256)))
(def learned-id (catalog/create-slot root learned-opts))
(def learned-loaded (catalog/load-slot root learned-id))
(assert (= :terrain-diffusion-python (get (get learned-loaded :manifest) :provider)))
(assert (= false (nil? (get learned-loaded :artifact-dir))))
(assert (= :directory (os/lstat (get learned-loaded :artifact-dir) :mode)))
(assert (= :file (os/lstat (string (get learned-loaded :artifact-dir) "/tiles/0_0.tdh") :mode)))
(assert (= learned-ident (get (get (get learned-loaded :manifest) :artifact) :identity)))
(assert (not= learned-src (get learned-loaded :artifact-dir)))
(assert (= :ready (get (first (filter |(= learned-id (get $ :id))
                                    (catalog/list-slots root))) :status)))
(print "temporary learned artifact is owned and loadable: passed")
(def learned-dir (string root "/" learned-id))
(def learned-first (get (get learned-loaded :manifest) :snapshot))
(def learned-save (catalog/save-slot root learned-id learned-world player {}))
(assert (not= learned-first (get learned-save :snapshot)))
(assert (= :file (os/lstat (string (get (catalog/load-slot root learned-id)
                                     :artifact-dir) "/tiles/0_0.tdh") :mode)))
(reject (fn [] (catalog/save-slot root learned-id learned-world player
                                 {:settings {:size 32 :sea-level 28 :profile "alpine"}}))
        "generation settings")
(def learned-owned (get (catalog/load-slot root learned-id) :artifact-dir))
(def owned-tile (string learned-owned "/tiles/0_0.tdh"))
(def tile-original (read-raw owned-tile))
(def corrupt (buffer/new-filled (length tile-original) 0))
(for i 0 (length tile-original) (put corrupt i (get tile-original i)))
(put corrupt 54 60)
(write-raw owned-tile corrupt)
(reject (fn [] (catalog/load-slot root learned-id)) "CRC")
(assert (= :incompatible
           (get (first (filter |(= learned-id (get $ :id))
                                (catalog/list-slots root))) :status)))
(write-raw owned-tile tile-original)
(def owned-manifest (string learned-owned "/manifest.janet"))
(def original-manifest (read-raw owned-manifest))
(replace-once owned-manifest ":format 3" ":format 4")
(reject (fn [] (catalog/load-slot root learned-id)) "format")
(write-raw owned-manifest original-manifest)
(def owned-ready (string learned-owned "/READY"))
(def original-ready (read-raw owned-ready))
(os/rm owned-ready)
(reject (fn [] (catalog/load-slot root learned-id)) "incomplete")
(write-raw owned-ready original-ready)
(assert (= :ready (get (first (filter |(= learned-id (get $ :id))
                                     (catalog/list-slots root))) :status)))
(print "learned save, tile tamper, malformed twin and cancellation fail closed: passed")
# Seed zero is a legal WORLD identity, but the Python model receives a pinned
# nonzero MODEL seed. The TDS3 manifest must name model seed while the slot and
# region provenance retain the world seed. Neither may be silently interchanged.
(def zero-seed (seed/parse-seed-input "0"))
(def zero-model-seed (get (provider/python-model-seed 0) 0))
(assert (= 0 (get zero-seed :value)))
(assert (not= 0 zero-model-seed))
(def zero-source (string root "/zero-source"))
(os/mkdir zero-source)
(os/mkdir (string zero-source "/tiles"))
(each name ["manifest.json" "provenance.json" "summary.json" "READY"]
  (write-raw (string zero-source "/" name)
             (read-raw (string learned-src "/" name))))
(write-raw (string zero-source "/manifest.janet")
           (string/replace (string " :seed " (get parsed :value) " ")
                           (string " :seed " zero-model-seed " ")
                           (string (read-raw (string learned-src "/manifest.janet")))))
(write-raw (string zero-source "/tiles/0_0.tdh")
           (read-raw (string learned-src "/tiles/0_0.tdh")))
(def zero-world (world/world-new))
(put zero-world :seed 0)
(def zero-ch (world/chunk-new 0 0))
(world/chunk-set zero-ch 0 40 0 world/block-grass)
(world/world-put-chunk zero-world zero-ch)
(def zero-inspected (catalog/inspect-artifact zero-source 0))
(assert (= zero-model-seed (get zero-inspected :model-seed)))
(assert (= provider/seed-mapping-version (get zero-inspected :seed-mapping-version)))
(def zero-id (catalog/create-slot root {:name "World zero" :seed zero-seed
                :world zero-world :player player :provider :terrain-diffusion-python
                :settings {:size 16 :sea-level 28 :profile "alpine"}
                :artifact-dir zero-source}))
(def zero-loaded (catalog/load-slot root zero-id))
(assert (= 0 (get (get (get zero-loaded :manifest) :seed) :value)))
(assert (= zero-model-seed (get (get (get zero-loaded :manifest) :artifact) :model-seed)))
(assert (= provider/seed-mapping-version
           (get (get (get zero-loaded :manifest) :artifact) :seed-mapping-version)))
(assert (= zero-model-seed
           (get (terrain-cache/load-manifest (get zero-loaded :artifact-dir)) :seed)))
(assert (= 0 (get (get zero-loaded :world) :seed)))
(assert (= :ready (get (first (filter |(= zero-id (get $ :id))
                                     (catalog/list-slots root))) :status)))
(catalog/save-slot root zero-id zero-world player {})
(assert (= 0 (get (get (catalog/load-slot root zero-id) :world) :seed)))
(print "seed-zero world/model mapping persists across reload and save: passed")

#
# --- Versioned settings: v1 records are frozen, v2 is additive ----------
#
# A catalogue slot's settings version decides which key set and which identity
# string its manifest must carry. The properties that matter are that an existing
# v1 slot still validates and still reports version 1 after a save, that a v2 slot
# is accepted when asked for explicitly and refused when malformed, and that the
# two are distinguishable in identity even when their terrain is identical.
#
# Every world here is built through the same helper so a difference in the
# manifest cannot come from a difference in the region bytes.
(defn v2-world []
  (def w (world/world-new))
  (put w :seed (get parsed :value))
  (def c (world/chunk-new 0 0))
  (world/chunk-set c 1 40 1 world/block-grass)
  (world/world-put-chunk w c)
  w)(defn version-of [slot-id]
  (get (catalog/load-manifest root slot-id) :settings-version))

# The slot created at the top of this file is a v1 world with no explicit version.
(assert (= 1 (version-of id)))
(def v1-manifest (catalog/load-manifest root id))
(assert (= 4 (length (keys (get v1-manifest :settings)))))
(assert (not (string/find ":clearing=" (get v1-manifest :settings-identity))))
(assert (string/find "procedural:v1:" (get v1-manifest :settings-identity)))

# A v1 slot RE-SAVED must stay v1. This is the "no automatic upgrade" rule: an
# upgrade is a deliberate act with its own identity, never a side effect of save.
(def v1-resaved (catalog/save-slot root id (v2-world) player {}))
(assert (= 1 (get v1-resaved :settings-version)))
(assert (= 4 (length (keys (get v1-resaved :settings)))))
(assert (= (get v1-manifest :settings-identity) (get v1-resaved :settings-identity)))

# Explicit v2: the fifth control is accepted and written.
(def v2-slot (catalog/create-slot root {:name "v2 clearings" :seed parsed
                                         :world (v2-world) :player player
                                         :settings-version 2
                                         :settings {:clearing-density 25}}))
(def v2-manifest (catalog/load-manifest root v2-slot))
(assert (= 2 (get v2-manifest :settings-version)))
(assert (= 5 (length (get v2-manifest :settings))))
(assert (= 25 (get (get v2-manifest :settings) :clearing-density)))
(assert (string/find "procedural:v2:" (get v2-manifest :settings-identity)))
(assert (string/find ":clearing=25" (get v2-manifest :settings-identity)))
# It must round-trip through the load gate like any other slot.
(assert (= (get v2-manifest :settings-identity)
           (get (get (catalog/load-slot root v2-slot) :manifest) :settings-identity)))

# A v2 slot at clearing 0 has v1's TERRAIN but not v1's identity: the version
# distinguishes which settings contract produced a world, so the two can never be
# silently substituted for one another.
(def v2-zero-slot (catalog/create-slot root {:name "v2 at zero" :seed parsed
                                              :world (v2-world) :player player
                                              :settings-version 2 :settings {}}))
(def v2-zero (catalog/load-manifest root v2-zero-slot))
(assert (= 2 (get v2-zero :settings-version)))
(assert (= 0 (get (get v2-zero :settings) :clearing-density)))
(assert (not= (get v2-zero :settings-identity) (get v1-manifest :settings-identity)))
(assert (string/find ":clearing=0" (get v2-zero :settings-identity)))

# A v2 slot re-saved stays v2, and keeps its invisible-to-terrain control.
(def v2-resaved (catalog/save-slot root v2-slot (v2-world) player {}))
(assert (= 2 (get v2-resaved :settings-version)))
(assert (= 25 (get (get v2-resaved :settings) :clearing-density)))

# Malformed v2 requests fail closed rather than being rounded into validity.
(reject (fn [] (catalog/create-slot root {:name "bad" :seed parsed :world (v2-world)
                                          :player player :settings-version 2
                                          :settings {:clearing-density 101}}))
        "invalid world setting")
(reject (fn [] (catalog/create-slot root {:name "bad" :seed parsed :world (v2-world)
                                          :player player :settings-version 3
                                          :settings {}}))
        "unsupported settings version")
# A fifth key smuggled into a v1 slot is an unknown control there.
(reject (fn [] (catalog/create-slot root {:name "bad" :seed parsed :world (v2-world)
                                          :player player :settings-version 1
                                          :settings {:clearing-density 10}}))
        "invalid world setting")

# And the on-disk validators refuse a HAND-EDITED mismatch in both directions: a
# fifth key under a v1 manifest, and a missing fifth key under a v2 manifest.
(def v1-dir (string root "/" id))
(def v1-manifest-path (string v1-dir "/manifest.janet"))
(def v1-saved (read-raw v1-manifest-path))
(replace-once v1-manifest-path ":forest-density 0}}"
              ":forest-density 0 :clearing-density 0}}")
(reject (fn [] (catalog/load-manifest root id)) "settings must contain exactly 4")
(write-raw v1-manifest-path v1-saved)
(def v2-dir (string root "/" v2-slot))
(def v2-manifest-path (string v2-dir "/manifest.janet"))
(def v2-saved (read-raw v2-manifest-path))
(replace-once v2-manifest-path " :clearing-density 25" "")
(reject (fn [] (catalog/load-manifest root v2-slot)) "settings must contain exactly 5")
(write-raw v2-manifest-path v2-saved)
# Restored, both still load: the refusals above were about shape, not damage.
(assert (= 1 (version-of id)))
(assert (= 2 (version-of v2-slot)))
(print "versioned settings v1 frozen and v2 additive: passed")


#
# --- Optional climate container: producer-format artifacts are publishable ---
#
# `tools/scenic_terrain.py` (f7dd22c) writes `climate.f32` beside the tiles and
# describes it in the CRC-bound `provenance.json`. The catalogue used to demand
# EXACTLY six directory entries, so a world whose producer generated real climate
# could be built and never saved. These checks publish one and then establish
# that the seventh entry is still a CONTRACT rather than a hole: an unknown
# seventh name, a declaration without bytes, bytes without a declaration, a
# corrupt payload, a truncated payload, a payload describing another grid, a
# declared byte count that is not this grid's size, and an unreadable record all
# refuse.
(def climate-name "climate.f32")
(def climate-samples [0x3f800000 0x40200000 0xc0500000 0x00000000 0x42c80000])
(defn climate-bytes [h w]
  # Channel-last float32: h*w samples of five finite values. For the one-tile
  # fixture that is 16*16*5*4 = 5120 bytes.
  (def buf (buffer/new-filled (* h w 5 4) 0))
  (for i 0 (* h w 5)
    (put-le32 buf (* i 4) (get climate-samples (mod i 5))))
  buf)
(def climate-payload (climate-bytes 16 16))
(defn climate-record
  ``The producer's `climate` block over `body`, as the CRC-bound record.

  Deliberately carries escapes, nested objects, a nested array and a boolean so
  the scanner is exercised on the real wire rather than a convenient subset.``
  [shape declared-bytes crc sha]
  (string "{\"format\":3,\"magic\":\"TDS3\","
          "\"mapping\":{\"profile\":\"alpine\",\"sea_level\":28},"
          "\"climate\":{\"container\":\"flat-f32-le\",\"container-version\":1,"
          "\"file\":\"climate.f32\",\"shape\":[" (shape 0) "," (shape 1) ","
          (shape 2) "],\"dtype\":\"f32<\","
          "\"order\":\"row-major, channel-last (x fastest within a row)\","
          "\"bytes\":" declared-bytes ","
          "\"channels\":[\"temperature\",\"temperature-seasonality\","
          "\"precipitation\",\"precipitation-variability\",\"lapse-rate\"],"
          "\"units\":{\"temperature\":\"degrees C, elevation-adjusted mean\","
          "\"temperature-seasonality\":\"degrees C, standard deviation\","
          "\"precipitation\":\"millimetres per year\","
          "\"precipitation-variability\":\"coefficient of variation, percent\","
          "\"lapse-rate\":\"degrees C per metre\"},"
          "\"basis\":\"source-derived\",\"calibrated\":false,"
          "\"projection\":{\"source-grid\":[16,16],\"artifact-grid\":[16,16],"
          "\"scale\":1,\"origin\":[0,0],\"semantics\":\"cell-grid\"},"
          "\"sha256\":\"" sha "\",\"crc32\":" crc "}}\n"))
(defn write-climate-twin
  ``Write `dir`'s record AND the twin that binds it by size and CRC-32.

  `provenance.json` is itself bound by `manifest.janet`, so every mutation below
  goes through this one writer: the pair stays self-consistent as a CACHE, and
  only the climate contract is ever broken. Without that, the cache layer would
  refuse first and the check under test would never run.``
  [dir record]
  (write-raw (string dir "/provenance.json") record)
  (write-raw (string dir "/manifest.janet")
             (string "{:format 3 :magic \"TDS3\" :identity \"" learned-ident
                     "\" :seed " (get parsed :value)
                     " :payload-bytes 256 :tile-bytes 308 :height-min 4 :height-max 252"
                     " :bounds [0 0 0 0] :origin [100000 100000]"
                     " :json-bytes " (length record)
                     " :json-crc32 " (integrity/crc32 record) "}\n")))
(defn publish-climate-source
  ``Write one complete producer-format artifact under `dir`, contract and all.

  This is the artifact `import_raw` would leave behind for a map whose producer
  generated climate: the payload beside the tiles and its digest/size inside the
  CRC-bound record. Every refusal below starts from exactly this directory and
  then breaks one thing, so a refusal can never come from fixture drift.``
  [dir]
  (when (os/lstat dir) (remove-tree dir))
  (os/mkdir dir)
  (os/mkdir (string dir "/tiles"))
  (write-raw (string dir "/" climate-name) climate-payload)
  # The record binds the bytes that were WRITTEN, so the digest is taken from the
  # file the producer left behind rather than from an in-memory copy.
  (def record (climate-record [16 16 5] (length climate-payload)
                              (integrity/crc32 (string climate-payload))
                              (runtime/sha256-file (string dir "/" climate-name))))
  (write-climate-twin dir record)
  (write-raw (string dir "/manifest.json") "{\"format\": 3}\n")
  (write-raw (string dir "/summary.json") "{\"tiles\": 1}\n")
  (write-raw (string dir "/READY")
             (string "{\"ready\": true, \"temporary\": true, \"identity\": \""
                     learned-ident "\", \"tiles\": 1}\n"))
  (write-raw (string dir "/tiles/0_0.tdh")
             (read-raw (string learned-src "/tiles/0_0.tdh")))
  dir)

# A producer-format climate artifact is now publishable: inspect, create, reload
# and re-save all preserve the payload byte for byte.
(def climate-src (string root "/climate-source"))
(publish-climate-source climate-src)
(def climate-inspected (catalog/inspect-artifact climate-src (get parsed :value)))
(assert (= [0 0 0 0] (get climate-inspected :bounds)))
(assert (= 7 (length (os/dir climate-src))))
(def climate-id (catalog/create-slot root
                  {:name "Climate world" :seed parsed :world learned-world
                   :player player :provider :terrain-diffusion-python
                   :settings {:size 16 :sea-level 28 :profile "alpine"}
                   :artifact-dir climate-src}))
(def climate-owned (get (catalog/load-slot root climate-id) :artifact-dir))
(defn owned-climate-bytes [dir] (read-raw (string dir "/" climate-name)))
(assert (= (string climate-payload) (string (owned-climate-bytes climate-owned))))
# A save clones the payload again, so the container survives the immutable
# snapshot path and not only the first publish.
(def climate-first (get (get (catalog/load-slot root climate-id) :manifest) :snapshot))
(catalog/save-slot root climate-id learned-world player {})
(def climate-second (get (get (catalog/load-slot root climate-id) :manifest) :snapshot))
(assert (not= climate-first climate-second))
(assert (= (string climate-payload)
           (string (owned-climate-bytes (get (catalog/load-slot root climate-id)
                                             :artifact-dir)))))
(assert (= :ready (get (first (filter |(= climate-id (get $ :id))
                                    (catalog/list-slots root))) :status)))
(print "producer climate container is owned, reloaded and cloned byte for byte: passed")

# Every refusal below starts from one VERBATIM published artifact and then breaks
# exactly one thing, so a refusal cannot come from fixture drift.
(def probe (string root "/climate-probe"))
(defn rejects [mutate fragment]
  (publish-climate-source probe)
  (mutate)
  (reject (fn [] (catalog/inspect-artifact probe (get parsed :value))) fragment))
# CORRUPTION: one flipped byte in the payload breaks the declared CRC-32 and
# SHA-256 -- the record still describes the bytes the producer wrote.
(defn flip-a-byte []
  (def flipped (buffer/new-filled (length climate-payload) 0))
  (for i 0 (length climate-payload) (put flipped i (get climate-payload i)))
  (put flipped 100 (band (bxor (get flipped 100) 255) 255))
  (write-raw (string probe "/" climate-name) flipped))
(rejects flip-a-byte "CRC-32 mismatch")
# TRUNCATION: fewer bytes than the contract declares, same record.
(defn truncate []
  (write-raw (string probe "/" climate-name)
             (string/slice climate-payload 0 5116)))
(rejects truncate "bytes")
# A DECLARATION WITH NO BYTES and BYTES WITH NO DECLARATION: both directions of
# the same mismatch, and neither may be published.
(rejects (fn [] (os/rm (string probe "/" climate-name))) "no climate.f32")
(rejects (fn []
           # The record no longer declares climate; the payload is still there.
           (def record (string (read-raw (string probe "/provenance.json"))))
           (write-climate-twin probe
             (string/replace (string "\"climate\":{\"container\":\"flat-f32-le\"")
                             (string "\"xclimate\":{\"container\":\"flat-f32-le\"")
                             record)))
         "without declaring")
# AN UNKNOWN SEVENTH ENTRY is still refused: the whitelist did not widen.
(rejects (fn [] (write-raw (string probe "/notes.txt") "x")) "unexpected")
# A PAYLOAD DESCRIBING ANOTHER GRID is refused rather than stretched onto this
# map, even when its own record is internally consistent with its own bytes.
(rejects (fn []
           (def wide (buffer/new-filled 10240 0))
           (write-raw (string probe "/" climate-name) wide)
           (write-climate-twin probe
             (climate-record [32 16 5] 10240
                             (integrity/crc32 (string wide))
                             (runtime/sha256-file (string probe "/" climate-name)))))
         "does not match")
# A DECLARED BYTE COUNT that is not this grid's exact size.
(rejects (fn []
           (def record (string (read-raw (string probe "/provenance.json"))))
           (write-climate-twin probe
             (string/replace "\"bytes\":5120" "\"bytes\":5124" record)))
         "exactly 5120")
# A DECLARED CONTAINER this reader does not implement is refused, not assumed.
(rejects (fn []
           (def record (string (read-raw (string probe "/provenance.json"))))
           (write-climate-twin probe
             (string/replace "\"container-version\":1" "\"container-version\":2"
                             record)))
         "container-version")
# AN UNREADABLE RECORD beside a payload is a refusal, not "no climate": bytes
# nobody described are exactly what this check exists to stop.
(rejects (fn [] (write-climate-twin probe "{\"climate\":{\"container\":"))
         "cannot be read")
# ADVERSARIAL: each of these is a record that a string-search or a permissive
# parser would ACCEPT. They must refuse, because accepting them means a validator
# can be shown one value while a loader reads another.
# A DECOY `climate` INSIDE A STRING is not a field: the scanner never looks inside
# a string, so a record whose only mention of climate is quoted TEXT declares none
# and -- with a payload present -- refuses rather than publishing bare bytes.
(rejects (fn []
           (write-climate-twin probe "{\"format\":3,\"note\":\"a climate block\"}\n"))
         "without declaring")
# A DECOY `climate` IN A NESTED OBJECT must not be picked up: only the ROOT
# record's own `climate` key is the declaration, so burying the block one level
# down declares nothing and a present payload refuses.
(rejects (fn []
           (write-climate-twin probe
             "{\"meta\":{\"climate\":{\"container\":\"flat-f32-le\"}}}\n"))
         "without declaring")
# A DUPLICATE `climate` KEY is refused outright, not resolved last-one-wins.
# Duplicate detection happens during scanning, so a minimal record is enough.
(rejects (fn []
           (write-climate-twin probe
             (string "{\"climate\":{\"container\":\"flat-f32-le\"},"
                     "\"climate\":{\"container\":\"flat-f32-le\"}}}\n")))
         "duplicate key")
# A DUPLICATE FIELD INSIDE the block is the same attack one level down: a record
# could otherwise show a validator one `crc32` and a loader another.
(rejects (fn []
           (write-climate-twin probe
             (string "{\"climate\":{\"crc32\":1,\"crc32\":2}}}\n")))
         "duplicate key")
# AN UNKNOWN FIELD in the block is a different contract, not a superset.
(rejects (fn []
           (def real (string (read-raw (string probe "/provenance.json"))))
           (write-climate-twin probe
             (string/replace "\"basis\":" "\"calibration-note\":\"x\",\"basis\":" real)))
         "keys")
# A RENAMED CHANNEL with a consistent count and size is still the wrong data.
(rejects (fn []
           (def real (string (read-raw (string probe "/provenance.json"))))
           (write-climate-twin probe
             (string/replace "\"temperature-seasonality\"" "\"humidity\"" real)))
         "channel")
# A REWRITTEN UNIT is refused: `calibrated: false` only means something beside
# the units this reader understands.
(rejects (fn []
           (def real (string (read-raw (string probe "/provenance.json"))))
           (write-climate-twin probe
             (string/replace "millimetres per year" "arbitrary units" real)))
         "unit for")
# A PROJECTION describing another grid is refused even at the right shape.
(rejects (fn []
           (def real (string (read-raw (string probe "/provenance.json"))))
           (write-climate-twin probe
             (string/replace "\"artifact-grid\":[16,16]" "\"artifact-grid\":[32,32]" real)))
         "artifact-grid")
# TRAILING JUNK after the root object is refused, not ignored.
(rejects (fn []
           (def real (string (read-raw (string probe "/provenance.json"))))
           (write-climate-twin probe (string real "{}")))
         "trailing bytes")
# TRUNCATED input (EOF mid-object) refuses.
(rejects (fn []
           (def real (string (read-raw (string probe "/provenance.json"))))
           (write-climate-twin probe (string/slice real 0 200)))
         "cannot be read")

# The PUBLIC helpers are what a cache loader will call, so they are exercised
# directly: pure function in, validated contract out, no file access.
(defn valid-record []
  (publish-climate-source probe)
  (read-raw (string probe "/provenance.json")))
(def bound (catalog/climate-metadata (valid-record) [0 0 0 0] true))
(assert (= [16 16 5] (get bound :shape)))
(assert (= 5120 (get bound :bytes)))
(assert (= (integrity/crc32 (string climate-payload)) (get bound :crc32)))
# No payload AND no declaration is the pre-climate artifact: nil, not an error.
(write-climate-twin probe "{\"format\":3}\n")
(assert (nil? (catalog/climate-metadata (read-raw (string probe "/provenance.json"))
                                       [0 0 0 0] false)))
# A declaration WITHOUT a payload refuses through the public entry point too --
# the same parity rule the catalogue applies, reachable by a future loader.
(reject (fn [] (catalog/climate-metadata
                 (string "{\"climate\":{\"container\":\"flat-f32-le\"}}")
                 [0 0 0 0] false))
        "no climate.f32 payload")
# An UNREADABLE record with a payload refuses rather than reporting "declares
# nothing": unexplained bytes are never published.
(reject (fn [] (catalog/climate-metadata "{\"climate\":{" [0 0 0 0] true))
        "cannot be read")
(print "climate corruption, truncation, presence mismatch and wrong grid refuse: passed")

(print "world catalogue: ALL CHECKS PASSED")
