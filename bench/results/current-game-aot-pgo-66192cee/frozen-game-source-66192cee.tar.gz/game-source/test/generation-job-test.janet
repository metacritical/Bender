(import ../src/generation-job :as job)

(defn fixture []
  (def calls @{:spawn 0 :watch 0 :pump 0 :term 0 :kill 0 :wait 0
               :argv nil :now 100})
  (def process @{:pid 7731})
  (def opts @{:slot @{:job nil}
              :spawn (fn [argv]
                       (put calls :spawn (+ 1 (calls :spawn)))
                       (put calls :argv argv)
                       process)
              :watch (fn [p completed]
                       (assert (= p process) "watch owns spawned handle")
                       (put calls :watch (+ 1 (calls :watch))))
              :pump (fn [] (put calls :pump (+ 1 (calls :pump))))
              :clock (fn [] (calls :now))
              :term (fn [p]
                      (assert (= p process) "TERM exact owned handle")
                      (put calls :term (+ 1 (calls :term))))
              :kill (fn [p]
                      (assert (= p process) "kill exact owned handle")
                      (put calls :kill (+ 1 (calls :kill))))
              :wait (fn [p completed]
                      (assert (= p process) "reap exact owned handle")
                      (put calls :wait (+ 1 (calls :wait)))
                      (put completed :exit-code 137)
                      137)
              :direct-reap (fn [p completed]
                             (assert (= p process) "emergency reap exact owned handle")
                             (put calls :wait (+ 1 (calls :wait)))
                             (put completed :exit-code 137)
                             (put completed :wait-error nil)
                             137)
              :read-progress (fn [path] {:version 1 :stage :sample
                                         :completed 1 :total 4 :message "sampling"})
              :progress-path "test-stage"
              :validate (fn [j] true)})
  [opts calls process])

(let [[opts calls process] (fixture)
      active (job/start "a ridge" @["python3" "-m" "terrain"] opts)]
  (assert (= 7731 (active :pid)) "exact owned PID")
  (assert (= 1 (calls :spawn)) "one direct process")
  (assert (deep= @["python3" "-m" "terrain"] (calls :argv)) "argv never shell-stringified")
  (assert (not (try (do (job/start "other" @["python3"] opts) true) ([e] false)))
          "owned slot rejects concurrent start")
  (assert (= :running ((job/poll active) :phase)) "poll does not wait for live child")
  (assert (= :sample (get ((job/poll active) :progress) :stage))
          "validated stage progress visible")
  (assert (= 0 (calls :wait)) "poll never blocks to reap")
  (put (active :completion) :exit-code 0)
  (assert (= :succeeded ((job/poll active) :phase)) "completed child succeeds")
  (assert (= 0 ((job/poll active) :exit-code)) "exit code preserved")
  (assert (= nil (get (opts :slot) :job)) "successful job releases slot")
  (assert (= 0 (calls :kill)) "successful job never killed")
  (assert (= :succeeded ((job/close active) :phase)) "close success idempotent"))

(let [[opts calls process] (fixture)
      active (job/start "cancel" @["python3"] opts)]
  (assert (= :cancelling ((job/cancel active) :phase)) "TERM begins cancellation")
  (assert (= 1 (calls :term)) "TERM sent once to exact handle")
  (assert (= 0 (calls :kill)) "cancel does not instantly KILL")
  (assert (= 0 (calls :wait)) "cancel never blocks to reap")
  (assert (= active (get (opts :slot) :job)) "cancelling retains slot")
  (assert (= :cancelling ((job/cancel active) :phase)) "repeated cancel is harmless")
  (put calls :now 104.99)
  (assert (= :cancelling ((job/poll active) :phase)) "poll before grace remains cancelling")
  (assert (= 0 (calls :kill)) "KILL not sent before five seconds")
  (put calls :now 105)
  (assert (= :cancelling ((job/poll active) :phase)) "KILL awaits watcher reap")
  (assert (= 1 (calls :kill)) "KILL exact handle after grace")
  (assert (= 0 (calls :wait)) "poll still does not block on reap")
  (job/poll active)
  (assert (= 1 (calls :kill)) "KILL sent only once")
  (put (active :completion) :exit-code 137)
  (assert (= :cancelled ((job/poll active) :phase)) "watcher finalizes cancellation")
  (assert (= 137 (active :exit-code)) "watcher exit code preserved")
  (assert (= nil (get (opts :slot) :job)) "reaped job releases slot")
  (assert (= 1 (calls :term)) "TERM not duplicated")
  (assert (= 0 (calls :wait)) "poll never uses shutdown wait"))

(let [[opts calls process] (fixture)
      active (job/start "graceful" @["python3"] opts)]
  (job/cancel active)
  (put (active :completion) :exit-code 130)
  (assert (= :cancelled ((job/poll active) :phase)) "TERM exit completes without KILL")
  (assert (= 0 (calls :kill)) "cooperative child is not killed")
  (assert (= nil (get (opts :slot) :job)) "cooperative exit releases slot"))

(let [[opts calls process] (fixture)]
  (put opts :spawn (fn [argv] (error "cannot spawn")))
  (def failed (job/start "fail" @["python3"] opts))
  (assert (= :failed ((job/poll failed) :phase)) "spawn errors are visible")
  (assert (= nil (get (opts :slot) :job)) "failed start releases slot")
  (assert (string/find "generation spawn failed:" (failed :error)) "spawn failure context"))

(let [[opts calls process] (fixture)]
  (put opts :watch (fn [p completed] (error "cannot watch")))
  (def failed (job/start "fail watch" @["python3"] opts))
  (assert (= :failed ((job/poll failed) :phase)) "watch failure visible")
  (assert (= 1 (calls :kill)) "watch failure terminates exact process")
  (assert (= 1 (calls :wait)) "watch failure reaps exact process")
  (assert (= nil (get (opts :slot) :job)) "watch failure releases slot"))

(let [[opts calls process] (fixture)]
  (assert (not (try (do (job/start "bad" @["sh" "-c" 12] opts) true) ([e] false)))
          "non-string argv rejected before spawn")
  (assert (= 0 (calls :spawn)) "invalid argv cannot start worker"))

(let [[opts calls process] (fixture)]
  (put opts :validate (fn [j] false))
  (def active (job/start "invalid artifact" @["python3"] opts))
  (put (active :completion) :exit-code 0)
  (assert (= :failed ((job/poll active) :phase))
          "zero process exit is not artifact-ready without validation")
  (assert (= nil (get (opts :slot) :job)) "failed validation releases reaped slot"))

(let [[opts calls process] (fixture)]
  (put opts :read-progress (fn [path] (error "corrupt stage file")))
  (def active (job/start "broken progress" @["python3"] opts))
  (put (active :completion) :exit-code 0)
  (assert (= :failed ((job/poll active) :phase)) "progress read failures are visible")
  (assert (string/find "progress read failed:" (active :error))
          "progress failure retains context"))

(let [[opts calls process] (fixture)]
  (put opts :kill (fn [p] (error "could not kill")))
  (put opts :wait (fn [p c] (error "could not reap")))
  (def active (job/start "unsafe cleanup" @["python3"] opts))
  (job/cancel active)
  (put calls :now 105)
  (assert (= :cancelling ((job/poll active) :phase))
          "failed KILL retains owned slot until watcher reaps")
  (assert (= active (get (opts :slot) :job))
          "failed kill prevents new generation")
  (assert (= :failed ((job/close active) :phase)) "reap failure reported at shutdown")
  (assert (= active (get (opts :slot) :job))
          "failed reap preserves ownership and prevents new generation"))

(let [[opts calls process] (fixture)
      active (job/start "completed before cancel" @["python3"] opts)]
  (put (active :completion) :exit-code 0)
  (assert (= :succeeded ((job/cancel active) :phase)) "cancel collects an already completed child")
  (assert (= 0 (calls :term)) "completed child is not signalled")
  (assert (= nil (get (opts :slot) :job)) "completion race releases reaped slot"))

(let [[opts calls process] (fixture)
      active (job/start "wait failed" @["python3"] opts)]
  (put (active :completion) :wait-error "wait failed")
  (assert (= :failed ((job/poll active) :phase)) "watcher error is explicit")
  (assert (= active (get (opts :slot) :job)) "unreaped failure keeps slot")
  (job/close active)
  (assert (= 1 (calls :kill)) "failed watcher cleanup kills only owned handle")
  (assert (= 1 (calls :wait)) "failed watcher uses emergency reap")
  (assert (= nil (get (opts :slot) :job)) "successful emergency reap releases slot"))

(print "generation job fake-process tests: ok")
