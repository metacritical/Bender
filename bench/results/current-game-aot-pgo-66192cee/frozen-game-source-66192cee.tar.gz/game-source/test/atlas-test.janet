# Headless contract tests for the procedural Trinecraft atlas.
(import ../src/atlas :as atlas)
(import ../src/rl :as rl)
(import ../src/material-recipes :as recipes)

(defn near [a b] (< (math/abs (- a b)) 0.000001))

(for block 1 8
  (for face 0 6
    (let [tile (atlas/tile-for block face)]
      (assert (and (<= 0 tile) (< tile 16))))))
(print "tile indices: pass")

(let [top (atlas/tile-for 3 4)
      side (atlas/tile-for 3 0)
      bottom (atlas/tile-for 3 5)]
  (assert (and (not= top side) (not= side bottom) (not= top bottom)))
  (for face 0 4 (assert (= side (atlas/tile-for 3 face)))))
(print "grass faces: pass")

(for block 1 8
  (for face 0 6
    (let [rect (atlas/face-uv block face)]
      (assert (= 4 (length rect)))
      (each n rect (assert (and (number? n) (<= 0 n) (<= n 1))))
      (assert (< (get rect 0) (get rect 2)))
      (assert (< (get rect 1) (get rect 3))))))
(print "UV bounds: pass")

(let [tiles @{}]
  (for block 1 8
    (for face 0 6
      (let [tile (atlas/tile-for block face)
            rect (atlas/face-uv block face)]
        (if (has-key? tiles tile)
          (assert (= rect (get tiles tile)))
          (put tiles tile rect)))))
  (each [a ra] (pairs tiles)
    (each [b rb] (pairs tiles)
      (when (not= a b) (assert (not= ra rb))))))
(print "tile-to-UV mapping: pass")

(for block 1 8
  (for face 0 6
    (let [tile (atlas/tile-for block face)
          rect (atlas/face-uv block face)
          col (mod tile atlas/atlas-cols)
          row (math/floor (/ tile atlas/atlas-cols))]
      (assert (near (- (get rect 2) (get rect 0)) (/ 1 atlas/atlas-cols)))
      (assert (near (- (get rect 3) (get rect 1)) (/ 1 atlas/atlas-rows)))
      (assert (near (get rect 0) (/ col atlas/atlas-cols)))
      (assert (near (get rect 1) (/ row atlas/atlas-rows))))))
(print "atlas grid alignment: pass")

(let [rect (atlas/face-uv 1 0)
      shrunk (atlas/inset-uv rect 1)
      extreme (atlas/inset-uv rect 100)]
  (assert (near (- (get shrunk 0) (get rect 0)) (/ 1 64)))
  (assert (near (- (get shrunk 1) (get rect 1)) (/ 1 64)))
  (assert (near (- (get rect 2) (get shrunk 2)) (/ 1 64)))
  (assert (near (- (get rect 3) (get shrunk 3)) (/ 1 64)))
  (assert (<= (get extreme 0) (get extreme 2)))
  (assert (<= (get extreme 1) (get extreme 3))))
(print "UV inset: pass")

# Raylib image generation and drawing are CPU-side; no window is opened.
(let [image (atlas/build-atlas-image)
      offsets (map |($ :offset) ((ffi/struct-info rl/image-type) :fields))]
  (assert (= 64 (ffi/read :int image (get offsets 1))))
  (assert (= 64 (ffi/read :int image (get offsets 2))))
  (rl/unload-image (ffi/read rl/image-type image)))
(print "headless image dimensions: pass")

# A custom recipe changes its tile without changing the fixed tile/UV mapping.
(let [custom (merge recipes/recipes {:stone (merge (get recipes/recipes :stone)
                                                   {:kind :checker :base [12 34 56 255]
                                                    :dark [12 34 56 255] :light [12 34 56 255]})})
      image (atlas/build-atlas-image custom)
      data (ffi/read :ptr image (get atlas/image-offsets 0))
      # Stone is tile 1: x=16..31, y=0..15, row-major RGBA bytes.
      stone-byte (* 4 16)]
  (each channel (range 4)
    (assert (= (get [12 34 56 255] channel)
               (ffi/read :uint8 data (+ stone-byte channel)))))
  (rl/unload-image (ffi/read rl/image-type image)))
(print "custom recipe image pixels: pass")

(let [custom (merge recipes/recipes {:grass (merge (get recipes/recipes :grass)
                                                   {:kind :checker :base [10 200 10 255]
                                                    :dark [10 200 10 255] :light [10 200 10 255]})
                                     :dirt (merge (get recipes/recipes :dirt)
                                                  {:kind :checker :base [90 40 10 255]
                                                   :dark [90 40 10 255] :light [90 40 10 255]})})]
  (assert (= [10 200 10 255] (atlas/tile-sample custom 4 7 3)))
  (assert (= [90 40 10 255] (atlas/tile-sample custom 4 7 4)))
  (assert (= (recipes/sample (get custom :grass) 7 8)
             (atlas/tile-sample custom 3 7 8))))
(print "grass-side recipe layers: pass")
# The default side tile retains the old seed-4 cap, seam and dirt pixels.
(for y 0 16
  (for x 0 16
    (let [n (mod (+ (* (+ x 4) 73856093) (* (+ y 4) 19349663)
                    (* (+ x 4) (+ y 4) 83492791)) 17)
          expected (cond
                     (< y 4) (if (< n 4) [51 140 47 255] [80 168 62 255])
                     (= y 4) [95 64 39 255]
                     (< n 2) [95 64 39 255]
                     (> n 14) [157 111 71 255]
                     [125 85 52 255])]
      (assert (= expected (atlas/tile-sample recipes/recipes 4 x y))))))


# --- Snow (block 8) and legacy ID preservation -------------------------
# Snow is the first block added after the original eight, so these pin two
# things at once: that the new block works, and that adding it did not
# renumber or re-tile anything that already existed.

(print "snow tile: ")
# Snow sits on its own tile, outside the range the original blocks occupy.
(let [tile (atlas/tile-for 8 4)]
  (assert (= 9 tile))
  (assert (and (<= 0 tile) (< tile 16))))
(for face 0 6
  (let [tile (atlas/tile-for 8 face)]
    (assert (= 9 tile)
            (string "face " face " should also use tile 9, got " tile))))
(print "  block 8 -> tile 9 on all six faces: pass")

# face-uv must return a real rect for block 8. This is the check that fails if
# `face-rects` still builds only 8 entries -- the failure would be a nil UV at
# mesh time, or a silent fallback to a unit rect.
(for face 0 6
  (let [rect (atlas/face-uv 8 face)]
    (assert (= 4 (length rect)) (string "face " face " has no UV rect"))
    (each n rect (assert (and (number? n) (<= 0 n) (<= n 1))))
    (assert (< (get rect 0) (get rect 2)))
    (assert (< (get rect 1) (get rect 3)))))
(print "  block 8 has a non-empty in-bounds UV rect on all faces: pass")

# Tile 9 must be PAINTED. Before snow existed the atlas only wrote tiles 1-8,
# so mapping a block to tile 9 would have produced transparent black -- a
# failure that looks like a rendering bug rather than a missing loop bound.
(let [recipe (recipes/resolve :snow)]
  (assert (recipes/validate recipe))
  (let [base (atlas/tile-sample recipes/recipes 9 0 0)]
    (assert (not= [0 0 0 0] base)
            "tile 9 must be painted, not left transparent")
    # Low contrast: snow reads as snow through low variance, not through being
    # pure white, so the three tones must stay close together.
    (each c [1 2]
      (assert (< (math/abs (- (get (recipe :base) c) (get (recipe :light) c))) 40)
              (string "channel " c " varies too much for snow")))
    # Cool, not warm: the blue channel is the strongest one.
    (assert (> (get (recipe :base) 2) (get (recipe :base) 0))
            "snow base should be cool (blue > red)")))
(print "  tile 9 is painted and holds a low-contrast cool snow tone: pass")

# Legacy preservation: the original eight IDs and their tiles must not move.
# Hardcoded on purpose -- a computed expectation would move with the code.
(let [expected {0 nil 1 1 2 2 3 nil 4 5 5 6 6 7 7 8}]
  (each [block tile] (pairs expected)
    (if tile
      (for face 0 6
        (assert (= tile (atlas/tile-for block face))
                (string "block " block " face " face " tile changed")))
      nil)))
(print "  blocks 1,2,3(-cap),4,5,6,7 keep their original tiles: pass")

# Grass is the one block whose tile depends on the face; assert the exact
# three-way split still holds after the extension.
(assert (= 3 (atlas/tile-for 3 4)))
(assert (= 2 (atlas/tile-for 3 5)))
(for face 0 4 (assert (= 4 (atlas/tile-for 3 face))))
(print "  grass top/side/bottom split unchanged: pass")

# Every tile referenced by any block must be painted by build-atlas-image.
# The loop bound and the tile map are two separate constants, and this is the
# only thing tying them together.
(let [painted-to 9]
  (for block 1 9
    (for face 0 6
      (let [tile (atlas/tile-for block face)]
        (assert (<= tile painted-to)
                (string "block " block " references unpainted tile " tile))))))
(print "  no block references an unpainted tile: pass")

(let [started (os/clock)]
  (for i 0 200000 (atlas/face-uv (+ 1 (mod i 7)) (mod i 6)))
  (print "face-uv 200000 calls: " (- (os/clock) started) " s"))
(print "atlas tests: pass")
