# Scenic climate integration: the REAL reader chain, end to end.
#
# `scenic-worldgen-test` drives `fill` with a MOCKED reader returning
# `{:status :present :values ..}`, so it can never disagree with `fill`. The real
# path answers `:sampled`, and that difference is exactly how the status
# regression (7e4dd6c) slipped past the suite. Here every column is answered by
# the actual chain, with no hand-built status:
#
#   climate-tile/read -> terrain-cache/attach-climate! (or attach-climate) ->
#   terrain-cache/climate-at-world -> scenic-worldgen/fill
#
# Fixture budget: a 2x1-chunk map at a NEGATIVE origin = 32x16 = 512 cells, the
# largest grid this suite needs. No GL, no window, no model, no subprocess.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/scenic-climate-integration-test.janet

(import ../src/terrain-cache :as tc)
(import ../src/terrain-integrity :as integrity)
(import ../src/scenic-worldgen :as scenic)
(import ../src/world :as world)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(var scratch-counter 0)
(def scratch-roots @[])
(defn scratch-dir []
  (++ scratch-counter)
  (def path (string (or (os/getenv "TMPDIR") "/tmp")
                    "/trinecraft-climate-int-" (os/getpid) "-" scratch-counter))
  (os/mkdir path)
  (array/push scratch-roots path)
  path)

(defn rm-tree [path]
  (when (os/stat path)
    (each name (try (os/dir path) ([e] @[]))
      (def child (string path "/" name))
      (if (= :directory (os/stat child :mode)) (rm-tree child) (try (os/rm child) ([e] nil))))
    (try (os/rm path) ([e] nil))))

# --- The map: 2x1 chunks at a negative origin = 512 cells --------------
#
# Chunks cx0..cx1 = -1..0, cz 0..0, so 32 x 16 world cells anchored at (-16, 0).
# Climate must be 1:1 with that, i.e. a (16 32 5) grid.
(def map-bounds [-1 0 0 0])
(def map-origin [-16 0])
(def grid-shape [16 32 5])              # (height width channels)

# A bounded scenic identity is a manifest binding provenance.json by size and
# CRC-32 -- the minimum `cache-new` accepts.
(defn write-scenic-cache [dir]
  (def json "{\"profile\": \"scenic\", \"seed\": 2024}\n")
  (defn put-file [path data]
    (def f (file/open path :wbn)) (file/write f data) (file/close f))
  (put-file (tc/scenic-json-path dir) json)
  (put-file (string dir "/manifest.janet")
            (string "{:format 3 :magic \"TDS3\" :identity \"" (string/repeat "e" 64)
                    "\" :seed 2024 :payload-bytes 256 :tile-bytes 308"
                    " :height-min 4 :height-max 252"
                    " :bounds [" (map-bounds 0) " " (map-bounds 1) " "
                    (map-bounds 2) " " (map-bounds 3) "]"
                    " :origin [" (map-origin 0) " " (map-origin 1) "]"
                    " :json-bytes " (length json) " :json-crc32 "
                    (integrity/crc32 json) "}"))
  dir)

# --- The producer's wire: channel-last little-endian float32 -----------
(defn- f32-into [buf offset v]
  (def bits
    (if (= v 0) 0
        (let [[frac e] (math/frexp (math/abs v))
              raw (bor (if (< v 0) (blshift 1 31) 0)
                       (blshift (+ e 126) 23)
                       (- (math/floor (* frac 16777216)) 8388608))]
          (if (< raw 0) (+ raw 4294967296) raw))))
  (for i 0 4 (put buf (+ offset i) (% (math/floor (/ bits (math/pow 256 i))) 256))))

(defn climate-buffer
  "A (h w 5) buffer; `cell` is `(fn [x z] -> five channel numbers)`."
  [h w cell]
  (def buf (buffer/new-filled (* h w 5 4) 0))
  (for z 0 h
    (for x 0 w
      (def vs (cell x z))
      (for c 0 5 (f32-into buf (* (+ (* (+ (* z w) x) 5) c) 4) (get vs c)))))
  buf)

# 30 C / 20 mm/yr: warm and arid -> :desert -> sand over stone.  The legacy
# ladder at this height is grass over dirt, which is the change under test.
(defn desert-cell [x z] [30 100 20 50 1])
# Below freezing and wet -> :ice -> snow over dirt. A DIFFERENT surface again, so
# a misaddressed column cannot pass as correct.
(defn ice-cell [x z] [-5 300 900 20 1])

(def meta {:has_climate true})
(defn flat [] (fn [wx wz] 40))          # dry land: sea 28, shore band ends at 31

(defn chunk-of [cx cz opts]
  (def blocks (buffer/new-filled world/chunk-volume 0))
  (scenic/fill blocks cx cz (flat) opts)
  blocks)

(defn block-at [blocks lx y lz] (get blocks (world/block-index lx y lz)))

(defn column [blocks lx lz] [(block-at blocks lx 40 lz) (block-at blocks lx 39 lz)])

(defn all-columns? [blocks top sub]
  (var ok true)
  (for z 0 world/chunk-z
    (for x 0 world/chunk-x
      (unless (= [top sub] (column blocks x z)) (set ok false))))
  ok)

(defn crc-of [blocks] (integrity/crc32-hex (string blocks)))

(defn real-reader [cache] (fn [wx wz] (tc/climate-at-world cache wx wz)))

(def opts-v1 {:seed 1 :sea-level 28 :surface-policy :v1})

# --- 1. The real chain at 1:1 -----------------------------------------
(print "climate chain (1:1):")

(def root1 (write-scenic-cache (scratch-dir)))
(def cache1 (tc/cache-new root1 2024))
(def grid1 (climate-buffer 16 32 desert-cell))

(check "the fixture map is 512 cells at the negative origin"
       (= [2 1 32 16] (tc/climate-extent cache1)))
(check "the 1:1 grid is (16 32 5)"
       (= grid-shape (tc/climate-shape cache1)))
(check "attach-climate validates and attaches the real buffer"
       (= :present ((tc/attach-climate cache1 grid1 grid-shape meta) :status)))

# SEMANTIC STATUS. The cache answers a sampled record, not the reader's :present
# -- the whole point of this suite. Assert the status AND what it carries, since
# a status alone would still pass if the values were a neighbour's.
(def corner (tc/climate-at-world cache1 -16 0))
(check "the real cache answers :status :sampled"
       (= :sampled (corner :status)) (string (corner :status)))
(check "the sampled record carries the packed channels at grid cell 0"
       (and (= 0 (corner :index))
            (= 30 ((corner :values) :temperature))
            (= 20 ((corner :values) :precipitation))
            (= 5 (length (pairs (corner :values))))))
# Off the grid: unavailable with a machine-readable reason, never a silent zero.
(check "outside the map the cache answers :unavailable/:outside-map"
       (let [r (tc/climate-at-world cache1 16 0)]
         (and (= :unavailable (r :status)) (= :outside-map (r :reason))
              (nil? (get r :values)))))

(def legacy (chunk-of -1 0 {:seed 1 :sea-level 28}))
(def policy (chunk-of -1 0 (merge opts-v1 {:climate-at (real-reader cache1)})))

# SAND vs GRASS, checked at the column level and not only by CRC: every column is
# grass-over-dirt under the legacy ladder and sand-over-stone under the policy.
(check "legacy: every column is grass over dirt"
       (all-columns? legacy world/block-grass world/block-dirt))
(check "policy :v1: every column is sand over stone"
       (all-columns? policy world/block-sand world/block-stone)
       (string (column policy 3 3)))
(check "the difference is the surface, not the shape"
       (and (= (crc-of legacy) (crc-of (chunk-of -1 0 {:seed 1 :sea-level 28})))
            (not= (crc-of legacy) (crc-of policy))))
(check "y=41 is still air under the policy"
       (do
         (var ok true)
         (for z 0 world/chunk-z
           (for x 0 world/chunk-x
             (unless (= world/block-air (block-at policy x 41 z)) (set ok false))))
         ok))

# One cache, two biomes: the grid's x=16 boundary is world 0, so the two chunks
# carry different surfaces. Per-column addressing through the real projection.
(def mixed (climate-buffer 16 32 (fn [x z] (if (< x 16) (desert-cell x z) (ice-cell x z)))))
(def cache-mixed (tc/cache-new (write-scenic-cache (scratch-dir)) 2024))
(check "a mixed grid attaches at 1:1"
       (= :present ((tc/attach-climate cache-mixed mixed grid-shape meta) :status)))
(def west (chunk-of -1 0 (merge opts-v1 {:climate-at (real-reader cache-mixed)})))
(def east (chunk-of 0 0 (merge opts-v1 {:climate-at (real-reader cache-mixed)})))

(check "the arid chunk is sand over stone"
       (all-columns? west world/block-sand world/block-stone))
(check "the frozen chunk is snow over dirt"
       (all-columns? east world/block-snow world/block-dirt))
(check "one cache, two surfaces, decided per column"
       (not= (crc-of west) (crc-of east)))

# --- 2. Missing climate keeps the legacy chunk byte for byte -----------
(print "\nmissing climate:")

(def cache-bare (tc/cache-new (write-scenic-cache (scratch-dir)) 2024))
(def bare-policy (chunk-of -1 0 (merge opts-v1 {:climate-at (real-reader cache-bare)})))

(check "an unattached cache answers :unavailable/:not-attached"
       (let [r (tc/climate-at-world cache-bare -16 0)]
         (and (= :unavailable (r :status)) (= :not-attached (r :reason)))))
# An EXACT HASH pin: the policy chunk over a climate-less cache is not merely
# "equivalent" to legacy, it is the same bytes, and it stays that way.
# An EXACT HASH pin, in both directions: the legacy chunk is a fixed artifact
# hash, and the policy chunk over a climate-less cache reproduces it bit for bit
# rather than merely "looking the same".
(check "the legacy chunk hashes to a fixed value"
       (= "efa8c59e" (crc-of legacy)) (crc-of legacy))
(check "and the climate-less policy chunk matches that hash exactly"
       (= "efa8c59e" (crc-of bare-policy)) (crc-of bare-policy))

# --- 3. Negative origin, and the exact boundary -----------------------
(print "\nnegative origin and boundary:")

(defn cell-of [wx wz] (let [a (tc/climate-at-world cache1 wx wz)] [(a :x) (a :z)]))
(check "world -16 -> (0,0) and -1 -> (15,0) across the chunk"
       (and (= [0 0] (cell-of -16 0)) (= [15 0] (cell-of -1 0))))
(check "world 0 -> (16,0) and 15 -> (31,0) in the second chunk"
       (and (= [16 0] (cell-of 0 0)) (= [31 0] (cell-of 15 0))))
(check "the z axis covers 0..15 and stops at 16"
       (and (= 15 (let [a (tc/climate-at-world cache1 -16 15)] (a :z)))
            (= :outside-map ((tc/climate-at-world cache1 -16 16) :reason))))
# One step past the low edge, and one past the high edge: never clamped inward.
(check "world -17 and 16 are outside the map on both sides"
       (and (= :outside-map ((tc/climate-at-world cache1 -17 0) :reason))
            (= :outside-map ((tc/climate-at-world cache1 16 0) :reason))))

# --- 4. attach's own validation, on a table with no file behind it -----
#
# `attach-climate!` is the validation authority; driving it with a minimal cache
# table exercises every refusal without touching the filesystem. Each case gets a
# FRESH table, so no state from an earlier attach can mask the check.
(print "\nattach validation (no file):")

(defn table-cache [] @{:bounds map-bounds :origin map-origin :climate nil :closed false})
(def decoded (tc/attach-climate (table-cache) grid1 grid-shape meta))

(check "a minimal table accepts the projection the map declares"
       (= :present ((tc/attach-climate! (table-cache) decoded map-origin 1) :status)))
(check "a wrong origin is refused, not silently reprojected"
       (let [r (protect (tc/attach-climate! (table-cache) decoded [-32 0] 1))]
         (and (not (r 0)) (truthy? (string/find "origin x" (string (r 1)))))))
(check "a grid that leaves a remainder is refused rather than resampled"
       (let [r (protect (tc/attach-climate! (table-cache) decoded map-origin 2))]
         (and (not (r 0))
              (truthy? (string/find "cover the map exactly" (string (r 1)))))))
(check "a non-integer scale is refused"
       (let [r (protect (tc/attach-climate! (table-cache) decoded map-origin 1.5))]
         (and (not (r 0)) (truthy? (string/find "positive integer" (string (r 1)))))))
(check "a legacy cache cannot take climate at all"
       (let [r (protect (tc/attach-climate! @{:bounds nil :origin nil :climate nil}
                                            decoded map-origin 1))]
         (and (not (r 0)) (truthy? (string/find "bounded scenic cache" (string (r 1)))))))

(each d scratch-roots (rm-tree d))
(print "")
(if (zero? failures)
  (print "ALL CHECKS PASSED  (0 failures)")
  (do (printf "FAILURES: %d" failures) (os/exit 1)))
