# Headless checks for the loading screen's presentation logic.
#
# Nothing here opens a window, touches a GPU, or needs an image on disk. The
# point of splitting the module the way it is split -- pure geometry, pure text,
# pure discovery, and only then raylib -- is that every claim worth checking is
# checkworthy without a GL context. What CANNOT be checked here is that a
# texture actually renders; that is called out in the commit and must be
# confirmed in the first windowed run.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/loading-screen-test.janet

(import ./../src/loading-screen :as ls)
(import ./../src/rl :as rl)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(defn approx= [a b &opt eps]
  (<= (math/abs (- a b)) (or eps 0.51)))

#
# --- Cover crop ---------------------------------------------------------
#
(print "cover crop:")

# The shipped case: every supplied background is 2752x1536 at 16:9, the window
# is 1280x800 at 16:10. Cover must keep the FULL height and crop horizontally,
# which is the only crop that does not letterbox and does not distort.
(def r (ls/cover 2752 1536 1280 800))
(check "2752x1536 -> 1280x800 keeps full height"
       (approx= (r 3) 1536) (string (r 3)))
(check "2752x1536 -> 1280x800 crops 147px from each side"
       (approx= (r 0) 147.2) (string (r 0)))
(check "cropped width is 2458"
       (approx= (r 2) 2457.6) (string (r 2)))
(check "no vertical crop" (zero? (r 1)))

# A portrait source into a landscape frame must crop VERTICALLY instead -- the
# opposite axis -- or the image would be squashed.
(def p (ls/cover 1000 2000 1280 800))
(check "portrait source crops vertically" (pos? (p 1)) (string (p 1)))
(check "portrait source keeps full width" (approx= (p 2) 1000) (string (p 2)))
(check "portrait source crops height to 625" (approx= (p 3) 625) (string (p 3)))

# Identical aspect: nothing to crop, the source rect is the whole image.
(def same (ls/cover 1600 1000 1280 800))
(check "matching 16:10 aspect keeps full width" (approx= (same 2) 1600))
(check "matching 16:10 aspect keeps full height" (approx= (same 3) 1000))

# Degenerate input must not divide by zero. Returning the whole source rect is
# a defensible answer; NaN is not.
(def zero (ls/cover 0 0 1280 800))
(check "zero-sized source yields a zero rect, not NaN"
       (and (zero? (zero 2)) (zero? (zero 3))))
(def no-dst (ls/cover 2752 1536 0 800))
(check "zero-width destination yields the full source"
       (and (approx= (no-dst 2) 2752) (approx= (no-dst 3) 1536)))

(print "\ncover crop always stays inside the image:")
# Sweep, because a crop that escapes the bounds is the one bug that produces a
# smear of edge pixels rather than an obvious crash.
(def srcs [[2752 1536] [800 1200] [16 16] [1 5000] [5000 1]])
(def dsts [[1280 800] [1920 1080] [800 1280] [1 1] [100 50]])
(var in-bounds true)
(var bad nil)
(each [sw sh] srcs
  (each [dw dh] dsts
    (def [sx sy cw ch] (ls/cover sw sh dw dh))
    (unless (and (>= sx -0.001) (>= sy -0.001)
                 (<= (+ sx cw) (+ sw 0.001))
                 (<= (+ sy ch) (+ sh 0.001))
                 (>= cw 0) (>= ch 0))
      (set in-bounds false)
      (set bad (string sw "x" sh " -> " dw "x" dh
                       " gave " sx " " sy " " cw " " ch)))))
(check "every source rect is inside its image" in-bounds bad)

#
# --- Slideshow cycle ----------------------------------------------------
#
(print "\nslideshow cycle (8s period, 1s fade, 4 images):")

(defn alpha [t] (get (ls/cycle-position t 8 1 4) 1))
(defn index [t] (get (ls/cycle-position t 8 1 4) 0))

(check "t=0 shows image 0 fully" (and (= 0 (index 0)) (= 255 (alpha 0))))
(check "t=6.9 still fully opaque" (= 255 (alpha 6.9)))
(check "t=7.0 is the last opaque instant" (= 255 (alpha 7.0)))
(check "t=7.5 is mid-fade" (and (> (alpha 7.5) 0) (< (alpha 7.5) 255))
       (string (alpha 7.5)))
(check "t=8 has advanced to image 1" (and (= 1 (index 8)) (= 255 (alpha 8))))
(check "t=16 has advanced to image 2" (and (= 2 (index 16)) (= 255 (alpha 16))))

# The fade must be MONOTONE: an alpha that dips and recovers would read as a
# flicker rather than a crossfade.
(def fade-alphas (map alpha [7.0 7.2 7.4 7.6 7.8 7.99]))
(var monotone true)
(var prev 256)
(each a fade-alphas
  (when (> a prev) (set monotone false))
  (set prev a))
(check "alpha decreases monotonically through the fade" monotone
       (string/format "%j" fade-alphas))

# Continuity across the boundary is the property that separates a real
# crossfade from a flash: the index owned by the cycle must not change mid-fade,
# so the incoming slide (index+1) fades in and is then simply "the current
# slide" at the next boundary with no alpha jump.
(check "index does not change during the fade"
       (and (= 0 (index 7.0)) (= 0 (index 7.5)) (= 0 (index 7.99)))
       (string (index 7.99)))
(check "the incoming slide is the next index"
       (= 1 (mod (+ (index 7.5) 1) 4)))

# Wrap: 64s is exactly 8 cycles on a 4-image set.
(check "t=64 wraps to image 0" (and (= 0 (index 64)) (= 255 (alpha 64))))
(check "t=32 wraps to image 0" (= 0 (index 32)))

# Robustness. A clock reset (negative elapsed), a zero count, a zero cycle and
# a fade longer than the cycle must all produce something drawable rather than
# an error or a NaN.
(check "negative elapsed is treated as 0" (= 255 (alpha -5)))
(check "zero image count degrades to index 0" (= 0 (index 3)))
(check "zero cycle degrades safely" (= 255 (alpha 3)))
(def long-fade (ls/cycle-position 0.5 2 10 4))
(check "fade longer than cycle is clamped, not negative"
       (and (>= (long-fade 1) 0) (<= (long-fade 1) 255))
       (string (long-fade 1)))

# Alpha is a byte everywhere: rl's Color is uchar, so 256 would wrap to 0 and
# an image would vanish for a frame.
(defn integral? [x] (and (number? x) (= x (math/floor x))))

(var alpha-ok true)
(var alpha-bad nil)
(for i 0 400
  (def a (alpha (* i 0.1)))
  (unless (and (integral? a) (>= a 0) (<= a 255))
    (set alpha-ok false) (set alpha-bad a)))
(check "alpha is always an integer 0..255" alpha-ok (string alpha-bad))

(var index-ok true)
(var index-bad nil)
(for i 0 400
  (def x (index (* i 0.1)))
  (unless (and (integral? x) (>= x 0) (< x 4))
    (set index-ok false) (set index-bad x)))
(check "index is always an integer in range" index-ok (string index-bad))

#
# --- Progress bar -------------------------------------------------------
#
(print "\nprogress bar (measured readiness only):")
(check "0 of 25 is empty" (zero? (ls/bar-frac 0 25)))
(check "7 of 25 is 0.28" (approx= (ls/bar-frac 7 25) 0.28 0.001))
(check "25 of 25 is full" (= 1 (ls/bar-frac 25 25)))
(check "ready greater than total clamps to 1" (= 1 (ls/bar-frac 30 25)))
(check "zero total yields 0, no division by zero" (zero? (ls/bar-frac 0 0)))
(check "negative ready yields 0" (zero? (ls/bar-frac -3 25)))
(check "a full bar fills the whole width" (= 420 (ls/bar-fill 25 25 420)))
(check "an empty bar fills nothing" (zero? (ls/bar-fill 0 25 420)))

#
# --- Elapsed clock ------------------------------------------------------
#
(print "\nelapsed clock:")
(check "0 -> 0:00" (= "0:00" (ls/format-elapsed 0)))
(check "5 -> 0:05" (= "0:05" (ls/format-elapsed 5)))
(check "94.4 -> 1:34" (= "1:34" (ls/format-elapsed 94.4)))
(check "3599 -> 59:59" (= "59:59" (ls/format-elapsed 3599)))
# Minutes must not wrap: a cold bake runs long, and "0:12" after 60 minutes
# would be a lie about how long the user has waited.
(check "3600 -> 60:00, minutes do not wrap" (= "60:00" (ls/format-elapsed 3600)))
(check "negative clamps to 0:00" (= "0:00" (ls/format-elapsed -4)))

#
# --- Word wrap (error text) ---------------------------------------------
#

(defn as-ascii-ok?
  "True when every BYTE of `s` is printable ASCII (raylib draws only those)."
  [s]
  (all |(and (>= $ 32) (<= $ 126)) (string/bytes (string s))))
(print "\nerror text wrapping:")
(def short (ls/wrap-text "boom" 20 4))
(check "short text stays on one line" (and (= 1 (length short))
                                           (= "boom" (short 0))))
(def wrapped (ls/wrap-text "the terrain worker exited before it published a tile"
                           20 10))
(check "long text wraps on spaces" (> (length wrapped) 1)
       (string (length wrapped)))
(var all-fit true)
(each line wrapped
  (when (> (length line) 20) (set all-fit false)))
(check "no wrapped line exceeds the width" all-fit)

# A single overlong token -- a path, a stack frame -- must be hard-broken, or
# it runs off the window.
(def long-token (ls/wrap-text "/Users/someone/a/very/long/path/that/never/ends" 12 8))
(var token-fit true)
(each line long-token
  (when (> (length line) 12) (set token-fit false)))
(check "an overlong token is hard-broken" token-fit
       (string/format "%j" long-token))

(def bounded (ls/wrap-text
               "one two three four five six seven eight nine ten eleven twelve"
               10 3))
(check "output is capped at max-lines" (= 3 (length bounded))
       (string (length bounded)))
# Three ASCII dots, NOT U+2026: raylib's default font is the 224-glyph ASCII
# set, so a typographic ellipsis draws nothing and the truncation becomes
# invisible -- the opposite of the intent.
(check "truncation is visible with an ASCII ellipsis"
       (string/has-suffix? "..." (last bounded)) (last bounded))
(check "the truncated line is plain ASCII"
       (as-ascii-ok? (last bounded)) (string/format "%j" (last bounded)))

(check "empty input still yields one line"
       (and (= 1 (length (ls/wrap-text "" 20 4)))
            (= "" ((ls/wrap-text "" 20 4) 0))))
(check "nil input still yields one line"
       (= 1 (length (ls/wrap-text nil 20 4))))
(check "a long word list never yields an empty result"
       (pos? (length (ls/wrap-text "a b c d e f g h" 4 2))))

#
# --- Discovery (filesystem only) ----------------------------------------
#
(print "\ndiscovery:")
(def tmp-root (string "/tmp/trinecraft-loading-" (os/getpid)))
(def tmp-assets (string tmp-root "/assets"))

(defn cleanup []
  (each f (try (os/dir tmp-assets) ([_] @[]))
    (os/rm (string tmp-assets "/" f)))
  (os/rmdir tmp-assets)
  (os/rmdir tmp-root))

# An absent assets directory is the NORMAL case for a fresh clone (the shipped
# assets are gitignored), so it must yield an empty list rather than throw.
(check "missing directory yields an empty list"
       (empty? (ls/discover (string tmp-root "/nope") 4)))
(check "missing assets dir does not throw"
       (empty? (ls/resolve-paths {:root tmp-root})))

# Build a real directory: four GAME-art names, one non-image, one uppercase.
# Security/curation rule under test here is only "does the extension and the
# name prefix admit it" -- the exclusion of foreign art is covered separately.
(os/mkdir tmp-root)
(os/mkdir tmp-assets)
(each f ["Gemini_Generated_Image_b.png" "Gemini_Generated_Image_a.jpg"
         "notes.txt" "Gemini_Generated_Image_C.PNG"
         "Gemini_Generated_Image_d.webp"]
  (spit (string tmp-assets "/" f) "not really an image"))

(def found (ls/discover tmp-assets 10))
(check "only curated game images are picked up"
       (= 4 (length found)) (string/format "%j" found))
(check "results are sorted by name"
       (= found (sort found)) (string/format "%j" found))
(check "assets directory is used when no :paths given"
       (= 4 (length (ls/resolve-paths {:root tmp-root :max-images 10}))))

(def capped (ls/discover tmp-assets 2))
(check "max-images truncates" (= 2 (length capped)) (string/format "%j" capped))
(check "truncation keeps the sorted head" (= (get found 0) (get capped 0)))
(check "max-images 0 yields nothing" (empty? (ls/discover tmp-assets 0)))

# Explicit paths: nonexistent entries are dropped at CONSTRUCTION, not at draw
# time, so a misconfigured flag costs one startup warning instead of a failure
# on every frame forever.
(def explicit (ls/resolve-paths
                {:paths [(string tmp-assets "/Gemini_Generated_Image_a.jpg")
                         (string tmp-assets "/Gemini_Generated_Image_missing.png")
                         (string tmp-assets "/Gemini_Generated_Image_b.png")]}))
(check "nonexistent explicit paths are dropped" (= 2 (length explicit))
       (string/format "%j" explicit))
(check "existing explicit paths survive in order"
       (= (string tmp-assets "/Gemini_Generated_Image_a.jpg") (get explicit 0)))

(check "an empty :paths list falls back to directory discovery"
       (= 4 (length (ls/resolve-paths {:paths [] :root tmp-root
                                       :max-images 10}))))
(cleanup)

#
# --- Construction is window-free ---------------------------------------
#
(print "\nconstruction without a GL context:")
# `new` must not touch raylib at all: the caller has to be able to build the
# screen before the window exists, which is the ordering the loading stage
# needs. Reaching this line at all proves no texture was decoded.
(def screen (ls/new {:root "/nonexistent-root"}))
(check "new succeeds with no assets and no window" (not (nil? screen)))
(check "a missing root reports the gradient path"
       (true? (ls/fallback? screen)))
(check "no textures are loaded before the first draw"
       (zero? (ls/loaded-count screen)))
(check "the path list is empty rather than nil"
       (and (indexed? (ls/paths screen)) (empty? (ls/paths screen))))
(check "dispose is safe before any draw"
       (do (ls/dispose screen) (zero? (ls/loaded-count screen))))
(check "dispose is idempotent"
       (do (ls/dispose screen) (ls/dispose screen) (true? (ls/fallback? screen))))

(def tuned (ls/new {:root "/nonexistent-root" :cycle-seconds 12
                    :fade-seconds 2 :max-images 2}))
(check "cycle-seconds is honoured" (= 12 (tuned :cycle-seconds)))
(check "fade-seconds is honoured" (= 2 (tuned :fade-seconds)))

(def defaulted (ls/new))
(check "cycle defaults to 8 seconds" (= 8 (defaulted :cycle-seconds)))
(check "fade defaults to 1 second" (= 1 (defaulted :fade-seconds)))

# A nonsensical cycle must not divide by zero; it falls back to the default.
(def bad-cycle (ls/new {:cycle-seconds 0}))
(check "a zero cycle-seconds falls back to 8" (= 8 (bad-cycle :cycle-seconds)))

# `draw` must return WITHOUT drawing when the framebuffer is not ready: the
# window may be minimised or not yet created, and a zero divisor would put NaN
# into the cover-crop. This is the one draw-path branch reachable with no GL
# context at all -- it must not reach raylib.
(check "draw with a zero-sized framebuffer is a no-op"
       (do (ls/draw (ls/new {:root "/nonexistent-root"}) {} 0 0) true))
(check "draw with a negative framebuffer is a no-op"
       (do (ls/draw (ls/new {:root "/nonexistent-root"}) {} -5 800) true))
(check "draw with no view table at all is a no-op"
       (do (ls/draw (ls/new {:root "/nonexistent-root"}) nil 0 0) true))


#
# --- REAL ASSET PROOF ---------------------------------------------------
#
# Everything above is synthetic. These two sections exist because the screen
# ships with four specific local images and the drawing path depends on FFI
# marshalling that no synthetic test can exercise. Both are still headless:
# LoadImage decodes on the CPU, and CheckCollisionRecs takes Rectangles by
# value on the CPU, exactly as DrawTexturePro does on the GPU.
#
(print "\nreal assets in the repository:")

(def repo-assets
  "/Users/pankajdoharey/Development/Projects/ML/trinecraft/assets")

(def shipped (ls/discover repo-assets 4))
(check "the four shipped backgrounds are discovered" (= 4 (length shipped))
       (string/format "%j" shipped))
(check "every discovered path exists"
       (all |(os/stat $) shipped))
(check "discovery is sorted"
       (= shipped (sort shipped)))
(check "all four are PNG as required"
       (all |(string/has-suffix? ".png" (string/ascii-lower $)) shipped)
       (string/format "%j" shipped))

# The exact path the user specified must be the default root behaviour.
(def by-root (ls/new {:root "/Users/pankajdoharey/Development/Projects/ML/trinecraft"}))
(check "new with the repo root finds all four" (= 4 (length (ls/paths by-root)))
       (string/format "%j" (ls/paths by-root)))
(check "paths are the real files, not placeholders"
       (all |(os/stat $) (ls/paths by-root)))

(print "\nraw texture decode (CPU, no GL context):")
# LoadImage needs no window. This is the strongest headless evidence available
# that a real PNG reaches raylib's decoder and comes back with real pixels.
(def decoded @[])
(each path shipped
  (def img (try (rl/load-image path) ([err] nil)))
  (when (and img (not (nil? (get img 0))))
    (array/push decoded @{:path path
                          :w (get img 1)
                          :h (get img 2)
                          :fmt (get img 4)})))
(check "all four assets decode with a non-null data pointer"
       (= 4 (length decoded)) (string (length decoded)))
(check "every decoded image is 2752x1536"
       (all |(and (= 2752 ($ :w)) (= 1536 ($ :h))) decoded)
       (string/format "%j" (map |[($ :w) ($ :h)] decoded)))
(check "every decoded image is RGBA (fmt 7)"
       (all |(= 7 ($ :fmt)) decoded))
# The cover crop must be computable from the size that actually came back, not
# from a number someone typed into the test.
(each d decoded
  (def [sx sy sw sh] (ls/cover (d :w) (d :h) 1280 800))
  (check (string "crop fits " (last (string/split "/" (d :path))))
         (and (>= sx 0) (>= sy 0)
              (<= (+ sx sw) (+ (d :w) 0.001))
              (<= (+ sy sh) (+ (d :h) 0.001)))))

(print "\nby-value Rectangle marshalling (the DrawTexturePro path):")
# DrawTexturePro passes two Rectangles BY VALUE. Until now that was untested:
# every other by-value struct in rl.janet is a return type or a pointer. We
# prove the calling convention here on the CPU with CheckCollisionRecs, which
# has the identical two-Rectangle-by-value signature.
(def rl-native (ffi/native (rl/find-raylib)))
(def rect-hits
  (ffi/lookup rl-native "CheckCollisionRecs"))
(def rect-sig (ffi/signature :default :bool rl/rect-type rl/rect-type))
(defn rect-overlap? [a b] (ffi/call rect-hits rect-sig a b))
(check "two overlapping Rectangles marshal by value"
       (rect-overlap? [0 0 10 10] [5 5 10 10]))
(check "two disjoint Rectangles marshal by value"
       (not (rect-overlap? [0 0 10 10] [100 100 10 10])))
(check "touching edges do not overlap"
       (not (rect-overlap? [0 0 10 10] [10 0 10 10])))
# Fractional coordinates are what a real cover-crop produces (147.2, 2457.6),
# so the float path -- not just the integer path -- must be exercised.
(check "fractional Rectangle coordinates marshal correctly"
       (rect-overlap? [0.5 0.5 9.5 9.5] [4.5 4.5 20.0 20.0]))
(def cropped (ls/cover 2752 1536 1280 800))
(check "the real crop rect is accepted by a by-value Rectangle call"
       (rect-overlap? cropped [0 0 1280 800]))


#
# --- Foreground legibility (measured, not asserted) ---------------------
#
# A loading screen is unreadable exactly when nobody checked. These pin WCAG
# contrast for every text colour over the WORST background that can actually
# occur: the brightest of the four supplied images (208/255), under the scrim
# alphas the module now uses. If someone lightens a scrim or darkens the muted
# grey, this fails instead of shipping a screen that looks fine on one photo.
#
(print "\nforeground legibility (WCAG contrast over the brightest asset):")

(defn- srgb-lin [c]
  (def v (/ c 255))
  (if (<= v 0.03928) (/ v 12.92) (math/pow (/ (+ v 0.055) 1.055) 2.4)))

(defn relative-luminance [rgb]
  (+ (* 0.2126 (srgb-lin (get rgb 0)))
     (* 0.7152 (srgb-lin (get rgb 1)))
     (* 0.0722 (srgb-lin (get rgb 2)))))

(defn contrast-ratio [fg bg]
  (def a (relative-luminance fg))
  (def b (relative-luminance bg))
  (def hi (max a b))
  (def lo (min a b))
  (/ (+ hi 0.05) (+ lo 0.05)))

(defn- over-black [rgb alpha]
  "rgb composited over black at `alpha` -- what a scrim leaves behind."
  (def a (/ alpha 255))
  (tuple (* (get rgb 0) (- 1 a)) (* (get rgb 1) (- 1 a)) (* (get rgb 2) (- 1 a))))

(def brightest-asset-luma 208)          # measured from hunr1nhunr1nhunr.png
(def brightest [brightest-asset-luma brightest-asset-luma brightest-asset-luma])

# The module's actual scrim alphas.
(def left-scrim-alpha 0xbe)
(def bottom-scrim-alpha 0xbe)
(def left-bg (over-black brightest left-scrim-alpha))
(def bottom-bg (over-black brightest bottom-scrim-alpha))

(defn rgb3 [c] (tuple (get c 0) (get c 1) (get c 2)))

# Large text (>=24px) needs 3.0; normal text needs 4.5.
(check "title (34px) reaches AAA 7:1 over the left scrim"
       (>= (contrast-ratio (rgb3 ls/col-title) left-bg) 7.0)
       (string/format "%.2f" (contrast-ratio (rgb3 ls/col-title) left-bg)))
(check "title reaches AAA 7:1 over the bottom scrim"
       (>= (contrast-ratio (rgb3 ls/col-title) bottom-bg) 7.0)
       (string/format "%.2f" (contrast-ratio (rgb3 ls/col-title) bottom-bg)))
(check "stage line reaches AA 4.5:1 over the left scrim"
       (>= (contrast-ratio (rgb3 ls/col-stage) left-bg) 4.5)
       (string/format "%.2f" (contrast-ratio (rgb3 ls/col-stage) left-bg)))
(check "subtitle reaches AA 4.5:1 over the left scrim"
       (>= (contrast-ratio (rgb3 ls/col-subtitle) left-bg) 4.5)
       (string/format "%.2f" (contrast-ratio (rgb3 ls/col-subtitle) left-bg)))
# `muted` is the 16px footer/hint, the smallest text on the screen, so it must
# clear the full 4.5 rather than the large-text 3.0.
(check "muted body text reaches AA 4.5:1 over the left scrim"
       (>= (contrast-ratio (rgb3 ls/col-muted) left-bg) 4.5)
       (string/format "%.2f" (contrast-ratio (rgb3 ls/col-muted) left-bg)))
(check "muted body text reaches AA 4.5:1 over the bottom scrim"
       (>= (contrast-ratio (rgb3 ls/col-muted) bottom-bg) 4.5)
       (string/format "%.2f" (contrast-ratio (rgb3 ls/col-muted) bottom-bg)))
(check "error text reaches AA 4.5:1 over the left scrim"
       (>= (contrast-ratio (rgb3 ls/col-error) left-bg) 4.5)
       (string/format "%.2f" (contrast-ratio (rgb3 ls/col-error) left-bg)))
(check "body text reaches AA 4.5:1 over the left scrim"
       (>= (contrast-ratio (rgb3 ls/col-text) left-bg) 4.5)
       (string/format "%.2f" (contrast-ratio (rgb3 ls/col-text) left-bg)))

# The fallback gradient must be legible on its own, since a fresh clone sees
# only that. Its darkest end is the binding constraint.
(def grad-bg (rgb3 ls/col-grad-bottom))
(each [name color] [[:title ls/col-title] [:subtitle ls/col-subtitle]
                    [:stage ls/col-stage] [:text ls/col-text]
                    [:muted ls/col-muted] [:error ls/col-error]]
  (check (string "fallback gradient bottom clears AA for " name)
         (>= (contrast-ratio (rgb3 color) grad-bg) 4.5)
         (string/format "%.2f" (contrast-ratio (rgb3 color) grad-bg))))


#
# --- Stage labels (never show the state machine to the user) ------------
#
(print "\nstage labels:")
# The bug this pins: rendering the internal keyword produced "WAIT", which
# reads as an instruction. Every loading state must read as a description.
(check "await reads as Generating terrain, not WAIT"
       (= "Generating terrain" (ls/stage-text {:stage :await})))
(check "wait also reads as Generating terrain"
       (= "Generating terrain" (ls/stage-text {:stage :wait})))
(check "await-tiles reads as Generating terrain"
       (= "Generating terrain" (ls/stage-text {:stage :await-tiles})))
(check "build-world reads as Building the world"
       (= "Building the world" (ls/stage-text {:stage :build-world})))
# A string stage must map the same way as its keyword, because the caller may
# pass either after reading a config file.
(check "a string stage maps like its keyword"
       (= "Generating terrain" (ls/stage-text {:stage "await"})))
# An unmapped keyword must not lose its first letter or shout.
(check "an unmapped keyword is title-cased, keeping its first letter"
       (= "Some new state" (ls/stage-text {:stage :some_new_state}))
       (ls/stage-text {:stage :some_new_state}))
(check "a nil stage renders nothing"
       (= "" (ls/stage-text {:stage nil})))
(check "no stage renders nothing" (= "" (ls/stage-text {})))
# A non-string, non-keyword stage must not throw on the draw path.
(check "a numeric stage is ignored rather than crashing"
       (= "" (ls/stage-text {:stage 42})))

#
# --- Incremental decode (first frame must not stall) --------------------
#
(print "\nincremental decode:")
# The supplied PNGs are ~8.8 MB each and 2752x1536; decoding all four is
# ~0.5 s. Paying that in the frame the window first appears is the hitch the
# loading screen exists to avoid, so `draw` decodes ONE per frame.
#
# Decode needs a GL context, so the counter behaviour is checked through the
# state the function maintains rather than by calling it: a screen with no
# paths has nothing to decode, which must leave `:next-path` untouched and not
# spin.
(def bare (ls/new {:root "/nonexistent-root"}))
(check "a screen with no candidate paths loads zero"
       (zero? (ls/ensure-loaded bare 1280 800 1)))
(check "and stays in the gradient fallback"
       (true? (ls/fallback? bare)))
(check "a second call is still zero and does not throw"
       (zero? (ls/ensure-loaded bare 1280 800 1)))
# The cursor must not advance past a list it exhausted, or a later call would
# read out of bounds.
(def with-paths (ls/new {:paths ["/tmp/definitely-not-an-image-xyz.png"]}))
(check "a nonexistent explicit path is dropped before decode"
       (empty? (ls/paths with-paths)))
(check "so there is nothing to decode"
       (zero? (ls/ensure-loaded with-paths 1280 800 1)))
# With no window the decode is refused outright, so nothing is "attempted" --
# `:attempted` means "every candidate was tried against a live GPU", and
# claiming otherwise would hide the ordering mistake this guard exists to
# survive.
(check "nothing is attempted while the window is not ready"
       (false? (with-paths :attempted)))

# The regression that matters most here: `LoadTextureFromImage` with no window
# does not raise, it SEGFAULTS -- raylib logs "GPU is not ready" and then
# dereferences a null GL pointer. A `try` cannot catch that, so the guard is a
# readiness check, and reaching the next line at all proves it held. This test
# crashed the interpreter before the guard existed.
(def no-window (ls/new
                 {:root "/Users/pankajdoharey/Development/Projects/ML/trinecraft"}))
(check "loading with a real asset but no window returns without crashing"
       (zero? (ls/ensure-loaded no-window 1280 800 1)))
(check "and the cursor did not advance into the decode"
       (or (nil? (no-window :next-path)) (zero? (no-window :next-path)))
       (string (no-window :next-path)))
(check "and the screen still reports the gradient fallback"
       (true? (ls/fallback? no-window)))
# Repeated calls must stay a no-op rather than eventually reaching the decode.
(check "repeated GL-less calls stay no-ops"
       (and (zero? (ls/ensure-loaded no-window 1280 800 1))
            (zero? (ls/ensure-loaded no-window 1280 800 4))))


#
# --- Default-font safety (raylib draws only ASCII) ----------------------
#
(print "\ndefault-font safety:")
# raylib's GetFontDefault is a 224-glyph ASCII bitmap font. Any codepoint above
# it simply does not draw, which is silent: the text appears to end early. That
# turned an em dash into "Generating terrain ? 0 requested" on a real screen.
# These pin every string the module emits to the printable ASCII range.
(defn ascii-only? [s] (as-ascii-ok? s))

(check "a wrapped error message is ASCII only"
       (ascii-only? (string/join (ls/wrap-text
                                   "the terrain worker exited unexpectedly while "
                                   20 4)
                                 " ")))
(check "stage labels are ASCII only"
       (all |(ascii-only? (ls/stage-text {:stage $}))
            [:probe :await :wait :await-tiles :build-world :build-meshes
             :meshing :ready :failed :cancelled :timed-out :unmapped_state]))
(check "the elapsed clock is ASCII only"
       (ascii-only? (ls/format-elapsed 94.4)))
(check "a long token truncation marker is ASCII only"
       (ascii-only? (last (ls/wrap-text
                            "/a/very/long/path/that/never/ends/anywhere/at/all"
                            12 3))))


#
# --- Shared presenter (menu -> loading handoff) -------------------------
#
# The menu and the loading screen must paint from ONE screen value: one decode,
# one slideshow clock, one texture set. If `main` built a second one at handoff
# the artwork would restart, so these pin the parts of the contract that are
# testable without a GPU -- the clock lives in the value, and painting advances
# it, so handing the same value across keeps time continuous.
#
(print "\nshared presenter:")

(defn- ticked
  "A screen whose clock has been advanced directly, standing in for frames."
  [screen seconds]
  (put screen :elapsed (+ (screen :elapsed) seconds))
  screen)

(def shared (ls/new {:root "/nonexistent-root"}))
(check "the clock lives in the screen value, not in module state"
       (number? (shared :elapsed)))
(def before (shared :elapsed))
(ticked shared 1.5)
(check "advancing the same value carries the clock forward"
       (> (shared :elapsed) before))
# The point of the shared value: a handoff does not reset the cycle.
(def cycle-index (get (ls/cycle-position (shared :elapsed) 8 1 4) 0))
(check "a handed-over clock resumes at the same slide"
       (= cycle-index (get (ls/cycle-position (shared :elapsed) 8 1 4) 0)))

# paint-background and paint-scrim must exist and be callable without a window:
# the guard returns before any GL call, which is what lets `main` paint the menu
# before anything is loaded.
# Without a window these must return WITHOUT touching raylib. That is not a
# nicety: `draw-rectangle-gradient-v` is a GL call that SEGFAULTS with no
# context -- raylib dereferences a null GL pointer instead of raising, so a
# `try` cannot catch it. This test crashed the interpreter before the guard.
(check "paint-background is a no-op before the window exists"
       (zero? (ls/paint-background (ls/new {:root "/nonexistent-root"}) 1280 800)))
(check "paint-background is a no-op for a zero-sized framebuffer"
       (zero? (ls/paint-background shared 0 0)))
(check "paint-scrim returns without crashing before a window exists"
       (nil? (ls/paint-scrim 1280 800)))
(check "paint-scrim is a no-op for a zero-sized framebuffer"
       (nil? (ls/paint-scrim 0 0)))

# dispose must be safe on the shared value after both screens have used it, and
# twice -- main disposes once at quit, and a failed handoff may also dispose.
(check "dispose on a shared presenter is idempotent"
       (do (ls/dispose shared) (ls/dispose shared) (true? (ls/fallback? shared))))
(check "disposing does not clear the path list the menu may still read"
       (indexed? (ls/paths shared)))

# Bounded ownership: a screen built with no assets loads nothing, and asking for
# more frames of decode does not accumulate textures.
(def bounded (ls/new {:root "/nonexistent-root"}))
(for i 0 5 (ls/ensure-loaded bounded 1280 800 1))
(check "repeated decodes with no assets load nothing and do not accumulate"
       (zero? (ls/loaded-count bounded)))


#
# --- Home artwork and the live loading bar ------------------------------
#
(print "\nhome artwork:")

# The home art is a SEPARATE, single texture. It must never appear in the
# slideshow rotation: the main image has its logo and characters composed into
# it, so rotating it would move a logo the artwork fixed in place.
(check "the default main-art path is the dedicated poster"
       (= "assets/Trinexraft_main.png" ls/default-main-art))
(check "new() reports that default without touching the filesystem"
       (= "assets/Trinexraft_main.png"
          ((ls/new {:root "/nonexistent-root"}) :main-art)))
(check "main-art is overridable"
       (= "x/y.png" ((ls/new {:main-art "x/y.png"}) :main-art)))

# A screen with no assets still has zero slides AND no main texture -- distinct
# fields, so "no slideshow" and "no home art" cannot be confused.
(def no-assets (ls/new {:root "/nonexistent-root"}))
(check "no slideshow textures on a bare screen" (zero? (ls/loaded-count no-assets)))
(check "no main texture on a bare screen" (nil? (no-assets :main-texture)))
(check "main-art decode is a no-op before the window exists"
       (nil? (ls/ensure-main-loaded no-assets 1280 800)))
(check "and it did not claim the decode was attempted"
       (false? (no-assets :main-attempted)))
(check "paint-main-background is a no-op before the window exists"
       (zero? (ls/paint-main-background no-assets 1280 800)))

# dispose owns both: a second call must stay a no-op even after a main-art
# attempt, so the exit path cannot double-unload.
(check "dispose covers main art and stays idempotent"
       (do (ls/dispose no-assets) (ls/dispose no-assets)
           (nil? (no-assets :main-texture))))

(print "\nlive loading bar:")

# Placement must follow the sample's proportions and survive a resize. The
# sample puts the bar at ~33-66% width and ~86-93% height.
(def g (ls/bar-geometry 1600 893))
(def gx (g 0)) (def gy (g 1)) (def gw (g 2)) (def gh (g 3))
(check "the bar is horizontally centred"
       (<= (math/abs (- (/ 1600 2) (+ gx (/ gw 2)))) 1)
       (string (+ gx (/ gw 2))))
(check "it starts near one third across"
       (and (>= (/ gx 1600) 0.30) (<= (/ gx 1600) 0.36))
       (string/format "%.3f" (/ gx 1600)))
(check "it ends near two thirds across"
       (and (>= (/ (+ gx gw) 1600) 0.64) (<= (/ (+ gx gw) 1600) 0.70))
       (string/format "%.3f" (/ (+ gx gw) 1600)))
(check "it sits in the lower band, not on the edge"
       (and (>= (/ gy 893) 0.84) (<= (/ gy 893) 0.92))
       (string/format "%.3f" (/ gy 893)))
(check "a narrow window still gets a bar of usable width"
       (let [n (ls/bar-geometry 640 480)] (>= (n 2) ls/bar-min-width))
       (string ((ls/bar-geometry 640 480) 2)))

# The fill is the caller's MEASURED fraction. What must never happen is a
# percentage invented for a job that has not reported a count.
(check "the bar fraction is the measured ratio"
       (= (ls/bar-frac 7 25) (ls/bar-frac 7 25)))
(check "an unreported total yields no fill, not a fake one"
       (zero? (ls/bar-frac 0 0)))

# The tip is a fact or an instruction, and must survive being absent.
(check "draw-tip tolerates nil" (nil? (ls/draw-tip 1280 800 nil)))
(check "draw-tip tolerates an empty string" (nil? (ls/draw-tip 1280 800 "")))


#
# --- Bar palette and contextual tips ------------------------------------
#
(print "\nbar palette:")

# The fill is cyan at the low end and purple at the high end, as the reference
# loader has it. The stone/moss FRAME is unchanged -- the frame reads as carved
# stone around a lit core, which is the look being matched.
(check "the fill starts cyan (blue and green high, red low)"
       (and (> (get ls/col-fill-cyan 2) 180) (> (get ls/col-fill-cyan 1) 180)
            (< (get ls/col-fill-cyan 0) 120)))
(check "the fill ends purple (red and blue high, green low)"
       (and (> (get ls/col-fill-purple 0) 100)
            (> (get ls/col-fill-purple 2) 200)
            (< (get ls/col-fill-purple 1) 140)))
(check "the two fill ends are visibly different colours"
       (> (math/abs (- (get ls/col-fill-cyan 0) (get ls/col-fill-purple 0))) 60))
# The frame is still stone/moss, NOT cyan: the frame and the fill must not
# converge or the bar loses its carved border.
(check "the frame stays neutral stone, not cyan"
       (< (math/abs (- (get ls/col-frame-inner 0) (get ls/col-frame-inner 2))) 24))

(print "\ncontextual tips:")

# A tip must never describe work that is not happening. The old line claimed
# tiles take minutes even when the cache was already baked.
(check "nothing measured gets a generic gameplay tip"
       (string/find "Press F" (ls/choose-tip {})))
(check "a complete ready count does NOT claim generation is running"
       (let [t (ls/choose-tip {:ready 25 :total 25})]
         (and (not (string/find "several minutes" t))
              (string/find "Press F" t))))
(check "partway through says tiles are arriving"
       (let [t (ls/choose-tip {:ready 7 :total 25})]
         (and (not (string/find "several minutes" t))
              (string/find "arrive" t))))
(check "zero ready may say generation takes minutes"
       (string/find "several minutes" (ls/choose-tip {:ready 0 :total 25})))
# No tip may promise an ability the game does not have.
(check "no tip promises a conjuring or spell ability"
       (let [tip (ls/choose-tip {:ready 5 :total 25})]
         (and (not (string/find "conjure" tip))
              (not (string/find "spell" tip)))))
# And none may claim the artwork is a terrain preview.
(check "no tip claims the artwork shows the terrain"
       (let [tip (ls/choose-tip {})]
         (not (string/find "preview" tip))))

# Every tip must be ASCII: the default font cannot draw anything else, and a
# tip that half-renders is worse than no tip.
(check "every tip is plain ASCII"
       (all |(<= $ 126)
            (string/bytes
              (string/join (map ls/choose-tip
                                [{} {:ready 0 :total 25} {:ready 7 :total 25}
                                 {:ready 25 :total 25}])
                           " "))))


#
# --- Curated discovery: game art only -----------------------------------
#
# The asset ROOT can resolve from the executable rather than the repo. A
# permissive `*.png` scan then put a compiler checkout's mascot art on the
# loading screen -- a real reported bug, not a hypothetical. These pin the rule
# that a default slide is one of the four shipped backgrounds and nothing else.
#
(print "\ncurated discovery:")

(def real-assets "/Users/pankajdoharey/Development/Projects/ML/trinecraft/assets")
(def real-slides (ls/discover real-assets 4))
(check "the four shipped backgrounds are the only default slides"
       (= 4 (length real-slides)) (string (length real-slides)))
# Paths come back absolute, so the NAME rule is checked on the basename.
(check "every default slide is a Gemini game image"
       (all |(string/has-prefix? "Gemini_Generated_Image_"
                                 (last (string/split "/" $)))
            real-slides)
       (string/format "%j" real-slides))
(check "the main poster is NOT a slide"
       (not (some |(string/has-suffix? "Trinexraft_main.png" $) real-slides)))
(check "the loader sample is NOT a slide"
       (not (some |(string/has-suffix? "loader_sampel" $) real-slides)))

# A directory full of unrelated images must yield NOTHING, not "the best it can
# find". This is the exact failure: bender.png / janet-big.png in a compiler
# checkout's assets directory.
(defn temp-dir-with [names]
  (def d (string "/tmp/ls-curated-" (os/getpid)))
  (when-let [old (try (os/dir d) ([_] nil))] (each f old (os/rm (string d "/" f))))
  (os/mkdir d)
  (each n names (spit (string d "/" n) "x"))
  d)

(def foreign (temp-dir-with ["bender.png" "janet-big.png" "janet-w200.png" "icon.png"]))
(check "a foreign art directory yields no slides"
       (empty? (ls/discover foreign 4))
       (string/format "%j" (ls/discover foreign 4)))
(each f (try (os/dir foreign) ([_] @[])) (os/rm (string foreign "/" f)))
(os/rmdir foreign)

# Mixed directory: the game images survive, the foreign ones do not, and the
# two specially-purposed files are excluded even though they match the prefix
# pattern's neighbourhood.
(def mixed (temp-dir-with ["Gemini_Generated_Image_aaa.png"
                           "Gemini_Generated_Image_bbb.jpg"
                           "bender.png"
                           "Trinexraft_main.png"
                           "trineraft_main_loader_sampel.png"]))
(def mixed-found (ls/discover mixed 8))
(check "mixed directory keeps only the game slides"
       (= 2 (length mixed-found)) (string/format "%j" mixed-found))
(check "mixed directory drops the mascot art"
       (not (some |(string/find "bender" $) mixed-found)))
(check "mixed directory drops the main poster"
       (not (some |(string/find "Trinexraft_main" $) mixed-found)))
(check "mixed directory drops the loader sample"
       (not (some |(string/find "loader_sampel" $) mixed-found)))
(each f (try (os/dir mixed) ([_] @[])) (os/rm (string mixed "/" f)))
(os/rmdir mixed)

# A missing directory is graceful, not fatal: the gradient is the documented
# fallback and a fresh clone has no assets at all.
(check "a missing asset directory yields no slides"
       (empty? (ls/discover "/tmp/definitely-not-here-xyz" 4)))
(check "and a screen built from it reports the gradient path"
       (true? (ls/fallback? (ls/new {:asset-dir "/tmp/definitely-not-here-xyz"}))))

# Explicit paths are the documented override and must still be honoured even
# for a name discovery would refuse -- a caller who names a file gets that file.
(def explicit-target (string real-assets "/Trinexraft_main.png"))
(def explicit (ls/new {:paths [explicit-target]}))
(check "an explicit path bypasses curation"
       (= 1 (length (ls/paths explicit)))
       (string/format "%j" (ls/paths explicit)))


#
# --- Indeterminate progress (generation with no count) ------------------
#
# A generation phase reports a stage and a sentence but no `ready/total`. The
# screen must still show the styled bar, sweeping, with no percentage -- the old
# behaviour suppressed the bar entirely, which is why generation looked like a
# bare text screen.
#
(print "\nindeterminate progress:")

# The bar paints with no count at all. Assert on the geometry, which is what the
# painter returns and what a headless test can observe.
(def no-count (ls/bar-geometry 1600 893))
(check "bar geometry is available without any count"
       (= 4 (length no-count)))
(check "it keeps the sample placement"
       (and (>= (/ (get no-count 0) 1600) 0.30)
            (<= (/ (get no-count 0) 1600) 0.36)))

# The fraction must be zero when there is nothing to divide by: an invented
# fraction would be a fabricated progress claim.
(check "an absent total cannot yield a fraction"
       (zero? (ls/bar-frac 0 0)))
(check "a nil total cannot yield a fraction"
       (zero? (ls/bar-frac 7 nil)))

# The tip must not claim generation is running when a count says it is done.
(def done-tip (ls/choose-tip {:ready 25 :total 25 :stage :ready}))
(check "a finished count does not claim minutes of generation"
       (not (string/find "several minutes" done-tip)))

# A stage-only view is a legitimate input; it must not crash the painter's
# decisions anywhere they depend on the count.
(check "a stage-only view does not crash tip selection"
       (string? (ls/choose-tip {:stage :generating :detail "sampling"})))
(check "a stage-only view still gets a usable tip"
       (pos? (length (ls/choose-tip {:stage :generating}))))


#
# --- Unknown vs zero: what the bar CLAIMS ------------------------------
#
# `draw` calls the real raylib module for its gradient pass, so a whole frame
# cannot be rendered headlessly -- attempting it segfaults on a null GL pointer.
# The decision that matters lives in the bar's LABEL and FILL, which are pure
# functions of (ready, total). Those are asserted directly, which is stronger
# than a drawn-frame proxy: it pins the claim, not the pixels.
#
(print "\nunknown vs zero:")

(defn determinate?
  "The bar's own test for 'is there a denominator'."
  [total]
  (and (number? total) (pos? total)))

(check "a positive total is determinate" (determinate? 25))
(check "a nil total is NOT determinate" (not (determinate? nil)))
(check "a zero total is NOT determinate" (not (determinate? 0)))

# 0 of 25 is a MEASUREMENT of zero and must read 0%.
(check "0 of 25 yields a zero fraction"
       (zero? (ls/bar-frac 0 25)))
(check "and it is a real fraction, unlike an absent total"
       (and (determinate? 25) (not (determinate? 0))))

# An unknown total can never produce a percentage, which is the bug the parent
# reported: a generation view with no count must not show a fabricated number.
(check "no total cannot yield a percentage"
       (zero? (ls/bar-frac 7 nil)))
(check "zero total cannot yield a percentage"
       (zero? (ls/bar-frac 7 0)))
(check "a nil total does not crash the fraction"
       (number? (ls/bar-frac nil nil)))

# The bar geometry is still produced for an unknown view, so the caller gets a
# styled frame rather than a text-only screen.
(def unknown-geom (ls/bar-geometry 1600 893))
(check "geometry is available for an unknown-count frame"
       (= 4 (length unknown-geom)))
(check "and it keeps the sample placement"
       (and (>= (/ (get unknown-geom 0) 1600) 0.30)
            (<= (/ (get unknown-geom 0) 1600) 0.36)))


#
# --- Main-art path resolution -----------------------------------------
#
# The poster path must follow the caller's asset root, not the process cwd. A
# bare relative default would miss the game's artwork whenever the game is
# launched from anywhere but its own directory, which is how the mascot-art bug
# happened in the first place.
#
(print "\nmain-art resolution:")

(check "a bare screen still reports the documented default"
       (= "assets/Trinexraft_main.png" ((ls/new {}) :main-art)))
(check "the poster follows a supplied asset-dir"
       (= "/game/assets/Trinexraft_main.png"
          ((ls/new {:asset-dir "/game/assets"}) :main-art)))
(check "an explicit main-art still wins over the asset-dir"
       (= "/custom/T.png"
          ((ls/new {:asset-dir "/game/assets" :main-art "/custom/T.png"}) :main-art)))
(check "an empty asset-dir falls back to the default"
       (= "assets/Trinexraft_main.png" ((ls/new {:asset-dir ""}) :main-art)))
(check "the poster path is never the loader SAMPLE"
       (not (string/find "sampel" ((ls/new {:asset-dir "/game/assets"}) :main-art))))

#
# --- Result -------------------------------------------------------------
#
(print "")
(if (zero? failures)
  (print "ALL CHECKS PASSED  (0 failures)")
  (do (printf "FAILURES: %d" failures) (os/exit 1)))
