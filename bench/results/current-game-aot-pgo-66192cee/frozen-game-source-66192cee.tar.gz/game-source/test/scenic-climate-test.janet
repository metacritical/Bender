# Scenic climate attachment: the OPTIONAL container, and the four things that can
# go wrong around it.
#
# Every fixture here is built the way `tools/scenic_terrain.py`
# (`write_scenic_identity` + `write_climate_payload` + `climate_record`) actually
# writes an artifact: a TDS3 tile set, a canonical JSON map record bound to the
# twin by its exact byte length and CRC-32, and — when the producer sampled
# climate — a flat little-endian float32 `climate.f32` described by the record's
# own `climate` block. No Python, no model, no GPU, no window and no subprocess is
# involved: this suite writes bytes and checks what the reader makes of them.
#
# The two properties this suite exists to pin are the ones a plausible-looking
# implementation gets wrong:
#
#   * THE SCALE. The producer's `projection.scale` is the source->artifact UPSAMPLE
#     RATIO, not a world-cell span. A record that honestly says `scale: 4` over a
#     quarter-size source grid describes a climate grid that is still 1:1 with the
#     world, and must attach at world scale 1. Treating the producer's number as
#     the attachment scale would place a sample every four cells while looking
#     perfectly valid.
#   * ABSENCE. A six-entry artifact and a legacy cache must both answer
#     "unavailable" WITHOUT touching a single field of the cache, and heights must
#     read identically before and after.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/scenic-climate-test.janet

(import ../src/scenic-climate :as sc)
(import ../src/climate-tile :as climate)
(import ../src/terrain-cache :as tc)
(import ../src/terrain-integrity :as integrity)
(import ../src/terrain-runtime :as runtime)
(import ../src/world-catalog :as catalog)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(defn reject
  "Assert `f` raises and that its message mentions `fragment`."
  [name f fragment]
  (def message (try (do (f) nil) ([e] (string e))))
  (check name (and message (truthy? (string/find fragment message))) message))

# --- scratch directories --------------------------------------------------
(var scratch 0)
(def roots @[])
(defn scratch-dir []
  (++ scratch)
  (def path (string (or (os/getenv "TMPDIR") "/tmp")
                    "/trinecraft-scenic-climate-" (os/getpid) "-" scratch))
  (os/mkdir path)
  (array/push roots path)
  path)

(defn rm-tree [path]
  (when (os/stat path)
    (each name (try (os/dir path) ([e] @[]))
      (def child (string path "/" name))
      (if (= :directory (os/stat child :mode)) (rm-tree child) (try (os/rm child) ([e] nil))))
    (try (os/rm path) ([e] nil))))

(defn put-file [path data]
  (def f (file/open path :wbn))
  (unless f (error (string "cannot write " path)))
  (file/write f data)
  (file/close f))

(defn read-file-bytes
  "The exact bytes of `path`, as the catalogue's pure accessors expect them."
  [path]
  (def f (file/open path :rb))
  (unless f (error (string "cannot read " path)))
  (def b (file/read f :all))
  (file/close f)
  b)

# --- float32, exactly as the producer's masked array writes it ------------
(defn- f32-into [buf offset v]
  (def bits
    (if (= v 0)
      0
      (let [[frac e] (math/frexp (math/abs v))
            raw (bor (if (< v 0) (blshift 1 31) 0)
                     (blshift (+ e 126) 23)
                     (- (math/floor (* frac 16777216)) 8388608))]
        (if (< raw 0) (+ raw 4294967296) raw))))
  (for i 0 4
    (put buf (+ offset i) (% (math/floor (/ bits (math/pow 256 i))) 256))))

(defn put-le32 [buf offset value]
  (for i 0 4
    (put buf (+ offset i) (% (math/floor (/ value (math/pow 256 i))) 256))))

(defn climate-buffer
  "A `(height width 5)` channel-last float32 payload; `cell` is `(fn [x z])`."
  [h w cell]
  (def buf (buffer/new-filled (* h w 5 4) 0))
  (for z 0 h
    (for x 0 w
      (def vs (cell x z))
      (for c 0 5 (f32-into buf (* (+ (* (+ (* z w) x) 5) c) 4) (get vs c)))))
  buf)

#: Distinct per cell, so a misaddressed sample cannot pass as a correct one.
(defn cell [x z] [(+ 100 x) (+ 200 z) (+ 300 x z) 0 -1])

# --- the artifact writer --------------------------------------------------
#
# `opts`:
#   :bounds       inclusive [cx0 cz0 cx1 cz1]
#   :origin       world voxel origin of chunk-min (must equal bounds*16)
#   :grid         climate (height width) as declared in :shape
#   :source-grid  the producer's SOURCE grid, and
#   :producer-scale  the ratio between the two (reported, never used as a scale)
#   :climate?     whether the record declares (and the directory carries) climate
#   :payload      the bytes to write; a mutated copy is how corruption is tested
(defn write-artifact [dir opts]
  (os/mkdir dir)
  (os/mkdir (string dir "/tiles"))
  (def b (get opts :bounds))
  (def climate? (get opts :climate? true))
  (def grid (get opts :grid))
  (def h (get grid 0))
  (def w (get grid 1))
  (def payload (or (get opts :payload)
                   (climate-buffer h w (or (get opts :cell) cell))))
  (def payload-path (string dir "/" sc/climate-name))
  (when climate? (put-file payload-path payload))
  (def sha (when climate? (runtime/sha256-file payload-path)))
  (def crc (when climate? (integrity/crc32 (string payload))))
  (defn shape-text [] (string "[" h "," w "," climate/channel-count "]"))
  (def climate-block
    (when climate?
      (string "\"climate\":{\"container\":\"flat-f32-le\",\"container-version\":1,"
              "\"file\":\"climate.f32\",\"shape\":" (shape-text) ","
              "\"dtype\":\"f32<\","
              "\"order\":\"row-major, channel-last (x fastest within a row)\","
              "\"bytes\":" (or (get opts :bytes)
                               (* h w climate/channel-count 4))
              ",\"channels\":[\"temperature\",\"temperature-seasonality\","
              "\"precipitation\",\"precipitation-variability\",\"lapse-rate\"],"
              "\"units\":{\"temperature\":\"degrees C, elevation-adjusted mean\","
              "\"temperature-seasonality\":\"degrees C, standard deviation\","
              "\"precipitation\":\"millimetres per year\","
              "\"precipitation-variability\":\"coefficient of variation, percent\","
              "\"lapse-rate\":\"degrees C per metre\"},"
              "\"basis\":\"source-derived\",\"calibrated\":false,"
              "\"projection\":{\"source-grid\":[" (get (get opts :source-grid) 0) ","
              (get (get opts :source-grid) 1) "],"
              "\"artifact-grid\":[" h "," w "],"
              "\"scale\":" (get opts :producer-scale 1) ","
              "\"origin\":[" (get (get opts :origin) 0) ","
              (get (get opts :origin) 1) "],"
              "\"semantics\":\"cell-grid\"},"
              "\"sha256\":\"" sha "\",\"crc32\":" crc "}")))
  # The record the producer writes: a canonical-JSON map record. Only the keys
  # this reader consults are load-bearing, so the rest is representative shape.
  (def record
    (string "{\"bounds_inclusive\":[" (get b 0) "," (get b 1) ","
            (get b 2) "," (get b 3) "],\"format\":3,\"magic\":\"TDS3\","
            "\"origin_voxels\":[" (get (get opts :origin) 0) ","
            (get (get opts :origin) 1) "],"
            "\"pixels\":[" (* 16 (+ 1 (- (get b 2) (get b 0)))) ","
            (* 16 (+ 1 (- (get b 3) (get b 1)))) "],"
            "\"vertical_unit\":\"voxels above baseline; world Y == height\""
            (if climate-block (string "," climate-block) "") "}\n"))
  (put-file (string dir "/provenance.json") record)
  # The twin that BINDS the record by its exact size and CRC-32. Without this the
  # cache layer would refuse before the climate contract was ever consulted.
  (put-file (string dir "/manifest.janet")
            (string "{:format 3 :magic \"TDS3\" :identity \"" (string/repeat "d" 64)
                    "\" :seed 2024 :payload-bytes 256 :tile-bytes 308"
                    " :height-min 4 :height-max 252"
                    " :bounds [" (get b 0) " " (get b 1) " " (get b 2) " " (get b 3) "]"
                    " :origin [" (get (get opts :origin) 0) " "
                    (get (get opts :origin) 1) "]"
                    " :json-bytes " (length record)
                    " :json-crc32 " (integrity/crc32 record) "}\n"))
  # Tiles, so heights can be read on both sides of an attachment.
  (defn s32 [v] (if (< v 0) (+ v 4294967296) v))
  (for cx (get b 0) (+ 1 (get b 2))
    (for cz (get b 1) (+ 1 (get b 3))
      (def tile (buffer/new-filled tc/tile-bytes 0))
      (for i 0 4 (put tile i (get "TDS3" i)))
      (put-le32 tile 4 (s32 cx))
      (put-le32 tile 8 (s32 cz))
      (put-le32 tile 12 256)
      (def heights (buffer/new-filled 256 (+ 40 cx cz)))
      (put-le32 tile 16 (integrity/crc32 (string heights)))
      (for i 0 256 (put tile (+ 52 i) (get heights i)))
      (put-file (tc/tile-path dir cx cz) tile)))
  dir)

(defn legacy-artifact [dir]
  (os/mkdir dir)
  (os/mkdir (string dir "/tiles"))
  (put-file (string dir "/manifest.janet")
            (string "{:format 2 :magic \"TDH2\" :identity \"" (string/repeat "e" 64)
                    "\" :seed 2024 :payload-bytes 256 :tile-bytes 308}\n"))
  dir)

# The one map used by most checks: 2x1 chunks at world (0,0) = 32x16 cells, so a
# 1:1 climate grid is (16 32 5).
(def bounds-a [0 0 1 0])
(def origin-a [0 0])
(def grid-a [16 32])

(defn open-a [&opt mutate]
  (def dir (write-artifact (scratch-dir)
                           {:bounds bounds-a :origin origin-a :grid grid-a
                            :source-grid grid-a :producer-scale 1}))
  (when mutate (mutate dir))
  (tc/cache-new dir 2024))

#
# --- 1. A declared payload attaches, and says exactly what it is -------
#
(print "declared climate:")
(def cache-a (open-a))
(def described (sc/info-of cache-a))
(check "info-of describes the container without attaching it"
       (and (sc/present? described) (not (sc/unavailable? described))
            (= false (sc/attached? described))))
(check "info-of leaves the cache with no climate"
       (= :not-attached (get (tc/cache-climate cache-a) :reason)))
(def info (sc/attach! cache-a))
(check "attach! reports :present and :attached"
       (and (= :present (get info :status)) (sc/attached? info)))
(check "the shape is the artifact's own (16 32 5) grid"
       (= [16 32 5] (tuple ;(get info :shape))) (string (get info :shape)))
(check "units are the reader's, source-derived, and MEASURED nowhere"
       (and (= climate/unit-basis (get info :unit-basis))
            (= false (get info :units-measured?))
            (= "source-derived" (get info :basis))))
(check "every channel carries the reader's own unit string"
       (let [units (get info :units)]
         (and (= climate/channel-count (length (keys units)))
              (every? (map |(= (climate/channel-unit $) (get units $))
                           climate/channels)))))
(check "calibrated is FALSE, copied from the record and not upgraded"
       (= false (get info :calibrated)))
(check "origin and derived scale are the map's own"
       (and (= [0 0] (tuple ;(get info :origin))) (= 1 (get info :scale))))
(check "the producer's own ratio is reported beside the world scale"
       (= 1 (get info :producer-scale)))
(check "the digests the catalogue verified are reported"
       (and (= 64 (length (get info :sha256)))
            (number? (get info :crc32))))
(check "the cache now samples :sampled with the packed values"
       (let [s ((sc/sampler cache-a) 0 0)]
         (and (= :sampled (get s :status)) (= 0 (get s :index))
              (= 100 ((get s :values) :temperature))
              (= 200 ((get s :values) :temperature-seasonality))
              (= 300 ((get s :values) :precipitation)))))
(check "addressing is per world cell, not per chunk"
       (and (= 31 (get ((sc/sampler cache-a) 31 0) :index))
            (= 131 ((get ((sc/sampler cache-a) 31 0) :values) :temperature))))
(check "outside the map answers :outside-map, never a clamped edge sample"
       (= :outside-map (get ((sc/sampler cache-a) 32 0) :reason)))
(check "re-attaching identical data is idempotent"
       (and (sc/attached? (sc/attach! cache-a))
            (= :sampled (get ((sc/sampler cache-a) 5 5) :status))))

#
# --- 2. A corrupt payload refuses BEFORE attaching ----------------------
#
(print "\ncorrupt payload:")
# One flipped byte in the middle of the container. The record still describes the
# bytes the producer wrote, so the CRC-32 is what catches it.
(defn flip [dir]
  (def path (string dir "/" sc/climate-name))
  (def f (file/open path :rb))
  (def raw (buffer (file/read f :all)))
  (file/close f)
  (put raw 100 (band (bxor (get raw 100) 255) 255))
  (put-file path raw))
(def cache-b (open-a flip))
(reject "a flipped byte raises instead of degrading to absent"
        (fn [] (sc/attach! cache-b)) "CRC-32")
(check "and the cache is left with NO climate"
       (= :not-attached (get (tc/cache-climate cache-b) :reason)))
(check "so sampling still answers :not-attached"
       (and (= :unavailable (get ((sc/sampler cache-b) 0 0) :status))
            (= :not-attached (get ((sc/sampler cache-b) 0 0) :reason))))
# A truncated container is a different file, not a readable one.
(defn truncate [dir]
  (def path (string dir "/" sc/climate-name))
  (def f (file/open path :rb))
  (def raw (file/read f :all))
  (file/close f)
  (put-file path (string/slice raw 0 (- (length raw) 4))))
(def cache-t (open-a truncate))
(reject "a short payload is refused by the declared byte count"
        (fn [] (sc/attach! cache-t)) "bytes")

#
# --- 3. No climate is ABSENCE, and changes nothing ----------------------
#
(print "\nmissing climate:")
# The producer's six-entry artifact: no payload AND no declaration, which is the
# only honest way to be absent. (A payload the record never described is a
# mismatch, and the last check of this section pins that it refuses.)
(def cache-c (tc/cache-new
               (write-artifact (scratch-dir)
                               {:bounds bounds-a :origin origin-a :grid grid-a
                                :source-grid grid-a :producer-scale 1
                                :climate? false})
               2024))
(def dir-c (get cache-c :dir))
(def bare (tc/cache-new dir-c 2024))
(def heights-before (tc/read-height-tile bare 0 0))
(def bare-info (sc/attach! bare))
(check "a six-entry artifact answers :unavailable/:absent"
       (and (sc/unavailable? bare-info) (= :absent (get bare-info :reason))))
(check "and NOTHING was attached"
       (= :not-attached (get (tc/cache-climate bare) :reason)))
(check "heights read identically before and after"
       (= (string heights-before) (string (tc/read-height-tile bare 0 0))))
(check "the sampler answers :not-attached, never a zero climate"
       (let [r ((sc/sampler bare) 0 0)]
         (and (= :unavailable (get r :status)) (= :not-attached (get r :reason))
              (nil? (get r :values)))))
(reject "a payload the record does not declare is refused, not adopted"
        (fn []
          (put-file (string dir-c "/" sc/climate-name) (climate-buffer 16 32 cell))
          (sc/attach! bare))
        "without declaring")

# A legacy cache declares no map extent at all, so no grid can be checked.
(def legacy (tc/cache-new (legacy-artifact (scratch-dir)) 2024))
(def legacy-info (sc/attach! legacy))
(check "a legacy cache answers :unavailable/:unbounded"
       (and (sc/unavailable? legacy-info) (= :unbounded (get legacy-info :reason))))

#
# --- 4. The producer's ratio is NOT the world scale ---------------------
#
# A genuine producer record for a map upsampled 4x: `source-grid` is a quarter of
# the artifact grid, and `scale: 4` describes SOURCE->ARTIFACT. The climate
# container is still emitted at the artifact grid, so it is 1:1 with the world and
# attaching at 4 would misaddress every fourth column.
(print "\nproducer scale vs world scale:")
(def bounds-n [-1 0 0 0])
(def origin-n [-16 0])
(def cache-n (tc/cache-new
               (write-artifact (scratch-dir)
                               {:bounds bounds-n :origin origin-n :grid [16 32]
                                :source-grid [4 8] :producer-scale 4})
               2024))
(def info-n (sc/attach! cache-n))
(check "a negative-origin map attaches"
       (and (= :present (get info-n :status)) (sc/attached? info-n)))
(check "the producer's scale 4 is REPORTED, not used"
       (= 4 (get info-n :producer-scale)))
(check "the derived world scale is 1"
       (= 1 (get info-n :scale)))
(check "the source grid is reported beside it"
       (= [4 8] (tuple ;(get info-n :producer-source-grid))))
(check "the projection origin is the map's chunk-min corner"
       (= [-16 0] (tuple ;(get info-n :origin))))
(check "world -16 maps to grid cell 0 and world -1 to cell 15"
       (and (= 0 (get ((sc/sampler cache-n) -16 0) :index))
            (= 15 (get ((sc/sampler cache-n) -1 0) :index))))
(check "world 0 crosses into the second chunk at cell 16"
       (= 16 (get ((sc/sampler cache-n) 0 0) :index)))
(check "values follow the cell, so a misaddressed sample cannot pass"
       (= 116 ((get ((sc/sampler cache-n) 0 0) :values) :temperature)))
(check "one cell past each edge is outside the map"
       (and (= :outside-map (get ((sc/sampler cache-n) -17 0) :reason))
            (= :outside-map (get ((sc/sampler cache-n) 16 0) :reason))))
# The derivation is a checked function, not a division done in five places.
(check "world-scale derives 1 for a 1:1 grid and 2 for a half-size one"
       (and (= 1 (sc/world-scale [0 0 1 0] [16 32]))
            (= 2 (sc/world-scale [0 0 1 0] [8 16]))))
(reject "a grid that leaves a remainder is refused, not resampled"
        (fn [] (sc/world-scale [0 0 1 0] [12 32])) "remainder")
(reject "two different integer ratios are refused"
        (fn [] (sc/world-scale [0 0 1 0] [8 32])) "one integer scale")
(reject "a grid wider than the map is refused"
        (fn [] (sc/world-scale [0 0 1 0] [16 64])) "wider")

#
# --- 5. Nothing returned aliases the cache -----------------------------
#
# The two ways this could leak: handing out the reader's mutable table, and
# handing out something that still points at a file the caller can rewrite.
(print "\naliasing:")
(def info-m (sc/attach! cache-a))
(check "the info record is immutable"
       (= false (get (protect (put info-m :status :unavailable)) 0)))
(check "the units map is immutable"
       (= false (get (protect (put (get info-m :units) :temperature "x")) 0)))
(check "the shape is immutable"
       (= false (get (protect (put (get info-m :shape) 0 999)) 0)))
(check "the cache's own climate view is immutable"
       (let [c (tc/cache-climate cache-a)]
         (and (= false (get (protect (put c :status :unavailable)) 0))
              (= false (get (protect (put (get c :values) :temperature @[])) 0)))))
# OWNERSHIP: rewrite the container on disk with different values. If the cache had
# kept a view of the file -- or a reference the caller still holds -- the sample
# below would change. It must not.
(def dir-a (get cache-a :dir))
(put-file (string dir-a "/" sc/climate-name)
          (climate-buffer 16 32 (fn [x z] [999 999 999 999 999])))
(check "rewriting the file does not change what the cache samples"
       (= 100 ((get ((sc/sampler cache-a) 0 0) :values) :temperature)))
(check "so a second attach! of different bytes is refused, not merged"
       (let [fresh (tc/cache-new dir-a 2024)]
         (reject "changed bytes cannot attach twice over an attachment"
                 (fn [] (sc/attach! fresh)) "CRC-32")
         true))
# `info-of` must never mutate, on a cache whose attachment state is still nil.
(def cache-fresh (open-a))
(sc/info-of cache-fresh)
(check "info-of attaches nothing"
       (= :not-attached (get (tc/cache-climate cache-fresh) :reason)))

#
# --- 6. No discovery: the name is a contract, not a search -------------
#
# A container under any other name is a file nobody described. The artifact opens
# as a climate-less one, because FINDING a file is not being told what it is.
(print "\nno discovery:")
(def cache-x
  (tc/cache-new
    (write-artifact (scratch-dir)
                    {:bounds bounds-a :origin origin-a :grid grid-a
                     :source-grid grid-a :producer-scale 1
                     :climate? false})
    2024))
(def dir-x (get cache-x :dir))
(put-file (string dir-x "/climate.bin") (climate-buffer 16 32 cell))
(put-file (string dir-x "/climate-f32") (climate-buffer 16 32 cell))
(def info-x (sc/attach! cache-x))
(check "a container under another name is not the payload"
       (and (sc/unavailable? info-x) (= :absent (get info-x :reason))))
(check "and the cache holds no climate"
       (= :not-attached (get (tc/cache-climate cache-x) :reason)))
(check "payload-path is the one fixed name"
       (= (string dir-x "/climate.f32") (sc/payload-path dir-x)))
(check "payload-present? follows neither links nor directories blindly"
       (and (= false (sc/payload-present? dir-x))
            (do (os/mkdir (string dir-x "/climate.f32"))
                (= true (sc/payload-present? dir-x)))))
# A directory (or a link) at the payload path is a REFUSAL, never a silent
# absence: the catalogue's own file check is the authority, and this module must
# not turn its refusal into "this artifact has no climate".
(reject "a directory at the payload path is refused, not treated as bytes"
        (fn [] (sc/attach! cache-x)) "climate.f32")
(check "and the refusing cache holds no climate"
       (= :not-attached (get (tc/cache-climate cache-x) :reason)))

#
# --- 7. `load!`: one call, three status words, a sampler every time -----
#
# This is the seam a session wires. It must never require the caller to read the
# binding chain first, and it must never return a nil sampler -- an absent climate
# is an ANSWER, so a caller writes one function and no branch.
(print "\nload!:")
(def loaded (sc/load! (open-a)))
(check "a declared payload loads as :attached"
       (= :attached (get loaded :status)))
(check "and its sampler is live"
       (let [s ((get loaded :sampler) 0 0)]
         (and (= :sampled (get s :status))
              (= 100 ((get s :values) :temperature)))))
(def loaded-bare (sc/load! (tc/cache-new
                             (write-artifact (scratch-dir)
                                             {:bounds bounds-a :origin origin-a
                                              :grid grid-a :source-grid grid-a
                                              :producer-scale 1 :climate? false})
                             2024)))
(check "a six-entry artifact loads as :absent"
       (= :absent (get loaded-bare :status)))
(check "and STILL returns a sampler, so no caller needs a nil check"
       (and (function? (get loaded-bare :sampler))
            (= :not-attached (get ((get loaded-bare :sampler) 0 0) :reason))))
(def loaded-legacy (sc/load! (tc/cache-new (legacy-artifact (scratch-dir)) 2024)))
(check "a legacy cache loads as :legacy"
       (= :legacy (get loaded-legacy :status)))
(check "and returns a sampler too"
       (= :not-attached (get ((get loaded-legacy :sampler) 0 0) :reason)))
(check "load! carries the frozen info through for a UI to explain itself"
       (and (sc/present? (get loaded :info))
            (= false (get (protect (put (get loaded :info) :status :absent)) 0))))
# A corrupt payload must still RAISE through load!, not become :absent.
(check "load! does not swallow a corrupt payload"
       (let [r (protect (sc/load! (open-a flip)))]
         (and (= false (get r 0)) (truthy? (string/find "CRC-32" (string (get r 1)))))))

#
# --- 8. The projection comes from EXISTING public catalogue API ---------
#
# No new JSON parser, no duplicated schema, and no change to `world-catalog`.
# `climate-metadata` deliberately discards the projection (four fields only), so
# this pins that the loader reaches it through `climate-declaration` -- the
# catalogue's public accessor -- and that the two functions really do differ. If a
# future edit tries to read the projection off `climate-metadata`, this fails.
(print "\npublic catalogue API:")
(def record-n (read-file-bytes (tc/scenic-json-path (get cache-n :dir))))
(check "climate-metadata returns exactly the four-field contract"
       (let [c (catalog/climate-metadata record-n bounds-n true)]
         (= [:bytes :crc32 :sha256 :shape] (tuple ;(sort (keys c))))))
(check "and therefore carries NO projection, which is why declaration is used"
       (nil? (get (catalog/climate-metadata record-n bounds-n true) :projection)))
(check "climate-declaration is public and exposes the validated projection"
       (let [d (catalog/climate-declaration record-n true)
             p (get d "projection")]
         (and (= 4 (get p "scale"))
              (= [-16 0] (tuple ;(get p "origin")))
              (= false (get d "calibrated"))
              (= "source-derived" (get d "basis")))))
# The loader's reported numbers are those values, not a re-derivation guess.
(check "the loader reports the record's own projection verbatim"
       (and (= 4 (get info-n :producer-scale))
            (= [-16 0] (tuple ;(get info-n :origin)))))

#
# --- 9. Reading climate does NOT require a published (READY) artifact ---
#
# A real producer run can leave a directory whose TILES are unusable -- the seed-42
# run at 25 m/voxel clipped all 16384 heights below the height band and was
# correctly refused at READY -- while its CLIMATE is perfectly good bytes. Those
# are two independent products, and `READY` is the PUBLISHER's gate in
# `world-catalog/verify-artifact`, not a condition of reading climate.
#
# This pins the separation, hermetically: `cache-new` opens the manifest, `load!`
# reads the payload, and NOTHING here consults READY. It is a claim about what
# this module requires, NOT an endorsement of a failed artifact as production --
# heights that clip are still refused, and no caller should publish that map.
(print "\nno READY required to read climate:")
(def unready (write-artifact (scratch-dir)
                             {:bounds bounds-a :origin origin-a :grid grid-a
                              :source-grid grid-a :producer-scale 1}))
# The producer writes these before READY; only the final marker is withheld, so
# the publisher's refusal below is provably about READY and not about a short
# directory listing.
(put-file (string unready "/manifest.json") "{\"format\": 3}\n")
(put-file (string unready "/summary.json") "{\"tiles\": 2}\n")
(check "the fixture genuinely has no READY marker"
       (nil? (os/lstat (string unready "/READY"))))
(def unready-cache (tc/cache-new unready 2024))
(def unready-loaded (sc/load! unready-cache))
(check "climate still attaches from an unpublished directory"
       (= :attached (get unready-loaded :status)))
(check "and the real values are readable"
       (= 100 ((get ((get unready-loaded :sampler) 0 0) :values) :temperature)))
(check "the manifest, not READY, is what was required"
       (= [0 0 1 0] (tuple ;(tc/cache-bounds unready-cache))))
# The publisher's gate still refuses it -- this module did not weaken that check.
(check "world-catalog still refuses to PUBLISH it without READY"
       (let [r (protect (catalog/inspect-artifact unready 2024))]
         (and (= false (get r 0))
              (truthy? (string/find "READY" (string (get r 1)))))))

#
# --- 10. What a REAL artifact can actually declare: scale is always 1 ---
#
# `world-catalog/climate-block` requires the declared climate `shape` to equal
# `climate-shape-for bounds`, which is `[16*chunks_z, 16*chunks_x, 5]` -- one
# sample per world cell. A coarser climate grid is therefore REFUSED by the
# catalogue before this module is ever reached.
#
# This matters for wiring: a MAIN integration does not need to handle `scale > 1`
# on the real path, because the contract cannot express it. The derived
# `world-scale` still refuses a remainder and still reports what it computed, so
# nothing here is unsafe -- it is simply unreachable from a published artifact,
# and this check says so instead of leaving a reader to guess.
(print "\nreal artifacts cannot declare a coarser grid:")
(def units-text
  (string "\"units\":{\"temperature\":\"degrees C, elevation-adjusted mean\","
          "\"temperature-seasonality\":\"degrees C, standard deviation\","
          "\"precipitation\":\"millimetres per year\","
          "\"precipitation-variability\":\"coefficient of variation, percent\","
          "\"lapse-rate\":\"degrees C per metre\"}"))
(defn decl-record
  "A producer-shaped record whose climate grid is `h x w` over a 2x1-chunk map."
  [h w]
  (string "{\"format\":3,\"climate\":{\"container\":\"flat-f32-le\","
          "\"container-version\":1,\"file\":\"climate.f32\","
          "\"shape\":[" h "," w ",5],\"dtype\":\"f32<\","
          "\"order\":\"row-major, channel-last (x fastest within a row)\","
          "\"bytes\":" (* h w 5 4) ","
          "\"channels\":[\"temperature\",\"temperature-seasonality\","
          "\"precipitation\",\"precipitation-variability\",\"lapse-rate\"],"
          units-text ",\"basis\":\"source-derived\",\"calibrated\":false,"
          "\"projection\":{\"source-grid\":[" (div h 2) "," (div w 2) "],"
          "\"artifact-grid\":[" h "," w "],\"scale\":2,\"origin\":[0,0],"
          "\"semantics\":\"cell-grid\"},"
          "\"sha256\":\"" (string/repeat "a" 64) "\",\"crc32\":1}}\n"))
# A 2x1-chunk map is 16 rows x 32 columns of world cells, so its 1:1 grid is the
# only shape the catalogue accepts.
(check "the full pixel grid (16x32) is the accepted contract"
       (get (protect (catalog/climate-metadata (decl-record 16 32) [0 0 1 0] true)) 0))
(check "a quarter-size climate grid is REFUSED, so scale>1 is unreachable"
       (let [r (protect (catalog/climate-metadata (decl-record 8 16) [0 0 1 0] true))]
         (and (= false (get r 0))
              (truthy? (string/find "artifact-grid does not match"
                                    (string (get r 1)))))))
# The producer may still RECORD a source-grid ratio other than 1 for its own
# bookkeeping; that is `:producer-scale` and never changes where a sample lands.
(check "so every real attachment derives world scale 1"
       (= 1 (get info :scale)))
(check "and the producer's own ratio is independent of it"
       (and (= 1 (get info :producer-scale)) (= 4 (get info-n :producer-scale))))

#
# --- 11. Real artifacts, when this machine has them (SKIPPED otherwise) ---
#
# The producer's real output lives under the gitignored `tmp/`, so it is not in a
# clean clone and must never make this suite fail elsewhere. When it IS present,
# this is the only place the loader is exercised against bytes a model actually
# wrote, rather than a fixture written to match the reader.
#
# What the real common-mapping artifacts prove: 64 tiles, a 327680-byte container,
# bounds [-1 -1 6 6] at origin [-16 -16], scale 1, and NO READY -- the loader
# attaches anyway, because READY is the publisher's gate and `cache-new` does not
# consult it. Heights in these artifacts are all-zero (below the height band), so
# nothing here claims they are publishable; only that climate reads.
(print "\nreal artifacts (skipped when absent):")
(def real-artifacts
  [[42 "tmp/visual-common-mapping-seed42/0592b55bf58b259f724973ee95b70725476d9aa1e31847d4dd33f92388cebb07"]
   [2026 "tmp/visual-common-mapping-seed2026/07740b1f32a42171f0659efff1fd96742f54bc7a862069ad902698c7092b6f43"]])
(var real-checked 0)
(each entry real-artifacts
  (def seed (get entry 0))
  (def dir (get entry 1))
  (if (nil? (os/lstat dir))
    (printf "  skip seed %d (artifact not present)" seed)
    (do
      (++ real-checked)
      (def cache (tc/cache-new dir seed))
      (def L (sc/load! cache))
      (def i (get L :info))
      (def label (string "seed " seed))
      (check (string label ": attaches with no READY marker")
             (and (= :attached (get L :status))
                  (nil? (os/lstat (string dir "/READY")))))
      (check (string label ": scale is 1 and the grid is 128x128x5")
             (and (= 1 (get i :scale)) (= 1 (get i :producer-scale))
                  (= [128 128 5] (tuple ;(get i :shape)))))
      (check (string label ": origin is the chunk-min corner [-16 -16]")
             (= [-16 -16] (tuple ;(get i :origin))))
      (check (string label ": the payload is the declared 327680 bytes")
             (= 327680 (get i :bytes)))
      # NOTE the two types: `:basis` is the STRING the producer wrote into JSON,
      # while `:unit-basis` is `climate-tile`'s own KEYWORD. Both print as
      # "source-derived"; the loader deliberately copies each from its owner
      # rather than coercing one into the other's shape.
      (check (string label ": basis is source-derived and NOT calibrated")
             (and (= "source-derived" (get i :basis))
                  (= :source-derived (get i :unit-basis))
                  (= false (get i :calibrated))))
      # Corner, middle, and one cell past each edge -- through the real payload.
      (def s ((get L :sampler) -16 -16))
      (check (string label ": the chunk-min corner samples at index 0")
             (and (= :sampled (get s :status)) (= 0 (get s :index))))
      (check (string label ": the far corner samples at the last index")
             (= 16383 (get ((get L :sampler) 111 111) :index)))
      (check (string label ": one cell past either edge is outside the map")
             (and (= :outside-map (get ((get L :sampler) 112 112) :reason))
                  (= :outside-map (get ((get L :sampler) -17 -16) :reason))))
      (def temp ((get s :values) :temperature))
      (check (string label ": the corner temperature is finite and plausible")
             (and (number? temp) (> temp -90) (< temp 60)))
      (print (string "  (" label " corner temperature " temp " C)")))))
(check "the two real seeds are DIFFERENT climate, not one artifact twice"
       (if (< real-checked 2)
         true   # cannot compare without both present
         (let [sampler-a (get (sc/load! (tc/cache-new (get (get real-artifacts 0) 1) 42))
                              :sampler)
               sampler-b (get (sc/load! (tc/cache-new (get (get real-artifacts 1) 1) 2026))
                              :sampler)
               a (get (get (sampler-a -16 -16) :values) :temperature)
               b (get (get (sampler-b -16 -16) :values) :temperature)]
           (and (number? a) (number? b) (not= a b)))))

(each d roots (rm-tree d))
(print "")
(if (zero? failures)
  (print "ALL CHECKS PASSED  (0 failures)")
  (do (printf "FAILURES: %d" failures) (os/exit 1)))
