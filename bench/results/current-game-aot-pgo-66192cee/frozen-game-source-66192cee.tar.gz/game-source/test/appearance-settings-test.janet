(import ../src/appearance-settings :as appearance)
(def path (string "tmp/appearance-test-" (os/getpid) ".janet"))
(defn write-text [text]
  (let [f (file/open path :wbn)]
    (file/write f text)
    (file/close f)))
(defn fails? [f]
  (try (do (f) false) ([err] true)))
(try (os/rm path) ([ignored] nil))
(assert (deep= (appearance/load path) appearance/defaults))
(assert (appearance/validate appearance/defaults))
(assert (not (appearance/validate {:version 2})))
(assert (not (appearance/validate (merge appearance/defaults {:water-alpha-cap 2}))))
(assert (not (appearance/validate (merge appearance/defaults {:water-normal-strength -1}))))
(assert (not (appearance/validate (merge appearance/defaults {:water-alpha-cap :bad}))))
(def state (appearance/source path))
(assert (not (os/stat path))) # load never writes a missing file
(def custom (merge appearance/defaults {:water-normal-strength 0.35}))
(appearance/save custom path)
(assert (deep= (appearance/load path) custom))
(assert (deep= (appearance/current (appearance/reload state)) custom))
(assert (fails? (fn [] (appearance/save {:version 2} path))))
(assert (deep= (appearance/load path) custom))
(write-text "{:version 1 :water-normal-strength (os/exit 9)}\n")
(assert (fails? (fn [] (appearance/reload state))))
(assert (deep= (appearance/current state) appearance/defaults))
(write-text "not valid Janet (@\n")
(assert (fails? (fn [] (appearance/load path))))
(os/rm path)
(print "appearance persistence: passed")

# The saved file is hand-edited (a developer tunes the water here), so its
# layout is part of the contract: %j wrote one dense line and printed
# 0.94999999999999996 for 0.95, which reads as corruption.
(let [d (string "tmp/appearance-layout-" (os/getpid) ".janet")]
  (appearance/save custom d)
  (def text (do (def f (file/open d :rb)) (def t (file/read f :all)) (file/close f) t))
  (assert (string/find "# Renderer appearance settings" text))
  (assert (> (length (string/split "\n" text)) 12))
  (assert (string/find ":water-alpha-cap 0.95" text))
  (assert (not (string/find "0.94999" text)))
  (assert (deep= (appearance/load d) custom))
  (os/rm d))
(print "saved layout: passed")
