# Independent height-tile adapter checks; no model or renderer required.
(import ../src/worldgen :as terrain)
(import ../src/world :as world)

(defn blocks [] (buffer/new-filled world/chunk-volume 0))
(defn heights [] (buffer/new-filled 256 28))
(defn index [x y z] (+ x (* 16 (+ z (* 16 y)))))

# The existing noise path is the byte-exact oracle, including negative chunks.
(each coords [[0 0] [1 -2] [-1 0] [-3 -4] [7 11]]
  (each seed [0 4 9217 -713]
    (let [cx (coords 0) cz (coords 1)
          tile (heights)
          expected (blocks)
          actual (blocks)]
      (for z 0 16
        (for x 0 16
          (put tile (+ x (* 16 z))
               (terrain/height-at seed (+ (* cx 16) x) (+ (* cz 16) z)))))
      (terrain/generate-into expected cx cz seed)
      (assert (= actual (terrain/generate-from-heights actual cx cz tile))
              "adapter must return caller buffer")
      (assert (= (string expected) (string actual))
              "height-tile fill differs from noise-generated chunk"))))
(print "height tile parity: ok")

# Each accepted extreme and each water/beach boundary is independently checked.
(each h [4 27 28 29 30 60]
  (let [tile (buffer/new-filled 256 h) out (blocks)
        beach (<= h 29)]
    (terrain/generate-from-heights out -1 2 tile)
    (for z 0 16
      (for x 0 16
        (for y 0 64
          (let [expected (cond
                           (= y 0) 1
                           (< y (- h 4)) 1
                           (< y h) (if beach 4 2)
                           (= y h) (if beach 4 3)
                           (<= y 28) 5
                           0)]
            (assert (= expected (get out (index x y z)))
                    (string "wrong column block at height " h " y " y))))))))
(print "height extremes and sea rules: ok")

# Scenic heights use the same block rule above the original 64-high range.
(each h [61 64 128 251 terrain/scenic-max-height]
  (let [out (blocks) tile (buffer/new-filled 256 h)]
    (terrain/generate-from-heights-scenic out -2 3 tile)
    (assert (= world/block-stone (get out (index 0 0 0))))
    (assert (= world/block-stone (get out (index 15 (- h 5) 15))))
    (assert (= world/block-dirt (get out (index 15 (- h 4) 15))))
    (assert (= world/block-grass (get out (index 15 h 15))))
    (assert (= world/block-air (get out (index 15 (+ h 1) 15))))
    (assert (= world/block-air (get out (index 15 255 15))))))
(let [out (buffer/new-filled world/chunk-volume 137)
      tile (buffer/new-filled 256 64)]
  (let [[ok _] (protect (terrain/generate-from-heights out 0 0 tile))]
    (assert (not ok) "legacy tile adapter must still reject heights over 60")
    (assert (= 137 (get out 0)) "rejected legacy heights must not write"))
  (put tile 255 253)
  (let [[ok _] (protect (terrain/generate-from-heights-scenic out 0 0 tile))]
    (assert (not ok) "scenic tile cannot exceed headroom bound")
    (assert (= 137 (get out 0)) "invalid scenic tile must not partially write")))
(print "scenic heights and atomicity: ok")

# A scenic waterline shifts both submerged blocks and the sand/grass edge.
(let [tile (buffer/new-filled 256 64) out (blocks)]
  (put tile 0 62)
  (put tile 1 65)
  (put tile 2 66)
  (terrain/generate-from-heights-scenic out 3 -2 tile {:sea-level 64})
  (assert (= world/block-water (get out (index 0 63 0))) "sea64 covers height62")
  (assert (= world/block-water (get out (index 0 64 0))) "water reaches sea64")
  (assert (= world/block-air (get out (index 0 65 0))) "water stops above sea64")
  (assert (= world/block-sand (get out (index 1 65 0))) "beach reaches sea+1")
  (assert (= world/block-grass (get out (index 2 66 0))) "dry land starts sea+2")
  (assert (= world/block-sand (get out (index 3 64 0))) "shoreline at sea64"))
(let [tile (buffer/new-filled 256 63) out (buffer/new-filled world/chunk-volume 137)]
  (each options [{:sea-level -1} {:sea-level 253} {:sea-level 64.5}
                 {:sea-level :invalid} {:sea-level 64 :extra 1}
                 64 []]
    (let [before (string out)
          [ok _] (protect (terrain/generate-from-heights-scenic out 0 0 tile options))]
      (assert (not ok) (string "invalid scenic option accepted: " options))
      (assert (= before (string out)) "invalid scenic option partially wrote blocks"))))
(print "scenic sea-level 64 and option atomicity: ok")

(defn rejects-unchanged [out cx cz tile]
  (let [before (string out)
        [ok _] (protect (terrain/generate-from-heights out cx cz tile))]
    (assert (not ok) "invalid adapter input accepted")
    (assert (= before (string out)) "invalid input partially modified blocks")))

(let [out (buffer/new-filled world/chunk-volume 137)]
  (rejects-unchanged out 0 0 (buffer/new-filled 255 28))
  (rejects-unchanged out 0 0 (buffer/new-filled 257 28))
  (rejects-unchanged out 0 0 @[])
  (rejects-unchanged out 0 0 nil)
  (rejects-unchanged out 0 0 (buffer/new-filled 256 3))
  (rejects-unchanged out 0 0 (buffer/new-filled 256 61))
  (let [tile (array/new-filled 256 28)]
    (put tile 255 28.5)
    (rejects-unchanged out 0 0 tile)
    (put tile 255 :invalid)
    (rejects-unchanged out 0 0 tile))
  (let [tile (heights)]
    (put tile 255 61)
    (rejects-unchanged out 0 0 tile))
  (rejects-unchanged (buffer/new-filled 16383 137) 0 0 (heights))
  (rejects-unchanged (buffer/new-filled 16385 137) 0 0 (heights))
  (rejects-unchanged @[] 0 0 (heights))
  (rejects-unchanged out 0.5 0 (heights))
  (rejects-unchanged out 0 0.5 (heights)))
(print "invalid input atomicity: ok")
(print "worldgen heights tests: all passed")
