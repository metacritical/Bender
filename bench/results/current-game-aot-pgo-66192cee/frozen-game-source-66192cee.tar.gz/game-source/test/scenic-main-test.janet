# main.janet scenic-map integration: finite bounds, height field, one seam.
#
# No window, no GPU, no Python backend. This suite imports `main.janet` as a
# MODULE -- bender only auto-invokes `main` for the entry script -- so the scenic
# helpers can be driven directly while the game itself never starts.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/scenic-main-test.janet
#
# The fixtures build TDS3 tiles and a format-3 manifest with explicit
# little-endian arithmetic rather than through the consumer's own encoder: a
# fixture that reused the code under test would agree with it even when both were
# wrong. The CRC-32 comes from the shared implementation because that is the one
# field both sides really verify.

(import ../src/terrain-cache :as tc)
(import ../src/terrain-integrity :as integrity)
(import ../src/world :as world)
(import ../src/worldgen :as worldgen)
(import ../src/scenic-worldgen :as scenic)
(import ../src/stream :as stream)
(import ../src/loading-screen :as loading-screen)
(import ../src/world-provider :as provider)
(import ../src/world-seed :as world-seed)
(import ../src/world-catalog :as catalog)
(import ../src/player :as player)
(import ../main :as game)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(var scratch-counter 0)
(defn scratch-dir []
  (++ scratch-counter)
  (def base (or (os/getenv "TMPDIR") "/tmp"))
  (def path (string base "/trinecraft-scenic-main-" (os/getpid) "-" scratch-counter))
  (os/mkdir path)
  path)

(defn rm-tree [path]
  (when (os/stat path)
    (each name (try (os/dir path) ([e] @[]))
      (def child (string path "/" name))
      (if (= :directory (os/stat child :mode))
        (rm-tree child)
        (try (os/rm child) ([e] nil))))
    (try (os/rm path) ([e] nil))))

(defn any-true?
  "Is any element of `xs` true? `some` is two-argument in bender, so this stays explicit."
  [xs]
  (pos? (length (filter identity (map (fn [x] (if x true false)) xs)))))

(defn message-of [thunk]
  (def r (protect (thunk)))
  (if (get r 0) nil (string (get r 1))))

#
# --- Fixtures -----------------------------------------------------------
#

(defn- put-le-u32 [buf offset value]
  (put buf offset (% value 256))
  (put buf (+ offset 1) (% (math/floor (/ value 256)) 256))
  (put buf (+ offset 2) (% (math/floor (/ value 65536)) 256))
  (put buf (+ offset 3) (% (math/floor (/ value 16777216)) 256)))

(defn- put-le-i32 [buf offset value]
  (put-le-u32 buf offset (if (neg? value) (+ value 4294967296) value)))

(defn- write-bytes [path data]
  (def f (file/open path :wbn))
  (file/write f data)
  (file/close f))

(defn- scenic-tile
  "A well-formed TDS3 tile: same 308-byte envelope, magic TDS3, band 4..252."
  [cx cz heights]
  (def out (buffer/new-filled tc/tile-bytes 0))
  (put out 0 84) (put out 1 68) (put out 2 83) (put out 3 51)   # TDS3
  (put-le-i32 out 4 cx)
  (put-le-i32 out 8 cz)
  (put-le-u32 out 12 tc/payload-bytes)
  (put-le-u32 out 16 (integrity/crc32 (string heights)))
  (for i 0 32 (put out (+ 20 i) (% (+ i 13) 256)))
  (for i 0 tc/payload-bytes (put out (+ tc/header-bytes i) (get heights i)))
  out)

(defn- heights-varying [&opt seed]
  (def s (or seed 0))
  (def out (buffer/new-filled tc/payload-bytes 0))
  (for z 0 16
    (for x 0 16
      (put out (+ x (* 16 z)) (+ 4 (% (+ (* 29 x) (* 17 z) s) 249)))))
  out)

(defn- profile-json [sea]
  # The producer's record shape. `sea_level` lives inside its mapping block, so a
  # reader that only looked at the top level would find nothing -- which is what
  # the sea-level cases below pin.
  (string "{\"seed\":4,\"pixels_per_voxel\":1,\"origin_pixels\":[100000,100000],"
          "\"mapping\":{\"meters_per_voxel\":4.0,\"sea_level\":" sea
          ",\"baseline_elevation_m\":0.0,\"height_min\":4,\"height_max\":252,"
          "\"profile\":\"scenic\",\"sampling\":\"offline-import\"},"
          "\"raw_sha256\":\"" (string/repeat "a" 64) "\",\"raw_grid\":[256,256]}"))

(defn write-scenic
  ``One scenic identity directory. Options choose identity, bounds, band and sea.

  When no identity is given, the directory's own name is used. That is not a
  convenience: `cache-open` refuses a cache whose directory is not named after its
  identity, and a fixture that picked an unrelated constant would fail at the
  directory check before reaching the behaviour under test.

  Defaults describe a 4x3-chunk map whose lower-left corner is a LARGE chunk
  coordinate pair: that is what a real export of a 100000-pixel origin produces,
  and a helper that quietly assumed chunk 0 would appear to work and then look
  for the map in the wrong place.``
  [dir &opt opts]
  (def o (or opts @{}))
  (def bounds (get o :bounds [6250 6250 6253 6252]))
  (def origin (get o :origin [100000 100000]))
  (def lo (get o :height-min 4))
  (def hi (get o :height-max 252))
  (def json (profile-json (get o :sea 60)))
  (os/mkdir dir)
  (os/mkdir (tc/tiles-dir dir))
  (os/mkdir (tc/requests-dir dir))
  (write-bytes (tc/scenic-json-path dir) json)
  (write-bytes (string dir "/manifest.janet")
               (string "{:format 3 :magic \"TDS3\" :identity \""
                      (or (get o :identity)
                          (let [parts (string/split "/" dir)]
                            (last parts)))
                      "\" :seed " (or (get o :seed) 4)
                      " :payload-bytes 256 :tile-bytes 308"
                      " :height-min " lo " :height-max " hi
                      " :bounds [" (get bounds 0) " " (get bounds 1) " "
                      (get bounds 2) " " (get bounds 3) "]"
                      " :origin [" (get origin 0) " " (get origin 1) "]"
                      " :json-bytes " (length json)
                      " :json-crc32 " (integrity/crc32 json) "}"))
  dir)

(defn fill-tiles
  "Write a tile for every coordinate in `coords` under `dir`."
  [dir coords &opt seed]
  (each c coords
    (write-bytes (tc/tile-path dir (c 0) (c 1))
                 (scenic-tile (c 0) (c 1) (heights-varying (or seed 0))))))

(defn rect
  "Every chunk coordinate in an inclusive rectangle, row by row."
  [cx0 cz0 cx1 cz1]
  (def out @[])
  (for cz cz0 (+ cz1 1)
    (for cx cx0 (+ cx1 1)
      (array/push out [cx cz])))
  out)

#
# --- Profile detection --------------------------------------------------
#
(print "\nprofile detection:")

(def sdir (write-scenic (string (scratch-dir) "/" (string/repeat "b" 64))))
(def scenic-cache (tc/cache-new sdir 4))
(check "the cache reports the scenic profile"
       (= :scenic (tc/cache-profile scenic-cache)))
(check "main recognises a scenic cache"
       (truthy? (game/scenic-cache? scenic-cache)))
(check "main does not call a nil cache scenic"
       (not (truthy? (game/scenic-cache? nil))))
(check "main does not call a legacy cache scenic"
       (not (truthy? (game/scenic-cache? {:profile :legacy}))))
(check "a scenic cache carries its bounds through"
       (= [6250 6250 6253 6252] (game/scenic-bounds scenic-cache)))
(check "the map's own band is read, not assumed"
       (and (= 4 (scenic-cache :height-min)) (= 252 (scenic-cache :height-max))))

# A legacy cache must never be reachable from any scenic branch, and the
# helpers that ask "is this scenic?" must answer from the profile alone.
(check "a legacy profile is not scenic"
       (not (truthy? (game/scenic-cache? {:profile :legacy}))))

#
# --- Bounds clipping ----------------------------------------------------
#
(print "\nbounds and spawn derivation:")

(check "the spawn chunk is the map's centre"
       (= [6251 6251] (game/scenic-spawn-chunk scenic-cache)))
(check "the spawn chunk is inside the declared bounds"
       (let [c (game/scenic-spawn-chunk scenic-cache)]
         (tc/in-bounds? scenic-cache (get c 0) (get c 1))))
(check "the map span is inclusive on both ends"
       (= [4 3] (game/scenic-map-span scenic-cache)))
# A small map still gets the full default radius rather than a 2-chunk clearing:
# the floor exists so a finite map never opens onto a postage stamp of terrain.
(check "a small map gets the default radius, not half its span"
       (= game/scenic-default-radius (game/scenic-radius-for-map scenic-cache)))
(check "the default radius is large enough to see a ring of terrain"
       (>= game/scenic-default-radius 12))
(check "the radius is capped, never the whole of a large map"
       (<= (game/scenic-radius-for-map
             (tc/cache-new sdir 4))
           game/scenic-radius-cap))

# The spawn ring is the one place that must be CLIPPED rather than refused: a
# small map cannot supply a full 5x5 ring, and requiring one would report
# "incomplete bake" for a complete map.
(def small-dir (write-scenic (string (scratch-dir) "/" (string/repeat "c" 64))
                             {:bounds [100 100 101 101]}))
(def small-cache (tc/cache-new small-dir 4))
(game/scenic-setup! small-cache)
(def small-coords (game/spawn-tile-coords))
(check "a 2x2 map spawns the 4 tiles it actually has"
       (= 4 (length small-coords)))
(check "every required spawn tile is inside the map"
       (every? (map (fn [c] (tc/in-bounds? small-cache (c 0) (c 1))) small-coords)))
(check "the clipped ring never names a coordinate outside the map"
       (not (any-true? (map (fn [c] (= [99 100] c)) small-coords))))

# A full-size map keeps the ordinary ring.
(def big-dir (write-scenic (string (scratch-dir) "/" (string/repeat "d" 64))
                           {:bounds [0 0 40 40]}))
(game/scenic-setup! (tc/cache-new big-dir 4))
(check "a map larger than the spawn ring still spawns the full ring"
       (= 25 (length (game/spawn-tile-coords))))
(check "the full ring is centred on the map, not on the origin"
       (let [coords (game/spawn-tile-coords)]
         (and (any-true? (map (fn [c] (= c [20 20])) coords))
              (not (any-true? (map (fn [c] (= c [0 0])) coords))))))

#
# --- Height field -------------------------------------------------------
#
(print "\nheight field:")

(def map-dir (write-scenic (string (scratch-dir) "/" (string/repeat "e" 64))
                           {:bounds [300 -5 303 1]}))
(fill-tiles map-dir (rect 300 -5 303 1))
(game/scenic-setup! (tc/cache-new map-dir 4))

# One column inside, with the value the fixture wrote there: index is x-fastest
# within the tile, and the lookup must agree with it exactly. A transposed or
# off-by-one lookup produces a plausible *different* height, which is why this
# asserts a specific value rather than "some number".
(def inside-h (game/scenic-height-at (+ (* 300 world/chunk-x) 5)
                                     (+ (* -5 world/chunk-z) 7)))
(check "a covered column reports the tile's height"
       (= (get (heights-varying) (+ 5 (* 16 7))) inside-h))
(check "a covered column reports a number, not nil"
       (number? inside-h))

# A NEGATIVE chunk coordinate is the case a `floor`-vs-truncate mistake breaks,
# and it is exactly where a real map's lower-left corner can sit.
(check "a negative chunk coordinate is covered and read correctly"
       (= (get (heights-varying) (+ 3 (* 16 2)))
          (game/scenic-height-at (+ (* 302 world/chunk-x) 3)
                                 (+ (* -5 world/chunk-z) 2))))

# A FRACTIONAL position must read the block containing it. This is the defect a
# real camera ray exposed: `get` on a buffer with a fractional index SILENTLY
# returns nil, so an eye at x=59.99985 (which `(+ 60 (* (cos -1.57) d))` produces)
# saw the entire map as absent. The failure looks exactly like a map edge, which
# is why it needs its own check rather than riding on the integer one above.
(check "a position inside a block reads that block's height"
       (= inside-h (game/scenic-height-at
                     (+ (* 300 world/chunk-x) 5.4)
                     (+ (* -5 world/chunk-z) 7.9))))
(check "fractional X alone does not fall off the map"
       (number? (game/scenic-height-at 4800.9999 0)))
(check "fractional Z alone does not fall off the map"
       (number? (game/scenic-height-at 4805 (+ (* -5 world/chunk-z) 2.5))))
# The exact arithmetic a yaw aimed north produces, pinned so the regression
# cannot return through a "tidy up the floor call" edit.
(check "a camera ray at yaw -1.57 does not report absence"
       (let [yaw -1.5708]
         (number? (game/scenic-height-at (+ (* 300 world/chunk-x) 12.5)
                                         (+ (* -5 world/chunk-z) 2)))))

(check "a column just outside the map is nil, not zero"
       (nil? (game/scenic-height-at (dec (* 300 world/chunk-x)) 0)))
(check "a column past the far edge is nil"
       (nil? (game/scenic-height-at (* 304 world/chunk-x) 0)))
(check "a column below the map is nil"
       (nil? (game/scenic-height-at 0 (dec (* -5 world/chunk-z)))))
(check "a far-away column is nil"
       (nil? (game/scenic-height-at 1000000 1000000)))

# Absence inside the declared bounds (a map tile that is simply not there) is
# also nil: the bound is what makes a column addressable, the tile makes it real.
(check "an in-bounds column with no tile is nil"
       (nil? (game/scenic-height-at (+ (* 3250 world/chunk-x) 1) 1)))

#
# --- Generation seam ----------------------------------------------------
#
(print "\ngeneration seam:")

# A scenic chunk filled through the seam must match one filled directly by the
# two scenic stages: the dispatcher adds nothing of its own, which is the only
# way "one seam" is worth claiming.
(game/scenic-setup! (tc/cache-new map-dir 4))
(def seam-blocks (buffer/new-filled world/chunk-volume 0))
(game/fill-tile-into! seam-blocks 301 0
                      (tc/read-height-tile (tc/cache-new map-dir 4) 301 0))
(def direct-blocks (buffer/new-filled world/chunk-volume 0))
(def hf (fn [wx wz] (game/scenic-height-at wx wz)))
(scenic/fill direct-blocks 301 0 hf
             (game/scenic-scene-opts (tc/cache-new map-dir 4)
                                     (game/scenic-sea-level map-dir)))
(check "the scenic seam equals fill with the map's own options"
       (= (string seam-blocks) (string direct-blocks)))
(check "a scenic chunk is not empty"
       (not (every? (map (fn [b] (= b world/block-air)) seam-blocks))))

# Above the legacy ceiling (60) but inside the scenic band: the legacy adapter
# refuses such a tile outright, so a scenic chunk proving it filled above 60 is
# the difference between "used the scenic path" and "used the legacy one".
(def tall-blocks (buffer/new-filled world/chunk-volume 0))
(game/fill-tile-into! tall-blocks 301 0
                      (buffer/new-filled 256 200))
(var above-60 0)
(each i (range 0 256)
  (def x (% i 16))
  (def z (math/floor (/ i 16)))
  (when (not= world/block-air
              (world/chunk-get {:blocks tall-blocks} x 199 z))
    (++ above-60)))
(check "the scenic seam fills columns above the legacy 60 ceiling"
       (= 256 above-60))

# And the legacy path is untouched: the same dispatcher with no scenic session
# active produces exactly what `worldgen/generate-from-heights` produces.
(game/scenic-reset!)
(def legacy-seam (buffer/new-filled world/chunk-volume 0))
(def legacy-direct (buffer/new-filled world/chunk-volume 0))
(def legacy-tile (buffer/new-filled 256 30))
(game/fill-tile-into! legacy-seam 0 0 legacy-tile)
(worldgen/generate-from-heights legacy-direct 0 0 legacy-tile)
(check "without a scenic map the seam is the unchanged legacy adapter"
       (= (string legacy-seam) (string legacy-direct)))
(check "the legacy adapter still refuses a height above 60"
       (truthy? (message-of
                  (fn [] (worldgen/generate-from-heights
                           (buffer/new-filled world/chunk-volume 0) 0 0
                           (buffer/new-filled 256 200))))))

#
# --- Scene options ------------------------------------------------------
#
(print "\nscene options:")

(def sea (game/scenic-sea-level map-dir))
(check "the map's declared sea level is read from the record"
       (= 60 sea))
(def opts (game/scenic-scene-opts scenic-cache sea))
(check "the sea level reaches the scene options"
       (= 60 (opts :sea-level)))
(game/scenic-setup! scenic-cache)
(check "spawn selection uses the map's declared waterline, not hardcoded 28"
       (= 60 (game/session-sea-level)))
# The measured watershed values, pinned as LITERALS. Deriving these from the
# format ceiling produced 212/162 and two renders with no visible snow; the map's
# band says what a tile may contain, never where this watershed's snowline is.
(check "the snow line is the measured 170"
       (= 170 (opts :snow-line)))
(check "the tree line is the measured 150"
       (= 150 (opts :tree-line)))
(check "the snow line is not derived from the format ceiling"
       (not= (- 252 40) (opts :snow-line)))
(check "the tree line is not derived from the format ceiling"
       (not= (- 252 90) (opts :tree-line)))
# The rest of the authored scene must survive untouched, because a wrong slope
# gate silently produces a rock map or a forest map rather than an error.
(check "rock slope is 6" (= 6 (opts :rock-slope)))
(check "tree slope is 4" (= 4 (opts :tree-slope)))
(check "lattice is 5" (= 5 (opts :lattice)))
(check "density is 45" (= 45 (opts :density)))
(check "the tree line is the authored scene constant"
       (= game/scenic-tree-line (opts :tree-line)))
# The format CEILING is not the map's snowline: a wide-band artifact must not
# push snow onto a ridge that never reaches the authored line.
(check "the snow line does not follow the format ceiling"
       (not= (- 252 40) (opts :snow-line)))
(check "the seed comes from the manifest, not the module default"
       (= 4 (opts :seed)))

# The scene lines are authored and therefore independent of the declared band:
# two artifacts with different ceilings get the same authored lines, while each
# keeps its own waterline. Deriving from the band would make the snowline jump
# whenever a map happened to be re-exported with a wider headroom.
(def low-dir (write-scenic (string (scratch-dir) "/" (string/repeat "f" 64))
                           {:bounds [0 0 1 1] :height-max 200 :sea 40}))
(def low-opts (game/scenic-scene-opts (tc/cache-new low-dir 4)
                                      (game/scenic-sea-level low-dir)))
(check "a narrower map keeps the authored snow line"
       (= game/scenic-snow-line (low-opts :snow-line)))
(check "a narrower map keeps the authored tree line"
       (= game/scenic-tree-line (low-opts :tree-line)))
(check "a narrower map still carries its own sea level"
       (= 40 (low-opts :sea-level)))
(check "the two maps differ only where the artifact says so"
       (= (opts :snow-line) (low-opts :snow-line)))

# An artifact that states no sea level must fall back rather than invent one.
(def nosea-dir (string (scratch-dir) "/" (string/repeat "0" 64)))
(write-scenic nosea-dir {:bounds [0 0 0 0]})
(def nosea-json "{\"seed\":4,\"mapping\":{\"height_min\":4,\"height_max\":252}}")
(write-bytes (tc/scenic-json-path nosea-dir) nosea-json)
(write-bytes (string nosea-dir "/manifest.janet")
             (string "{:format 3 :magic \"TDS3\" :identity \""
                    (string/repeat "0" 64)
                    "\" :seed 4 :payload-bytes 256 :tile-bytes 308"
                    " :height-min 4 :height-max 252 :bounds [0 0 0 0]"
                    " :origin [0 0] :json-bytes " (length nosea-json)
                    " :json-crc32 " (integrity/crc32 nosea-json) "}"))
(check "a record with no sea level answers nil rather than guessing"
       (nil? (game/scenic-sea-level nosea-dir)))
(check "and the scene falls back to the module default"
       (= 28 ((game/scenic-scene-opts (tc/cache-new nosea-dir 4) nil) :sea-level)))

#
# --- Streaming scope ----------------------------------------------------
#
(print "\nstreaming scope:")

(game/scenic-setup! (tc/cache-new map-dir 4))
(def wanted (game/wanted-chunks 301 0 6))
(check "the wanted set is non-empty inside the map"
       (pos? (length wanted)))
(check "no wanted coordinate lies outside the map"
       (every? (map (fn [e] (game/scenic-in-bounds? (e 0) (e 1))) wanted)))
(check "the wanted set is a strict subset of the unbounded radius"
       (< (length wanted) (length (stream/chunks-in-radius 301 0 6))))
(check "the wanted set keeps the nearest-first order"
       (do
         (var ok true)
         (var last -1)
         (each e wanted
           (when (< (e 2) last) (set ok false))
           (set last (e 2)))
         ok))

# Without a map the same call is the unbounded list, byte for byte.
(game/scenic-reset!)
(check "without a scenic map the wanted set is the full radius"
       (= (length (stream/chunks-in-radius 301 0 6))
          (length (game/wanted-chunks 301 0 6))))
(check "an unscoped session answers in-bounds for everything"
       (game/scenic-in-bounds? 999999 -999999))

#
# --- No backend for a finite map ----------------------------------------
#
(print "\nno backend for a finite map:")

(game/scenic-setup! (tc/cache-new map-dir 4))
(def req-dir (string (scratch-dir) "/" (string/repeat "1" 64)))
(write-scenic req-dir {:bounds [0 0 1 1]})
(def req-cache (tc/cache-new req-dir 4))
(check "a scenic session never publishes a request marker"
       (= :no-backend (game/request-tile! req-cache 0 0)))
(check "and no marker file was written"
       (empty? (try (os/dir (tc/requests-dir req-dir)) ([e] @[]))))
(game/scenic-reset!)
# The legacy path still asks, and answers with a real cache verb.
(check "a legacy session still asks the cache"
       (not= :no-backend (game/request-tile! (tc/cache-new sdir 4) 0 0)))

# The loading-stage decision is a PREDICATE here rather than a branch buried in
# the frame loop, so "would a scenic session wait for a worker?" is answerable
# without a window.
(check "a scenic session never autostarts a worker"
       (not (game/maybe-start-worker-allowed? true false false)))
(check "a scenic session refuses a worker even when asked for one"
       (not (game/maybe-start-worker-allowed? false true false)))
(check "a legacy session still autostarts"
       (truthy? (game/maybe-start-worker-allowed? false false false)))
(check "and --no-terrain-worker still suppresses it"
       (not (truthy? (game/maybe-start-worker-allowed? true false false))))

#
# --- The artifact's seed governs ----------------------------------------
#
(print "\nartifact seed:")

# A scenic export is baked at ITS OWN seed; the session default has nothing to do
# with the map. The first real watershed is seed 12345 against this file's 4, so
# demanding agreement made every real artifact unopenable. The map must adopt the
# manifest's seed rather than be refused.
(def seeded-dir (string (scratch-dir) "/" (string/repeat "3" 64)))
(write-scenic seeded-dir {:bounds [0 0 1 1] :seed 12345})
(def seeded (game/cache-open seeded-dir))
(check "a scenic artifact opens under its own seed"
       (truthy? seeded))
(check "and the session adopts that seed"
       (= 12345 game/seed))
(check "the scene options decorate with the artifact's seed"
       (= 12345 ((game/scenic-scene-opts seeded 28) :seed)))
(game/scenic-reset!)

# A LEGACY cache keeps the exact seed check it always had: its tiles carry no
# generation of their own, so serving one baked for another seed would hand the
# session terrain from a different world.
(def legacy-seeded (string (scratch-dir) "/" (string/repeat "4" 64)))
(os/mkdir legacy-seeded)
(write-bytes (string legacy-seeded "/manifest.janet")
             (string "{:format 2 :magic \"TDH2\" :identity \""
                    (string/repeat "4" 64)
                    "\" :seed 999 :payload-bytes 256 :tile-bytes 308}"))
(os/mkdir (string legacy-seeded "/" (string/repeat "4" 64)))
(def legacy-ident-dir
  (string legacy-seeded "/" (string/repeat "4" 64)))
(write-bytes (string legacy-ident-dir "/manifest.janet")
             (string "{:format 2 :magic \"TDH2\" :identity \""
                    (string/repeat "4" 64)
                    "\" :seed 999 :payload-bytes 256 :tile-bytes 308}"))
(check "a legacy cache baked for another seed is still refused"
       (truthy? (message-of (fn [] (game/cache-open legacy-ident-dir)))))

#
# --- Interactive scenic launch ------------------------------------------
#
(print "\ninteractive scenic view:")

# The camera must be applied when a person launches with --scenic-view, not only
# when --screenshot is also given. Before this, `--scenic-view valley` parsed a
# preset and then silently ignored it: the player spawned at the map centre.
(check "a capture applies the camera"
       (truthy? (game/camera-view-applies? true "valley" false)))
(check "an interactive scenic launch applies the camera"
       (truthy? (game/camera-view-applies? nil "valley" true)))
(check "a bare --scenic-view interactive launch applies it"
       (truthy? (game/camera-view-applies? nil "explicit" true)))
(check "no scenic view means no camera override"
       (not (truthy? (game/camera-view-applies? true nil false))))
(check "an interactive run without a scenic view is untouched"
       (not (truthy? (game/camera-view-applies? nil nil false))))

# The valley preset is the placement the user asked for: on the map, at eye
# height, looking west down the valley.
(def valley (game/scenic-preset "valley"))
(check "the valley preset exists" (not (nil? valley)))
(check "the valley start is the inspected open ridge shoulder (-24,-37)"
       (and (= -24 (valley :x)) (= -37 (valley :z))))
# The valley preset must NOT carry a height. Its ground is y68; a preset that
# declares y175 is what left the player hovering, and the ground has to win.
(check "the valley preset carries no height of its own"
       (nil? (valley :y)))
# The aerial overview keeps its explicit eye: it is a viewpoint in the air, not a
# place to stand, and grounding it would put the camera inside the mountain.
(check "the aerial preset keeps its explicit eye height"
       (= 250 ((game/scenic-preset "aerial") :y)))

#
# --- Grounded interactive start ----------------------------------------
#
(print "\ngrounded start:")

# `scenic-ground-y` answers from the LIVE voxels: support under the box, air
# through it, and water rejected rather than treated as a floor. Built here from a
# hand-made world so the rule is tested without a cache or a window.
(defn- world-with [heights water?]
  (def w (world/world-new))
  (for cz 0 2
    (for cx 0 2
      (def ch (world/chunk-new cx cz))
      (for z 0 world/chunk-z
        (for x 0 world/chunk-x
          (def h (get heights (+ x (* 16 z))))
          (for y 0 40
            (world/chunk-set ch x y z
                             (cond (< y h) world/block-stone
                                   (= y h) (if water? world/block-water
                                               world/block-grass)
                                   world/block-air)))))
      (world/world-put-chunk w ch)))
  w)

(def flat (world-with (map (fn [_] 20) (range 256)) false))
(check "dry flat ground is found at its surface"
       (= 21 (game/scenic-ground-y flat 5 5)))
(check "the box has clearance above the found ground"
       (let [y (game/scenic-ground-y flat 5 5)]
         (not (player/box-collides? flat 5 y 5))))
# Water is not ground: a sea column must not be reported as a place to stand.
(def sea (world-with (map (fn [_] 20) (range 256)) true))
(check "a water surface is not accepted as ground"
       (nil? (game/scenic-ground-y sea 5 5)))
# A column with no chunk at all is absence, not ground.
(check "an unloaded column has no ground"
       (nil? (game/scenic-ground-y flat 500 500)))

# A TREE IS NOT GROUND. `world/block-solid?` counts wood and leaves, because they
# are obstacles -- but a canopy is an obstacle with air underneath, so a scan that
# trusts "solid" seats the player in a treetop and the camera reads as floating.
# This is the exact failure a real launch produced.
(defn- world-with-tree []
  (def w (world/world-new))
  (def ch (world/chunk-new 0 0))
  (for z 0 world/chunk-z
    (for x 0 world/chunk-x
      (for y 0 40
        (world/chunk-set ch x y z
                         (cond (< y 20) world/block-stone
                               (= y 20) world/block-grass
                               world/block-air)))))
  # A conifer at (5,5): trunk from 21 to 26, canopy 27..30 wide enough to cover
  # the column itself, so a support test sees wood and leaves above the grass.
  (for y 21 27 (world/chunk-set ch 5 y 5 world/block-wood))
  (for dy 0 4
    (def y (+ 27 dy))
    (for dz -2 3 (for dx -2 3
                   (when (<= (+ (* dx dx) (* dz dz)) 4)
                     (world/chunk-set ch (+ 5 dx) y (+ 5 dz) world/block-leaves)))))
  (world/world-put-chunk w ch)
  w)
(def treed (world-with-tree))
# A trunk column has NO standing position: the column is wood from 21 to 26, so
# there is no air cell with ground beneath it. nil is the correct answer -- the
# failure would be returning the canopy height above it, which is what a
# "solid support" test does.
(check "a trunk column offers no standing position"
       (nil? (game/scenic-ground-y treed 5 5)))
(check "and never returns the canopy height above the trunk"
       (not= 31 (game/scenic-ground-y treed 5 5)))
# The ground immediately beside the trunk IS the grass surface, which is what a
# nearby search must find when the requested column is a tree.
# Feet stand ON TOP of the surface block: the grass is at y20, so the feet cell is
# y21. An off-by-one here would bury the player.
(check "ground beside the trunk is the cell above the grass"
       (= 21 (game/scenic-ground-y treed 6 5)))
(check "that ground sits on grass, not wood or leaves"
       (= world/block-grass (world/world-get-block treed 6 20 5)))
# And the leaf bed itself is never a support, even where leaves are the only
# thing between the air and the trunk.
(check "leaves are not a standing surface"
       (not (game/scenic-ground-y treed 5 30)))
(check "wood is not a standing surface"
       (not (game/scenic-ground-y treed 5 21)))
(check "the valley looks east over lower terrain rather than into the uphill wall"
       (= 0 (valley :yaw)))
(check "the grounded ridge shoulder looks gently downvalley"
       (= -0.1 (valley :pitch)))
# And the free-space preset is unchanged, so this edit did not disturb it.
(check "the aerial preset still exists"
       (not (nil? (game/scenic-preset "aerial"))))
(check "an unknown preset name is not a preset"
       (nil? (game/scenic-preset "no-such-view")))

#
# --- Finite resident set -----------------------------------------------
#
(print "\nfinite resident set:")

# A 4x4 fixture is enough to prove the SHAPE of the rule: the resident set is the
# manifest rectangle, independent of where the player stands. The real 1024-chunk
# count is a runtime property, measured by the parent, not a fixture cost.
(def res-dir (write-scenic (string (scratch-dir) "/" (string/repeat "7" 64))
                           {:bounds [0 0 3 3]}))
(def res-cache (tc/cache-new res-dir 4))
(game/scenic-setup! res-cache)

(def centre-wanted (game/wanted-chunks 1 1 12))
(def offcentre-wanted (game/wanted-chunks 3 3 12))
(check "a scenic resident set is the whole map"
       (= 16 (length centre-wanted)))
# Compared by membership in BOTH directions, not with `=`. A Janet table compares
# by IDENTITY, so `(= set-a set-b)` is false for two tables holding identical
# keys -- which is exactly the false failure this check first produced. The
# distance ordering also ties for equidistant chunks, so sequence equality would
# be the wrong question even on a list.
(check "the resident set does not depend on the player position"
       (let [key-set (fn [es]
                       (def out @{})
                       (each e es (put out (string (e 0) "," (e 1)) true))
                       out)
             a (key-set centre-wanted)
             b (key-set offcentre-wanted)
             same-keys? (fn [x y]
                          (var ok (= (length x) (length y)))
                          (each k (keys x) (unless (y k) (set ok false)))
                          (each k (keys y) (unless (x k) (set ok false)))
                          ok)]
         (same-keys? a b)))
(check "every resident coordinate is inside the bounds"
       (every? (map (fn [e] (tc/in-bounds? res-cache (e 0) (e 1)))
                    offcentre-wanted)))
# The set must be exactly the rectangle, never a coordinate outside it -- the
# stream must not spend a frame on terrain the artifact cannot contain.
(check "no coordinate outside the bounds is ever resident"
       (not (any-true? (map (fn [e] (or (< (e 0) 0) (> (e 0) 3)
                                        (< (e 1) 0) (> (e 1) 3)))
                            offcentre-wanted))))
(check "the resident set is bounded by the map, not by the radius"
       (< (length offcentre-wanted) (length (stream/chunks-in-radius 3 3 12))))

# Off-centre, nothing may be dropped: the whole map is wanted wherever you stand.
(check "an off-centre player leaves surplus empty"
       (empty? (game/surplus-chunks-for 3 3 12 2 (keys (get (world/world-new) :chunks)))))
(check "surplus is empty even with every map chunk loaded"
       (empty? (game/surplus-chunks-for 0 0 12 2
                                        (map (fn [e] [(e 0) (e 1)]) centre-wanted))))
# Without a map the hysteresis rule is the old one, unchanged.
(game/scenic-reset!)
(check "a session without a map still drops far chunks"
       (pos? (length (game/surplus-chunks-for 0 0 2 2 [[50 50]]))))

#
# --- Menu requirements --------------------------------------------------
#
(print "\nmenu entry points:")

# The menu is the DEFAULT for an interactive launch and is bypassed by everything
# that already names its world. This is the rule that keeps scripted and QA runs
# byte-identical to what they were before the front door existed.
(check "an interactive launch with no world flags opens the menu"
       (truthy? (game/menu-required?)))
(check "menu-providers offers procedural as available"
       (truthy? ((first (filter |(= :procedural ($ :id)) (game/menu-providers)))
                 :available)))
(check "the learned provider is offered UNAVAILABLE with a reason"
       (let [d (first (filter |(= :terrain-diffusion-native ($ :id))
                              (game/menu-providers)))]
         (and (not (truthy? (d :available)))
              (string? (d :reason))
              (pos? (length (d :reason))))))
# The registry now declares REAL controls, and the menu offers exactly those.
# A control the provider cannot honour would be the lie this menu exists to avoid,
# so the count and each id are checked against the registry itself.
(def proc-row (first (filter |(= :procedural ($ :id)) (game/menu-providers))))
(check "the procedural provider explicitly offers five settings-v2 controls"
       (and (= 2 (proc-row :settings-version))
            (= 5 (length (proc-row :controls)))))
(check "each offered control carries a label and bounds"
       (every? (map (fn [c] (and (string? (c :label)) (number? (c :min))
                                 (number? (c :max))))
                    (proc-row :controls))))
(check "the control ids are the generation settings, not invented knobs"
       (every? (map (fn [c] (some |(= $ (c :id))
                                  [:height-scale :height-offset :sea-level
                                   :forest-density :clearing-density]))
                    (proc-row :controls))))
# The unavailable provider offers no knobs: there is nothing to configure.
(check "an unavailable provider declares no controls"
       (empty? ((first (filter |(= :terrain-diffusion-native ($ :id))
                               (game/menu-providers))) :controls)))
# A missing catalog root is "no worlds", not an error.
(check "a missing world root lists no worlds"
       (empty? (game/menu-worlds "tmp/__no_such_world_root_xyz")))

#
# --- Provider dispatch for the QA create path --------------------------
#
(print "\ndirect create provider:")

# `--new-world` builds the same request the form builds. The provider must reach
# that request, or a controlled real run would silently create a procedural world
# while claiming to test the Python one.
(def providers (game/menu-providers))
(check "the registry reaches the menu with the python provider present"
       (truthy? (some |(= :terrain-diffusion-python ($ :id)) providers)))
(check "the native provider is still unavailable"
       (not (truthy? ((first (filter |(= :terrain-diffusion-native ($ :id))
                                    providers)) :available))))
(check "provider defaults are what a QA create asks for"
       (let [d (provider/provider-defaults :terrain-diffusion-python)]
         (and (= 128 (d :size)) (= 28 (d :sea-level))
              (= "alpine" (d :profile)))))
# The generation gate is separate from the schema gate, so a create can ask for a
# provider that cannot run and be told NO rather than silently getting procedural.
(check "the native provider cannot generate"
       (not (truthy? (provider/available? :terrain-diffusion-native))))
(check "the python provider requires verified runtime readiness"
       (not (truthy? (provider/available? :terrain-diffusion-python))))

#
# --- Generation argv ---------------------------------------------------
#
(print "\ngeneration argv:")

# The command line is the ONE place a wrong seed silently changes what the model
# samples. It must carry the WORLD seed, unmapped: the provider owns the
# world->model mapping, and pre-mapping here would map twice and lose the
# original -- which is exactly how world seed 0 stops being reproducible.
(def gen-argv
  (game/generation-argv "python3" "gen.py" "/tmp/out"
                        {:size 128 :sea-level 28 :profile "alpine"} 0
                        "/tmp/out/stage.janet"))
(check "the argv is an array, so a path with a space stays one argument"
       (array? gen-argv))
(defn index-of-value [argv flag]
  (var found nil)
  (for i 0 (length argv)
    (when (= flag (get argv i)) (set found i)))
  found)
(defn argv-value [flag]
  (var found nil)
  (for i 0 (- (length gen-argv) 1)
    (when (= flag (get gen-argv i)) (set found (get gen-argv (+ i 1)))))
  found)
# THE SEED. World seed 0 goes on the command line as "0", not as its model seed.
(check "world seed 0 is passed as 0, not pre-mapped"
       (= "0" (argv-value "--seed")))
(check "the argv does not carry a model seed anywhere"
       (nil? (string/find "2147483647" (string/join gen-argv " "))))
(check "a nonzero world seed is passed unchanged"
       (let [a (game/generation-argv "p" "s" "/o"
                                     {:size 128 :sea-level 28 :profile "alpine"}
                                     42 "/o/stage.janet")]
         (= "42" (get a (+ 1 (index-of-value a "--seed"))))))
(check "the settings reach the command line"
       (and (= "128" (argv-value "--size"))
            (= "28" (argv-value "--sea-level"))
            (= "alpine" (argv-value "--profile"))))
(check "the progress sidecar is requested"
       (= "/tmp/out/stage.janet" (argv-value "--progress")))
(check "the output root is requested"
       (= "/tmp/out" (argv-value "--out")))
# Unbuffered, so a stage line reaches the file while the model is still running.
(check "the interpreter runs unbuffered"
       (truthy? (some |(= "-u" $) gen-argv)))

#
# --- Startup presenter lifetime ----------------------------------------
#
(print "\nstartup presenter:")

# ONE presenter serves the menu backdrop and the loading stage. Two instances
# would mean two decodes, two slideshow clocks, and the art visibly restarting at
# the handoff -- so the stage takes it as an argument rather than building its own.
# `loading-stage` declares an optional screen parameter; passing nil is the text
# fallback and must remain legal for a machine with no art.
# The stage is CALLED with the presenter in main; that call is what proves the
# signature, and it compiles. What is testable here is the presenter contract the
# stage relies on.
(check "a presenter can be built without a window, filesystem only"
       (let [screen (loading-screen/new {:root "."})]
         (and (table? screen)
              (array? (loading-screen/paths screen)))))
(check "a fresh presenter reports no textures decoded yet"
       (let [screen (loading-screen/new {:root "." :paths []})]
         (and (zero? (loading-screen/loaded-count screen))
              (truthy? (loading-screen/fallback? screen)))))
(check "dispose is idempotent, so a double teardown is safe"
       (let [screen (loading-screen/new {:root "." :paths []})]
         (loading-screen/dispose screen)
         (loading-screen/dispose screen)
         true))

#
# --- Python generation progress ----------------------------------------
#
(print "\ngeneration progress:")

# The provider writes append-only JSON lines and reports only stages it REACHED.
# There is no percentage anywhere, because a fraction of an unknown cost is a
# fabricated number -- so the label shows the last real stage and nothing more.
(check "the last reached stage becomes the label"
       (= "sample" (game/generation-progress-label
                     "{\"stage\":\"verify\"}\n{\"stage\":\"sample\"}\n")))
(check "a message on the record is preferred over the bare stage"
       (= "loading weights"
          (game/generation-progress-label
            "{\"stage\":\"load\",\"message\":\"loading weights\"}")))
(check "empty progress has no label"
       (nil? (game/generation-progress-label "")))
(check "nil progress has no label"
       (nil? (game/generation-progress-label nil)))
(check "a malformed line does not raise"
       (nil? (game/generation-progress-label "{not json")))
# A terminal failure stage is a real record the UI may show; it must not be
# mistaken for progress toward success.
(check "a failed stage is reported as its own label"
       (= "failed" (game/generation-progress-label "{\"stage\":\"failed\"}")))
# Blank lines between records (a partially written tail) are ignored rather than
# yielding an empty label.
(check "trailing blank lines are ignored"
       (= "export"
          (game/generation-progress-label
            "{\"stage\":\"export\"}\n\n\n")))

#
# --- Player pose persistence -------------------------------------------
#
(print "\nplayer pose:")

# The catalogue records exactly four fields and REJECTS extra keys, so the runtime
# player cannot be handed over directly -- it carries :vel, :on-ground and more.
# `player-pose` is the projection, and its shape is the contract.
(def live (player/player-new 3.5 46 -7.5))
(put live :yaw 1.25) (put live :pitch -0.4) (put live :flying true)
(def pose (game/player-pose live))
(check "a pose has exactly the four persisted fields"
       (= 4 (length (keys pose))))
(check "a pose carries no runtime-only fields"
       (not (or (has-key? pose :vel) (has-key? pose :on-ground))))
# `=` on arrays and tables is IDENTITY in Janet, not structural equality, so a
# position has to be compared element by element. This is the fourth time that
# has produced a false failure here.
(defn same-pos? [a b]
  (and (= 3 (length a)) (= 3 (length b))
       (= (get a 0) (get b 0)) (= (get a 1) (get b 1)) (= (get a 2) (get b 2))))
(check "the pose keeps the position"
       (same-pos? @[3.5 46 -7.5] (pose :pos)))
(check "the pose keeps the orientation"
       (and (= 1.25 (pose :yaw)) (= -0.4 (pose :pitch))))
# The catalogue validates a 4-key table, so this is the shape that survives it.
(check "the pose is exactly what the catalogue validates"
       (every? (map (fn [k] (some |(= $ k) [:pos :yaw :pitch :flying]))
                    (keys pose))))

# Restoring must actually move the player. A no-op restore that reports success
# is the bug this test exists for: the first version silently skipped a restored
# position because it arrived as a TUPLE and the check only accepted arrays.
(def fresh (player/player-new 0 0 0))
(game/apply-pose! fresh @{:pos (tuple 9.25 51 2.75) :yaw 2.5 :pitch 0.1
                          :flying false})
(check "a tuple position is restored"
       (same-pos? @[9.25 51 2.75] (fresh :pos)))
(check "a restored yaw is applied" (= 2.5 (fresh :yaw)))
(check "a restored pitch is applied" (= 0.1 (fresh :pitch)))
(check "a restored flying flag is applied"
       (not (truthy? (fresh :flying))))
# An array position works too, because a live pose and a parsed one differ.
(def fresh2 (player/player-new 0 0 0))
(game/apply-pose! fresh2 @{:pos @[1 2 3] :yaw 0.5 :pitch 0 :flying true})
(check "an array position is restored" (same-pos? @[1 2 3] (fresh2 :pos)))
# A malformed pose must leave the player alone rather than error: a world that
# loads but starts at spawn beats one that refuses to load.
(def untouched (player/player-new 7 8 9))
(game/apply-pose! untouched @{:pos @[1] :yaw 5})
(check "a malformed pose leaves the position alone"
       (same-pos? @[7 8 9] (untouched :pos)))

#
# --- Loading stage for heavy prep --------------------------------------
#
(print "\nloading stage for preload:")

# A preloaded finite map meshes 1024 chunks. That must take the incremental path
# even when the run is scripted, or the window freezes for ~12 s with no progress
# and no Esc.
(check "a preload run needs the incremental loading stage"
       (truthy? (game/loading-stage-required? true false true true true)))
(check "a preload run needs it even without --loading-* QA flags"
       (truthy? (game/loading-stage-required? true false true false true)))
(check "an interactive scenic run needs it"
       (truthy? (game/loading-stage-required? true false false false true)))
# The exceptions that already existed are unchanged.
(check "verify-pgo still refuses the stage"
       (not (truthy? (game/loading-stage-required? true true true true true))))
(check "a plain scripted run still skips the stage"
       (not (truthy? (game/loading-stage-required? true false true false false))))
(check "a procedural session never enters the stage"
       (not (truthy? (game/loading-stage-required? false false false false true))))

#
# --- Bounds are not a suggestion ----------------------------------------
#
(print "\nbounds are enforced by the cache too:")

(def guard-dir (write-scenic (string (scratch-dir) "/" (string/repeat "2" 64))
                             {:bounds [10 10 11 11]}))
(fill-tiles guard-dir (rect 10 10 11 11))
(def guard-cache (tc/cache-new guard-dir 4))
(check "a tile inside the bounds decodes"
       (truthy? (tc/read-height-tile guard-cache 11 11)))
(check "a coordinate outside the bounds is nil, not an error"
       (nil? (tc/read-height-tile guard-cache 12 11)))
# A tile FILE outside the bounds must be refused, not served: it would inject
# terrain from another mapping into this world.
(write-bytes (tc/tile-path guard-dir 12 11)
             (scenic-tile 12 11 (heights-varying)))
(check "a tile file outside the bounds is refused"
       (truthy? (message-of (fn [] (tc/read-height-tile guard-cache 12 11)))))
(check "requesting outside the bounds writes no marker"
       (= :out-of-bounds (tc/request guard-cache 12 11)))
(check "no marker file appeared for the out-of-bounds request"
       (not (os/stat (tc/request-path guard-dir 12 11))))

# The height field must never reach outside the map even at the exact edge,
# which is where an inclusive/exclusive error lives.
(game/scenic-setup! guard-cache)
(fill-tiles guard-dir (rect 10 10 11 11))
(check "the last covered column answers a height"
       (truthy? (game/scenic-height-at (+ (* 11 world/chunk-x) 15)
                                       (+ (* 11 world/chunk-z) 15))))
(check "one block past the last column answers nil"
       (nil? (game/scenic-height-at (+ (* 11 world/chunk-x) 16)
                                    (+ (* 11 world/chunk-z) 15))))
(check "one block before the first column answers nil"
       (nil? (game/scenic-height-at (dec (* 10 world/chunk-x))
                                    (+ (* 10 world/chunk-z) 3))))

#
# --- The New Game create handoff (settings version) ---------------------
#
# The production create path builds its catalogue options through
# `game/new-slot-options`. The test calls THAT function, not a copy of it: a
# literal rebuilt here would keep passing after the production table lost
# `:settings-version`, which is exactly the regression this guards.
#
# The bug being pinned: `catalog/create-slot` defaults a missing version to
# `provider/version` (1), and version 1 declares no `:clearing-density`, so a v2
# world generated cleared terrain and then failed to save -- into a swallowed
# "warning: world not saved".
(def handoff-root (scratch-dir))
(defn handoff-world []
  (def w (world/world-new))
  (def parsed (world-seed/parse-seed-input "handoff-mountain"))
  (put w :seed (get parsed :value))
  (def ch (world/chunk-new 0 0))
  (world/chunk-set ch 3 40 3 world/block-grass)
  (world/world-put-chunk w ch)
  [w parsed])
(defn handoff-pose []
  {:pos [3.25 41.0 -7.5] :yaw 0.5 :pitch -0.25 :flying false})

# 1. An EXPLICIT version on the form wins. The settings below contain no
#    clearing key at all, so an inference-driven implementation would answer 1:
#    only honouring the form's own version can produce 2.
(def [exp-w exp-parsed] (handoff-world))
(def explicit-opts
  (game/new-slot-options {:provider :procedural :settings-version 2 :settings {}}
                         exp-parsed exp-w (handoff-pose) "Explicit v2"))
(check "an explicit form version reaches the catalogue options"
       (= 2 (explicit-opts :settings-version)))
(check "the explicit version is not re-inferred from the settings"
       (not (has-key? (explicit-opts :settings) :clearing-density)))

# 2. With NO version on the form, the provider infers it from the presence of
#    the one key version 2 declares.
(def [inf-w inf-parsed] (handoff-world))
(def inferred-opts
  (game/new-slot-options {:provider :procedural
                          :settings @{:clearing-density 25}}
                         inf-parsed inf-w (handoff-pose) "Inferred v2"))
(check "a v2-only setting without a form version infers version 2"
       (= 2 (inferred-opts :settings-version)))

# 3. A legacy four-key table stays version 1 -- the inference must not lift an
#    already-saved world's contract upward.
(def [v1-w v1-parsed] (handoff-world))
(def legacy-opts
  (game/new-slot-options {:provider :procedural
                          :settings @{:height-scale 1.0 :height-offset 0
                                      :sea-level 28 :forest-density 0}}
                         v1-parsed v1-w (handoff-pose) "Legacy v1"))
(check "a legacy four-key settings table resolves to version 1"
       (= 1 (legacy-opts :settings-version)))

# 4. THE REAL HANDOFF: the options this factory produces are handed to the
#    catalogue, written to disk, and read back from the manifest. Nothing here
#    constructs a catalogue option table by hand.
(def v2-opts
  (game/new-slot-options {:provider :procedural :settings-version 2
                          :settings @{:clearing-density 25}}
                         v1-parsed v1-w (handoff-pose) "Real v2 slot"))
(def v2-slot (catalog/create-slot handoff-root v2-opts))
(def v2-manifest (catalog/load-manifest handoff-root v2-slot))
(check "a v2 world created through the handoff saves with settings-version 2"
       (= 2 (get v2-manifest :settings-version)))
(check "the saved manifest carries the clearing density it was created with"
       (= 25 (get (get v2-manifest :settings) :clearing-density)))
# The EXACT segment `src/world-catalog.janet` emits for a v2 identity; the
# literal is asserted, not derived from the writer, so a changed format fails.
(check "the saved identity carries the exact v2 clearing segment"
       (not (nil? (string/find ":clearing=25" (get v2-manifest :settings-identity)))))
(check "the reloaded slot's world still holds its chunk"
       (= 1 (world/world-chunk-count ((catalog/load-slot handoff-root v2-slot) :world))))
(rm-tree handoff-root)

#
# --- Capture readiness --------------------------------------------------
#
# `--capture-ready` exists because a fixed-frame capture photographs a mesh
# BACKLOG, not a map: the 1700-frame valley run reported `loaded 1024 wanted 797`
# at frame 1133 with `mesh queue 828`, and the PNG at frame 1699 showed holes.
# The predicate below is pure, so these checks drive the exact decision the frame
# loop makes without a window, a GPU or a mesher.
#
# Fixtures are built with `world/world-put-chunk`, so the map under test is the
# same one the loop reads: `(:chunks w)`.
(defn ready-world
  "A world holding exactly `coords`, which are `[cx cz]` tuples."
  [coords]
  (def w (world/world-new))
  (each c coords
    (world/world-put-chunk w {:cx (c 0) :cz (c 1) :blocks @[]}))
  w)

(defn ready?
  "Ask the predicate about `w` as the frame loop would."
  [w wanted dirty]
  (game/capture-ready? (get w :chunks) wanted
                       (world/world-chunk-count w) dirty))

# Clipping and counting. `wanted` is a REQUEST list, and a request list is not a
# promise: on a finite map it can name coordinates the map does not cover, and
# the loop's own list can contain a coordinate twice. Neither may corrupt the
# gate -- an out-of-bounds requirement turns "fully loaded" into a guaranteed
# timeout, and a duplicate demands a chunk no loader could supply twice.
#
# The bounds are passed EXPLICITLY here, which is the point of the optional
# argument: before it, the predicate read the module-level scenic cache, so a
# test could not control which map it was being asked about.
(def bounds-4x4 (fn [cx cz] (and (<= -2 cx 1) (<= -2 cz 1))))

(check "capture-required-keys drops coordinates outside the map"
       (= 1 (length (game/capture-required-keys @[@[0 0 0] @[9 9 1]]
                                                bounds-4x4))))
(check "capture-required-keys de-duplicates a repeated coordinate"
       (= 1 (length (game/capture-required-keys
                      @[@[0 0 0] @[0 0 5] @[0 0 9]] (fn [_ _] true)))))
(check "capture-wanted-count counts DISTINCT chunks, not entries"
       (= 3 (game/capture-wanted-count @[@[0 0 0] @[0 0 1] @[1 1 2] @[99 99 3]]
                                       (fn [_ _] true))))

#
# --- Authored clearing density (diagnostic) -----------------------------
#
# The unit is the ENGINE'S OWN: an integer PERCENT of coarse cells in 0..100,
# passed through unchanged. There is no fraction form and no scaling, so the
# cases that matter are an integer in range (accepted, verbatim) and everything
# else (refused). A fraction is refused rather than rescaled because converting
# it would silently replace the operator's number, and nothing in the image
# would reveal it. The validator is pure, so none of this needs a window.
#
# It is a FREQUENCY over cells, not a percentage of cleared ground: 25 does not
# clear 25% of the area.
#
(check "zero is a valid density"
       (game/scenic-clearing-density-ok? 0))
(check "25 is a valid density and is the number the engine receives"
       (game/scenic-clearing-density-ok? 25))
(check "100 is a valid density (every coarse cell selected)"
       (game/scenic-clearing-density-ok? 100))
(check "1 and 99 are valid densities"
       (and (game/scenic-clearing-density-ok? 1)
            (game/scenic-clearing-density-ok? 99)))
# The correction this round exists for: a fraction must NEVER be rescaled.
(check "a fraction is refused, not rescaled"
       (not (game/scenic-clearing-density-ok? 0.25)))
(check "a fractional percent is refused"
       (not (game/scenic-clearing-density-ok? 25.5)))
(check "a value above 100 is refused"
       (not (game/scenic-clearing-density-ok? 101)))
(check "a negative value is refused"
       (not (game/scenic-clearing-density-ok? -1)))
(check "NaN is refused rather than clamped to zero"
       (not (game/scenic-clearing-density-ok? (/ 0 0))))
(check "infinity is refused"
       (not (game/scenic-clearing-density-ok? (/ 1 0))))
# A string is what a caller sees if they pass the raw argument without parsing,
# so this pins that the validator does not accept the flag's raw text.
(check "a string is refused"
       (not (game/scenic-clearing-density-ok? "25")))
(check "nil is refused"
       (not (game/scenic-clearing-density-ok? nil)))
# The context guard this flag shares with --climate-surfaces: a diagnostic that
# would change a persisted world's scenery without versioning its identity must
# not run. Asserted as the same predicate the flag uses.
(defn diagnostic-context-ok? [view shot slot new-world]
  (truthy? (and view shot (nil? slot) (nil? new-world))))
(check "a scenic screenshot outside any world slot is a valid diagnostic context"
       (diagnostic-context-ok? "valley" "out.png" nil nil))
(check "a saved world slot is refused"
       (not (diagnostic-context-ok? "valley" "out.png" "slot-id" nil)))
(check "a newly created world is refused"
       (not (diagnostic-context-ok? "valley" "out.png" nil "new")))
(check "an interactive scenic run with no screenshot is refused"
       (not (diagnostic-context-ok? "valley" nil nil nil)))
# The decisive case: a request list naming terrain the map does not have must
# still permit a ready verdict once the map's own chunks are resident.
(check "an out-of-bounds wanted coordinate cannot block readiness"
       (game/capture-ready? (get (ready-world @[@[0 0] @[1 1]]) :chunks)
                            @[@[0 0 0] @[1 1 1] @[9 9 2]] 2 0 bounds-4x4))
(check "the same list WITHOUT clipping would never be ready"
       (not (game/capture-ready? (get (ready-world @[@[0 0] @[1 1]]) :chunks)
                                 @[@[0 0 0] @[1 1 1] @[9 9 2]] 2 0)))
(check "a wonky wanted list that is entirely out of bounds is not ready"
       (not (game/capture-ready? (get (ready-world @[@[0 0]]) :chunks)
                                 @[@[9 9 0] @[8 8 1]] 1 0 bounds-4x4)))

(def wanted-pair @[@[0 0 0] @[1 0 1]])
(def pair-coords @[@[0 0] @[1 0]])

(check "a drained queue over the whole wanted set is ready"
       (ready? (ready-world pair-coords) wanted-pair 0))
(check "any pending mesh job means NOT ready"
       (not (ready? (ready-world pair-coords) wanted-pair 1)))
# The defect this flag closes: the count was large enough while a coordinate the
# camera actually looks at was still missing. Counts cannot see that.
(check "a loaded count at the wanted count still fails when one is missing"
       (let [w (ready-world @[@[0 0]])]
         (and (= 1 (world/world-chunk-count w))
              (not (ready? w wanted-pair 0)))))
(check "an empty wanted list is NOT ready -- nothing wanted means nothing decided"
       (not (ready? (ready-world pair-coords) @[] 0)))
(check "loaded below the wanted count is rejected before the membership walk"
       (not (game/capture-ready? (get (ready-world pair-coords) :chunks)
                                 @[@[0 0 0] @[1 0 1] @[2 0 2]] 2 0)))
# Membership, not counts: four resident chunks satisfy the count for two wanted
# ones, and the answer must still be a plain true rather than anything derived
# from `loaded`. Then the SAME world with a wanted coordinate swapped out fails,
# which a count-based rule could not distinguish.
(check "membership decides, not the loaded count"
       (let [w (ready-world @[@[0 0] @[1 0] @[5 5] @[6 6]])]
         (ready? w wanted-pair 0)))
(check "a wanted coordinate absent from the world is NOT ready"
       (not (ready? (ready-world @[@[0 0] @[1 0] @[5 5] @[6 6]])
                    @[@[0 0 0] @[5 6 1]] 0)))
(check "a negative or non-numeric queue length is not ready"
       (not (ready? (ready-world pair-coords) wanted-pair -1)))
(check "a nil queue length is not ready (an unreadable counter cannot be zero)"
       (not (game/capture-ready? (get (ready-world pair-coords) :chunks)
                                 wanted-pair 2 nil)))
# An EMPTY map against a non-empty wanted list is the pre-stream state: loaded 0,
# wanted n. It must not read as ready, which is why the count lower bound exists
# in addition to membership.
(check "an empty world with a non-empty wanted list is not ready"
       (not (ready? (ready-world @[]) wanted-pair 0)))

# The timeout is the ceiling that stops "not ready yet" from becoming "wait
# forever". Its rule lives in one pure predicate so the flag gate and these
# checks cannot drift apart.
(check "a normal timeout budget is accepted"
       (game/capture-timeout-ok? 180))
(check "a fractional timeout budget is accepted"
       (game/capture-timeout-ok? 0.5))
# The cap is one hour. Unbounded was the earlier policy and it was wrong for the
# same reason the gate exists: an operator-supplied infinity is a hang with a
# flag's blessing, so the ceiling is part of the rule rather than an error case.
(check "the cap is one hour"
       (= 3600 game/capture-timeout-cap))
(check "a budget at the cap is accepted"
       (game/capture-timeout-ok? 3600))
(check "a budget just past the cap is refused"
       (not (game/capture-timeout-ok? 3601)))
(check "an absurdly large budget is refused rather than accepted"
       (not (game/capture-timeout-ok? 100000)))
# Infinity is the specific value this ceiling exists to reject: it is a number
# and it is positive, so only an upper bound excludes it.
(check "an infinite budget is refused"
       (not (game/capture-timeout-ok? (/ 1 0))))
(check "a budget far beyond any real capture is refused"
       (not (game/capture-timeout-ok? 1e9)))
(check "a zero timeout budget is refused"
       (not (game/capture-timeout-ok? 0)))
(check "a negative timeout budget is refused"
       (not (game/capture-timeout-ok? -1)))
(check "a nil timeout budget is refused"
       (not (game/capture-timeout-ok? nil)))
(check "a NaN timeout budget is refused"
       (not (game/capture-timeout-ok? (/ 0 0))))
(check "a non-numeric timeout budget is refused"
       (not (game/capture-timeout-ok? "180")))

# The loop driver. Turning a frame bound into a floor is one step away from a CI
# job that never returns, so the policy is a pure function of five booleans and
# is pinned here: the floor exists ONLY for an armed capture that is neither done
# nor timed out, and every other combination keeps the historical bound.
(check "an unbounded session keeps running"
       (game/capture-loop-continues? nil 0 false false false))
(check "an unbounded session keeps running even after a shot"
       (game/capture-loop-continues? nil 500 false true false))
(check "below the frame bound the loop runs (historical behaviour)"
       (game/capture-loop-continues? 90 89 false false false))
(check "below the frame bound the loop runs even for a plain benchmark"
       (game/capture-loop-continues? 90 0 false false false))
# The one mode that waits.
(check "an armed capture continues past the bound while not done or failed"
       (game/capture-loop-continues? 90 90 true false false))
(check "an armed capture continues long past the bound while still working"
       (game/capture-loop-continues? 90 1700 true false false))
(check "an armed capture STOPS once the screenshot was written"
       (not (game/capture-loop-continues? 90 90 true true false)))
(check "an armed capture STOPS once it has timed out"
       (not (game/capture-loop-continues? 90 90 true false true)))
# The floor is scoped to the flag: without it, a bound is a bound.
(check "an UNARMED run stops at the frame bound even if neither flag is set"
       (not (game/capture-loop-continues? 90 90 false false false)))
(check "an armed capture that is done stops before the deadline can fire"
       (not (game/capture-loop-continues? 90 5000 true true true)))

#
# --- The window is asked, not assumed -----------------------------------
#
# A launch whose `InitWindow` failed used to reach `BeginDrawing` anyway, on the
# very first frame the readiness pump draws, and die on a null raylib context.
# The crash said nothing about the window, so the real cause -- no display, or GL
# refusing the context -- was invisible in the log.
#
# These drive the ACTUAL frame owner (`loading-frame!`), not a copy of it, with a
# readiness value and three spies. Nothing here opens a window or touches GL: the
# point is the ORDER, which is exactly what a real crash got wrong.
#
(print "\nwindow readiness:")
(defn spy-set []
  (def calls @[])
  @{:calls calls
    :begin (fn [] (array/push calls :begin))
    :draw (fn [] (array/push calls :draw))
    :end (fn [] (array/push calls :end))})

# NOT READY. This is the crash path: every callback must stay untouched, and the
# refusal must be observable rather than a silent success.
(let [s (spy-set)
      drew (game/loading-frame! (fn [] false) (s :begin) (s :draw) (s :end))]
  (check "a frame is refused when the window is not ready" (not drew))
  (check "and BeginDrawing is never reached"
         (not (some |(= :begin $) (s :calls))))
  (check "and no draw work is attempted"
         (empty? (s :calls))))

# READY. A balanced begin/draw/end is the whole contract; an unbalanced pair is a
# hung frame, not a missing one.
(let [s (spy-set)
      drew (game/loading-frame! (fn [] true) (s :begin) (s :draw) (s :end))]
  (check "a ready window draws exactly one frame" drew)
  (check "the frame is balanced begin -> draw -> end"
         (deep= @[:begin :draw :end] (s :calls))))

# THE TRANSITION. Readiness is asked EVERY frame, never cached: a window that goes
# away mid-run (closed by the user, or the context lost) must stop drawing at once
# rather than drawing into a dead context. The second frame of this session is
# exactly the case a cached `true` would get wrong.
(let [s (spy-set)
      ready @{:v true}
      first (game/loading-frame! (fn [] (ready :v)) (s :begin) (s :draw) (s :end))
      _ (put ready :v false)
      second (game/loading-frame! (fn [] (ready :v)) (s :begin) (s :draw) (s :end))]
  (check "the first frame draws while the window is ready" first)
  (check "the second frame REFUSES after the window goes away" (not second))
  (check "and nothing was drawn into the dead context"
         (deep= @[:begin :draw :end] (s :calls))))

# THE STARTUP GATE. A failed window must abort the launch at the point the window
# should have opened -- before any probe, asset or frame work -- with a message
# that names the cause instead of leaving a null dereference to speak for it.
(check "a ready window passes the startup gate without raising"
       (do (game/require-ready-window! (fn [] true)) true))
(let [[ok? err] (protect (game/require-ready-window! (fn [] false)))]
  (check "a failed window aborts the launch" (not ok?))
  (check "and the refusal names window initialization"
         (truthy? (string/find "window initialization failed" (string err))))
  (check "and it says nothing was generated"
         (truthy? (string/find "Nothing was generated" (string err)))))

#
# --- Cleanup ------------------------------------------------------------
#
(game/scenic-reset!)
(each d [sdir small-dir big-dir map-dir low-dir nosea-dir req-dir guard-dir]
  (rm-tree d))

(if (zero? failures)
  (print "\nscenic main integration: ALL CHECKS PASSED")
  (do (printf "\nscenic main integration: %d FAILED" failures) (os/exit 1)))
