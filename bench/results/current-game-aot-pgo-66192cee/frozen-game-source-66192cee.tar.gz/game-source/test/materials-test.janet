# Pure tests for the nine shipped block descriptors. No GL, no window, no
# model, no filesystem writes, and world is READ only (never modified).
(import ../src/materials :as m)
(import ../src/world :as world)

(var failures 0)
(defn check [name ok]
  (if ok (printf "  ok   %s" name)
      (do (++ failures) (printf "  FAIL %s" name))))

(print "shape:")
(check "version is 1" (= 1 m/version))
(check "block-count is 9" (= 9 m/block-count))
(check "valid? accepts the shipped table" (m/valid?))
(check "nine descriptors" (= 9 (length m/descriptors)))
(check "ids are exactly 0..8" (= (m/ids) (tuple ;(range 0 9))))
# Immutability is structural: tuples and struct literals, no freeze required.
(check "registry is a tuple, not an array" (tuple? m/descriptors))
(check "every entry is a struct, not a table"
       (every? (map |(struct? $) m/descriptors)))
(check "planned is a tuple of structs"
       (and (tuple? m/planned) (every? (map |(struct? $) m/planned))))
(check "no entry is a mutable table"
       (not (some (fn [d] (table? d)) m/descriptors)))
(check "a descriptor rejects put"
       (try (do (put (m/by-id 1) :solid false) false) ([e] true)))
(check "the registry rejects put" (try (do (put m/descriptors 0 {:id 99}) false) ([e] true)))

(print "agreement with src/world.janet (read only):")
(each id (range 0 9)
  (check (string "id " id " name matches world/block-name")
         (= (world/block-name id) (m/id->name id)))
  (check (string "id " id " :solid matches block-solid?")
         (= (get (m/by-id id) :solid) (world/block-solid? id)))
  (check (string "id " id " :opaque inverts block-transparent?")
         (= (get (m/by-id id) :opaque) (not (world/block-transparent? id)))))
(each id (range 0 9)
  (check (string "id " id " round-trips" ) (= id (m/name->id (m/id->name id)))))
(check "id 9 is absent from both" (and (nil? (m/by-id 9)) (nil? (world/block-name 9))))

# Spawn ground is the natural floor rule, NOT solidity: a canopy is standable
# but must never be a spawn surface.
(print "spawn ground:")
(check "spawn-ground is exactly stone dirt grass sand snow"
       (= (tuple ;(map |(get $ :name)
                       (filter |(m/spawn-ground? (get $ :name)) m/descriptors)))
          [:stone :dirt :grass :sand :snow]))
(check "wood is solid but not spawn ground"
       (and (true? (get (m/by-name :wood) :solid)) (false? (m/spawn-ground? :wood))))
(check "leaves are solid but not spawn ground"
       (and (true? (get (m/by-name :leaves) :solid)) (false? (m/spawn-ground? :leaves))))
(check "water and air are neither"
       (and (false? (m/spawn-ground? :water)) (false? (m/spawn-ground? :air))))
(check "spawn ground implies solid"
       (every? (map |(or (not (m/spawn-ground? (get $ :name)))
                         (get $ :solid))
                    m/descriptors)))

(print "planned:")
(check "planned names exist" (pos? (length m/planned)))
(check "titanium is planned and unavailable"
       (and (m/planned-name? :titanium)
            (false? (get (find |(= :titanium (get $ :name)) m/planned) :available))))
(check "no planned entry owns an id"
       (every? (map |(not (has-key? $ :id)) m/planned)))
(check "no planned entry carries physics"
       (every? (map |(not (or (has-key? $ :solid) (has-key? $ :opaque)
                              (has-key? $ :spawn-ground?)))
                    m/planned)))
(check "planned names resolve to no live id"
       (every? (map |(nil? (m/name->id (get $ :name))) m/planned)))
(check "no live name is planned"
       (every? (map |(not (m/planned-name? (get $ :name))) m/descriptors)))

# Unknown and nil must return nil, never alias a real entry or throw.
(print "unknown input:")
(check "by-id rejects unknown and non-integers"
       (and (nil? (m/by-id -1)) (nil? (m/by-id 9)) (nil? (m/by-id 1.5))
            (nil? (m/by-id "stone")) (nil? (m/by-id nil))))
(check "by-name rejects unknown and non-keywords"
       (and (nil? (m/by-name :nope)) (nil? (m/by-name nil)) (nil? (m/by-name "stone"))))
(check "name->id and id->name reject unknown"
       (and (nil? (m/name->id :nope)) (nil? (m/id->name 99)) (nil? (m/id->name nil))))
(check "spawn-ground? is false for unknown and nil"
       (and (false? (m/spawn-ground? :nope)) (false? (m/spawn-ground? nil))))
(check "planned-name? is false for unknown and live names"
       (and (false? (m/planned-name? :nope)) (false? (m/planned-name? :stone))))

(check "world constants were not modified" (= 9 (length (range 0 9))))
(if (zero? failures)
  (print "materials: pass")
  (do (printf "%d failed" failures) (error "materials tests failed")))
