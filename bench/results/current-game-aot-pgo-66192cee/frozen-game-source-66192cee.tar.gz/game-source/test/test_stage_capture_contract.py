"""Producer -> validator contract test, standard library only.

This exercises the REAL pipeline: tensors are packed and written by the
production helpers in ``tools/terrain_stage_capture.py``, the metadata is
assembled exactly as a capture assembles it, and the result is judged by the real
``tools/validate_stage_capture.py``. Nothing here reimplements the writer, and
nothing imports numpy, torch, or a model.

Two cases, both required:
  1. a valid artifact round-trips to ``ok``
  2. the same-size corruption of a single tensor is REJECTED

No model, GPU, forward pass, capture run or subprocess is involved.
"""

import json
import os
import pathlib
import shutil
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for _path in (os.path.join(_REPO, "tools"),):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import terrain_stage_capture as producer      # noqa: E402
import validate_stage_capture as validator    # noqa: E402


def _publish_tensor(directory, name, suffix, values):
    """Write one tensor through the production helper; return its metadata.

    This mirrors what `main()` does for x/out/cond/noise: pack, write, record the
    digest and the shape from the same values.
    """
    payload = producer.tensor_payload(values)
    digest = producer.write_payload(
        os.path.join(directory, "%s_%s.f32" % (name, suffix)), payload)
    return {"shape": [len(values)], "sha256": digest}


def build_capture(directory):
    """Assemble a complete stage-meta.json using the production helpers."""
    directory = producer.prepare_output_dir(directory)

    # Shapes are deliberately unlike each other (and unlike 81920) so a mixed-up
    # artifact is caught by size alone, matching the parent's failing case.
    stages = {}

    x = _publish_tensor(directory, "coarse", "x", [0.5] * 12)
    out = _publish_tensor(directory, "coarse", "out", [1.5] * 12)
    noise = _publish_tensor(directory, "coarse", "noise", [0.25, -0.75])
    stages["coarse"] = {
        "stage": "coarse", "call_index": 0,
        "x_shape": x["shape"], "x_sha256": x["sha256"],
        "out_shape": out["shape"], "out_sha256": out["sha256"],
        "noise_shape": noise["shape"], "noise_sha256": noise["sha256"],
        "noise_labels": [0.25, -0.75],
        # The real conditioning is 5 scalar channels, so exercise all five rather
        # than one: a mismatch in indexing or ordering only shows at i > 0.
        "conds": [
            _publish_tensor(directory, "coarse", "cond%d" % i, [float(i) + 0.25] * 6)
            for i in range(5)
        ],
    }

    # NB: the validator builds "<key>_x.f32" from the STAGE KEY, so the tensors
    # must be written under that key, not under the bare stage name.
    key = "base-step-0001"
    bx = _publish_tensor(directory, key, "x", [0.125] * 8)
    bout = _publish_tensor(directory, key, "out", [0.375] * 8)
    stages[key] = {
        "stage": "base", "call_index": 21,
        "x_shape": bx["shape"], "x_sha256": bx["sha256"],
        "out_shape": bout["shape"], "out_sha256": bout["sha256"],
        "conds": [],
    }

    meta = {
        "origin": 100000, "seed": 12345, "size": 64, "device": "cpu",
        "stage_order": list(producer.STAGE_ORDER),
        "stage_counts": {"coarse": 20, "base": 2, "decoder": 1},
        "calls": [
            {"label": "coarse", "stage": "coarse",
             "stage_index": 0, "global_index": 0},
            {"label": "base-step-0001", "stage": "base",
             "stage_index": 1, "global_index": 21},
        ],
        "stages": stages,
    }
    producer.write_meta_atomic(
        os.path.join(directory, "stage-meta.json"), meta)
    return directory, meta


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="contract-")
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def test_valid_artifact_round_trips(self):
        """The files the production writer emits must satisfy the validator."""
        directory, _meta = build_capture(os.path.join(self.tmp, "valid"))
        report = validator.validate(pathlib.Path(directory))
        self.assertTrue(report["ok"], report["errors"])
        self.assertEqual(report["error_count"], 0)
        # 2 stages x2 (x/out) + 5 conds + 1 noise = 10 tensors.
        self.assertEqual(report["checked"], 10)

    def test_same_size_corruption_is_rejected(self):
        """Flipping one byte in place must be caught by the recorded digest."""
        directory, _meta = build_capture(os.path.join(self.tmp, "corrupt"))
        target = os.path.join(directory, "coarse_x.f32")
        with open(target, "rb") as handle:
            original = handle.read()
        tampered = bytearray(original)
        tampered[0] ^= 0xFF                      # same length, different content
        with open(target, "wb") as handle:
            handle.write(bytes(tampered))
        self.assertEqual(os.path.getsize(target), len(original))

        report = validator.validate(pathlib.Path(directory))
        self.assertFalse(report["ok"])
        self.assertTrue(any("sha256 mismatch" in e for e in report["errors"]),
                        report["errors"])

    def test_wrong_shape_reported_as_size_mismatch(self):
        """A tensor whose size disagrees with its metadata is refused."""
        directory, meta = build_capture(os.path.join(self.tmp, "shape"))
        meta["stages"]["coarse"]["x_shape"] = [81920]
        producer.write_meta_atomic(
            os.path.join(directory, "stage-meta.json"), meta)
        report = validator.validate(pathlib.Path(directory))
        self.assertFalse(report["ok"])
        self.assertTrue(any("bytes" in e for e in report["errors"]),
                        report["errors"])

    def test_missing_tensor_file_is_rejected(self):
        directory, _meta = build_capture(os.path.join(self.tmp, "missing"))
        os.unlink(os.path.join(directory, "base-step-0001_out.f32"))
        report = validator.validate(pathlib.Path(directory))
        self.assertFalse(report["ok"])

    def test_noise_digest_binds_the_file(self):
        """The noise tensor is verified by digest, not by its label list."""
        directory, meta = build_capture(os.path.join(self.tmp, "noise"))
        self.assertIn("noise_sha256", meta["stages"]["coarse"])
        target = os.path.join(directory, "coarse_noise.f32")
        with open(target, "wb") as handle:
            # Same length (2 floats = 8 bytes) but values now 0.5, 0.5.
            handle.write(producer.tensor_payload([0.5, 0.5]))
        report = validator.validate(pathlib.Path(directory))
        self.assertFalse(report["ok"])
        self.assertTrue(any("noise" in e for e in report["errors"]),
                        report["errors"])

    def test_metadata_is_the_only_thing_that_binds_tensors(self):
        """Deleting the meta file makes the artifact unverifiable, not 'empty'."""
        directory, _meta = build_capture(os.path.join(self.tmp, "nometa"))
        os.unlink(os.path.join(directory, "stage-meta.json"))
        report = validator.validate(pathlib.Path(directory))
        self.assertFalse(report["ok"])
        self.assertTrue(any("stage-meta.json" in e for e in report["errors"]))


class StdlibOnlyTests(unittest.TestCase):
    def test_producer_helpers_need_no_numpy_or_torch(self):
        self.assertNotIn("numpy", sys.modules)
        self.assertNotIn("torch", sys.modules)

    def test_payload_is_little_endian_float32(self):
        # 1.0f LE is 00 00 80 3f; -2.5f LE is 00 00 20 c0.
        self.assertEqual(producer.tensor_payload([1.0, -2.5]).hex(),
                         "0000803f000020c0")

    def test_digest_matches_written_bytes(self):
        import hashlib

        payload = producer.tensor_payload([0.5, 1.5, 2.5])
        tmp = tempfile.mkdtemp(prefix="contract-digest-")
        self.addCleanup(shutil.rmtree, tmp, True)
        path = os.path.join(tmp, "t.f32")
        digest = producer.write_payload(path, payload)
        with open(path, "rb") as handle:
            ondisk = handle.read()
        self.assertEqual(ondisk, payload)
        self.assertEqual(digest, hashlib.sha256(ondisk).hexdigest())

    def test_shape_bytes_agrees_with_payload_length(self):
        for count in (1, 2, 6, 12, 256):
            payload = producer.tensor_payload([0.0] * count)
            self.assertEqual(len(payload), validator.shape_bytes([count]))


if __name__ == "__main__":
    unittest.main()
