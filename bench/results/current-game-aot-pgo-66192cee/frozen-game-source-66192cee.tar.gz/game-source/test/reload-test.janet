# Tests for live module reload.
#
# The property that matters most: a failed reload must leave the running game
# untouched. A reload that half-applied would corrupt a live session, which is
# far worse than refusing to reload.
#
# These use a temporary module on disk rather than the real source tree, so the
# tests never depend on -- or disturb -- a file someone is editing.

(import ../src/console :as console)
(import ../src/reload :as reload)

(var failures 0)
(defn check [name ok?]
  (if ok?
    (print "  ok   " name)
    (do (++ failures) (print "  FAIL " name))))

(def tmpdir (string "tmp/reload-test-" (os/getpid)))
(os/mkdir tmpdir)
(defn write-mod [name text]
  (def f (file/open (string tmpdir "/" name) :wbn))
  (file/write f text)
  (file/close f))

#
# --- Merge semantics ----------------------------------------------------
#

(print "=== merge semantics ===")

# A live environment holding one binding with a shared reference, which is how
# real call sites see a module's function.
(def live-binding @{:value (fn [] "old")})
(def live {'greet live-binding})

# dofile of the same module after an edit.
(write-mod "greet.janet" "(defn greet [] \"new\")\n")
(def fresh (dofile (string tmpdir "/greet.janet")))

(def report (reload/merge-into live fresh))
(check "update counted" (= 1 (report :updated)))

# The critical assertion: the ORIGINAL binding table must have been updated in
# place. Janet has no identity predicate and compares tables by value, so
# identity is proven by mutation instead: writing through the ORIGINAL
# reference and reading it back through the table shows they are one object.
# If merge had rebound the slot, these two would have diverged.
(put live-binding :probe :written)
(check "bindings share one table (mutation visible both ways)"
       (= :written (get (get live 'greet) :probe)))
(check "new behaviour visible through the original reference"
       (= "new" ((live-binding :value))))

# A newly introduced definition is adopted wholesale.
(def live2 @{})
(def report2 (reload/merge-into live2 fresh))
(check "new binding added" (= 1 (report2 :added)))

#
# --- Failure leaves state untouched -------------------------------------
#

(print "=== failure containment ===")

(def console-for-reload (console/console-new))
(console/bind! console-for-reload
               {'mesher-version (fn [] "original")}
               (curenv))

# Point reload at a module path that contains a syntax error.
(write-mod "broken.janet" "(defn oops [] (this is not valid\n")
(os/mkdir (string tmpdir "/src"))

(defn copy-mod [from to]
  (def src (slurp (string tmpdir "/" from)))
  (write-mod to src))

# Reload with a deliberately broken file: the live env must be unchanged.
(def broke
  (try (do (dofile (string tmpdir "/broken.janet")) :parsed)
       ([err] :failed)))
(check "broken source fails to parse" (= :failed broke))

# And the console's real binding survived that attempt.
# The console env stores binding tables, not bare values, so the function is
# reached through :value -- the same shape merge-into operates on.
(check "live binding untouched after a failed parse"
       (= "original"
          ((get (get (console-for-reload :env) 'mesher-version) :value))))

#
# --- Module registry ----------------------------------------------------
#

(print "=== module registry ===")
(check "known core module resolves" (reload/known? :mesher))
(check "unknown module is refused" (not (reload/known? :not-a-module)))
(check "unknown module path is nil" (nil? (reload/module-path :not-a-module)))
(check "real module path exists in project"
       (and (reload/known? :world)
            (string/has-prefix? "src/" (reload/module-path :world))))

#
# --- Real module round trip ---------------------------------------------
#

(print "=== real module reload ===")
(def con (console/console-new))
(console/bind! con {'world nil} (curenv))
(def r (try (reload/reload con :world ".") ([err] nil)))
(check "real module reloads" (and r (number? (r :updated))))
(check "report names the module" (and r (= :world (r :module))))

#
# --- Report -------------------------------------------------------------
#

(os/rm (string tmpdir "/greet.janet"))
(os/rm (string tmpdir "/broken.janet"))
(os/rm (string tmpdir "/src"))
(os/rm tmpdir)

(if (zero? failures)
  (print "reload tests passed")
  (do
    (printf "reload tests FAILED (%d)" failures)
    (os/exit 1)))
