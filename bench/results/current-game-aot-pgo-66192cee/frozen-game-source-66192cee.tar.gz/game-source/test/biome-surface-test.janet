# Headless tests for the authored biome-to-surface policy.
#
# Pure: no GL, no window, no model, no inference, no subprocess, no filesystem.
# The module holds no state and reads nothing, so this suite cannot change a
# saved world and cannot be reached by one either.
#
# THE VOCABULARY ISN'T INVENTED HERE. Every check below derives the biome set from
# what `climate-biome/classify` actually RETURNS and the block ids from
# `materials`, so a change in either authority fails here rather than silently
# drifting.
#
# THE CONTRACT IS COVERAGE, NOT AGREEMENT WITH THE PUBLISHED LIST. A classifier
# result with no policy is this module's bug; a policy key the classifier cannot
# produce is also this module's bug. Whether `biomes` happens to list every one of
# those keywords is a `climate-biome` question, so a gap is reported as a NOTE and
# never asserted -- this suite must stay green when the classifier is fixed.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/biome-surface-test.janet

(import ../src/biome-surface :as surf)
(import ../src/climate-biome :as bio)
(import ../src/climate-tile :as tile)
(import ../src/materials :as mat)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

#
# --- Fixtures -----------------------------------------------------------
#

(defn climate [&opt opts]
  (def o (or opts {}))
  @{:temperature (get o :temperature 12.0)
    :temperature-seasonality (get o :temperature-seasonality 200.0)
    :precipitation (get o :precipitation 900.0)
    :precipitation-variability (get o :precipitation-variability 30.0)
    :lapse-rate (get o :lapse-rate -0.006)})

(def sea 28)

# Every biome the CLASSIFIER can return, produced by classifying a fixture rather
# than read from a list -- so this set stays honest if a rule changes.
(defn reachable-biomes []
  (def fixtures
    @[@[{} 60]                                        # temperate wet -> forest
      @[{:precipitation 400.0} 60]                    # temperate dry -> grassland
      @[{:temperature 2.0 :precipitation 800.0} 60]   # taiga
      @[{:temperature 2.0 :precipitation 300.0} 60]   # tundra
      @[{:temperature -5.0 :precipitation 900.0} 60]  # ice
      @[{:temperature 25.0 :precipitation 100.0} 60]  # desert
      @[{:temperature 25.0 :precipitation 900.0} 60]  # savanna
      @[{} 28]                                        # ocean (at sea level)
      @[{} 31]])                                      # shore (sea + 3)
  (def found @{})
  (each [opts elev] fixtures
    (def r (bio/classify (climate opts) elev sea))
    (when (bio/classified? r) (put found (bio/biome-of r) true)))
  (tuple ;(sort (keys found))))

(defn policy-biomes [] (tuple ;(sort (keys surf/policy))))

# `=` is identity on arrays, so sets are compared as sorted tuples --
# structural, order-independent, and not fooled by fresh allocations.
(defn in? [xs x] (truthy? (find (fn [v] (= x v)) xs)))

#
# --- Vocabulary ---------------------------------------------------------
#

(print "\nvocabulary:")

(check "the policy is valid by its own self-check" (surf/valid?))

# THE POLICY'S OBLIGATION, STATED TWICE AND BOTH WAYS: it covers every biome
# `classify` can RETURN, and it covers every member of the published vocabulary.
(check "every biome the classifier RETURNS is covered by the policy"
       (every? (map |(truthy? (surf/descriptor-of $)) (reachable-biomes)))
       (string "reachable=" (reachable-biomes)))

(check "no policy entry is UNREACHABLE -- the table maps nothing the classifier cannot produce"
       (let [reachable (reachable-biomes)]
         (every? (map (fn [b] (truthy? (find (fn [r] (= b r)) reachable)))
                      (policy-biomes)))))

# The two sets must now AGREE, with no exclusion and no exception list. `:savanna`
# was the one gap; `climate-biome` owns it and it is fixed there, so this asserts
# equality rather than reporting a discrepancy.
(defn published-biomes []
  (tuple ;(sort (filter (fn [b] (not= :unknown b)) bio/biomes))))

(check "the reachable set of classifier answers equals the published vocabulary minus :unknown"
       (= (published-biomes) (reachable-biomes))
       (string "reachable=" (reachable-biomes)
               " published=" (published-biomes)))

# No `or :savanna` bypass, no special-cased keyword: the public vocabulary itself
# must admit every answer the classifier gives.
(check "every published biome except :unknown has a policy"
       (every? (map (fn [b] (or (= :unknown b) (truthy? (surf/descriptor-of b))))
                    bio/biomes)))
(check "bio/biome? admits an actual classified :savanna"
       (let [r (bio/classify (climate {:temperature 25.0 :precipitation 900.0})
                             60 sea)]
         (and (bio/classified? r)
              (= :savanna (bio/biome-of r))
              (bio/biome? (bio/biome-of r)))))
(check "the reachable set is non-empty and has no :unknown"
       (and (pos? (length (reachable-biomes)))
            (nil? (some |(= :unknown $) (reachable-biomes)))))

# "Invented" means: a policy key the classifier can never produce. Derived from
# the classifier, NOT from a hand-kept allowlist -- so `:savanna` is legitimate
# here precisely because `classify` returns it, and would stop being legitimate
# the moment it did not.
(check "there is no INVENTED biome in the policy"
       (let [reachable (reachable-biomes)]
         (every? (map (fn [b] (in? reachable b)) (policy-biomes)))))

(check "no policy key is duplicated"
       (= (length surf/policy) (length (distinct (policy-biomes)))))

(check "the policy has no :unknown entry" (nil? (surf/descriptor-of :unknown)))

# Names that a plausible-looking biome list might carry but that THIS classifier
# never returns. Adding a policy for them would be a guess, so there is none.
(each invented [:beach :alpine :snowy-taiga :mushroom :jungle]
  (check (string "the policy invents nothing for " invented)
         (nil? (surf/descriptor-of invented))))

#
# --- Block ids are REAL and never air or water --------------------------
#

(print "\nblock ids:")

(each b (policy-biomes)
  (let [d (surf/descriptor-of b)]
    (check (string "policy " b " top is a live id")
           (not (nil? (mat/by-id (d :top)))))
    (check (string "policy " b " subsoil is a live id")
           (not (nil? (mat/by-id (d :subsoil)))))
    (check (string "policy " b " top is never air (0)") (not= 0 (d :top)))
    (check (string "policy " b " subsoil is never air (0)") (not= 0 (d :subsoil)))
    (check (string "policy " b " top is never water (5)") (not= 5 (d :top)))
    (check (string "policy " b " subsoil is never water (5)") (not= 5 (d :subsoil)))
    (check (string "policy " b " top name agrees with its id")
           (= (mat/id->name (d :top)) (d :top-name)))
    (check (string "policy " b " subsoil name agrees with its id")
           (= (mat/id->name (d :subsoil)) (d :subsoil-name)))
    (check (string "policy " b " carries no new/planned material")
           (and (not (mat/planned-name? (d :top-name)))
                (not (mat/planned-name? (d :subsoil-name)))))))

(check "no planned roadmap name reaches the policy"
       (not (some |(mat/planned-name? (get $ :top-name))
                  (values surf/policy))))

#
# --- Determinism and immutability ---------------------------------------
#

(print "\ndeterminism:")

(each b (policy-biomes)
  (check (string "descriptor " b " is a frozen struct")
         (struct? (surf/descriptor-of b))))

(check "descriptor-of is stable across calls"
       (= (surf/descriptor-of :ocean) (surf/descriptor-of :ocean)))
(check "surface is stable across calls"
       (= (surf/surface :desert 60 sea) (surf/surface :desert 60 sea)))
(check "the policy is unchanged after being read"
       (let [before (length (keys surf/policy))]
         (surf/surface :ocean 10 sea)
         (surf/descriptor-of :ice)
         (= before (length (keys surf/policy)))))
(check "an unknown query does not add a policy entry"
       (let [before (length (keys surf/policy))]
         (surf/surface :plains 60 sea)
         (= before (length (keys surf/policy)))))
(check "the descriptor table is still valid after use" (surf/valid?))

#
# --- Ocean vs shore: water is a flag, not a block -----------------------
#

(print "\nocean and shore:")

(def ocean (surf/surface :ocean 10 sea))
(def shore (surf/surface :shore 31 sea))

(check "ocean classifies at a below-sea elevation" (surf/classified? ocean))
(check "ocean's top is a SEABED, not water" (= (mat/name->id :sand) (ocean :top)))
(check "ocean's subsoil is solid" (= (mat/name->id :sand) (ocean :subsoil)))
(check "ocean asks for water via a flag" (true? (ocean :water?)))
(check "the water flag is NOT a block id in the terrain pair"
       (and (not= (mat/name->id :water) (ocean :top))
            (not= (mat/name->id :water) (ocean :subsoil))))
(check "ocean at exactly sea level classifies" (surf/classified? (surf/surface :ocean sea sea)))
# The module does not adjudicate the waterline: elevation and sea are the
# caller's, and the policy answer is a function of the biome alone.
(check "ocean resolves the same at any elevation -- no waterline is adjudicated"
       (and (= ocean (surf/surface :ocean (+ sea 40) sea))
            (= ocean (surf/surface :ocean -500 sea))))
(check "the ocean answer promises no water block, only the flag"
       (and (= (mat/name->id :sand) (ocean :top))
            (not (has-key? ocean :water-id))))

(check "shore classifies" (surf/classified? shore))
(check "shore is sand on sand" (and (= (mat/name->id :sand) (shore :top))
                                    (= (mat/name->id :sand) (shore :subsoil))))
(check "shore carries NO water flag" (false? (shore :water?)))
(def water-biomes
  (tuple ;(sort (filter |(true? ((surf/descriptor-of $) :water?))
                        (policy-biomes)))))
(check "only :ocean carries the water flag" (= (tuple :ocean) water-biomes)
       (string "water=" water-biomes))

#
# --- Unknown input never invents material -------------------------------
#

(print "\nunknown:")

(def plains (surf/surface :plains 60 sea))
(def typo (surf/surface :temperate-forrest 60 sea))

(check "an invented biome is :unavailable" (= :unavailable (plains :status)))
(check "an invented biome reports :missing-climate"
       (= :missing-climate (plains :reason)))
(check "an invented biome says preserve the legacy column"
       (true? (plains :preserve-legacy)))
(check "an invented biome carries NO :top" (nil? (get plains :top)))
(check "an invented biome carries NO :subsoil" (nil? (get plains :subsoil)))
(check "a misspelling is refused too" (= :missing-climate (typo :reason)))
(check ":unknown is refused, having no policy of its own"
       (= :missing-climate ((surf/surface :unknown 60 sea) :reason)))

# The strong form: there is ONE no-answer value, returned by identity-equality
# from every refusing path. A caller may compare against it directly, and no
# fresh table is allocated per call that could drift or be mutated.
(check "every refusing path returns THE shared unavailable struct"
       (and (= surf/unavailable plains)
            (= surf/unavailable typo)
            (= surf/unavailable (surf/surface :unknown 60 sea))
            (= surf/unavailable (surf/surface nil 60 sea))
            (= surf/unavailable (surf/surface :plains (/ 0 0) (/ 1 0)))))
(check "the shared unavailable struct is a read-only struct, not a table"
       (struct? surf/unavailable))

# Immutability is structural, not by convention: a struct literal in Janet is a
# read-only table, so `put` REFUSES. This is why no `freeze` call is needed -- and
# why freezing would be wrong, since freeze on a struct is a runtime error.
(defn mutation-refused? [v k x]
  (try (do (put v k x) false) ([_err] true)))

(check "a classified result refuses mutation"
       (mutation-refused? (surf/surface :desert 60 sea) :top 5))
(check "the shared unavailable struct refuses mutation"
       (mutation-refused? surf/unavailable :status :classified))
(check "a descriptor refuses mutation"
       (mutation-refused? (surf/descriptor-of :ocean) :top 5))
(check "the policy table itself refuses new keys"
       (mutation-refused? surf/policy :plains (surf/descriptor-of :ocean)))
(check "a refused mutation leaves the shared value intact"
       (and (= surf/unavailable (surf/surface :plains 60 sea))
            (= :missing-climate (surf/unavailable :reason))))

# The classify-result input path: an :unknown result carries no climate, so the
# policy must refuse rather than treat :unknown as a biome.
(def no-climate (bio/classify nil 60 sea))
(check "a classify :unknown result is unavailable, not materialised"
       (= :unavailable ((surf/surface no-climate 60 sea) :status)))
(check "a classify :unknown result preserves the legacy column"
       (true? ((surf/surface no-climate 60 sea) :preserve-legacy)))
(check "a classify :unknown result has no :top key"
       (nil? (get (surf/surface no-climate 60 sea) :top)))

# And the classified path through a real classifier result agrees with the
# keyword path, so the two inputs cannot diverge.
(check "a classified result resolves to the same surface as its keyword"
       (let [r (bio/classify (climate {:temperature 25.0 :precipitation 100.0}) 60 sea)]
         (= (surf/surface :desert 60 sea) (surf/surface r 60 sea))))

#
# --- The module owns no waterline and no validation of its own ----------
#
# A policy lookup is a function of the biome. `elevation` and `sea` are accepted
# for call-site symmetry with the classifier and are carried through unused, so
# this layer cannot reject a column, invent a waterline, or quietly disagree with
# the future generator about where the water is.
#

(print "\nno adjudication:")

(check "a classified biome answers identically for any elevation and sea"
       (let [a (surf/surface :desert 60 sea)
             b (surf/surface :desert -1e9 -1e9)
             c (surf/surface :desert (/ 0 0) (/ 1 0))]
         (and (= a b) (= a c))))
(check "the module exposes no elevation or sea validation arm"
       (and (nil? (get surf/unavailable :reason-bad-elevation))
            (not (truthy? (some |(= :bad-elevation $)
                                (values surf/unavailable))))))
(check "an unknown biome is still unavailable even given a fine elevation"
       (= surf/unavailable (surf/surface :plains 60 sea)))

#
# --- Revision and provenance --------------------------------------------
#

(print "\nrevision:")

(check "surface-revision is a positive number"
       (and (number? surf/surface-revision) (pos? surf/surface-revision)))
(check "the module declares a version" (and (number? surf/version) (pos? surf/version)))
(check "the basis names the same surface revision"
       (= surf/surface-revision (surf/basis :surface-revision)))
(check "the basis names the classifier's biome revision"
       (= bio/biome-revision (surf/basis :biome-revision)))
(check "the basis names climate-biome as the authority"
       (= :climate-biome (surf/basis :authority)))
(check "the basis declares authored provenance"
       (= :authored (surf/basis :provenance)))
(check "the basis says the thresholds are authored and unmeasured"
       (= :authored-unmeasured (surf/basis :thresholds-source)))
(check "the basis republishes the classifier's thresholds unchanged"
       (= bio/thresholds (surf/basis :thresholds)))
(check "a classified result carries its revision"
       (= surf/surface-revision ((surf/surface :ice 60 sea) :surface-revision)))
(check "a classified result carries its provenance"
       (= :authored ((surf/surface :ice 60 sea) :provenance)))

#
# --- The module is not wired into a generator ---------------------------
#

(print "\nisolation:")

(check "the module reads no world state: surface needs only its three arguments"
       (surf/classified? (surf/surface :grassland 60 sea)))
(check "the classifier's unit basis is untouched by this module"
       (and (= :source-derived tile/unit-basis) (tile/units-verified?)))

#
# --- Summary ------------------------------------------------------------
#

(if (zero? failures)
  (print "\nbiome surface tests: pass")
  (do (printf "\n%d check(s) failed" failures)
      (error "biome surface tests failed")))
