# Deterministic parity probe for src/world-seed.janet.
#
# Prints one tab-separated line per vector and nothing else, so the output of
# the interpreter and of a compiled binary can be compared byte for byte. Used
# by tools/verify-world-seed-parity.sh; not a test suite (it asserts nothing,
# the comparison is the assertion).
#
# Entropy is ALWAYS injected here and never drawn from the OS: a live
# os/cryptorand would differ between the two runs and make the probe useless.
#
# What this does and does not prove: bender's --aot embeds a Janet VM image and
# compiles only eligible unboxed kernels. For this module it reports
# "native-lib 0 kernels", so the compiled run executes the same bytecode as the
# interpreter. The probe therefore proves that compiling and embedding the
# module does not change any resolved seed -- parity, not native arithmetic.
(import ../src/world-seed :as ws)

(def vectors
  ["0" "42" "00042" "+42" "-0" "-1" "-2" "-2147483648" "2147483647"
   "2147483648" "4294967295" "999999999999999999999999"
   "1000000000000000000000000000000" "-999999999999999999999999"
   "007" "  42  " " hello " "hello" "hello, world!" "TrineXraft"
   "!@#$%^&*()" "éèê" "Ω" "🌍" "a🌍b" "😀😀😀" "42a" "1e5" "0x10" "12.0"
   "+" "-" "1-2" "--1"])

(each text vectors
  (def p (ws/parse-seed-input text))
  (printf "%q\t%d\t%d\t%q\t%s"
          (p :input) (p :version) (p :value) (p :kind) (p :canonical)))

(def blanks ["" " " "\t" "\r" "\n" "   " "\t\n "])
(each text blanks
  (printf "blank\t%q\t%s" text
          (try (do (ws/parse-seed-input text) "NO-RAISE")
               ([e] "raise"))))

(each bytes [@"\x00\x00\x00\x00" @"\x00\x00\x00\x01" @"\x7f\xff\xff\xff"
             @"\x80\x00\x00\x01" @"\xff\xff\xff\xff" @"\x12\x34\x56\x78"]
  (def r (ws/random-identity bytes))
  (printf "random\t%q\t%d\t%s\t%s"
          (r :entropy) (r :value) (r :kind) (r :canonical)))

(printf "constants\t%d\t%d\t%s" ws/modulus ws/max-seed (string ws/text-tag))
