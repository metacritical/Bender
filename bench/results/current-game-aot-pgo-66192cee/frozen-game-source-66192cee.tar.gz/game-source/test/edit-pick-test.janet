(import ../src/edit-pick)
(import ../src/player)
(import ../src/world)

(defn close [actual expected]
  (assert (< (math/abs (- actual expected)) 0.000001)))

(defn check-ray [ray expected]
  (each i (range 0 3) (close (get ray i) (get expected i))))

(defn rays []
  (let [eye [2 10 3] w 1000 h 600 fov 90]
    (each [yaw pitch] [[0 0] [(/ math/pi 2) 0] [0 0.4] [0 -0.5]
                       [1.3 0.9]]
      (check-ray (edit-pick/screen-ray eye yaw pitch fov (/ w h) w h
                                       [(/ w 2) (/ h 2)])
                 (player/look-direction {:yaw yaw :pitch pitch})))
    (let [s (math/sqrt 2)
          edge-length (math/sqrt (+ 1 (* (/ w h) (/ w h))))]
      (check-ray (edit-pick/screen-ray eye 0 0 fov (/ w h) w h [1000 300])
                 [(/ 1 edge-length) 0 (/ (/ w h) edge-length)])
      (check-ray (edit-pick/screen-ray eye 0 0 fov (/ w h) w h [500 0])
                 [(/ 1 s) (/ 1 s) 0])
      (check-ray (edit-pick/screen-ray eye 0 0 fov (/ w h) w h [500 600])
                 [(/ 1 s) (- (/ 1 s)) 0])))
  (print "center, yaw/pitch, and screen offsets: passed"))

(defn picking []
  (let [w (world/world-new)
        chunk (world/chunk-new 0 0)
        eye [1.5 10.5 1.5]]
    (world/world-put-chunk w chunk)
    (assert (world/world-set-block w 4 10 1 world/block-stone))
    (assert (world/world-set-block w 5 10 1 world/block-dirt))
    (let [hit (edit-pick/pick-first-solid w eye 0 0 70 (/ 1000 600)
                                          1000 600 [500 300] 8)]
      (assert hit)
      (assert (= [4 10 1 world/block-stone 3]
                 [(get hit :x) (get hit :y) (get hit :z)
                  (get hit :block) (get hit :face)])))
    (assert (nil? (edit-pick/pick-first-solid w eye 0 0 70 (/ 1000 600)
                                               1000 600 [500 300] 2.49)))
    # Inspector begins at x=660. Neither its edge nor any position beyond it
    # may trigger a world pick, even if the ray would hit a solid block.
    (each mouse [[660 300] [999 300] [1000 300] [-1 300]
                 [500 -1] [500 600]]
      (assert (nil? (edit-pick/pick-first-solid w eye 0 0 70 (/ 1000 600)
                                                 1000 600 mouse 8))))
    (assert (nil? (edit-pick/pick-first-solid w eye 0 0 70 1
                                               340 600 [0 300] 8)))
    (print "first solid, reach and inspector guard: passed")))

(rays)
(picking)
