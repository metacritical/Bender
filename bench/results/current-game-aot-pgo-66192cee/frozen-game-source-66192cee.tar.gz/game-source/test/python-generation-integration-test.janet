# Python provider integration: a real child process must produce a real artifact.
#
# This exercises the whole non-GUI generation path with an actual OS process and
# an actual artifact on disk -- no mocks, no GPU, no model weights, no torch.
#
# The process it starts is `test/fixtures/terrain-provider-fake.py`, which parses
# the same argv the game sends and then calls the REAL `tools/terrain_new_game.py`
# `generate()`. So the validation, seed mapping, identity construction, TDS3
# export, `verify_artifact` re-read and READY publication are all the production
# code. Only the sampler is synthetic, supplied through the module's own
# documented `pipeline_factory` seam, and the artifact says so: the fixture writes
# FAKE_PROVENANCE and prints PROVENANCE_FAKE, so nothing here can be mistaken for
# real inference.
#
# What is asserted, and why each can regress independently:
#   * a valid artifact arrives through a real child process and the real job
#     lifecycle, with the stage sequence the loading screen will poll
#   * the artifact is genuinely readable by the JANET reader (the consumer that
#     actually ships), not merely by the Python that wrote it
#   * a nonzero exit is a failure, never a quiet success
#   * a zero exit whose artifact is absent or truncated is still a failure: the
#     validator, not the exit code, decides success
#   * cancellation reaps the child and reports cancelled, without orphaning it
#   * the artifact is refused when a tile is corrupted after publication
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/python-generation-integration-test.janet
# Skipped (with a clear message, not a silent pass) when python3 is unavailable.

(import ../src/generation-job :as job)
(import ../src/terrain-cache :as tcache)
(import ../src/world-catalog :as catalog)

(var failures 0)
(var skipped 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))
(defn skip [name why]
  (++ skipped)
  (printf "  SKIP %s -- %s" name why))

#
# --- Environment -------------------------------------------------------
#

(def here (os/cwd))
(def fixture (string here "/test/fixtures/terrain-provider-fake.py"))
(def python (or (os/getenv "PYTHON") "python3"))

(defn file-bytes [path]
  (def f (file/open path :rb))
  (if (nil? f) nil
      (let [b (file/read f :all)] (file/close f) b)))

(defn python-available? []
  (def p (os/spawn [python "-c" "import sys"] :p))
  (def ok (and p (= 0 (:wait p))))
  ok)

(var scratch-counter 0)
(defn fresh-root []
  (++ scratch-counter)
  (def base (or (os/getenv "TMPDIR") "/tmp"))
  (def path (string base "/trinecraft-pyint-" (os/getpid) "-" scratch-counter))
  (def st (os/lstat path))
  (when st
    (each name (os/dir path)
      (try (os/rm (string path "/" name)) ([e] nil)))
    (try (os/rm path) ([e] nil)))
  (os/mkdir path)
  path)

(defn drop-tree [path]
  (defn walk [dir]
    (def st (os/lstat dir))
    (cond
      (nil? st) nil
      (= :directory (get st :mode))
      (do (each name (os/dir dir) (walk (string dir "/" name)))
          (try (os/rm dir) ([e] nil)))
      true (try (os/rm dir) ([e] nil))))
  (walk path))

#
# --- The validator the game uses --------------------------------------
#
# Production validation is "open the cache the artifact will be served from".
# `tcache/cache-new` reads manifest.janet, refuses a malformed or missing one,
# and refuses a cache baked for a different seed -- which is exactly the
# guarantee the job needs before it may report success.
#

(defn digest-dirs [out-root]
  "Every 64-lowercase-hex directory under `out-root`, which is the artifact."
  (if (nil? (os/lstat out-root))
    @[]
    (filter (fn [name]
              (and (= 64 (length name))
                   (every? (map (fn [i]
                                  (def c (get name i))
                                  (or (and (<= 48 c) (<= c 57))
                                      (and (<= 97 c) (<= c 102))))
                                (range 64)))
                   (= :directory (os/lstat (string out-root "/" name) :mode))))
            (os/dir out-root))))

(defn artifact-seed-of [out-root]
  "The seed the artifact itself records, or nil when there is no single artifact."
  (def dirs (digest-dirs out-root))
  (when (= 1 (length dirs))
    (def manifest (try (tcache/load-manifest (string out-root "/" (first dirs)))
                       ([e] nil)))
    (when manifest (get manifest :seed))))

(defn validate-artifact [out-root &opt world-seed]
  ``The SHIPPING gate: the catalogue's own artifact inspection.

  Deliberately not the cache reader alone. The catalogue is what New Game
  actually calls, and it enforces a stricter contract than `cache-new`: exactly
  six names inside the identity directory, a READY marker with its literal
  flags, a bounded shape, and a model seed derived from the WORLD seed. A fake
  that only satisfied the reader would have shipped an artifact the game
  rejects -- which is exactly what happened before this fix.``
  # A failed or cancelled child may never have created the root at all.
  (when (nil? (os/lstat out-root))
    (break nil))
  # The real provider leaves raw_export.{json,npz} beside the identity
  # directory, so "exactly one entry" is the wrong test: find the single
  # directory and let the cache reader judge it.
  (def dirs (digest-dirs out-root))
  (if (not= 1 (length dirs))
    nil
    (do
      (def dir (string out-root "/" (first dirs)))
      (if (nil? (os/lstat (string dir "/READY")))
        nil
        (do
          # The catalogue takes the WORLD seed and derives the model seed itself,
          # which is the mapping under test. World seed 0 is the interesting case.
          (def opened (try [true (catalog/inspect-artifact dir world-seed)]
                           ([e] [false (string e)])))
          (if (opened 0) dir nil))))))

#
# --- Job driving -------------------------------------------------------
#

# Start a generation job and drive it to a terminal phase, or cancel it.
# Returns the final status plus the child pid, so the test can assert the process
# is really gone rather than merely assumed reaped.
(defn run-job
  [argv opts]
  (def options (or opts {}))
  (def slot @{:job nil})
  # Mode comes from the ENVIRONMENT, never from a test-only flag on the
  # production argparse surface the game speaks. bender's `os/spawn :env`
  # REPLACES the child environment rather than extending it, which would strip
  # PATH, so the variable is scoped to the child with env(1) instead: it applies
  # to this invocation only and never leaks into the test process.
  (def env (get options :env))
  (defn prefix-env [argv]
    (if (nil? env)
      argv
      (do
        (def out @["/usr/bin/env"])
        (eachp [k v] env (array/push out (string k "=" v)))
        (each a argv (array/push out a))
        out)))
  (def out-root (get options :out))
  (def j (job/start
           "integration"
           (prefix-env argv)
           {:slot slot
            :progress-path (get options :progress)
            # No seed argument: the validator reads the seed the artifact
            # records. A world seed of 0 maps to a different model seed, so
            # passing the world seed here would reject a correct artifact.
            :validate (fn [_job]
                        (if (validate-artifact out-root (get options :seed 12345))
                            true nil))}))
  (def started-pid (j :pid))
  (var status (job/poll j))
  (var turns 0)
  (def cancel-after (get options :cancel-after))
  # The phase may be :running or :cancelling; both need driving. A cancelled
  # child gets a five-second TERM grace window before KILL, so the loop must be
  # able to outlast that and must not exit while still :cancelling.
  (while (and (or (= :running (status :phase)) (= :cancelling (status :phase)))
              (< turns 3000))
    (when (and cancel-after (= turns cancel-after))
      (job/cancel j))
    (when (= :cancelling (status :phase))
      # Give the grace window a chance to elapse in this test's terms.
      nil)
    (set status (job/poll j))
    (++ turns)
    (os/sleep 0.02))
  (put status :pid started-pid)
  status)

# True when PID still names a running process. bender has no os/kill(pid, 0),
# so liveness is probed with the shell's own `kill -0`, which fails exactly when
# the pid is gone. Test-side only: the job lifecycle never signals a PID it does
# not own.
(defn alive?
  [pid]
  (if (nil? pid)
    false
    (do
      (def p (os/spawn ["/bin/sh" "-c" (string "kill -0 " pid " 2>/dev/null")] :p))
      (and p (= 0 (:wait p))))))

#
# --- Tests -------------------------------------------------------------
#

(if (not (python-available?))
  (skip "python provider integration" (string python " not runnable"))
  (do
    (check "the fake provider fixture exists" (not (nil? (os/lstat fixture))))

    #
    # 1. A valid artifact through a real process.
    #
    (def root (fresh-root))
    (def out (string root "/out"))
    # Progress lives INSIDE the output root, which is the contract the game
    # generates under: the provider tolerates its own sidecar there.
    (def progress (string out "/stage.janet"))
    # Seed 0 is the mapping case that matters: the backend rejects seed 0, so
    # the provider maps it and the artifact records BOTH the world seed and the
    # model seed. Testing only nonzero seeds would leave that untested.
    (def argv @[python fixture "--out" out "--seed" "0" "--size" "128"
                "--sea-level" "28" "--profile" "alpine"
                "--progress" progress])
    (def s1 (run-job argv {:out out :progress progress :seed 0}))
    (check "a real child process produced a valid artifact" (= :succeeded (s1 :phase))
           (string "phase=" (s1 :phase) " error=" (s1 :error) " exit=" (s1 :exit-code)))
    (check "the child exited zero" (= 0 (s1 :exit-code)))
    (check "the child had a real pid" (number? (s1 :pid)))
    (check "the child is reaped, not left running" (not (alive? (s1 :pid))))
    # The provider writes ONE inert Janet record, atomically replaced per stage
    # (the same convention `generation-job` reads), so the final record must be
    # the ready stage. Asserted from the file the real module actually wrote.
    (def progress-text (file-bytes progress))
    (check "the provider wrote a progress record" (not (nil? progress-text))
           (string "progress path " progress))
    (check "the final progress stage is ready"
           (and progress-text
                (not (nil? (string/find ":stage :ready" (string progress-text)))))
           (string "saw " (if progress-text (string progress-text) "<none>")))
    (check "the progress record names its schema version"
           (and progress-text (not (nil? (string/find ":version 1" (string progress-text))))))
    # And the job's own reader accepts it, which is the pairing that matters.
    (def probe-slot @{:job nil})
    (def probe-job (job/start "probe" @[python "-c" "import sys; sys.exit(0)"]
                              {:slot probe-slot :progress-path progress
                               :validate (fn [_] true)}))
    (var probe-status (job/poll probe-job))
    (var probe-turns 0)
    (while (and (= :running (probe-status :phase)) (< probe-turns 500))
      (set probe-status (job/poll probe-job))
      (++ probe-turns)
      (os/sleep 0.01))
    (check "the job reader parses the provider's progress record"
           (= :ready (get (probe-status :progress) :stage))
           (string "phase=" (probe-status :phase)
                   " progress=" (string (probe-status :progress))))

    # The artifact itself, read by the JANET reader that ships.
    # The artifact's own seed is the MODEL seed, which for world seed 0 is the
    # mapped value, not 0. That is why the reader is opened with it explicitly.
    (def artifact-seed (artifact-seed-of out))
    (check "seed 0 was mapped to a nonzero model seed"
           (and (number? artifact-seed) (= 2147483647 artifact-seed))
           (string "artifact seed " (string artifact-seed)))
    (def dir (validate-artifact out artifact-seed))
    (check "the Janet cache reader accepts the artifact" (not (nil? dir)))
    (when dir
      (def c (tcache/cache-new dir artifact-seed))
      (check "a generated tile is ready" (= :ready (tcache/request c 0 0)))
      (def raw (file-bytes (tcache/tile-path dir 0 0)))
      (check "the tile is a TDH2 record" (and raw (= 308 (length raw))))
      (def heights (tcache/decode-tile-for :scenic raw 0 0))
      (check "the tile decodes to 256 heights" (= 256 (length heights)))
      (check "every height is inside the manifest band"
             (every? (map |(and (>= $ 4) (<= $ 252)) heights)))
      (check "a coordinate outside the map is out-of-bounds"
             (= :out-of-bounds (tcache/request c 999 999)))
      # Provenance is marked, so the artifact cannot pass as real inference.
      # The parent's contract: exactly ONE 64-hex directory, with only dot
      # entries and the stage sidecar beside it inside the root.
      (check "the output root holds exactly one digest directory"
             (= 1 (length (digest-dirs out))))
      # The production exporter leaves raw_export.{json,npz} beside the
      # identity directory; they are its own intermediates, not foreign files.
      # The root legitimately holds five entries: the identity directory, the
      # stage sidecar the game itself asks for, the exporter's two raw_export
      # intermediates, and this fixture's TESTFAKE marker. Asserted by exact
      # set, so an unexpected extra file fails rather than being tolerated.
      (check "the output root holds exactly the expected sidecars"
             (let [names (sorted (os/dir out))
                   want (sorted @[(last (string/split "/" progress))
                                  "TESTFAKE_PROVENANCE"
                                  "raw_export.json"
                                  "raw_export.npz"
                                  (first (digest-dirs out))])]
               (= (string/join names ",") (string/join want ",")))
             (string "entries: " (string/join (os/dir out) ",")))
      # The marker lives in the OUTPUT ROOT, never inside the identity
      # directory: the catalogue accepts exactly six names in there and rejects
      # the artifact as "files incomplete or unexpected" otherwise.
      (check "the identity directory holds exactly the six contract files"
             (= 6 (length (os/dir dir)))
             (string "entries: " (string/join (os/dir dir) ",")))
      (check "the fake artifact is labelled TESTFAKE outside the identity dir"
             (not (nil? (os/lstat (string out "/TESTFAKE_PROVENANCE")))))
      (check "no TESTFAKE marker is inside the identity directory"
             (nil? (os/lstat (string dir "/TESTFAKE_PROVENANCE"))))
      (check "the marker says the weights were not sampled"
             (let [b (file-bytes (string out "/TESTFAKE_PROVENANCE"))]
               (and b (not (nil? (string/find "label=TESTFAKE" (string b)))))))
      # And the artifact is accepted by the SHIPPING gate, not merely the reader.
      (check "the catalogue accepts the artifact for world seed 0"
             (not (nil? (try (do (catalog/inspect-artifact dir 0) true)
                             ([e] false)))))
      # The catalogue and the cache reader must agree on the SAME artifact, or a
      # world would be inspected as one generation and served as another.
      (check "the catalogue and the cache agree on the model seed for world seed 0"
             (let [cat (try (catalog/inspect-artifact dir 0) ([e] nil))
                   seed ((tcache/load-manifest dir) :seed)]
               (and cat (= (get cat :model-seed) seed))))
      # A cache baked for a different seed must be refused.
      (check "the reader refuses a mismatched seed"
             (not (try (do (tcache/cache-new dir (dec artifact-seed)) true) ([e] false)))))

    (drop-tree root)

    #
    # 2. A nonzero exit is a failure, never a quiet success.
    #
    (def root2 (fresh-root))
    (def out2 (string root2 "/out"))
    (def s2 (run-job @[python fixture "--out" out2 "--seed" "0"]
                     {:out out2 :env {"TC_FAKE_PROVIDER_MODE" "fail"}}))
    (check "a failing child is reported failed" (= :failed (s2 :phase)))
    (check "a failing child keeps its nonzero exit code"
           (and (number? (s2 :exit-code)) (not= 0 (s2 :exit-code))))
    (check "a failing child leaves no valid artifact"
           (nil? (validate-artifact out2 12345)))
    (check "a failing child is reaped" (not (alive? (s2 :pid))))
    (drop-tree root2)

    #
    # 3. A ZERO exit with no artifact is still a failure.
    #    The validator, not the exit code, decides success.
    #
    (def root3 (fresh-root))
    (def out3 (string root3 "/out"))
    (os/mkdir out3)
    (def s3 (run-job @[python "-c" "import sys; sys.exit(0)"]
                     {:out out3}))
    (check "a zero-exit process with no artifact is failed" (= :failed (s3 :phase)))
    (check "the failure is attributed to validation, not the exit code"
           (not (nil? (string/find "validation" (or (s3 :error) ""))))
           (string "error=" (s3 :error)))
    (drop-tree root3)

    #
    # 4. A truncated artifact is refused even though the process succeeded.
    #
    (def root4 (fresh-root))
    (def out4 (string root4 "/out"))
    (def s4 (run-job @[python fixture "--out" out4 "--size" "128"]
                     {:out out4 :seed 12345}))
    (check "a complete run first succeeds" (= :succeeded (s4 :phase))
           (string "phase=" (s4 :phase) " err=" (s4 :error)))
    (def dir4 (validate-artifact out4 12345))
    (when dir4
      # Corrupt one tile after publication: the summary still claims success.
      (def tp (tcache/tile-path dir4 0 0))
      (def f (file/open tp :wbn))
      (file/write f "not a tile at all, just bytes")
      (file/close f)
      (check "a corrupted tile is rejected by the reader"
             (not (try (do (tcache/decode-tile-for :scenic (file-bytes tp) 0 0) true)
                       ([e] false))))
      # `cache-new` validates the manifest, not every tile, so opening still
      # succeeds -- the corruption is caught when the tile is actually decoded.
      # Assert exactly that, rather than a stronger claim the reader never made.
      (check "a corrupted tile is caught by the catalogue gate"
             (nil? (validate-artifact out4 12345)))
      (check "the corrupted coordinate decodes to an error, not heights"
             (not (try (do (tcache/decode-tile-for :scenic (file-bytes tp) 0 0) true)
                       ([e] false))))
      (check "a good coordinate still decodes in the same artifact"
             (let [other (tcache/tile-path dir4 1 0)]
               (= 256 (length (tcache/decode-tile-for :scenic (file-bytes other) 1 0))))))
    (drop-tree root4)

    #
    # 5. Cancellation reaps the child and never reports success.
    #
    (def root5 (fresh-root))
    (def out5 (string root5 "/out"))
    (def s5 (run-job @[python fixture "--out" out5 "--seed" "0"]
                     {:out out5 :cancel-after 3
                      :env {"TC_FAKE_PROVIDER_MODE" "sleep" "TC_FAKE_PROVIDER_SLEEP" "2"}}))
    (check "a cancelled run is not reported as succeeded"
           (not= :succeeded (s5 :phase)))
    (check "a cancelled run ends in a terminal phase"
           (or (= :cancelled (s5 :phase)) (= :failed (s5 :phase)))
           (string "phase=" (s5 :phase)))
    (check "a cancelled child is reaped, not orphaned" (not (alive? (s5 :pid))))
    (check "a cancelled run leaves no valid artifact"
           (nil? (validate-artifact out5 12345)))
    (drop-tree root5)

    #
    # 6. The CLI contract the QA commands depend on: --check without --out,
    #    and the fail/partial modes leaving no loadable artifact.
    #
    (def check-root (fresh-root))
    (def never (string check-root "/never-created"))
    (def chk (os/spawn [python fixture "--check" "--out" never] :p))
    (def chk-code (if chk (:wait chk) -1))
    (check "--check exits zero" (= 0 chk-code) (string "exit " chk-code))
    (check "--check writes no output directory" (nil? (os/lstat never)))
    # --check must also work with NO --out at all, which the real CLI refuses.
    (def chk2 (os/spawn [python fixture "--check"] :p))
    (check "--check works without --out" (= 0 (if chk2 (:wait chk2) -1)))
    (drop-tree check-root)

    (def root6 (fresh-root))
    (def out6 (string root6 "/out"))
    (def s6 (run-job @[python fixture "--out" out6 "--seed" "0" "--size" "128"]
                     {:out out6 :seed 0
                      :env {"TC_FAKE_PROVIDER_MODE" "partial"}}))
    (check "partial mode fails" (= :failed (s6 :phase)))
    (check "partial mode leaves tiles but no loadable artifact"
           (nil? (validate-artifact out6 0)))
    # Tiles really were written: the refusal is about READY, not about nothing.
    (def dirs6 (digest-dirs out6))
    (check "partial mode did write a tiles directory"
           (and (= 1 (length dirs6))
                (not (nil? (os/lstat (string (string out6 "/" (first dirs6))
                                             "/tiles"))))))
    (check "partial mode wrote no READY"
           (nil? (os/lstat (string (string out6 "/" (first dirs6)) "/READY"))))
    (drop-tree root6)))

#
# --- Result ------------------------------------------------------------
#

(cond
  (> failures 0)
  (do (printf "\npython generation integration: %d FAILED" failures) (os/exit 1))
  (> skipped 0)
  (printf "\npython generation integration: ALL CHECKS PASSED (%d skipped)" skipped)
  true
  (print "\npython generation integration: ALL CHECKS PASSED"))
