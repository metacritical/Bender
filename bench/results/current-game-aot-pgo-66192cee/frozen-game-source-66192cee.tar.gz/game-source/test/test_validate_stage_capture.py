"""Isolated fake-binary tests; never import torch or load a model."""
import hashlib
import json
from pathlib import Path
import sys
import struct
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from validate_stage_capture import validate


class StageCaptureValidationTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.data = bytes(range(16))
        self.entry = {"x_shape": [2, 2], "out_shape": [2, 2],
                      "x_sha256": hashlib.sha256(self.data).hexdigest(),
                      "out_sha256": hashlib.sha256(self.data).hexdigest(),
                      "conds": [{"shape": [2, 2],
                                 "sha256": hashlib.sha256(self.data).hexdigest()}]}
        self.document = {"stages": {"coarse": self.entry}}
        self.write_fixture()

    def write_fixture(self):
        (self.root / "stage-meta.json").write_text(json.dumps(self.document))
        for suffix in ("x", "out", "cond0"):
            (self.root / f"coarse_{suffix}.f32").write_bytes(self.data)

    def assert_rejected(self, text):
        result = validate(self.root)
        self.assertFalse(result["ok"])
        self.assertTrue(any(text in error for error in result["errors"]), result)

    def test_valid_fixture(self):
        result = validate(self.root)
        self.assertTrue(result["ok"], result)
        self.assertEqual(result["checked"], 3)
        self.assertIn("capture-order", result["warning"])

    def test_wrong_size(self):
        (self.root / "coarse_x.f32").write_bytes(self.data[:-1])
        self.assert_rejected("coarse_x.f32: bytes 15 != expected 16")

    def test_same_size_corruption(self):
        (self.root / "coarse_out.f32").write_bytes(bytes(reversed(self.data)))
        self.assert_rejected("coarse_out.f32: sha256 mismatch")

    def test_missing_condition(self):
        (self.root / "coarse_cond0.f32").unlink()
        self.assert_rejected("coarse_cond0.f32")

    def test_symlink_refused(self):
        target = self.root / "outside"
        target.write_bytes(self.data)
        (self.root / "coarse_x.f32").unlink()
        (self.root / "coarse_x.f32").symlink_to(target)
        self.assert_rejected("symlink refused")

    def test_malformed_shape(self):
        for bad in ([True, 2], [0, 4], [2.0, 2], [100000000, 2], [], [1] * 9):
            with self.subTest(shape=bad):
                self.entry["x_shape"] = bad
                self.write_fixture()
                self.assert_rejected("coarse_x.f32: ")

    def test_stage_name_traversal_refused(self):
        self.document["stages"] = {"../outside": self.entry}
        self.write_fixture()
        self.assert_rejected("path traversal refused")

    def test_missing_or_oversized_metadata(self):
        (self.root / "stage-meta.json").unlink()
        self.assert_rejected("stage-meta.json")
        (self.root / "stage-meta.json").write_bytes(b" " * (2 * 1024 * 1024 + 1))
        self.assert_rejected("at most 2 MiB")

    def test_legacy_noise_bytes_match_recorded_float32_labels(self):
        labels = [1.5645464658737183, -0.125]
        self.entry["noise_labels"] = labels
        self.write_fixture()
        (self.root / "coarse_noise.f32").write_bytes(struct.pack("<2f", *labels))
        result = validate(self.root)
        self.assertTrue(result["ok"], result)
        self.assertEqual(result["checked"], 4)

    def test_new_noise_shape_digest_and_labels_agree(self):
        data = struct.pack("<2f", 1.5645464658737183, -0.125)
        self.entry.update(noise_shape=[1, 2], noise_sha256=hashlib.sha256(data).hexdigest(),
                          noise_labels=[1.5645464658737183, -0.125])
        self.write_fixture()
        (self.root / "coarse_noise.f32").write_bytes(data)
        result = validate(self.root)
        self.assertTrue(result["ok"], result)
        self.assertEqual(result["checked"], 4)

    def test_new_noise_digest_rejects_hash_even_if_labels_match(self):
        data = struct.pack("<f", 1.0)
        self.entry.update(noise_shape=[1], noise_sha256="0" * 64,
                          noise_labels=[1.0])
        self.write_fixture()
        (self.root / "coarse_noise.f32").write_bytes(data)
        self.assert_rejected("coarse_noise.f32: sha256 mismatch")

    def test_new_noise_rejects_shape_and_missing_digest(self):
        data = struct.pack("<f", 1.0)
        self.entry.update(noise_shape=[2], noise_sha256=hashlib.sha256(data).hexdigest(),
                          noise_labels=[1.0])
        self.write_fixture()
        (self.root / "coarse_noise.f32").write_bytes(data)
        self.assert_rejected("noise_shape size differs from noise_labels")
        self.entry["noise_shape"] = [1]
        del self.entry["noise_sha256"]
        self.write_fixture()
        self.assert_rejected("invalid sha256 metadata")

    def test_new_noise_rejects_label_mismatch_despite_valid_digest(self):
        data = struct.pack("<f", 1.25)
        self.entry.update(noise_shape=[1], noise_sha256=hashlib.sha256(data).hexdigest(),
                          noise_labels=[1.0])
        self.write_fixture()
        (self.root / "coarse_noise.f32").write_bytes(data)
        self.assert_rejected("float32 values differ from noise_labels")

    def test_legacy_noise_byte_mismatch_and_nonfinite(self):
        self.entry["noise_labels"] = [1.0]
        self.write_fixture()
        (self.root / "coarse_noise.f32").write_bytes(struct.pack("<f", 1.25))
        self.assert_rejected("float32 values differ")
        (self.root / "coarse_noise.f32").write_bytes(struct.pack("<f", float("nan")))
        self.assert_rejected("float32 values differ")

    def test_legacy_noise_size_missing_and_link_rejected(self):
        self.entry["noise_labels"] = [1.0]
        self.write_fixture()
        self.assert_rejected("coarse_noise.f32")
        (self.root / "coarse_noise.f32").write_bytes(b"123")
        self.assert_rejected("bytes 3 != expected 4")
        (self.root / "coarse_noise.f32").unlink()
        (self.root / "coarse_noise.f32").symlink_to(self.root / "coarse_x.f32")
        self.assert_rejected("symlink refused")

    def test_invalid_noise_labels_rejected(self):
        for labels in ([], [float("nan")], [float("inf")], [True], [1.0] * 65):
            with self.subTest(labels=labels):
                self.entry["noise_labels"] = labels
                self.write_fixture()
                self.assert_rejected("noise_labels must contain 1..64 finite numbers")

    def test_bounded_error_output_preserves_total_count(self):
        self.document["stages"] = {f"extra{i}": dict(self.entry) for i in range(20)}
        self.write_fixture()
        result = validate(self.root)
        self.assertFalse(result["ok"])
        self.assertEqual(result["error_count"], 60)
        self.assertEqual(len(result["errors"]), 16)
        self.assertEqual(result["errors_truncated"], 44)


if __name__ == "__main__":
    unittest.main()
