# Headless geometry contract for the first-person pickaxe overlay.
(import ../src/pickaxe)

(def idle (pickaxe/segments 1280 800))
(def swung (pickaxe/segments 1280 800 0.5))
(assert (= 7 (length idle)))
(assert (= 7 (length swung)))
(assert (not= idle swung))
(assert (= idle (pickaxe/segments 1280 800 0)))
(assert (= idle (pickaxe/segments 1280 800 1)))
(assert (= idle (pickaxe/segments 1280 800 2)))
(each segment idle
  (assert (= 6 (length segment)))
  (assert (pos? (segment 5)))
  (assert (= 4 (length (segment 4)))))
(def small (pickaxe/segments 640 400))
(assert (< ((small 0) 5) ((idle 0) 5)))
(print "pickaxe geometry: passed")
