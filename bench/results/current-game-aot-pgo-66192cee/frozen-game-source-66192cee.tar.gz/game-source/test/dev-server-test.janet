# Tests for the development socket server.
#
# These are headless: no raylib, no window, no GL. The server is pure socket
# plumbing over the console's evaluator, so every property worth having can be
# asserted in a batch run.
#
# What is deliberately covered:
#   - the wire format, including that a reply is always exactly one line
#   - error containment: bad syntax, runtime throws, and output capture
#   - lifecycle: client disconnect, server close, and repeated close
#   - the frame-budget promise: `pump` does bounded work and never blocks
#
# What is deliberately NOT covered: rendering, and the game loop itself. Those
# are exercised by running the game with --dev.

(import ../src/console :as console)
(import ../src/dev-server :as dev)

(var failures 0)
(defn check [name ok?]
  (if ok?
    (print "  ok   " name)
    (do (++ failures) (print "  FAIL " name))))

#
# --- Reply formatting ---------------------------------------------------
#

(print "=== reply format ===")
(def ok-result @{:ok true :output "" :value 42})
(check "value reply carries the value"
       (= "ok  => 42" (dev/format-reply ok-result)))

(def echo-result @{:ok true :output "hello\n" :value nil})
(def echo-line (dev/format-reply echo-result))
(check "nil value renders as nil" (string/find "=> nil" echo-line))
(check "output newline is escaped, not emitted"
       (and (string/find "hello\\n" echo-line)
            (not (string/find "\n" echo-line))))

(def err-result @{:ok false :output "" :error "boom"})
(check "error reply is tagged err" (string/has-prefix? "err " (dev/format-reply err-result)))

# A stack trace in an error contains newlines. If those leaked the client would
# lose framing on exactly the replies it most needs to read.
(def multi @{:ok false :output "" :error "line one\nline two"})
(check "multi-line error collapses to one line"
       (not (string/find "\n" (dev/format-reply multi))))

# Backslashes must survive: escape order decides whether \n written by the
# user comes back as \n or as \\n.
(check "backslash is escaped before newline"
       (= "a\\\\nb" (dev/escape-reply "a\\nb")))

#
# --- Evaluation against a real console env ------------------------------
#
# The socket shares the console's environment. That is what makes the socket
# and the `~` prompt the same REPL, so it is asserted rather than assumed.
#

(print "=== shared environment ===")
(def counter @{:n 0})
(def con (console/console-new))
(console/bind! con {'bump (fn [] (++ (counter :n)))} (curenv))

(def server (dev/start (dev/server-new con "127.0.0.1" 0)))
(check "server bound a port" (number? (dev/bound-port server)))
(def port (dev/bound-port server))

(defn request
  ``Send one line and read one reply.

  The reply is delivered by a reader fiber, so the pump must be driven across
  several turns: each `ev/sleep` yields so the fiber can run. Bounded so a
  protocol regression fails the test instead of hanging it.``
  [line &opt max-pumps]
  (default max-pumps 400)
  (def client (net/connect "127.0.0.1" (string port)))
  (:write client (string line "\n"))
  (var reply nil)
  (var tries 0)
  (while (and (nil? reply) (< tries max-pumps))
    (++ tries)
    (dev/pump server)
    (ev/sleep 0.001)
    (def chunk (buffer/new 4096))
    # A zero timeout raises "timeout" when the reply has not landed yet; that
    # is the expected idle case while pumping, not a failure.
    (def got (try (ev/read client 4096 chunk 0) ([err] nil)))
    (when (and got (pos? (length chunk)))
      (set reply (string (buffer/slice chunk 0 (length chunk))))))
  (try (:close client) ([err] nil))
  reply)

(def r1 (request "(+ 1 2)"))
(check "arithmetic round trip" (and r1 (string/find "=> 3" r1)))

(def r2 (request "(bump)"))
(check "can call a binding from the console environment"
       (and r2 (string/find "=> 1" r2)))
(check "the shared binding really ran" (= 1 (counter :n)))

(def r3 (request "(bump)"))
(check "binding persists across requests" (and r3 (string/find "=> 2" r3)))

#
# --- Error containment --------------------------------------------------
#
# A dev REPL that can be killed by its input is worse than no dev REPL.
#

(print "=== error containment ===")
(def bad-syntax (request "(+ 1"))
(check "unbalanced syntax replies err, server survives"
       (and bad-syntax (string/has-prefix? "err " bad-syntax)))

(def throws (request "(error \"deliberate\")"))
(check "runtime throw replies err" (and throws (string/has-prefix? "err " throws)))

(def still-alive (request "(+ 2 2)"))
(check "server still evaluates after errors"
       (and still-alive (string/find "=> 4" still-alive)))

(def prints (request "(do (print \"captured\") 7)"))
(check "printed output is captured into the reply"
       (and prints (string/find "captured" prints) (string/find "=> 7" prints)))

# A blank line must not evaluate: a client sending trailing newlines should
# not receive a stream of nil replies. Sending one and getting nothing back is
# the assertion -- a reply here would mean the blank line was evaluated.
(def blank (request "" 40))
(check "blank line produces no reply" (nil? blank))

#
# --- Lifecycle ----------------------------------------------------------
#

(print "=== lifecycle ===")
# `request` closes its client, but the server only notices on its next pump.
# Pruning has to happen in `pump`, not in `request`, otherwise a disconnected
# editor would leak a connection slot until the game is restarted.
(dev/pump server)
(ev/sleep 0.01)
(dev/pump server)
(check "closed clients are pruned" (= 0 (dev/connection-count server)))

(dev/close server)
(check "close is idempotent" (do (dev/close server) true))

(def status (dev/status nil))
(check "status on nil server is safe"
       (and (= 0 (status :connections)) (nil? (status :port))))
(check "pump on nil server is safe" (zero? (dev/pump nil)))

#
# --- Bounded work -------------------------------------------------------
#
# The whole reason this can live in the render loop: a pump with nothing to do
# must cost almost nothing, and must not block waiting for a client.
#

(print "=== bounded work ===")
(def idle (dev/start (dev/server-new con "127.0.0.1" 0)))
(def t0 (os/clock :cputime))
(for i 0 500 (dev/pump idle))
(def idle-ms (* 1000 (- (os/clock :cputime) t0)))
(print (string/format "  500 idle pumps: %.2f ms (%.1f us each)" idle-ms (/ idle-ms 500)))
(check "idle pump stays far under a frame budget" (< idle-ms 200))

# A client that connects but never sends must not block the pump.
(def silent (net/connect "127.0.0.1" (string (dev/bound-port idle))))
(dev/pump idle)
(dev/pump idle)
(check "silent client does not block the pump" true)
(try (:close silent) ([err] nil))
(dev/close idle)

#
# --- Report -------------------------------------------------------------
#

(if (zero? failures)
  (print "dev-server tests passed")
  (do
    (printf "dev-server tests FAILED (%d)" failures)
    (os/exit 1)))
