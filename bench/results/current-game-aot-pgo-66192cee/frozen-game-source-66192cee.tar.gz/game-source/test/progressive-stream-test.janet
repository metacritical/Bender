(import ../src/progressive-stream :as stream)

(defn check [description condition]
  (assert condition description)
  (print "  ok " description))

(def s (stream/new {:capacity 2}))
(check "negative coordinates accepted" (= :queued (stream/request! s -2 -1)))
(check "pending coordinate deduplicated" (= :duplicate (stream/request! s -2 -1)))
(check "bounded queue accepts second" (= :queued (stream/request! s 2 1)))
(check "queue limit rejects without evicting" (= :full (stream/request! s 7 7)))
(check "pending count remains two" (= 2 (get (stream/status s) :pending)))
(check "fractional coordinate refused"
       (not (try (do (stream/request! s 0.5 0) true) ([e] false))))
(check "out of bounds refused"
       (not (try (do (stream/request! s 134217728 0) true) ([e] false))))
(stream/focus! s 0 0 1 0)
(def first (stream/take! s))
(check "nearest chooses positive coordinate on forward tie"
       (and (= 2 (first :px)) (= 1 (first :pz))))
(check "inflight coordinate deduplicated" (= :duplicate (stream/request! s 2 1)))
(check "single lease blocks second take" (nil? (stream/take! s)))
(check "validated success publishes exact ticket" (= :published (stream/complete! s first true)))
(check "duplicate acknowledgement rejected" (= :stale (stream/complete! s first true)))
(check "published history blocks duplicate" (= :published (stream/request! s 2 1)))
(def second (stream/take! s))
(check "negative coordinate selected next" (= -2 (second :px)))
(check "explicit failed transition" (= :failed (stream/fail! s second)))
(check "failed patch not silently retried" (= :not-failed (stream/retry! s 2 1)))
(check "explicit retry queues failed patch" (= :queued (stream/retry! s -2 -1)))
(check "retry ticket differs from previous lease"
       (let [third (stream/take! s)]
         (and (not= (third :token) (second :token))
              (= :published (stream/complete! s third true)))))

(def tie (stream/new))
(stream/focus! tie 0 0 1 0)
(each coord @[@[-1 0] @[0 -1] @[0 1] @[1 0]]
  (stream/request! tie (coord 0) (coord 1)))
(def forward (stream/take! tie))
(check "lookahead breaks equal-distance tie" (= 1 (forward :px)))
(stream/complete! tie forward true)
(def lexical (stream/take! tie))
(check "remaining equal-distance priority follows deterministic lookahead"
       (and (= 0 (lexical :px)) (= -1 (lexical :pz))))
(stream/complete! tie lexical true)
(def lex-tie (stream/new))
(stream/request! lex-tie 0 1)
(stream/request! lex-tie 0 -1)
(def lex-first (stream/take! lex-tie))
(check "lexical tie break deterministic without lookahead"
       (and (= 0 (lex-first :px)) (= -1 (lex-first :pz))))
(stream/complete! lex-tie lex-first true)

(def cancelled (stream/new {:capacity 1}))
(stream/request! cancelled -9 3)
(def owned (stream/take! cancelled))
(def old-epoch (owned :epoch))
(stream/cancel! cancelled)
(check "cancel advances epoch" (= (+ old-epoch 1) (get (stream/status cancelled) :epoch)))
(check "cancel retains physical lease" (= 1 (get (stream/status cancelled) :inflight)))
(check "new epoch request admitted while old lease retained"
       (= :queued (stream/request! cancelled 0 0)))
(check "old lease blocks new work" (nil? (stream/take! cancelled)))
(check "forged ticket cannot acknowledge lease"
       (= :stale (stream/complete! cancelled
                                   {:px -9 :pz 3 :epoch old-epoch :token 999} true)))
(check "forged ack does not release lease" (= 1 (get (stream/status cancelled) :inflight)))
(check "late success discarded after cancellation"
       (= :discarded (stream/complete! cancelled owned true)))
(check "lease released only after exact acknowledgement"
       (= 0 (get (stream/status cancelled) :inflight)))
(check "old epoch completion remains stale" (= :stale (stream/complete! cancelled owned true)))
(check "new epoch work can now start"
       (let [fresh (stream/take! cancelled)]
         (and (= 0 (fresh :px)) (= 1 (fresh :epoch))
              (= :published (stream/complete! cancelled fresh true)))))

(def history (stream/new))
(for i 0 40
  (stream/request! history i 0)
  (def ticket (stream/take! history))
  (stream/complete! history ticket true))
(check "published history stays bounded" (= 32 (get (stream/status history) :history)))
(check "caller durable-present predicate prevents evicted duplicate"
       (= :present (stream/request! history 0 0 (fn [x z] (= x 0)))))
(check "evicted patch may be requested without durable-present predicate"
       (= :queued (stream/request! history 0 0)))

(print "progressive stream policy tests: ok")
