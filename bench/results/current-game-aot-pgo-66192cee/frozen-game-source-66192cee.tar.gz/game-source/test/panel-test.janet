# Tests for the studio panel registry.
#
# The registry is the game's declaration of what the panel shows. Two properties
# matter most:
#
#   * the wire format cannot be broken by content -- a label containing a
#     delimiter must not split into two controls;
#   * declaration order is stable, because a panel that reorders itself while
#     being clicked is worse than one that is merely wrong.

(import ../src/panel :as panel)

(var failures 0)
(defn check [name ok?]
  (if ok?
    (print "  ok   " name)
    (do (++ failures) (print "  FAIL " name))))

(defn fresh []
  (def r (panel/registry-new))
  (panel/define! r "add" {:kind :action :group "math" :label "Add"
                          :form "(+ 1 2)" :hint "wire the remark"})
  (panel/define! r "fps" {:kind :readout :group "perf" :label "FPS"
                          :form "(get (stats) :fps)"})
  (panel/define! r "set" {:kind :number :group "perf" :label "Radius"
                          :form "(radius %s)"})
  r)

#
# --- Escaping -----------------------------------------------------------
#

(print "=== escaping ===")
# A delimiter inside a label would otherwise split the record and the panel
# would show a corrupted control, or invent one.
(check "pipe is escaped"
       (= "a\\pb" (panel/escape-field "a|b")))
(check "semicolon is escaped"
       (= "a\\sb" (panel/escape-field "a;b")))
(check "newline is escaped"
       (= "a\\nb" (panel/escape-field "a\nb")))
(check "backslash is escaped first"
       (= "a\\\\pb" (panel/escape-field "a\\pb")))

(def hostile
  (do (def r (panel/registry-new))
      (panel/define! r "x" {:label "a|b;c" :form "(+ 1 2)"})
      (panel/manifest r)))
# The label's delimiters must survive as DATA: splitting the manifest on the
# record separator has to yield exactly one record, and splitting that on the
# field separator exactly six fields. Either escaping bug shows up here.
(check "hostile label does not split into extra records"
       (= 1 (length (string/split ";" hostile))))
(check "hostile label does not split into extra fields"
       (= 10 (length (string/split "|" hostile))))
(check "hostile label keeps its text"
       (string/find "a\\pb\\sc" hostile))

#
# --- Ordering and replacement ------------------------------------------
#

(print "=== ordering ===")
(def r (fresh))
(def lines (string/split ";" (panel/manifest r)))
(check "all controls present" (= 3 (length lines)))
(check "declaration order preserved"
       (and (string/has-prefix? "add|" (get lines 0))
            (string/has-prefix? "fps|" (get lines 1))
            (string/has-prefix? "set|" (get lines 2))))
(check "count matches" (= 3 (panel/count-of r)))

# Re-registering an id must replace in place, not append.
(panel/define! r "add" {:kind :action :group "math" :label "Add v2"
                        :form "(+ 2 2)"})
(def after (string/split ";" (panel/manifest r)))
(check "replacement does not grow the list" (= 3 (length after)))
(check "replacement keeps its position"
       (string/has-prefix? "add|" (get after 0)))
(check "replacement updated the label" (string/find "Add v2" (get after 0)))

# Numeric bounds travel with the control so the panel can build a stepped
# editor rather than a text field.
(def rn (panel/registry-new))
(panel/define! rn "t" {:kind :number :form "(t %s)" :read-form "(t)"
                       :min 0 :max 1 :step 0.05 :label "Time"})
(def rec (get (string/split ";" (panel/manifest rn)) 0))
(def flds (string/split "|" rec))
(check "manifest carries min" (= "0" (get flds 6)))
(check "manifest carries max" (= "1" (get flds 7)))
(check "manifest carries step" (= "0.05" (get flds 8)))
(check "manifest carries display form" (= "(t)" (get flds 9)))

(check "removal drops the control"
       (do (panel/remove! r "fps") (= 2 (panel/count-of r))))
(check "removal is idempotent"
       (do (panel/remove! r "fps") (= 2 (panel/count-of r))))

#
# --- Readouts -----------------------------------------------------------
#

(print "=== readouts ===")
(def r2 (fresh))
(def calls @[])
(defn fake-eval [form]
  (array/push calls form)
  (case form
    "(get (stats) :fps)" 144
    "(+ 1 2)" 3
    (error "unexpected")))

(def out (panel/readouts r2 fake-eval))
(check "only readout controls are evaluated" (= 1 (length calls)))
(check "readout renders id=value" (= "fps=144" out))

# A readout that throws must not break the panel: it is diagnostic, so an
# error in it is information, not a failure.
(panel/define! r2 "broken" {:kind :readout :group "perf" :form "(explode)"})
(def out2 (panel/readouts r2 fake-eval))
(check "throwing readout is reported in place"
       (string/find "broken=error:" out2))
(check "the good readout still rendered" (string/find "fps=144" out2))

#
# --- Empty registry -----------------------------------------------------
#

(print "=== empty ===")
(def empty (panel/registry-new))
(check "empty manifest is an empty string" (= "" (panel/manifest empty)))
(check "empty readouts is an empty string"
       (= "" (panel/readouts empty (fn [f] nil))))
(check "empty count is zero" (= 0 (panel/count-of empty)))

#
# --- Report -------------------------------------------------------------
#

(if (zero? failures)
  (print "panel tests passed")
  (do
    (printf "panel tests FAILED (%d)" failures)
    (os/exit 1)))
