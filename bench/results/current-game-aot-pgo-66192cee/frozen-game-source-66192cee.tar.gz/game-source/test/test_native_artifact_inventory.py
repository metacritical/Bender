"""Stdlib-only, toy-byte safety checks; never touches model files."""
import contextlib
import hashlib
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from native_artifact_inventory import InventoryError, inventory, main  # noqa: E402


class InventoryTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "package"
        (self.root / "models").mkdir(parents=True)
        (self.root / "notices").mkdir()
        self.payload = b"toy model bytes, not an inference graph"
        (self.root / "models" / "coarse.onnx").write_bytes(self.payload)
        (self.root / "notices" / "MODEL-LICENSE").write_text("Example only\n")
        self.spec_path = Path(self.temp.name) / "spec.json"
        self.spec = {"version": 1, "artifacts": [{
            "role": "coarse-model", "path": "models/coarse.onnx",
            "notice": "notices/MODEL-LICENSE",
            "expected_sha256": hashlib.sha256(self.payload).hexdigest()}]}
        self.write_spec()

    def write_spec(self):
        self.spec_path.write_text(json.dumps(self.spec))

    def check_refuses(self):
        self.write_spec()
        with self.assertRaises(InventoryError):
            inventory(self.root, self.spec_path)

    def test_valid_observed_and_expected(self):
        result = inventory(self.root, self.spec_path)
        artifact = result["artifacts"][0]
        self.assertEqual(artifact["bytes"], len(self.payload))
        self.assertEqual(artifact["sha256"], self.spec["artifacts"][0]["expected_sha256"])
        self.assertTrue(artifact["expected_sha256_matched"])
        self.assertGreater(artifact["notice_bytes"], 0)
        self.assertFalse(result["validated_numeric"])
        self.assertFalse(result["shipping_ready"])
        with contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(main([str(self.root), str(self.spec_path)]), 0)
        self.assertFalse(json.loads(output.getvalue())["shipping_ready"])

    def test_observation_without_expected_hash_is_not_integrity_claim(self):
        del self.spec["artifacts"][0]["expected_sha256"]
        self.write_spec()
        self.assertFalse(inventory(self.root, self.spec_path)["artifacts"][0]
                         ["expected_sha256_matched"])

    def test_tampered_artifact_rejected(self):
        (self.root / "models" / "coarse.onnx").write_bytes(self.payload + b"tamper")
        self.check_refuses()

    def test_missing_or_empty_notice_rejected(self):
        notice = self.root / "notices" / "MODEL-LICENSE"
        notice.unlink()
        self.check_refuses()
        notice.write_bytes(b"")
        self.check_refuses()

    def test_traversal_and_absolute_path_rejected(self):
        for unsafe in ("../escape", "models/../escape", "/etc/passwd", "models//coarse.onnx"):
            with self.subTest(unsafe=unsafe):
                self.spec["artifacts"][0]["path"] = unsafe
                self.check_refuses()

    def test_symlinked_file_and_parent_rejected(self):
        target = self.root / "models" / "coarse.onnx"
        target.unlink()
        target.symlink_to(self.root / "notices" / "MODEL-LICENSE")
        self.check_refuses()
        target.unlink()
        (self.root / "models").rmdir()
        (self.root / "models").symlink_to(self.root / "notices", target_is_directory=True)
        self.check_refuses()

    def test_duplicate_roles_and_paths_rejected(self):
        duplicate = dict(self.spec["artifacts"][0])
        self.spec["artifacts"].append(duplicate)
        self.check_refuses()
        duplicate["role"] = "decoder-model"
        self.check_refuses()
        duplicate["path"] = "notices/MODEL-LICENSE"
        self.check_refuses()

    def test_malformed_bounds_and_schema_rejected(self):
        original = self.spec["artifacts"][0]
        for count in (0, 129):
            with self.subTest(count=count):
                self.spec["artifacts"] = [dict(original,
                                                role=f"model-{i}", path=f"models/{i}")
                                          for i in range(count)]
                self.check_refuses()
        self.spec["artifacts"] = [{"role": "x", "path": "models/coarse.onnx",
                                   "notice": "notices/MODEL-LICENSE",
                                   "expected_sha256": "broken"}]
        self.check_refuses()
        self.spec_path.write_bytes(b" " * 1_048_577)
        with self.assertRaises(InventoryError):
            inventory(self.root, self.spec_path)


if __name__ == "__main__":
    unittest.main()
