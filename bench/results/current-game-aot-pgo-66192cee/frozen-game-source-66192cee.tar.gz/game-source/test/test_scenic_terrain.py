"""Scenic format 3 tests: offline raw export, global transfer, and the TDS3 tile.

These are offline tests. Nothing here loads a model or touches a GPU; a fake
elevation field stands in for the sampler exactly as the backend tests use one.
"""

import hashlib
import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "tools"))

import scenic_terrain as st          # noqa: E402
import terrain_cache as tc           # noqa: E402


def _grid(width=32, height=32, low=850.0, high=1600.0):
    """A deterministic ramp in metres, spanning a known range."""
    import numpy as np

    rows = []
    for z in range(height):
        row = [low + (high - low) * (x + z) / float(width + height - 2)
               for x in range(width)]
        rows.append(row)
    return np.asarray(rows, dtype=np.float32)


class MappingTests(unittest.TestCase):
    def test_scenic_band_is_4_to_252(self):
        mapping = st.scenic_mapping(meters_per_voxel=25, sea_level=28)
        self.assertEqual(mapping.height_min, 4)
        self.assertEqual(mapping.height_max, 252)

    def test_reserved_top_values_are_refused(self):
        for bad in (253, 254, 255, 300):
            with self.assertRaises(st.ScenicError):
                st.scenic_mapping(
                    meters_per_voxel=25, sea_level=28, height_max=bad
                )

    def test_scale_must_be_positive_and_finite(self):
        for bad in (0, -1, float("inf"), float("nan"), True):
            with self.assertRaises(st.ScenicError):
                st.scenic_mapping(meters_per_voxel=bad, sea_level=28)

    def test_finer_scale_uses_more_levels(self):
        """The whole point: 750 m of relief compresses into 15 levels at 50 m."""
        coarse = tc.HEIGHT_MAPPING
        fine = st.scenic_mapping(meters_per_voxel=25, sea_level=28)
        coarse_span = coarse.quantize(1600.0) - coarse.quantize(850.0)
        fine_span = fine.quantize(1600.0) - fine.quantize(850.0)
        self.assertGreater(fine_span, coarse_span * 2 - 2)

    def test_mapping_is_global_not_per_tile(self):
        """Same elevation must quantize the same regardless of neighbours."""
        mapping = st.scenic_mapping(meters_per_voxel=25, sea_level=28)
        self.assertEqual(mapping.quantize(1234.5), mapping.quantize(1234.5))

    def test_mapping_record_carries_profile_and_sampling(self):
        mapping = st.scenic_mapping(meters_per_voxel=25, sea_level=28)
        record = st.mapping_record(mapping, profile="alpine")
        self.assertEqual(record["profile"], "alpine")
        self.assertEqual(record["sampling"], "offline-import")
        self.assertEqual(record["height_max"], 252)


class TileFormatTests(unittest.TestCase):
    def test_scenic_tile_is_308_bytes_with_tds3_magic(self):
        data = st.encode_scenic_tile(3, -2, bytes([30] * 256))
        self.assertEqual(len(data), 308)
        self.assertEqual(data[:4], b"TDS3")

    def test_round_trip_preserves_heights(self):
        heights = bytes((i % 249) + 4 for i in range(256))
        data = st.encode_scenic_tile(7, 9, heights)
        cx, cz, payload = st.decode_scenic_tile(data, 7, 9)
        self.assertEqual((cx, cz), (7, 9))
        self.assertEqual(bytes(payload), heights)

    def test_heights_above_the_tdh2_band_survive(self):
        """200 is legal in scenic and would be clamped by TDH2."""
        data = st.encode_scenic_tile(0, 0, bytes([200] * 256))
        _, _, payload = st.decode_scenic_tile(data, 0, 0)
        self.assertEqual(max(payload), 200)

    def test_tdh2_reader_refuses_a_scenic_tile(self):
        data = st.encode_scenic_tile(0, 0, bytes([60] * 256))
        with self.assertRaises(tc.TileCorruptError) as caught:
            tc.decode_tile(data, 0, 0)
        self.assertIn("magic", str(caught.exception))

    def test_scenic_reader_refuses_a_tdh2_tile(self):
        data = tc.encode_tile(0, 0, bytes([60] * 256))
        with self.assertRaises(st.ScenicError) as caught:
            st.decode_scenic_tile(data, 0, 0)
        self.assertIn("magic", str(caught.exception))

    def test_out_of_band_height_is_refused_on_encode(self):
        for bad in (3, 253, 255):
            with self.assertRaises(st.ScenicError):
                st.encode_scenic_tile(0, 0, bytes([bad] * 256))

    def test_corrupt_payload_is_refused(self):
        data = bytearray(st.encode_scenic_tile(0, 0, bytes([40] * 256)))
        data[-1] = 41
        with self.assertRaises(st.ScenicError):
            st.decode_scenic_tile(bytes(data), 0, 0)

    def test_coordinate_mismatch_is_refused(self):
        data = st.encode_scenic_tile(1, 2, bytes([40] * 256))
        with self.assertRaises(st.ScenicError):
            st.decode_scenic_tile(data, 9, 9)

    def test_truncated_tile_is_refused(self):
        data = st.encode_scenic_tile(0, 0, bytes([40] * 256))[:-1]
        with self.assertRaises(st.ScenicError):
            st.decode_scenic_tile(data, 0, 0)


class RawExportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="scenic-test-")

    def _export(self, **kwargs):
        path = os.path.join(self.tmp, "raw.npz")
        meta = st.export_raw(
            path,
            kwargs.pop("grid", _grid()),
            origin_pixels=(100000, 100000),
            seed=12345,
            provenance={"model": "terrain-diffusion-30m"},
            **kwargs,
        )
        return path, meta

    def test_export_records_real_metre_range(self):
        _, meta = self._export()
        self.assertFalse(meta["quantized"])
        self.assertAlmostEqual(meta["elevation_min_m"], 850.0, places=1)
        self.assertAlmostEqual(meta["elevation_max_m"], 1600.0, places=1)
        self.assertEqual(meta["origin_pixels"], [100000, 100000])

    def test_export_keeps_metres_not_voxels(self):
        import numpy as np

        path, _ = self._export()
        arrays, _ = st.read_raw(path)
        self.assertEqual(arrays["elevation_m"].dtype, np.float32)
        # 1600 m is nowhere near a voxel index, so it cannot be quantized data.
        self.assertGreater(float(arrays["elevation_m"].max()), 200.0)

    def test_export_refuses_non_finite_samples(self):
        import numpy as np

        grid = _grid()
        grid[3][3] = float("nan")
        with self.assertRaises(st.ScenicError):
            self._export(grid=grid)

    def test_read_raw_detects_a_tampered_digest(self):
        path, meta = self._export()
        with open(path, "ab") as handle:
            handle.write(b"x")
        with self.assertRaises(st.ScenicError) as caught:
            st.read_raw(path)
        self.assertIn("digest", str(caught.exception))

    def test_read_raw_refuses_a_quantized_export(self):
        path, _ = self._export()
        meta_path = os.path.splitext(path)[0] + ".json"
        with open(meta_path) as handle:
            meta = json.load(handle)
        meta["quantized"] = True
        with open(meta_path, "w") as handle:
            json.dump(meta, handle)
        with self.assertRaises(st.ScenicError) as caught:
            st.read_raw(path)
        self.assertIn("quantized", str(caught.exception))


def _climate(rows=32, cols=32, channels=5, base=0.0):
    """A deterministic climate grid, distinct per channel and cell."""
    import numpy as np

    out = np.empty((rows, cols, channels), dtype=np.float32)
    for c in range(channels):
        for z in range(rows):
            for x in range(cols):
                out[z, x, c] = base + 1000.0 * c + 10.0 * x + z
    return out


class ClimateExportTests(unittest.TestCase):
    """The raw export already carried climate; this is the container seam."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="scenic-climate-")
        self.raw = os.path.join(self.tmp, "raw.npz")

    def _export(self, climate=None):
        return st.export_raw(
            self.raw, _grid(), origin_pixels=(100000, 100000), seed=12345,
            provenance={"model": "terrain-diffusion-30m"}, climate=climate,
        )

    def _import(self, cache_root=None, **kwargs):
        kwargs.setdefault("meters_per_voxel", 25)
        kwargs.setdefault("sea_level", 28)
        kwargs.setdefault("profile", "alpine")
        kwargs.setdefault("world_origin_voxels", (-256, -256))
        return st.import_raw(
            self.raw, cache_root or os.path.join(self.tmp, "cache"), **kwargs
        )

    def test_no_climate_writes_no_payload_and_no_record_block(self):
        self._export()
        summary = self._import()
        directory = os.path.join(os.path.dirname(summary["directory"]),
                                 summary["identity"])
        self.assertFalse(
            os.path.exists(os.path.join(directory, st.CLIMATE_NAME)))
        self.assertFalse(summary["has_climate"])
        with open(os.path.join(directory, st.SCENIC_JSON_NAME)) as handle:
            record = json.load(handle)
        self.assertNotIn("climate", record)

    def test_absent_climate_is_byte_identical_to_the_old_record(self):
        """The pre-climate artifact must not change at all."""
        self._export()
        summary = self._import()
        directory = summary["directory"]
        baseline = st.scenic_map_record(
            {"seed": 12345, "pixels_per_voxel": 1,
             "origin_pixels": [100000, 100000], "origin_voxels": [-256, -256],
             "mapping": st.mapping_record(
                 st.scenic_mapping(meters_per_voxel=25, sea_level=28),
                 profile="alpine"),
             "provenance": {"model": "terrain-diffusion-30m"}},
            map_bounds={"width_pixels": 32, "height_pixels": 32,
                        "chunks_x": 2, "chunks_z": 2,
                        "chunk_min": [-16, -16], "chunk_max": [-14, -14]},
            profile="alpine", raw_sha256=summary["raw_sha256"],
            mapping=st.scenic_mapping(meters_per_voxel=25, sea_level=28),
        )
        with open(os.path.join(directory, st.SCENIC_JSON_NAME)) as handle:
            on_disk = json.load(handle)
        self.assertEqual(on_disk, baseline)
        self.assertEqual(len(on_disk), 18)   # the pre-climate key count

    def test_climate_bytes_metadata_and_projection_are_recorded(self):
        climate = _climate()
        self._export(climate=climate)
        summary = self._import()
        self.assertTrue(summary["has_climate"])
        location = summary["directory"]
        with open(os.path.join(location, st.CLIMATE_NAME), "rb") as handle:
            payload = handle.read()

        self.assertEqual(len(payload), 32 * 32 * 5 * 4)
        with open(os.path.join(location, st.SCENIC_JSON_NAME)) as handle:
            record = json.load(handle)
        block = record["climate"]
        self.assertEqual(block["container"], "flat-f32-le")
        self.assertEqual(block["container-version"], st.CLIMATE_CONTAINER_VERSION)
        self.assertEqual(block["shape"], [32, 32, 5])
        self.assertEqual(block["dtype"], "f32<")
        self.assertEqual(block["bytes"], len(payload))
        self.assertEqual(block["channels"], list(st.CLIMATE_CHANNELS))
        self.assertEqual(block["basis"], "source-derived")
        self.assertFalse(block["calibrated"])
        self.assertEqual(block["sha256"],
                         hashlib.sha256(payload).hexdigest())
        self.assertEqual(block["crc32"],
                         __import__("zlib").crc32(payload) & 0xFFFFFFFF)
        # A 32x32 source imported into a 32x32 artifact is scale 1, honest.
        self.assertEqual(block["projection"]["scale"], 1)
        self.assertEqual(block["projection"]["origin"], [-256, -256])
        self.assertEqual(block["projection"]["source-grid"], [32, 32])
        self.assertEqual(block["projection"]["artifact-grid"], [32, 32])

    def test_payload_round_trips_to_the_source_values(self):
        import numpy as np

        climate = _climate()
        self._export(climate=climate)
        summary = self._import()
        with open(os.path.join(summary["directory"], st.CLIMATE_NAME),
                  "rb") as handle:
            payload = handle.read()
        recovered = np.frombuffer(payload, dtype="<f4").reshape(32, 32, 5)
        self.assertEqual(float(recovered[7, 9, 3]), float(climate[7, 9, 3]))
        self.assertEqual(float(recovered[31, 31, 4]), float(climate[31, 31, 4]))

    def test_climate_does_not_change_the_manifest_key_set(self):
        self._export(climate=_climate())
        summary = self._import()
        record = st.read_scenic_manifest(
            os.path.join(self.tmp, "cache"), summary["identity"])
        self.assertEqual(set(record), set(st.SCENIC_MANIFEST_KEYS))
        self.assertEqual(len(record), 12)

    def test_upstream_channel_major_climate_is_refused(self):
        """`(5, H, W)` is what upstream returns; the exporter wants (H, W, 5)."""
        import numpy as np

        climate = np.zeros((5, 32, 32), dtype=np.float32)
        with self.assertRaises(st.ScenicError) as caught:
            self._export(climate=climate)
        self.assertIn("channels", str(caught.exception))

    def test_wrong_plane_shape_is_refused(self):
        import numpy as np

        climate = np.zeros((16, 16, 5), dtype=np.float32)
        with self.assertRaises(st.ScenicError) as caught:
            self._export(climate=climate)
        self.assertIn("grid", str(caught.exception))

    def test_non_finite_climate_is_refused_before_any_artifact(self):
        import numpy as np

        climate = _climate()
        climate[4, 5, 2] = float("nan")
        with self.assertRaises(st.ScenicError) as caught:
            self._export(climate=climate)
        self.assertIn("non-finite", str(caught.exception))
        self.assertFalse(os.path.exists(self.raw))

    def test_sidecar_and_array_must_agree(self):
        """`has_climate: true` with no array is an inconsistent export."""
        import numpy as np

        self._export()
        meta_path = os.path.splitext(self.raw)[0] + ".json"
        with open(meta_path) as handle:
            meta = json.load(handle)
        meta["has_climate"] = True
        with open(meta_path, "w") as handle:
            json.dump(meta, handle)
        with self.assertRaises(st.ScenicError) as caught:
            self._import()
        self.assertIn("no 'climate' array", str(caught.exception))

    def test_climate_changes_the_identity_through_the_raw_digest(self):
        """Two maps differing only by climate must not share an identity."""
        self._export(climate=_climate())
        with_climate = self._import(
            cache_root=os.path.join(self.tmp, "a"))["identity"]
        self._export()
        without = self._import(
            cache_root=os.path.join(self.tmp, "b"))["identity"]
        self.assertNotEqual(with_climate, without)

    def test_projection_refuses_an_unprojectable_artifact_grid(self):
        with self.assertRaises(st.ScenicError) as caught:
            st.climate_projection(
                source_grid=(32, 32), artifact_grid=(33, 32),
                world_origin_voxels=(0, 0),
            )
        self.assertIn("integer multiple", str(caught.exception))

    def test_projection_records_a_honest_scale_for_an_upsampled_grid(self):
        projection = st.climate_projection(
            source_grid=(128, 128), artifact_grid=(512, 512),
            world_origin_voxels=(-16, -16),
        )
        self.assertEqual(projection["scale"], 4)
        self.assertEqual(projection["origin"], [-16, -16])
        self.assertEqual(projection["semantics"], "cell-grid")
        self.assertEqual(projection["source-grid"], [128, 128])
        self.assertEqual(projection["artifact-grid"], [512, 512])



class ResampleTests(unittest.TestCase):
    """Upscaling must be declared, endpoint-preserving, and must invent nothing."""

    def test_target_shape_is_exact(self):
        import numpy as np

        source = _grid(16, 16)
        out = st.resample_to_shape(source, (64, 64))
        self.assertEqual(out.shape, (64, 64))

    def test_endpoints_and_corners_are_preserved(self):
        import numpy as np

        source = _grid(16, 16)
        out = st.resample_to_shape(source, (64, 64))
        for sy, sx, oy, ox in ((0, 0, 0, 0), (0, -1, 0, -1),
                               (-1, 0, -1, 0), (-1, -1, -1, -1)):
            self.assertAlmostEqual(
                float(out[oy, ox]), float(source[sy, sx]), places=4
            )

    def test_sample_lattice_hits_source_rows(self):
        import numpy as np

        source = _grid(16, 16)
        out = st.resample_to_shape(source, (61, 61))
        # With a 15-span over 60 intervals, every 4th output row is a real sample.
        for i in range(16):
            self.assertAlmostEqual(
                float(out[i * 4, 0]), float(source[i, 0]), places=4
            )

    def test_no_overshoot_between_samples(self):
        import numpy as np

        source = _grid(16, 16)
        out = st.resample_to_shape(source, (128, 128))
        self.assertGreaterEqual(out.min(), source.min() - 1e-3)
        self.assertLessEqual(out.max(), source.max() + 1e-3)

    def test_relief_is_preserved(self):
        import numpy as np

        source = _grid(16, 16)
        out = st.resample_to_shape(source, (256, 256))
        self.assertAlmostEqual(
            float(out.max() - out.min()),
            float(source.max() - source.min()),
            places=2,
        )


class AdoptRawTests(unittest.TestCase):
    """A scout artifact must enter through verification, with honest metadata."""

    def setUp(self):
        import numpy as np

        self.tmp = tempfile.mkdtemp(prefix="scenic-adopt-")
        self.source = os.path.join(self.tmp, "scout.npz")
        self.grid = _grid(32, 32)
        # Written the way the real scout wrote it: npz_sha256, no provenance.
        np.savez_compressed(
            self.source,
            elevation_m=self.grid.astype(np.float32),
            origin_pixels=np.asarray([100000, 100000], dtype=np.int64),
            seed=np.asarray([12345], dtype=np.int64),
            pixels_per_voxel=np.asarray([1], dtype=np.int64),
        )
        with open(self.source, "rb") as handle:
            digest = hashlib.sha256(handle.read()).hexdigest()
        with open(os.path.join(self.tmp, "scout.json"), "w") as handle:
            json.dump({"source": "raw-scout-128", "npz_sha256": digest,
                       "quantized": False}, handle)

    def _adopt(self, **kwargs):
        destination = os.path.join(self.tmp, "adopted.npz")
        kwargs.setdefault("target_shape", (128, 128))
        kwargs.setdefault("provenance", {"identity_digest": "c210cb74",
                                         "sampled_by": "pipeline.get"})
        return st.adopt_raw(self.source, destination, **kwargs), destination

    def test_legacy_digest_key_is_accepted(self):
        meta, _ = self._adopt()
        self.assertEqual(meta["width"], 128)
        self.assertEqual(meta["height"], 128)

    def test_tampered_source_is_refused(self):
        with open(self.source, "ab") as handle:
            handle.write(b"x")
        with self.assertRaises(st.ScenicError) as caught:
            self._adopt()
        self.assertIn("digest", str(caught.exception))

    def test_provenance_is_recorded_verbatim_and_not_invented(self):
        meta, _ = self._adopt()
        provenance = meta["provenance"]
        self.assertEqual(provenance["identity_digest"], "c210cb74")
        self.assertEqual(provenance["sampled_by"], "pipeline.get")
        # Nothing model-specific is fabricated: only what the caller asserted.
        self.assertNotIn("model_revision", provenance)

    def test_interpolation_is_declared_in_metadata(self):
        meta, _ = self._adopt()
        transform = meta["provenance"]["grid_transform"]
        self.assertEqual(transform["operation"], "bilinear")
        self.assertEqual(transform["source_shape"], [32, 32])
        self.assertEqual(transform["output_shape"], [128, 128])
        self.assertTrue(transform["endpoint_preserving"])
        self.assertFalse(transform["invents_detail"])

    def test_identity_transform_when_no_resampling(self):
        meta, _ = self._adopt(target_shape=None)
        transform = meta["provenance"]["grid_transform"]
        self.assertEqual(transform["operation"], "identity")
        self.assertEqual(transform["output_shape"], [32, 32])

    def test_adopted_export_is_readable_and_reverifiable(self):
        _, destination = self._adopt()
        arrays, meta = st.read_raw(destination)
        self.assertEqual(arrays["elevation_m"].shape, (128, 128))
        self.assertFalse(meta["quantized"])


class AdoptRawClimateTests(unittest.TestCase):
    """`adopt_raw` must not shed climate it read out of a real raw export."""

    def setUp(self):
        import numpy as np

        self.tmp = tempfile.mkdtemp(prefix="scenic-adopt-climate-")
        self.source = os.path.join(self.tmp, "scout.npz")
        self.grid = _grid(32, 32)
        self.climate = _climate(32, 32)

    def _write_source(self, *, climate=True, has_climate=None, climate_values=None):
        """Write a scout npz the way a real producer did: npz_sha256, no provenance."""
        import numpy as np

        arrays = {
            "elevation_m": self.grid.astype(np.float32),
            "origin_pixels": np.asarray([100000, 100000], dtype=np.int64),
            "seed": np.asarray([42], dtype=np.int64),
            "pixels_per_voxel": np.asarray([1], dtype=np.int64),
        }
        values = None
        if climate:
            values = self.climate if climate_values is None else climate_values
            # A COPY, so the source bytes are independent of the caller's array.
            arrays["climate"] = np.asarray(values, dtype=np.float32).copy()
        np.savez_compressed(self.source, **arrays)
        with open(self.source, "rb") as handle:
            digest = hashlib.sha256(handle.read()).hexdigest()
        meta = {
            "source": "raw-scout-128",
            "npz_sha256": digest,
            "quantized": False,
            "has_climate": climate if has_climate is None else has_climate,
        }
        with open(os.path.join(self.tmp, "scout.json"), "w") as handle:
            json.dump(meta, handle)
        return arrays.get("climate")

    def _adopt(self, name="adopted.npz", **kwargs):
        destination = os.path.join(self.tmp, name)
        kwargs.setdefault("target_shape", None)
        kwargs.setdefault("provenance", {"sampled_by": "pipeline.get"})
        return st.adopt_raw(self.source, destination, **kwargs), destination

    def test_climate_survives_adoption_byte_for_byte(self):
        import numpy as np

        written = self._write_source()
        meta, destination = self._adopt()
        self.assertTrue(meta["has_climate"])

        arrays, read_meta = st.read_raw(destination)
        self.assertTrue(read_meta["has_climate"])
        self.assertIn("climate", arrays)

        original = written.astype("<f4").tobytes()
        adopted = np.asarray(arrays["climate"]).astype("<f4", copy=False).tobytes()
        self.assertEqual(adopted, original)
        self.assertEqual(arrays["climate"].shape, (32, 32, 5))
        self.assertEqual(len(adopted), 32 * 32 * 5 * 4)

    def test_adopted_climate_sha_matches_the_source_payload(self):
        import numpy as np

        written = self._write_source()
        meta, destination = self._adopt()
        arrays, _ = st.read_raw(destination)
        self.assertEqual(
            hashlib.sha256(np.asarray(arrays["climate"])
                           .astype("<f4").tobytes()).hexdigest(),
            hashlib.sha256(written.astype("<f4").tobytes()).hexdigest(),
        )
        # The adopted export's own raw digest covers the climate it carries.
        with open(destination, "rb") as handle:
            self.assertEqual(meta["raw_sha256"],
                             hashlib.sha256(handle.read()).hexdigest())

    def test_adopted_climate_imports_into_a_bound_container(self):
        import numpy as np

        self._write_source()
        meta, destination = self._adopt()
        summary = st.import_raw(
            destination, os.path.join(self.tmp, "cache"),
            meters_per_voxel=25, sea_level=28, profile="alpine",
            world_origin_voxels=(-16, -16),
        )
        self.assertTrue(summary["has_climate"])
        with open(os.path.join(summary["directory"], st.CLIMATE_NAME), "rb") as h:
            payload = h.read()
        self.assertEqual(len(payload), 32 * 32 * 5 * 4)
        with open(os.path.join(summary["directory"], st.SCENIC_JSON_NAME)) as h:
            block = json.load(h)["climate"]
        self.assertEqual(block["sha256"], hashlib.sha256(payload).hexdigest())
        recovered = np.frombuffer(payload, dtype="<f4").reshape(32, 32, 5)
        self.assertEqual(float(recovered[3, 4, 2]), float(self.climate[3, 4, 2]))

    def test_no_climate_source_adopts_byte_identically_as_before(self):
        """The legacy path is untouched: no array, no flag, same claims."""
        self._write_source(climate=False)
        meta, destination = self._adopt()
        self.assertFalse(meta["has_climate"])
        arrays, read_meta = st.read_raw(destination)
        self.assertNotIn("climate", arrays)
        self.assertFalse(read_meta["has_climate"])
        # The identity transform is still recorded exactly as it was.
        transform = meta["provenance"]["grid_transform"]
        self.assertEqual(transform["operation"], "identity")
        self.assertEqual(transform["output_shape"], [32, 32])

    def test_corrupt_climate_is_refused_not_dropped(self):
        import numpy as np

        broken = self.climate.copy()
        broken[6, 7, 1] = float("nan")
        self._write_source(climate_values=broken)
        with self.assertRaises(st.ScenicError) as caught:
            self._adopt()
        self.assertIn("non-finite", str(caught.exception))
        # Nothing was written for a source that could not be validated.
        self.assertFalse(os.path.exists(os.path.join(self.tmp, "adopted.npz")))

    def test_flag_and_array_must_agree_on_the_source(self):
        self._write_source(climate=True, has_climate=False)
        with self.assertRaises(st.ScenicError) as caught:
            self._adopt()
        self.assertIn("has_climate is false", str(caught.exception))

    def test_declared_climate_without_an_array_is_refused(self):
        self._write_source(climate=False, has_climate=True)
        with self.assertRaises(st.ScenicError) as caught:
            self._adopt()
        self.assertIn("no 'climate' array", str(caught.exception))

    def test_resampling_a_climate_bearing_source_is_refused(self):
        """Climate is carried unchanged, so a resampled grid cannot describe it."""
        self._write_source()
        with self.assertRaises(st.ScenicError) as caught:
            self._adopt(target_shape=(128, 128))
        self.assertIn("refusing to resample", str(caught.exception))

    def test_existing_destination_is_never_overwritten(self):
        self._write_source()
        destination = os.path.join(self.tmp, "adopted.npz")
        with open(destination, "wb") as handle:
            handle.write(b"a ready artifact may be reading this")
        with self.assertRaises(st.ScenicError) as caught:
            self._adopt()
        self.assertIn("refusing to overwrite", str(caught.exception))
        with open(destination, "rb") as handle:
            self.assertEqual(handle.read(), b"a ready artifact may be reading this")


class ImportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="scenic-import-")
        self.raw = os.path.join(self.tmp, "raw.npz")
        st.export_raw(
            self.raw, _grid(), origin_pixels=(100000, 100000), seed=12345
        )
        self.cache_root = os.path.join(self.tmp, "cache")

    def _import(self, **kwargs):
        kwargs.setdefault("meters_per_voxel", 25)
        kwargs.setdefault("sea_level", 28)
        kwargs.setdefault("profile", "alpine")
        kwargs.setdefault("world_origin_voxels", (-256, -256))
        return st.import_raw(self.raw, self.cache_root, **kwargs)

    def test_manifest_key_set_matches_the_janet_reader_exactly(self):
        """The Janet gate compares key COUNT against its own 12-key vector."""
        summary = self._import()
        record = st.read_scenic_manifest(self.cache_root, summary["identity"])
        self.assertEqual(set(record), set(st.SCENIC_MANIFEST_KEYS))
        self.assertEqual(len(record), 12)
        for required in ("bounds", "origin", "json-crc32", "json-bytes"):
            self.assertIn(required, record)

    def test_bounds_are_inclusive_chunks_and_origin_is_world_voxels(self):
        summary = st.import_raw(
            self.raw, self.cache_root,
            meters_per_voxel=25, sea_level=28, profile="alpine",
            world_origin_voxels=(-256, -256),
        )
        record = st.read_scenic_manifest(self.cache_root, summary["identity"])
        # 32x32 raw => 2x2 chunks starting at -16, so inclusive upper is -15.
        self.assertEqual(record["bounds"], [-16, -16, -15, -15])
        self.assertEqual(record["origin"], [-256, -256])

    def test_world_origin_is_independent_of_sampling_origin(self):
        summary = st.import_raw(
            self.raw, self.cache_root,
            meters_per_voxel=25, sea_level=28, profile="alpine",
            world_origin_voxels=(-256, -256),
        )
        record = st.read_scenic_manifest(self.cache_root, summary["identity"])
        # Sampling origin stays 100000 px; world placement is -256 blocks.
        self.assertEqual(summary["origin_voxels"], [-256, -256])
        self.assertNotEqual(record["bounds"][0], 100000 // 16)

    def test_centred_world_origin_makes_spawn_intersect(self):
        """A 512-block map centred on 0 must straddle chunk (0,0).

        The default fixture is only 2 chunks wide, so it cannot span the origin;
        this uses a 32-chunk (512 block) grid, the delivered map's size.
        """
        import numpy as np

        big = os.path.join(self.tmp, "big.npz")
        st.export_raw(
            big, np.zeros((512, 512), dtype=np.float32),
            origin_pixels=(100000, 100000), seed=12345,
        )
        summary = st.import_raw(
            big, os.path.join(self.tmp, "bigcache"),
            meters_per_voxel=5, sea_level=28, profile="alpine",
            world_origin_voxels=(-256, -256),
        )
        b = summary["bounds_inclusive"]
        self.assertEqual(b, [-16, -16, 15, 15])
        self.assertLessEqual(b[0], 0)
        self.assertGreaterEqual(b[2], 0)

    def test_moving_the_world_origin_changes_the_identity(self):
        first = st.import_raw(
            self.raw, os.path.join(self.tmp, "a"),
            meters_per_voxel=25, sea_level=28, profile="alpine",
            world_origin_voxels=(-256, -256),
        )["identity"]
        second = st.import_raw(
            self.raw, os.path.join(self.tmp, "b"),
            meters_per_voxel=25, sea_level=28, profile="alpine",
            world_origin_voxels=(0, 0),
        )["identity"]
        self.assertNotEqual(first, second)

    def test_record_is_bound_by_size_and_crc(self):
        import zlib

        summary = self._import()
        digest = summary["identity"]
        directory = os.path.join(self.cache_root, digest)
        record = st.read_scenic_manifest(self.cache_root, digest)
        with open(os.path.join(directory, "provenance.json"), "rb") as handle:
            data = handle.read()
        self.assertEqual(record["json-bytes"], len(data))
        self.assertEqual(record["json-crc32"], zlib.crc32(data) & 0xFFFFFFFF)

    def test_twin_declares_bounds_origin_and_binding(self):
        summary = self._import()
        directory = os.path.join(self.cache_root, summary["identity"])
        with open(os.path.join(directory, "manifest.janet")) as handle:
            twin = handle.read()
        for token in (":bounds [", ":origin [", ":json-crc32", ":json-bytes",
                      ":height-min 4", ":height-max 252"):
            self.assertIn(token, twin)

    def test_import_writes_a_readable_scenic_cache(self):
        summary = self._import()
        self.assertEqual(summary["tiles"], 4)          # 32x32 -> 2x2 tiles
        self.assertEqual(summary["height_max"], 252)
        digest = summary["identity"]
        record = st.read_scenic_manifest(self.cache_root, digest)
        self.assertEqual(record["format"], 3)
        self.assertEqual(record["magic"], "TDS3")
        # Coordinates come from the world origin (-256 blocks = chunk -16),
        # not from the 100000-pixel sampling origin.
        cx, cz, payload = st.read_scenic_tile(
            self.cache_root, digest, -16, -16
        )
        self.assertEqual(len(payload), 256)
        self.assertEqual((cx, cz), (-16, -16))

    def test_import_reports_clamping_from_the_real_range(self):
        # 1600 m at 5 m/voxel quantizes to ~348, past the 252 ceiling, so the
        # clamp must be counted rather than silently dropped.
        summary = self._import(meters_per_voxel=5)
        self.assertGreater(summary["clamped_at_max"], 0)

    def test_a_scale_that_fits_reports_no_clamping(self):
        summary = self._import(meters_per_voxel=25)
        self.assertEqual(summary["clamped_at_max"], 0)

    def test_import_records_source_range_from_raw(self):
        summary = self._import()
        self.assertAlmostEqual(summary["source_min_m"], 850.0, places=1)
        self.assertAlmostEqual(summary["source_max_m"], 1600.0, places=1)

    def test_a_different_scale_is_a_different_identity(self):
        first = self._import(meters_per_voxel=25)["identity"]
        second = st.import_raw(
            self.raw, os.path.join(self.tmp, "other"),
            meters_per_voxel=50, sea_level=28, profile="alpine",
        )["identity"]
        self.assertNotEqual(first, second)

    def test_same_parameters_are_idempotent(self):
        first = self._import()
        second = self._import()
        self.assertEqual(first["identity"], second["identity"])

    def test_manifest_is_not_a_tdh2_manifest(self):
        summary = self._import()
        record = st.read_scenic_manifest(self.cache_root, summary["identity"])
        self.assertNotEqual(record["format"], tc.FORMAT_VERSION)
        # The Janet gate compares key COUNT, so scenic must differ there too.
        self.assertNotEqual(len(record), 6)

    def test_scenic_reader_refuses_a_tdh2_manifest(self):
        import hashlib

        digest = hashlib.sha256(b"fake").hexdigest()
        directory = os.path.join(self.cache_root, digest)
        os.makedirs(directory)
        with open(os.path.join(directory, "manifest.json"), "w") as handle:
            json.dump({"format": 2, "magic": "TDH2"}, handle)
        with self.assertRaises(st.ScenicError) as caught:
            st.read_scenic_manifest(self.cache_root, digest)
        self.assertIn("format", str(caught.exception))

    def test_import_refuses_a_grid_that_is_not_whole_tiles(self):
        import numpy as np

        odd = os.path.join(self.tmp, "odd.npz")
        st.export_raw(
            odd, np.zeros((30, 30), dtype=np.float32),
            origin_pixels=(0, 0), seed=1,
        )
        with self.assertRaises(st.ScenicError) as caught:
            st.import_raw(
                odd, os.path.join(self.tmp, "c2"),
                meters_per_voxel=25, sea_level=28, profile="alpine",
            )
        self.assertIn("whole number", str(caught.exception))


if __name__ == "__main__":
    unittest.main()
