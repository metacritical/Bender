# Isolated scheduler tests; worldgen's world import is not exercised.
(import ../src/async-worldgen :as async)
(import ../src/worldgen :as worldgen)

(defn expected [cx cz seed]
  (worldgen/generate-into (buffer/new 16384) cx cz seed))

# proc lanes are process-global: each scheduler below owns them sequentially.
(assert (= 0 (proc/lanes)) "test requires unowned process lanes")

(defn check-result [result]
  (assert (not (get (result :result) :error)) "worker failed")
  (assert (= 16384 (length ((result :result) :blocks))) "wrong chunk size")
  (assert (= (string (expected (result :cx) (result :cz) (result :seed)))
             (string ((result :result) :blocks))) "worker bytes differ"))

(let [scheduler (async/new {:concurrency 2 :capacity 4})]
  (assert (= 0 (async/submit scheduler 0 0 42 0)) "sequence starts at zero")
  (async/submit scheduler 1 -1 42 0)
  (async/submit scheduler 2 -2 27 7)
  (async/submit scheduler 3 -3 27 7)
  (assert (= 2 (proc/lanes)) "concurrency owns two persistent lanes")
  (assert (not (try (do (async/new {:concurrency 1}) true) ([e] false)))
          "second scheduler cannot claim already owned lanes")
  (assert (= 2 (proc/lanes)) "rejected scheduler leaves owner lanes intact")
  (assert (= 2 (length (scheduler :workers))) "one persistent worker per lane")
  (def worker-pids (map identity (scheduler :workers)))
  (each pid worker-pids
    (assert (tuple? pid) "worker identity is a pid tuple")
    (assert (= :pid (pid 0)) "worker pid tuple tag")
    # The routed proc/spawn return identifies the lane; self-pid is not used.
    (assert (<= 1 (pid 1) (proc/lanes)) "routed worker pid names a non-main lane"))
  (assert (not (= (get worker-pids 0) (get worker-pids 1))) "distinct workers")
  (assert (= 2 (length (scheduler :running))) "concurrency bound")
  (assert (= 2 (length (scheduler :pending))) "pending bound")
  (assert (= 2 ((get (scheduler :pending) 0) :sequence)) "priority queue order")
  (assert (= nil (async/submit scheduler 4 4 42)) "full queue returns nil")
  (assert (= 4 (scheduler :sequence)) "full queue does not consume sequence")
  (assert (= 2 (length (scheduler :running))) "full queue launches no worker")
  (assert (= 2 (length (scheduler :pending))) "full queue preserves pending requests")
  (def results (async/drain scheduler))
  (assert (= 4 (length results)) "all results delivered")
  (assert (deep= (map (fn [r] (r :sequence)) results) @[2 3 0 1]) "deterministic priority delivery")
  (each result results (check-result result))
  (assert (= 4 (async/submit scheduler 4 4 42)) "next accepted request keeps sequence")
  (assert (= 5 (async/submit scheduler 5 5 42)) "second batch uses both worker slots")
  (def second-batch (async/drain scheduler))
  (assert (= 2 (length second-batch)) "second batch delivers both results")
  (each result second-batch (check-result result))
  (assert (deep= worker-pids (scheduler :workers)) "same worker handles reused across batches")
  (async/teardown scheduler)
  (assert (= 2 (scheduler :quit-acks)) "each persistent worker acknowledged quit")
  (assert (= 0 (proc/lanes)) "teardown joins and stops worker lanes"))

# Reject lanes started by another owner, not only a second scheduler. Always
# release the test-owned lanes even if the assertion fails.
(proc/lanes-start 1)
(def preexisting-rejected
  (try (do (async/new {:concurrency 1}) false) ([e] true)))
(def preexisting-lanes (proc/lanes))
(proc/lanes-stop)
(assert preexisting-rejected "scheduler rejects externally started lanes")
(assert (= 1 preexisting-lanes) "rejection preserves external lane ownership")
(assert (= 0 (proc/lanes)) "external test lane is stopped")

# Invalid requests must fail before entering the queue or launching work.
(let [scheduler (async/new {:concurrency 1 :capacity 3 :fallback true})
      invalid [[1.5 0 1 0] [0 -2.5 1 0] [0 0 1.25 0]
               [0 0 1 2.5] ["0" 0 1 0] [0 nil 1 0]
               [0 0 "1" 0] [0 0 1 "2"]
               [0 0 1 math/inf] [0 0 math/nan 0]
               [134217728 0 1 0] [0 -134217729 1 0]
               [0 0 2147483648 0] [0 0 1 9007199254740992]]]
  (each request invalid
    (assert (not (try (do (apply async/submit scheduler request) true) ([e] false)))
            "invalid request rejected")
    (assert (= 0 (scheduler :sequence)) "invalid request consumes no sequence")
    (assert (= 0 (length (scheduler :running))) "invalid request launches no work")
    (assert (= 0 (length (scheduler :pending))) "invalid request is not queued"))
  (assert (= 0 (async/submit scheduler 0 0 1 0)) "valid request starts at zero")
  (check-result (get (async/drain scheduler) 0))
  (async/teardown scheduler))

(let [scheduler (async/new {:concurrency 1 :capacity 3})]
  (async/submit scheduler 0 0 1)
  (async/submit scheduler 1 0 1)
  (async/cancel scheduler)
  (async/submit scheduler -1 0 9)
  (def results (async/drain scheduler))
  (assert (= 1 (length results)) "stale generation discarded")
  (assert (= -1 ((get results 0) :cx)) "new generation survives")
  (check-result (get results 0))
  (async/teardown scheduler)
  (assert (= 0 (proc/lanes)) "teardown with outstanding worker leaves no lanes")
  (assert (scheduler :closed) "teardown closes scheduler")
  (assert (= 0 (length (scheduler :running))) "all handles rejoined")
  (assert (not (try (do (async/submit scheduler 0 0 1) true) ([e] false))) "closed rejects requests"))

# A lower-priority completion cannot pass a pending higher-ranked request.
# Keep this deterministic by using synchronous fallback and one execution slot.
(let [scheduler (async/new {:concurrency 1 :capacity 3 :fallback true})]
  (async/submit scheduler 0 0 1 0)
  (async/submit scheduler 1 0 1 9)
  (assert (= 0 (length (async/poll scheduler))) "low priority must wait across polls")
  (def results (async/poll scheduler))
  (assert (deep= (map (fn [r] (r :sequence)) results) @[1 0])
          "barrier releases priority order")
  (each result results (check-result result))
  (async/teardown scheduler))

# Block the sole worker with an observable running entry while cancellation
# invalidates it; the fresh request must stay pending until its reply is reaped.
(let [scheduler (async/new {:concurrency 1 :capacity 2})]
  (async/submit scheduler 0 0 1)
  (def stale (get (scheduler :running) 0))
  (async/cancel scheduler)
  (async/submit scheduler 1 0 1)
  (assert (= 1 (length (scheduler :running))) "stale request still owns the worker")
  (assert (= (stale :sequence) ((get (scheduler :running) 0) :sequence))
          "fresh request did not reuse busy worker")
  (assert (= 1 (length (scheduler :pending))) "fresh request waits for stale worker")
  (def fresh (async/drain scheduler))
  (assert (= 1 (length fresh)) "only fresh generation is delivered")
  (assert (= 1 ((get fresh 0) :cx)) "stale reply is discarded")
  (check-result (get fresh 0))
  (async/teardown scheduler))

# Shutdown must consume in-flight replies before quit acknowledgements, even when
# a queued request remains outstanding.
(let [scheduler (async/new {:concurrency 2 :capacity 4})]
  (async/submit scheduler 0 0 3)
  (async/submit scheduler 1 0 3)
  (async/submit scheduler 2 0 3)
  (assert (= 2 (length (scheduler :running))) "teardown begins with active jobs")
  (assert (= 1 (length (scheduler :pending))) "teardown begins with pending job")
  (async/teardown scheduler)
  (assert (scheduler :closed) "outstanding teardown closes scheduler")
  (assert (= 0 (length (scheduler :running))) "outstanding teardown receives every reply")
  (assert (= 0 (length (scheduler :pending))) "outstanding teardown clears pending jobs")
  (assert (= 2 (scheduler :quit-acks)) "outstanding teardown gets every quit acknowledgement")
  (assert (= 0 (proc/lanes)) "outstanding teardown leaves no lanes")
  (async/teardown scheduler)
  (assert (= 0 (proc/lanes)) "repeated teardown does not restart lanes"))

# Validation rejects bad public requests; mutate a private queued request after
# submission to exercise the worker's protected error-result path deterministically.
(let [scheduler (async/new {:concurrency 1 :capacity 2})]
  (async/submit scheduler 0 0 3)
  (def bad-sequence (async/submit scheduler 1 0 3))
  (put (get (scheduler :pending) 0) :seed "invalid-worker-seed")
  (def results (async/drain scheduler))
  (assert (= 2 (length results)) "worker error does not lose neighboring result")
  (def bad-result (get (filter (fn [r] (= (r :sequence) bad-sequence)) results) 0))
  (assert bad-result "malformed queued work returned a result")
  (assert (= :string (type (get (bad-result :result) :error)))
          "worker exception becomes a string error record")
  (check-result (get (filter (fn [r] (not (= (r :sequence) bad-sequence))) results) 0))
  (async/teardown scheduler)
  (assert (= 1 (scheduler :quit-acks)) "error does not prevent healthy worker quit")
  (assert (= 0 (proc/lanes)) "error test leaves no lanes"))

# Failed proc/send must complete with an error, not generate terrain on the caller.
(let [scheduler (async/new {:concurrency 1 :capacity 2})
      workers (scheduler :workers)
      real-pid (get workers 0)]
  (put workers 0 :invalid-pid)
  (def failed-sequence (async/submit scheduler 5 6 7))
  (put workers 0 real-pid)
  (assert (= 0 failed-sequence) "failed dispatch retains accepted sequence")
  (assert (= 0 (length (scheduler :running))) "failed dispatch has no running work")
  (assert (= 0 (length (scheduler :pending))) "failed dispatch has no pending work")
  (def results (async/drain scheduler))
  (assert (= 1 (length results)) "failed dispatch drains without waiting for a reply")
  (def failed (get results 0))
  (assert (= failed-sequence (failed :sequence)) "failed dispatch returns its request")
  (assert (= :string (type (get (failed :result) :error))) "failed dispatch returns string error")
  (assert (string/find "worldgen dispatch failed:" (get (failed :result) :error))
          "failed dispatch retains its error tag")
  (assert (not (get failed :sync)) "failed dispatch does not use synchronous fallback")
  (assert (not (get (failed :result) :blocks)) "failed dispatch generates no blocks")
  (assert (= 0 (length (async/poll scheduler))) "failed dispatch leaves no late result")
  (put workers 0 :invalid-pid)
  (async/submit scheduler 8 9 10)
  (put workers 0 real-pid)
  (async/cancel scheduler)
  (assert (= 0 (length (async/drain scheduler))) "cancel discards failed dispatch generation")
  (async/teardown scheduler)
  (assert (= 1 (scheduler :quit-acks)) "failed dispatch worker acknowledges quit")
  (assert (= 0 (proc/lanes)) "failed dispatch teardown joins lane"))

(let [scheduler (async/new {:concurrency 1 :fallback true})]
  (async/submit scheduler 5 6 7)
  (assert (= 0 (proc/lanes)) "explicit fallback starts no lanes")
  (assert (= 0 (length (scheduler :workers))) "explicit fallback starts no workers")
  (assert ((get (scheduler :running) 0) :sync) "explicit fallback uses no worker")
  (def results (async/poll scheduler))
  (assert (= 1 (length results)) "fallback polls")
  (check-result (get results 0))
  (async/teardown scheduler)
  (assert (= 0 (proc/lanes)) "fallback leaves lanes stopped"))

(print "async worldgen: ok")
