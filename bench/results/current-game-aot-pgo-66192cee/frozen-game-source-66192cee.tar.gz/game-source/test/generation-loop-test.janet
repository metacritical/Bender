# main's generation loop, driven headless against a REAL child process.
#
# The loop used to be untestable because it called raylib directly. `draw` and
# `cancel-pressed?` are now parameters, so this suite exercises the actual
# ownership, polling, cancellation and artifact handoff with a fake provider --
# no model, no GPU, no window.
#
# What it proves: one child is started, its PID is real, the loop reaps it on
# every path, a cancelled run leaves no artifact, and a zero exit with no artifact
# is a FAILURE rather than a success.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/generation-loop-test.janet


(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(import ../main :as game)
(def script "tools/fake-terrain-probe.py")
(def python "python3")

(def settings @{:size 32 :sea-level 28 :profile "alpine"})

(defn rm-folder [root]
  (each n (try (os/dir root) ([_] @[]))
    (try (os/rm (string root "/" n) true) ([_] nil))))

(defn fresh-root [tag]
  (def root (string "tmp/genloop-" tag "-" (os/getpid)))
  (when (os/stat root)
    (each n (try (os/dir root) ([_] @[]))
      (try (os/rm (string root "/" n) true) ([_] nil)))
    (try (os/rm root) ([_] nil)))
  (os/mkdir root)
  root)

#
# --- A successful run ---------------------------------------------------
#
(print "\nsuccess:")

(def ok-root (fresh-root "ok"))
(def saw-pids @[])
(def result
  (game/run-python-generation
    settings 4 ok-root script python
    # The draw hook is where a real frame would paint; here it records that the
    # loop actually ran one.
    (fn [view] (array/push saw-pids (get view :stage)))
    (fn [] false)))
(check "a complete artifact is reported as success"
       (and (table? result) (truthy? (result :ok))))
(check "the result carries the identity directory, not the out-root"
       (and (string? (result :out))
            (not= ok-root (result :out))))
(check "the identity directory name is 64 hex characters"
       (= 64 (length (last (string/split "/" (result :out))))))
(check "the metadata is the catalogue's own inspection"
       (let [m (result :metadata)]
         (and (or (table? m) (struct? m))
              (string? (get m :identity))
              (pos? (length (get m :identity))))))
(check "the artifact directory really exists"
       (truthy? (os/stat (result :out))))
(check "the READY marker is present in the artifact"
       (truthy? (os/stat (string (result :out) "/READY"))))
(check "the loop drew at least one frame"
       (pos? (length saw-pids)))

#
# --- A zero exit with no artifact is a FAILURE --------------------------
#
(print "\nno artifact:")

# This is the case that matters most: a process can exit 0 and still produce
# nothing. Reporting success there would hand the game an empty world.
(def empty-root (fresh-root "empty"))
# A provider that exits 0 WITHOUT writing anything. This is the case that matters
# most: a process can succeed and still produce nothing, and reporting success
# there would hand the game an empty world.
# `--mode empty` is appended by passing a shell-free wrapper: the loop takes an
# argv built from the script path, so a distinct script name is used instead of an
# environment variable -- this Janet has no setenv.
(def empty-script "tools/fake-empty-probe.sh")
(def empty-result
  (game/run-python-generation
    settings 4 empty-root empty-script python
    (fn [_] nil)
    (fn [] false)))
(check "a run with no artifact is not a success"
       (not (and (or (table? empty-result) (struct? empty-result))
                 (empty-result :ok))))
(check "and it reports why"
       (let [r (if (or (table? empty-result) (struct? empty-result))
                 (empty-result :error) (get empty-result 1))]
         (and (string? r) (pos? (length r)))))

#
# --- Failure ------------------------------------------------------------
#
(print "\nfailure:")

(def fail-root (fresh-root "fail"))
# A script path that does not exist is the cheapest real failure: spawn fails.
(def fail-result
  (game/run-python-generation
    settings 4 fail-root "tools/no-such-provider.py" python
    (fn [_] nil)
    (fn [] false)))
(check "an unspawnable provider is reported as failure"
       (not (and (table? fail-result) (fail-result :ok))))
(check "the failure carries a reason"
       (let [r (if (table? fail-result) (fail-result :error) (get fail-result 1))]
         (and (string? r) (pos? (length r)))))

#
# --- Cancellation -------------------------------------------------------
#
(print "\ncancel:")

# A hanging provider cancelled on the first poll. The loop must run the cancel,
# keep polling until the child is reaped, and report cancellation -- not success,
# and not a crash.
(def hang-root (fresh-root "hang"))
(def cancel-result
  (game/run-python-generation
    settings 4 hang-root script python
    (fn [_] nil)
    (fn [] true)))
(check "a cancel is reported as cancelled"
       (and (indexed? cancel-result) (= :cancelled (get cancel-result 0))))
(check "no artifact is left behind by a cancelled run"
       (let [entries (filter |(not (string/find "stage.janet" $))
                             (try (os/dir hang-root) ([_] @[])))]
         (zero? (length entries))))

#
# --- Result -------------------------------------------------------------
#
(if (zero? failures)
  (print "\ngeneration loop: ALL CHECKS PASSED")
  (do (printf "\ngeneration loop: %d FAILED" failures) (os/exit 1)))
