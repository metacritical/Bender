# Standalone, headless palette packing contract tests.
(import ../src/palette :as palette)
(import ../src/world :as world)
(import ../src/worldgen :as worldgen)

(defn as-buffer [values]
  (let [out (buffer/new-filled (length values) 0)]
    (for i 0 (length values) (put out i (get values i)))
    out))

(defn check [name blocks expected-bits expected-palette]
  (let [packed (palette/pack blocks)
        decoded (palette/unpack packed)
        per-byte (/ 8 expected-bits)
        data-length (math/ceil (/ (length blocks) per-byte))]
    (assert (= expected-bits (get packed :bits)))
    (assert (= (length expected-palette) (length (get packed :palette))))
    (for i 0 (length expected-palette)
      (assert (= (get expected-palette i) (get (get packed :palette) i))))
    (assert (= (length blocks) (get packed :count)))
    (assert (= data-length (length (get packed :data))))
    (assert (= (+ (length expected-palette) data-length)
               (palette/packed-bytes packed)))
    (assert (= (/ (length blocks) (palette/packed-bytes packed))
               (palette/compression-ratio packed)))
    (assert (= (length blocks) (length decoded)))
    (for i 0 (length blocks) (assert (= (get blocks i) (get decoded i))))
    (when (> (length decoded) 0)
      (let [old (get blocks 0)]
        (put decoded 0 (mod (+ old 1) 256))
        (assert (= old (get blocks 0)))))
    (let [again (palette/pack blocks)]
      (assert (= (get packed :bits) (get again :bits)))
      (for i 0 (length (get packed :palette))
        (assert (= (get (get packed :palette) i)
                   (get (get again :palette) i))))
      (for i 0 (length (get packed :data))
        (assert (= (get (get packed :data) i)
                   (get (get again :data) i)))))
    (print name ": pass (" (palette/packed-bytes packed)
           " bytes, " (palette/compression-ratio packed) "x)")))

(check "all air" (buffer/new-filled world/chunk-volume world/block-air)
       1 @[world/block-air])
(check "uniform stone" (buffer/new-filled world/chunk-volume world/block-stone)
       1 @[world/block-stone])
(check "two colors" (as-buffer @[7 0 7 0 7 0 7 0 7]) 1 @[7 0])
(check "five colors" (as-buffer @[4 2 3 1 0 4 2 3 1 0 4])
       4 @[4 2 3 1 0])
(check "sixteen colors" (as-buffer (range 16)) 4 (range 16))
(check "all eight blocks" (as-buffer (range 8)) 4 (range 8))
(check "maximum diversity" (as-buffer (range 256)) 8 (range 256))
(check "three colors" (as-buffer @[0 1 2 2 1 0 2]) 2 @[0 1 2])
(check "four colors" (as-buffer @[0 1 2 3]) 2 @[0 1 2 3])
(check "seventeen colors" (as-buffer (range 17)) 8 (range 17))

# Explicit byte layout verifies index order across byte boundaries.
(let [packed (palette/pack (as-buffer @[7 0 7 0 0 7 0 7 7]))]
  (assert (= 0x5A (get (get packed :data) 0)))
  (assert (= 0 (get (get packed :data) 1))))
(let [packed (palette/pack (as-buffer @[0 1 2 3 3 2 1 0]))]
  (assert (= 0xE4 (get (get packed :data) 0)))
  (assert (= 0x1B (get (get packed :data) 1))))
(let [packed (palette/pack (as-buffer (range 16)))]
  (assert (= 0x10 (get (get packed :data) 0)))
  (assert (= 0xFE (get (get packed :data) 7))))
(print "low-bit-first byte layout: pass")

(let [ch (worldgen/generate-chunk (world/world-new) 2 -3 42)]
  (let [packed (palette/pack (get ch :blocks))
        decoded (palette/unpack packed)]
    (for i 0 world/chunk-volume
      (assert (= (get (get ch :blocks) i) (get decoded i))))
    (assert (> (palette/compression-ratio packed) 1))
    (print "worldgen realistic compression: "
           (palette/packed-bytes packed) " bytes, "
           (palette/compression-ratio packed) "x")))
(print "palette tests: pass")
