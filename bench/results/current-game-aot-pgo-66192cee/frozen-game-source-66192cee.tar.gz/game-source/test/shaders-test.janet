# Source-contract checks only: importing shaders never opens a game window.
(import ../src/shaders :as shaders)

(def terrain shaders/chunk-fragment-shader)
(def water shaders/water-fragment-shader)

(defn contains [source snippet]
  (not (nil? (string/find snippet source))))

# Ambient controls the baseline; the sun cannot create a fixed night floor.
(assert (contains terrain "vec3 light = ambientColor + (1.0 - ambientColor) * sunColor * lambert;"))
(assert (not (contains terrain "0.5 + 0.5 * lambert")))
(assert (contains terrain "vec3 lit = texel.rgb * colDiffuse.rgb * fragColor.rgb * light;"))

# Water follows the same atmospheric inputs rather than inventing light.
(assert (contains water "* sunColor * lambert"))
(assert (not (contains water "0.45 + 0.55 * lambert")))
(assert (contains water "mix(lit, fogColor, fresnel * waterFresnelStrength * fragColor.g)"))
(assert (contains water "col = mix(col, fogColor, clamp(f, 0.0, 1.0));"))
(assert (contains water "* fragColor.g * detailFade * step(0.0, dot(n, sunDir))"))
(assert (contains water "col += ambientColor * vec3(0.05, 0.09, 0.10)"))
(assert (contains water "vec3(r, 0.0, r)"))
(assert (contains water "waterSpecularPower"))
(assert (contains water "waterAlphaCap"))
(assert (contains terrain "causticStrength"))

# Underwater attenuation retains near-field shapes and a translucent surface.
(assert (contains terrain "lit *= mix(vec3(1.0), absorb, t);"))
(assert (contains terrain "lit  = mix(lit, vec3(0.03, 0.17, 0.26), t * underwaterTintStrength);"))
(assert (contains water "if (underwater > 0.5) alpha = min(alpha, 0.55);"))
(print "shader night lighting: passed")
