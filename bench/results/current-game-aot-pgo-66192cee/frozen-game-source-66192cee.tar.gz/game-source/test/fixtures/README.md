# Frozen conditioning table fixture

`pipeline_data.json` is the **official** frozen conditioning table, copied byte
for byte from the pinned revision:

```
repo      xandergos/terrain-diffusion-30m-onnx
revision  ad2df557eca5645f588766101cf3bc3682455c3e
path      pipeline_data.json
size      12226 bytes
sha256    e3132c3ef0c65d8613615f9278ffe23bbd9363ddcd87f1cc6f18456bcc9efe5c
```

Its canonical digest (sorted keys, compact separators, no trailing newline) is
`528754ea8203928364cccd931686ec87612b1eefba44ef7956293f33a68bdbe3`, which is
the `OFFICIAL_STATS_SHA256` constant in `tools/terrain_backend.py` and the
`stats_sha256` every real cache carries.

It is committed so the test suite can exercise the official-table pin without a
network call and without skipping: a test that skips is a test that proves
nothing about the pin. Tests that need to prove *rejection* mutate a copy in a
temporary directory or pass a fixture digest, and those tests are labelled as
fixtures rather than as production behaviour.

Source repository `xandergos/terrain-diffusion-30m-onnx` is MIT licensed; this
file is redistributed unmodified under the same licence.
