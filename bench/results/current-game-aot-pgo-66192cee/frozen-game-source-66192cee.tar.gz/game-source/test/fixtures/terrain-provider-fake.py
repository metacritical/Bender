#!/usr/bin/env python3
"""TEST-FAKE terrain provider: a hermetic stand-in for `tools/terrain_new_game.py`.

WHY THIS EXISTS
---------------
The game's New Game path runs one owned Python process and then validates the
artifact it produced. To test that path end to end (success, refusal,
cancellation, QA screenshots) without a GPU, a model, weights or the pinned
upstream checkout, the process must still produce a REAL, valid TDS3 artifact --
one the shipping Janet reader accepts.

This fixture therefore does NOT invent a file format. It calls the same
production building blocks the real provider calls, in the same order:

    scenic_terrain.export_raw     -> unquantized float32 elevation + provenance
    scenic_terrain.import_raw     -> the TDS3 tiles, manifest.json and the
                                     Janet twin the game actually reads
    terrain_new_game.verify_artifact -> re-read and validate what was written
    terrain_new_game.write_ready  -> the READY flag, last, via atomic rename

Only two things are substituted, and both are named in the artifact:

  * the SAMPLER: a closed-form synthetic field instead of model inference
  * the model-pin checks: the identity is a FIXED, PINNED synthetic descriptor
    rather than one derived by digesting weights and an upstream checkout

WHAT IS DIFFERENT FROM A REAL ARTIFACT
--------------------------------------
The artifact is labelled, at three independent points, so it can never be
mistaken for a real generation:

  * this docstring and the module name both say TEST-FAKE
  * the provenance record carries `"label": "TESTFAKE"` and
    `"model_weights_present": "not-sampled"`
  * `<out>/TESTFAKE_PROVENANCE` is written in the OUTPUT ROOT, never inside the
    identity directory. The shipping catalogue requires exactly six entries in
    an identity directory (manifest.janet, manifest.json, provenance.json,
    summary.json, READY, tiles) and rejects anything else, so a marker in there
    would make a valid artifact unloadable. The output root is the caller's
    staging area, not part of the artifact contract.

The tile bytes, manifest key set, band, CRC and READY contract are all real, so
the game's validation is genuinely exercised. That is the point: a fake that
validated differently would prove nothing about the real path.

USAGE
-----
    terrain-provider-fake.py --out DIR --seed N [--size N] [--progress PATH]
                             [--check] [--fake-label] ...

`--check` reports readiness and exits 0 WITHOUT writing an output directory or a
progress sidecar, matching the real CLI's contract.

Behaviour is selected by the environment so that no test-only flag leaks into
the production argparse surface the game speaks:

    TC_FAKE_PROVIDER_MODE=success  (default) write a valid artifact
    TC_FAKE_PROVIDER_MODE=fail     exit 1 without a valid artifact
    TC_FAKE_PROVIDER_MODE=partial  write tiles, then exit 1 WITHOUT READY
    TC_FAKE_PROVIDER_MODE=sleep    sleep up to TC_FAKE_PROVIDER_SLEEP seconds
                                   (max 2.0), then exit 1 -- never hangs

Exit codes: 0 success, 1 provider error, 130 cancelled (SIGTERM/SIGINT).

NO MODEL IS EVER LOADED. No network. No GPU. numpy is the only requirement, and
it is already a dependency of the production exporter.
"""

from __future__ import annotations

import argparse
import json
import os
import signal
import sys
import math

_HERE = os.path.dirname(os.path.abspath(__file__))
_TOOLS = os.path.abspath(os.path.join(_HERE, "..", "..", "tools"))
if _TOOLS not in sys.path:
    sys.path.insert(0, _TOOLS)

import scenic_terrain as st          # noqa: E402
import terrain_cache as tc           # noqa: E402
import terrain_new_game as ng        # noqa: E402

# ---------------------------------------------------------------------------
# Fixed, pinned synthetic identity: no weight digests, no upstream checkout.
# ---------------------------------------------------------------------------

FAKE_IDENTITY = {
    "model": "TESTFAKE-synthetic-terrain",
    "model_revision": "0" * 40,
    "upstream_revision": "0" * 40,
    "source_sha256": "0" * 64,
    "config_sha256": "0" * 64,
    "configs_sha256": "0" * 64,
    "weights_sha256": "0" * 64,
    "stats_sha256": "0" * 64,
    "conditioning_version": 1,
    "dtype": "fp32",
    "device": "cpu",
    "pixels_per_voxel": 1,
    "sampler": {"name": "test-fake-ramp", "steps": 0},
    "mapping": {"version": 1, "meters_per_voxel": 25.0, "sea_level": 28},
    "query": {"size": 128},
}

MODE_ENV = "TC_FAKE_PROVIDER_MODE"
SLEEP_ENV = "TC_FAKE_PROVIDER_SLEEP"
MAX_SLEEP = 2.0            # a fake must never hang a CI job
PROVENANCE_LABEL = "TESTFAKE"


class Cancelled(Exception):
    pass


def _install_signals():
    def handler(_signum, _frame):
        raise Cancelled()
    for name in ("SIGTERM", "SIGINT"):
        sig = getattr(signal, name, None)
        if sig is not None:
            try:
                signal.signal(sig, handler)
            except (ValueError, OSError):
                pass


def synthetic_elevation(size, *, low=850.0, high=1600.0):
    """Closed-form metres: deterministic, finite, no model, no randomness.

    A pure function of the pixel coordinate, mirroring the shape of the
    production fake pipeline used by test/test_terrain_new_game.py.
    """
    span = float(high - low)
    return [
        [low + span * (((x * 7) + (z * 3)) % 97) / 96.0 for x in range(size)]
        for z in range(size)
    ]


def build_parser():
    p = argparse.ArgumentParser(
        prog="terrain-provider-fake",
        description="TEST-FAKE terrain provider; produces a real TDS3 artifact "
                    "with a synthetic sampler and no model.")
    p.add_argument("--out", default=None,
                   help="output cache root; required unless --check")
    p.add_argument("--check", action="store_true",
                   help="report readiness and exit without generating anything")
    p.add_argument("--json", action="store_true", help="machine-readable --check")
    p.add_argument("--seed", type=int, default=ng.DEFAULT_SEED)
    p.add_argument("--size", type=int, default=ng.DEFAULT_SIZE)
    p.add_argument("--sea-level", type=int, default=ng.DEFAULT_SEA_LEVEL)
    p.add_argument("--profile", default=ng.DEFAULT_PROFILE)
    p.add_argument("--origin-x", type=int, default=ng.DEFAULT_ORIGIN[0])
    p.add_argument("--origin-z", type=int, default=ng.DEFAULT_ORIGIN[1])
    p.add_argument("--meters-per-voxel", type=float,
                   default=ng.DEFAULT_METERS_PER_VOXEL)
    p.add_argument("--world-origin-x", type=int, default=ng.DEFAULT_WORLD_ORIGIN[0])
    p.add_argument("--world-origin-z", type=int, default=ng.DEFAULT_WORLD_ORIGIN[1])
    p.add_argument("--progress", default=None,
                   help="inert Janet progress sidecar written here")
    # Accepted for CLI parity with the real provider so a caller cannot depend
    # on a flag this stand-in silently lacks. They are recorded, not used.
    p.add_argument("--device", default="cpu")
    p.add_argument("--dtype", default="fp32")
    p.add_argument("--snapshot", default=None)
    p.add_argument("--upstream", default=None)
    p.add_argument("--stats-json", default=None)
    p.add_argument("--fake-label", action="store_true",
                   help="write out/TESTFAKE_PROVENANCE (default on; kept for parity)")
    return p


def emit_progress(path, stage, **detail):
    """Write one inert Janet progress record via the real renderer."""
    if not path:
        return
    try:
        ng.write_progress(path, stage=stage,
                          completed=detail.get("completed"),
                          total=detail.get("total"),
                          message=detail.get("message"))
    except Exception:
        # Progress is advisory; a write failure must not fail generation.
        pass


def report_check(args):
    """Readiness without touching the filesystem. Exit 0 when we can generate."""
    problems = []
    try:
        import numpy  # noqa: F401
    except Exception as exc:  # noqa: BLE001
        problems.append("numpy unavailable: %s" % exc)
    if args.size < 16 or args.size % 16:
        problems.append("--size must be a positive multiple of 16 for tiles")
    payload = {"ready": not problems, "provider": "TESTFAKE",
               "label": PROVENANCE_LABEL, "temporary": True,
               "python_executable": sys.executable,
               "problems": problems}
    if args.json:
        sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    else:
        sys.stdout.write("TESTFAKE terraform provider: %s\n"
                         % ("ready" if not problems else "unavailable"))
        for problem in problems:
            sys.stdout.write("  - %s\n" % problem)
    return 0 if not problems else 1


def generate(args):
    mode = os.environ.get(MODE_ENV, "success").strip().lower()
    if mode not in ("success", "fail", "partial", "sleep"):
        sys.stderr.write("fake provider: unknown %s=%r\n" % (MODE_ENV, mode))
        return 1

    if mode == "sleep":
        try:
            seconds = float(os.environ.get(SLEEP_ENV, "2"))
        except ValueError:
            seconds = MAX_SLEEP
        seconds = max(0.0, min(MAX_SLEEP, seconds))
        emit_progress(args.progress, "load", message="sleeping %.1fs" % seconds)
        import time
        deadline = time.time() + seconds
        while time.time() < deadline:
            time.sleep(0.02)
        sys.stderr.write("fake provider: sleep mode finished, no artifact\n")
        return 1

    if mode == "fail":
        emit_progress(args.progress, "resolve", message="deliberate failure")
        sys.stderr.write("fake provider: deliberate failure before sampling\n")
        return 1

    out = args.out
    if not out:
        sys.stderr.write("fake provider: --out is required to generate\n")
        return 1

    # Refuse a non-empty root exactly as the real provider does, tolerating this
    # run's own progress sidecar when the caller put it inside the root.
    out = ng.prepare_output(out, progress_path=args.progress)

    emit_progress(args.progress, "resolve", completed=0, total=4)
    elevation = synthetic_elevation(args.size)

    raw_path = os.path.join(out, "raw_export.npz")
    provenance = {
        "provider": "python-terrain-diffusion",
        "provider_version": 1,
        "temporary": True,
        "label": PROVENANCE_LABEL,
        "model_weights_present": "not-sampled",
        "not_model_output": True,
        "fixture": "test/fixtures/terrain-provider-fake.py",
        "model": FAKE_IDENTITY["model"],
        "model_revision": FAKE_IDENTITY["model_revision"],
        "upstream_revision": FAKE_IDENTITY["upstream_revision"],
        # The world seed the player chose. For seed 0 the artifact's own seed is
        # the mapped model seed, so both are recorded rather than one guessed.
        "world_seed": args.seed,
        "seed_mapping": "nonzero-v1",
        "size": args.size,
        "origin": [args.origin_x, args.origin_z],
        "profile": args.profile,
        "sea_level": args.sea_level,
        "meters_per_voxel": args.meters_per_voxel,
    }
    # The artifact's seed is the MODEL seed. The backend rejects 0, so map it the
    # same way the real provider does rather than writing a seed readers reject.
    model_seed = args.seed if args.seed != 0 else 2147483647
    st.export_raw(raw_path, elevation,
                  origin_pixels=(args.origin_x, args.origin_z),
                  seed=model_seed,
                  pixels_per_voxel=1,
                  provenance=provenance)
    emit_progress(args.progress, "sample", completed=2, total=4)

    summary = st.import_raw(
        raw_path, out,
        meters_per_voxel=args.meters_per_voxel,
        sea_level=args.sea_level,
        profile=args.profile,
        world_origin_voxels=(args.world_origin_x, args.world_origin_z))
    emit_progress(args.progress, "export", completed=3, total=4)

    if mode == "partial":
        # Tiles exist and are self-consistent, but READY never appears. This is
        # the interrupted-publication case the game must treat as failure.
        sys.stderr.write("fake provider: partial mode, no READY written\n")
        return 1

    verified = ng.verify_artifact(out, summary["identity"])
    emit_progress(args.progress, "verify-artifact", completed=4, total=4)

    # The marker goes in the OUTPUT ROOT, not the identity directory: the
    # catalogue accepts exactly six names inside that directory and would reject
    # the artifact as "files incomplete or unexpected".
    with open(os.path.join(out, "TESTFAKE_PROVENANCE"), "w") as handle:
        handle.write("label=%s\n" % PROVENANCE_LABEL)
        handle.write("sampler=test-fake-ramp\n")
        handle.write("model_weights_present=not-sampled\n")
        handle.write("not_model_output=true\n")
        handle.write("fixture=test/fixtures/terrain-provider-fake.py\n")

    ready = ng.write_ready(out, summary, verified)
    emit_progress(args.progress, "ready", message=str(ready))
    sys.stdout.write("%s_PROVENANCE identity=%s tiles=%s seed=%s\n"
                     % (PROVENANCE_LABEL, summary["identity"],
                        summary["tiles"], model_seed))
    sys.stdout.flush()
    return 0


def main(argv=None):
    args = build_parser().parse_args(argv)
    _install_signals()
    if args.check:
        return report_check(args)
    try:
        return generate(args)
    except Cancelled:
        sys.stderr.write("fake provider: cancelled\n")
        return 130
    except BaseException as exc:  # noqa: BLE001
        sys.stderr.write("fake provider: %s: %s\n" % (type(exc).__name__, exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
