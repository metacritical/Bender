# Standalone POSIX integration smoke test. Run only after generation-job fixes land:
#   JANET_NO_PROFILE=1 /path/to/build/bender test/generation-job-smoke.janet
# Uses exactly two direct, lightweight /bin/sleep children, sequentially. Never
# runs a game, Python, model, shell, native build, or detached process.
(import ../src/generation-job :as job)

(defn now [] (os/clock :monotonic))
(defn tick-until [active expected deadline]
  (var state (job/poll active))
  (while (and (not= (state :phase) expected) (< (now) deadline))
    (assert (or (= (state :phase) :running)
                (= (state :phase) :cancelling))
            (string "job failed before " expected ": " (state :error)))
    (os/sleep 0.005)
    (set state (job/poll active)))
  (assert (= (state :phase) expected)
          (string "timed out awaiting " expected "; owned PID " (state :pid)))
  state)

# A successful child runs long enough to demonstrate a frame poll does not
# wait for process exit. Every spawned PID is printed immediately for auditing.
(def success-slot @{:job nil})
(def success (job/start "POSIX heartbeat" @["/bin/sleep" "0.3"]
                        {:slot success-slot :validate (fn [j] true)}))
(assert (= :running (success :phase)) "sleep child must start")
(printf "generation smoke success PID=%v\n" (success :pid))
(assert (and (number? (success :pid)) (> (success :pid) 0)) "owned PID required")
(def before (now))
(def heartbeat (job/poll success))
(assert (< (- (now) before) 0.1) "one GUI-frame poll must not wait for child")
(assert (= :running (heartbeat :phase)) "heartbeat precedes child exit")
(def finished (tick-until success :succeeded (+ (now) 3)))
(assert (= 0 (finished :exit-code)) "watcher must record zero exit")
(assert (= nil (success-slot :job)) "reaped success must release ownership slot")

# A second child would otherwise live five seconds. TERM is requested once;
# repeated frame polls collect its one watcher, without blocking a frame.
(def cancel-slot @{:job nil})
(def active (job/start "POSIX cancellation" @["/bin/sleep" "5"]
                       {:slot cancel-slot :validate (fn [j] true)}))
(assert (= :running (active :phase)) "cancellation child must start")
(printf "generation smoke cancellation PID=%v\n" (active :pid))
(assert (and (number? (active :pid)) (> (active :pid) 0)) "owned PID required")
(def cancel-start (now))
(def cancelling (job/cancel active))
(assert (< (- (now) cancel-start) 0.1) "cancel must not wait on GUI frame")
(assert (= :cancelling (cancelling :phase)) "TERM enters cancelling state")
(assert (= active (cancel-slot :job)) "slot retained until child is reaped")
(def cancelled (tick-until active :cancelled (+ (now) 7)))
(assert (number? (cancelled :exit-code)) "watcher must record cancellation exit")
(assert (= nil (cancel-slot :job)) "reaped cancellation must release slot")
(assert (= :cancelled ((job/close active) :phase)) "close after reap is idempotent")
(printf "generation smoke: two owned children reaped; PIDs=%v,%v\n"
        (success :pid) (active :pid))
