# Terrain identity sidecar: opaque digest, CRC pairing, load gate.
#
# Independent of world/, worldgen/, region/ and terrain-cache/ on purpose, but
# it does use the shared `src/terrain-integrity.janet` CRC-32, because the whole
# point of the sidecar's pairing is that both sides compute the same checksum
# with the same code. `crc32` takes bytes, so the sidecar API stays a plain
# integer parameter and never re-reads the region file itself.
(import ../src/terrain-integrity :as integrity)
(import ../src/terrain-identity :as ti)

(def root "/tmp/trinecraft-terrain-identity")
(def region (string root "/region.trcr"))
(defn clear []
  (try (os/rm region) ([e] nil))
  (try (os/rm (ti/sidecar-path region)) ([e] nil)))
(defn rejects? [f] (try (do (f) false) ([_] true)))
(defn assert-error [f fragment]
  (def message (try (do (f) nil) ([e] (string e))))
  (assert message (string "expected an error mentioning " fragment))
  (assert (not (nil? (string/find fragment message)))
          (string "expected \"" fragment "\" in: " message)))
(defn crc-of-region []
  "The CRC a caller supplies: computed from the bytes the region has NOW."
  (integrity/crc32 (string (file/read (file/open region :rb) :all))))
(defn write-region [text]
  (def f (file/open region :wbn))
  (file/write f text)
  (file/close f))
(defn write-sidecar [text]
  (def f (file/open (ti/sidecar-path region) :wbn))
  (file/write f text)
  (file/close f))

(clear)
(os/mkdir root)

#
# --- Composition with the shared integrity helper ----------------------
#

# The sidecar takes a CRC integer, so prove the value the caller would supply
# from the real helper round-trips through the sidecar and the gate.
(assert (= 0 (integrity/crc32 "")))
(assert (= "cbf43926" (integrity/crc32-hex "123456789")))
(assert (= "414fa339" (integrity/crc32-hex "The quick brown fox jumps over the lazy dog")))
(assert (= 0 (integrity/crc32 (buffer/new 0))))
(assert (= (integrity/crc32 "abc") (integrity/crc32 (buffer "abc")))
        "buffer and string bytes must checksum identically")
(print "integrity helper vectors: passed")

(def digest-a "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef")
(def digest-b "fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210")
(def noise (ti/noise-identity 4))
(def diffusion (ti/diffusion-identity digest-a 1234))

(each invalid-crc [-1 4294967296 0.5 (math/pow 10 309)]
  (assert (rejects? (fn [] (ti/format-sidecar noise invalid-crc)))))
(each valid-crc [0 2147483648 4294967295]
  (assert (string? (ti/format-sidecar noise valid-crc))))
(assert (rejects? (fn [] (ti/noise-identity (math/pow 10 309)))))

#
# --- Opaque identity ----------------------------------------------------
#

(assert (= "noise:v2h256:4" (ti/identity-string noise)))
(assert (= (string "diffusion:h256:" digest-a ":1234") (ti/identity-string diffusion)))
(assert (ti/compatible? noise (ti/noise-identity 4)))
(assert (= :v2h256 (noise :profile)))
(assert (= 256 (noise :height)))
(assert (= 65536 (noise :volume)))
(assert-error (fn [] (ti/identity-string {:version 1 :generation :noise :seed 4})) "legacy identity")
(assert-error (fn [] (ti/identity-string {:version 2 :generation :noise :seed 4 :profile :v1h64 :height 64 :volume 16384})) "height/volume")
(assert-error (fn [] (ti/identity-string {:version 2 :generation :noise :seed 4 :profile :v1h64 :height 256 :volume 65536})) "profile")
(assert (not (ti/compatible? noise (ti/noise-identity 5))))
(assert (not (ti/compatible? noise diffusion)))
(assert (not (ti/compatible? diffusion (ti/diffusion-identity digest-b 1234))))
(assert (not (ti/compatible? diffusion (ti/diffusion-identity digest-a 1235)))
        "same digest with a different seed is a different world")
(assert (= "noise:v2h256:4" (ti/describe noise)))
# The digest is opaque: any 64 lowercase hex string is accepted verbatim, and
# this module never re-derives or truncates it.
(assert (= digest-b ((ti/diffusion-identity digest-b 1) :digest)))
(assert-error (fn [] (ti/diffusion-identity "short" 1)) "64 lowercase hex")
(assert-error (fn [] (ti/diffusion-identity (string/ascii-upper digest-a) 1)) "64 lowercase hex")
(assert-error (fn [] (ti/diffusion-identity (string digest-a "0") 1)) "64 lowercase hex")
(assert-error (fn [] (ti/diffusion-identity digest-a 1.5)) "must be an integer")
(assert-error (fn [] (ti/noise-identity "4")) "must be an integer")
(assert-error (fn [] (ti/identity-string @{:version 2 :height 256 :volume 65536 :generation :villages})) "must name :generation")
(print "opaque identity: passed")

# Frozen and immutable: a validated identity cannot be edited after the fact.
(assert (rejects? (fn [] (put diffusion :digest digest-b))))
(assert (= digest-a (diffusion :digest)))
(print "identity immutability: passed")

#
# --- Paths --------------------------------------------------------------
#

(assert (= "/tmp/w.trcr.terrain.janet" (ti/sidecar-path "/tmp/w.trcr")))
(assert (= "world.trcr.terrain.janet" (ti/sidecar-path "world.trcr")))
(assert (rejects? (fn [] (ti/sidecar-path nil))))
(print "sidecar path: passed")

#
# --- Absent -------------------------------------------------------------
#

(clear)
(def absent (ti/read region))
(assert (= :absent (absent :status)))
(assert (nil? (absent :identity)))
# A gate must never call that a match.
(assert (= :unverifiable ((ti/gate region noise) :status)))
# And a diffusion session may not adopt unknown provenance at all.
(assert (= :mismatch ((ti/gate region diffusion) :status)))
(assert (not (ti/loadable? region diffusion)))
(assert (ti/loadable? region noise))
(print "absent sidecar: passed")

#
# --- Round trip ---------------------------------------------------------
#

(write-region "REGION-BYTES")
(def region-crc (integrity/crc32 (string "REGION-BYTES")))
(def other-crc (integrity/crc32 (string "DIFFERENT-BYTES")))
(assert (not= region-crc other-crc))
(ti/write-atomic region diffusion region-crc)
(def present (ti/read region region-crc))
(assert (= :present (present :status)))
(assert (= (ti/identity-string diffusion) (ti/identity-string (present :identity))))
(assert (= :match ((ti/gate region diffusion region-crc) :status)))
(assert (ti/loadable? region diffusion region-crc))
# A CRC of different bytes means the sidecar describes another region: stale.
(assert (= :stale ((ti/read region other-crc) :status)))
(assert (= :stale ((ti/gate region diffusion other-crc) :status)))
(assert (not (ti/loadable? region diffusion other-crc)))
# Rewriting the region genuinely changes the CRC a caller computes from it,
# which is the corruption case the pairing exists to catch.
(write-region "OTHER-BYTES-ENTIRELY")
(assert (not= region-crc (crc-of-region)))
(assert (= :stale ((ti/gate region diffusion (crc-of-region)) :status)))
(assert (not (ti/loadable? region diffusion (crc-of-region))))
(write-region "REGION-BYTES")
(assert (= region-crc (crc-of-region)) "restoring the bytes restores the pairing")
# A missing CRC cannot confirm the pairing either.
(assert (= :stale ((ti/read region) :status)))
# No temp residue after a successful publish.
(assert (= 0 (length (filter |(string/find "terrain.janet.tmp" $) (os/dir root)))))
(print "write then read: passed")

#
# --- Exact keys and values ---------------------------------------------
#

(defn bad [text fragment]
  (write-sidecar text)
  (assert-error (fn [] (ti/read region 111)) fragment))
(bad "{:version 2 :generation :noise :seed 4 :height 256 :volume 65536 :profile :v2h256}" ":region-crc")
(bad "{:version 99 :generation :noise :seed 4 :height 256 :volume 65536 :profile :v2h256 :region-crc 111}" ":version")
(bad "{:version 1 :generation :noise :seed 4 :region-crc 111}" ":version")
(bad "{:version 2 :generation :villages :seed 4 :height 256 :volume 65536 :region-crc 111}" ":generation")
(bad "{:version 2 :generation :noise :seed 4 :height 256 :volume 65536 :profile :v2h256 :region-crc 111 :model \"m\"}" "unknown key")
(bad "{:version 2 :generation :noise :seed 4.5 :height 256 :volume 65536 :profile :v2h256 :region-crc 111}" ":seed")
(bad "{:version 2 :generation :noise :seed 4 :height 256 :volume 65536 :profile :v2h256 :digest \"x\" :region-crc 111}" "must not carry :digest")
(bad "{:version 2 :generation :noise :seed 4 :height 256 :volume 65536 :profile :v2h256 :settings-identity \"procedural:v1:h256:custom\" :region-crc 111}" "must not carry :settings-identity")
(bad (string "{:version 2 :generation :diffusion :digest \"" digest-a "\" :seed 4 :height 256 :volume 65536 :settings-identity \"procedural:v1:h256:custom\" :region-crc 111}") "must not carry :settings-identity")
(bad "{:version 2 :generation :procedural :seed 4 :height 256 :volume 65536 :profile :v2h256 :region-crc 111}" "settings identity")
(bad "{:version 2 :generation :noise :seed 4 :height 64 :volume 16384 :profile :v2h256 :region-crc 111}" ":height/:volume")
(bad "{:version 2 :generation :noise :seed 4 :height 256 :volume 65536 :region-crc 111}" ":profile")
(bad "{:version 2 :generation :noise :seed 4 :height 256 :volume 65536 :profile :v1h64 :region-crc 111}" ":profile")
(bad "{:version 2 :generation :diffusion :seed 4 :height 256 :volume 65536 :region-crc 111}" ":digest")
(bad "{:version 2 :generation :diffusion :digest \"nope\" :seed 4 :height 256 :volume 65536 :region-crc 111}" "64 lowercase hex")
# Not one plain data form.
# Malformed bodies must be refused; which of the two rejection messages fires
# depends on where the reader stops, and both are correct refusals.
(defn bad-any [text fragments]
  (write-sidecar text)
  (def message (try (do (ti/read region 111) nil) ([e] (string e))))
  (assert message (string "expected a rejection for: " text))
  (assert (some |(not (nil? (string/find $ message))) fragments)
          (string "expected one of " (string/join fragments " / ") " in: " message)))
(bad "{} {}" "exactly one form")
(bad-any "(" @["invalid terrain identity syntax" "exactly one form"])
(bad-any "---not janet---" @["invalid terrain identity syntax" "exactly one form"])
# No eval: a form is rejected as non-data, never executed.
(write-sidecar "{:version 2 :generation :noise :seed 4 :region-crc (fn [] 1)}")
(assert (rejects? (fn [] (ti/read region 111))))
(assert (= 0 (length (filter |(string/find "terrain.janet.tmp" $) (os/dir root)))))
(print "exact keys and values: passed")

# Oversized bodies are refused before being read into memory.
(write-sidecar (string (buffer/new-filled (+ ti/max-body-bytes 100) 32)))
(assert-error (fn [] (ti/read region 111)) "exceeds")
(assert (= 65536 ti/max-body-bytes))
(print "body size limit: passed")

#
# --- Write consistency --------------------------------------------------
#

(clear)
(write-region "REGION-BYTES")
(ti/write-atomic region diffusion 111)
# Re-writing the same identity is allowed and refreshes the CRC.
(ti/write-atomic region diffusion 222)
(assert (= :present ((ti/read region 222) :status)))
(assert (= :stale ((ti/read region 111) :status)))
# A different identity is refused and the previous sidecar survives.
(assert-error (fn [] (ti/write-atomic region noise 222)) "already pins a different")
(assert (= :present ((ti/read region 222) :status)))
(assert (= :diffusion (((ti/read region 222) :identity) :generation)))
# :replace allows a deliberate generation change.
(ti/write-atomic region noise 222 @{:replace true})
(assert (= :noise (((ti/read region 222) :identity) :generation)))
(assert (= :match ((ti/gate region noise 222) :status)))
# An unreadable sidecar blocks the write too: its identity cannot be compared.
(write-sidecar "not data (")
(assert-error (fn [] (ti/write-atomic region noise 222)) "unreadable terrain identity")
(print "write consistency: passed")

#
# --- Gate matrix --------------------------------------------------------
#

(clear)
(write-region "REGION-BYTES")
(ti/write-atomic region (ti/diffusion-identity digest-a 1234) 111)
# Identical session loads.
(assert (= :match ((ti/gate region (ti/diffusion-identity digest-a 1234) 111) :status)))
# Each generation-affecting difference refuses.
(assert (= :mismatch ((ti/gate region (ti/diffusion-identity digest-b 1234) 111) :status)))
(assert (= :mismatch ((ti/gate region (ti/diffusion-identity digest-a 1235) 111) :status)))
(assert (= :mismatch ((ti/gate region noise 111) :status)))
# The refusal names both sides.
(assert (string/find "diffusion" ((ti/gate region noise 111) :reason)))
# Stale refuses too, even for an identical identity.
(assert (= :stale ((ti/gate region (ti/diffusion-identity digest-a 1234) 222) :status)))
(assert (not (ti/loadable? region (ti/diffusion-identity digest-a 1234) 222)))
# A noise world round-trips as noise.
(clear)
(write-region "NOISE-BYTES")
(ti/write-atomic region (ti/noise-identity 972) 333)
(assert (= :match ((ti/gate region (ti/noise-identity 972) 333) :status)))
(assert (= :mismatch ((ti/gate region (ti/noise-identity 4) 333) :status)))
(assert (= :mismatch ((ti/gate region (ti/diffusion-identity digest-a 972) 333) :status)))
(print "gate matrix: passed")

#
# --- Cleanup ------------------------------------------------------------
#

(clear)
(try (os/rm root) ([e] nil))
(print "terrain identity: ALL CHECKS PASSED")
