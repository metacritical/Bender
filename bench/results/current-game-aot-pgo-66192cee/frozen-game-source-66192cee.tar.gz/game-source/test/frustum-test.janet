# Headless frustum contract tests. Run with the project's Janet interpreter.
# Camera inputs are world-space position, target, up and vertical FOV.
# Queries accept scalar coordinates; boundary contacts count.
(import ../src/frustum)
(import ../src/world)

(defn camera [&opt px py pz tx ty tz fovy aspect near far]
  (frustum/frustum-from-camera
    [(or px 0) (or py 0) (or pz 0)] [(or tx 0) (or ty 0) (or tz -1)]
    [0 1 0] (or fovy 90) (or aspect 1) (or near 1) (or far 100)))

(defn look [position target &opt up fovy aspect near far]
  (frustum/frustum-from-camera position target (or up [0 1 0])
                               (or fovy 90) (or aspect 1)
                               (or near 1) (or far 100)))

(defn point [f x y z] (frustum/point-inside? f x y z))
(defn box [f x0 y0 z0 x1 y1 z1]
  (frustum/aabb-visible? f x0 y0 z0 x1 y1 z1))
(defn sphere [f x y z r] (frustum/sphere-visible? f x y z r))
(defn chunk [f x z] (frustum/chunk-visible? f x z))

(defn group [name run]
  (print name ":")
  (let [start (os/clock)]
    (run)
    (print "  passed in " (- (os/clock) start) " seconds")))

(group "0. tall chunk frustum bounds" (fn []
  (let [f (look [8 220 80] [8 220 0] [0 1 0] 50 1 1 100)]
    (assert (= world/chunk-y 256))
    (assert (frustum/chunk-visible? f 0 0)
            "chunk upper 192 blocks must not be culled")
    (assert (not (frustum/chunk-visible? f 0 0 16 64 16))
            "test camera looks above legacy chunk height"))))

(group "1. camera direction and central ray" (fn []
  (let [f (camera)]
    (assert (point f 0 0 -2))
    (assert (point f 0 0 -50))
    (assert (not (point f 0 0 2))))))

(group "2. near and far clipping" (fn []
  (let [f (camera)]
    (assert (not (point f 0 0 -0.5)))
    (assert (point f 0 0 -1.01))
    (assert (point f 0 0 -99.99))
    (assert (not (point f 0 0 -101))))))

(group "3. horizontal field of view" (fn []
  (let [f (camera)]
    (assert (point f 4 0 -5))
    (assert (point f -4 0 -5))
    (assert (not (point f 6 0 -5)))
    (assert (not (point f -6 0 -5))))))

(group "4. vertical field of view" (fn []
  (let [f (camera)]
    (assert (point f 0 4 -5))
    (assert (point f 0 -4 -5))
    (assert (not (point f 0 6 -5)))
    (assert (not (point f 0 -6 -5))))))

(group "5. aspect ratio and narrower FOV" (fn []
  (let [wide (camera 0 0 0 0 0 -1 90 2 1 100)
        narrow (camera 0 0 0 0 0 -1 60 1 1 100)]
    (assert (point wide 7 0 -5))
    (assert (not (point narrow 4 0 -5)))
    (assert (not (point wide 0 7 -5))))))

(group "6. translated camera" (fn []
  (let [f (camera 100 20 -40 100 20 -41 90 1 1 100)]
    (assert (point f 100 20 -45))
    (assert (not (point f 0 0 -5)))
    (assert (not (point f 100 20 -39))))))

(group "7. rotated camera" (fn []
  (let [f (camera 0 0 0 1 0 0 90 1 1 100)]
    (assert (point f 5 0 0))
    (assert (point f 5 0 -4))
    (assert (not (point f -5 0 0)))
    (assert (not (point f 0 0 -5))))))

(group "8. AABB inside, crossing, outside and behind" (fn []
  (let [f (camera)]
    (assert (box f -1 -1 -6 1 1 -4))
    (assert (box f 4 -1 -6 6 1 -4))
    (assert (not (box f 7 -1 -6 9 1 -4)))
    (assert (not (box f -1 -1 1 1 1 3)))
    (assert (box f -1 -1 -2 1 1 0))
    # A box enclosing the entire finite frustum must never be culled.
    (assert (box f -1000 -1000 -1000 1000 1000 1000)))))

(group "9. sphere fully inside, crossing, outside and behind" (fn []
  (let [f (camera)]
    (assert (sphere f 0 0 -5 1))
    (assert (sphere f 5.5 0 -5 1))
    (assert (not (sphere f 9 0 -5 1)))
    (assert (not (sphere f 0 0 5 1)))
    (assert (sphere f 0 0 -0.5 1)))))

(group "10. chunks and negative world coordinates" (fn []
  (let [f (camera 0 80 16 0 80 0 90 1 1 100)]
    (assert (chunk f 0 0))
    (assert (chunk f -1 0))
    (assert (not (chunk f 0 10)))
    (assert (not (chunk f 10 0))))))

(group "11. deterministic randomized stress and repeatability" (fn []
  (let [f (camera)
        start (os/clock)]
    (var seed 1729)
    (for i 0 10000
      (set seed (mod (+ (* seed 48271) 0) 2147483647))
      (let [x (- (mod seed 81) 40)]
        (set seed (mod (* seed 48271) 2147483647))
        (let [y (- (mod seed 81) 40)]
          (set seed (mod (* seed 48271) 2147483647))
          (let [depth (+ 2 (mod seed 79))
                z (- depth)
                expected (and (< (math/abs x) depth)
                              (< (math/abs y) depth))
                boundary (or (= (math/abs x) depth)
                             (= (math/abs y) depth))
                actual (point f x y z)]
            # Floating plane normalization may round exact side contacts.
            (unless boundary (assert (= expected actual)))
            (assert (= actual (point f x y z)))
            (assert (= actual (box f x y z x y z)))
            (assert (= actual (sphere f x y z 0)))))))
    (print "  10000 seeded points, boxes and spheres: "
           (- (os/clock) start) " seconds"))))

(group "12. four horizontal cardinal directions and straight down" (fn []
  (each [target front back] [[[1 0 0] [5 0 0] [-5 0 0]]
                              [[-1 0 0] [-5 0 0] [5 0 0]]
                              [[0 0 1] [0 0 5] [0 0 -5]]
                              [[0 0 -1] [0 0 -5] [0 0 5]]
                              [[0 -1 0] [0 -5 0] [0 5 0]]]
    (let [f (look [0 0 0] target)]
      (assert (point f (get front 0) (get front 1) (get front 2)))
      (assert (not (point f (get back 0) (get back 1) (get back 2))))))))

(group "13. specified chunks and 21x21 grid minority" (fn []
  (let [east (look [0 32 8] [40 32 8] [0 1 0] 60 1 1 80)
        west (look [0 32 8] [-72 32 8] [0 1 0] 60 1 1 100)
        grid (look [0 32 8] [0 32 -8] [0 1 0] 55 1 1 48)]
    (assert (chunk east 2 0))
    (assert (chunk west -5 0))
    (assert (not (chunk east -5 0)))
    (assert (not (chunk west 2 0)))
    (var visible 0)
    (for cx -10 11
      (for cz -10 11
        (when (chunk grid cx cz) (++ visible))))
    (assert (> visible 0))
    (assert (< visible 221))
    (print "  visible chunks: " visible " / 441"))))

(group "14. seeded camera orientations and conservative boxes" (fn []
  (var seed 142857)
  (defn next-random []
    (set seed (mod (* seed 48271) 2147483647))
    (/ seed 2147483647))
  (for trial 0 100
    (let [px (- (* 60 (next-random)) 30)
          py (+ 5 (* 50 (next-random)))
          pz (- (* 60 (next-random)) 30)
          dx (- (* 2 (next-random)) 1)
          dy (- (* 2 (next-random)) 1)
          dz (- (* 2 (next-random)) 1)
          f (look [px py pz] [(+ px dx) (+ py dy) (+ pz dz)]
                  [0 1 0] 75 1.4 0.5 90)]
      (for sample 0 50
        (let [x (- (* 160 (next-random)) 80)
              y (- (* 100 (next-random)) 20)
              z (- (* 160 (next-random)) 80)
              sx (+ 0.1 (* 12 (next-random)))
              sy (+ 0.1 (* 12 (next-random)))
              sz (+ 0.1 (* 12 (next-random)))
              x1 (+ x sx) y1 (+ y sy) z1 (+ z sz)]
          # Independent witness sampling can prove intersection, never absence.
          (each [u v w] [[0 0 0] [1 1 1] [0 1 0] [1 0 1]
                        [0.5 0.5 0.5] [0.25 0.75 0.5]]
            (let [wx (+ x (* u sx)) wy (+ y (* v sy)) wz (+ z (* w sz))]
              (when (point f wx wy wz)
                (assert (box f x y z x1 y1 z1)))))))))))

(group "15. 200000 culling calls (informational timing)" (fn []
  (let [f (look [0 32 8] [0 32 -8] [0 1 0] 70 1.5 1 100)
        start (os/clock)]
    (var visible 0)
    (for i 0 200000
      (let [cx (- (mod i 61) 30)
            cz (- (mod (math/floor (/ i 61)) 61) 30)]
        (when (chunk f cx cz) (++ visible))))
    (let [elapsed (- (os/clock) start)]
      (print "  200000 chunk calls: " elapsed " seconds; " visible
             " visible; " (/ 200000 elapsed) " calls/second")))))

(print "frustum tests passed")
