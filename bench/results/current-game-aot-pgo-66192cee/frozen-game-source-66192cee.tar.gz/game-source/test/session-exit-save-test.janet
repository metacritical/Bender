# Ordinary-session exit save: the teardown helper's dispatch and its effect.
#
# When a player closes the window, main tears the session down and saves first
# (main.janet:5023). Until that was extracted into `save-on-exit!` the decision
# was inline, untestable and its failure was an `eprint` nobody could observe.
# This suite drives the extracted helper directly, so the dispatch is proven and
# not merely assumed.
#
# What it covers, and why each part can regress on its own:
#
#   * an ordinary session SAVES: an edit made after the last save and the
#     player's final pose both survive the exit save
#   * a scripted or verify run SKIPS and leaves the slot BYTE-IDENTICAL -- the
#     whole point of the skip is that evidence-producing runs must not mutate
#     the tree their output describes
#   * a session with no slot SKIPS
#   * settings are passed through only when provided, so a session that never
#     had settings does not overwrite the slot's stored ones with `{}`
#   * a failure is RETURNED as [:failed reason], never thrown, so a caller can
#     report it instead of losing the world silently
#
# Provider kinds: the catalogue's save path is provider-agnostic, so both are
# exercised against the same code. The learned case uses an isolated TDS3
# artifact built through the real scenic exporter -- no model, no weights, no
# GPU, no inference process -- because a real QA slot must never be mutated.
#
# No window, no GPU, no child process. Unique scratch root; teardown touches
# only roots this suite created.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/session-exit-save-test.janet

(import ../main :as game)
(import ../src/world-catalog :as catalog)
(import ../src/world :as world)
(import ../src/worldgen :as worldgen)
(import ../src/world-seed :as ws)
(import ../src/terrain-integrity :as integrity)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(def here (os/cwd))

#
# --- Scratch roots -----------------------------------------------------
#

(def created-roots @[])
(var counter 0)

(defn drop-root [p]
  (def st (os/lstat p))
  (cond
    (nil? st) nil
    (= :directory (st :mode))
    (do (each n (os/dir p) (drop-root (string p "/" n))) (os/rm p))
    true (os/rm p)))

(defn fresh-root [tag]
  (++ counter)
  (def root (string here "/tmp/sx-" tag "-" (os/getpid) "-" counter))
  (drop-root root)
  (os/mkdir root)
  (array/push created-roots root)
  root)

#
# --- Slot fixtures -----------------------------------------------------
#

(def pose-a {:pos [1.5 44.25 -3.75] :yaw 0.5 :pitch -0.25 :flying false})
(def pose-b {:pos [9.125 60.5 7.875] :yaw 1.75 :pitch 0.375 :flying true})

(defn small-world [seed]
  (def w (world/world-new))
  (put w :seed seed)
  (worldgen/generate-chunk w 0 0 seed)
  (worldgen/generate-chunk w 1 0 seed)
  w)

(defn make-procedural-slot [root seed settings]
  (def w (small-world seed))
  (def id (catalog/create-slot root
                               {:name "Session"
                                :seed (ws/parse-seed-input (string seed))
                                :world w
                                :player pose-a
                                :settings settings}))
  [id w])

(defn manifest-path [root id] (string root "/" id "/manifest.janet"))

(defn stamp
  "Modification time and size: enough to prove a file was not rewritten."
  [path]
  (def st (os/lstat path))
  (if (nil? st) nil [(get st :modified) (get st :size)]))

(defn slot-files [root id]
  (def dir (string root "/" id))
  (if (nil? (os/lstat dir))
    @[]
    (sorted (os/dir dir))))

(defn file-digest
  "CRC-32 of a file's actual bytes, via the shared integrity helper.

  Not the file SIZE: a same-length mutation (one block changed, one byte
  flipped, a timestamp rewritten in place) leaves the size identical and would
  pass a size-only comparison. These slot fixtures are far under a megabyte, so
  reading them is cheap and exact."
  [path]
  (def f (file/open path :rb))
  (if (nil? f)
    "missing"
    (do
      (def data (try (file/read f :all) ([e] nil)))
      (file/close f)
      (if (nil? data) "unreadable" (integrity/crc32-hex (string data))))))

(defn slot-fingerprint
  "Every file under the slot with its SIZE and its CRC-32.

  Size alone is not byte equality; the digest is. Both are recorded so a
  difference in either is visible and the message stays diagnosable."
  [root id]
  (def dir (string root "/" id))
  (def out @[])
  (defn walk [d prefix]
    (each n (sorted (os/dir d))
      (def p (string d "/" n))
      (def st (os/lstat p))
      (cond
        (nil? st) nil
        (= :directory (st :mode)) (walk p (string prefix n "/"))
        true (array/push out (string prefix n ":" (get st :size)
                                     ":" (file-digest p))))))
  (when (os/lstat dir) (walk dir ""))
  (string/join out ","))

#
# --- 1. An ordinary session saves: edit and pose both survive ----------
#

(print "\nordinary session saves:")
(def root-a (fresh-root "save"))
(def [slot-a world-a] (make-procedural-slot root-a 7 @{}))
(def loaded-a (catalog/load-slot root-a slot-a))
(def restored-a (get loaded-a :world))
# The saved world starts with no wood at this cell; the edit is what must persist.
(check "the block starts as air before the edit"
       (= world/block-air (world/world-get-block restored-a 3 70 5)))
(world/world-set-block world-a 3 70 5 world/block-wood)
(check "the in-memory world took the edit"
       (= world/block-wood (world/world-get-block world-a 3 70 5)))
# The exit save is exactly what teardown calls, with a final pose.
(def outcome-a (game/save-on-exit! root-a slot-a world-a pose-b nil false false))
(check "an ordinary session reports :saved" (= :saved outcome-a)
       (string "outcome " (string outcome-a)))
(def after-a (catalog/load-slot root-a slot-a))
(def world-after-a (get after-a :world))
(check "the edit survives the exit save"
       (= world/block-wood (world/world-get-block world-after-a 3 70 5)))
# Pose, not just terrain: the player's last position is part of the session.
(def pose-after-a (get after-a :player))
(check "the exit pose survives"
       (= (get (get pose-after-a :pos) 0) (get (get pose-b :pos) 0)))
(check "the exit pose y survives"
       (= (get (get pose-after-a :pos) 1) (get (get pose-b :pos) 1)))
(check "the exit pose z survives"
       (= (get (get pose-after-a :pos) 2) (get (get pose-b :pos) 2)))
(check "the exit yaw survives" (= (get pose-after-a :yaw) (get pose-b :yaw)))
(check "the exit pitch survives" (= (get pose-after-a :pitch) (get pose-b :pitch)))
(check "the exit flying flag survives" (= (get pose-after-a :flying) (get pose-b :flying)))
# Saving twice must be idempotent in outcome, not merely in effect.
(check "a second exit save also reports :saved"
       (= :saved (game/save-on-exit! root-a slot-a world-a pose-b nil false false)))

#
# --- 2. Skipped runs leave the slot byte-identical ---------------------
#

(print "\nskipped runs do not mutate:")
(def root-b (fresh-root "skip"))
(def [slot-b world-b] (make-procedural-slot root-b 11 @{}))
(def before-b (slot-fingerprint root-b slot-b))
(def before-stamp (stamp (manifest-path root-b slot-b)))
# An edit in memory plus a new pose: if a skip leaked, both would land.
(world/world-set-block world-b 5 70 5 world/block-wood)
(os/sleep 1)  # enough that a rewritten file would carry a different mtime

(check "a verify run reports :skipped"
       (= :skipped (game/save-on-exit! root-b slot-b world-b pose-b nil true false)))
(check "a scripted run reports :skipped"
       (= :skipped (game/save-on-exit! root-b slot-b world-b pose-b nil false true)))
(check "a verify AND scripted run reports :skipped"
       (= :skipped (game/save-on-exit! root-b slot-b world-b pose-b nil true true)))
(check "a session with no slot reports :skipped"
       (= :skipped (game/save-on-exit! root-b nil world-b pose-b nil false false)))
# Both a content fingerprint and the manifest's own timestamp must be unchanged.
(check "skips left every slot file's bytes unchanged"
       (= before-b (slot-fingerprint root-b slot-b))
       (string "before " before-b " after " (slot-fingerprint root-b slot-b)))
(check "skips did not rewrite the manifest"
       (= before-stamp (stamp (manifest-path root-b slot-b))))
# And the edit genuinely was NOT saved.
(def after-b (catalog/load-slot root-b slot-b))
(check "a skipped run does not save the edit"
       (= world/block-air (world/world-get-block (get after-b :world) 5 70 5)))
(check "a skipped run does not save the pose"
       (= (get (get (get after-b :player) :pos) 0) (get (get pose-a :pos) 0)))

#
# --- 3. Settings pass through only when provided ----------------------
#

(print "\nsettings handling:")
(def root-c (fresh-root "settings"))
# A slot created WITH nondefault settings must keep them through an exit save
# that supplies settings explicitly.
(def custom @{:height-scale 1.5 :height-offset 6 :sea-level 30 :forest-density 20})
(def [slot-c world-c] (make-procedural-slot root-c 21 custom))
(def saved-settings-c (get (catalog/load-manifest root-c slot-c) :settings))
(check "the slot was created with nondefault settings"
       (= 1.5 (get saved-settings-c :height-scale)))
(check "an exit save with explicit settings reports :saved"
       (= :saved (game/save-on-exit! root-c slot-c world-c pose-b custom false false)))
(check "explicit settings are preserved, not reset"
       (= 1.5 (get (get (catalog/load-manifest root-c slot-c) :settings) :height-scale)))
# An exit save with NO settings must keep the stored ones rather than overwrite
# them with {}: `save-on-exit!` passes @{} (no key), which save-slot treats as
# "unchanged". If it passed {:settings {}} the world would be silently downgraded.
(check "an exit save with no settings reports :saved"
       (= :saved (game/save-on-exit! root-c slot-c world-c pose-b nil false false)))
(check "stored settings survive an exit save that passes none"
       (= 1.5 (get (get (catalog/load-manifest root-c slot-c) :settings) :height-scale))
       (string "settings now "
               (string (get (catalog/load-manifest root-c slot-c) :settings))))

#
# --- 4. A failure is returned, never thrown ---------------------------
#

(print "\nfailure is observable:")
(def root-d (fresh-root "fail"))
(def [slot-d world-d] (make-procedural-slot root-d 31 @{}))
# A different seed in the world than in the slot: save-slot refuses it, which is
# the cheapest real failure that is not a missing file.
(def other-world (world/world-new))
(put other-world :seed 999)
(worldgen/generate-chunk other-world 0 0 999)
(def failed (game/save-on-exit! root-d slot-d other-world pose-b nil false false))
(check "a refused save returns a tuple, not a throw"
       (and (indexed? failed) (= :failed (get failed 0)))
       (string "result " (string failed)))
(check "the failure carries a non-empty reason"
       (let [r (get failed 1)] (and (string? r) (pos? (length r)))))
# The original slot must be unharmed by the failed attempt.
(check "a failed exit save leaves the slot loadable"
       (not (nil? (try (do (catalog/load-slot root-d slot-d) true) ([e] false)))))
# And a missing slot id is a failure too, not a crash.
(def missing (game/save-on-exit! root-d "0" world-d pose-b nil false false))
(check "an unknown slot id is a returned failure"
       (and (indexed? missing) (= :failed (get missing 0))))

#
# --- 5. The helper is provider-agnostic -------------------------------
#
# The catalogue's save path branches on the slot's own provider, not on the
# caller, so the same helper must serve a learned slot. The artifact here is an
# isolated TDS3 built through the real scenic exporter: no model is loaded and
# no real QA slot is touched.
#

(print "\nlearned provider slot:")
(def root-e (fresh-root "learned"))
(def artifact-script (string here "/test/fixtures/terrain-provider-fake.py"))
(def artifact-ok
  (try (do
         (os/setenv "TC_FAKE_PROVIDER_MODE" "success")
         (def p (os/spawn ["python3" artifact-script
                           "--out" (string root-e "/artifact")
                           "--seed" "0" "--size" "128"] :p))
         (= 0 (if p (:wait p) -1)))
       ([e] false)))
(os/setenv "TC_FAKE_PROVIDER_MODE" "success")
(check "an isolated TDS3 artifact was produced without a model" artifact-ok)

(when artifact-ok
  (def art-root (string root-e "/artifact"))
  (def ids (filter (fn [n] (and (= 64 (length n))
                                (every? (map (fn [i]
                                               (def c (get n i))
                                               (or (and (<= 48 c) (<= c 57))
                                                   (and (<= 97 c) (<= c 102))))
                                             (range 64)))
                                (= :directory (os/lstat (string art-root "/" n) :mode))))
                   (os/dir art-root)))
  (check "exactly one artifact directory was produced" (= 1 (length ids)))
  (when (= 1 (length ids))
    (def art-dir (string art-root "/" (first ids)))
    (def meta (try (catalog/inspect-artifact art-dir 0) ([e] nil)))
    (check "the catalogue accepts the learned artifact" (not (nil? meta)))
    (when meta
      # A learned slot built from the inspected artifact. The catalogue requires
      # the artifact directory, so it is passed through unchanged.
      # create-slot requires a built world even for a learned slot: the world is
      # the session's live terrain, the artifact supplies the generation record.
      # World seed 0 is deliberate -- it is the case that maps to a model seed.
      (def learned-world-source (small-world 0))
      (def learned
        (try (catalog/create-slot root-e
                                  {:name "Learned"
                                   :seed (ws/parse-seed-input "0")
                                   :world learned-world-source
                                   :provider :terrain-diffusion-python
                                   :artifact-dir art-dir
                                   :player pose-a
                                   # A learned slot's settings are exactly the
                                   # three generation controls its provider has.
                                   :settings {:size 128 :sea-level 28
                                              :profile "alpine"}})
             ([e] [:failed (string e)])))
      (if (and (indexed? learned) (= :failed (get learned 0)))
        (check "a learned slot could not be created in this fixture"
               false
               (string "create-slot refused: " (get learned 1)))
        (do
          (def learned-slot learned)
          (def loaded-learned (try (catalog/load-slot root-e learned-slot) ([e] nil)))
          (check "the learned slot loads" (not (nil? loaded-learned)))
          (def before-e (slot-fingerprint root-e learned-slot))
          (def learned-world (get loaded-learned :world))
          (check "a learned ordinary session reports :saved"
                 (= :saved (game/save-on-exit! root-e learned-slot learned-world
                                               pose-b nil false false)))
          (def after-e (catalog/load-slot root-e learned-slot))
          (check "the learned exit save keeps its pose"
                 (= (get (get (get after-e :player) :pos) 0)
                    (get (get pose-b :pos) 0)))
          # And the skip contract holds for learned slots too.
          (def before-skip (slot-fingerprint root-e learned-slot))
          (check "a learned verify run reports :skipped"
                 (= :skipped (game/save-on-exit! root-e learned-slot learned-world
                                                 pose-a nil true false)))
          (check "a learned skip leaves the slot byte-identical"
                 (= before-skip (slot-fingerprint root-e learned-slot))))))))

#
# --- Result -----------------------------------------------------------
#

(each root created-roots
  (def r (try [true (drop-root root)] ([e] [false (string e)])))
  (when (not (r 0)) (printf "  note cleanup %s: %s" root (r 1))))
(if (zero? failures)
  (print "\nsession exit save: ALL CHECKS PASSED")
  (do (printf "\nsession exit save: %d FAILED" failures) (os/exit 1)))
