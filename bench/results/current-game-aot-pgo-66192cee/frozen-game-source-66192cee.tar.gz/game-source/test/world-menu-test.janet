# Front-door menu: pure state, transitions and layout. No window, no GL, no files.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/world-menu-test.janet
#
# Fixtures are INJECTED, exactly as the module expects: a provider list and a
# world catalog. Nothing here opens a directory or starts a bake, which is the
# point -- the menu's honesty rules are testable without a world existing.

(import ../src/world-menu :as menu)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(defn refuses? [v]
  (and (indexed? v) (= :refuse (get v 0))))

#
# --- Fixtures -----------------------------------------------------------
#

(defn provider
  [id label-text available reason &opt controls]
  @{:id id :label label-text :available available :reason reason
    :controls (or controls @[])})

(def native
  (provider :native "Procedural (built in)" true nil
            @[@{:id :sea-level :label "Sea level" :kind :int
                :min 4 :max 60 :default 28}
              @{:id :hill-scale :label "Hill scale" :kind :number
                :min 8.0 :max 40.0 :default 14.0}]))

(def learned
  (provider :learned "Learned model" false "backend not installed" @[]))

(def providers @[native learned])

(def worlds
  @[@{:id "a" :name "Alpha" :provider :native :seed 4 :modified 100}
    @{:id "b" :name "Bravo" :provider :native :seed 7 :modified 200}
    @{:id "c" :name "Charlie" :provider :learned :seed 9 :modified 50}])

(defn fresh [] (menu/state-new providers worlds))

#
# --- Home ---------------------------------------------------------------
#
(print "\nhome:")

(def home (fresh))
(check "the menu opens on home" (= :home (home :screen)))
(check "home offers New and Load"
       (= 2 (length ((menu/layout home) :rows))))
(check "New game is enabled when a provider is available"
       (truthy? ((get ((menu/layout home) :rows) 0) :enabled)))
# Load is only offered when there is something to load: a button that opens an
# empty list is a dead end dressed as a destination.
(check "Load game is enabled when worlds exist"
       (truthy? ((get ((menu/layout home) :rows) 1) :enabled)))
(def empty-worlds (menu/state-new providers @[]))
(check "Load game is disabled with no worlds"
       (not (truthy? ((get ((menu/layout empty-worlds) :rows) 1) :enabled))))

(check "New game moves to the new-world screen"
       (= :new ((menu/step home [:new]) :screen)))
(check "Load game moves to the load screen"
       (= :load ((menu/step home [:load]) :screen)))
(check "back returns to home"
       (= :home ((menu/step (menu/step home [:load]) [:back]) :screen)))
(check "back works from the new screen too"
       (= :home ((menu/step (menu/step home [:new]) [:back]) :screen)))

#
# --- Transitions must not mutate their argument ------------------------
#
(print "\ntransitions:")

# The UI holds one state value; a transition that mutated it in place would make
# an undo or a re-render impossible and would let a test's two states interfere.
(def before (fresh))
(def after (menu/step before [:edit-name "Zed"]))
(check "a transition leaves the input state untouched"
       (= "" (before :name)))
(check "the returned state carries the edit"
       (= "Zed" (after :name)))
(check "two states from one are independent"
       (do
         (def a (menu/step before [:edit-name "A"]))
         (def b (menu/step before [:edit-name "B"]))
         (and (= "A" (a :name)) (= "B" (b :name)))))

#
# --- Providers ----------------------------------------------------------
#
(print "\nproviders:")

(def form (menu/step home [:new]))
(check "the new screen selects an available provider"
       (= :native (form :provider)))
(check "the form starts from the provider's declared defaults"
       (and (= 28 ((form :settings) :sea-level))
            (= 14.0 ((form :settings) :hill-scale))))
(check "changing provider resets the settings to that provider's"
       (zero? (length ((menu/step form [:change-provider :learned]) :settings))))
(check "changing to an unknown provider is an error"
       (= :error ((menu/step form [:change-provider :no-such]) :screen)))

# THE rule this module exists for: an unavailable provider must refuse to create,
# and must say why. A menu that drew it greyed but still built would be worse than
# one that offered nothing.
(def unavailable (menu/step form [:change-provider :learned]))
(check "an unavailable provider can be selected so its reason can be shown"
       (= :learned (unavailable :provider)))
(check "creating with an unavailable provider is refused"
       (refuses? (menu/create-request unavailable)))
(check "the refusal carries the provider's own reason"
       (= "backend not installed" (get (menu/create-request unavailable) 1)))
(defn row-for [state id]
  (first (filter |(= id ($ :id)) (menu/provider-rows state))))
(check "its row exposes available=false"
       (not (truthy? ((row-for unavailable :learned) :available))))
(check "and the row carries the reason for the view to render"
       (= "backend not installed" ((row-for unavailable :learned) :reason)))
(check "an available provider's row says so"
       (truthy? ((row-for unavailable :native) :available)))
# New-game entry must not park the player on a provider that cannot run.
(def only-unavailable (menu/state-new @[learned] worlds))
(check "a session whose only provider is unavailable has no provider chosen"
       (nil? ((menu/step only-unavailable [:new]) :provider)))
(check "New game is disabled when nothing can generate"
       (not (truthy? ((get ((menu/layout (menu/state-new @[learned] @[]))
                            :rows) 0) :enabled))))
(check "creating with no provider is refused"
       (refuses? (menu/create-request (menu/step only-unavailable [:new]))))

#
# --- Names and seeds ----------------------------------------------------
#
(print "\nnames and seeds:")

(def named (menu/step form [:edit-name "Vale of Ünicode ✓"]))
(check "a custom unicode name is carried verbatim"
       (= "Vale of Ünicode ✓" (named :name)))
(check "the name reaches the request"
       (= "Vale of Ünicode ✓" ((menu/create-request named) :name)))
(check "symbols and spaces survive"
       (= "a/b\\c d-e_f" ((menu/step form [:edit-seed "a/b\\c d-e_f"]) :seed-input)))

# A seed typed as text is RAW: the menu must not parse or clamp it, because the
# world's owner is the only thing that may decide what a seed means.
(def numeric (menu/step form [:edit-seed "123456"]))
(check "a numeric seed stays raw text"
       (= "123456" ((menu/create-request numeric) :seed-input)))
(check "the menu does not turn it into a number"
       (string? ((menu/create-request numeric) :seed-input)))
(check "a non-numeric seed is accepted as text"
       (= "hello" ((menu/step form [:edit-seed "hello"]) :seed-input)))

# Random is an EXPLICIT mode, not "empty input". The two are different requests:
# one says "pick for me", the other says "I typed nothing".
(check "random starts off"
       (not (truthy? (form :seed-random))))
(def randomed (menu/step form [:random-seed true]))
(check "random can be turned on"
       (truthy? (randomed :seed-random)))
(check "the request carries the random flag"
       (truthy? ((menu/create-request randomed) :seed-random)))
(check "typing a seed turns random off"
       (not (truthy? ((menu/step randomed [:edit-seed "42"]) :seed-random))))
(check "empty seed with random off is still a literal empty seed"
       (and (not (truthy? ((menu/create-request (menu/step randomed [:random-seed false]))
                           :seed-random)))
            (= "" ((menu/create-request (menu/step randomed [:random-seed false]))
                   :seed-input))))

#
# --- Settings are validated against the provider's own schema ----------
#
(print "\nsettings:")

(check "a value inside the declared range is accepted"
       (= :new ((menu/step form [:update-setting :sea-level 40]) :screen)))
(check "an out-of-range value is an error"
       (= :error ((menu/step form [:update-setting :sea-level 999]) :screen)))
(check "an out-of-range error names the control and the bound"
       (let [e ((menu/step form [:update-setting :sea-level 999]) :error)]
         (and (not (nil? (string/find "sea-level" e)))
              (not (nil? (string/find "4" e))))))
(check "a fractional value for an int control is refused"
       (= :error ((menu/step form [:update-setting :sea-level 4.5]) :screen)))
(check "a string for a numeric control is refused"
       (= :error ((menu/step form [:update-setting :hill-scale "fast"]) :screen)))
# A setting the provider never declared must be refused, not stored: the UI cannot
# know a feature its provider did not describe.
(check "an undeclared setting is refused"
       (= :error ((menu/step form [:update-setting :magic 1]) :screen)))
(check "the refusal names the missing control"
       (not (nil? (string/find "magic"
                               ((menu/step form [:update-setting :magic 1]) :error)))))
(check "a valid update lands in the settings"
       (= 40 (((menu/step form [:update-setting :sea-level 40]) :settings)
              :sea-level)))
(check "an invalid update does not change the settings"
       (= 28 (((menu/step form [:update-setting :sea-level 999]) :settings)
              :sea-level)))
# The request re-validates: a provider swapped underneath a form must not emit
# settings the new provider never accepted.
(check "a request is refused when a live setting is invalid"
       (let [broken (menu/step form [:change-provider :native])
             tampered (do (put (broken :settings) :sea-level 999) broken)]
         (refuses? (menu/create-request tampered))))

#
# --- Selection ----------------------------------------------------------
#
(print "\nselection:")

(def load-screen (menu/step home [:load]))
(check "no world is selected on entry"
       (nil? (load-screen :selected-world)))
(check "opening with no selection is refused"
       (refuses? (menu/open-request load-screen)))
(def selected (menu/step load-screen [:select-world "b"]))
(check "selecting a world records it"
       (= "b" (selected :selected-world)))
(check "opening a selected world produces an open request"
       (let [r (menu/open-request selected)]
         (and (menu/request? r) (= :open (r :kind)) (= "b" (r :world)))))
# An id the catalog does not contain must never become selected: the UI cannot
# invent an id, and a stale one is not a world.
(check "selecting an unknown world is an error"
       (= :error ((menu/step load-screen [:select-world "nope"]) :screen)))
(check "and cannot be opened"
       (refuses? (menu/open-request (menu/step load-screen [:select-world "nope"]))))
# `layout` is a TABLE of rows, so the selected row is found by id rather than by
# position -- `first` on a table is not the first row.
(check "the layout marks the selected row"
       (let [rows ((menu/layout selected) :rows)]
         (truthy? ((first (filter |(= "b" ($ :id)) rows)) :selected))))
(check "the layout does not mark the others"
       (let [rows ((menu/layout selected) :rows)]
         (not (truthy? ((first (filter |(= "a" ($ :id)) rows)) :selected)))))

#
# --- Pagination ---------------------------------------------------------
#
(print "\npagination:")

(def many (menu/state-new providers
                            (map (fn [i] @{:id (string i) :name (string "W" i)})
                                 (range 10))))
(def paged (menu/step (menu/step many [:load]) [:page 0]))
(check "a page holds at most page-size worlds"
       (= 8 (length (menu/visible-worlds paged))))
(check "the page count reflects the catalog"
       (= 2 (menu/page-count paged)))
(check "page 2 holds the remainder"
       (= 2 (length (menu/visible-worlds (menu/step paged [:page 1])))))
(check "a page past the end is clamped, not empty"
       (= 1 ((menu/step paged [:page 99]) :page)))
(check "a negative page is clamped to the first"
       (= 0 ((menu/step paged [:page -5]) :page)))

#
# --- Layout is data -----------------------------------------------------
#
(print "\nlayout:")

(check "the layout reports the current screen"
       (= :home ((menu/layout home) :screen)))
(check "the error screen carries its reason"
       (let [err (menu/step form [:update-setting :sea-level 999])]
         (= (err :error) ((menu/layout err) :error))))
(check "the error screen offers a way back"
       (= :home ((menu/step (menu/step form [:update-setting :sea-level 999])
                            [:back]) :screen)))
(check "provider rows appear only on the new screen"
       (and (pos? (length ((menu/layout form) :providers)))
            (empty? ((menu/layout home) :providers))))
(check "control rows carry live values"
       (= 28 (do (def rows (menu/control-rows form))
                 ((first (filter |(= :sea-level ($ :id)) rows)) :value))))
# An unrecognised action must not crash the menu; a drifting key map is expected.
(check "an unknown action is ignored"
       (= :home ((menu/step home [:no-such-action]) :screen)))

#
# --- Settings version: v2 opt-in, v1 untouched --------------------------
#
# Versioning is a provider-ROW property, and the menu must follow the row rather
# than assuming a version. These fixtures carry an explicit `:settings-version` so
# the menu is exercised exactly as the real adapter builds it, without importing
# the provider registry into this pure test.
#
(print "\nsettings version:")

(def v2-native
  @{:id :native :label "Procedural (built in)" :available true :reason nil
    :settings-version 2
    :controls @[@{:id :height-scale :label "Relief scale" :kind :number
                  :min 0.5 :max 2.0 :default 1.0}
                @{:id :height-offset :label "Elevation offset" :kind :int
                  :min -16 :max 64 :default 0}
                @{:id :sea-level :label "Sea level" :kind :int
                  :min 0 :max 128 :default 28}
                @{:id :forest-density :label "Forest" :kind :int
                  :min 0 :max 100 :default 0}
                @{:id :clearing-density :label "Clearings" :kind :int
                  :min 0 :max 100 :default 0}]})

(def v2-providers @[v2-native learned])

# A row without a declared version belongs to a caller that predates versioning:
# the menu must read that as the legacy 1, never as the newest.
(def legacy (fresh))
(check "a provider row without a version is treated as version 1"
       (= 1 (legacy :settings-version)))
(def legacy-new (menu/step legacy [:new]))
(check "the v1 form still submits a v1 request"
       (= 1 ((menu/create-request legacy-new) :settings-version)))

(def v2-state (menu/state-new v2-providers worlds))
(def v2-new (menu/step v2-state [:new]))
(check "the form adopts the provider row's version"
       (= 2 (v2-new :settings-version)))
(check "the form shows the fifth control"
       (= 5 (length ((menu/provider-of v2-new :native) :controls))))
(check "the clearing control defaults to 0"
       (= 0 ((v2-new :settings) :clearing-density)))

(def edited (menu/step v2-new [:update-setting :clearing-density 35]))
(check "the clearing value survives an edit"
       (= 35 ((edited :settings) :clearing-density)))
(check "editing does not change the settings version"
       (= 2 (edited :settings-version)))
(def req (menu/create-request edited))
(check "the create request carries settings version 2"
       (= 2 (req :settings-version)))
(check "the create request carries all five controls"
       (= 5 (length (keys (req :settings)))))
# COUNT IS NOT ENOUGH. Five keys of the wrong five would satisfy the check above,
# so the payload is pinned by the exact control ids the provider declares. This is
# what stops a curated New Game form from silently shipping a substituted key.
# Compared as JOINED STRINGS, not as arrays: `=` on two mutable arrays compares
# identity in Janet, so an array-to-array comparison here would fail even when the
# contents match.
(defn sorted-key-string [tbl] (string/join (sort (keys tbl)) ","))
(check "the create request carries exactly the declared control ids"
       (= (sorted-key-string
            (let [t @{}]
              (each c ((menu/provider-of v2-new :native) :controls)
                (put t (string (c :id)) true))
              t))
          (sorted-key-string (req :settings)))
       (sorted-key-string (req :settings)))
(check "the create request carries the curated generation controls"
       (= "clearing-density,forest-density,height-offset,height-scale,sea-level"
          (sorted-key-string (req :settings)))
       (sorted-key-string (req :settings)))
(check "the create request carries the edited clearing value"
       (= 35 ((req :settings) :clearing-density)))
(check "a clearing value outside the declared bounds is an error"
       (= :error ((menu/step v2-new [:update-setting :clearing-density 101]) :screen)))
(check "the refusal names the clearing control"
       (not (nil? (string/find "clearing-density"
                               ((menu/step v2-new
                                           [:update-setting :clearing-density 101])
                                :error)))))

# Switching to a provider that offers only v1 must DROP the v2 contract and the
# clearing control. Otherwise the form would submit a version the new provider
# cannot validate, carrying a key it never declared. The target must be AVAILABLE
# or the form would refuse outright and prove nothing about versions.
(def v1-available
  @{:id :native-v1 :label "Procedural (v1)" :available true :reason nil
    :settings-version 1
    :controls @[@{:id :sea-level :label "Sea level" :kind :int
                  :min 0 :max 128 :default 28}
                @{:id :forest-density :label "Forest" :kind :int
                  :min 0 :max 100 :default 0}]})
(def switchable (menu/state-new @[v2-native v1-available] worlds))
(def switch-form (menu/step (menu/step switchable [:new])
                            [:update-setting :clearing-density 35]))
(def switched (menu/step switch-form [:change-provider :native-v1]))
(check "switching provider falls back to that provider's version"
       (= 1 (switched :settings-version)))
(check "switching provider drops the clearing control"
       (not (has-key? (switched :settings) :clearing-density)))
(check "the switched form shows that provider's own controls"
       (= 2 (length ((menu/provider-of switched :native-v1) :controls))))
(check "the switched request is a v1 request"
       (= 1 ((menu/create-request switched) :settings-version)))

# A ROW THAT ADVERTISES AN UNKNOWN VERSION IS NOT TRUSTED. Only 1 and 2 exist;
# forwarding a third would produce a form that submits a contract the provider
# refuses, and the player would learn that at the last click.
(def bogus-native
  @{:id :bogus :label "Bogus" :available true :reason nil
    :settings-version 7
    :controls @[@{:id :sea-level :label "Sea level" :kind :int
                  :min 0 :max 128 :default 28}]})
(def bogus (menu/step (menu/state-new @[bogus-native] @[]) [:new]))
(check "an unknown advertised version falls back to 1"
       (= 1 (bogus :settings-version)))
(check "an unknown advertised version still produces a v1 request"
       (= 1 ((menu/create-request bogus) :settings-version)))
# A string is not a version either, however truthy it looks.
(def stringy-native
  @{:id :stringy :label "Stringy" :available true :reason nil
    :settings-version "2"
    :controls @[@{:id :sea-level :label "Sea level" :kind :int
                  :min 0 :max 128 :default 28}]})
(check "a non-numeric advertised version falls back to 1"
       (= 1 ((menu/step (menu/state-new @[stringy-native] @[]) [:new])
             :settings-version)))

# The Python-style row keeps its OWN version and settings across a provider switch,
# even when the form it is switched into was v2. This is the property that makes a
# mixed registry safe: one row's version never leaks into another's.
(def proc-v2
  @{:id :procedural :label "Procedural" :available true :reason nil
    :settings-version 2
    :controls @[@{:id :sea-level :label "Sea level" :kind :int
                  :min 0 :max 128 :default 28}
                @{:id :clearing-density :label "Clearings" :kind :int
                  :min 0 :max 100 :default 0}]})
(def py-v1
  @{:id :py :label "Python" :available true :reason nil
    :settings-version 1
    :controls @[@{:id :size :label "Map size" :kind :int
                  :min 16 :max 512 :default 128}
                @{:id :sea-level :label "Sea level" :kind :int
                  :min 0 :max 128 :default 28}
                @{:id :profile :label "Profile" :kind :choice
                  :choices ["alpine"] :default "alpine"}]})
(def mixed (menu/state-new @[proc-v2 py-v1] @[]))
(def mixed-form (menu/step (menu/step mixed [:new])
                           [:update-setting :clearing-density 50]))
(def to-py (menu/step mixed-form [:change-provider :py]))
(check "switching to the Python-style row yields its three controls"
       (= 3 (length ((menu/provider-of to-py :py) :controls))))
(check "the Python-style row keeps settings version 1"
       (= 1 (to-py :settings-version)))
(check "its settings are the Python provider's own, not the previous form's"
       (and (has-key? (to-py :settings) :size)
            (has-key? (to-py :settings) :profile)
            (not (has-key? (to-py :settings) :clearing-density))))
(check "its request carries version 1 and three keys"
       (let [r (menu/create-request to-py)]
         (and (= 1 (r :settings-version)) (= 3 (length (keys (r :settings)))))))

#
# --- Result -------------------------------------------------------------
#
(if (zero? failures)
  (print "\nworld menu: ALL CHECKS PASSED")
  (do (printf "\nworld menu: %d FAILED" failures) (os/exit 1)))
