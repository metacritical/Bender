# Headless streaming-policy tests. No window, no world mutation.
# Run: ./run.sh test

(import ./../src/stream :as stream)
(import ./../src/world :as world)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

#
# --- Coordinates --------------------------------------------------------
#
(print "chunk coordinates:")
(check "positive world x maps to its chunk" (= 0 (stream/chunk-coord-of 5)))
(check "a chunk boundary belongs to the higher chunk"
       (= 1 (stream/chunk-coord-of 16)))
# Floor division, not truncation: -1 lies in chunk -1, not chunk 0. Getting
# this wrong loads the wrong ring for any player west or north of origin,
# which is most of the world.
(check "negative world x floors, not truncates"
       (= -1 (stream/chunk-coord-of -1)))
(check "exactly -16 is chunk -1" (= -1 (stream/chunk-coord-of -16)))
(check "-17 is chunk -2" (= -2 (stream/chunk-coord-of -17)))

(check "distance is symmetric"
       (= (stream/chunk-distance2 0 0 3 4) (stream/chunk-distance2 3 4 0 0)))
(check "distance is squared" (= 25 (stream/chunk-distance2 0 0 3 4)))
(check "distance to self is zero" (zero? (stream/chunk-distance2 7 7 7 7)))

#
# --- Radius membership --------------------------------------------------
#
(print "\nradius membership:")
(check "the player's own chunk is in radius" (stream/in-radius? 0 0 0 0 4))
(check "a chunk at exactly the radius is included"
       (stream/in-radius? 4 0 0 0 4))
(check "one beyond the radius is excluded"
       (not (stream/in-radius? 5 0 0 0 4)))
# Circular, not square: the diagonal corner of a 4-radius square is 5.66
# chunks away and must be excluded.
(check "the square's diagonal corner is excluded"
       (not (stream/in-radius? 4 4 0 0 4)))
(check "radius is relative to the player, not the origin"
       (and (stream/in-radius? 104 0 100 0 4)
            (not (stream/in-radius? 106 0 100 0 4))))

#
# --- Ordering -----------------------------------------------------------
#
(print "\nload ordering:")
(def ring (stream/chunks-in-radius 0 0 4))
(check "radius 4 yields a sensible chunk count"
       (and (> (length ring) 40) (< (length ring) 81))
       (string "got " (length ring)))
(check "the player's own chunk comes first"
       (and (= 0 ((ring 0) 0)) (= 0 ((ring 0) 1))))
(var ordered true)
(for i 1 (length ring)
  (when (< ((ring i) 2) ((ring (- i 1)) 2)) (set ordered false)))
(check "chunks are ordered nearest first" ordered)
(check "no chunk outside the radius is listed"
       (do (var ok true)
           (each e ring (unless (stream/in-radius? (e 0) (e 1) 0 0 4)
                          (set ok false)))
           ok))
(check "no duplicates"
       (= (length ring)
          (length (distinct (map |(string ($ 0) "," ($ 1)) ring)))))
(check "a larger radius is a superset"
       (let [small (stream/chunks-in-radius 0 0 2)
             big (stream/chunks-in-radius 0 0 5)
             bigset (table ;(mapcat |[(string ($ 0) "," ($ 1)) true] big))]
         (do (var ok true)
             (each e small
               (unless (get bigset (string (e 0) "," (e 1))) (set ok false)))
             ok)))

#
# --- Missing ------------------------------------------------------------
#
(print "\nmissing chunks:")
(def loaded @{})
(defn has? [cx cz] (truthy? (get loaded [cx cz])))
(check "with nothing loaded, everything in radius is missing"
       (= (length (stream/chunks-in-radius 0 0 3))
          (length (stream/missing-chunks 0 0 3 has?))))
(each e (stream/chunks-in-radius 0 0 3) (put loaded [(e 0) (e 1)] true))
(check "with everything loaded, nothing is missing"
       (empty? (stream/missing-chunks 0 0 3 has?)))
(put loaded [1 0] nil)
(def miss (stream/missing-chunks 0 0 3 has?))
(check "a hole is reported" (= 1 (length miss)))
(check "and it is the right chunk"
       (and (= 1 ((miss 0) 0)) (= 0 ((miss 0) 1))))
(check "missing chunks are also nearest-first"
       (do (put loaded [3 0] nil) (put loaded [0 1] nil)
           (def m (stream/missing-chunks 0 0 3 has?))
           (var ok true)
           (for i 1 (length m)
             (when (< ((m i) 2) ((m (- i 1)) 2)) (set ok false)))
           ok))

#
# --- Unloading and hysteresis -------------------------------------------
#
(print "\nunloading:")
(def keys3 (map |[($ 0) ($ 1)] (stream/chunks-in-radius 0 0 6)))
(check "nothing is surplus while the player has not moved"
       (empty? (stream/surplus-chunks 0 0 6 2 keys3)))
(def surplus (stream/surplus-chunks 20 0 6 2 keys3))
(check "everything is surplus once the player is far away"
       (= (length keys3) (length surplus)))
(check "surplus is furthest-first"
       (do (var ok true)
           (for i 1 (length surplus)
             (when (> ((surplus i) 2) ((surplus (- i 1)) 2)) (set ok false)))
           ok))

# Hysteresis is the point: a chunk just outside the load radius must NOT be
# dropped, or walking back and forth over a boundary thrashes it.
(def edge @[[7 0]])
(check "a chunk just beyond the radius survives inside the margin"
       (empty? (stream/surplus-chunks 0 0 6 2 edge)))
(check "but is dropped once beyond radius + margin"
       (= 1 (length (stream/surplus-chunks 0 0 4 2 edge))))
(check "zero margin drops immediately beyond the radius"
       (= 1 (length (stream/surplus-chunks 0 0 6 0 @[[7 0]]))))

# The real anti-thrash property: step one chunk back and forth and confirm
# nothing is ever both loaded and immediately surplus.
(def held (map |[($ 0) ($ 1)] (stream/chunks-in-radius 0 0 5)))
(var thrash false)
(each p [[0 0] [1 0] [0 0] [1 0]]
  (def want (stream/chunks-in-radius (p 0) (p 1) 5))
  (def drop (stream/surplus-chunks (p 0) (p 1) 5 2 held))
  (def dropset (table ;(mapcat |[(string ($ 0) "," ($ 1)) true] drop)))
  (each e want
    (when (get dropset (string (e 0) "," (e 1))) (set thrash true))))
(check "a chunk is never wanted and surplus at the same moment"
       (not thrash))

#
# --- Seams --------------------------------------------------------------
#
(print "\nseam neighbours:")
(def nb (stream/seam-neighbours 5 5))
(check "a chunk has four seam neighbours" (= 4 (length nb)))
# deep= , not = : in Janet `=` on two arrays compares identity, so an
# array-vs-array equality check passes or fails for the wrong reason.
(check "they are the four edge-adjacent chunks"
       (deep= (sort (map |(string ($ 0) "," ($ 1)) nb))
              (sort @["4,5" "5,4" "5,6" "6,5"])))
(check "diagonals are excluded"
       (not (find |(and (= ($ 0) 6) (= ($ 1) 6)) nb)))
(check "the chunk itself is excluded"
       (not (find |(and (= ($ 0) 5) (= ($ 1) 5)) nb)))

#
# --- Work budget --------------------------------------------------------
#
(print "\nwork budget:")
(def b (stream/budget-new 4))
(stream/budget-begin b)
(check "a fresh budget is not exhausted" (not (stream/budget-exhausted? b)))
(check "it starts with no items" (zero? (b :items)))
(stream/budget-note b)
(check "noting work counts an item" (= 1 (b :items)))

# Burn past the budget and confirm it actually trips. A budget that never
# reports exhaustion would let streaming stall a frame indefinitely.
(def b2 (stream/budget-new 5))
(stream/budget-begin b2)
(var spins 0)
(while (and (not (stream/budget-exhausted? b2)) (< spins 50000000))
  (++ spins))
(check "the budget trips once its time is spent"
       (stream/budget-exhausted? b2))
(check "and it spun rather than returning instantly" (> spins 0))

# Cost-aware admission: the property that actually bounds frame time.
(def b4 (stream/budget-new 10))
(stream/budget-begin b4)
(check "a job that fits is admitted" (stream/budget-allows? b4 2))
# Forward progress: a job bigger than the entire budget must still run as the
# frame's first item, or it starves forever and streaming stalls. This exact
# case deadlocked the engine -- 7.3 ms chunks under a 6 ms budget.
(check "an oversized job is admitted as the first item of a frame"
       (stream/budget-allows? b4 50))
(stream/budget-note b4)
(check "but is refused once something has already run"
       (not (stream/budget-allows? b4 50)))
(check "a job that still fits is admitted after the first"
       (stream/budget-allows? b4 1))
(check "remaining starts near the full budget"
       (> (stream/budget-remaining b4) 9))

(def e (stream/ema-new 5))
(check "an ema starts at its seed" (= 5 (e :value)))
(stream/ema-update e 10)
(check "an ema moves toward a new sample" (and (> (e :value) 5) (< (e :value) 10)))
(for i 0 60 (stream/ema-update e 10))
(check "and converges on a steady sample"
       (< (math/abs (- (e :value) 10)) 0.01)
       (string "got " (e :value)))
(for i 0 60 (stream/ema-update e 1))
(check "it tracks downward too" (< (e :value) 1.1))

(def b3 (stream/budget-new 0))
(stream/budget-begin b3)
(check "a zero budget is immediately exhausted" (stream/budget-exhausted? b3))

#
# --- Scale --------------------------------------------------------------
#
(print "\nscale:")
(each r [4 8 12 16]
  (printf "  info radius %2d -> %4d chunks (%d blocks across)"
          r (length (stream/chunks-in-radius 0 0 r))
          (* (+ (* 2 r) 1) world/chunk-x)))
(def t0 (os/clock))
(for i 0 200 (stream/chunks-in-radius 0 0 12))
(printf "  info chunks-in-radius(12): %.3f ms per call"
        (* 1000 (/ (- (os/clock) t0) 200)))

(printf "\n%s  (%d failure%s)"
        (if (zero? failures) "ALL CHECKS PASSED" "CHECKS FAILED")
        failures (if (= 1 failures) "" "s"))
(os/exit (if (zero? failures) 0 1))
