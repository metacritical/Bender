# Seed input contract: numeric reduction, text hashing, random entropy.
#
# Pure and independent of the game. The text-seed vectors are CRC-32 values that
# were computed independently of this module with Python's `zlib.crc32` over the
# same tagged UTF-8 bytes, so this suite pins the contract rather than merely
# restating the implementation. Python's zlib is the reference implementation
# of CRC-32/ISO-HDLC: for "123456789" it yields cbf43926, which
# `test/terrain-integrity-test.janet` already asserts.
(import ../src/world-seed :as ws)
(import ../src/terrain-integrity :as integrity)

(defn rejects? [f] (try (do (f) false) ([_] true)))
(defn assert-error [f fragment]
  (def message (try (do (f) nil) ([e] (string e))))
  (assert message (string "expected an error mentioning " fragment))
  (assert (not (nil? (string/find fragment message)))
          (string "expected \"" fragment "\" in: " message)))
(defn seed-of [text] ((ws/parse-seed-input text) :value))
(defn kind-of [text] ((ws/parse-seed-input text) :kind))

#
# --- The contract's range ----------------------------------------------
#

(assert (= 1 ws/version))
(assert (= 2147483648 ws/modulus))
(assert (= 2147483647 ws/max-seed))
(assert (= "text-v1:" (string ws/text-tag)))
# The generator itself reduces through worldgen/i32 and mixes modulo 2^31-1, so
# this range is what actually reaches terrain. Both ends are valid seeds.
(assert (= 0 (seed-of "0")))
(assert (= 2147483647 (seed-of "2147483647")))
(print "contract constants: passed")

#
# --- Numeric: decimal forms that are the same number --------------------
#

(defn same [a b]
  (assert (= (seed-of a) (seed-of b))
          (string "expected " a " and " b " to be the same seed")))

(same "42" "00042")
(same "42" "+42")
(same "007" "7")
(same "0" "-0")
(same "0" "+0")
(same "0" "0000000000000000000")
(assert (= 42 (seed-of "42")))
(assert (= :numeric (kind-of "00042")))
(assert (= :numeric (kind-of "-1")))
(assert (= :numeric (kind-of "+42")))
# Numeric means "optional sign then digits ONLY". Anything else is text, which
# is why a float or exponent form never silently becomes a number.
# Note "42 " and " 42" trim to a numeric "42" -- covered by the trim section.
(each t ["12.0" "1e5" "0x10" "4 2" "-" "+" "--1" "1-2" "12a" "+-3"]
  (assert (not= :numeric (kind-of t))
          (string t " must be text, not a number")))
(print "numeric equivalence: passed")

#
# --- Numeric: reduction beyond the range ------------------------------
#

# Reduced digit by digit modulo 2^31, never through a float. An exponent form
# would have lost precision here; these do not.
(assert (= 0 (seed-of "2147483648")))
(assert (= 2147483647 (seed-of "4294967295")))
(assert (= 1073741824 (seed-of "1000000000000000000000000000000")))
(assert (= 553648127 (seed-of "999999999999999999999999")))
# Negative wrap is the stable two's-complement form.
(assert (= 2147483647 (seed-of "-1")))
(assert (= 2147483646 (seed-of "-2")))
(assert (= 0 (seed-of "-2147483648")))
(assert (= 2024026859 (seed-of "-123456789")))
(assert (= 1 (seed-of "-2147483647")))
# Every result is inside the contract range, for every form tried.
(each t ["0" "1" "2147483647" "2147483648" "4294967295" "-1" "-2147483648"
         "999999999999999999999999" "-999999999999999999999999" "007"]
  (def v (seed-of t))
  (assert (and (= v (math/floor v)) (<= 0 v) (<= v 2147483647))
          (string t " produced out-of-range " v)))
(print "numeric reduction and wrap: passed")

#
# --- Text: independently verified CRC-32 vectors ----------------------
#

# Each pair is (input, expected) with `expected` produced by Python's
# `zlib.crc32(("text-v1:" + input).encode()) & 0x7fffffff`, not by this module.
# The empty string is NOT a text seed -- blank input is rejected -- so its
# tagged CRC is asserted directly against the same Python reference value.
(assert (= 2111854563 (% (integrity/crc32 (string ws/text-tag)) ws/modulus)))
(assert-error (fn [] (ws/parse-seed-input "")) "blank input is not a seed")
(each [text expected]
       [["hello" 1020132233]
        ["🌍" 144782882]
        ["a🌍b" 175511721]
        ["hello, world!" 665452696]
        ["TrineXraft" 1630703007]
        # "  spaced  " trims to "spaced" BEFORE hashing, so the reference is
        # the digest of the trimmed text, not of the padded input.
        ["  spaced  " 1313677683]
        ["!@#$%^&*()" 1781241311]
        ["éèê" 779842521]
        ["Ω" 1006037739]
        ["😀😀😀" 456100236]
        ["abc" 1265632941]]
  (assert (= :text (kind-of text)) (string text " should be a text seed"))
  (assert (= expected (seed-of text))
          (string "text seed mismatch for " text ": expected " expected
                  " got " (seed-of text))))
(print "text CRC vectors: passed")

# The hash is over UTF-8 BYTES, so a multi-byte character contributes more than
# one byte and cannot be treated as a single code point.
(assert (= 4 (length "🌍")))
(assert (not= (seed-of "🌍") (seed-of "a")))
(assert (not= (seed-of "😀") (seed-of "😁")))
# Unicode is deliberately NOT normalized: a precomposed e-acute and the
# decomposed e+combining-acute are different byte sequences, so they are
# different worlds. Both values are Python zlib references. Asserted so the
# choice cannot drift silently into an accidental normalization.
(assert (= 240686246 (seed-of "é")))          # U+00E9, 2 bytes
(assert (= 855227458 (seed-of "é")))          # U+0065 U+0301, 3 bytes
(assert (not= (seed-of "é") (seed-of "é")))
(print "utf8 byte semantics: passed")

# The domain tag prevents a text seed from colliding with the number formed by
# the same characters, which is the whole reason the tag exists.
(assert (not= (seed-of "hello") 11))
(assert (= (integrity/crc32 "text-v1:hello") (+ (* 0 1) (seed-of "hello"))))
(print "domain separation: passed")

#
# --- Trim: outer ASCII whitespace only --------------------------------
#

(same "42" " 42")
(same "42" "42 ")
(same "42" "\t\n42\r\n")
(same "hello" "  hello  ")
(same "hello" "\thello\n")
# Inner whitespace is significant: these are different text seeds.
(assert (not= (seed-of "a b") (seed-of "a  b")))
(assert (not= (seed-of "a b") (seed-of "ab")))
# Captured input preserves exactly what was supplied, before trimming.
(assert (= "  42  " ((ws/parse-seed-input "  42  ") :input)))
(print "outer whitespace trimming: passed")

#
# --- Blank input is an explicit error --------------------------------
#

# A blank field means "random world", which is a separate affordance. Making it
# silently mean zero would be indistinguishable from typing "0".
(each t ["" " " "   " "\t" "\n" " \t\n "]
  (assert-error (fn [] (ws/parse-seed-input t)) "blank input is not a seed"))
(assert-error (fn [] (ws/parse-seed-input nil)) "must be a string")
(assert-error (fn [] (ws/parse-seed-input 42)) "must be a string")
(assert-error (fn [] (ws/parse-seed-input :seed)) "must be a string")
(print "blank rejection: passed")

#
# --- Result shape ------------------------------------------------------
#

(def parsed (ws/parse-seed-input "00042"))
(assert (= 1 (parsed :version)))
(assert (= "00042" (parsed :input)))
(assert (= :numeric (parsed :kind)))
(assert (= 42 (parsed :value)))
(assert (= "42" (parsed :canonical)))
(assert (= 42 (ws/seed-of parsed)))
# Canonical is the decimal form of the resolved value, so it round-trips.
(assert (= 42 (seed-of (parsed :canonical))))
(each t ["0" "42" "2147483647" "-1" "hello" "🌍"]
  (def p (ws/parse-seed-input t))
  (assert (= (p :value) (seed-of (p :canonical)))
          (string "canonical form of " t " must round-trip")))
# A parsed input is frozen: the contract value cannot be edited after the fact.
(assert (rejects? (fn [] (put parsed :value 7))))
(assert (= 42 (parsed :value)))
(print "result shape: passed")

#
# --- Random seeds -----------------------------------------------------
#

# Injected entropy makes a random seed reproducible, which is what lets a test
# assert a value and lets a caller describe a world from the bytes it used.
(def fixed (ws/random-identity @"\x00\x00\x00\x01"))
(assert (= 1 (fixed :value)))
(assert (= :random (fixed :kind)))
(assert (= 1 (fixed :version)))
(assert (nil? (fixed :input)))
(assert (= "1" (fixed :canonical)))
(assert (= "\0\0\0\x01" (fixed :entropy)))
(assert (= 1 ((ws/random-identity @"\x00\x00\x00\x01") :value))
        "identical entropy must reproduce the same seed")
(assert (= 2147483647 ((ws/random-identity @"\x7f\xff\xff\xff") :value)))
# The mask drops the top bit rather than reducing modulo 2^31, so entropy with
# the high bit set does not wrap into the same bucket as the low values.
(assert (= 1 ((ws/random-identity @"\x80\x00\x00\x01") :value))
        "only the top bit is masked away, not reduced modulo")
(assert (= 2147483647 ((ws/random-identity @"\xff\xff\xff\xff") :value)))
(each bytes [@"\x00\x00\x00\x00" @"\x7f\xff\xff\xff" @"\x80\x00\x00\x00"
             @"\xff\xff\xff\xff" @"\x12\x34\x56\x78"]
  (def v ((ws/random-identity bytes) :value))
  (assert (and (= v (math/floor v)) (<= 0 v) (<= v 2147483647))
          (string "injected entropy produced out-of-range " v)))
# The entropy must be exactly the four bytes the contract describes.
(assert-error (fn [] (ws/random-identity @"\x00\x00\x00")) "exactly 4 bytes")
(assert-error (fn [] (ws/random-identity @"\x00\x00\x00\x00\x00")) "exactly 4 bytes")
(assert-error (fn [] (ws/random-identity "")) "exactly 4 bytes")
(assert-error (fn [] (ws/random-identity 5)) "must be bytes")
# The default path draws from the OS and still lands in range.
(for i 0 16
  (def r (ws/random-identity))
  (def v (r :value))
  (assert (and (= v (math/floor v)) (<= 0 v) (<= v 2147483647))
          (string "os entropy produced out-of-range " v))
  (assert (= 4 (length (r :entropy))))
  (assert (= :random (r :kind))))
(assert (rejects? (fn [] (put fixed :value 9))))
(assert (= 1 (fixed :value)))
(print "random identity: passed")

#
# --- Description -------------------------------------------------------
#

(assert (= "42 (numeric \"00042\")" (ws/describe (ws/parse-seed-input "00042"))))
(assert (not (nil? (string/find "(text " (ws/describe (ws/parse-seed-input "abc"))))))
(assert (= "1 (random)" (ws/describe fixed)))
(assert-error (fn [] (ws/describe @{:kind :telepathy :value 1})) "unknown seed kind")
(print "describe: passed")

#
# --- Determinism -------------------------------------------------------
#

# The whole contract is pure: repeated parses agree, and the order of unrelated
# work cannot change a result.
(def first (seed-of "TrineXraft"))
(for i 0 100
  (assert (= first (seed-of "TrineXraft"))))
(assert (= (seed-of "hello") (seed-of "  hello  ")))
(print "determinism: passed")

(print "world seed: ALL CHECKS PASSED")
