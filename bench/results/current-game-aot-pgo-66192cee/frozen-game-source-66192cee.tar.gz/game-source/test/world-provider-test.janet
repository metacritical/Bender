# World provider registry: entries, per-provider settings, seed mapping, readiness.
#
# No GPU, no model, no inference. Every claim here is about the CONTRACT main and
# the menu code against: which providers exist, what each one's real controls are,
# that settings cannot leak between providers, and that world seed 0 is mapped
# deterministically rather than silently randomised.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/world-provider-test.janet

(import ../src/world-provider :as provider)
(import ../src/world :as world)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(defn refuses? [f]
  (try (do (f) false) ([_] true)))

#
# --- The registry is honest ---------------------------------------------
#
(print "\nregistry:")

(def ids (map |($ :id) (provider/providers)))
(check "three providers are offered"
       (= 3 (length ids)))
(check "procedural is available"
       (truthy? ((provider/provider-info :procedural) :available)))
# The temporary Python provider is the one this turn adds. Its LABEL says both
# what it is and that it is temporary, because a player comparing it with the
# native entry deserves to know why one works.
(def py (provider/provider-info :terrain-diffusion-python))
(check "the python provider exists"
       (truthy? py))
(check "its label names Python and says temporary"
       (let [l (py :label)]
         (and (truthy? (string/find "Python" l))
              (truthy? (string/find "temporary" l)))))
(check "the python provider is unavailable until an offline check passes"
       (not (truthy? (py :available))))
# Native stays unavailable, and its reason says the PIPELINE is unverified --
# not that no runtime exists, which would be false.
(def nat (provider/provider-info :terrain-diffusion-native))
(check "the native provider is unavailable"
       (not (truthy? (nat :available))))
(check "its reason says the pipeline is unverified"
       (and (string? (nat :reason))
            (truthy? (string/find "not verified" (nat :reason)))))
(check "an unavailable provider declares no controls"
       (empty? (nat :controls)))

#
# --- Controls are the real ones -----------------------------------------
#
(print "\ncontrols:")

(def py-controls (map |($ :id) (py :controls)))
# Exactly what tools/terrain_new_game.py accepts. No `steps`: the upstream
# pipeline runs a fixed denoise count, so a steps knob would change nothing.
(check "the python provider declares size, sea-level and profile"
       (= 3 (length py-controls)))
(check "size is a control"
       (truthy? (some |(= :size $) py-controls)))
(check "sea-level is a control"
       (truthy? (some |(= :sea-level $) py-controls)))
(check "profile is a control"
       (truthy? (some |(= :profile $) py-controls)))
(check "there is NO steps control, because steps cannot be changed"
       (nil? (some |(= :steps $) py-controls)))
# Size moves in whole tiles: the artifact is tiled, so a size between tiles would
# produce a map the reader rejects.
(check "size declares a tile step"
       (= 16 ((first (filter |(= :size ($ :id)) (py :controls))) :step)))
(check "profile is a choice control limited to the real profile"
       (let [c (first (filter |(= :profile ($ :id)) (py :controls)))]
         (and (= :choice (c :type))
              (= 1 (length (c :choices)))
              (= "alpine" (first (c :choices))))))

#
# --- Settings cannot leak between providers -----------------------------
#
(print "\nsettings:")

(check "procedural accepts its own controls"
       (= 1.0 ((provider/validate-settings :procedural {:height-scale 1.0})
               :height-scale)))
# THE LEAK RULE. A procedural knob handed to the python provider must be refused,
# not silently accepted into a world whose screen never showed it.
(check "a procedural setting is refused by the python provider"
       (refuses? (fn [] (provider/validate-settings :terrain-diffusion-python
                                                    {:height-scale 1.5}))))
(check "a python setting is refused by procedural"
       (refuses? (fn [] (provider/validate-settings :procedural {:size 128}))))
# SCHEMA AND AVAILABILITY ARE DIFFERENT QUESTIONS. `validate-settings` asks only
# whether a value is inside what the provider declares; `assert-generatable` asks
# whether it can run. Conflating them is how a SAVED world becomes unopenable the
# moment its provider is unavailable -- a player who generated a map and then lost
# the Python environment could no longer open their own map.
(check "validate-settings accepts an unavailable provider's schema"
       (let [v (try (do (provider/validate-settings :terrain-diffusion-native nil)
                        :accepted)
                    ([_] :refused))]
         (= :accepted v)))
(check "assert-generatable refuses that same provider"
       (refuses? (fn [] (provider/assert-generatable :terrain-diffusion-native))))
(check "available? reports the generation answer, not the schema answer"
       (not (truthy? (provider/available? :terrain-diffusion-native))))
(check "static available? refuses an unverified Python provider"
       (not (truthy? (provider/available? :terrain-diffusion-python))))
(check "static assert-generatable refuses an unverified Python provider"
       (refuses? (fn [] (provider/assert-generatable :terrain-diffusion-python))))
(check "procedural provider remains generatable"
       (= :procedural (provider/assert-generatable :procedural)))
(check "validate-settings still refuses an unknown provider"
       (refuses? (fn [] (provider/validate-settings :no-such-provider nil))))
(check "an unknown provider is refused"
       (refuses? (fn [] (provider/validate-settings :no-such-provider nil))))

(check "python defaults are complete"
       (let [s (provider/validate-settings :terrain-diffusion-python nil)]
         (and (= 128 (s :size)) (= 28 (s :sea-level)) (= "alpine" (s :profile)))))
(check "a size between tiles is refused"
       (refuses? (fn [] (provider/validate-settings :terrain-diffusion-python
                                                    {:size 130}))))
(check "a size off the declared step is refused even inside the range"
       (refuses? (fn [] (provider/validate-settings :terrain-diffusion-python
                                                    {:size 40}))))
(check "a tile-aligned size inside the range is accepted"
       (= 144 ((provider/validate-settings :terrain-diffusion-python {:size 144})
               :size)))
(check "a size past the maximum is refused"
       (refuses? (fn [] (provider/validate-settings :terrain-diffusion-python
                                                    {:size 1024}))))
(check "an unknown profile is refused"
       (refuses? (fn [] (provider/validate-settings :terrain-diffusion-python
                                                    {:profile "tundra"}))))
(check "a fractional sea level is refused"
       (refuses? (fn [] (provider/validate-settings :terrain-diffusion-python
                                                    {:sea-level 28.5}))))

#
# --- World seed 0 is mapped, not randomised -----------------------------
#
(print "\nseed mapping:")

# World seed 0 is a LEGAL world seed. The provider refuses it because upstream
# reads a falsy seed as "draw something random", which would make the recorded
# seed a lie. Mapping it would be equally bad if it were silent, so the mapping is
# fixed, versioned, and returned alongside the model seed.
(def mapped (provider/python-model-seed 0))
(check "world seed 0 maps to a non-zero model seed"
       (pos? (get mapped 0)))
(check "the mapped seed is the documented constant"
       (= provider/python-seed-zero-model-seed (get mapped 0)))
(check "the mapping is versioned"
       (= provider/seed-mapping-version (get mapped 1)))
(check "the mapping is deterministic"
       (let [again (provider/python-model-seed 0)]
         (and (= (get mapped 0) (get again 0))
              (= (get mapped 1) (get again 1)))))
# A non-zero seed is used as-is and carries NO version, so a reader can tell a
# remapped world from an ordinary one without consulting anything else.
(def plain (provider/python-model-seed 7))
(check "a non-zero seed is used unchanged"
       (= 7 (get plain 0)))
(check "an unmapped seed reports no mapping version"
       (nil? (get plain 1)))
(check "the mapped seed differs from every ordinary seed it could collide with"
       (not= (get mapped 0) 0))
(check "a negative world seed is refused"
       (refuses? (fn [] (provider/python-model-seed -1))))
(check "a fractional world seed is refused"
       (refuses? (fn [] (provider/python-model-seed 1.5))))

#
# --- Per-session asynchronous readiness via shared job supervisor --------
#
(print "\nreadiness:")

# The existing test file is a harmless script path; hooks prevent executing it.
(def script "test/world-provider-test.janet")
(defn fixture [&opt fail-spawn]
  (def hooks @{:now 100 :spawn 0 :term 0 :kill 0 :argv nil :completion nil})
  (def opts {:slot @{:job nil}
             :spawn (fn [argv]
                      (put hooks :spawn (+ 1 (get hooks :spawn)))
                      (put hooks :argv argv)
                      (when fail-spawn (error "missing interpreter\nargv: fake-python --check\nnext row"))
                      {:pid 777})
             :watch (fn [proc completion] (put hooks :completion completion))
             :pump (fn [] nil)
             :clock (fn [] (get hooks :now))
             :term (fn [proc] (put hooks :term (+ 1 (get hooks :term))))
             :kill (fn [proc] (put hooks :kill (+ 1 (get hooks :kill))))})
  [hooks (provider/python-readiness-new
           {:python "fake-python" :script script :check-out "/tmp/inert check dir"
             :timeout-seconds 3
            :clock (fn [] (get hooks :now)) :job-opts opts})])
(defn py-runtime [probe]
  (first (filter |(= :terrain-diffusion-python (get $ :id))
                 (provider/providers-for-runtime probe))))
(let [[hooks probe] (fixture)]
  (check "unknown readiness never enables generation"
         (not (get (py-runtime probe) :available)))
  (check "unchecked registry is unavailable"
         (not (get (py-runtime nil) :available)))
  (check "the check starts as a nonblocking owned child"
         (= :checking (get (provider/python-readiness-start! probe) :state)))
  (check "only offline --check is passed without a shell"
         (deep= @["fake-python" script "--out" "/tmp/inert check dir" "--check"]
                 (get hooks :argv)))
  (check "checking does not enable provider"
         (not (get (py-runtime probe) :available)))
  (check "poll never waits for an incomplete child"
         (= :checking (get (provider/python-readiness-poll! probe) :state)))
  (put (get hooks :completion) :exit-code 0)
  (check "only a completed successful offline check enables provider"
         (= :verified (get (provider/python-readiness-poll! probe) :state)))
  (check "verified provider descriptor is available"
         (get (py-runtime probe) :available))
  (check "verified probe permits only the temporary Python generation"
         (= :terrain-diffusion-python
            (provider/assert-generatable :terrain-diffusion-python probe)))
  (check "static generation guard remains fail-closed"
         (refuses? (fn [] (provider/assert-generatable :terrain-diffusion-python))))
  (check "native descriptor remains unavailable"
         (not (get (first (filter |(= :terrain-diffusion-native (get $ :id))
                                  (provider/providers-for-runtime probe))) :available)))
  (check "static saved-world schema remains accepted when unchecked"
         (= "alpine" (get (provider/validate-settings
                             :terrain-diffusion-python nil) :profile)))
  (provider/python-readiness-close! probe)
  (check "closed check no longer advertises readiness"
         (not (get (py-runtime probe) :available))))
(let [[hooks probe] (fixture)]
  (provider/python-readiness-start! probe)
  (put (get hooks :completion) :exit-code 2)
  (check "nonzero exit leaves provider unavailable"
         (= :unavailable (get (provider/python-readiness-poll! probe) :state)))
  (check "failure reason preserves exit status"
         (truthy? (string/find "exit 2" (get probe :reason))))
  (check "nonzero error reason is short and single-line"
         (and (<= (length (get probe :reason)) 120)
              (nil? (string/find "\n" (get probe :reason))))))
(let [[hooks probe] (fixture true)]
  (check "spawn failure cannot enable provider"
         (= :unavailable (get (provider/python-readiness-start! probe) :state)))
  (check "spawn reason is actionable and bounded to one line"
         (and (truthy? (string/find "--terrain-python" (get probe :reason)))
              (<= (length (get probe :reason)) 120)
              (nil? (string/find "\n" (get probe :reason)))))
  (check "raw multiline spawn error remains available as detail"
         (truthy? (string/find "next row" (get probe :detail)))))
(let [[hooks probe] (fixture)]
  (provider/python-readiness-start! probe)
  (put hooks :now 103)
  (check "timeout immediately de-advertises availability"
         (= :unavailable (get (provider/python-readiness-poll! probe) :state)))
  (check "timeout asks supervisor to terminate owned process"
         (= 1 (get hooks :term)))
  (check "timeout reports itself before child is reaped"
         (truthy? (string/find "timed out" (get probe :reason))))
  (put hooks :now 108)
  (provider/python-readiness-poll! probe)
  (check "supervisor sends KILL after grace"
         (= 1 (get hooks :kill)))
  (put (get hooks :completion) :exit-code 137)
  (provider/python-readiness-poll! probe)
  (check "late timeout completion stays unavailable"
         (not (get (py-runtime probe) :available))))
(let [[hooks probe] (fixture)]
  (provider/python-readiness-start! probe)
  (put hooks :now 103)
  (put (get hooks :completion) :exit-code 0)
  (provider/python-readiness-poll! probe)
  (check "a zero exit observed at deadline cannot resurrect readiness"
         (not (get (py-runtime probe) :available))))
(let [[hooks probe] (fixture)]
  (provider/python-readiness-start! probe)
  (provider/python-readiness-cancel! probe)
  (check "cancel de-advertises immediately"
         (not (get (py-runtime probe) :available)))
  (check "cancel delegates TERM to owned supervisor"
         (= 1 (get hooks :term)))
  (put (get hooks :completion) :exit-code 0)
  (provider/python-readiness-poll! probe)
  (check "late cancelled success cannot mark ready"
         (not (get (py-runtime probe) :available))))
# A watcher failure after spawn must keep the exact handle reachable until a
# later emergency reap succeeds. These hooks never spawn an OS child.
(let [[hooks probe] (fixture)]
  (def shared-slot (get probe :slot))
  (def reap-ok @{:value false :count 0})
  (put probe :job-opts (merge @{} (get probe :job-opts)))
  (put (get probe :job-opts) :watch (fn [proc completion]
                                     (error "watch installation failed")))
  (put (get probe :job-opts) :direct-reap
       (fn [proc completion]
         (put reap-ok :count (+ 1 (get reap-ok :count)))
         (unless (get reap-ok :value) (error "reap unavailable"))
         (put completion :exit-code 137)
         137))
  (check "failed watcher retains owned readiness handle"
         (let [result (provider/python-readiness-start! probe)]
           (and (= :unavailable (get result :state))
                (get probe :job)
                (= (get shared-slot :job) (get probe :job)))))
  (check "unreaped readiness refuses a second start"
         (refuses? (fn [] (provider/python-readiness-start! probe))))
  (check "failed close retains handle and unavailable readiness"
         (let [result (provider/python-readiness-close! probe)]
           (and (= :unavailable (get result :state))
                (= (get shared-slot :job) (get probe :job))
                (truthy? (string/find "cleanup pending" (get result :reason)))
                (not (get (py-runtime probe) :available)))))
  (put reap-ok :value true)
  (check "later successful close releases exact owned handle"
         (let [result (provider/python-readiness-close! probe)]
           (and (= :unavailable (get result :state))
                (nil? (get shared-slot :job))
                (nil? (get probe :job))
                (= 3 (get reap-ok :count)))))
  (check "reaped readiness may attempt another check"
         (let [result (provider/python-readiness-start! probe)]
           (and (= :unavailable (get result :state))
                (= 2 (get hooks :spawn))
                (nil? (get shared-slot :job))
                (nil? (get probe :job))))))
(let [[hooks probe] (fixture)]
  (put probe :script "/tmp/no-such-terrain-check-564738")
  (check "missing script never spawns a child"
         (= :unavailable (get (provider/python-readiness-start! probe) :state)))
  (check "missing script explains the absence"
         (truthy? (string/find "missing" (get probe :reason))))
  (check "missing script did not spawn"
         (= 0 (get hooks :spawn))))

#
# --- Versioned settings: v1 frozen, v2 additive -------------------------
#
# The rule this section protects is that a saved world's generation is decided by
# a NAMED settings version, never by which keys happen to be present. v1 is every
# world already on disk; v2 is the same generator plus one authored control, and
# choosing v2 is the caller's explicit act.
#
(print "\nversioned settings:")

(check "version 1 remains the default for a versionless caller"
       (= 4 (length (keys (provider/validate-settings :procedural nil)))))
(check "version 2 carries exactly the fifth control"
       (= 5 (length (keys (provider/validate-settings :procedural nil 2)))))
(check "version 2's extra control is the clearing density"
       (= 0 ((provider/validate-settings :procedural nil 2) :clearing-density)))
# Inference is a RUNTIME convenience, not a licence to reinterpret a record. A
# versionless caller passing a clearing density is validated as v2; an EXPLICIT
# version 1 still refuses it, which is what the catalogue relies on.
(check "an explicit version 1 still refuses a clearing density"
       (refuses? (fn [] (provider/validate-settings :procedural {:clearing-density 10} 1))))
(check "a versionless clearing density is inferred as version 2"
       (= 5 (length (keys (provider/validate-settings :procedural {:clearing-density 10})))))
(check "a versionless table without clearings stays version 1"
       (= 4 (length (keys (provider/validate-settings :procedural {:sea-level 30})))))
(check "settings-version-for reports the inferred version"
       (and (= 1 (provider/settings-version-for :procedural {:sea-level 30}))
            (= 1 (provider/settings-version-for :procedural nil))
            (= 2 (provider/settings-version-for :procedural {:clearing-density 10}))))
(check "an unknown settings version is refused rather than defaulted"
       (refuses? (fn [] (provider/validate-settings :procedural nil 3))))
(check "an unknown settings version is refused by the descriptor too"
       (refuses? (fn [] (provider/settings-descriptor :procedural nil 3))))
(check "a v2 clearing density outside 0..100 is refused"
       (and (refuses? (fn [] (provider/validate-settings :procedural {:clearing-density -1} 2)))
            (refuses? (fn [] (provider/validate-settings :procedural {:clearing-density 101} 2)))))
(check "a fractional v2 clearing density is refused"
       (refuses? (fn [] (provider/validate-settings :procedural {:clearing-density 2.5} 2))))

# The descriptor is the identity input, so its version must be observable: that is
# what lets a catalogue tell a v2-at-0 world from a v1 world whose terrain is
# identical.
(check "the v1 descriptor reports version 1 and no clearing density"
       (let [d (provider/settings-descriptor :procedural nil)]
         (and (= 1 (get d :version)) (not (has-key? d :clearing-density)))))
(check "the v2 descriptor reports version 2 and the clearing density"
       (let [d (provider/settings-descriptor :procedural nil 2)]
         (and (= 2 (get d :version)) (= 0 (get d :clearing-density)))))
(check "the v1 descriptor keeps its seven keys"
       (= 7 (length (keys (provider/settings-descriptor :procedural nil)))))
(check "provider-defaults reports four controls at v1 and five at v2"
       (and (= 4 (length (keys (provider/provider-defaults :procedural))))
            (= 5 (length (keys (provider/provider-defaults :procedural 2))))))

# DISCOVERY. A world UI must be able to enumerate a version's controls from the
# registry rather than hardcoding them, or the menu and the validator drift.
(def proc (provider/provider-info :procedural))
(check "the registry row exposes both control lists"
       (and (= 4 (length (get proc :controls)))
            (= 5 (length (get proc :controls-v2)))))
(check "the registry row still reports its v1 version unchanged"
       (= 1 (get proc :version)))
(check "the registry row lists both settings versions"
       (= 2 (length (get proc :settings-versions))))
(check "controls-for returns the version's own list"
       (and (= 4 (length (provider/controls-for :procedural)))
            (= 5 (length (provider/controls-for :procedural 2)))))
(check "controls-for refuses an unknown version"
       (refuses? (fn [] (provider/controls-for :procedural 3))))
(check "controls-for refuses an unknown provider"
       (refuses? (fn [] (provider/controls-for :no-such-provider))))
# The discovered control is the one validation actually enforces, so a menu can
# render its label and bounds and be sure they describe a real constraint.
(check "the v2 control list names the clearing density with the validated bounds"
       (let [c (first (filter |(= :clearing-density ($ :id))
                              (provider/controls-for :procedural 2)))]
         (and c (= 0 (get c :min)) (= 100 (get c :max)) (= 0 (get c :default)))))

# TERRAIN BYTES. v2 at clearing 0 must produce exactly v1's bytes: the version
# names the settings contract, not a change in appearance, and a world must not
# change by being remade at a newer version.
(defn bytes-for [settings-version settings]
  (def b (buffer/new-filled world/chunk-volume 0))
  (provider/generate-into! :procedural b 0 0 1234 settings settings-version)
  (string b))
(check "v2 with every control at default is byte-identical terrain to v1"
       (= (bytes-for 1 nil) (bytes-for 2 nil)))
(check "v2 at clearing 0 is byte-identical to v1 even with forests on"
       (= (bytes-for 1 {:forest-density 45})
          (bytes-for 2 {:forest-density 45 :clearing-density 0})))
(check "v2 with clearings actually changes the decoration"
       (not= (bytes-for 2 {:forest-density 45})
             (bytes-for 2 {:forest-density 45 :clearing-density 30})))
# Measured over a REGION, not one chunk. A single chunk holds few anchors and many
# of them are supplied by neighbouring lattice cells whose trunks fall outside it,
# so a one-chunk wood count saturates at 17 and would make this assertion pass for
# the wrong reason; the suppression is only visible across a block of chunks.
(check "a higher clearing density leaves fewer trunks across a region"
       (let [count-wood (fn [st]
                          (var n 0)
                          (for cz 0 4
                            (for cx 0 4
                              (def b (buffer/new-filled world/chunk-volume 0))
                              (provider/generate-into! :procedural b cx cz 1234 st 2)
                              (set n (+ n (length (filter |(= $ world/block-wood) b))))))
                          n)]
         (> (count-wood {:forest-density 45 :clearing-density 10})
            (count-wood {:forest-density 45 :clearing-density 60}))))

#
# --- Result -------------------------------------------------------------
#
(if (zero? failures)
  (print "\nworld provider: ALL CHECKS PASSED")
  (do (printf "\nworld provider: %d FAILED" failures) (os/exit 1)))
