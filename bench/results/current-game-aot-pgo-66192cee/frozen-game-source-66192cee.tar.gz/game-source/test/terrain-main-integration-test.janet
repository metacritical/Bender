# main.janet terrain-cache integration: preflight, bounded queue, persistence.
#
# No window, no GPU and no Python backend run here. This suite imports
# `main.janet` as a MODULE: bender only auto-invokes `main` for the entry
# script, so importing it defines the preflight and cache helpers without
# starting the game or opening a raylib window. That is what makes the
# "refuses before display" guarantee testable at all -- the refusal lives in
# `cache-open`/`preflight-spawn`, which run before `rl/init-window`.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/terrain-main-integration-test.janet
#
# Fixtures build TDH2 tiles and manifests with explicit little-endian
# arithmetic rather than sharing the consumer's encoder: a fixture that reused
# the code under test would agree with it even when both were wrong.

(import ./../src/terrain-cache :as tc)
(import ./../src/terrain-identity :as ti)
(import ./../src/terrain-integrity :as integrity)
(import ./../src/world :as world)
(import ./../src/worldgen :as worldgen)
(import ./../src/stream :as stream)
(import ./../src/mesher :as mesher)
(import ./../src/region :as region)
(import ./../main :as game)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(var scratch-counter 0)
(defn scratch-dir []
  (++ scratch-counter)
  (def base (or (os/getenv "TMPDIR") "/tmp"))
  (def path (string base "/trinecraft-main-" (os/getpid) "-" scratch-counter))
  (os/mkdir path)
  path)

(defn rm-tree [path]
  (when (os/stat path)
    (each name (try (os/dir path) ([e] @[]))
      (def child (string path "/" name))
      (if (= :directory (os/stat child :mode))
        (rm-tree child)
        (try (os/rm child) ([e] nil))))
    (try (os/rm path) ([e] nil))))

#
# --- Fixture ------------------------------------------------------------
#

(defn- put-le-u32 [buf offset value]
  (put buf offset (% value 256))
  (put buf (+ offset 1) (% (math/floor (/ value 256)) 256))
  (put buf (+ offset 2) (% (math/floor (/ value 65536)) 256))
  (put buf (+ offset 3) (% (math/floor (/ value 16777216)) 256)))

(defn- put-le-i32 [buf offset value]
  (put-le-u32 buf offset (if (neg? value) (+ value 4294967296) value)))

(defn heights-for [cx cz]
  "256 x-fastest heights inside the 4..60 band, shifted per chunk."
  (def out (buffer/new-filled tc/payload-bytes 0))
  (for z 0 16
    (for x 0 16
      (put out (+ x (* 16 z))
           (+ 8 (% (+ (* 3 z) x (% (+ cx cz) 16)) 40)))))
  out)

(defn tile-for [cx cz heights]
  (def out (buffer/new-filled tc/tile-bytes 0))
  (put out 0 84) (put out 1 68) (put out 2 72) (put out 3 50)   # TDH2
  (put-le-i32 out 4 cx)
  (put-le-i32 out 8 cz)
  (put-le-u32 out 12 tc/payload-bytes)
  (put-le-u32 out 16 (integrity/crc32 (string heights)))
  (for i 0 32 (put out (+ 20 i) (% (+ i 7) 256)))
  (for i 0 tc/payload-bytes (put out (+ tc/header-bytes i) (get heights i)))
  out)

(defn write-bytes [path bytes]
  (def f (file/open path :wbn))
  (file/write f bytes)
  (file/close f))


(def fixture-identity (string/repeat "b" 64))

(defn write-manifest [dir &opt identity seed]
  (write-bytes (string dir "/manifest.janet")
               (string "{:format 2 :magic \"TDH2\" :identity \""
                      (or identity fixture-identity)
                      "\" :seed " (or seed game/seed)
                      " :payload-bytes 256 :tile-bytes 308}")))

(defn tiles-dir! [dir]
  (def path (tc/tiles-dir dir))
  (try (os/mkdir path) ([e] nil))
  path)

(defn write-tile [dir cx cz &opt heights]
  (tiles-dir! dir)
  (def h (or heights (heights-for cx cz)))
  (write-bytes (tc/tile-path dir cx cz) (tile-for cx cz h)))



(defn identity-named-dir
  ``A scratch directory named by its identity, as a real cache root addresses
  generations. `cache-open` refuses a directory whose name is not the manifest
  identity, so every fixture that expects to open must be named this way --
  including the ones testing OTHER failures, or they would fail on the name
  before reaching the condition under test.``
  [&opt identity]
  (def parent (scratch-dir))
  (def dir (string parent "/" (or identity fixture-identity)))
  (os/mkdir dir)
  dir)

(defn full-cache []
  "A complete, seed-matching identity directory: all 25 spawn tiles."
  (def dir (identity-named-dir))
  (write-manifest dir)
  (each coord (game/spawn-tile-coords)
    (write-tile dir (coord 0) (coord 1)))
  dir)

(defn message-of [thunk]
  (def r (protect (thunk)))
  (cond (get r 0) nil
        (string? (get r 1)) (get r 1)
        true (string (get r 1))))

#
# --- 1. Preflight refuses before any window ----------------------------
#

# Every check in this section is a call to code that runs BEFORE
# `rl/init-window` in `main`, so a pass here is a real pre-display refusal.

(let [dir (identity-named-dir)]
  (def message (message-of (fn [] (game/cache-open dir))))
  (check "missing manifest refuses to open"
         (and message (not (nil? (string/find "manifest.janet" message))))
         message))

(let [dir (identity-named-dir)]
  (write-manifest dir fixture-identity (+ game/seed 1))
  (def message (message-of (fn [] (game/cache-open dir))))
  (check "wrong-seed cache refuses to open"
         (and message (not (nil? (string/find "seed" message))))
         message))

(let [dir (identity-named-dir)]
  (write-manifest dir "not-a-digest")
  (def message (message-of (fn [] (game/cache-open dir))))
  (check "malformed identity refuses to open" (not (nil? message)) message))

(let [dir (identity-named-dir)]
  (write-manifest dir)
  (write-bytes (string dir "/manifest.janet") "{:format 2 :magic \"TDH2\" :identity \""
               )
  (check "truncated manifest is not accepted"
         (not (nil? (message-of (fn [] (game/cache-open dir)))))))

#
# --- 2. All 25 spawn tiles required ------------------------------------
#
(let [dir (full-cache)
      cache (game/cache-open dir)]
  (def [missing corrupt remaining _] (game/spawn-tiles-missing cache))
  (check "complete fixture has no missing spawn tiles" (empty? missing))
  (check "complete fixture has no corrupt spawn tiles" (empty? corrupt))
  (check "preflight passes on a complete fixture"
         (= cache (game/preflight-spawn cache))))

# One tile short: the run must refuse and must have ASKED for it, without
# waiting for an answer.
(let [dir (full-cache)
      victim (tc/tile-path dir 2 2)]
  (os/rm victim)
  (def cache (game/cache-open dir))
  (def message (message-of (fn [] (game/preflight-spawn cache))))
  (check "incomplete fixture refuses preflight" (not (nil? message)))
  (check "incomplete message is actionable"
         (and message
              (not (nil? (string/find "Run the terrain worker/bake" message))))
         message)
  (check "incomplete message names the missing count"
         (and message (not (nil? (string/find "missing 1 of 25" message))))
         message)
  (check "missing tile was requested, not filled from noise"
         (not (nil? (os/stat (tc/request-path dir 2 2))))
         nil)
  (check "no tile was fabricated by preflight"
         (nil? (os/stat victim))))

# A present but undecodable tile is a different failure from a miss: asking
# again cannot repair it, so the message must say damaged, not "rerun the bake".
(let [dir (full-cache)]
  (def bytes (buffer/new-filled tc/tile-bytes 0))
  (write-bytes (tc/tile-path dir -1 0) bytes)
  (def cache (game/cache-open dir))
  (def message (message-of (fn [] (game/preflight-spawn cache))))
  (check "corrupt spawn tile refuses preflight" (not (nil? message)))
  (check "corrupt message points at the damaged coordinate"
         (and message
              (not (nil? (string/find "damaged spawn tile at (-1,0)" message))))
         message))

# A tile whose payload is outside the height band is corrupt even though its
# length, magic and CRC are consistent -- the decoder, not the fixture, is what
# guarantees the band.
(let [dir (full-cache)]
  (def bad (heights-for 0 0))
  (put bad 0 99)
  (write-tile dir 0 0 bad)
  (def cache (game/cache-open dir))
  (check "out-of-band height refuses preflight"
         (not (nil? (message-of (fn [] (game/preflight-spawn cache)))))))

#
# --- 2b. Preflight probing is BOUNDED ---------------------------------
#
# The requested property: a missing-tile preflight must not issue more than a
# fixed number of filesystem probes in one pass, no matter how many tiles the
# spawn area has. These pass an explicit small budget and count what was
# examined, so the bound is asserted rather than inferred from 25 being small.
(let [dir (full-cache)
      cache (game/cache-open dir)]
  # Nothing exists for coordinates far outside this fixture, so a bounded pass
  # over a budget of 4 must examine exactly 4 and report the remainder.
  (def [missing corrupt remaining examined] (game/spawn-tiles-missing cache 4 0))
  (check "a budgeted pass examines at most the budget"
         (= 4 (length examined)) (string (length examined)))
  (check "a budgeted pass reports the unexamined remainder"
         (= (- 25 4) remaining) (string remaining))
  (check "a budgeted pass does not report unexamined coords as missing"
         (zero? (length missing)) (string (length missing)))
  (check "the budget is a hard 4, not a rounding"
         (<= (length examined) 4))
  # The NEXT pass resumes exactly where the last stopped: no coordinate is
  # probed twice and none is skipped.
  (def [m2 c2 remaining2 examined2] (game/spawn-tiles-missing cache 4 4))
  (check "the next pass resumes after the previous one"
         (= 4 (length examined2)) (string (length examined2)))
  (check "resumed passes make disjoint progress"
         (not= (string examined) (string examined2)))
  (check "the remainder shrinks by the budget"
         (= (- remaining 4) remaining2) (string remaining2))
  # Walking the whole set in bounded passes covers every coordinate exactly
  # once, and at the shipped radius the default budget finishes in one pass.
  (var seen @{})
  (var from 0)
  (var passes 0)
  (while (< from 25)
    (def [_ _ _ examined3] (game/spawn-tiles-missing cache 4 from))
    (each coord examined3 (put seen (string coord) true))
    (set from (+ from (max 1 (length examined3))))
    (++ passes))
  (check "bounded passes together examine all 25 spawn coordinates"
         (= 25 (length seen)) (string (length seen)))
  (check "walking the spawn set takes ceil(25/4) = 7 passes"
         (= 7 passes) (string passes))
  # The production budget admits the shipped spawn area in a single pass --
  # small enough to be bounded, large enough not to pay several round trips.
  (check "the shipped probe budget covers all spawn tiles in one pass"
         (<= 25 game/preflight-probe-budget) (string game/preflight-probe-budget)))

#
# --- 2c. The cache directory must be named by its identity ------------
#
# A cache root addresses generations by directory name, so a manifest sitting
# in a differently-named directory means a copied or renamed tree: exactly how
# one generation's tiles would be served under another's name.
(let [parent (scratch-dir)
      wrongly-named (string parent "/not-the-identity")]
  (os/mkdir wrongly-named)
  (write-manifest wrongly-named)
  (def message (message-of (fn [] (game/cache-open wrongly-named))))
  (check "a directory named differently from its manifest is refused"
         (not (nil? message)) message)
  (check "the refusal names both the directory and the identity"
         (and message
              (not (nil? (string/find "not-the-identity" message)))
              (not (nil? (string/find fixture-identity message))))
         message)
  (check "the refusal explains why it matters"
         (and message (not (nil? (string/find "attributable" message))))
         message))

# The correctly-named directory opens, so the check rejects names and not the
# fixture itself.
(let [dir (full-cache)]
  (check "a directory named by its identity opens"
         (not (nil? (game/cache-open dir)))))

#
# --- 3. Bounded, idempotent, non-throwing queue ------------------------
#
(defn rm-ignoring [path]
  (try (os/rm path) ([e] nil)))

(let [dir (full-cache)
      cache (game/cache-open dir)
      # The fixture only bakes the 25 spawn tiles, so the removed ring must
      # lie inside that set: coordinates outside it were never written.
      ring [[2 2] [-2 2] [2 -2] [-2 -2] [0 2] [2 0]]]
  (each coord ring (rm-ignoring (tc/tile-path dir (coord 0) (coord 1))))
  (def outcomes @[])
  (each coord ring
    (array/push outcomes (tc/request cache (coord 0) (coord 1))))
  (check "absent tiles are requested" (all |(= :requested $) outcomes)
         (string/join (map string outcomes) ","))
  (def again (tc/request cache 2 2))
  (check "re-requesting is suppressed, not duplicated"
         (= :suppressed again) (string again))
  (check "pending queue is bounded by capacity"
         (<= (length (cache :pending)) (cache :capacity)))
  # Poll is bounded and must never throw, even with nothing ready.
  (def polls (tc/poll cache game/poll-limit))
  (check "poll with no ready tile returns an empty, not an error" (empty? polls))
  (check "poll limit is a small bound"
         (and (number? game/poll-limit) (<= 1 game/poll-limit 8))
         (string game/poll-limit))
  # Now publish one of the requested tiles and confirm it is collected.
  (write-tile dir 2 2)
  (tc/request cache 2 2)
  (def collected (tc/poll cache game/poll-limit))
  (check "a published tile is collected by poll"
         (truthy? (some (fn [r] (and (= :ready (get r 0)) (= 2 (get r 1)))) collected)))
  (check "collected heights are the fixture's"
         (let [r (find (fn [r] (and (= :ready (get r 0)) (= 2 (get r 1)))) collected)]
           (and r (= (string (heights-for 2 2)) (string (get r 3)))))))

# A backend error file must turn into one bounded error result, never an
# exception on the frame path.
(let [dir (full-cache)
      cache (game/cache-open dir)]
  (rm-ignoring (tc/tile-path dir 1 1))
  (try (os/mkdir (tc/errors-dir dir)) ([e] nil))
  (write-bytes (tc/error-path dir 1 1) "backend exploded\n")
  (check "failed coordinate is suppressed rather than retried"
         (= :suppressed (tc/request cache 1 1)))
  (def message (message-of (fn [] (tc/read-height-tile cache 1 1))))
  (check "reading a failed coordinate reports the backend reason"
         (and message (not (nil? (string/find "backend exploded" message))))
         message))

#
# --- 3b. A request the cache REFUSED is not "requested" ---------------
#
# Out-of-range outcomes (capacity full, unwritable requests directory) must not
# be reported as though the worker had been told what to bake: that sends the
# operator to wait on a coordinate that was never announced.
(let [dir (full-cache)
      cache (game/cache-open dir)]
  (check "requesting an empty set publishes nothing"
         (empty? (game/request-spawn-tiles cache @[])))
  (def keep-dir dir)
  # Capacity-full is reported as its own condition, naming it explicitly.
  (def small (tc/cache-new dir game/seed 1))
  (def outcomes (game/request-spawn-tiles small [[40 40] [41 41]]))
  (check "outcomes are recorded per coordinate" (= 2 (length outcomes)))
  (def summary (game/request-failure-summary outcomes small))
  (check "a queued-away request is reported, not counted as asked"
         (and summary (not (nil? (string/find "NOT requested" summary)))) summary)
  (check "the report names the capacity"
         (and summary (not (nil? (string/find "pending queue is full" summary))))
         summary)
  # A successful request produces no failure summary at all. A fresh consumer
  # is needed: `small` above is already at capacity, so any further coordinate
  # would be reported as queued (correctly).
  (def fresh (tc/cache-new dir game/seed 4))
  (def ok-outcomes (game/request-spawn-tiles fresh [[42 42]]))
  (check "a genuinely published request reports no problem"
         (nil? (game/request-failure-summary ok-outcomes fresh))
         (string (game/request-failure-summary ok-outcomes fresh))))

# An unwritable requests directory must surface as an error, not silence.
(let [dir (full-cache)
      cache (game/cache-open dir)]
  # A regular file where requests/ must be a directory: mkdir fails, so the
  # marker cannot be published.
  (write-bytes (tc/requests-dir dir) "not a directory")
  (def outcomes (game/request-spawn-tiles cache [[7 7]]))
  (def summary (game/request-failure-summary outcomes cache))
  (check "an unwritable requests directory is reported"
         (not (nil? summary)) summary)
  (check "the report carries the underlying filesystem reason"
         (and summary (not (nil? (string/find "request" summary)))) summary))

#
# --- 3c. Results for coordinates outside the wanted set are rejected ---
#
# `poll` returns whatever resolved from a queue that outlives the player's
# position. `wanted-key-set` is the membership test the frame loop applies, so
# a tile for a coordinate the player has left must not be adopted -- otherwise
# the world grows without bound and a just-dropped chunk can be resurrected.
(let [wanted (stream/chunks-in-radius 0 0 2)
      set (game/wanted-key-set wanted)]
  (check "the wanted set is non-empty" (pos? (length set)))
  (check "a coordinate inside the radius is a member"
         (truthy? (get set (world/chunk-key 0 0))))
  (check "a coordinate at the radius edge is a member"
         (truthy? (get set (world/chunk-key 2 0))))
  (check "a coordinate just outside the radius is NOT a member"
         (not (truthy? (get set (world/chunk-key 3 0)))))
  (check "a far-away coordinate is NOT a member"
         (not (truthy? (get set (world/chunk-key 40 40)))))
  # The membership test is by VALUE, so an independently constructed tuple
  # answers the same way as one taken from the radius list itself.
  (check "membership does not depend on tuple identity"
         (truthy? (get set [0 0])))
  # A different centre has a different membership, so the set is rebuilt from
  # the CURRENT wanted list rather than cached forever.
  (def moved (game/wanted-key-set (stream/chunks-in-radius 30 30 2)))
  (check "the membership follows the current wanted list"
         (and (truthy? (get moved (world/chunk-key 30 30)))
              (not (truthy? (get moved (world/chunk-key 0 0)))))))

#
# --- 4. World construction uses the tile adapter ----------------------
#
# `generate-from-heights` is the only worldgen entry the cache path may use.
# Prove the heights a tile carries are what the chunk actually contains, so a
# later change cannot quietly route cached terrain back through the noise
# generator.
(let [dir (full-cache)
      cache (game/cache-open dir)
      w (world/world-new)]
  (def made (game/generate-chunk-from-cache w cache 0 0))
  (check "a cached tile produces a chunk" (not (nil? made)))
  (check "the chunk is registered in the world"
         (not (nil? (world/world-get-chunk w 0 0))))
  (def ch (world/world-get-chunk w 0 0))
  (def heights (heights-for 0 0))
  (def expected (buffer/new-filled world/chunk-volume 0))
  (worldgen/generate-from-heights expected 0 0 heights)
  (check "cached chunk blocks match generate-from-heights exactly"
         (= (string expected) (string (ch :blocks))))
  # The tile heights must actually differ from what the procedural generator
  # would produce here, or this check would pass even on a noise fallback.
  (def noise (buffer/new-filled world/chunk-volume 0))
  (worldgen/generate-into noise 0 0 game/seed)
  (check "cached terrain is distinguishable from procedural terrain"
         (not= (string expected) (string noise)))
  # A coordinate with no tile must miss rather than invent terrain.
  (check "a missing tile produces no chunk"
         (nil? (game/generate-chunk-from-cache w cache 40 40)))
  (check "a missing tile leaves the world untouched"
         (nil? (world/world-get-chunk w 40 40))))

#
# --- 5. Void guard ----------------------------------------------------
#
# The guard's decision is a pure predicate, so it is testable without a window:
# the frame loop restores a position snapshot when it returns false.
(let [w (world/world-new)
      ch (world/chunk-new 0 0)]
  (world/world-put-chunk w ch)
  (check "a player inside a loaded chunk is grounded"
         (game/footprint-loaded? w 8.0 8.0))
  (check "a player at a chunk edge still fits inside that chunk"
         (game/footprint-loaded? w 0.4 8.0))
  # The centre is inside chunk 0 but the box straddles chunk -1, which is
  # absent: this is exactly the hole the guard exists for.
  (check "a box straddling into an unloaded neighbour is refused"
         (not (game/footprint-loaded? w 0.0 8.0)))
  (check "a player well inside an unloaded chunk is refused"
         (not (game/footprint-loaded? w 40.0 8.0)))
  (check "a far negative coordinate is refused"
         (not (game/footprint-loaded? w -400.0 -400.0)))
  # Once the neighbour arrives the same position becomes valid again, so the
  # guard is not permanently sticky.
  (world/world-put-chunk w (world/chunk-new -1 0))
  (check "loading the neighbour makes the straddling position valid"
         (game/footprint-loaded? w 0.0 8.0))
  # Diagonal neighbours count too: a corner can touch four chunks at once.
  (let [w2 (world/world-new)]
    (world/world-put-chunk w2 (world/chunk-new 0 0))
    (world/world-put-chunk w2 (world/chunk-new -1 0))
    (world/world-put-chunk w2 (world/chunk-new 0 -1))
    (check "a corner missing its diagonal neighbour is refused"
           (not (game/footprint-loaded? w2 0.0 0.0)))
    (world/world-put-chunk w2 (world/chunk-new -1 -1))
    (check "all four diagonal chunks loaded makes the corner valid"
           (game/footprint-loaded? w2 0.0 0.0))))

#
# --- 6. Identity gate and legacy provenance ---------------------------
#
# These pin the persistence rules `main`'s save/load verbs depend on. The verbs
# themselves need a live game; the decisions they make are these functions.
(defn crc-of [path]
  (integrity/crc32 (string (file/read (file/open path :rb) :all))))

(let [region (string (scratch-dir) "/legacy.trcr")]
  (write-bytes region "TRCR bytes")
  # No sidecar: unknown provenance.
  (def noise (ti/noise-identity game/seed))
  (def verdict (ti/gate region noise (crc-of region)))
  (check "legacy region with no sidecar is unverifiable for noise"
         (= :unverifiable (verdict :status)) (string (verdict :status)))
  (check "unverifiable legacy region is loadable in a noise session"
         (ti/loadable? region noise (crc-of region)))
  # A diffusion session must NOT adopt unknown provenance.
  (def diffusion (ti/diffusion-identity fixture-identity game/seed))
  (check "diffusion session refuses an unknown-provenance region"
         (= :mismatch ((ti/gate region diffusion (crc-of region)) :status)))
  # Writing a sidecar for those bytes is what would falsely relabel them, so
  # the rule under test is that main skips the sidecar rather than claiming it.
  # `write-atomic` itself allows the first claim; main's :unknown provenance is
  # the guard.
  (check "gate never reports :match for an absent sidecar"
         (not= :match (ti/gate region noise (crc-of region))))
  # The identity string is the ONE comparison unit every load/save gate uses, so
  # its exact spelling is the contract, not a formatting detail. Storage pinned
  # v2 on the 256-high engine (c3ff584): a generation profile is now part of the
  # string, because a v1 noise/diffusion sidecar describes 64-high terrain and
  # must never authorize a 256-high session even when the seed and digest agree.
  (check "a diffusion identity round-trips to its exact digest string"
         (= (string "diffusion:h256:" fixture-identity ":" game/seed)
            (ti/identity-string diffusion)))
  # Spelled out separately so a silent return to the v1 form -- which would
  # re-authorize old 64-high regions -- fails here rather than only in the
  # identity suite.
  (check "the diffusion string carries the 256-high profile pin"
         (not= (string "diffusion:" fixture-identity ":" game/seed)
               (ti/identity-string diffusion))))

(let [region (string (scratch-dir) "/pinned.trcr")]
  (write-bytes region "TRCR bytes")
  (def noisy (ti/noise-identity game/seed))
  (ti/write-atomic region noisy (crc-of region))
  (def reread (ti/read region (crc-of region)))
  (check "a written sidecar reads back present"
         (= :present (reread :status)) (string (reread :status)))
  (check "the sidecar's identity is the one written"
         (= (ti/identity-string noisy) (ti/identity-string (reread :identity))))
  # A different generation must be refused rather than overwritten.
  (def other (ti/diffusion-identity fixture-identity game/seed))
  (check "write-atomic refuses a different identity"
         (not (nil? (message-of (fn [] (ti/write-atomic region other (crc-of region)))))))
  # Bytes changed under the sidecar: stale, which is refused for loading.
  (write-bytes region "TRCR other bytes")
  (check "changed bytes make the sidecar stale"
         (= :stale ((ti/gate region noisy (crc-of region)) :status)))
  (check "stale region is not loadable"
         (not (ti/loadable? region noisy (crc-of region)))))

#
# --- 7. Save gating and the legacy-provenance rule --------------------
#
# `save-permitted?` is the whole decision the `save` verb makes before it
# touches a file, so these are the real rules, not a reconstruction.

(let [root (scratch-dir)
      target (string root "/w.trcr")
      identity (ti/noise-identity game/seed)]
  (check "a first save to a new path is permitted"
         (= :ok (get (game/save-permitted? target identity 0) 0)))
  (write-bytes target "TRCR legacy bytes")
  (def bytes-crc (crc-of target))
  # Unknown provenance, and this session did not load it: refuse.
  (def verdict (game/save-permitted? target identity bytes-crc))
  (check "an untouched legacy region is refused a blind overwrite"
         (= :refuse (get verdict 0)) (string (get verdict 0)))
  (check "the refusal explains why"
         (not (nil? (get verdict 1))) (string (get verdict 1)))
  # Unknown provenance, but THIS session loaded exactly this file: allowed, so
  # a legacy world stays writable without being relabelled.
  (check "re-saving a region this session loaded is permitted"
         (= :ok (get (game/save-permitted? target identity bytes-crc target) 0)))
  (check "that permission does not extend to a different path"
         (= :refuse (get (game/save-permitted? target identity bytes-crc
                                               (string root "/other.trcr")) 0)))
  # Once a sidecar pins this identity, the same path is allowed without the
  # legacy exception.
  (ti/write-atomic target identity bytes-crc)
  (check "a correctly pinned region is permitted without the exception"
         (= :ok (get (game/save-permitted? target identity (crc-of target)) 0)))
  # A sidecar for a different generation must refuse even at that path.
  (def other (ti/diffusion-identity fixture-identity game/seed))
  (try (os/rm (ti/sidecar-path target)) ([e] nil))
  (ti/write-atomic target other (crc-of target))
  (check "a region pinned to another generation is refused"
         (= :refuse (get (game/save-permitted? target identity (crc-of target)) 0)))
  # Bytes changed under a valid sidecar: stale, so refused.
  (try (os/rm (ti/sidecar-path target)) ([e] nil))
  (ti/write-atomic target identity (crc-of target))
  (write-bytes target "TRCR different bytes entirely")
  (check "a stale region is refused"
         (= :refuse (get (game/save-permitted? target identity (crc-of target)) 0))))

#
# --- 8. Session identity ----------------------------------------------
#
(let [noise (game/session-identity nil game/seed)]
  (check "a procedural session's identity is a noise identity"
         (not (nil? (string/find "noise:" (ti/identity-string noise))))))

#
# --- 9. Decode from the validated buffer, not a second read -----------
#
# The load path gates a CRC of bytes it read, then adopts chunks. If those
# chunks came from a SECOND read of the path, a file replaced between the two
# reads passes the gate on its old content and installs its new content. The
# fix decodes the validated buffer, so gated and adopted bytes are identical by
# construction. These pin that: the decoder must consume the bytes it is given
# and never consult the path.
(let [root (scratch-dir)
      region-path (string root "/src.trcr")
      world-a (world/world-new)
      world-b (world/world-new)]
  # Two regions with the same shape but different heights, so decoding the
  # wrong one is visible in the block data rather than merely plausible.
  (def ch-a (world/chunk-new 0 0))
  (buffer/fill (ch-a :blocks) world/block-stone)
  (world/world-put-chunk world-a ch-a)
  (def ch-b (world/chunk-new 0 0))
  (buffer/fill (ch-b :blocks) world/block-sand)
  (world/world-put-chunk world-b ch-b)
  (region/save-world region-path world-a)
  (def bytes-a (region/read-file region-path))
  (region/save-world region-path world-b)
  # The file on disk is now world-b, but the validated bytes are world-a.
  (def decoded (game/decode-region-bytes bytes-a))
  (check "the decoder produced the region's chunks" (= 1 (length decoded)))
  (check "decoded blocks come from the SUPPLIED bytes, not the path"
         (= world/block-stone (get (get (get decoded 0) :blocks) 0))
         (string (get (get (get decoded 0) :blocks) 0)))
  (check "the file on disk still holds the other content"
         (= world/block-sand
            (get (get (get (region/load-region region-path) 0) :blocks) 0)))
  # A truncated buffer must fail during decode, i.e. before any caller could
  # have mutated a world.
  (check "a truncated validated buffer fails to decode"
         (not (nil? (message-of (fn [] (game/decode-region-bytes
                                          (region/slice-bytes bytes-a 0 20)))))))
  (check "a buffer with a broken index fails to decode"
         (not (nil? (message-of (fn [] (game/decode-region-bytes "TRCR junk")))))))

# The end-to-end property: gating then decoding the SAME buffer is consistent
# even when the path is rewritten in between, which is exactly the race.
(let [root (scratch-dir)
      region (string root "/race.trcr")
      identity (ti/noise-identity game/seed)
      w1 (world/world-new)]
  (def ch (world/chunk-new 0 0))
  (buffer/fill (ch :blocks) world/block-stone)
  (world/world-put-chunk w1 ch)
  (region/save-world region w1)
  (def gated-bytes (region/read-file region))
  (def gated-crc (integrity/crc32 gated-bytes))
  (ti/write-atomic region identity gated-crc)
  (def verdict (ti/gate region identity gated-crc))
  (check "the original bytes pass the gate"
         (= :match ((ti/gate region identity (integrity/crc32 gated-bytes))
                    :status)))
  # Rewrite the file behind the gate, then confirm that (a) the gated buffer
  # still decodes to the gated content, and (b) a fresh gate on the NEW bytes
  # does NOT match -- so the only safe adoption is the buffer that was gated.
  (def w2 (world/world-new))
  (def ch2 (world/chunk-new 0 0))
  (buffer/fill (ch2 :blocks) world/block-leaves)
  (world/world-put-chunk w2 ch2)
  (region/save-world region w2)
  (def now-crc (integrity/crc32 (region/read-file region)))
  (check "the rewrite is detected by the sidecar"
         (not= :match ((ti/gate region identity now-crc) :status))
         (string ((ti/gate region identity now-crc) :status)))
  (check "the gated buffer still decodes to the gated content"
         (= world/block-stone
            (get (get (get (game/decode-region-bytes gated-bytes) 0) :blocks) 0)))
  (check "the rewritten file decodes to different content"
         (= world/block-leaves
            (get (get (get (game/decode-region-bytes (region/read-file region)) 0)
                      :blocks) 0))))

#
# --- 10. Unknown provenance must not leave a stale sidecar ------------
#
# A session holding unknown-provenance contents writes no sidecar. Overwriting
# a path that HAS one would leave that sidecar pinning bytes that no longer
# exist, so the region and its identity record would disagree permanently with
# nothing left to repair them.
(let [root (scratch-dir)
      target (string root "/pinned.trcr")
      identity (ti/noise-identity game/seed)]
  (write-bytes target "TRCR original bytes")
  (ti/write-atomic target identity (crc-of target))
  (check "the path is pinned before the test" (not (nil? (os/stat (ti/sidecar-path target)))))
  # A KNOWN-provenance session may rewrite it: its sidecar is refreshed.
  (check "a known-provenance session may rewrite a pinned path"
         (= :ok (get (game/save-permitted? target identity (crc-of target)) 0)))
  # An UNKNOWN-provenance session must not, even though the gate would pass --
  # it writes no sidecar, so the existing pin would go stale.
  (def verdict (game/save-permitted? target identity (crc-of target) nil true))
  (check "an unknown-provenance session may not overwrite a pinned path"
         (= :refuse (get verdict 0)) (string (get verdict 0)))
  (check "the refusal explains the stale-sidecar consequence"
         (and (not (nil? (get verdict 1)))
              (not (nil? (string/find "sidecar" (get verdict 1)))))
         (string (get verdict 1)))
  # An unpinned existing path is still allowed for that session: there is no
  # sidecar to leave behind, so nothing becomes stale.
  (def unpinned (string root "/unpinned.trcr"))
  (write-bytes unpinned "TRCR legacy bytes")
  (check "an unknown-provenance session may re-save the unpinned file it loaded"
         (= :ok (get (game/save-permitted? unpinned identity (crc-of unpinned)
                                           unpinned true) 0)))
  # A brand-new path is always fine: a first save creates whatever it needs.
  (check "a new path is permitted even with unknown provenance"
         (= :ok (get (game/save-permitted? (string root "/brand-new.trcr")
                                           identity 0 nil true) 0))))

#
# --- 11. The wanted walk must rotate, not restart at zero ------------
#
# The defect: the generation loop began at index 0 every frame, so an
# already-pending coordinate looked like a fresh one. The first few entries were
# re-probed forever and everything past the attempt limit was never reached --
# queue capacity unused, prefetch frontier starved. `cursor-slice` is that rule
# extracted, so it can be tested without a running game.
(let [[first-indices next] (game/cursor-slice 20 0 8)]
  (check "a pass from 0 examines the first 8 indices"
         (= "(0 1 2 3 4 5 6 7)" (string/format "%p" (tuple ;first-indices)))
         (string/format "%p" (tuple ;first-indices)))
  (check "the pass is bounded to the limit"
         (= 8 (length first-indices)) (string (length first-indices)))
  (check "the cursor resumes where the pass stopped" (= 8 next) (string next)))

# With more than 8 missing coordinates, successive calls must make progress
# through the whole list rather than repeating the head.
(let [count 20
      limit 8]
  (var cursor 0)
  (def seen @{})
  (var calls 0)
  (while (< calls 3)
    (def [indices next] (game/cursor-slice count cursor limit))
    (check (string "call " calls " probes at most the limit")
           (<= (length indices) limit) (string (length indices)))
    (each i indices (put seen i true))
    (set cursor next)
    (++ calls))
  (check "three bounded passes cover 24 slots of a 20-wide list"
         (= 20 (length seen)) (string (length seen)))
  # Crucially: entry 0 is NOT re-probed on every call.
  (def [second-indices _] (game/cursor-slice count 8 limit))
  (check "the second pass does not repeat index 0"
         (not (some |(= 0 $) second-indices)) (string second-indices))
  (check "the second pass starts where the first stopped"
         (= 8 (get second-indices 0)) (string (get second-indices 0))))

# No head starvation: every index in a long list is reached, and the LAST one
# is reached within the ceil(count/limit) passes that rotation promises.
(let [count 113
      limit 8]
  (var cursor 0)
  (def seen @{})
  (var passes 0)
  (while (< (length seen) count)
    (def [indices next] (game/cursor-slice count cursor limit))
    (each i indices (put seen i true))
    (set cursor next)
    (++ passes)
    (when (> passes 100) (break)))
  (check "every index of a 113-wide list is eventually examined"
         (= count (length seen)) (string (length seen)))
  (check "the tail is reached, not starved"
         (truthy? (get seen (- count 1))))
  (check "coverage takes ceil(113/8) = 15 passes"
         (= 15 passes) (string passes))
  (check "the pass count is the theoretical minimum"
         (= passes (math/ceil (/ count limit))) (string passes)))

# Rotation must not permanently skip a coordinate that becomes free later: a
# pass starting mid-list wraps and still reaches the front.
(let [[indices _] (game/cursor-slice 10 8 4)]
  (check "a pass past the middle wraps to the front"
         (= "(8 9 0 1)" (string/format "%p" (tuple ;indices)))
         (string/format "%p" (tuple ;indices))))

# A degenerate list must not throw or loop.
(check "an empty wanted list yields no indices"
         (nil? (game/cursor-slice 0 0 8)))
(let [[indices next] (game/cursor-slice 3 0 8)]
  (check "a limit larger than the list examines only the list"
         (= "(0 1 2)" (string/format "%p" (tuple ;indices)))
         (string/format "%p" (tuple ;indices)))
  (check "the cursor wraps to zero after a full sweep" (= 0 next) (string next)))

#
# --- 12. Loading state core -------------------------------------------
#
# The loading stage exists so the window can open before 25 tiles are ready.
# Its transitions are pure data, so ready / missing / failed / cancelled and the
# no-double-count guarantee are testable without a window, a GPU or a worker.

(defn loading-fixture
  "Loading state over a small spawn set, with a stub cache."
  [&opt n]
  (def coords @[])
  (for i 0 (or n 4) (array/push coords [i 0]))
  (game/loading-new nil coords))

# --- ready -------------------------------------------------------------
(let [st (loading-fixture 3)]
  (check "a new state starts in :probe"
         (= :probe (st :state)) (string (st :state)))
  (check "nothing is ready before a tile is observed"
         (zero? (game/loading-ready-count st)))
  (check "every spawn coordinate is outstanding initially"
         (= 3 (game/loading-outstanding st)))
  (for i 0 3
    (game/loading-record-tile st [:ready i 0 (buffer/new-filled 256 8)]))
  (check "three ready results make three tiles ready"
         (= 3 (game/loading-ready-count st)) (string (game/loading-ready-count st)))
  (check "ready tiles leave nothing outstanding"
         (zero? (game/loading-outstanding st)))
  (check "the advance rule moves to build-world when all tiles are ready"
         (= :build-world (get (game/loading-advance st) 0)))
  (check "the state itself is still :probe until entered"
         (= :probe (st :state))))

# --- no double count ---------------------------------------------------
# A tile observed twice must not become two tiles. This is the difference
# between counting decoded heights and counting observations.
(let [st (loading-fixture 2)
      h (buffer/new-filled 256 8)]
  (game/loading-record-tile st [:ready 0 0 h])
  (game/loading-record-tile st [:ready 0 0 h])
  (game/loading-record-tile st [:ready 0 0 h])
  (check "a re-observed tile is counted once"
         (= 1 (game/loading-ready-count st)) (string (game/loading-ready-count st)))
  (check "a re-observed tile still leaves one outstanding"
         (= 1 (game/loading-outstanding st)) (string (game/loading-outstanding st)))
  (check "the stored heights are the decoded ones"
         (= h (get (st :heights) (game/loading-key 0 0)))))

# --- missing -----------------------------------------------------------
# Missing tiles must not advance the stage, and must remain requestable.
(let [st (loading-fixture 4)]
  (game/loading-record-tile st [:ready 0 0 (buffer/new-filled 256 8)])
  (check "a partially-ready set stays outstanding"
         (= 3 (game/loading-outstanding st)))
  (check "the advance rule stays in :await while tiles are missing"
         (= :await (get (game/loading-advance st) 0)))
  (check "missing coordinates are exactly the un-validated ones"
         (= 3 (length (game/loading-needs st))))
  (check "a validated coordinate is not requested again"
         (not (some (fn [c] (= 0 (get c 0))) (game/loading-needs st)))))

# --- failed ------------------------------------------------------------
# A tile that will never arrive is terminal: the stage must not wait forever
# and must never fall through to a world built from noise.
(let [st (loading-fixture 4)]
  (game/loading-record-tile st [:error 1 0 "backend exploded"])
  (check "an error result fails the stage"
         (= :failed (st :state)) (string (st :state)))
  (check "the failure reason names the coordinate"
         (not (nil? (string/find "(1,0)" (st :reason)))) (string (st :reason)))
  (check "the failure reason carries the backend text"
         (not (nil? (string/find "backend exploded" (st :reason)))))
  (check "a failed stage is terminal"
         (truthy? (game/loading-terminal? st)))
  (check "a failed stage does not advance to building"
         (= :hold (get (game/loading-advance st) 0)))
  (check "a failed coordinate leaves the needs list"
         (not (some (fn [c] (= 1 (get c 0))) (game/loading-needs st))))
  (check "a failed stage is described, not blank"
         (not (nil? (game/loading-describe st)))))

# --- cancelled / timed out --------------------------------------------
(let [st (loading-fixture 4)]
  (game/loading-cancel st)
  (check "cancel is terminal" (truthy? (game/loading-terminal? st)))
  (check "cancel does not advance" (= :hold (get (game/loading-advance st) 0)))
  (check "cancel is describable" (= "cancelled" (game/loading-describe st))))
(let [st (loading-fixture 4)]
  (game/loading-timeout st)
  (check "timeout is terminal" (truthy? (game/loading-terminal? st)))
  (check "timeout does not advance" (= :hold (get (game/loading-advance st) 0)))
  (check "timeout is described"
         (not (nil? (string/find "timed out" (game/loading-describe st))))))

# --- validated, not merely present ------------------------------------
# `stat` presence is not readiness. A coordinate only counts once heights are
# decoded, which is what stops a truncated tile being counted as available.
(let [st (loading-fixture 2)]
  (put (st :probed) (game/loading-key 0 0) true)
  (check "a probed-but-undecoded tile is not ready"
         (zero? (game/loading-ready-count st)))
  (check "a probed-but-undecoded tile is still outstanding"
         (= 2 (game/loading-outstanding st))))

# --- bounded probe -----------------------------------------------------
(let [st (loading-fixture 10)
      calls @[]]
  (game/loading-step-probe st (fn [cx cz] (array/push calls [cx cz]) [:missing]) 4)
  (check "a probe pass touches at most the budget"
         (<= (length calls) 4) (string (length calls)))
  (check "a probe pass touches exactly the budget when work exists"
         (= 4 (length calls)) (string (length calls))))

# --- build steps are bounded and honest -------------------------------
(let [st (loading-fixture 5)
      built @[]]
  (for i 0 5
    (game/loading-record-tile st [:ready i 0 (buffer/new-filled 256 8)]))
  (game/loading-enter st :build-world)
  (game/loading-step-build-world st 2 (fn [cx cz h] (array/push built [cx cz])))
  (check "a world pass builds at most the limit"
         (<= (length built) 2) (string (length built)))
  (check "the world pass counts what it built"
         (= (length built) (st :worlds)) (string (st :worlds)))
  (check "the world count is not yet complete"
         (< (st :worlds) 5))
  (game/loading-step-build-world st 10 (fn [cx cz h] (array/push built [cx cz])))
  (check "the remaining chunks are built on the next pass"
         (= 5 (st :worlds)) (string (st :worlds)))
  # A built world goes to the dry-land search FIRST: meshing is only useful
  # once there is somewhere safe to stand.
  (check "advance moves to the spawn search once every chunk exists"
         (= :find-spawn (get (game/loading-advance st) 0)))
  (game/loading-enter st :find-spawn)
  (check "the search keeps going while no spawn is found"
         (= :find-spawn (get (game/loading-advance st) 0)))
  (put st :spawn @[0.5 40 0.5])
  (check "advance moves on to meshing only after a spawn is found"
         (= :build-meshes (get (game/loading-advance st) 0))))

# --- truthful progress text -------------------------------------------
(let [st (loading-fixture 4)]
  (game/loading-record-tile st [:ready 0 0 (buffer/new-filled 256 8)])
  (def text (game/loading-progress-text st))
  (check "progress text reports the real ready count"
         (not (nil? (string/find "1/4" text))) text)
  (check "progress text does not invent a percentage"
         (nil? (string/find "%" text)) text))

# --- transition ordering and terminal behaviour -----------------------
# A warm cache must reach :ready, and no terminal state may ever advance into a
# playable world.
(let [st (loading-fixture 2)]
  (for i 0 2
    (game/loading-record-tile st [:ready i 0 (buffer/new-filled 256 8)]))
  (game/loading-enter st :build-world)
  (game/loading-step-build-world st 10 (fn [cx cz h] nil))
  (check "a fully built world advances to the spawn search"
         (= :find-spawn (get (game/loading-advance st) 0)))
  (game/loading-enter st :find-spawn)
  (put st :spawn @[0.5 40 0.5])
  (check "a found spawn advances to meshing"
         (= :build-meshes (get (game/loading-advance st) 0)))
  (game/loading-enter st :build-meshes)
  (put st :meshes 2)
  (check "a fully meshed world advances to ready"
         (= :ready (get (game/loading-advance st) 0))))

# --- worker argv / ownership (no process is spawned) ------------------
(let [argv (game/worker-argv "/repo" "tmp/venv/python" "/repo/cache/abc")]
  (check "the worker argv names the interpreter"
         (= "/repo/tmp/venv/python" (get argv 0)) (get argv 0))
  (check "the worker argv names the backend script"
         (= "/repo/tools/terrain_backend.py" (get argv 1)) (get argv 1))
  (check "the worker subcommand is worker"
         (= "worker" (get argv 2)) (get argv 2))
  (check "the worker is pinned by full identity directory"
         (= "--from-identity" (get argv 3)) (get argv 3))
  (check "the identity directory is passed through"
         (= "/repo/cache/abc" (get argv 4)) (get argv 4))
  (check "no generation flags are passed, so the launcher cannot drift"
         (= 5 (length argv)) (string (length argv))))
(let [argv (game/worker-argv "/repo" "/abs/python" "/c")]
  (check "an absolute interpreter path is used as given"
         (= "/abs/python" (get argv 0)) (get argv 0)))

# A missing interpreter is reported, never spawned, so a bare checkout fails
# with an actionable message instead of an obscure spawn error.
(let [r (game/worker-start "/nonexistent-root" "no/such/python" "/tmp")]
  (check "a missing interpreter is reported, not spawned"
         (not (nil? (get r :error))) (string (get r :error)))
  (check "the error names the interpreter path"
         (not (nil? (string/find "python" (get r :error))))))

# --- root discovery ---------------------------------------------------
(check "a bare script name resolves to the cwd"
       (= "." (game/spawning-root "main.janet")) (game/spawning-root "main.janet"))
(check "a repo-relative script resolves to its directory"
       (= "/r" (game/spawning-root "/r/main.janet")))
(check "a subdirectory script resolves to that subdirectory"
       (= "/r/sub" (game/spawning-root "/r/sub/main.janet")))

# --- meshing is never claimed without being done ----------------------
# The stage finishes at :build-meshes because the mesher needs a GL context
# built later in startup. It must therefore reach :ready WITHOUT reporting
# meshes it did not perform: a loading screen that says "meshing 25/25" while
# nothing was meshed is the exact dishonesty this core exists to prevent.
(let [st (loading-fixture 2)]
  (for i 0 2
    (game/loading-record-tile st [:ready i 0 (buffer/new-filled 256 8)]))
  (game/loading-enter st :build-world)
  (game/loading-step-build-world st 10 (fn [cx cz h] nil))
  (check "the world is fully built before meshing is considered"
         (= 2 (st :worlds)))
  (game/loading-enter st :build-meshes)
  (check "entering :build-meshes does not pre-set the mesh count"
         (zero? (st :meshes)) (string (st :meshes)))
  (def text (game/loading-progress-text st))
  (check "progress text does not claim meshing that has not happened"
         (nil? (string/find "meshing" text)) text))

# --- terminal states never report meshing either ----------------------
(let [st (loading-fixture 3)]
  (game/loading-record-tile st [:error 0 0 "boom"])
  (def text (game/loading-progress-text st))
  (check "a failed stage's text claims no meshing"
         (nil? (string/find "meshing" text)) text)
  (check "a failed stage's text reports the failure count"
         (not (nil? (string/find "1 failed" text))) text))

#
# --- 13. Worker stop actually reaps the child -------------------------
#
# The defect this pins: signalling a child leaves a ZOMBIE, and a zombie keeps
# its PID. A stop that merely signals therefore looks complete while the PID
# still exists, which is exactly what "child PID exists after stop" catches.
# No GPU and no backend is involved: `/bin/sleep` is spawned as a stand-in.
#
# Uses os/execute on /bin/ps and /bin/kill purely as test instruments; the code
# under test is worker-stop.

(defn pid-state [pid]
  "Process state from ps, or nil when the PID is gone."
  (def r (try (os/execute ["/bin/ps" "-o" "stat=" "-p" (string pid)] :p)
              ([e] nil)))
  (when (and (number? r) (zero? r))
    (def out (try (string/trim (string (os/execute
                                         ["/bin/ps" "-o" "stat=" "-p" (string pid)]
                                         :p)))
                  ([e] "")))
    (if (empty? out) nil out)))

(defn gone? [pid]
  (nil? (pid-state pid)))

(let [p (os/spawn ["/bin/sleep" "30"] :p)
      pid (get p :pid)
      worker @{:process p}]
  (check "the stand-in child is running before the stop"
         (not (gone? pid)) (string (pid-state pid)))
  (def stopped (game/worker-stop worker))
  (check "worker-stop reports it reaped the child"
         (truthy? (stopped :reaped)) (string (stopped :reaped)))
  (check "the owned child is GONE after the stop (no zombie)"
         (gone? pid) (string (pid-state pid)))
  (check "the process handle is cleared after the stop"
         (nil? (stopped :process)))
  (check "the worker is marked stopped" (truthy? (stopped :stopped))))

# A second stop must be a no-op, not an error, since a session may stop on the
# success path and again on an exit path.
(let [p (os/spawn ["/bin/sleep" "30"] :p)
      pid (get p :pid)
      worker @{:process p}]
  (game/worker-stop worker)
  (check "a stopped worker's child is gone" (gone? pid) (string (pid-state pid)))
  (def again (game/worker-stop worker))
  (check "stopping twice is tolerated" (nil? (again :process))))

# A worker that was never started must not raise.
(check "stopping an empty worker returns it"
       (not (nil? (game/worker-stop @{:process nil}))))

#
# --- 14. Incremental meshing is incremental and honest ----------------
#
# The one-shot `build-meshes` blocks for ~300 ms on a 25-chunk spawn area --
# the freeze the loading stage exists to remove. `build-meshes-incremental` does
# the same per-chunk work but yields a frame between batches. These use a stub
# uploader and a plain world, so no GL context is needed.

(defn stub-world-with [n]
  "A world holding n chunks with distinguishable coordinates."
  (def w (world/world-new))
  (for i 0 n
    (world/world-put-chunk w (world/chunk-new i 0)))
  w)

# The batcher must call the draw hook AS IT GOES, not only at the end, or the
# window would still be frozen for the whole pass.
(let [w (stub-world-with 9)
      drawables @{}
      seen @[]]
  # The real batcher runs against this world; the draw hook observes it.
  (def total (game/build-meshes-incremental
               (mesher/mesher-new) w drawables 4
               (fn [done total] (array/push seen [done total]))))
  (check "the batcher reports a total equal to the chunk count"
         (all |(= 9 (get $ 1)) seen) (string seen))
  (check "the batcher draws more than once for 9 chunks at 4 per frame"
         (> (length seen) 2) (string (length seen)))
  (check "the batcher finishes with a full count"
         (= 9 (get (last seen) 0)) (string (last seen)))
  (check "progress never exceeds the total"
         (all |(<= (get $ 0) (get $ 1)) seen) (string seen)))

# A per-frame of 1 must draw after every chunk: the strongest guarantee that no
# long stall can occur.
(let [w (stub-world-with 5)
      seen @[]]
  (game/build-meshes-incremental (mesher/mesher-new) w @{} 1
    (fn [done total] (array/push seen done)))
  (check "per-frame 1 reports every intermediate count"
         (= "(1 2 3 4 5 5)" (string/format "%p" (tuple ;seen)))
         (string/format "%p" (tuple ;seen))))

# An empty world must not throw and must report zero.
(let [w (world/world-new)
      seen @[]]
  (def n (game/build-meshes-incremental (mesher/mesher-new) w @{} 4
                                         (fn [d t] (array/push seen [d t]))))
  (check "an empty world meshes nothing without throwing" (zero? n))
  (check "an empty world still reports a final count of zero"
         (= "((0 0))" (string/format "%p" (tuple ;seen)))
         (string/format "%p" (tuple ;seen))))

#
# --- 15. Probe keeps looking: stale-marker starvation ---------------
#
# The P1 this pins: `terrain-cache/request` answers `:suppressed` for a marker
# left by a PREVIOUS session and does NOT enrol the coordinate in the local
# pending set, so `poll` never watches it. A probe that retired a coordinate
# after one look would then never look again and the loading stage would wait
# forever. These drive the pure probe step with a counter, so the guarantee is
# measured rather than inferred.

(defn probe-counting-state [n]
  "A loading state whose probes always report :missing, counting calls."
  (def coords @[])
  (for i 0 n (array/push coords [i 0]))
  (game/loading-new nil coords))

(let [st (probe-counting-state 10)
      calls @{}]
  (defn missing-probe [cx cz]
    (put calls (game/loading-key cx cz) (+ 1 (get calls (game/loading-key cx cz) 0)))
    [:missing])
  # A budget of 4 must cover all 10 required coordinates within 3 passes.
  (game/loading-step-probe st missing-probe 4)
  (game/loading-step-probe st missing-probe 4)
  (game/loading-step-probe st missing-probe 4)
  (check "every still-missing coordinate is re-probed, not retired"
         (= 10 (length calls)) (string (length calls)))
  (def all-seen (all (fn [i] (pos? (get calls (game/loading-key i 0) 0))) (range 10)))
  # Three passes of 4 over 10 coordinates: the rotation starts at a different
  # index each time, so no single coordinate is hit more than twice.
  (check "a bounded pass touches at most the budget"
         (all |(<= $ 2) (values calls)) (string/format "%p" (tuple ;(values calls))))
  (check "no coordinate is probed more often than the passes allow"
         (all |(>= $ 1) (values calls)) (string/format "%p" (tuple ;(values calls))))
  (check "the whole needed set is covered, so nothing starves" all-seen))

# The strongest form: a coordinate that stays missing must be re-examined, or a
# tile published later by a worker would never be noticed.
(let [st (probe-counting-state 3)
      seen @[]]
  (defn tick [cx cz] (array/push seen [cx cz]) [:missing])
  (game/loading-step-probe st tick 1)
  (game/loading-step-probe st tick 1)
  (game/loading-step-probe st tick 1)
  (check "a budget of 1 still walks the whole set over successive passes"
         (= 3 (length seen)) (string (length seen)))
  (check "budget 1 visits three DIFFERENT coordinates"
         (= 3 (length (distinct seen))) (string/format "%p" (tuple ;seen))))

# A tile that appears on a later pass must be picked up by that same probe path.
(let [st (probe-counting-state 2)
      c @{:n 0}]
  (defn late-probe [cx cz]
    (++ (c :n))
    (if (> (c :n) 2) [:ready (buffer/new-filled 256 8)] [:missing]))
  (game/loading-step-probe st late-probe 1)
  (game/loading-step-probe st late-probe 1)
  (game/loading-step-probe st late-probe 1)
  (check "a tile that appears later is validated by a later pass"
         (pos? (game/loading-ready-count st))
         (string (game/loading-ready-count st))))

# Validated and failed coordinates DO retire: re-probing them would be waste.
(let [st (probe-counting-state 2)
      counter @{:n 0}]
  (game/loading-step-probe st (fn [cx cz]
                                (++ (counter :n))
                                (if (= cx 0)
                                  [:ready (buffer/new-filled 256 8)]
                                  [:corrupt "broken"]))
                          2)
  (def after-first (counter :n))
  (game/loading-step-probe st (fn [cx cz] (++ (counter :n)) [:missing]) 2)
  (check "validated and failed coordinates are not probed again"
         (= after-first (counter :n)) (string (counter :n))))

#
# --- 16. Worker reuse is proven by launch token, not by PID -----------
#
# The P1: the backend writes :idle on its way out, so a stale status file with a
# positive pid is indistinguishable from a live worker. Trusting it would
# suppress the autolaunch and wait forever. Reuse must be confirmed by the
# receipt the CHILD wrote, carrying the token THIS launch passed.

(defn write-json-ish [path text]
  (def f (file/open path :wbn))
  (file/write f text)
  (file/close f))

(let [dir (scratch-dir)
      id (string/repeat "d" 64)]
  # A stale status: identity matches, pid positive, state :idle -- exactly the
  # shape a previous session leaves behind.
  (write-json-ish (game/worker-status-path dir)
                  (string "{:version 1 :identity-digest \"" id "\" :pid 999999 "
                          ":state :idle :completed 0 :message \"stale\"}"))
  (check "a stale idle status alone does NOT prove a live worker"
         (nil? (game/live-worker-status dir id "L-other-token"))
         "stale status was accepted")
  (check "a nil token is never accepted as reuse"
         (nil? (game/live-worker-status dir id nil))))

# A per-launch receipt naming OUR token and a serving pid is a confirmed worker.
# Note `:worker-pid`, not the child's own pid: on a contention loss the worker is
# the EXISTING OWNER, which is the whole reason a launch cannot compare its own
# pid against the status record.
(let [dir (scratch-dir)
      id (string/repeat "e" 64)
      token "L123-456"]
  (write-json-ish (game/worker-receipt-path dir token)
                  (string "{:version 1 :identity-digest \"" id "\" :state :started"
                          " :launcher-pid 111 :worker-pid 4242 :owner-token \""
                          token "\" :message \"\"}"))
  (def adopted (game/live-worker-status dir id token))
  (check "a receipt naming our token confirms a worker" (not (nil? adopted))
         "no worker detected")
  (check "the confirmed pid is the SERVING worker pid, not the launcher's"
         (= 4242 (adopted :pid)) (string (adopted :pid)))
  (check "a started receipt is not reported as a reuse"
         (not (truthy? (adopted :reused))) (string (adopted :reused))))
# A :reused receipt says the existing owner serves -- its pid, not ours.
(let [dir (scratch-dir)
      id (string/repeat "1" 64)
      token "L2-2"]
  (write-json-ish (game/worker-receipt-path dir token)
                  (string "{:version 1 :identity-digest \"" id "\" :state :reused"
                          " :launcher-pid 222 :worker-pid 999 :owner-token \""
                          token "\" :message \"busy\"}"))
  (def adopted (game/live-worker-status dir id token))
  (check "a reused receipt confirms the existing owner"
         (= 999 (adopted :pid)) (string (adopted :pid)))
  (check "a reused receipt is marked as a reuse"
         (truthy? (adopted :reused)) (string (adopted :reused))))
# Another launch's receipt is not ours, even when it exists and is healthy.
(let [dir (scratch-dir)
      id (string/repeat "2" 64)]
  (write-json-ish (game/worker-receipt-path dir "L-other")
                  (string "{:version 1 :identity-digest \"" id "\" :state :started"
                          " :launcher-pid 3 :worker-pid 44 :owner-token \"L-other\""
                          " :message \"\"}"))
  (check "another launch's receipt is not adopted"
         (nil? (game/live-worker-status dir id "L-mine"))))
# A receipt for a different identity never authorises anything.
(let [dir (scratch-dir)
      id (string/repeat "3" 64)
      other (string/repeat "0" 64)
      token "L3-3"]
  (write-json-ish (game/worker-receipt-path dir token)
                  (string "{:version 1 :identity-digest \"" other "\" :state :started"
                          " :launcher-pid 4 :worker-pid 55 :owner-token \""
                          token "\" :message \"\"}"))
  (check "a receipt for another identity is rejected"
         (nil? (game/live-worker-status dir id token))))
# A :failed receipt is surfaced as an actionable reason, not as "still loading".
(let [dir (scratch-dir)
      id (string/repeat "4" 64)
      token "L4-4"]
  (write-json-ish (game/worker-receipt-path dir token)
                  (string "{:version 1 :identity-digest \"" id "\" :state :failed"
                          " :launcher-pid 5 :worker-pid 0 :owner-token \""
                          token "\" :message \"identity digest mismatch\"}"))
  (check "a failed receipt yields no worker"
         (nil? (game/live-worker-status dir id token)))
  (def why (game/launch-failed-reason dir id token))
  (check "a failed receipt yields the reason" (not (nil? why)) (string why))
  (check "the reason is the backend's message"
         (not (nil? (string/find "identity digest mismatch" why))) (string why))
  # A healthy receipt must never be reported as a failure.
  (write-json-ish (game/worker-receipt-path dir token)
                  (string "{:version 1 :identity-digest \"" id "\" :state :started"
                          " :launcher-pid 5 :worker-pid 66 :owner-token \""
                          token "\" :message \"\"}"))
  (check "a healthy receipt is not reported as a failure"
         (nil? (game/launch-failed-reason dir id token))))

# Launch tokens must differ between launches, including in one process.
(let [a (game/launch-token)
      b (game/launch-token)]
  (check "launch tokens are non-empty strings"
         (and (string? a) (pos? (length a))) (string a))
  (check "two launches get different tokens" (not= a b) (string a " vs " b)))

# --- 17. Graceful stop gives the child a real grace window ------------
#
# TERM then immediate KILL defeats the backend's handler, which only checks its
# flag between inference queries. The stop must wait, bounded, when asked to.
(let [p (os/spawn ["/bin/sh" "-c" "trap 'exit 0' TERM; sleep 30"] :p)
      pid (get p :pid)
      worker @{:process p :dir "/nonexistent-status-dir"}
      t0 (os/clock)
      stopped (game/worker-stop worker 400)
      elapsed (* 1000 (- (os/clock) t0))]
  (check "the grace window is actually waited"
         (>= elapsed 250) (string elapsed))
  (check "the graceful wait is bounded, not a hang"
         (< elapsed 5000) (string elapsed))
  (check "the child is reaped after the stop" (truthy? (stopped :reaped)))
  # `ps` is the instrument, not `kill -0`: kill -0 on a reaped PID can be
  # answered by PID reuse, while ps reports nothing for a vanished process.
  (check "the child is gone after the stop" (gone? pid) (string (pid-state pid))))

# A zero grace must not wait at all, for a cancelled load where the user is
# already trying to leave.
(let [p (os/spawn ["/bin/sleep" "30"] :p)
      worker @{:process p :dir "/nonexistent-status-dir"}
      t0 (os/clock)
      stopped (game/worker-stop worker 0)
      elapsed (* 1000 (- (os/clock) t0))]
  (check "a zero grace returns immediately"
         (< elapsed 500) (string elapsed))
  (check "a zero-grace stop still reaps" (truthy? (stopped :reaped)))
  (check "a zero-grace stop still marks the worker stopped"
         (truthy? (stopped :stopped))))

#
# --- 18. Spawn must be dry land, never water -------------------------
#
# The guarantee: the player always starts above sea level on supported ground.
# `src/spawn` judges real loaded chunks, so these build genuine terrain buffers
# -- no mocks -- and check the position it reports.

(import ./../src/spawn :as spawn)

(defn flat-world
  "A world of loaded chunks whose surface height is `h`, water below sea level."
  [h &opt cols]
  (def w (world/world-new))
  (def n (or cols 3))
  (for cz (- n) (+ n 1)
    (for cx (- n) (+ n 1)
      (def ch (world/chunk-new cx cz))
      (for z 0 16
        (for x 0 16
          (for y 0 64
            (put (ch :blocks) (world/block-index x y z)
                 (cond (= y 0) world/block-stone
                       (< y (- h 4)) world/block-stone
                       (< y h) world/block-dirt
                       (= y h) world/block-grass
                       (<= y 28) world/block-water
                       true world/block-air)))))
      (world/world-put-chunk w ch)))
  w)

# Dry land above sea level: the search must find it and report a safe column.
(let [w (flat-world 40)
      found (spawn/find-dry-spawn w {:radius 8})]
  (check "dry land is found" (not (nil? found)) (string/format "%p" found))
  (check "the found position is above sea level"
         (> (get found 1) 28) (string (get found 1)))
  (check "the found position is not inside water"
         (not= world/block-water
               (world/world-get-block w (math/floor (get found 0))
                                      (math/floor (get found 1))
                                      (math/floor (get found 2)))))
  (check "there is solid ground under the found position"
         (world/block-solid?
           (world/world-get-block w (math/floor (get found 0))
                                  (- (get found 1) 1)
                                  (math/floor (get found 2)))))
  (check "the body is clear air"
         (= world/block-air
            (world/world-get-block w (math/floor (get found 0))
                                   (get found 1)
                                   (math/floor (get found 2))))))

# All-ocean terrain: the search must EXHAUST, not invent an island and not
# hand back the water column at the origin.
(let [w (flat-world 20)          # surface at 20 is below sea level 28
      search (spawn/search-new {:radius 6})]
  (spawn/search-step search w 2000)
  (check "an all-ocean world reports :exhausted rather than a position"
         (and (= :exhausted (search :status)) (nil? (search :position)))
         (string (search :status)))
  (check "an all-ocean world examined a bounded number of columns"
         (<= (search :examined) 2000) (string (search :examined)))
  (check "no dry spawn is returned for an all-ocean world"
         (nil? (spawn/find-dry-spawn w {:radius 6}))))

# Unjudgeable columns are reported as required chunks, so the caller can ask
# for COVERAGE rather than lowering the bar.
(let [w (world/world-new)        # nothing loaded at all
      search (spawn/search-new {:radius 4})]
  (spawn/search-step search w 1000)
  (check "nothing loaded produces :exhausted"
         (= :exhausted (search :status)) (string (search :status)))
  (check "the search names the chunks it could not judge"
         (pos? (length (search :requiredchunks)))
         (string (length (search :requiredchunks))))
  (check "no position is fabricated from unloaded chunks"
         (nil? (search :position))))

# The loading step drives the same search and records its outcome on the state.
(let [st (game/loading-new nil @[[0 0]])
      w (flat-world 40)]
  (put st :state :find-spawn)
  (game/loading-step-find-spawn st w 4000)
  (check "the loading step records a found spawn"
         (not (nil? (st :spawn))) (string/format "%p" (st :spawn)))
  (check "the loading step counts columns examined"
         (pos? (or (st :spawn-examined) 0)) (string (st :spawn-examined))))

(let [st (game/loading-new nil @[[0 0]])
      w (flat-world 20)]
  (put st :state :find-spawn)
  (game/loading-step-find-spawn st w 4000)
  (check "an ocean world leaves the loading stage without a spawn"
         (nil? (st :spawn)))
  (check "an ocean world is marked exhausted, not silently accepted"
         (truthy? (st :spawn-exhausted))))

# An exhausted search must be TERMINAL. Spinning in :find-spawn forever would be
# exactly the hang the loading stage exists to avoid, and it would look like a
# slow load rather than "this world is ocean".
(let [st (game/loading-new nil @[[0 0]])]
  (put st :state :find-spawn)
  (put st :spawn-exhausted true)
  (check "an exhausted search does not stay in :find-spawn"
         (= :hold (get (game/loading-advance st) 0))
         (string/format "%p" (game/loading-advance st)))
  (game/loading-fail st "no dry land")
  (check "an ocean world ends in a terminal state"
         (truthy? (game/loading-terminal? st)) (string (st :state)))
  (check "the ocean failure is described for the screen"
         (not (nil? (game/loading-describe st)))))

#
# --- 19. A launch that never happened must not wait forever ----------
#
# The P1: `worker-start` could fail (no interpreter, no script) and the stage
# merely warned, then awaited tiles with no timeout by default -- a screen
# saying "0 ready" and nothing ever producing a tile. A failed launch is
# terminal and its reason must reach the error block.

# A missing interpreter is reported, not spawned, and never returns a process.
(let [r (game/worker-start "/nonexistent-root" "no/such/python" "/tmp")]
  (check "a missing interpreter is reported rather than spawned"
         (not (nil? (get r :error))) (string (get r :error)))
  (check "no process is returned on failure" (nil? (get r :process))))

# The failure text becomes the stage's terminal reason and the view's error.
(let [st (game/loading-new nil @[[0 0]])]
  (game/loading-fail st "could not start the terrain worker: no interpreter")
  (check "a failed launch makes the stage terminal"
         (truthy? (game/loading-terminal? st)) (string (st :state)))
  (check "a failed launch does not advance to building"
         (= :hold (get (game/loading-advance st) 0)))
  (def view (game/loading-view st))
  (check "the failure reason reaches the screen's error field"
         (not (nil? (get view :error))) (string/format "%p" (get view :error)))
  (check "the error block says the launch failed, not that terrain is broken"
         (not (nil? (string/find "terrain worker" (get view :error))))
         (get view :error)))

# An external publisher remains a supported setup, so the message must point at
# it rather than implying the cache is corrupt.
(let [st (game/loading-new nil @[[0 0]])]
  (game/loading-fail st (string "could not start the terrain worker: no worker"
                                " interpreter at /x. Either install it, pass"
                                " --terrain-python, or run an external publisher"))
  (def msg (game/loading-describe st))
  (check "the failure mentions the external-publisher escape hatch"
         (not (nil? (string/find "external publisher" msg))) msg))

#
# --- 20. "0 requested" was a lie: pending was never populated ---------
#
# Found against a real 180-frame capture: waiting for a missing tile showed
# "0 requested". The cause was not formatting -- `:pending` was declared,
# cleared in three places, and NEVER written, so the count could only be zero.
# These pin that a published request is counted and a refused one is not.

# A request the cache ACCEPTED counts as pending.
(let [st (game/loading-new nil @[[0 0] [1 0]])]
  (put (st :pending) (game/loading-key 0 0) true)
  (check "a published request is counted"
         (= 1 (game/loading-pending-count st)) (string (game/loading-pending-count st)))
  (check "the progress text reports the pending count, not zero"
         (not (nil? (string/find "1 requested" (game/loading-progress-text st))))
         (game/loading-progress-text st)))

# A validated tile stops being pending: the count must drop as tiles arrive,
# or it would keep claiming work after the work was done.
(let [st (game/loading-new nil @[[0 0] [1 0]])]
  (put (st :pending) (game/loading-key 0 0) true)
  (put (st :pending) (game/loading-key 1 0) true)
  (check "both requests are pending" (= 2 (game/loading-pending-count st)))
  (game/loading-record-tile st [:ready 0 0 (buffer/new-filled 256 8)])
  (check "a validated tile is no longer pending"
         (= 1 (game/loading-pending-count st)) (string (game/loading-pending-count st))))

# With autolaunch disabled the wording must not claim this process is
# generating anything -- it is waiting for somebody else.
(let [st (game/loading-new nil @[[0 0]])
      _ (put st :state :await)
      view (game/loading-view st true)]
  (check "autolaunch disabled says external"
         (not (nil? (string/find "external" (get view :detail))))
         (string/format "%p" (get view :detail))))
(let [st (game/loading-new nil @[[0 0]])
      _ (put st :state :await)
      view (game/loading-view st false)]
  (check "autolaunch enabled does not claim an external worker"
         (nil? (string/find "external" (get view :detail)))
         (string/format "%p" (get view :detail))))

# Emitted strings must be printable ASCII: raylib's default font is a 224-glyph
# bitmap and draws NOTHING above it, silently. A separator that vanishes makes
# the detail line collide with the headline.
(defn ascii-only? [s]
  (all (fn [b] (and (>= b 32) (<= b 126))) (string/bytes s)))
(let [st (game/loading-new nil @[[0 0] [1 0]])]
  (check "the progress line is printable ASCII"
         (ascii-only? (game/loading-progress-text st))
         (game/loading-progress-text st))
  (each state [:probe :await :build-world :find-spawn :build-meshes :ready]
    (put st :state state)
    (each line (game/loading-lines st)
      (check (string "the " state " line is printable ASCII") (ascii-only? line) line))))

#
# --- 21. A confirmed worker must not be failed by a vanished receipt --
#
# The backend removes its receipt on a clean exit. If "receipt absent" were read
# as "launch failed", a perfectly good worker would fail the stage the moment it
# finished. These pin the distinction between a launch that NEVER confirmed a
# worker and one that did.

(defn receipt [dir token id state &opt msg worker-pid]
  (write-json-ish
    (game/worker-receipt-path dir token)
    (string "{:version 1 :identity-digest \"" id "\" :state :" state
            " :launcher-pid 1 :worker-pid " (or worker-pid 0)
            " :owner-token \"" token "\" :message \""
            (or msg "") "\"}")))

# A :failed receipt with no worker ever confirmed is a launch failure.
(let [dir (scratch-dir)
      id (string/repeat "5" 64)
      token "L5-5"]
  (receipt dir token id "failed" "identity digest mismatch")
  (check "an unconfirmed failure yields a reason"
         (not (nil? (game/launch-failed-reason dir id token))))
  (check "and yields no worker"
         (nil? (game/live-worker-status dir id token))))

# After a CONFIRMED worker, the receipt disappearing is a clean exit, not a
# failure -- `launch-failed-reason` must then be nil (no receipt to read).
(let [dir (scratch-dir)
      id (string/repeat "6" 64)
      token "L6-6"
      worker @{:token token :confirmed true}]
  (check "a confirmed worker is flagged as confirmed"
         (truthy? (worker :confirmed)))
  (check "with no receipt left there is no failure reason"
         (nil? (game/launch-failed-reason dir id token))))

# A confirmed worker whose receipt is REPLACED by a failed one is contradictory
# data; the reader still reports what it reads, and the frame loop's `confirmed`
# guard is what prevents a false failure. Pin the reader's contract.
(let [dir (scratch-dir)
      id (string/repeat "7" 64)
      token "L7-7"]
  (receipt dir token id "started" "" 4242)
  (check "a started receipt reports a worker"
         (= 4242 ((game/live-worker-status dir id token) :pid)))
  (check "a started receipt reports no failure"
         (nil? (game/launch-failed-reason dir id token))))

#
# --- 22. QA opt-in must ENABLE the loading stage in a headless run ----
#
# The P1 behind bash40: `--loading-timeout` / `--loading-screenshot` on a
# scripted `--frames` run fell through to the immediate path, which starts with
# `preflight-spawn` and dies on "missing 1 of 25" before drawing a single
# loading frame. `loading-qa?` was computed and then never consulted.
#
# `loading-stage-required?` is that decision, pure, so it is testable here.

# Interactive, cache-backed: yes.
(check "an interactive cache run uses the stage"
       (truthy? (game/loading-stage-required? true false false false)))

# --verify-pgo never enters it.
(check "verify-pgo never uses the stage"
       (not (truthy? (game/loading-stage-required? true true false false))))
(check "verify-pgo does not use the stage even with QA flags"
       (not (truthy? (game/loading-stage-required? true true true true))))

# Plain scripted headless keeps the deterministic immediate path.
(check "a plain scripted run does not use the stage"
       (not (truthy? (game/loading-stage-required? true false true false))))

# THE FIX: an explicit QA opt-in turns the stage back on in a headless run.
(check "a scripted run with QA flags DOES use the stage"
       (truthy? (game/loading-stage-required? true false true true)))

# No cache means nothing to wait for.
(check "procedural runs never use the stage"
       (not (truthy? (game/loading-stage-required? false false false false))))
(check "procedural runs ignore QA flags"
       (not (truthy? (game/loading-stage-required? false false true true))))

# The loading gate and the MESHING gate must agree. When they disagreed, a QA
# run entered the loading stage and then meshed in one blocking pass with the
# window frozen -- the precise freeze the incremental path exists to remove.
# Both now consult `loading-stage-required?`, so one predicate decides.
(let [required? game/loading-stage-required?]
  (check "QA opt-in enables the stage in a scripted run"
         (truthy? (required? true false true true)))
  (check "and therefore enables incremental meshing for that same run"
         (truthy? (required? true false true true)))
  (check "a plain scripted run keeps the one-shot mesh path"
         (not (truthy? (required? true false true false))))
  (check "an interactive run meshes incrementally"
         (truthy? (required? true false false false)))
  (check "verify-pgo keeps the one-shot path in every combination"
         (all (fn [qa] (not (truthy? (required? true true true qa))))
              [true false])))

#
# --- 23. The loading budget must never be the gameplay frame budget --
#
# The bug this pins: the stage was capped by `headless-frames`, so
# `--frames 90` became a ~1.5-second loading deadline. A publisher that took 2
# seconds to deliver the last tile was therefore never seen, and the run failed
# with "spawn tiles did not arrive" on a cache that was about to be complete.
#
# The predicate is the whole rule, so the unit test is the right size. What
# matters is the INPUT: gameplay frames are not the loading budget.

# Explicit --loading-frames is an exact loading-frame cap.
(check "an explicit --loading-frames caps loading by frames"
       (= 120 (game/loading-budget-from-frames 120 false)))
(check "a plain --frames run does NOT cap loading by frames"
       (nil? (game/loading-budget-from-frames nil true)))

# No implicit deadline, including scripted opt-ins: the user may wait minutes.
(check "a scripted opt-in has no automatic deadline"
       (nil? (game/loading-timeout-for true nil)))
(check "an explicit --loading-timeout is honoured"
       (= 20 (game/loading-timeout-for true 20)))
(check "an interactive run has no automatic deadline"
       (nil? (game/loading-timeout-for false nil)))
(check "an interactive run still honours an explicit timeout"
       (= 5 (game/loading-timeout-for false 5)))

# The decisive regression: 90 gameplay frames must not produce a 1.5s budget.
(check "90 gameplay frames do not become a loading deadline"
       (not= 1.5 (game/loading-timeout-for true nil)))

# The exact regression the parent reproduced: `--frames 90` must NOT become a
# ~1.5-second loading cap. `bad27fc` had
#   (or loading-frames-arg (when headless-frames headless-frames))
# so a 2-second publisher was never seen and the run failed on a cache that was
# about to be complete.
(check "headless 90 with --loading-timeout 20 yields NO frame cap"
       (nil? (game/loading-budget-from-frames nil 90)))
(check "an explicit --loading-frames is the ONLY thing that caps frames"
       (= 6000 (game/loading-budget-from-frames 6000 90)))
(check "gameplay frames never cap loading, at any value"
       (all (fn [n] (nil? (game/loading-budget-from-frames nil n)))
            [1 30 90 720 6000]))
(check "a 90-frame gameplay budget is not a 1.5s loading deadline"
       (not= 1.5 (game/loading-budget-from-frames nil 90)))

# Wall-clock seconds are the only time budget, and only when given.
(check "--loading-timeout 20 is honoured as 20 seconds"
       (= 20 (game/loading-timeout-for 90 20)))
(check "no --loading-timeout means no deadline (slow inference must finish)"
       (nil? (game/loading-timeout-for 90 nil)))
(check "interactive runs likewise have no implicit deadline"
       (nil? (game/loading-timeout-for nil nil)))

#
# --- 24. No deadline unless the user asked for one ---------------------
#
# The rule the user set: normal startup may legitimately take a minute or two,
# so there is NO implicit frame or wall-clock cap. Only explicit flags bound it.
# A fake deadline once aborted a real 100-second MPS query.

(check "no --loading-timeout means no wall-clock deadline"
       (nil? (game/loading-timeout-for 90 nil)))
(check "a plain headless run gets no deadline even with many gameplay frames"
       (nil? (game/loading-timeout-for 6000 nil)))
(check "an explicit --loading-timeout is honoured"
       (= 20 (game/loading-timeout-for 90 20)))
(check "no --loading-frames means no frame cap"
       (nil? (game/loading-budget-from-frames nil 90)))
(check "an explicit --loading-frames caps loading frames"
       (= 6000 (game/loading-budget-from-frames 6000 60)))

# The timeout must be REAL ELAPSED TIME, not `waiting-frames * dt`. Summing a
# per-frame dt multiplied by the frame index explodes: one 1-second MPS frame at
# index 1000 would read as ~1000 seconds against a 20 s timeout, failing a query
# that was still working.
(let [start (os/clock)]
  (os/sleep 0.15)
  (def elapsed (- (os/clock) start))
  (check "wall-clock elapsed measures real seconds"
         (and (>= elapsed 0.12) (< elapsed 1.0)) (string elapsed))
  # The rejected form, for contrast: with one slow frame the product is absurd.
  (def bad-form (* 1000 1.0))
  (check "frame-count times dt is not real elapsed time"
         (> bad-form 100) (string bad-form)))

#
# --- Result ------------------------------------------------------------
#
(if (pos? failures)
  (do (printf "\n%d check(s) FAILED" failures) (os/exit 1))
  (print "\nall terrain main-integration checks passed"))
