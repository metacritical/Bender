# Asset-directory resolution: priority, refusals, and the native layout.
#
# No window, no GPU, no cwd assumption under test. The filesystem is INJECTED as a
# `:dir?` predicate wherever a case is about policy, and real temporary directories
# are used for the cases that must agree with `os/stat` -- so a test can assert
# "this was refused" without depending on what happens to exist on the machine.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/asset-paths-test.janet

(import ../src/asset-paths :as assets)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

# A filesystem made of a fixed set of directories. Deterministic and independent of
# whatever the checkout contains.
(defn dirs-of [& paths]
  (def set @{})
  (each p paths (put set p true))
  (fn [path] (truthy? (get set path))))

# Nothing exists anywhere: every case must report :none rather than guessing.
(defn empty-fs [_] false)

#
# --- Priority -----------------------------------------------------------
#
(print "\npriority:")
(def source-assets
  (assets/resolve {:script "/game/main.janet"
                   :executable "/compiler/build/bender" :cwd "/elsewhere"
                   :dir? (dirs-of "/game/assets" "/compiler/assets")}))
(check "source launch uses game artwork, never compiler artwork"
       (= "/game/assets" (source-assets :root)))
(check "source directory selection is reported" (= :script (source-assets :source)))

# An explicit directory wins over everything else, including a valid executable
# layout and a valid cwd layout.
(let [r (assets/resolve
          {:explicit "/opt/game/assets"
           :executable "/opt/game/bin/game"
           :cwd "/somewhere/else"
           :dir? (dirs-of "/opt/game/assets" "/opt/game/bin/assets" "/somewhere/else/assets")})]
  (check "an explicit directory wins"
         (= "/opt/game/assets" (r :root)))
  (check "and reports :explicit"
         (= :explicit (r :source))))

# The environment comes next, and still beats the executable.
(let [r (assets/resolve
          {:env-root "/env/assets"
           :executable "/opt/game/bin/game"
           :cwd "/somewhere/else"
           :dir? (dirs-of "/env/assets" "/opt/game/bin/assets" "/somewhere/else/assets")})]
  (check "an environment directory beats the executable"
         (= "/env/assets" (r :root)))
  (check "and reports :environment"
         (= :environment (r :source))))

# Explicit still beats the environment.
(let [r (assets/resolve
          {:explicit "/opt/game/assets" :env-root "/env/assets"
           :dir? (dirs-of "/opt/game/assets" "/env/assets")})]
  (check "explicit beats the environment"
         (= "/opt/game/assets" (r :root))))

#
# --- The native layout --------------------------------------------------
#
(print "\nnative layout:")

# THE SHIPPING CASE: a binary in `build/` with assets one level up. This is the
# shape the real checkout has, and the reason the module exists.
(let [r (assets/resolve
          {:executable "/proj/build/trinecraft-worlds"
           :cwd "/tmp/wherever"
           :dir? (dirs-of "/proj/assets")})]
  (check "a binary in build/ finds assets one level up"
         (= "/proj/assets" (r :root)))
  (check "and reports :executable, not :cwd"
         (= :executable (r :source))))

# Assets beside the binary take precedence over the parent directory.
(let [r (assets/resolve
          {:executable "/proj/build/game"
           :cwd "/elsewhere"
           :dir? (dirs-of "/proj/build/assets" "/proj/assets")})]
  (check "assets beside the binary win over the parent"
         (= "/proj/build/assets" (r :root))))

# THE POINT: the cwd must not matter when the executable is absolute. The same
# executable resolves identically from three different working directories.
(let [dir? (dirs-of "/proj/assets")
      a (assets/resolve {:executable "/proj/build/game" :cwd "/" :dir? dir?})
      b (assets/resolve {:executable "/proj/build/game" :cwd "/tmp" :dir? dir?})
      c (assets/resolve {:executable "/proj/build/game" :cwd "/a/b/c" :dir? dir?})]
  (check "the cwd does not change an absolute-executable result"
         (and (= (a :root) (b :root)) (= (b :root) (c :root))))
  (check "and all three agree on the source"
         (and (= :executable (a :source)) (= :executable (c :source)))))

# A RELATIVE executable is ignored, because resolving it would reintroduce the cwd
# dependency this module exists to remove. With nothing else available the answer
# is :none, not a guess based on the cwd.
(let [r (assets/resolve
          {:executable "build/game" :cwd "/proj"
           :dir? (dirs-of "/proj/assets")})]
  (check "a relative executable is not used for candidates"
         (= :cwd (r :source)))
  (check "so the legacy cwd path is what answers"
         (= "/proj/assets" (r :root))))

#
# --- Refusals: no silent cwd fallback -----------------------------------
#
(print "\nrefusals:")

# THE RULE THAT MATTERS MOST. A caller who named a directory is telling us where
# the assets are. Falling back to cwd would load a DIFFERENT set, so a mistyped
# path would look like a working install with the wrong art.
(let [r (assets/resolve
          {:explicit "/typo/not-here" :cwd "/proj"
           :dir? (dirs-of "/proj/assets")})]
  (check "a bad explicit directory is refused"
         (nil? (r :root)))
  (check "and reports :none rather than :cwd"
         (= :none (r :source))))

(let [r (assets/resolve
          {:env-root "/typo/not-here" :cwd "/proj"
           :dir? (dirs-of "/proj/assets")})]
  (check "a bad environment directory is refused"
         (nil? (r :root)))
  (check "and reports :none rather than :cwd"
         (= :none (r :source))))

# An explicit path that exists as a FILE is not a directory and is refused.
(let [r (assets/resolve
          {:explicit "/typo/is-a-file" :cwd "/proj"
           :dir? (fn [p] (or (= p "/proj/assets") false))})]
  (check "an explicit path that is not a directory is refused"
         (= :none (r :source))))

#
# --- Legacy cwd fallback ------------------------------------------------
#
(print "\ncwd fallback:")

(let [r (assets/resolve {:cwd "/proj" :dir? (dirs-of "/proj/assets")})]
  (check "with nothing configured, cwd/assets is used"
         (= "/proj/assets" (r :root)))
  (check "and reports :cwd"
         (= :cwd (r :source))))

(check "with nothing anywhere, the answer is :none"
       (let [r (assets/resolve {:cwd "/nowhere" :dir? empty-fs})]
         (and (nil? (r :root)) (= :none (r :source)))))
(check "a missing cwd does not raise"
       (= :none ((assets/resolve {:cwd "/definitely/not/here" :dir? empty-fs})
                 :source)))

# The cwd default, when no :cwd key is given at all, is "." -- and that must not
# raise either.
(check "omitting :cwd is legal"
       (let [r (assets/resolve {:dir? empty-fs})]
         (= :none (r :source))))

#
# --- Paths with spaces --------------------------------------------------
#
(print "\nawkward paths:")

# Separators are "/" everywhere in this codebase; a path with a space is ordinary
# and must survive untouched.
(let [r (assets/resolve
          {:explicit "/My Games/Trinexraft Assets"
           :dir? (dirs-of "/My Games/Trinexraft Assets")})]
  (check "a directory with spaces is returned verbatim"
         (= "/My Games/Trinexraft Assets" (r :root))))

(let [r (assets/resolve
          {:executable "/My Games/build/game"
           :cwd "/elsewhere"
           :dir? (dirs-of "/My Games/assets")})]
  (check "an executable path with spaces resolves its parent assets"
         (= "/My Games/assets" (r :root))))

#
# --- Real filesystem ----------------------------------------------------
#
(print "\nreal filesystem:")

# The injected predicate is for policy cases. These two must agree with `os/stat`,
# or the resolver would be pure fiction about a machine it cannot see.
(def root (string "tmp/asset-paths-" (os/getpid)))
(try (os/rm root true) ([_] nil))
(os/mkdir root)
(def assets-dir (string root "/assets"))
(os/mkdir assets-dir)
(check "a real directory resolves through os/stat"
       (= assets-dir ((assets/resolve {:explicit assets-dir}) :root)))
(check "a real missing directory is :none"
       (= :none ((assets/resolve {:explicit (string root "/nope")}) :source)))
(try (os/rm root true) ([_] nil))

#
# --- Result -------------------------------------------------------------
#
(if (zero? failures)
  (print "\nasset paths: ALL CHECKS PASSED")
  (do (printf "\nasset paths: %d FAILED" failures) (os/exit 1)))
