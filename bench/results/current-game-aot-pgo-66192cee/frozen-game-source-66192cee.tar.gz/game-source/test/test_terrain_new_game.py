"""Offline tests for the temporary Python Terrain Diffusion provider.

Nothing here loads a model, touches a GPU, spawns a process, or downloads
anything. ``FakePipeline`` is a deterministic closed-form elevation field standing
in for ``WorldPipeline``; it proves the *plumbing* -- sampling axis order, the
export path, the artifact verification, cancellation and refusal -- and proves
nothing about what the real model generates.

The backend's identity helpers are fixtures here too: the real snapshot is 1.1 GB
of safetensors, so the pin tables are patched to fixture digests exactly as the
backend's own suite does.
"""

import contextlib
import hashlib
import io
import json
import os
import shutil
import signal
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "tools"))

import scenic_terrain as st          # noqa: E402
import terrain_backend as tb         # noqa: E402
import terrain_cache as tc           # noqa: E402
import terrain_new_game as png       # noqa: E402


# ---------------------------------------------------------------------------
# A fake pipeline: a fixture, never a stand-in for the model
# ---------------------------------------------------------------------------


class FakePipeline:
    """Closed-form elevation in metres, a pure function of the pixel coordinate.

    Records every call so a test can assert the axis order and that the whole map
    is fetched in exactly one ``get``.
    """

    def __init__(self, low=850.0, high=1600.0, failure=None):
        self.low = low
        self.high = high
        self.failure = failure
        self.calls = []
        self.closed = False

    def elevation(self, x, z):
        span = float(self.low + self.high)
        return self.low + (self.high - self.low) * ((x + z) % 97) / 96.0

    def get(self, i1, j1, i2, j2, with_climate=False):
        if self.failure is not None:
            raise self.failure
        self.calls.append((i1, j1, i2, j2))
        if i2 <= i1 or j2 <= j1:
            raise AssertionError("empty region requested")
        rows = [[self.elevation(j, i) for j in range(j1, j2)] for i in range(i1, i2)]
        return {"elev": rows}

    def close(self):
        self.closed = True


_FAKE_CONFIG_FILES = (
    "config.json",
    "coarse_model/config.json",
    "base_model/config.json",
    "decoder_model/config.json",
)
_FAKE_WEIGHT_FILES = (
    "coarse_model/diffusion_pytorch_model.safetensors",
    "base_model/diffusion_pytorch_model.safetensors",
    "decoder_model/diffusion_pytorch_model.safetensors",
)

_FAKE_STATS = {
    "n_quantiles": 64,
    "noise_quantile_tables": [[float(i) for i in range(64)] for _ in range(5)],
    "data_quantile_tables": [[float(i) * 2.0 for i in range(64)] for _ in range(5)],
    "a_temp_std": -34.75522148,
    "b_temp_std": 1189.49646289,
    "temp_std_p1": -900.94322882,
    "temp_std_p99": 630.01483608,
}


class ProviderCase(unittest.TestCase):
    """A fixture snapshot, stats table and scratch work root."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="png-test-")
        self.snapshot = os.path.join(self.tmp, "snapshot")
        os.makedirs(self.snapshot)
        self.stats = os.path.join(self.tmp, "pd.json")
        with open(self.stats, "w") as handle:
            json.dump(_FAKE_STATS, handle)
        self.work = os.path.join(self.tmp, "work")
        self.out = os.path.join(self.tmp, "out")

        config = dict(tb.EXPECTED_CONFIG)
        with open(os.path.join(self.snapshot, "config.json"), "w") as handle:
            json.dump(config, handle)

        self.config_pins = {}
        for relative in _FAKE_CONFIG_FILES:
            path = os.path.join(self.snapshot, relative)
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            if relative != "config.json":
                with open(path, "wb") as handle:
                    handle.write(json.dumps({"fixture": relative}).encode())
            with open(path, "rb") as handle:
                payload = handle.read()
            self.config_pins[relative] = {
                "sha256": hashlib.sha256(payload).hexdigest(),
                "bytes": len(payload),
            }

        self.weight_pins = {}
        for relative in _FAKE_WEIGHT_FILES:
            path = os.path.join(self.snapshot, relative)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            payload = ("fixture weights %s" % relative).encode()
            with open(path, "wb") as handle:
                handle.write(payload)
            self.weight_pins[relative] = {
                "sha256": hashlib.sha256(payload).hexdigest(),
                "bytes": len(payload),
            }

        # Pin tables and the source hash are patched for the same reason the
        # backend suite patches them: the real ones are gigabytes of artifacts.
        self._patches = [
            mock.patch.object(tb, "MODEL_CONFIGS", self.config_pins),
            mock.patch.object(tb, "MODEL_WEIGHTS", self.weight_pins),
            mock.patch.object(
                tb, "verify_upstream",
                return_value={"pin_verified_by": "source-hash",
                              "git_head": None,
                              "source_sha256": tb.UPSTREAM_SOURCE_SHA256},
            ),
            mock.patch.object(png, "check_readiness", png.check_readiness),
        ]
        for patcher in self._patches:
            patcher.start()
            self.addCleanup(patcher.stop)

        self.noise_lib = {"sha256": "c" * 64, "dist_info": False,
                          "note": "test fixture, not a measured build"}

        self._stats_pin = mock.patch.object(
            tb, "OFFICIAL_STATS_SHA256", tb._sha256_bytes(tb.canonical_json(_FAKE_STATS))
        )
        self._stats_pin.start()
        self.addCleanup(self._stats_pin.stop)

        # stats_source_path resolves relative to a cache root; point it here.
        self._stats_path = mock.patch.object(
            tb, "stats_source_path", side_effect=lambda root, src=None: self.stats
        )
        self._stats_path.start()
        self.addCleanup(self._stats_path.stop)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def generate(self, **overrides):
        progress_path = overrides.pop("progress_path", None)
        kwargs = {
            "out": self.out,
            "seed": 12345,
            "size": 32,
            "origin": (0, 0),
            "snapshot": self.snapshot,
            "stats_source": self.stats,
            "pipeline_factory": lambda identity: FakePipeline(),
            "noise_lib": self.noise_lib,
        }
        if "work_root" not in overrides:
            kwargs["work_root"] = self.work
        kwargs.update(overrides)
        # A caller may pass its own Stages; only synthesise one when the test
        # asked for a progress path and did not supply a recorder.
        if "stages" not in kwargs and progress_path is not None:
            kwargs["stages"] = png.Stages(io.StringIO(), progress_path=progress_path)
        return png.generate(**kwargs)


# ---------------------------------------------------------------------------
# Offline readiness
# ---------------------------------------------------------------------------


class ReadinessTests(ProviderCase):
    def test_check_reports_every_section_without_generating(self):
        report = png.check_readiness(
            snapshot=self.snapshot, stats_source=self.stats, cache_root=self.work
        )
        for name in ("snapshot", "pins", "upstream", "stats"):
            self.assertIn(name, report["checks"])
        # This suite runs on whatever interpreter is invoking it, which is not
        # always the provisioned venv, so assert the invariant rather than a
        # hardcoded pass.
        self.assertEqual(report["ok"], not report["problems"])
        self.assertFalse(os.path.exists(self.out), "--check must create nothing")

    def test_check_fails_closed_on_a_drifted_submodel_config(self):
        path = os.path.join(self.snapshot, "decoder_model/config.json")
        with open(path, "wb") as handle:
            handle.write(b'{"disable_out_gain": true}')
        report = png.check_readiness(
            snapshot=self.snapshot, stats_source=self.stats, cache_root=self.work
        )
        self.assertFalse(report["ok"])
        self.assertIn("pins", " ".join(report["problems"]))

    def test_check_reports_the_absolute_interpreter_path(self):
        report = png.check_readiness(
            snapshot=self.snapshot, stats_source=self.stats, cache_root=self.work
        )
        self.assertEqual(report["python_executable"], sys.executable)
        self.assertTrue(os.path.isabs(report["python_executable"]))
        self.assertTrue(report["python_version"])

    def test_check_reports_the_resolved_roots(self):
        report = png.check_readiness(
            snapshot=self.snapshot, stats_source=self.stats, cache_root=self.work
        )
        self.assertEqual(report["snapshot"], self.snapshot)
        self.assertTrue(report["upstream"])
        self.assertEqual(report["checks"]["stats"]["source"], self.stats)

    def test_cli_check_prints_interpreter_and_roots(self):
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            png.main([
                "--out", self.out, "--check",
                "--snapshot", self.snapshot, "--stats-json", self.stats,
            ])
        output = buffer.getvalue()
        self.assertIn(sys.executable, output)
        self.assertIn(self.snapshot, output)
        self.assertIn("ready-to-generate:", output)

    def test_check_never_imports_torch(self):
        png.check_readiness(
            snapshot=self.snapshot, stats_source=self.stats, cache_root=self.work
        )
        self.assertNotIn("torch", sys.modules)

    def test_cli_check_returns_zero_and_writes_nothing(self):
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = png.main([
                "--out", self.out, "--check",
                "--snapshot", self.snapshot, "--stats-json", self.stats,
            ])
        expected = (png.EXIT_READY if png.check_dependencies()["ok"]
                    else png.EXIT_REFUSED)
        self.assertEqual(code, expected)
        self.assertIn("ready-to-generate:", buffer.getvalue())
        self.assertFalse(os.path.exists(self.out))

    def test_cli_check_reports_a_verdict(self):
        report = png.check_readiness(
            snapshot=self.snapshot, stats_source=self.stats, cache_root=self.work
        )
        self.assertEqual(report["ok"], not report["problems"])


class DependencyReadinessTests(unittest.TestCase):
    """`--check` must not say ready when the runtime cannot import the sampler.

    Before this existed, a probe reported ready with torch, numpy, diffusers and
    safetensors all absent, and the run then failed at load.
    """

    REQUIRED = (
        ("torch", "torch", "2.13.0"),
        ("diffusers", "diffusers", "0.42.1"),
    )

    def test_all_present_and_matching_is_ok(self):
        report = png.check_dependencies(
            self.REQUIRED,
            find_spec=lambda name: object(),
            distribution=lambda dist: {"torch": "2.13.0",
                                       "diffusers": "0.42.1"}[dist],
        )
        self.assertTrue(report["ok"])
        self.assertEqual(report["missing"], [])
        self.assertEqual(report["version_mismatches"], [])
        self.assertTrue(all(e["version_matches_pin"]
                            for e in report["packages"].values()))

    def test_absent_package_makes_readiness_false(self):
        report = png.check_dependencies(
            self.REQUIRED,
            find_spec=lambda name: None if name == "torch" else object(),
            distribution=lambda dist: "0.42.1",
        )
        self.assertFalse(report["ok"])
        self.assertEqual(report["missing"], ["torch"])
        self.assertFalse(report["packages"]["torch"]["present"])

    def test_absent_distribution_metadata_also_counts_as_missing(self):
        def no_metadata(dist):
            raise Exception("PackageNotFoundError")

        report = png.check_dependencies(
            self.REQUIRED, find_spec=lambda name: object(), distribution=no_metadata
        )
        self.assertFalse(report["ok"])
        self.assertEqual(len(report["missing"]), 2)

    def test_version_mismatch_is_reported_but_not_a_hard_failure(self):
        report = png.check_dependencies(
            self.REQUIRED,
            find_spec=lambda name: object(),
            distribution=lambda dist: "9.9.9",
        )
        self.assertTrue(report["ok"], "a patch difference must not refuse a run")
        self.assertEqual(len(report["version_mismatches"]), 2)

    def test_spec_lookup_failure_is_treated_as_absent(self):
        def boom(name):
            raise ImportError("broken")

        report = png.check_dependencies(
            self.REQUIRED, find_spec=boom, distribution=lambda dist: "1.0"
        )
        self.assertFalse(report["ok"])

    def test_a_fully_provisioned_interpreter_reports_ok(self):
        """Interpreter-independent: this suite may run where torch is absent.

        The venv has the full stack; a bare `python3` often does not, and that
        difference is exactly what the check exists to surface.
        """
        report = png.check_dependencies()
        self.assertEqual(report["ok"], not report["missing"])
        self.assertEqual(report["required"], len(png.REQUIRED_RUNTIME))
        for dist, entry in report["packages"].items():
            self.assertIn("present", entry)
            self.assertIn("version", entry)

    def test_check_dependencies_never_imports_torch(self):
        png.check_dependencies()
        self.assertNotIn("torch", sys.modules)


class ReadinessDependencyGateTests(ProviderCase):
    """The gap, at the level the parent observes: exit status of `--check`."""

    def test_check_exit_status_fails_when_a_dependency_is_absent(self):
        import importlib.util as util

        real = util.find_spec

        def deny(name, *a, **k):
            if name.split(".")[0] == "torch":
                return None
            return real(name, *a, **k)

        buffer = io.StringIO()
        with mock.patch.object(util, "find_spec", side_effect=deny), \
                contextlib.redirect_stdout(buffer):
            code = png.main([
                "--out", self.out, "--check",
                "--snapshot", self.snapshot, "--stats-json", self.stats,
            ])
        self.assertEqual(code, png.EXIT_REFUSED)
        self.assertIn("ready-to-generate: no", buffer.getvalue())
        self.assertIn("MISSING torch", buffer.getvalue())

    def test_check_reports_the_dependencies_section(self):
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = png.main([
                "--out", self.out, "--check",
                "--snapshot", self.snapshot, "--stats-json", self.stats,
            ])
        output = buffer.getvalue()
        self.assertIn("dependencies", output)
        # Exit status tracks the real runtime, so assert the invariant rather
        # than assuming this interpreter is fully provisioned.
        report = png.check_dependencies()
        self.assertEqual(code, png.EXIT_READY if report["ok"] else png.EXIT_REFUSED)
        # --check remains a pure read either way.
        self.assertFalse(os.path.exists(self.out))


# ---------------------------------------------------------------------------
# Sampling
# ---------------------------------------------------------------------------


class SamplingTests(ProviderCase):
    def test_one_get_covers_the_whole_map_in_row_then_column_order(self):
        pipeline = FakePipeline()
        png.sample_region(pipeline, origin=(100, 200), size=32)
        self.assertEqual(pipeline.calls, [(200, 100, 232, 132)])

    def test_sampled_values_are_x_fastest_and_match_the_field(self):
        pipeline = FakePipeline()
        rows = png.sample_region(pipeline, origin=(0, 0), size=16)
        self.assertEqual(len(rows), 16)
        self.assertEqual(len(rows[0]), 16)
        for z in (0, 7, 15):
            for x in (0, 3, 15):
                self.assertAlmostEqual(rows[z][x], pipeline.elevation(x, z), places=4)

    def test_missing_elevation_is_refused(self):
        class Empty(FakePipeline):
            def get(self, i1, j1, i2, j2, with_climate=False):
                return {}

        with self.assertRaises(png.ProviderError):
            png.sample_region(Empty(), origin=(0, 0), size=16)

    def test_wrong_shape_is_refused_not_reshaped(self):
        class Wrong(FakePipeline):
            def get(self, i1, j1, i2, j2, with_climate=False):
                return {"elev": [[0.0] * 8 for _ in range(8)]}

        with self.assertRaises(png.ProviderError):
            png.sample_region(Wrong(), origin=(0, 0), size=16)

    def test_cancellation_before_sampling_stops_the_run(self):
        cancel = png._Cancellation()
        cancel.requested = True
        with self.assertRaises(png.Cancelled):
            png.sample_region(FakePipeline(), origin=(0, 0), size=16,
                              cancellation=cancel)


# ---------------------------------------------------------------------------
# Climate: the producer requests it, converts it and refuses a bad one
# ---------------------------------------------------------------------------


def _channel_value(channel, x, z):
    """A distinct, deterministic value per (channel, x, z).

    Distinct per channel so a transposed or interleaved read is detectable; the
    channel offset is 1000 so no two channels can collide with each other.
    """
    return 1000.0 * channel + x * 10.0 + z


class ClimatePipeline(FakePipeline):
    """A pipeline that answers the climate flag, upstream's ``(5, H, W)`` layout.

    Upstream stacks the five channels on the LEADING axis
    (``torch.stack([...])`` in ``world_pipeline._compute_climate``), so this fake
    does too -- emitting ``(H, W, 5)`` here would hide the transpose the producer
    must perform.
    """

    def __init__(self, climate=None, **kwargs):
        super().__init__(**kwargs)
        self.climate = climate
        self.flags = []

    def get(self, i1, j1, i2, j2, with_climate=False):
        self.flags.append(with_climate)
        result = super().get(i1, j1, i2, j2)
        if with_climate:
            if self.climate is not None:
                result["climate"] = self.climate
            else:
                result["climate"] = [
                    [[_channel_value(c, x, z) for x in range(j1, j2)]
                     for z in range(i1, i2)]
                    for c in range(png.CLIMATE_CHANNELS)
                ]
        return result


class ClimateSamplingTests(ProviderCase):
    def test_sample_map_requests_climate_in_the_same_single_get(self):
        pipeline = ClimatePipeline()
        rows, climate = png.sample_map(pipeline, origin=(0, 0), size=16)
        self.assertEqual(pipeline.flags, [True])
        self.assertEqual(pipeline.calls, [(0, 0, 16, 16)])
        self.assertEqual(len(rows), 16)
        self.assertEqual(len(climate), 16)

    def test_sample_region_still_asks_for_elevation_only(self):
        """The elevation-only contract is unchanged: it never asks for climate."""
        pipeline = ClimatePipeline()
        png.sample_region(pipeline, origin=(0, 0), size=16)
        self.assertEqual(pipeline.flags, [False])

    def test_leading_axis_becomes_trailing_axis_with_values_intact(self):
        pipeline = ClimatePipeline()
        _rows, climate = png.sample_map(pipeline, origin=(3, 5), size=8)
        self.assertEqual(len(climate), 8)          # rows (z)
        self.assertEqual(len(climate[0]), 8)       # columns (x)
        self.assertEqual(len(climate[0][0]), png.CLIMATE_CHANNELS)
        for z in range(8):
            for x in range(8):
                expected = [_channel_value(c, 3 + x, 5 + z)
                            for c in range(png.CLIMATE_CHANNELS)]
                self.assertEqual(climate[z][x], expected)

    def test_transformers_and_numpy_like_arrays_are_accepted(self):
        class Array:
            """Mimics a numpy array: `.detach()` then `.numpy()`, plus `.tolist()`."""

            def __init__(self, values):
                self.values = values

            def detach(self):
                return self

            def to(self, _device):
                return self

            def float(self):
                return self

            def numpy(self):
                return self

            def tolist(self):
                return self.values

        class ArrayPipeline(ClimatePipeline):
            def get(self, i1, j1, i2, j2, with_climate=False):
                result = FakePipeline.get(self, i1, j1, i2, j2)
                if with_climate:
                    result["climate"] = Array([
                        [[_channel_value(c, x, z) for x in range(j1, j2)]
                         for z in range(i1, i2)]
                        for c in range(png.CLIMATE_CHANNELS)
                    ])
                return result

        _rows, climate = png.sample_map(
            ArrayPipeline(), origin=(0, 0), size=4)
        self.assertEqual(climate[1][2][0], _channel_value(0, 2, 1))

    def test_absent_climate_is_none_not_a_fabricated_field(self):
        """A pipeline that reports no climate exports none -- unchanged behaviour."""
        class NoClimate(FakePipeline):
            def get(self, i1, j1, i2, j2, with_climate=False):
                return {"elev": super().get(i1, j1, i2, j2)["elev"],
                        "climate": None}

        _rows, climate = png.sample_map(NoClimate(), origin=(0, 0), size=4)
        self.assertIsNone(climate)

    def test_wrong_channel_count_is_refused(self):
        bad = [[[1.0] * 4 for _ in range(4)] for _ in range(4)]
        with self.assertRaises(png.ProviderError) as caught:
            png.sample_map(ClimatePipeline(climate=bad), origin=(0, 0), size=4)
        self.assertIn("4 channels", str(caught.exception))

    def test_channel_plane_disagreeing_with_the_grid_is_refused(self):
        bad = [[[1.0] * 4 for _ in range(3)]
               for _ in range(png.CLIMATE_CHANNELS)]
        with self.assertRaises(png.ProviderError) as caught:
            png.sample_map(ClimatePipeline(climate=bad), origin=(0, 0), size=4)
        self.assertIn("rows", str(caught.exception))

    def test_non_finite_climate_is_refused_not_defaulted(self):
        for number in (float("nan"), float("inf"), float("-inf")):
            good = [[[1.0] * 4 for _ in range(4)]
                    for _ in range(png.CLIMATE_CHANNELS)]
            good[2][1][3] = number
            with self.assertRaises(png.ProviderError) as caught:
                png.sample_map(ClimatePipeline(climate=good), origin=(0, 0), size=4)
            self.assertIn("finite", str(caught.exception))

    def test_non_numeric_and_bool_samples_are_refused(self):
        for bad_value in ("warm", True, None):
            good = [[[1.0] * 4 for _ in range(4)]
                    for _ in range(png.CLIMATE_CHANNELS)]
            good[0][0][0] = bad_value
            with self.assertRaises(png.ProviderError):
                png.sample_map(ClimatePipeline(climate=good), origin=(0, 0), size=4)

    def test_a_pipeline_without_the_flag_raises_instead_of_losing_climate(self):
        """No silent downgrade: a pipeline that cannot answer the flag fails."""
        class NoFlag(FakePipeline):
            def get(self, i1, j1, i2, j2):
                return {"elev": [[0.0] * 4 for _ in range(4)]}

        with self.assertRaises(TypeError):
            png.sample_map(NoFlag(), origin=(0, 0), size=4)


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------


class SettingsTests(unittest.TestCase):
    def base(self, **overrides):
        kwargs = dict(seed=12345, size=32, meters_per_voxel=25.0, sea_level=28,
                      profile="alpine", origin=(0, 0), world_origin=(0, 0))
        kwargs.update(overrides)
        return kwargs

    def test_valid_settings_pass(self):
        self.assertTrue(png.validate_settings(**self.base()))

    def test_seed_zero_is_a_valid_world_seed(self):
        """0 is a number a player can type; it must be accepted, not refused."""
        self.assertTrue(png.validate_settings(**self.base(seed=0)))

    def test_seed_bounds_are_enforced(self):
        for seed in (-1, png.MAX_SEED + 1):
            with self.assertRaises(png.ProviderError):
                png.validate_settings(**self.base(seed=seed))
        png.validate_settings(**self.base(seed=png.MAX_SEED))

    def test_size_is_bounded_and_tile_aligned(self):
        for size in (png.MIN_SIZE - 1, png.MAX_SIZE + 1, 24):
            with self.assertRaises(png.ProviderError):
                png.validate_settings(**self.base(size=size))
        png.validate_settings(**self.base(size=16))
        png.validate_settings(**self.base(size=512))

    def test_negative_meters_per_voxel_is_refused(self):
        with self.assertRaises(png.ProviderError):
            png.validate_settings(**self.base(meters_per_voxel=0))

    def test_unaligned_world_origin_is_refused(self):
        with self.assertRaises(png.ProviderError):
            png.validate_settings(**self.base(world_origin=(1, 0)))


class SeedMappingTests(unittest.TestCase):
    """World seed 0 must be reproducible without handing upstream a falsy seed."""

    def test_zero_maps_to_the_fixed_nonzero_model_seed(self):
        record = png.resolve_seed(0)
        self.assertEqual(record["world_seed"], 0)
        self.assertEqual(record["model_seed"], png.ZERO_SEED_MODEL_SEED)
        self.assertEqual(record["seed_mapping"], png.SEED_MAPPING_VERSION)
        self.assertTrue(record["remapped"])

    def test_mapped_model_seed_is_never_falsy(self):
        self.assertNotEqual(png.resolve_seed(0)["model_seed"], 0)
        self.assertGreater(png.resolve_seed(0)["model_seed"], 0)

    def test_nonzero_seeds_are_unchanged(self):
        for world_seed in (1, 42, 12345, png.MAX_SEED):
            record = png.resolve_seed(world_seed)
            self.assertEqual(record["world_seed"], world_seed)
            self.assertEqual(record["model_seed"], world_seed)
            self.assertFalse(record["remapped"])

    def test_out_of_range_world_seeds_are_refused(self):
        for bad in (-1, png.MAX_SEED + 1):
            with self.assertRaises(png.ProviderError):
                png.resolve_seed(bad)

    def test_mapping_is_deterministic(self):
        self.assertEqual(png.resolve_seed(0), png.resolve_seed(0))

    def test_mapping_version_is_part_of_the_constant(self):
        self.assertTrue(png.SEED_MAPPING_VERSION)
        self.assertEqual(png.SEED_MAPPING_VERSION, "nonzero-v1")


class SeedZeroGenerationTests(ProviderCase):
    """World seed 0 produces a real, reproducible artifact with clear metadata."""

    def test_zero_seed_generates_and_records_both_seeds(self):
        result = self.generate(seed=0)
        self.assertEqual(result["world_seed"], 0)
        self.assertEqual(result["model_seed"], png.ZERO_SEED_MODEL_SEED)
        self.assertEqual(result["seed_mapping"], png.SEED_MAPPING_VERSION)

        record = json.loads(open(os.path.join(
            self.out, result["identity"], st.SCENIC_JSON_NAME)).read())
        provenance = record["provenance"]
        self.assertEqual(provenance["world_seed"], 0)
        self.assertEqual(provenance["model_seed"], png.ZERO_SEED_MODEL_SEED)
        self.assertEqual(provenance["seed_mapping"], png.SEED_MAPPING_VERSION)
        self.assertIs(provenance["seed_remapped"], True)
        # The artifact's own seed field is the model seed that was sampled.
        self.assertEqual(provenance["seed"], png.ZERO_SEED_MODEL_SEED)
        self.assertTrue(os.path.exists(
            os.path.join(self.out, result["identity"], png.READY_NAME)))

    def test_zero_seed_never_hands_the_pipeline_a_falsy_seed(self):
        """The whole point: the model seed must be nonzero at the call site."""
        seen = {}

        def factory(identity):
            seen["seed"] = identity["seed"]
            return FakePipeline()

        self.generate(seed=0, pipeline_factory=factory)
        self.assertEqual(seen["seed"], png.ZERO_SEED_MODEL_SEED)
        self.assertNotEqual(seen["seed"], 0)

    def test_zero_seed_is_reproducible(self):
        first = self.generate(seed=0)
        second_out = os.path.join(self.tmp, "out2")
        second = self.generate(seed=0, out=second_out)
        self.assertEqual(first["identity"], second["identity"])
        self.assertEqual(first["tiles"], second["tiles"])

    def test_zero_and_max_share_terrain_but_not_identity(self):
        """The deliberate collision: same model seed, distinct provenance."""
        zero = self.generate(seed=0, out=os.path.join(self.tmp, "zero"))
        top = self.generate(seed=png.MAX_SEED, out=os.path.join(self.tmp, "top"))
        # Same model seed, so the sampled terrain is the same...
        self.assertEqual(top["model_seed"], zero["model_seed"])
        zero_tiles = os.path.join(self.tmp, "zero", zero["identity"], tc.TILE_DIR_NAME)
        top_tiles = os.path.join(self.tmp, "top", top["identity"], tc.TILE_DIR_NAME)
        names = sorted(os.listdir(zero_tiles))
        self.assertEqual(names, sorted(os.listdir(top_tiles)))
        for name in names:
            with open(os.path.join(zero_tiles, name), "rb") as handle:
                a = handle.read()
            with open(os.path.join(top_tiles, name), "rb") as handle:
                b = handle.read()
            self.assertEqual(a, b, "tile %s should be identical terrain" % name)
        # ...but the recorded provenance differs, so the identities differ.
        self.assertNotEqual(zero["identity"], top["identity"])

    def test_nonzero_identity_unchanged_by_the_mapping(self):
        """A nonzero world seed yields the same model seed as before the fix."""
        result = self.generate(seed=12345)
        self.assertEqual(result["model_seed"], 12345)
        self.assertEqual(result["world_seed"], 12345)


# ---------------------------------------------------------------------------
# End-to-end with the fake pipeline
# ---------------------------------------------------------------------------


class GenerationTests(ProviderCase):
    def test_generate_produces_a_verified_ready_artifact(self):
        result = self.generate()
        identity = result["identity"]
        directory = os.path.join(self.out, identity)

        for name in (st.MANIFEST_NAME, st.SCENIC_JSON_NAME,
                     st.SCENIC_MANIFEST_KEYS and "summary.json", png.READY_NAME):
            self.assertTrue(os.path.exists(os.path.join(directory, name)),
                            "missing %s" % name)

        record = st.read_scenic_manifest(self.out, identity)
        self.assertEqual(record["format"], st.SCENIC_FORMAT)
        self.assertEqual(record["magic"], "TDS3")
        self.assertEqual(len(record), 12)

        ready = json.loads(open(os.path.join(directory, png.READY_NAME)).read())
        self.assertTrue(ready["ready"])
        self.assertEqual(ready["identity"], identity)
        self.assertEqual(ready["provider"], "python-terrain-diffusion")
        self.assertTrue(ready["temporary"])

    def test_every_tile_decodes_under_the_manifest_band(self):
        result = self.generate()
        identity = result["identity"]
        record = st.read_scenic_manifest(self.out, identity)
        tiles = os.listdir(os.path.join(self.out, identity, tc.TILE_DIR_NAME))
        self.assertEqual(len(tiles), result["tiles"])
        for name in tiles:
            cx, cz = name[: -len(".tdh")].split("_")
            heights = st.read_scenic_tile(self.out, identity, int(cx), int(cz))
            if isinstance(heights, tuple):
                heights = heights[-1]
            self.assertTrue(all(record["height-min"] <= v <= record["height-max"]
                                for v in heights))

    def test_stages_are_discrete_and_ready_is_last(self):
        stream = io.StringIO()
        stages = png.Stages(stream)
        self.generate(stages=stages)
        lines = [json.loads(line) for line in stream.getvalue().splitlines()]
        reached = [line["stage"] for line in lines]
        self.assertEqual(reached, list(png.STAGES))
        self.assertEqual(reached[-1], "ready")
        for line in lines:
            self.assertNotIn("percent", json.dumps(line))
            self.assertNotIn("eta", json.dumps(line))

    def test_ready_flag_absconds_on_failure(self):
        class Boom(FakePipeline):
            def get(self, i1, j1, i2, j2, with_climate=False):
                raise RuntimeError("inference exploded")

        with self.assertRaises(RuntimeError):
            self.generate(pipeline_factory=lambda identity: Boom())
        # A partially created output root may exist, but nothing may claim ready.
        if os.path.isdir(self.out):
            for root, _dirs, files in os.walk(self.out):
                self.assertNotIn(png.READY_NAME, files)

    def test_refuses_a_non_empty_output_directory(self):
        os.makedirs(self.out)
        with open(os.path.join(self.out, "existing.txt"), "w") as handle:
            handle.write("a running game might read this")
        with self.assertRaises(png.ProviderError) as caught:
            self.generate()
        self.assertIn("not empty", str(caught.exception))

    def test_provenance_carries_the_pins(self):
        result = self.generate()
        identity = result["identity"]
        record = json.loads(
            open(os.path.join(self.out, identity, st.SCENIC_JSON_NAME)).read()
        )
        provenance = record["provenance"]
        self.assertEqual(provenance["seed"], 12345)
        self.assertEqual(provenance["model"], tb.MODEL_REPO)
        self.assertEqual(provenance["model_revision"], tb.MODEL_REVISION)
        self.assertTrue(provenance["temporary"])
        for key in ("weightset_sha256", "configset_sha256", "stats_sha256",
                    "sampler", "mapping", "settings"):
            self.assertIn(key, provenance)
        self.assertEqual(provenance["settings"]["size"], 32)

    def test_tiles_are_whole_and_match_the_declared_bounds(self):
        result = self.generate(size=32)
        record = st.read_scenic_manifest(self.out, result["identity"])
        bounds = record["bounds"]
        chunks = (bounds[2] - bounds[0] + 1) * (bounds[3] - bounds[1] + 1)
        self.assertEqual(result["tiles"], chunks)
        self.assertEqual(result["tiles"], (32 // tc.TILE_SIZE) ** 2)

    def test_pipeline_is_closed_on_success(self):
        created = []

        def factory(identity):
            pipeline = FakePipeline()
            created.append(pipeline)
            return pipeline

        self.generate(pipeline_factory=factory)
        self.assertTrue(created and created[0].closed)

    def test_pipeline_is_closed_on_failure(self):
        created = []

        class Boom(FakePipeline):
            def get(self, i1, j1, i2, j2, with_climate=False):
                raise RuntimeError("boom")

        def factory(identity):
            pipeline = Boom()
            created.append(pipeline)
            return pipeline

        with self.assertRaises(RuntimeError):
            self.generate(pipeline_factory=factory)
        self.assertTrue(created and created[0].closed)

    def test_cancellation_leaves_no_ready_flag(self):
        stream = io.StringIO()
        stages = png.Stages(stream)

        # SIGTERM lands while the model is working: the handler sets the flag,
        # and the next checkpoint (before export) must abandon the run.
        signals = {}

        class Slow(FakePipeline):
            def get(self, i1, j1, i2, j2, with_climate=False):
                signals["cancel"].requested = True
                return super().get(i1, j1, i2, j2)

        class Recording(png._Cancellation):
            def __enter__(self):
                signals["cancel"] = self
                return super().__enter__()

        with mock.patch.object(png, "_Cancellation", Recording):
            with self.assertRaises(png.Cancelled):
                self.generate(stages=stages, pipeline_factory=lambda i: Slow())
        if os.path.isdir(self.out):
            for root, _dirs, files in os.walk(self.out):
                self.assertNotIn(png.READY_NAME, files)
        # `generate` raises; only `main` reports the cancel stage, so assert the
        # flag reached no ready stage and the artifact has no marker.
        self.assertNotIn("ready", stages.reached)
        self.assertIn("sample", stages.reached)

    def test_cli_returns_failed_on_a_model_error(self):
        class Boom(FakePipeline):
            def get(self, i1, j1, i2, j2, with_climate=False):
                raise RuntimeError("boom")

        with contextlib.redirect_stderr(io.StringIO()):
            code = png.main(
                ["--out", self.out, "--size", "32", "--seed", "12345",
                 "--snapshot", self.snapshot, "--stats-json", self.stats],
                pipeline_factory=lambda identity: Boom(),
                stages_stream=io.StringIO(),
                noise_lib=self.noise_lib,
            )
        self.assertEqual(code, png.EXIT_FAILED)

    def test_cli_returns_refused_on_bad_settings(self):
        with contextlib.redirect_stderr(io.StringIO()):
            code = png.main(
                ["--out", self.out, "--size", "32", "--seed", "-1",
                 "--snapshot", self.snapshot, "--stats-json", self.stats],
                pipeline_factory=lambda identity: FakePipeline(),
                stages_stream=io.StringIO(),
                noise_lib=self.noise_lib,
            )
        self.assertEqual(code, png.EXIT_REFUSED)


class ScratchRootTests(ProviderCase):
    """The load path must never touch a cache that belongs to another world.

    Regression for the first real New Game attempt: with no explicit work root,
    the provider wrote its identity directory into the backend's SHARED default
    cache root, which already held a different generation, so the run was refused
    before any inference.
    """

    def _legacy_root(self):
        legacy = os.path.join(self.tmp, "legacy-cache")
        occupied = os.path.join(legacy, "e22d1dfe" + "0" * 56)
        os.makedirs(occupied)
        with open(os.path.join(occupied, "manifest.json"), "w") as handle:
            handle.write("{}")
        return legacy

    def test_scratch_root_is_unique_per_call(self):
        first = png.scratch_root()
        second = png.scratch_root()
        self.addCleanup(shutil.rmtree, first, True)
        self.addCleanup(shutil.rmtree, second, True)
        self.assertNotEqual(first, second)
        self.assertTrue(os.path.isdir(first))
        self.assertIn(png.SCRATCH_PREFIX, os.path.basename(first))

    def test_load_path_does_not_touch_the_shared_default_cache_root(self):
        legacy = self._legacy_root()
        identity, _snapshot, _upstream = png.build_provider_identity(
            seed=4, size=32, origin=(0, 0), snapshot=self.snapshot,
            stats_source=self.stats, cache_root=self.work, noise_lib=self.noise_lib,
        )
        with mock.patch.object(tb, "DEFAULT_CACHE_ROOT", legacy):
            digest, layout = png.write_identity_for_sampler(
                identity, stats_source=self.stats, cache_root=None
            )
        # The legacy root is byte-for-byte untouched...
        self.assertEqual(os.listdir(legacy), ["e22d1dfe" + "0" * 56])
        # ...and the identity went somewhere private, outside the artifact.
        self.assertNotIn(legacy, layout.root)
        self.assertTrue(layout.root.startswith(png.scratch_root.__globals__[
            "os"].path.dirname(layout.root)))
        shutil.rmtree(os.path.dirname(layout.root), ignore_errors=True)

    def test_generate_cleans_its_own_scratch_root(self):
        created = []
        real = png.scratch_root

        def recording(parent=None):
            path = real(parent)
            created.append(path)
            return path

        # A fake pipeline bypasses the scratch root entirely, so exercise the
        # real helper the way the load path does.
        with mock.patch.object(png, "scratch_root", recording):
            identity, _s, _u = png.build_provider_identity(
                seed=9, size=32, origin=(0, 0), snapshot=self.snapshot,
                stats_source=self.stats, cache_root=self.work,
                noise_lib=self.noise_lib,
            )
            png.write_identity_for_sampler(identity, stats_source=self.stats,
                                           cache_root=None)
            shutil.rmtree(os.path.dirname(created[0]), ignore_errors=True)
        self.assertTrue(created, "generate should have created a scratch root")
        for path in created:
            self.assertFalse(os.path.exists(path),
                             "scratch root %s was left behind" % path)

    def test_a_caller_supplied_work_root_is_never_deleted(self):
        """A work root the caller owns must survive the run.

        The fixture's fake pipeline never touches the scratch path, so the
        property under test is that `generate` does not remove a caller-supplied
        directory -- not that it creates one.
        """
        os.makedirs(self.work)
        sentinel = os.path.join(self.work, "keep.txt")
        with open(sentinel, "w") as handle:
            handle.write("mine")
        self.generate(work_root=self.work)
        self.assertTrue(os.path.isdir(self.work))
        self.assertTrue(os.path.exists(sentinel))

    def test_a_new_seed_does_not_disturb_an_existing_generation(self):
        legacy = self._legacy_root()
        marker = os.path.join(legacy, "e22d1dfe" + "0" * 56, "manifest.json")
        before = open(marker, "rb").read()
        identity, _s, _u = png.build_provider_identity(
            seed=7, size=32, origin=(0, 0), snapshot=self.snapshot,
            stats_source=self.stats, cache_root=self.work, noise_lib=self.noise_lib,
        )
        with mock.patch.object(tb, "DEFAULT_CACHE_ROOT", legacy):
            png.write_identity_for_sampler(identity, stats_source=self.stats,
                                           cache_root=None)
        self.assertEqual(open(marker, "rb").read(), before)
        self.assertEqual(os.listdir(legacy), ["e22d1dfe" + "0" * 56])


class ClippingTests(unittest.TestCase):
    """A map with no surviving relief must not be marked ready."""

    def assess(self, metres, mv=25.0, sea=28, lo=4, hi=252):
        return png.clip_assessment(
            metres, meters_per_voxel=mv, sea_level=sea, baseline_elevation_m=0.0,
            height_min=lo, height_max=hi,
        )

    def grid(self, value, size=8):
        return [[float(value)] * size for _ in range(size)]

    def test_deep_ocean_map_is_all_clipped_below(self):
        # The real seed-4 map: every sample is far below the band.
        record = self.assess(self.grid(-2082.8))
        self.assertTrue(record["all_clipped"])
        self.assertEqual(record["bound"], "min")
        self.assertEqual(record["clipped_below_min"], record["samples"])
        self.assertIn("clipped to minimum", record["reason"])

    def test_very_tall_map_is_all_clipped_above(self):
        record = self.assess(self.grid(9000.0))
        self.assertTrue(record["all_clipped"])
        self.assertEqual(record["bound"], "max")
        self.assertIn("clipped to maximum", record["reason"])

    def test_exact_band_boundary_is_NOT_treated_as_clipped(self):
        """A value landing exactly on the limit has destroyed no relief.

        `summary.json` would count these as clamped (`value <= height_min`), which
        is why the gate re-derives from raw metres. Voxel 4 spans [-612.5,-587.5),
        so -600 m is legally voxel 4 and must not trip the refusal.
        """
        record = self.assess(self.grid(-600.0))
        self.assertEqual(record["raw_voxel_min"], 4)
        self.assertEqual(record["raw_voxel_max"], 4)
        self.assertEqual(record["clipped_below_min"], 0)
        self.assertFalse(record["all_clipped"])

    def test_exact_top_boundary_is_NOT_treated_as_clipped(self):
        # Voxel 252 spans [5587.5, 5612.5).
        record = self.assess(self.grid(5600.0))
        self.assertEqual(record["raw_voxel_max"], 252)
        self.assertEqual(record["clipped_above_max"], 0)
        self.assertFalse(record["all_clipped"])

    def test_a_genuine_flat_plateau_is_allowed(self):
        """Legitimate flat terrain is not the same as destroyed relief."""
        record = self.assess(self.grid(1500.0))
        self.assertFalse(record["all_clipped"])
        self.assertEqual(record["raw_voxel_min"], record["raw_voxel_max"])

    def test_partial_clipping_is_reported_but_not_refused(self):
        metres = [[-3000.0 if (x + z) % 4 == 0 else 1500.0 for x in range(8)]
                  for z in range(8)]
        record = self.assess(metres)
        self.assertFalse(record["all_clipped"])
        self.assertGreater(record["clipped_below_min"], 0)
        self.assertLess(record["clipped_below_min"], record["samples"])

    def test_mixed_above_and_below_is_not_all_clipped(self):
        metres = [[-3000.0, 9000.0] * 4 for _ in range(8)]
        record = self.assess(metres)
        self.assertFalse(record["all_clipped"])

    def test_empty_map_is_refused(self):
        with self.assertRaises(png.ProviderError):
            self.assess([])


class ClimateExportTests(ProviderCase):
    """End to end: what the exporter actually writes, and what it leaves alone."""

    def _raw_record(self):
        """The producer's own sidecar for the raw export it just wrote."""
        return json.load(open(os.path.join(self.out, "raw_export.json")))

    def test_climate_capable_run_exports_the_array_and_flags_it(self):
        result = self.generate(
            pipeline_factory=lambda identity: ClimatePipeline())

        # The producer's sidecar says climate is present ...
        self.assertTrue(self._raw_record()["has_climate"])
        # ... and the container actually carries it, (H, W, 5) on disk.
        import numpy as np
        with np.load(os.path.join(self.out, "raw_export.npz")) as arrays:
            self.assertEqual(sorted(arrays.files),
                             ["climate", "elevation_m", "origin_pixels",
                              "pixels_per_voxel", "seed"])
            climate = arrays["climate"]
            elevation = arrays["elevation_m"]
        self.assertEqual(climate.shape, (32, 32, png.CLIMATE_CHANNELS))
        self.assertEqual(climate.shape[:2], elevation.shape)
        # Values survive the transpose: channel c at (z, x) is c's own sample.
        self.assertEqual(float(climate[3, 5, 0]), _channel_value(0, 5, 3))
        self.assertEqual(float(climate[3, 5, 4]), _channel_value(4, 5, 3))
        # The artifact itself still verifies and is ready.
        self.assertTrue(os.path.exists(os.path.join(
            self.out, result["identity"], png.READY_NAME)))

    def test_elevation_only_run_records_has_climate_false(self):
        """The old path is untouched: no climate array, no climate claim."""
        self.generate(pipeline_factory=lambda identity: FakePipeline())
        self.assertFalse(self._raw_record()["has_climate"])

        import numpy as np
        with np.load(os.path.join(self.out, "raw_export.npz")) as arrays:
            self.assertNotIn("climate", arrays.files)

    def test_malformed_climate_fails_the_run_and_leaves_no_ready(self):
        bad_climate = [[[float("nan")] * 32 for _ in range(32)]
                       for _ in range(png.CLIMATE_CHANNELS)]
        with self.assertRaises(png.ProviderError):
            self.generate(
                pipeline_factory=lambda identity: ClimatePipeline(
                    climate=bad_climate))
        for root, _dirs, files in os.walk(self.out):
            self.assertNotIn(png.READY_NAME, files)


class ClippingGateTests(ProviderCase):
    """End to end: the refusal preserves the artifact but writes no READY."""

    def _deep_ocean_pipeline(self):
        # Far below the band, mimicking the real seed-4 result.
        # Band floor is -612.5 m, so anything here is strictly below it.
        return lambda identity: FakePipeline(low=-2400.0, high=-1900.0)

    def test_all_clipped_map_is_refused_with_no_ready_marker(self):
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            code = png.main(
                ["--out", self.out, "--size", "32", "--seed", "4",
                 "--snapshot", self.snapshot, "--stats-json", self.stats],
                pipeline_factory=self._deep_ocean_pipeline(),
                stages_stream=io.StringIO(), noise_lib=self.noise_lib,
            )
        self.assertEqual(code, png.EXIT_REFUSED)
        message = stderr.getvalue()
        self.assertIn("clipped to minimum", message)
        self.assertIn("another seed", message)
        # No artifact may claim ready.
        for root, _d, files in os.walk(self.out):
            self.assertNotIn(png.READY_NAME, files)

    def test_refusal_keeps_the_artifact_and_raw_as_a_diagnostic(self):
        with contextlib.redirect_stderr(io.StringIO()):
            png.main(
                ["--out", self.out, "--size", "32", "--seed", "4",
                 "--snapshot", self.snapshot, "--stats-json", self.stats],
                pipeline_factory=self._deep_ocean_pipeline(),
                stages_stream=io.StringIO(), noise_lib=self.noise_lib,
            )
        self.assertTrue(os.path.exists(os.path.join(self.out, "raw_export.npz")))
        identities = [n for n in os.listdir(self.out)
                      if len(n) == 64 and all(c in "0123456789abcdef" for c in n)]
        self.assertEqual(len(identities), 1, "the artifact should be preserved")
        self.assertFalse(os.path.exists(
            os.path.join(self.out, identities[0], png.READY_NAME)))

    def test_refusal_publishes_a_failed_progress_stage(self):
        path = os.path.join(self.tmp, "progress.janet")
        with contextlib.redirect_stderr(io.StringIO()):
            png.main(
                ["--out", self.out, "--size", "32", "--seed", "4",
                 "--progress", path, "--snapshot", self.snapshot,
                 "--stats-json", self.stats],
                pipeline_factory=self._deep_ocean_pipeline(),
                stages_stream=io.StringIO(), noise_lib=self.noise_lib,
            )
        record = png.read_progress(path)
        self.assertEqual(record["stage"], "failed")
        self.assertIn("clipped", record["message"])

    def test_land_map_is_still_marked_ready(self):
        result = self.generate(size=32, seed=12345)
        self.assertFalse(result["clipping"]["all_clipped"])
        self.assertTrue(os.path.exists(
            os.path.join(self.out, result["identity"], png.READY_NAME)))


class OutputRootTests(ProviderCase):
    """The output root must not refuse a run's own progress sidecar."""

    def test_progress_inside_the_out_root_does_not_self_reject(self):
        """Regression: the sidecar was written before the emptiness check."""
        prog = os.path.join(self.out, "progress.janet")
        result = self.generate(progress_path=prog)
        self.assertTrue(os.path.exists(prog))
        self.assertTrue(os.path.exists(
            os.path.join(self.out, result["identity"], png.READY_NAME)))
        self.assertEqual(png.read_progress(prog)["stage"], "ready")
        # The identity directory is the only map content in the root.
        entries = sorted(os.listdir(self.out))
        self.assertIn(result["identity"], entries)

    def test_progress_outside_the_out_root_works_too(self):
        prog = os.path.join(self.tmp, "stage.janet")
        result = self.generate(progress_path=prog)
        self.assertTrue(os.path.exists(prog))
        self.assertEqual(png.read_progress(prog)["stage"], "ready")
        self.assertNotIn("progress.janet", os.listdir(self.out))
        self.assertTrue(os.path.exists(
            os.path.join(self.out, result["identity"], png.READY_NAME)))

    def test_tolerance_is_scoped_to_the_named_path_not_to_an_extension(self):
        """Only the run's OWN sidecar path is tolerated, never a stray .janet.

        Tolerating by extension would let an unrelated file hide behind a name.
        Here the root already holds `other.janet`, which this run is NOT using as
        its progress file, so the root is genuinely occupied.
        """
        os.makedirs(self.out)
        with open(os.path.join(self.out, "other.janet"), "w") as handle:
            handle.write("{}\n")
        with self.assertRaises(png.ProviderError) as caught:
            self.generate(progress_path=os.path.join(self.out, "job-stage.janet"))
        self.assertIn("not empty", str(caught.exception))
        self.assertIn("other.janet", str(caught.exception))

    def test_the_default_sidecar_name_is_always_tolerated(self):
        os.makedirs(self.out)
        with open(os.path.join(self.out, png.PROGRESS_DEFAULT_NAME), "w") as handle:
            handle.write("{}\n")
        result = self.generate()
        self.assertTrue(os.path.exists(
            os.path.join(self.out, result["identity"], png.READY_NAME)))

    def test_exact_progress_path_already_present_is_honoured(self):
        prog = os.path.join(self.out, "job-stage.janet")
        os.makedirs(self.out)
        with open(prog, "w") as handle:
            handle.write("{}\n")
        self.generate(progress_path=prog)
        self.assertEqual(png.read_progress(prog)["stage"], "ready")

    def test_non_progress_content_still_refuses(self):
        os.makedirs(self.out)
        with open(os.path.join(self.out, "stale.tdh"), "wb") as handle:
            handle.write(b"existing")
        with self.assertRaises(png.ProviderError) as caught:
            self.generate()
        self.assertIn("not empty", str(caught.exception))
        self.assertIn("stale.tdh", str(caught.exception))

    def test_a_whole_identity_directory_still_refuses(self):
        """An existing map must never be overwritten, sidecar or not."""
        first = self.generate()
        with self.assertRaises(png.ProviderError):
            self.generate(progress_path=os.path.join(self.out, "progress.janet"))

    def test_prepare_output_tolerates_only_the_sidecar_name(self):
        os.makedirs(self.out)
        png.prepare_output(self.out)  # clean root is fine
        with open(os.path.join(self.out, png.PROGRESS_DEFAULT_NAME), "w") as handle:
            handle.write("{}\n")
        png.prepare_output(self.out)  # sidecar alone is tolerated
        with open(os.path.join(self.out, "tiles"), "w") as handle:
            handle.write("x")
        with self.assertRaises(png.ProviderError):
            png.prepare_output(self.out)


class ProgressSidecarTests(unittest.TestCase):
    """The progress sidecar is inert Janet data the game can parse and poll."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="png-progress-")
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def path(self, name="progress.janet"):
        return os.path.join(self.tmp, name)

    def test_record_is_one_janet_table_with_the_declared_keys(self):
        text = png.render_progress(
            stage="sample", completed=1, total=8, message="working"
        ).decode()
        self.assertTrue(text.startswith("{:version 1 :stage :sample "))
        self.assertTrue(text.endswith("}\n"))
        for key in (":version", ":stage", ":completed", ":total", ":message"):
            self.assertIn(key, text)

    def test_stage_is_a_whitelisted_keyword(self):
        for stage in png.PROGRESS_STAGES:
            text = png.render_progress(stage=stage).decode()
            self.assertIn(":stage :%s " % stage, text)
        with self.assertRaises(png.ProviderError):
            png.render_progress(stage="halfway")

    def test_terminal_stages_are_in_the_whitelist(self):
        self.assertIn("failed", png.PROGRESS_STAGES)
        self.assertIn("cancelled", png.PROGRESS_STAGES)
        self.assertEqual(set(png.PROGRESS_STAGES),
                         set(png.STAGES) | {"failed", "cancelled"})

    def test_message_is_escaped_so_it_cannot_break_the_literal(self):
        nasty = 'q"uote back\\slash new\nline tab\there'
        text = png.render_progress(stage="failed", message=nasty).decode()
        self.assertIn('\\"', text)
        self.assertNotIn('\nline', text.split(":message")[1].rstrip("}\n"))
        self.assertEqual(len(text.splitlines()), 1)

    def test_unbounded_or_negative_counts_are_refused(self):
        for bad in (-1, "3", 1.5, True):
            with self.assertRaises(png.ProviderError):
                png.render_progress(stage="sample", completed=bad)

    def test_oversized_message_is_refused_rather_than_truncated(self):
        with self.assertRaises(png.ProviderError) as caught:
            png.render_progress(stage="failed", message="x" * png.PROGRESS_MAX_BYTES)
        self.assertIn("over the", str(caught.exception))

    def test_write_is_atomic_and_leaves_no_temp_file(self):
        path = self.path()
        png.write_progress(path, stage="load", completed=2, total=7)
        self.assertTrue(os.path.exists(path))
        leftovers = [n for n in os.listdir(self.tmp) if n.startswith(".progress-tmp")]
        self.assertEqual(leftovers, [])
        record = png.read_progress(path)
        self.assertEqual(record["stage"], "load")
        self.assertEqual(record["completed"], 2)
        self.assertEqual(record["total"], 7)

    def test_rewriting_the_same_path_updates_in_place(self):
        path = self.path()
        png.write_progress(path, stage="resolve")
        png.write_progress(path, stage="ready")
        self.assertEqual(png.read_progress(path)["stage"], "ready")
        self.assertEqual(len(os.listdir(self.tmp)), 1)

    def test_stages_write_the_sidecar_on_every_emit(self):
        path = self.path()
        stages = png.Stages(io.StringIO(), progress_path=path)
        stages.emit("resolve", seed=1)
        self.assertEqual(png.read_progress(path)["stage"], "resolve")
        stages.emit("verify")
        self.assertEqual(png.read_progress(path)["stage"], "verify")

    def test_no_progress_file_without_a_path(self):
        before = set(os.listdir(self.tmp))
        stages = png.Stages(io.StringIO())
        stages.emit("resolve")
        stages.fail("boom")
        self.assertEqual(set(os.listdir(self.tmp)), before)

    def test_failure_and_cancel_publish_terminal_stages(self):
        failed = self.path("f.janet")
        png.Stages(io.StringIO(), progress_path=failed).fail("model exploded")
        record = png.read_progress(failed)
        self.assertEqual(record["stage"], "failed")
        self.assertEqual(record["message"], "model exploded")

        cancelled = self.path("c.janet")
        png.Stages(io.StringIO(), progress_path=cancelled).cancel("sample")
        record = png.read_progress(cancelled)
        self.assertEqual(record["stage"], "cancelled")
        self.assertIn("sample", record["message"])


class ProgressIntegrationTests(ProviderCase):
    """The sidecar tracks a whole run, and never lies about success."""

    def test_run_publishes_each_stage_and_ends_on_ready(self):
        path = os.path.join(self.tmp, "progress.janet")
        stages = png.Stages(io.StringIO(), progress_path=path)
        self.generate(stages=stages)
        self.assertEqual(png.read_progress(path)["stage"], "ready")
        # A READY marker is still required; the progress file proves nothing on
        # its own.
        seen = [json.loads(line)["stage"]
                for line in stages.stream.getvalue().splitlines()]
        self.assertEqual(seen, list(png.STAGES))

    def test_failed_run_publishes_failed_and_no_ready(self):
        path = os.path.join(self.tmp, "progress.janet")

        class Boom(FakePipeline):
            def get(self, i1, j1, i2, j2, with_climate=False):
                raise RuntimeError("exploded")

        with contextlib.redirect_stderr(io.StringIO()):
            code = png.main(
                ["--out", self.out, "--size", "32", "--seed", "12345",
                 "--snapshot", self.snapshot, "--stats-json", self.stats,
                 "--progress", path],
                pipeline_factory=lambda identity: Boom(),
                stages_stream=io.StringIO(),
                noise_lib=self.noise_lib,
            )
        self.assertEqual(code, png.EXIT_FAILED)
        self.assertEqual(png.read_progress(path)["stage"], "failed")
        for root, _dirs, files in os.walk(self.out):
            self.assertNotIn(png.READY_NAME, files)

    def test_check_writes_no_progress_even_when_asked(self):
        path = os.path.join(self.tmp, "must-not-appear.janet")
        with contextlib.redirect_stdout(io.StringIO()):
            png.main([
                "--out", self.out, "--check", "--progress", path,
                "--snapshot", self.snapshot, "--stats-json", self.stats,
            ])
        self.assertFalse(os.path.exists(path),
                         "--check must never write a progress file")

    def test_cancelled_run_publishes_cancelled_and_no_ready(self):
        path = os.path.join(self.tmp, "progress.janet")
        signals = {}

        class Slow(FakePipeline):
            def get(self, i1, j1, i2, j2, with_climate=False):
                signals["cancel"].requested = True
                return super().get(i1, j1, i2, j2)

        class Recording(png._Cancellation):
            def __enter__(self):
                signals["cancel"] = self
                return super().__enter__()

        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr), \
                mock.patch.object(png, "_Cancellation", Recording):
            code = png.main(
                ["--out", self.out, "--size", "32", "--seed", "12345",
                 "--snapshot", self.snapshot, "--stats-json", self.stats,
                 "--progress", path],
                pipeline_factory=lambda identity: Slow(),
                stages_stream=io.StringIO(),
                noise_lib=self.noise_lib,
            )
        self.assertEqual(code, png.EXIT_CANCELLED, stderr.getvalue())
        self.assertEqual(png.read_progress(path)["stage"], "cancelled")
        for root, _dirs, files in os.walk(self.out):
            self.assertNotIn(png.READY_NAME, files)


# ---------------------------------------------------------------------------
# Process discipline
# ---------------------------------------------------------------------------


class ProcessTests(unittest.TestCase):
    def test_module_never_spawns_children_or_imports_torch(self):
        """Asserted on the parsed module, so prose cannot mask real usage."""
        import ast

        with open(png.__file__) as handle:
            tree = ast.parse(handle.read())
        imported = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imported.add(alias.name.split(".")[0])
            elif isinstance(node, ast.ImportFrom) and node.module:
                imported.add(node.module.split(".")[0])
        for forbidden in ("subprocess", "multiprocessing", "torch",
                          "huggingface_hub", "requests", "urllib"):
            self.assertNotIn(forbidden, imported,
                             "the provider must not import %s" % forbidden)
        # And no dynamic process/network entry point by attribute name.
        attributes = {
            node.attr for node in ast.walk(tree) if isinstance(node, ast.Attribute)
        }
        for forbidden in ("fork", "execv", "system", "spawn", "popen", "urlopen"):
            self.assertNotIn(forbidden, attributes)

    def test_stage_list_is_fixed_and_ends_with_ready(self):
        self.assertEqual(png.STAGES[-1], "ready")
        self.assertEqual(len(png.STAGES), len(set(png.STAGES)))

    def test_unknown_stage_is_refused(self):
        with self.assertRaises(png.ProviderError):
            png.Stages(io.StringIO()).emit("halfway", percent=50)


if __name__ == "__main__":
    unittest.main()
