# Headless contract tests for static hydrology analysis. No window, no GL, no
# files, no model, no compiler work.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/static-hydrology-test.janet
#
# What these pin is the ANALYSIS, not water. Every assertion below is about
# geometry, determinism and ownership; none claims that anything flows, and none
# claims a pit is a filled lake. A test asserting "there is a river here" would be
# asserting a rendering decision this module deliberately does not make.

(import ../src/static-hydrology :as hydro)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(defn refuses? [f]
  (try (do (f) false) ([_] true)))

# Element-wise comparison. Frozen/plan arrays must never be compared with `=`,
# which on two mutable arrays tests identity, or with `string`, which on a tuple
# prints a pointer. Both mistakes pass vacuously.
(defn same-seq? [a b]
  (if (not= (length a) (length b))
    false
    (do
      (var ok true)
      (for i 0 (length a)
        (unless (= (get a i) (get b i)) (set ok false)))
      ok)))

(defn every-true?
  ``True only when every element of `xs` is truthy, as a real BOOLEAN.

  Written out rather than using `every?`, because this runtime's `every?` takes
  exactly ONE argument -- the conventional `(every? pred xs)` is a compile error
  here -- and the one-argument form returns the LAST ELEMENT rather than a
  boolean, so `(every? [true 1])` yields `1`. A predicate that leaks a non-boolean
  into a check is the same class of mistake this module's river mask exists to
  avoid, so the helper makes the answer explicit.``
  [xs]
  (do
    (var ok true)
    (for i 0 (length xs)
      (unless (get xs i) (set ok false)))
    ok))

#
# --- Fixtures -----------------------------------------------------------
#
# Heights are integer VOXELS, x-fastest (index = x + cols*z), the tiling the
# engine's height reader already uses. Built with an explicit loop so the layout
# stays visible instead of hiding inside a mapper.
#

(defn grid [rows cols f]
  (def out @[])
  (for z 0 rows
    (for x 0 cols
      (array/push out (f x z))))
  out)

(defn east-slope [rows cols top] (grid rows cols (fn [x z] (- top x))))
(defn flat-grid [rows cols h] (grid rows cols (fn [x z] h)))

#
# --- A drained plane reaches an outlet --------------------------------
#
(print "sloped plane:")

(def slope (hydro/analyze (east-slope 4 4 40) 4 4))
(check "a monotone slope has no basin"
       (zero? (get (slope :cells) :basin))
       (string (get (slope :cells) :basin)))
(check "a monotone slope drains off the eastern edge"
       (= 4 (get (slope :cells) :outflow)))
(check "interior cells drain east"
       (= [(inc 1) 1] (hydro/direction-to slope 1 1))
       (string (hydro/direction-to slope 1 1)))
# Upstream-first: the +x end of a row collects the whole row.
(check "the upstream cell accumulates its whole row"
       (= 4 (hydro/accumulation-at slope 3 0)))
(check "the downstream end accumulates one cell"
       (= 1 (hydro/accumulation-at slope 0 0)))
# The downstream accessor answers the SAME question as the coordinate accessor,
# in flat-index form: a caller working over the array must not have to convert.
(check "the flat downstream index matches the coordinate direction"
       (let [i (hydro/downstream-at slope 0 0)
             d (hydro/direction-to slope 0 0)]
         (and (= i (hydro/index-of 4 (get d 0) (get d 1)))
              (nil? (hydro/outlet-kind-at slope 0 0)))))

# The plan announces what it is: an authored analysis of voxels, not climate and
# not flowing water.
(check "the plan names itself an authored static analysis"
       (= :authored-static-analysis (slope :kind)))
(check "the plan records a version" (number? (slope :version)))
(check "the plan declares voxel units" (= :voxels (slope :units)))
(check "the plan reports its grid dimensions"
       (and (= 4 (slope :rows)) (= 4 (slope :cols))))

#
# --- Pits are BASINS, never filled lakes -----------------------------
#
(print "\npits:")

# A cell lower than all eight neighbours cannot drain under a STRICT step. It is
# reported as a :basin cell -- not as a lake, and never with a water level, because
# this analysis does not know how deep a lake would be.
(def pit @[50 50 50
           50 10 50
           50 50 50])
(def pit-plan (hydro/analyze pit 3 3))
(check "a lower cell in a ring is a basin"
       (= 1 (get (pit-plan :cells) :basin)))
(check "the basin cell reports :basin"
       (= :basin (hydro/outlet-kind-at pit-plan 1 1)))
(check "a basin has no downstream index"
       (nil? (hydro/downstream-at pit-plan 1 1)))
(check "the plan carries no water level, so it cannot claim a lake"
       (not (has-key? pit-plan :lake-level)))
(check "the surrounding ring is not flat"
       (zero? (get (pit-plan :cells) :flat)))
(check "no cell reports a direction into itself"
       (do
         (var ok true)
         (for z 0 3
           (for x 0 3
             (def d (hydro/direction-to pit-plan x z))
             (when (indexed? d)
               (when (= d [x z]) (set ok false)))))
         ok))

# Two LOW cells side by side are NOT two basins: each has an equal neighbour, so a
# strict step cannot separate them and the pair is a plateau. This distinction is
# the reason the module separates :flat from :basin at all.
(def twin @[50 50 50 50
             10 10 50 50
             50 50 50 50
             50 50 50 50])
(def twin-plan (hydro/analyze twin 4 4))
(check "adjacent equal lows form a plateau, not two basins"
       (and (zero? (get (twin-plan :cells) :basin))
            (pos? (get (twin-plan :cells) :flat)))
       (string (get (twin-plan :cells) :flat)))
# Separated pits really are two basins.
(def separated @[50 50 50 50 50
                 50 10 50 10 50
                 50 50 50 50 50
                 50 50 50 50 50
                 50 50 50 50 50])
(check "separated pits are two independent basins"
       (= 2 (get ((hydro/analyze separated 5 5) :cells) :basin))
       (string (get ((hydro/analyze separated 5 5) :cells) :basin)))

#
# --- Plateaus terminate explicitly, and are not water -----------------
#
(print "\nplateaus:")

(def plateau (hydro/analyze (flat-grid 3 3 30) 3 3))
(check "a constant grid produces no basins"
       (zero? (get (plateau :cells) :basin)))
(check "a constant grid's interior is unrouted flat"
       (= :flat (hydro/outlet-kind-at plateau 1 1)))
(check "a constant grid still drains its edge cells outward"
       (= 8 (get (plateau :cells) :outflow)))
(check "a flat cell has no downstream index"
       (nil? (hydro/downstream-at plateau 1 1)))
(check "no cell on a plateau is a river"
       (do
         (var none true)
         (for z 0 3
           (for x 0 3
             (when (hydro/river? plateau x z) (set none false))))
         none))

# A plateau with one low outlet resolves downhill and is NOT flat.
(def ledge @[30 30 30
             30 30 30
             30 30 10])
(def ledge-plan (hydro/analyze ledge 3 3))
(check "a plateau with a low outlet resolves toward it"
       (= [2 2] (hydro/direction-to ledge-plan 1 1))
       (string (hydro/direction-to ledge-plan 1 1)))
(check "that ledge is not classified as a basin"
       (zero? (get (ledge-plan :cells) :basin)))

#
# --- Missing data is blocked, never guessed ---------------------------
#
(print "\nmissing data:")

(def holed (grid 3 3 (fn [x z] (if (and (= x 1) (= z 1)) nil 40))))
(def holed-plan (hydro/analyze holed 3 3))
(check "a cell with no height is :void"
       (= :void (hydro/outlet-kind-at holed-plan 1 1)))
(check "void cells are counted"
       (= 1 (get (holed-plan :cells) :void)))
(check "a void cell accumulates NOTHING — there is no column to carry water"
       (= 0 (hydro/accumulation-at holed-plan 1 1)))
(check "a void cell is never a river"
       (not (hydro/river? holed-plan 1 1)))
# A void neighbour must not read as height 0, which would make the hole look like
# an infinitely deep sink and capture the whole grid.
(check "a surrounding cell does not drain into the void"
       (not= [1 1] (hydro/direction-to holed-plan 0 0))
       (string (hydro/direction-to holed-plan 0 0)))

(def empty-plan (hydro/analyze (grid 2 2 (fn [x z] nil)) 2 2))
(check "an entirely empty grid is all void"
       (= 4 (get (empty-plan :cells) :void)))
(check "an entirely empty grid produces no rivers"
       (zero? (empty-plan :rivers)))

#
# --- Ownership: the plan is the caller's, with no shared state --------
#
(print "\nownership:")

(def first-plan (hydro/analyze (east-slope 4 4 40) 4 4))
(def second-plan (hydro/analyze (east-slope 4 4 40) 4 4))
# Mutating one plan must not reach another. A module that returned a shared or
# memoised table would pass every value check above and fail this one.
(put (first-plan :accumulation) 0 999)
(check "two plans do not share their arrays"
       (not= 999 (get (second-plan :accumulation) 0)))
(check "a fresh analysis is unaffected by mutating an older plan"
       (= 1 (get (get (hydro/analyze (east-slope 4 4 40) 4 4) :accumulation) 0))
       (string "expected 1, got "
               (get (get (hydro/analyze (east-slope 4 4 40) 4 4) :accumulation) 0)))
# And the returned table itself is owned, not a frozen global.
(check "the returned plan is a table the caller may hold"
       (table? first-plan))

# THE SCENARIO ABOVE IS MADE EXPLICIT RATHER THAN INCIDENTAL. It relied on
# `east-slope` happening to build an untouched grid each call, so its sensitivity
# to a real aliasing bug depended on how the fixture was written. Here the caller's
# grid is a NAMED binding that is deliberately mutated between the two analyses, so
# the check fails if a plan ever reads through to caller storage.
(def caller-grid (east-slope 3 3 40))
(def plan-on-intact-grid (hydro/analyze caller-grid 3 3))
(def intact-value (get (get plan-on-intact-grid :accumulation) 2))
(check "the fixture starts drained, so the value is meaningful"
       (= 3 intact-value)
       (string "accumulation at the row end was " intact-value))
# Damage the caller's grid, then analyse it again as a FRESH call.
(put caller-grid 2 999)
(def plan-on-damaged-grid (hydro/analyze caller-grid 3 3))
(check "a fresh plan reflects the caller's grid as it is now"
       (not= intact-value (get (get plan-on-damaged-grid :accumulation) 2))
       (string intact-value " -> "
               (get (get plan-on-damaged-grid :accumulation) 2)))
(check "the OLDER plan still reports the grid it was given"
       (= intact-value (get (get plan-on-intact-grid :accumulation) 2))
       (string "expected " intact-value ", got "
               (get (get plan-on-intact-grid :accumulation) 2)))

# THE INPUT IS SNAPSHOTTED, NOT ALIASED. A plan must be a function of the grid it
# was GIVEN, so editing the caller's array afterwards cannot retroactively change
# what that plan says -- and a second analysis of the same array is a second
# independent result, not a view onto shared storage.
(def shared-grid (east-slope 3 3 40))
(def plan-before (hydro/analyze shared-grid 3 3))
# The mutated cell must be one whose height DECIDES something. Index 0 of a 3x3
# east-slope is an outlet: its accumulation is 1 whether it reads 40 or 999, so
# mutating it would prove nothing. Index 2 is the row's downstream end, and raising
# it re-routes the row.
(def acc-before (get (get plan-before :accumulation) 2))
# Mutate the caller's grid AFTER the first analysis.
(put shared-grid 2 999)
(check "editing the input after analysis does not change that plan"
       (= acc-before (get (get plan-before :accumulation) 2))
       (string acc-before " vs " (get (get plan-before :accumulation) 2)))
# The second analysis sees the NEW grid -- it is a different grid now, and the
# module must not have cached the first reading.
(def plan-after (hydro/analyze shared-grid 3 3))
(check "a later analysis reads the array as it is now"
       (not= (get (get plan-before :accumulation) 2)
             (get (get plan-after :accumulation) 2))
       (string (get (get plan-before :accumulation) 2) " vs "
               (get (get plan-after :accumulation) 2)))
# The plan owns no reference to the caller's array: no output array is that object.
(check "no output array is the caller's input object"
       (and (not= (plan-before :downstream) shared-grid)
            (not= (plan-before :accumulation) shared-grid)
            (not= (plan-before :river-mask) shared-grid)))
# Two analyses produce DISTINCT array objects, so a mutation cannot travel.
(check "two plans never share an output array object"
       (let [a (hydro/analyze (east-slope 3 3 40) 3 3)
             b (hydro/analyze (east-slope 3 3 40) 3 3)]
         (and (not= (a :downstream) (b :downstream))
              (not= (a :accumulation) (b :accumulation))
              (not= (a :river-mask) (b :river-mask))
              (not= (a :outlet-kind) (b :outlet-kind)))))

#
# --- Determinism and ties ---------------------------------------------
#
(print "\ndeterminism:")

(check "a symmetric tie resolves the same way on repeat runs"
       (= (hydro/direction-to pit-plan 0 0) (hydro/direction-to pit-plan 0 0)))
# The tie is broken by the module's fixed direction order; the property callers
# depend on is that ONE direction is chosen, not which.
(check "a symmetric tie picks exactly one direction"
       (let [d (hydro/direction-to pit-plan 0 0)]
         (and (indexed? d) (= 2 (length d)))))
(check "two analyses of one grid agree cell by cell"
       (let [a (hydro/analyze (east-slope 5 5 40) 5 5)
             b (hydro/analyze (east-slope 5 5 40) 5 5)]
         (and (same-seq? (a :downstream) (b :downstream))
              (same-seq? (a :accumulation) (b :accumulation))
              (same-seq? (a :outlet-kind) (b :outlet-kind)))))
(check "the plan depends on contents, not on how the array was built"
       (same-seq? ((hydro/analyze (east-slope 4 4 40) 4 4) :downstream)
                  ((hydro/analyze (east-slope 4 4 40) 4 4) :downstream)))

#
# --- Origin is output mapping only ------------------------------------
#
(print "\norigin:")

# A grid may describe a map whose first column sits at a negative world
# coordinate. The origin shifts the REPORTED coordinates and must not touch the
# analysis -- otherwise the same terrain would drain differently by where it sits.
(def shifted (hydro/analyze (east-slope 4 4 40) 4 4 {:origin [-256 -128]}))
(check "the origin offsets reported coordinates"
       (= [-256 -128] (hydro/coords-at shifted 0 0)))
(check "the origin does not change drainage"
       (same-seq? (slope :downstream) (shifted :downstream)))
(check "the origin does not change accumulation"
       (same-seq? (slope :accumulation) (shifted :accumulation)))
(check "the origin does not change the sink classification"
       (same-seq? (slope :outlet-kind) (shifted :outlet-kind)))
(check "the plan records its origin"
       (= [-256 -128] (shifted :origin)))

#
# --- River threshold is a caller choice, bounded ----------------------
#
(print "\nriver threshold:")

(check "a high threshold marks nothing as a river"
       (zero? ((hydro/analyze (east-slope 8 2 40) 8 2
                              {:river-threshold 1000}) :rivers)))
# A threshold of one makes every cell that HAS a receiver a channel. The two
# eastern-edge cells are outlets -- they drain out of the area rather than to a
# cell -- so they are 16 - 2 = 14, not 16. Counting them would mean a river runs
# off the edge of the analysed grid and into nothing.
(check "a threshold of one marks every cell with a receiver as a river"
       (= 14 ((hydro/analyze (east-slope 2 8 40) 2 8 {:river-threshold 1}) :rivers)))
(check "no outlet cell is ever a river"
       (do
         (def p (hydro/analyze (east-slope 2 8 40) 2 8 {:river-threshold 1}))
         (and (nil? (hydro/downstream-at p 7 0))
              (not (hydro/river? p 7 0)))))
(check "the plan records the threshold it used"
       (= 1000 ((hydro/analyze (east-slope 4 2 40) 4 2
                               {:river-threshold 1000}) :river-threshold)))
# `:river-mask` is the unambiguous form. JANET TREATS 0 AS TRUTHY, so a caller
# given a count or a numeric flag would read "river here" out of a zero; the mask
# is 0/1 and the predicate returns a real boolean, and both are checked as such
# rather than by truthiness.
(def masked (hydro/analyze (east-slope 8 4 40) 8 4 {:river-threshold 3}))
(check "the plan exposes a 0/1 river mask"
       (let [m (masked :river-mask)]
         (and (= 32 (length m))
              (do
                (var ok true)
                (for i 0 (length m)
                  (def v (get m i))
                  (unless (or (= 0 v) (= 1 v)) (set ok false)))
                ok))))
(check "the mask marks exactly the cells the predicate calls rivers"
       (do
         (var ok true)
         (for z 0 4
           (for x 0 8
             (def in-mask (= 1 (get (masked :river-mask) (hydro/index-of 8 x z))))
             (unless (= in-mask (hydro/river? masked x z)) (set ok false))))
         ok))
(check "river? always returns a boolean, never a count"
       (every-true?
         (map (fn [i] (= :boolean (type (hydro/river? masked (mod i 8)
                                                  (math/floor (/ i 8))))))
              (range 32))))
# And the helper itself is checked, because a wrong all-predicate would make the
# assertion above vacuous.
(check "the all-predicate helper returns a boolean and rejects a false"
       (and (= :boolean (type (every-true? [true 1])))
            (every-true? [true 1])
            (not (every-true? [true false]))
            (every-true? [])))
# A flat cell accumulates only itself and is never a river, even at threshold 1.
# This is the trap stated as a test: a caller reading the COUNT would see a
# non-zero number and could conclude "river".
(check "a flat cell accumulates itself but is never a river"
       (let [p (hydro/analyze (flat-grid 3 3 30) 3 3 {:river-threshold 1})]
         (and (= 1 (hydro/accumulation-at p 1 1))
              (not (hydro/river? p 1 1))
              (= 0 (get (p :river-mask) (hydro/index-of 3 1 1)))
              # Nothing drains anywhere on a plateau, so no cell is a channel --
              # which is the whole point of keeping :flat out of the river set.
              (zero? (p :rivers)))))
# And the mask is the authority: where it says 0 the predicate says false.
(check "mask and predicate never disagree even at threshold 1"
       (let [p (hydro/analyze (flat-grid 3 3 30) 3 3 {:river-threshold 1})]
         (do
           (var ok true)
           (for z 0 3
             (for x 0 3
               (def m (= 1 (get (p :river-mask) (hydro/index-of 3 x z))))
               (unless (= m (hydro/river? p x z)) (set ok false))))
           ok)))

(check "the river count agrees with the per-cell predicate"
       (do
         (def p (hydro/analyze (east-slope 8 4 40) 8 4 {:river-threshold 3}))
         (var counted 0)
         (for z 0 4
           (for x 0 8
             (when (hydro/river? p x z) (++ counted))))
         (= counted (p :rivers))))

#
# --- Bounds and refusals ----------------------------------------------
#
(print "\nbounds:")

(check "a non-positive dimension is refused"
       (refuses? (fn [] (hydro/analyze @[] 0 4))))
(check "a fractional dimension is refused"
       (refuses? (fn [] (hydro/analyze @[] 2.5 4))))
(check "a height count that disagrees with the dimensions is refused"
       (refuses? (fn [] (hydro/analyze (flat-grid 3 3 40) 4 3))))
# Heights must be INTEGERS: rounding a fractional height would silently move the
# waterline, so it is refused rather than coerced.
(check "a fractional height is refused"
       (refuses? (fn [] (hydro/analyze @[10 1.5 10 10] 2 2))))
(check "a non-numeric height is refused"
       (refuses? (fn [] (hydro/analyze @[10 "x" 10 10] 2 2))))
(check "a non-positive river threshold is refused"
       (refuses? (fn [] (hydro/analyze (flat-grid 2 2 30) 2 2 {:river-threshold 0}))))
(check "a malformed origin is refused"
       (refuses? (fn [] (hydro/analyze (flat-grid 2 2 30) 2 2 {:origin [1]}))))
(check "a grid past the analysed cell cap is refused"
       (refuses? (fn [] (hydro/analyze (array/new-filled (* 513 513) 10) 513 513))))
(check "a grid at the cap is accepted"
       (let [side 512]
         (def p (hydro/analyze (array/new-filled (* side side) 10) side side))
         (= (* side side) (length (p :downstream)))))

#
# --- Result -------------------------------------------------------------
#
(print "")
(if (zero? failures)
  (print "ALL CHECKS PASSED  (0 failures)")
  (do (printf "FAILURES: %d" failures) (os/exit 1)))
