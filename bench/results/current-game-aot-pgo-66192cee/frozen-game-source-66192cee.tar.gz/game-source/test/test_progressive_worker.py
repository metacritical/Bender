"""Model-free tests for the persistent progressive worker.

No model, no GPU, no window, no child process. A fake sampler stands in for the
pipeline and records how many times it was loaded and queried, which is how the
"one load, reused" and "one query per patch" claims are checked rather than
asserted.
"""

import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "tools"))

import progressive_world as pw     # noqa: E402
import progressive_worker as pwd   # noqa: E402
import terrain_cache as tc         # noqa: E402


WITNESS_PX = 96


class FakeSampler:
    """Closed-form GLOBAL elevation field, addressed by world pixel.

    Deliberately a pure function of the global coordinate: that is exactly the
    property the witness comparison is meant to detect the absence of. A test
    that wants a context-dependent pipeline subclasses this.
    """

    def __init__(self, low=850.0, high=1600.0):
        self.low = low
        self.high = high
        self.calls = []
        self.closed = False

    def elevation(self, px, pz):
        span = float(self.low + self.high)
        return self.low + (self.high - self.low) * ((px * 31 + pz * 17) % 199) / 198.0

    def get(self, i1, j1, i2, j2, with_climate=False):
        self.calls.append((i1, j1, i2, j2))
        rows = [[self.elevation(j, i) for j in range(j1, j2)]
                for i in range(i1, i2)]
        return {"elev": rows, "climate": None}

    def close(self):
        self.closed = True


class WorkerCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="progressive-worker-")
        self.world = "a" * 64
        self.lines = []
        self.loads = 0

    def worker(self, **kwargs):
        def factory(identity, layout):
            self.loads += 1
            return FakeSampler()

        kwargs.setdefault("sampler_factory", factory)
        kwargs.setdefault("emit", self.lines.append)
        return pwd.ProgressiveWorker(self.tmp, world_identity=self.world, **kwargs)

    def request(self, cx=0, cz=0, token="t1", epoch=1, world=None):
        return pwd.parse_line(json.dumps({
            "v": 1, "kind": "request", "world": world or self.world,
            "epoch": epoch, "token": token, "patch": {"cx": cx, "cz": cz},
        }))

    def result(self, worker, **kwargs):
        line = worker.handle(self.request(**kwargs))
        return json.loads(line)


# ---------------------------------------------------------------------------
# Wire parsing: bounded and strict
# ---------------------------------------------------------------------------


class ParseTests(unittest.TestCase):
    def test_a_well_formed_request_parses(self):
        record = pwd.parse_line(
            '{"v":1,"kind":"request","world":"%s","epoch":3,"token":"tok",'
            '"patch":{"cx":-4,"cz":8}}' % ("b" * 64)
        )
        self.assertEqual(record["kind"], "request")
        self.assertEqual(record["cx"], -4)
        self.assertEqual(record["cz"], 8)
        self.assertEqual(record["epoch"], 3)

    def test_a_cancel_line_parses(self):
        record = pwd.parse_line('{"v":1,"kind":"cancel","token":"tok"}')
        self.assertEqual(record["kind"], "cancel")

    def test_an_oversized_line_is_refused_before_parsing(self):
        payload = '{"v":1,"kind":"cancel","token":"tok","pad":"%s"}' % ("x" * 600)
        with self.assertRaises(pwd.WorkerError) as caught:
            pwd.parse_line(payload)
        self.assertIn("exceeds", str(caught.exception))

    def test_a_wrong_wire_version_is_refused(self):
        with self.assertRaises(pwd.WorkerError):
            pwd.parse_line('{"v":2,"kind":"cancel","token":"tok"}')

    def test_an_unknown_kind_is_refused(self):
        with self.assertRaises(pwd.WorkerError):
            pwd.parse_line('{"v":1,"kind":"sample","token":"tok"}')

    def test_a_non_digest_world_is_refused(self):
        with self.assertRaises(pwd.WorkerError):
            pwd.parse_line('{"v":1,"kind":"request","world":"short","epoch":1,'
                           '"token":"t","patch":{"cx":0,"cz":0}}')

    def test_coordinates_must_be_signed_int32(self):
        for bad in (2 ** 31, -2 ** 31 - 1):
            with self.assertRaises(pwd.WorkerError):
                pwd.parse_line(json.dumps({
                    "v": 1, "kind": "request", "world": "c" * 64, "epoch": 1,
                    "token": "t", "patch": {"cx": bad, "cz": 0},
                }))

    def test_a_token_with_a_disallowed_character_is_refused(self):
        with self.assertRaises(pwd.WorkerError):
            pwd.parse_line('{"v":1,"kind":"cancel","token":"has space"}')

    def test_a_non_json_line_is_refused(self):
        with self.assertRaises(pwd.WorkerError):
            pwd.parse_line("not json at all")

    def test_results_carry_every_agreed_field(self):
        line = pwd.result_line(token="t", cx=0, cz=0, status="validated",
                               epoch=1, reason=None, artifact=None)
        record = json.loads(line)
        self.assertEqual(set(record),
                         {"v", "kind", "token", "patch", "status", "epoch",
                          "reason", "artifact"})
        self.assertEqual(record["patch"], {"cx": 0, "cz": 0})

    def test_an_unknown_result_status_is_refused(self):
        with self.assertRaises(pwd.WorkerError):
            pwd.result_line(token="t", cx=0, cz=0, status="queued", epoch=1)


# ---------------------------------------------------------------------------
# Geometry
# ---------------------------------------------------------------------------


class GeometryTests(unittest.TestCase):
    def test_witness_bounds_add_one_chunk_of_halo(self):
        self.assertEqual(pwd.witness_chunk_bounds(0, 0), (-1, -1, 4, 4))
        self.assertEqual(pwd.core_chunk_bounds(0, 0), (0, 0, 3, 3))

    def test_witness_tiles_and_core_tiles_match_the_agreed_counts(self):
        self.assertEqual(pwd.witness_tile_count(), 36)
        self.assertEqual(pwd.core_tile_count(), 16)

    def test_negative_anchors_stay_on_the_layout(self):
        self.assertEqual(pwd.patch_anchor(-1, -1), (-4, -4))
        self.assertEqual(pwd.patch_anchor(0, 0), (0, 0))
        self.assertNotEqual(pwd.patch_anchor(-1, 0), pwd.patch_anchor(0, 0))

    def test_neighbours_are_the_eight_grid_legal_anchors(self):
        neighbours = pwd.neighbour_anchors(0, 0)
        self.assertEqual(len(neighbours), 8)
        for ax, az in neighbours:
            self.assertEqual((ax % 4, az % 4), (0, 0))

    def test_a_neighbour_overlap_is_twelve_tiles(self):
        """One halo chunk x six rows, on each side: the agreed 12."""
        shared = pwd.overlapping_cores(0, 0)
        self.assertIn((4, 0), shared)
        self.assertEqual(len(shared[(4, 0)]), 12)
        self.assertIn((3, 0), shared[(4, 0)])
        self.assertIn((-1, 3), shared[(-4, 0)])

    def test_the_witness_window_is_one_query_of_96(self):
        worker = pwd.ProgressiveWorker(
            tempfile.mkdtemp(prefix="progressive-geom-"),
            world_identity="d" * 64,
            sampler_factory=lambda i, l: FakeSampler(),
        )
        self.assertEqual(worker.witness_pixels(0, 0), (0 - 16, 0 - 16, 80, 80))
        self.assertEqual(worker.query["witness_window_pixels"], WITNESS_PX)


# ---------------------------------------------------------------------------
# Publication
# ---------------------------------------------------------------------------


class PublicationTests(WorkerCase):
    def test_one_request_publishes_a_sealed_patch(self):
        worker = self.worker()
        result = self.result(worker)
        self.assertEqual(result["status"], "published")
        directory = os.path.join(self.tmp, "patches", "0_0")
        self.assertEqual(result["artifact"], directory)
        self.assertTrue(os.path.isfile(os.path.join(directory, pwd.READY_NAME)))
        self.assertEqual(len(os.listdir(os.path.join(directory, pwd.TILES_DIR))),
                         16)
        self.assertEqual(len(os.listdir(os.path.join(directory, pwd.WITNESS_DIR))),
                         36)

    def test_the_manifest_has_exactly_the_fourteen_agreed_keys(self):
        worker = self.worker()
        self.result(worker)
        with open(os.path.join(self.tmp, "patches", "0_0", pwd.MANIFEST_NAME)) as h:
            text = h.read()
        self.assertTrue(text.startswith("{"))
        for key in pwd.MANIFEST_KEYS:
            self.assertIn(":%s " % key, text)
        self.assertIn(':magic "TDS4"', text)
        self.assertIn(":sealed true", text)
        self.assertIn(":halo-chunks 1", text)
        self.assertIn(":witness-tiles 36", text)

    def test_ready_is_written_inside_the_staging_directory_before_the_rename(self):
        worker = self.worker()
        self.result(worker)
        # No staging directory may survive a successful publish.
        leftovers = [n for n in os.listdir(os.path.join(self.tmp, "patches"))
                     if ".staging-" in n]
        self.assertEqual(leftovers, [])

    def test_core_tiles_use_the_existing_tds3_encoder(self):
        import scenic_terrain as st

        worker = self.worker()
        self.result(worker)
        path = os.path.join(self.tmp, "patches", "0_0", pwd.TILES_DIR, "0_0.tdh")
        with open(path, "rb") as handle:
            data = handle.read()
        st.decode_scenic_tile(data, 0, 0, height_min=4, height_max=60)

    def test_a_second_request_reuses_the_single_pipeline_load(self):
        worker = self.worker()
        first = self.result(worker, cx=0, cz=0, token="a")
        second = self.result(worker, cx=4, cz=0, token="b")
        self.assertEqual(first["status"], "published")
        self.assertEqual(second["status"], "published")
        self.assertEqual(worker.load_count, 1)
        self.assertEqual(self.loads, 1)

    def test_an_existing_patch_is_never_overwritten(self):
        worker = self.worker()
        self.result(worker)
        again = self.result(worker, token="t2")
        self.assertEqual(again["status"], "error")
        self.assertIn("already sealed", again["reason"])


# ---------------------------------------------------------------------------
# The overlap gate
# ---------------------------------------------------------------------------


class OverlapGateTests(WorkerCase):
    def test_two_adjacent_patches_agree_and_publish(self):
        worker = self.worker()
        first = self.result(worker, cx=0, cz=0, token="a")
        second = self.result(worker, cx=4, cz=0, token="b")
        self.assertEqual(first["status"], "published")
        self.assertEqual(second["status"], "published")
        with open(os.path.join(self.tmp, "patches", "4_0", pwd.READY_NAME)) as h:
            ready = json.load(h)
        # 12 shared witness tiles were actually compared, not zero.
        self.assertEqual(ready["compared-witness-tiles"], 12)

    def test_the_first_patch_compares_nothing_and_says_so(self):
        worker = self.worker()
        self.result(worker)
        with open(os.path.join(self.tmp, "patches", "0_0", pwd.READY_NAME)) as h:
            ready = json.load(h)
        self.assertEqual(ready["compared-witness-tiles"], 0)

    def test_a_context_dependent_pipeline_is_refused_before_publication(self):
        """The real gate: a neighbour whose halo disagrees must not publish."""

        class Drifting(FakeSampler):
            def __init__(self):
                super().__init__()
                self.offset = 0.0

            def get(self, i1, j1, i2, j2, with_climate=False):
                rows = super().get(i1, j1, i2, j2, with_climate)["elev"]
                return {"elev": [[value + self.offset for value in row]
                                 for row in rows], "climate": None}

        drifting = Drifting()

        def factory(identity, layout):
            self.loads += 1
            return drifting

        worker = pwd.ProgressiveWorker(self.tmp, world_identity=self.world,
                                       sampler_factory=factory)
        self.assertEqual(self.result(worker, cx=0, cz=0, token="a")["status"],
                         "published")
        drifting.offset = 40.0        # the pipeline is no longer context-free
        second = self.result(worker, cx=4, cz=0, token="b")
        self.assertEqual(second["status"], "error")
        self.assertIn("witness mismatch", second["reason"])
        # Nothing was published and no staging directory survived the refusal.
        self.assertFalse(os.path.exists(
            os.path.join(self.tmp, "patches", "4_0")))
        leftovers = [n for n in os.listdir(os.path.join(self.tmp, "patches"))
                     if ".staging-" in n]
        self.assertEqual(leftovers, [])

    def test_an_all_clipped_core_is_refused_not_flattened(self):
        def factory(identity, layout):
            self.loads += 1
            return FakeSampler(low=-2400.0, high=-1900.0)

        worker = pwd.ProgressiveWorker(self.tmp, world_identity=self.world,
                                       sampler_factory=factory)
        result = self.result(worker)
        self.assertEqual(result["status"], "error")
        self.assertIn("all_clipped", result["reason"])
        self.assertFalse(os.path.exists(
            os.path.join(self.tmp, "patches", "0_0")))


# ---------------------------------------------------------------------------
# Cancellation and epochs
# ---------------------------------------------------------------------------


class CancellationTests(WorkerCase):
    def test_a_cancel_line_only_takes_effect_between_requests(self):
        worker = self.worker()
        self.assertIsNone(worker.handle(pwd.parse_line(
            '{"v":1,"kind":"cancel","token":"t1"}')))
        result = self.result(worker, token="t1")
        self.assertEqual(result["status"], "error")
        self.assertIn("cancelled", result["reason"])

    def test_a_cancel_does_not_publish_anything(self):
        worker = self.worker()
        worker.handle(pwd.parse_line('{"v":1,"kind":"cancel","token":"t1"}'))
        self.result(worker, token="t1")
        self.assertFalse(os.path.exists(os.path.join(self.tmp, "patches", "0_0")))

    def test_the_worker_does_not_claim_to_interrupt_inference(self):
        """There is no interrupt API: cancellation is the parent's TERM/reap."""
        self.assertFalse(hasattr(pwd.ProgressiveWorker, "interrupt"))
        self.assertFalse(hasattr(pwd.ProgressiveWorker, "kill"))


# ---------------------------------------------------------------------------
# Climate policy
# ---------------------------------------------------------------------------


class ClimatePolicyTests(WorkerCase):
    def test_no_policy_is_accepted_and_exports_elevation_only(self):
        worker = self.worker()
        result = self.result(worker)
        self.assertEqual(result["status"], "published")
        with open(os.path.join(self.tmp, "patches", "0_0", pwd.MANIFEST_NAME)) as h:
            self.assertNotIn("climate", h.read())

    def test_a_policy_version_is_refused_until_the_container_is_supported(self):
        with self.assertRaises(pwd.WorkerError) as caught:
            pwd.ProgressiveWorker(
                tempfile.mkdtemp(prefix="progressive-climate-"),
                world_identity="e" * 64,
                climate=pw.climate_record(policy_version=1, container_version=1),
                sampler_factory=lambda i, l: FakeSampler(),
            )
        self.assertIn("not supported", str(caught.exception))


class ImportDisciplineTests(unittest.TestCase):
    def test_no_model_dependency_is_imported(self):
        import subprocess

        code = (
            "import sys; sys.path.insert(0, 'tools'); "
            "import progressive_worker; "
            "print('torch' in sys.modules or 'numpy' in sys.modules)"
        )
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        out = subprocess.run(["python3", "-c", code], cwd=root,
                             capture_output=True, text=True)
        self.assertEqual(out.returncode, 0, out.stderr)
        self.assertEqual(out.stdout.strip(), "False")


if __name__ == "__main__":
    unittest.main()
