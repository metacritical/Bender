"""Unit tests for the pure parts of the stage-capture oracle.

Standard library only. Nothing here imports torch or numpy, loads a model, or
captures a forward: the naming helper and the output guards are pure functions,
and the fake models below are distinct objects standing in for the pipeline's
submodels.

The bug these pin: the old hook used ONE global counter and assumed calls arrive
coarse, base, decoder in that order (`order[idx]`). The coarse stage alone runs 20
forwards, so the real sequence was labelled

    call 0 "coarse" (luck), call 1 "base", call 2 "decoder", call 3+ "extra3"...

-- every capture after the first attributed to the wrong stage, and the genuine
base and decoder forwards never captured. Stage identity must come from the model
object, not the call order or the tensor shape.
"""

import hashlib
import json
import os
import shutil
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "tools"))

import terrain_stage_capture as cap  # noqa: E402


class _Model:
    """A stand-in submodel. Identity is the only thing that matters here."""

    def __init__(self, name):
        self.name = name


class StageCallNameTests(unittest.TestCase):
    def setUp(self):
        self.coarse = _Model("coarse")
        self.base = _Model("base")
        self.decoder = _Model("decoder")
        self.models = {
            "coarse": self.coarse,
            "base": self.base,
            "decoder": self.decoder,
        }

    def name(self, model, counters):
        return cap.stage_call_name(model, self.models, counters)

    def test_first_call_per_stage_uses_the_bare_canonical_label(self):
        counters = {}
        for stage in cap.STAGE_ORDER:
            record = self.name(self.models[stage], counters)
            self.assertEqual(record["label"], stage)
            self.assertEqual(record["stage"], stage)
            self.assertEqual(record["stage_index"], 0)

    def test_subsequent_calls_are_suffixed_per_stage(self):
        counters = {}
        labels = [self.name(self.coarse, counters)["label"] for _ in range(4)]
        self.assertEqual(labels, [
            "coarse", "coarse-step-0001", "coarse-step-0002", "coarse-step-0003",
        ])

    def test_twenty_coarse_calls_then_base_and_decoder(self):
        """The real shape of the bug: 20 coarse forwards before anything else."""
        counters = {}
        labels = [self.name(self.coarse, counters)["label"] for _ in range(20)]
        self.assertEqual(labels[0], "coarse")
        self.assertEqual(labels[1], "coarse-step-0001")
        self.assertEqual(labels[19], "coarse-step-0019")
        # Under the old scheme these were labelled base, decoder, extra3, extra4,
        # ... -- every one of them attributed to the wrong stage.
        self.assertEqual(self.name(self.base, counters)["label"], "base")
        self.assertEqual(self.name(self.base, counters)["label"], "base-step-0001")
        self.assertEqual(self.name(self.decoder, counters)["label"], "decoder")

    def test_no_label_is_ever_an_extra_or_duplicated(self):
        counters = {}
        seen = []
        for _ in range(20):
            seen.append(self.name(self.coarse, counters)["label"])
        for _ in range(2):
            seen.append(self.name(self.base, counters)["label"])
        seen.append(self.name(self.decoder, counters)["label"])
        self.assertFalse([s for s in seen if s.startswith("extra")])
        self.assertEqual(len(seen), len(set(seen)), "labels must be unique")

    def test_per_stage_and_global_indices_are_reported(self):
        counters = {}
        first = self.name(self.coarse, counters)
        second = self.name(self.coarse, counters)
        third = self.name(self.base, counters)
        self.assertEqual((first["stage_index"], first["global_index"]), (0, 0))
        self.assertEqual((second["stage_index"], second["global_index"]), (1, 1))
        # base is its stage's first call but globally the third.
        self.assertEqual((third["stage_index"], third["global_index"]), (0, 2))

    def test_stage_is_chosen_by_identity_not_by_equality(self):
        """Two structurally equal models must not be confused."""
        twin = _Model("coarse")          # same shape of object, different instance
        counters = {}
        with self.assertRaises(cap.StageCaptureError):
            self.name(twin, counters)

    def test_unknown_model_raises_before_anything_is_written(self):
        counters = {}
        stranger = _Model("unknown")
        with self.assertRaises(cap.StageCaptureError) as caught:
            self.name(stranger, counters)
        self.assertIn("refusing to guess", str(caught.exception))
        # The counter must not have advanced: nothing was attributed.
        self.assertEqual(counters, {})

    def test_counters_is_the_only_state(self):
        counters = {}
        self.name(self.coarse, counters)
        self.name(self.base, counters)
        self.assertEqual(counters, {"coarse": 1, "base": 1})

    def test_missing_submodel_in_the_map_is_not_silently_ignored(self):
        partial = {"coarse": self.coarse}
        with self.assertRaises(cap.StageCaptureError):
            cap.stage_call_name(self.decoder, partial, {})


class EntryTagTests(unittest.TestCase):
    """Each captured entry must name its stage and its place in the sequence."""

    def setUp(self):
        self.coarse, self.base, self.decoder = _Model("c"), _Model("b"), _Model("d")
        self.models = {"coarse": self.coarse, "base": self.base,
                       "decoder": self.decoder}

    def test_record_carries_stage_and_call_index(self):
        counters = {}
        first = cap.stage_call_name(self.coarse, self.models, counters)
        second = cap.stage_call_name(self.coarse, self.models, counters)
        self.assertEqual((first["stage"], first["global_index"]), ("coarse", 0))
        self.assertEqual((second["stage"], second["global_index"]), ("coarse", 1))

    def test_call_index_is_global_and_stage_index_is_per_stage(self):
        counters = {}
        cap.stage_call_name(self.coarse, self.models, counters)
        cap.stage_call_name(self.coarse, self.models, counters)
        third = cap.stage_call_name(self.base, self.models, counters)
        self.assertEqual(third["stage_index"], 0, "base's first call")
        self.assertEqual(third["global_index"], 2, "third call overall")

    def test_identity_not_equality_is_used(self):
        """A model defining __eq__ must not be matched by value."""
        class Sneaky:
            def __eq__(self, other):
                return True          # pretends to equal everything
            __hash__ = None          # and is unhashable

        counters = {}
        with self.assertRaises(cap.StageCaptureError):
            cap.stage_call_name(Sneaky(), self.models, counters)
        self.assertEqual(counters, {}, "a refusal must not advance counters")

    def test_unhashable_known_models_are_fine(self):
        """torch modules may be unhashable; identity comparison must still work."""
        class Unhashable(_Model):
            __hash__ = None

        coarse = Unhashable("coarse")
        models = {"coarse": coarse, "base": _Model("b"), "decoder": _Model("d")}
        counters = {}
        record = cap.stage_call_name(coarse, models, counters)
        self.assertEqual(record["label"], "coarse")


class OutputDirTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="cap-test-")
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def test_creates_a_fresh_directory(self):
        target = os.path.join(self.tmp, "out")
        self.assertEqual(cap.prepare_output_dir(target), target)
        self.assertTrue(os.path.isdir(target))

    def test_existing_empty_directory_is_REFUSED(self):
        """Ownership cannot be proven after the fact, so a NEW dir is required.

        `os.mkdir` also makes the claim atomic, so two captures cannot both
        believe they own the same directory.
        """
        target = os.path.join(self.tmp, "empty")
        os.makedirs(target)
        with self.assertRaises(cap.StageCaptureError) as caught:
            cap.prepare_output_dir(target)
        self.assertIn("already exists", str(caught.exception))
        self.assertEqual(os.listdir(target), [], "a refusal must not write")

    def test_two_claims_on_one_path_admit_exactly_one(self):
        """The race the old non-empty check could not close."""
        target = os.path.join(self.tmp, "claimed")
        cap.prepare_output_dir(target)
        with self.assertRaises(cap.StageCaptureError):
            cap.prepare_output_dir(target)

    def test_non_empty_directory_is_refused(self):
        """Stale .f32 files must never be mixed with a new capture."""
        target = os.path.join(self.tmp, "used")
        os.makedirs(target)
        with open(os.path.join(target, "coarse_x.f32"), "wb") as handle:
            handle.write(b"stale")
        with self.assertRaises(cap.StageCaptureError) as caught:
            cap.prepare_output_dir(target)
        self.assertIn("already exists", str(caught.exception))
        # The stale file must be untouched by the refusal.
        self.assertTrue(os.path.exists(os.path.join(target, "coarse_x.f32")))

    def test_a_file_where_a_directory_belongs_is_refused(self):
        target = os.path.join(self.tmp, "file")
        with open(target, "w") as handle:
            handle.write("x")
        with self.assertRaises(cap.StageCaptureError):
            cap.prepare_output_dir(target)

    def test_meta_is_written_atomically_and_leaves_no_temp(self):
        target = os.path.join(self.tmp, "meta")
        os.makedirs(target)
        path = os.path.join(target, "stage-meta.json")
        cap.write_meta_atomic(path, {"stages": {}})
        self.assertTrue(os.path.exists(path))
        self.assertEqual([n for n in os.listdir(target) if n.startswith("stage-meta.json.tmp")], [])
        with open(path) as handle:
            self.assertEqual(json.load(handle), {"stages": {}})

    def test_meta_rewrite_replaces_in_place(self):
        target = os.path.join(self.tmp, "meta2")
        os.makedirs(target)
        path = os.path.join(target, "stage-meta.json")
        cap.write_meta_atomic(path, {"n": 1})
        cap.write_meta_atomic(path, {"n": 2})
        with open(path) as handle:
            self.assertEqual(json.load(handle), {"n": 2})
        self.assertEqual(len(os.listdir(target)), 1)


class LittleEndianWriterTests(unittest.TestCase):
    """The recorded digest must describe the bytes actually on disk."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="cap-le-")
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def test_digest_matches_the_file_contents(self):
        np = pytest_importorskip_numpy(self)
        path = os.path.join(self.tmp, "x.f32")
        values = np.array([1.0, -2.5, 3.25], dtype=np.float64)
        digest = cap.write_f32(path, values)
        with open(path, "rb") as handle:
            ondisk = handle.read()
        self.assertEqual(digest, hashlib.sha256(ondisk).hexdigest())
        self.assertEqual(len(ondisk), 12)

    def test_file_is_little_endian_regardless_of_input_dtype(self):
        np = pytest_importorskip_numpy(self)
        path = os.path.join(self.tmp, "le.f32")
        cap.write_f32(path, np.array([1.0], dtype=np.float64))
        with open(path, "rb") as handle:
            raw = handle.read()
        # 1.0f little-endian is 00 00 80 3f
        self.assertEqual(raw, b"\x00\x00\x80\x3f")

    def test_digest_is_stable_across_input_dtypes(self):
        np = pytest_importorskip_numpy(self)
        a = cap.write_f32(os.path.join(self.tmp, "a.f32"),
                          np.array([0.5], dtype=np.float32))
        b = cap.write_f32(os.path.join(self.tmp, "b.f32"),
                          np.array([0.5], dtype=np.float64))
        self.assertEqual(a, b, "the same value must hash the same either way")

    def test_2d_arrays_are_written_row_major(self):
        np = pytest_importorskip_numpy(self)
        path = os.path.join(self.tmp, "m.f32")
        arr = np.array([[1.0, 2.0], [3.0, 4.0]], dtype=np.float32)
        cap.write_f32(path, arr)
        with open(path, "rb") as handle:
            raw = handle.read()
        self.assertEqual(len(raw), 16)
        # Row-major C order: 1,2 then 3,4.
        self.assertEqual(raw[0:4], b"\x00\x00\x80\x3f")
        self.assertEqual(raw[8:12], b"\x00\x00\x40\x40")


def pytest_importorskip_numpy(case):
    """numpy is the module's own runtime dependency, not a test requirement."""
    try:
        import numpy
    except ImportError:  # pragma: no cover - only where numpy is absent
        case.skipTest("numpy is not installed on this interpreter")
    return numpy


class ImportDisciplineTests(unittest.TestCase):
    def test_module_imports_without_torch_or_numpy(self):
        """The helper must be importable where the model stack is absent."""
        import ast

        with open(cap.__file__) as handle:
            tree = ast.parse(handle.read())
        # Only module-level imports count: heavy ones belong inside main().
        top_level = set()
        for node in tree.body:
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top_level.add(alias.name.split(".")[0])
            elif isinstance(node, ast.ImportFrom) and node.module:
                top_level.add(node.module.split(".")[0])
        for heavy in ("torch", "numpy"):
            self.assertNotIn(heavy, top_level,
                             "%s must be imported inside main(), not at module "
                             "scope" % heavy)
        # And importing this module must not have pulled them in.
        self.assertNotIn("torch", sys.modules)
        self.assertNotIn("numpy", sys.modules)

    def test_stage_order_is_the_three_submodels(self):
        self.assertEqual(cap.STAGE_ORDER, ("coarse", "base", "decoder"))


if __name__ == "__main__":
    unittest.main()
