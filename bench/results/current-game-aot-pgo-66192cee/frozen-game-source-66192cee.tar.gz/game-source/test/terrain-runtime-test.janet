# Hermetic, no GPU/Python/network native-package discovery tests.
(import ../src/terrain-runtime :as runtime)

(def root "/tmp/trinecraft-terrain-runtime-test")
(def env-root (string root "/env"))
(def explicit-root (string root "/explicit"))
(def exec-root (string root "/bin/assets/terrain"))
(defn status [opts] (runtime/discover opts))
(defn- write-bytes [path bytes]
  (def f (file/open path :wb))
  (assert f)
  (file/write f bytes)
  (file/close f))
(defn- remove-tree [path]
  (when (= :directory (os/lstat path :mode))
    (each name (os/dir path) (remove-tree (string path "/" name))))
  (os/rm path))
(when (os/lstat root) (remove-tree root))
(os/mkdir root)
(os/mkdir env-root)
(os/mkdir explicit-root)
(os/mkdir (string root "/bin"))
(os/mkdir (string root "/bin/assets"))
(os/mkdir exec-root)
(defn- expect [code opts]
  (def found (status opts))
  (assert (= false (get found :available)))
  (assert (= code (get found :status)) (string found))
  found)
(defn- reject [f reason]
  (def text (try (do (f) nil) ([err] (string err))))
  (assert (and text (string/find reason text)) (string "expected " reason ": " text)))
(defn- fixture-manifest []
  (string "{:version 1 :revision \"" runtime/revision "\""
          " :platform :macos :arch :aarch64"
          " :provider :terrain-diffusion-native"
          " :runtime-version \"" runtime/runtime-version "\" :assets {"
          (string/join
            (map (fn [asset]
                   (def name (get asset :name))
                   (def bytes (or (get asset :bytes) 8))
                   (def sha (or (get runtime/known-sha256 name)
                                (string/repeat "a" 64)))
                   (string ":" name " {:bytes " bytes " :sha256 \"" sha "\"}"))
                 runtime/assets) " ") "}}"))
(defn- manifest [where text]
  (write-bytes (string where "/" runtime/manifest-name) text))
(defn- tiny-asset [where name bytes]
  # Large pinned graph sizes cannot be synthesized in a hermetic unit test;
  # stop at the first missing or wrong-sized asset before touching other files.
  (write-bytes (string where "/" name) bytes))

(assert (= :missing-root (get (expect :missing-root {:env-model-dir nil}) :status)))
(assert (= :invalid-root (get (expect :invalid-root
                                 {:model-dir "" :env-model-dir env-root}) :status)))
(assert (= :explicit (get (expect :missing-root
                           {:model-dir "/tmp/terrain-no-such-package-12345"
                            :env-model-dir env-root}) :source)))
(assert (= env-root (get (expect :invalid-manifest
                           {:env-model-dir env-root
                            :executable (string root "/bin/game")}) :root)))
(assert (= exec-root (get (expect :invalid-manifest
                            {:env-model-dir nil
                             :executable (string root "/bin/game")}) :root)))
(expect :missing-root {:env-model-dir nil :executable "relative/game"})
(reject (fn [] (status {:env-model-dir nil :oops true})) "unknown discovery option")
(print "explicit, environment and executable-relative precedence: passed")

(def good (fixture-manifest))
(manifest explicit-root "{}")
(expect :invalid-manifest {:model-dir explicit-root :env-model-dir nil})
(manifest explicit-root "(os/rm \"/tmp/never-executed\")")
(expect :invalid-manifest {:model-dir explicit-root :env-model-dir nil})
(manifest explicit-root "{} {}")
(expect :invalid-manifest {:model-dir explicit-root :env-model-dir nil})
(manifest explicit-root (string (buffer/new-filled 16385 65)))
(expect :invalid-manifest {:model-dir explicit-root :env-model-dir nil})
(manifest explicit-root (string/replace ":version 1" ":version 99" good))
(expect :invalid-manifest {:model-dir explicit-root :env-model-dir nil})
(manifest explicit-root (string/replace ":provider :terrain-diffusion-native"
                                        ":provider :some-future-model" good))
(expect :invalid-manifest {:model-dir explicit-root :env-model-dir nil})
(manifest explicit-root (string/replace ":assets {" ":root \"../../etc\" :assets {" good))
(expect :invalid-manifest {:model-dir explicit-root :env-model-dir nil})
(manifest explicit-root (string/replace ":arch :aarch64" ":arch :x64" good))
(expect :invalid-manifest {:model-dir explicit-root :env-model-dir nil})
(manifest explicit-root (string/replace runtime/revision "0000000000000000000000000000000000000000" good))
(expect :invalid-manifest {:model-dir explicit-root :env-model-dir nil})
(manifest explicit-root (string/replace (get runtime/known-sha256 "base_model.onnx")
                                        (string/repeat "0" 64) good))
(expect :invalid-manifest {:model-dir explicit-root :env-model-dir nil})
(manifest explicit-root good)
(print "inert bounded manifest, exact revision/keys/platform and known digests: passed")

(assert (= :missing-asset (get (expect :missing-asset
                               {:model-dir explicit-root :env-model-dir nil}) :status)))
(tiny-asset explicit-root "coarse_model.onnx" "bad")
(expect :size-mismatch {:model-dir explicit-root :env-model-dir nil})
(os/rm (string explicit-root "/coarse_model.onnx"))
(os/symlink "/tmp/no-model" (string explicit-root "/coarse_model.onnx"))
(expect :missing-asset {:model-dir explicit-root :env-model-dir nil})
(os/rm (string explicit-root "/coarse_model.onnx"))
(os/rm (string explicit-root "/" runtime/manifest-name))
(os/symlink "/tmp/no-manifest" (string explicit-root "/" runtime/manifest-name))
(expect :invalid-manifest {:model-dir explicit-root :env-model-dir nil})
(os/rm (string explicit-root "/" runtime/manifest-name))
(manifest explicit-root good)
(os/symlink explicit-root (string root "/linked"))
(expect :missing-root {:model-dir (string root "/linked") :env-model-dir nil})
(expect :unsupported-platform {:model-dir explicit-root :env-model-dir nil :platform :linux})
(print "missing, corrupt-size, linked and unsupported host package: passed")

# CommonCrypto is a macOS shipping API, not a runtime subprocess or a Python
# dependency. Verify NIST empty/abc and a multi-block vector with fixed reads.
(def hash-path (string root "/hash-input"))
(write-bytes hash-path "")
(assert (= "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
           (runtime/sha256-file hash-path)))
(write-bytes hash-path "abc")
(assert (= "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
           (runtime/sha256-file hash-path)))
(write-bytes hash-path (string/repeat "a" 1000000))
(assert (= "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0"
           (runtime/sha256-file hash-path)))
(os/rm hash-path)
(os/symlink "/tmp/nonexistent-hash-target" hash-path)
(reject (fn [] (runtime/sha256-file hash-path)) "linked")
(os/rm hash-path)
(print "streaming native SHA-256 NIST vectors and symlink rejection: passed")
# Complete SMALL fixture: its manifest uses the fixed filenames, exact schema,
# and actual SHA-256 digests, with a fully pinned test-only size/digest map.
# Production discover never receives these fixture pins and still insists on
# the 2GB/225MB graph sizes and published graph digests.
(def tiny-root (string root "/complete"))
(os/mkdir tiny-root)
(def tiny-pins @{})
(each [index asset] (pairs runtime/assets)
  (def name (get asset :name))
  (def body (string "asset:" index ":" name ":content"))
  (write-bytes (string tiny-root "/" name) body)
  (put tiny-pins (keyword name)
       {:bytes (length body)
        :sha256 (runtime/sha256-file (string tiny-root "/" name))}))
(defn- tiny-manifest [pin-map]
  (string "{:version 1 :revision \"" runtime/revision "\""
          " :platform :macos :arch :aarch64"
          " :provider :terrain-diffusion-native"
          " :runtime-version \"" runtime/runtime-version "\" :assets {"
          (string/join (map (fn [asset]
                              (def name (get asset :name))
                              (def pin (get pin-map (keyword name)))
                              (string ":" name " {:bytes " (get pin :bytes)
                                      " :sha256 \"" (get pin :sha256) "\"}"))
                            runtime/assets) " ") "}}"))
(manifest tiny-root (tiny-manifest tiny-pins))
(def fixture-options {:model-dir tiny-root :env-model-dir nil})
(def fixture (runtime/fixture-discover fixture-options tiny-pins))
(assert (= :unverified (get fixture :status)))
(assert (= false (get fixture :available)))
(assert (string/find "pipeline proof unavailable" (get fixture :reason)))
(expect :invalid-manifest fixture-options) # Production pins cannot be overridden.
(print "all real fixture hashes pass, but pipeline remains unavailable: passed")
# Changing one byte without changing asset length must detect a digest mismatch.
(def tampered-name "coarse_model.onnx")
(def tampered-path (string tiny-root "/" tampered-name))
(def original-body (string "asset:0:" tampered-name ":content"))
(write-bytes tampered-path (string "X" (string/slice original-body 1)))
(def tampered (runtime/fixture-discover fixture-options tiny-pins))
(assert (= :hash-mismatch (get tampered :status)))
(assert (= false (get tampered :available)))
(assert (string/find tampered-name (get tampered :reason)))
(write-bytes tampered-path original-body)
# Corrupting a pin, a fixed asset name, and the manifest path each fails closed.
(def manifest-text (tiny-manifest tiny-pins))
(manifest tiny-root (string/replace (get (get tiny-pins :coarse_model.onnx) :sha256)
                                    (string/repeat "0" 64) manifest-text))
(assert (= :invalid-manifest
           (get (runtime/fixture-discover fixture-options tiny-pins) :status)))
(manifest tiny-root (string/replace ":coarse_model.onnx" ":../../coarse_model.onnx"
                                    manifest-text))
(assert (= :invalid-manifest
           (get (runtime/fixture-discover fixture-options tiny-pins) :status)))
(manifest tiny-root manifest-text)
(reject (fn [] (runtime/fixture-discover fixture-options {})) "cover every")
(assert (= :invalid-root (get (runtime/fixture-discover
                     {:model-dir (string/repeat "x" 4097) :env-model-dir nil}
                     tiny-pins) :status)))
(print "same-size tamper, pinned digest and path bounds: passed")
(print "runtime remains unavailable pending native pipeline proof")
(print "terrain runtime discovery: ALL CHECKS PASSED")
