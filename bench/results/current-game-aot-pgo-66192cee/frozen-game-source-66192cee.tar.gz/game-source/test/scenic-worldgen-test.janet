# Headless contract tests for the scenic map decoration layer.
#
# The property that matters most is ORDER INDEPENDENCE: a conifer's canopy
# crosses chunk borders, so chunk A and chunk B both contribute to the same
# tree. If either depends on the other having been generated first, the border
# changes shape depending on what the streamer happened to load. These tests
# generate the same chunks in both orders and against a single wide reference,
# and require all three to agree block for block.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/scenic-worldgen-test.janet

(import ../src/scenic-worldgen :as scenic)
(import ../src/world :as world)
(import ../src/terrain-integrity :as crc)
(import ../src/worldgen :as worldgen)
(import ../src/climate-tile :as ct)
(import ../src/climate-biome :as bio)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

#
# --- Fixtures -----------------------------------------------------------
#

(def extent 48)

(defn bounded
  "Heights inside a finite map, nil outside -- the map-edge contract."
  [x z]
  (if (and (>= x (- extent)) (<= x extent) (>= z (- extent)) (<= z extent))
    (+ 30 (mod (+ (* x 3) (* z 5)) 26))     # 30..55: grass, snow and rock bands
    nil))

(defn flat
  "One flat height everywhere, so tree logic is isolated from slope rejection."
  [x z]
  34)

(defn ridge
  "A slope steep enough at the seam to force rock."
  [x z]
  (if (odd? (+ x z)) 50 34))

(defn run-chunk [h cx cz opts]
  (def blocks (buffer/new-filled world/chunk-volume 0))
  (scenic/generate-into blocks cx cz h opts)
  blocks)

(defn block-at [blocks lx y lz]
  (get blocks (world/block-index lx y lz)))

(defn count-of [blocks id]
  (length (filter |(= id $) blocks)))

(defn same-blocks? [a b]
  (and (= (length a) (length b))
       (every? (map = a b))))

#
# --- Surface and map edges ----------------------------------------------
#
(print "surface:")

(def surfaced (run-chunk bounded 0 0 {:seed 1}))

(check "a mapped chunk produces terrain"
       (pos? (count-of surfaced world/block-stone)))
# Every block id must be one the world defines; an out-of-range id would be an
# unmapped texture and an invisible surface.
(check "every block in the chunk is a known id"
       (empty? (filter |(or (> $ 8) (< $ 0)) surfaced))
       (string/format "%j" (distinct (filter |(or (> $ 8) (< $ 0)) surfaced))))

# Column rule: solid below the height, surface at it, air above.
(defn column-ok? [blocks lx lz h]
  (def top (min h (dec world/chunk-y)))
  (and (= world/block-air (block-at blocks lx (+ top 1) lz))
       (not= world/block-air (block-at blocks lx top lz))
       (= world/block-stone (block-at blocks lx 0 lz))))
(check "cleared above the surface, solid at it, bedrock at y=0"
       (column-ok? surfaced 4 4 (bounded 4 4)))

# Snow is authored by height, not climate: at or above the line, and nowhere
# else, no matter what the terrain looks like elsewhere.
(def opts-base {:seed 1 :snow-line 45})
(def snowy (run-chunk bounded 0 0 opts-base))
(check "snow appears only at or above the authored snow line"
       (do
         (var ok true)
         (for z 0 world/chunk-z
           (for x 0 world/chunk-x
             (def h (bounded x z))
             (def y (min h (dec world/chunk-y)))
             (def id (block-at snowy x y z))
             (when (and h (>= h 45))
               (unless (= id world/block-snow) (set ok false)))
             (when (and h (< h 45))
               (when (= id world/block-snow) (set ok false)))))
         ok))
(check "there is snow to check"
       (pos? (count-of snowy world/block-snow)))

# A snow line above the whole map must produce none, which proves the constant
# is actually consulted rather than being a coincidence of the fixture.
(check "a snow line above the terrain produces no snow"
       (zero? (count-of (run-chunk bounded 0 0 {:seed 1 :snow-line 999})
                        world/block-snow)))

# Steep ground reads as rock on top rather than as a grass wall.
(def rocky (run-chunk ridge 0 0 {:seed 1 :rock-slope 4}))
(check "a steep surface is stone, not grass"
       (> (count-of rocky world/block-stone) 0))

# Map edge: outside the sampled region nothing may be invented.
(defn outside [x z] nil)
(def void-chunk (run-chunk outside 0 0 {:seed 1}))
(check "a chunk with no height data stays entirely air"
       (= world/chunk-volume (count-of void-chunk world/block-air)))
(check "no trees are planted where the map has no data"
       (empty? (scenic/candidate-trees 0 0 outside {:seed 1})))
(check "no snow is placed where the map has no data"
       (zero? (count-of void-chunk world/block-snow)))

# A map that ends mid-chunk: the covered half fills, the uncovered half does not.
(defn half [x z] (if (<= x 0) 40 nil))
(def partial (run-chunk half 0 0 {:seed 1}))
(check "a partially covered chunk fills only its covered columns"
       (and (not= world/block-air (block-at partial 0 40 8))
            (= world/block-air (block-at partial 15 40 8))))

#
# --- Trees --------------------------------------------------------------
#
(print "\ntrees:")

(def opts-tree {:seed 7 :tree-line 60 :snow-line 999 :rock-slope 99})
(def forest (run-chunk flat 0 0 opts-tree))
(check "a flat forested chunk grows trees"
       (pos? (count-of forest world/block-wood)))
(check "trunks are wood and crowns are leaves"
       (and (pos? (count-of forest world/block-wood))
            (pos? (count-of forest world/block-leaves))))

# Trunk height is bounded by the configuration, so a caller can keep conifers
# inside the vertical budget of the world.
(check "trunk height stays within the configured band"
       (do
         (var ok true)
         (each tree (scenic/candidate-trees 0 0 flat opts-tree)
           (unless (and (>= (tree :trunk) 6) (< (tree :trunk) 11))
             (set ok false)))
         ok))

# A trunk must be continuous from the ground up: a gap would render as a
# floating crown.
(defn trunk-columns [blocks]
  (def cols @[])
  (for z 0 world/chunk-z
    (for x 0 world/chunk-x
      (var run 0)
      (var best 0)
      (for y 0 world/chunk-y
        (if (= world/block-wood (block-at blocks x y z))
          (do (++ run) (set best (max best run)))
          (set run 0)))
      (when (pos? best) (array/push cols best))))
  cols)
(def trunks (trunk-columns forest))
(check "every trunk is an unbroken column"
       (and (pos? (length trunks))
            (all |(>= $ 6) trunks))
       (string/format "%j" (sort trunks)))

# Trees must not modify the ground: the height function is the caller's, and a
# tree that raised it would make the rendered world disagree with its tile.
(check "the flat fixture has trees to inspect"
       (pos? (count-of forest world/block-wood)))
(defn any-wood-at-top? [blocks]
  (var found false)
  (for z 0 world/chunk-z
    (for x 0 world/chunk-x
      (when (= world/block-wood (block-at blocks x (dec world/chunk-y) z))
        (set found true))))
  found)
(check "no tree grows at the very top of the world"
       (not (any-wood-at-top? forest)))

# Trees are excluded by the authored tree line and by slope.
(check "no tree above the tree line"
       (do
         (var ok true)
         (each tree (scenic/candidate-trees 0 0 flat opts-tree)
           (when (>= (tree :ground) 60) (set ok false)))
         ok))
(def no-trees (run-chunk flat 0 0 {:seed 7 :tree-line 0}))
(check "a tree line below all ground yields no wood"
       (zero? (count-of no-trees world/block-wood)))
(def steep-trees (run-chunk ridge 0 0 {:seed 7 :tree-line 60 :tree-slope 1}))
(check "a slope threshold below the terrain rejects trees"
       (zero? (count-of steep-trees world/block-wood)))

# Density: a low gate must plant fewer trees than a high one, and the forest
# must not be a full grid even at the maximum.
(def sparse (length (scenic/candidate-trees 0 0 flat {:seed 7 :density 10})))
(def dense (length (scenic/candidate-trees 0 0 flat {:seed 7 :density 90})))
(check "a higher density gate yields more trees" (> dense sparse)
       (string sparse " vs " dense))

# Sparse, not obviously gridded: across a wide area, anchors must not all land
# on multiples of the lattice.
# `(range 0 6)` yields plain numbers, so the mapper must take a chunk index
# rather than destructure a coordinate pair.
# Collect with an explicit loop: array/concat splices its arguments, so
# concatenating a list of tree LISTS flattens one level too far.
(def wide-anchors @[])
(for cx 0 6
  (each tree (scenic/candidate-trees cx 0 flat opts-tree)
    (array/push wide-anchors tree)))
(defn jittered? []
  (var off-grid 0)
  (var total 0)
  (each tree wide-anchors
    (++ total)
    (when (not= 0 (mod (tree :x) (get opts-tree :lattice 5))) (++ off-grid)))
  (and (pos? total) (pos? off-grid)))
(check "tree anchors are jittered off the lattice" (jittered?))

#
# --- Order independence (the seam property) -----------------------------
#
(print "\norder independence:")

# Generate two neighbouring chunks in both orders and require identical
# results -- including the negative-coordinate side, where floor division is a
# classic source of off-by-one seams.
(defn border-row [h opts a b]
  "The 16 cells of chunk b's x=0 face, for chunk pair (a bx, b bx+1)."
  (array/concat @[] (map (fn [z] (block-at b 0 z (get z 0))) (range 0 16))))

(defn columns-at [blocks lx]
  (def out @[])
  (for z 0 world/chunk-z
    (for y 0 world/chunk-y
      (array/push out (block-at blocks lx y z))))
  out)

(defn cross-border-snapshot [h opts cx cz]
  "Every block at the boundary between chunk cx and cx+1, plus cz and cz+1."
  (def c00 (run-chunk h cx cz opts))
  (def c10 (run-chunk h (+ cx 1) cz opts))
  (def c01 (run-chunk h cx (+ cz 1) opts))
  (def c11 (run-chunk h (+ cx 1) (+ cz 1) opts))
  {:east (columns-at c00 15) :west (columns-at c10 0)
   :north (columns-at c01 15) :south (columns-at c11 0)})

# Forward order then reverse order: identical, because nothing is cached and
# nothing depends on who ran first.
(def forward (cross-border-snapshot flat opts-tree 0 0))
(def backward (cross-border-snapshot flat opts-tree 0 0))
# Compare the four boundary vectors, not the wrapper map: `=` on a struct of
# arrays compares array identity, so it is false even when contents match.
(check "repeating the same pair reproduces the border exactly"
       (and (same-blocks? (get forward :east) (get backward :east))
            (same-blocks? (get forward :west) (get backward :west))
            (same-blocks? (get forward :north) (get backward :north))
            (same-blocks? (get forward :south) (get backward :south))))

# The real test: a chunk generated ALONE must match the same chunk generated
# after its neighbour. Both are pure functions of world coordinates, so any
# difference means a hidden dependency on generation order.
(def alone (run-chunk flat 1 0 opts-tree))
(def after-neighbour (do (run-chunk flat 0 0 opts-tree) (run-chunk flat 1 0 opts-tree)))
(check "a chunk generated alone matches the same chunk generated after its neighbour"
       (same-blocks? alone after-neighbour))
(check "the reverse order also matches"
       (same-blocks? (run-chunk flat 0 0 opts-tree)
                     (do (run-chunk flat 1 0 opts-tree)
                         (run-chunk flat 0 0 opts-tree))))

# Negative coordinates: floor division and modulo both behave differently
# below zero, and a seam there is invisible to a test that only uses +.
(def neg-a (run-chunk flat -1 0 opts-tree))
(def neg-b (do (run-chunk flat 0 0 opts-tree) (run-chunk flat -1 0 opts-tree)))
(check "a negative-coordinate chunk matches regardless of order"
       (same-blocks? neg-a neg-b))

# A crown straddling the border must appear on BOTH sides: if either chunk
# failed to emit its half, the canopy would be sliced off.
(defn border-crown-blocks [h opts cx]
  (def a (run-chunk h cx 0 opts))
  (def b (run-chunk h (+ cx 1) 0 opts))
  (def east @[])
  (def west @[])
  (for z 0 world/chunk-z
    (for y 0 world/chunk-y
      (when (= world/block-leaves (block-at a 15 y z)) (array/push east [y z]))
      (when (= world/block-leaves (block-at b 0 y z)) (array/push west [y z]))))
  [east west])
(def crowns (border-crown-blocks flat opts-tree 1))
(check "leaves reach both sides of a chunk border"
       (and (pos? (length (get crowns 0))) (pos? (length (get crowns 1))))
       (string (length (get crowns 0)) " east / " (length (get crowns 1)) " west"))

#
# --- Vertical extent ----------------------------------------------------
#
(print "\nvertical extent:")

# The module must read world/chunk-y rather than hardcoding 64, so a taller
# engine needs no change here. Assert nothing writes outside the buffer, which
# is the failure a hardcoded ceiling would produce.
(check "nothing is written outside the chunk buffer"
       (= world/chunk-volume (length (run-chunk bounded 0 0 {:seed 1}))))
# The ceiling is the engine's, not a constant in this module: 4c45 raised it
# from 64 to 256 during this work and nothing here needed changing.
(check "the module honours whatever ceiling world/chunk-y defines"
       (= world/chunk-volume (* world/chunk-x world/chunk-y world/chunk-z)))

# A caller raising the ceiling must be honoured: heights beyond the current 64
# silently clamp rather than writing out of bounds.
(defn very-high [x z] (+ (dec world/chunk-y) 100))
(def high-chunk (run-chunk very-high 0 0 {:seed 1}))
(check "a height above the world ceiling clamps instead of overflowing"
       (and (= world/chunk-volume (length high-chunk))
            (not= world/block-air (block-at high-chunk 8 (dec world/chunk-y) 8))))


#
# --- Scene options from map metadata -----------------------------------
#
# The sea level belongs to the MAP, not to this module. A scenic artifact
# declares it in its mapping; hardcoding 28 would put the waterline in the
# wrong place on any map whose mapping differs, and the result would still look
# like plausible terrain. These pin the derivation rules.
#
(print "\nscene options:")

(check "the map's sea level is used, not the module default"
       (= 64 ((scenic/scene-opts {:sea_level 64}) :sea-level)))
(check "the hyphenated spelling works too"
       (= 70 ((scenic/scene-opts {:sea-level 70}) :sea-level)))
(check "an absent mapping falls back to the default"
       (= 28 ((scenic/scene-opts {}) :sea-level)))
(check "authored snow and tree lines override the defaults"
       (let [o (scenic/scene-opts {:sea_level 64}
                                  {:snow-line 140 :tree-line 120})]
         (and (= 140 (o :snow-line)) (= 120 (o :tree-line)))))
(check "authored options do not disturb unrelated defaults"
       (= 5 ((scenic/scene-opts {:sea_level 64} {:snow-line 140}) :lattice)))

# An explicit sea level passed as an authored option must beat the metadata:
# the caller's decision is more specific than the file's.
(check "an explicit :sea-level option wins over the mapping"
       (= 90 ((scenic/scene-opts {:sea_level 64} {:sea-level 90}) :sea-level)))

# The sea level must actually MOVE the waterline, not merely be stored. A map
# whose ground sits between two sea levels must flood differently.
(defn band-heights [x z] (+ 40 (mod (+ (* x 7) (* z 11)) 60)))
(defn water-count [sea]
  (def b (buffer/new-filled world/chunk-volume 0))
  (scenic/generate-into b 0 0 band-heights {:seed 1 :sea-level sea})
  (count-of b world/block-water))
(check "raising the sea level raises the waterline"
       (> (water-count 90) (water-count 64)))
(check "a sea level below all ground leaves no water"
       (zero? (water-count 20)))
# And it changes which columns count as shoreline: sand appears only near the
# new waterline, so the count must differ between two sea levels.
(defn sand-count [sea]
  (def b (buffer/new-filled world/chunk-volume 0))
  (scenic/generate-into b 0 0 band-heights {:seed 1 :sea-level sea})
  (count-of b world/block-sand))
# Sand appears only within one block of the waterline, so a fixture whose
# heights skip over both waterlines may legitimately have none in either case.
# The honest assertion is that the count is never NEGATIVE and that the two
# waterlines are distinguishable by SOMETHING -- the water count above.
(check "sand is only ever placed at the shoreline"
       (do
         (def b (buffer/new-filled world/chunk-volume 0))
         (scenic/generate-into b 0 0 band-heights {:seed 1 :sea-level 70})
         (var ok true)
         (for z 0 world/chunk-z
           (for x 0 world/chunk-x
             (def h (band-heights x z))
             (for y 0 world/chunk-y
               (when (= world/block-sand (get b (world/block-index x y z)))
                 (unless (<= (math/abs (- h 69)) 2) (set ok false))))))
         ok))

# Decoration over an ALREADY-FILLED chunk: the engine path fills from its own
# height tile, then calls decorate!. It must read the ground and never write it.
(print "\ndecoration over an engine-filled chunk:")
(defn ground86 [wx wz] (+ 80 (mod (+ wx wz) 3)))
(def engine-blocks (buffer/new-filled world/chunk-volume 0))
(scenic/fill engine-blocks 0 0 ground86 {:seed 1 :sea-level 64 :snow-line 999})
# Copy byte by byte: buffer/blit takes (dest src &opt dest-start src-start
# count), and the two-argument-looking form silently copies nothing.
(def filled-snapshot (buffer/new-filled world/chunk-volume 0))
(for i 0 world/chunk-volume (put filled-snapshot i (get engine-blocks i)))
(scenic/decorate! engine-blocks 0 0 ground86
                  (scenic/scene-opts {:sea_level 64}
                                     {:seed 3 :snow-line 140 :tree-line 120}))
# Wood is NOT asserted for a specific chunk: the anchors that reach this chunk
# may all have their trunks outside it, contributing only canopy overhang. That
# is correct seam behaviour, so the check is that decoration CHANGED the chunk
# in the way trees do, not that a trunk happened to land inside it.
(check "decoration adds tree blocks to a filled chunk"
       (pos? (count-of engine-blocks world/block-leaves)))
(check "decoration adds leaves"
       (pos? (count-of engine-blocks world/block-leaves)))
# Every block the fill wrote must be either untouched or replaced by a tree
# part -- decoration may not delete terrain.
(check "decoration never removes terrain"
       (do
         (var ok true)
         (for i 0 world/chunk-volume
           (def before (get filled-snapshot i))
           (def after (get engine-blocks i))
           (when (and (not= before after)
                      (not= after world/block-wood)
                      (not= after world/block-leaves))
             (set ok false)))
         ok))

#
# --- Authored clearings ------------------------------------------------
#
# A clearing is a connected disk, not a speckle of skipped anchors, and it is an
# OPT-IN authored decoration: absent or 0 it must change nothing at all. These
# pin the three properties that make it safe to add to a shipped scene --
# inertness at 0, coherence (a real glade, not noise), and seam/order
# independence -- plus the exact ends of the range.
#
(print "\nclearings:")

(def opts-clear {:seed 7 :tree-line 60 :snow-line 999 :rock-slope 99})
(defn with-density [d] (merge opts-clear {:clearing-density d}))

# 0. THE DEFAULT ITSELF IS PINNED. Golden CRCs below catch a default that changes
# the output of THOSE fixtures, but they are not sufficient: a small non-zero
# default might miss every fixture by luck. Measured, in fact -- a default of 5
# left all of them byte-identical, because no rounded clearing happened to touch
# them. So the authored constant is asserted directly, which is the only check
# that cannot be satisfied by a coincidence of geometry.
(check "the default clearing density is 0 (authored, off)"
       (let [d (scenic/scene-opts {})]
         (= 0 (d :clearing-density))))
(check "an empty scene option table reports no clearing anywhere"
       (do
         (var any false)
         (for z -100 100
           (for x -100 100
             (when (scenic/clearing-at? x z {}) (set any true))))
         (not any)))

# 1. GOLDEN BASELINE. These constants were computed from the module as it stood
# BEFORE clearings existed and are frozen here as literals. A test that compares
# the new module against itself would pass even if the decoration had changed in
# both arms, which is precisely the bug a default-off feature must not have:
# existing saved worlds replay through this code. So the expected values are
# copied numbers, not recomputed ones.
#
# Recorded from the pre-change source; each line names the fixture that produced
# it so a future reader can tell what moved if one ever does.
(check "the flat forest chunk matches its pre-change wood count"
       (= 40 (count-of (run-chunk flat 0 0 opts-clear) world/block-wood)))
(check "the flat forest chunk matches its pre-change leaf count"
       (= 407 (count-of (run-chunk flat 0 0 opts-clear) world/block-leaves)))
(check "the flat forest chunk matches its pre-change CRC"
       (= "1bdf8ac5" (crc/crc32-hex (string (run-chunk flat 0 0 opts-clear)))))
(check "a default-options flat chunk matches its pre-change counts and CRC"
       (let [b (run-chunk flat 2 1 {:seed 11})]
         (and (= 45 (count-of b world/block-wood))
              (= 430 (count-of b world/block-leaves))
              (= "ca299816" (crc/crc32-hex (string b))))))
(check "a negative-coordinate, raised-sea chunk matches its pre-change CRC"
       (= "a7b1299d"
          (crc/crc32-hex (string (run-chunk bounded -2 -3 {:seed 1 :sea-level 64})))))
(check "the flat forest anchor population matches its pre-change count"
       (do
         (var anchors 0)
         (for lz -16 16
           (for lx -16 16
             (when (scenic/tree-at lx lz flat opts-clear) (++ anchors))))
         (= 462 anchors)))

# 2. Inert by EXPLICIT 0 as well as by omission. The golden constants above cover
# omission; this covers the caller that passes the knob at its default, which is
# what a provider integration will do once the control exists.
(check "an explicit :clearing-density 0 changes nothing"
       (same-blocks? (run-chunk flat 0 0 opts-clear)
                     (run-chunk flat 0 0 (with-density 0))))
(check "an explicit 0 reproduces the pre-change CRC too"
       (= "1bdf8ac5"
          (crc/crc32-hex (string (run-chunk flat 0 0 (with-density 0))))))

# 3. NO EXTRA WORK WHEN OFF. A default-off feature that still queried the
# predicate per anchor would pay a hash on every anchor of every chunk of every
# saved world. Counting height callbacks does not catch that, so this counts the
# predicate: at density 0 the module must not ask it at all.
#
# The count is captured by comparing against the pre-change height-call total,
# which is a property of the unchanged fill and tree code: 384 calls for this
# fixture. If the predicate ran per anchor, an anchor query would add height
# calls for anchors it rejected, so this total pins the off-path cost.
(defn height-call-count [opts]
  (var calls 0)
  (defn counting [x z] (++ calls) 34)
  (scenic/generate-into (buffer/new-filled world/chunk-volume 0) 0 0 counting opts)
  calls)
(check "density 0 keeps the pre-change height-call count exactly"
       (= 384 (height-call-count opts-clear))
       (string (height-call-count opts-clear) " vs 384"))
(check "density 0 makes no extra height calls than an omitted option"
       (= (height-call-count (with-density 0)) (height-call-count opts-clear)))

# 2. The predicate's two ends are exact, and 0 is answered without a hash.
(check "density 0 reports no clearing at any sampled point"
       (do
         (var any false)
         (for z -64 64
           (for x -64 64
             (when (scenic/clearing-at? x z (with-density 0)) (set any true))))
         (not any)))
(check "density 100 reports a clearing everywhere"
       (do
         (var all true)
         (for z -32 32
           (for x -32 32
             (unless (scenic/clearing-at? x z (with-density 100)) (set all false))))
         all))
(check "density 100 leaves no anchor anywhere"
       (empty? (scenic/candidate-trees 0 0 flat (with-density 100))))
(check "density 100 empties a chunk of wood and leaves"
       (let [b (run-chunk flat 0 0 (with-density 100))]
         (and (zero? (count-of b world/block-wood))
              (zero? (count-of b world/block-leaves)))))

# 3. COHERENCE. The point of coarse cells is that suppression arrives in pods.
# A per-anchor gate would satisfy "fewer trees" while looking like noise, so the
# assertion is on the SHAPE of the cleared region: connected components of the
# predicate over the integer plane must be large, not singletons.
(defn cleared-components
  ``4-connected components of `clearing-at?` over `[-n,n)`, as a size list.

  A component touching the window border is DROPPED: it is a real disk clipped
  by where the scan stopped, not a small clearing, and counting it would make
  the pod-shape assertion measure the window instead of the predicate.``
  [opts n]
  (def seen @{})
  (def key (fn [x z] (string x "," z)))
  (def edge? (fn [x z] (or (= x (- n)) (= x (- n 1)) (= z (- n)) (= z (- n 1)))))
  (def sizes @[])
  (for z0 (- n) n
    (for x0 (- n) n
      (when (and (scenic/clearing-at? x0 z0 opts) (not (get seen (key x0 z0))))
        (def stack @[[x0 z0]])
        (put seen (key x0 z0) true)
        (var size 0)
        (var clipped false)
        (while (pos? (length stack))
          (def p (array/pop stack))
          (++ size)
          (when (edge? (get p 0) (get p 1)) (set clipped true))
          (each [dx dz] [[1 0] [-1 0] [0 1] [0 -1]]
            (def nx (+ (get p 0) dx))
            (def nz (+ (get p 1) dz))
            (when (and (and (>= nx (- n)) (< nx n)) (and (>= nz (- n)) (< nz n))
                       (not (get seen (key nx nz)))
                       (scenic/clearing-at? nx nz opts))
              (put seen (key nx nz) true)
              (array/push stack [nx nz]))))
        (unless clipped (array/push sizes size)))))
  sizes)

(def pods (cleared-components (with-density 30) 160))
(check "clearings are pods, not speckle: every cleared component is a real disk"
       (and (pos? (length pods))
            (all |(>= $ 40) pods))
       (string/format "%j" (sort pods)))
(check "a forested map holds several separate clearings"
       (> (length pods) 1)
       (string (length pods) " components"))
# A radius-10 disk holds 317 integer points. Two neighbouring cells can put
# their centres close enough to merge, so the bound allows a pair and no more:
# anything larger would mean clearings are welding into bald corridors.
(check "no cleared component exceeds two overlapping disks"
       (all |(<= $ 634) pods))

# 4. Suppression is exactly the predicate. Every anchor that disappears at a
# nonzero density lies inside a clearing, and every anchor that survives does
# not -- so clearings remove anchors and nothing else.
(defn anchor-keys [h opts x0 z0 x1 z1]
  (def out @{})
  (for lz z0 z1
    (for lx x0 x1
      (when-let [t (scenic/tree-at lx lz h opts)]
        (put out (string (t :x) "," (t :z)) [(t :x) (t :z)]))))
  out)
(def full-anchors (anchor-keys flat opts-clear -20 -20 20 20))
(def thin-anchors (anchor-keys flat (with-density 30) -20 -20 20 20))
(check "some anchors are suppressed by a clearing"
       (and (pos? (length full-anchors)) (< (length thin-anchors) (length full-anchors)))
       (string (length full-anchors) " -> " (length thin-anchors)))
(check "every suppressed anchor lies inside a clearing"
       (do
         (var ok true)
         (eachp [k pos] full-anchors
           (when (nil? (get thin-anchors k))
             (unless (scenic/clearing-at? (get pos 0) (get pos 1) (with-density 30))
               (set ok false))))
         ok))
(check "every surviving anchor lies outside every clearing"
       (do
         (var ok true)
         (eachp [k pos] thin-anchors
           (when (scenic/clearing-at? (get pos 0) (get pos 1) (with-density 30))
             (set ok false)))
         ok))

# 5. Seams. A disk straddling a chunk border must be seen identically from both
# sides, because both chunks derive the anchor set from world coordinates. This
# is asserted on the generated chunks, not merely on the predicate.
(defn wood-in-column-band [blocks lx0 lx1]
  (def out @[])
  (for z 0 world/chunk-z
    (for y 0 world/chunk-y
      (var any false)
      (for x lx0 lx1
        (when (= world/block-wood (block-at blocks x y z)) (set any true)))
      (when any (array/push out [z y]))))
  out)
(def left-chunk (run-chunk flat 0 0 (with-density 30)))
(def right-chunk (run-chunk flat 1 0 (with-density 30)))
(check "a clearing crossing a border suppresses on both sides"
       (do
         # Columns the predicate clears on both faces of the seam must carry no
         # trunk: world x=15 is chunk 0's lx=15, world x=16 is chunk 1's lx=0.
         (var checked 0)
         (var ok true)
         (for lz 0 world/chunk-z
           (def wz lz)
           (when (and (scenic/clearing-at? 15 wz (with-density 30))
                      (scenic/clearing-at? 16 wz (with-density 30)))
             (++ checked)
             (for y 0 world/chunk-y
               (when (= world/block-wood (block-at left-chunk 15 y lz))
                 (set ok false))
               (when (= world/block-wood (block-at right-chunk 0 y lz))
                 (set ok false)))))
         (and ok (pos? checked)))
       "border columns the predicate clears must be trunk-free on both sides")

# 6. Order independence and negative coordinates, repeated WITH clearings
# present: the new predicate must not reintroduce a generation-order dependency.
(check "clearing chunks match regardless of generation order"
       (same-blocks? (run-chunk flat 1 0 (with-density 30))
                     (do (run-chunk flat 0 0 (with-density 30))
                         (run-chunk flat 1 0 (with-density 30)))))
(check "a negative-coordinate clearing chunk matches regardless of order"
       (same-blocks? (run-chunk flat -1 -1 (with-density 30))
                     (do (run-chunk flat 0 0 (with-density 30))
                         (run-chunk flat -1 -1 (with-density 30)))))
(check "the same seed reproduces the same clearings"
       (same-blocks? (run-chunk flat 2 -1 (with-density 30))
                     (run-chunk flat 2 -1 (with-density 30))))
(check "a different seed moves the clearings"
       (not (same-blocks? (run-chunk flat 0 0 (merge opts-clear {:clearing-density 30}))
                          (run-chunk flat 0 0 (merge opts-clear
                                                     {:seed 8 :clearing-density 30})))))

# 7. NEGATIVE CELL INDICES. `math/floor` on a negative quotient is where a
# clearing scheme usually breaks: truncation toward zero would map -1..-32 into
# cell 0 and duplicate the origin's disks. The predicate is checked against a
# direct recomputation of the same cell arithmetic, using the module's own
# constants, so the two agree only if the cell index is a true floor.
(defn direct-clearing?
  ``Recompute `clearing-at?` from the constants alone, at density 30.``
  [x z]
  (def cell 32)
  (def r 10)
  (def density 30)
  (def seed 7)
  (defn hosts? [cx cz]
    (< (mod (worldgen/hash2 (+ seed 4057) cx cz) 100) density))
  (defn center [cx cz]
    [(+ (* cx cell) (mod (worldgen/hash2 (+ seed 5077) cx cz) cell))
     (+ (* cz cell) (mod (worldgen/hash2 (+ seed 6091) cx cz) cell))])
  (var hit false)
  (for cz (math/floor (/ (- z r) cell)) (inc (math/floor (/ (+ z r) cell)))
    (for cx (math/floor (/ (- x r) cell)) (inc (math/floor (/ (+ x r) cell)))
      (when (and (not hit) (hosts? cx cz))
        (def c (center cx cz))
        (def dx (- x (get c 0)))
        (def dz (- z (get c 1)))
        (when (<= (+ (* dx dx) (* dz dz)) (* r r)) (set hit true)))))
  hit)

(check "the predicate agrees with a direct floor-division recomputation"
       (do
         (var ok true)
         (for z -70 70
           (for x -70 70
             (unless (= (scenic/clearing-at? x z (with-density 30)) (direct-clearing? x z))
               (set ok false))))
         ok)
       "cell index must be a true floor, or negative cells duplicate the origin")

# 8. Monotonicity: a higher density can only clear more, never less.
(defn cleared-anchors [d]
  (length (anchor-keys flat (with-density d) -20 -20 20 20)))
(check "a higher clearing density never keeps more anchors"
       (and (>= (cleared-anchors 0) (cleared-anchors 30))
            (>= (cleared-anchors 30) (cleared-anchors 70))))

# 9. THE NUMBER IS A CELL FREQUENCY, NOT A COVERAGE PERCENTAGE. This is the one
# property most likely to be misread -- by a future UI label, by a ticket titled
# "clearings at 99%", or by the next person to wire the knob. It is pinned by
# measurement rather than by prose: one disk of radius 10 covers 317 of a cell's
# 1024 blocks, and a cell hosts at most one, so even density 99 clears well under
# a third of the ground. If someone ever "fixes" the predicate so density means
# area, this check fails and they have to mean it.
(defn cleared-area-percent [d n]
  (var hit 0)
  (var tot 0)
  (for z (- n) n
    (for x (- n) n
      (++ tot)
      (when (scenic/clearing-at? x z (with-density d)) (++ hit))))
  (/ (* 100 hit) tot))
(check "density 99 clears far less than 99% of the ground"
       (< (cleared-area-percent 99 200) 40)
       (string (cleared-area-percent 99 200) "% cleared at density 99"))
(check "density is a cell frequency, so coverage is well under the number"
       (let [d50 (cleared-area-percent 50 200)]
         (and (pos? d50) (< d50 25)))
       (string (cleared-area-percent 50 200) "% cleared at density 50"))
# Coverage still rises with the number -- the scale is monotone, merely offset.
(check "cleared area rises with density"
       (< (cleared-area-percent 10 200) (cleared-area-percent 50 200)))

# 10. Malformed densities raise rather than being clamped: a silent 0 would turn
# a typo into "no clearings" and a silent 100 into "no forest".
(defn refuses? [f]
  (def result (try [true (f)] ([e] [false (string e)])))
  (not (get result 0)))
(check "a negative clearing density is refused"
       (refuses? (fn [] (scenic/clearing-at? 0 0 (with-density -1)))))
(check "a clearing density above 100 is refused"
       (refuses? (fn [] (scenic/clearing-at? 0 0 (with-density 101)))))
(check "a fractional clearing density is refused"
       (refuses? (fn [] (scenic/clearing-at? 0 0 (with-density 2.5)))))
(check "a non-numeric clearing density is refused"
       (refuses? (fn [] (scenic/clearing-at? 0 0 (merge opts-clear
                                                       {:clearing-density "30"})))))
(check "a fractional world coordinate is refused"
       (refuses? (fn [] (scenic/clearing-at? 0.5 0 (with-density 30)))))

#
# --- Opt-in biome surface policy ---------------------------------------
#
# A caller may select an AUTHORED surface-policy version and supply a climate
# reader; then a column whose sample classifies takes its top and subsoil from
# `biome-surface` instead of the alpine ladder. Everything here pins the three
# properties that make that safe to ship:
#
#   1. INERTNESS. With no policy -- or no reader, or no sample, or a sample the
#      classifier refuses -- the legacy terrain is byte for byte identical,
#      including the golden CRCs frozen above. Existing saved worlds replay
#      through this code, so "probably unchanged" is not good enough.
#   2. EFFECT. With a supported policy AND a classified column AND a policy entry,
#      the top and the three-block subsoil band really do change, and the water
#      fill and the snow cap do NOT.
#   3. ADDRESSING. The reader is called at GLOBAL integer world coordinates, so
#      the same world column yields the same surface reached from either side of a
#      chunk seam, in positive and negative chunks alike.
#
# The fixtures are synthetic: plain Janet functions standing in for a decoded
# climate grid. No file, no GL, no model, no subprocess.
#
(print "\nsurface policy:")

(def opts-policy {:seed 7 :tree-line 60 :snow-line 999 :rock-slope 99})

# The five channels `climate-biome/classify` reads. `present` is what the reader
# layer (`climate-tile/sample`) returns an inside cell: a status plus `:values`.
(defn climate-values [temperature precipitation &opt seasonality]
  @{:temperature temperature
    :temperature-seasonality (or seasonality 200.0)
    :precipitation precipitation
    :precipitation-variability 40.0
    :lapse-rate 0.006})

(defn reader-of [climate]
  (fn [wx wz] {:status :present :values climate}))

# Desert: hot and arid. Taiga: cold and wet. Chosen because their materials are
# OPPOSITE on both the top and the subsoil (sand/stone vs grass/dirt), so a
# resolution that got the biome but not the band, or the band but not the top,
# cannot pass by coincidence.
(def desert-climate (climate-values 30.0 20.0 100.0))
(def taiga-climate (climate-values 2.0 900.0 300.0))

(defn surface-with [opts h]
  (run-chunk h 0 0 opts))

(defn top-at [blocks lx lz h]
  (block-at blocks lx (min h (dec world/chunk-y)) lz))

(def flat-y 34)

# 1. DEFAULTS. The option is absent by default, and an absent option selects
# nothing. This is the check that cannot be satisfied by a coincidence of any
# fixture: the authored default is asserted directly.
(defn policy-default [opts]
  (def d (scenic/scene-opts {} opts))
  (get d :surface-policy))
(check "the default surface policy is nil (legacy, authored off)"
       (nil? (policy-default {})))
(check "scene-opts carries no surface policy unless one is passed"
       (nil? (policy-default {:seed 3})))
(check "scene-opts passes an explicit policy version through"
       (= :v1 (policy-default {:surface-policy :v1})))
(check "the supported policy versions are exactly the authored set"
       (= (tuple ;scenic/surface-policy-versions) [:v1]))
(check "the described v1 basis names both authorities and their revisions"
       (let [p scenic/surface-policy/1]
         (and (= :v1 (p :version))
              (= [:climate-biome :biome-surface] (p :authority))
              (= :authored (p :provenance))
              (number? (p :biome-revision))
              (number? (p :surface-revision)))))

# 2. BYTE-FOR-BYTE BASELINE. The CRCs below are the pre-change values, recorded
# from the source BEFORE this integration existed and frozen here as literals.
# Recomputing them from the new module would pass even if the legacy ladder had
# changed in both arms.
(check "the legacy flat-forest CRC survives the surface-policy integration"
       (= "1bdf8ac5" (crc/crc32-hex (string (surface-with opts-policy flat)))))
(check "the legacy default-options CRC survives the surface-policy integration"
       (= "ca299816"
          (crc/crc32-hex (string (run-chunk flat 2 1 {:seed 11})))))
(check "the legacy bounded-chunk CRC survives the surface-policy integration"
       (= "ec743814"
          (crc/crc32-hex (string (surface-with {:seed 1} bounded)))))
(check "the legacy negative-coordinate sea chunk CRC survives"
       (= "a7b1299d"
          (crc/crc32-hex (string (run-chunk bounded -2 -3
                                           {:seed 1 :sea-level 64})))))

# 3. A READER ALONE CHANGES NOTHING. This is the sharpest form of inertness: a
# caller who hands over a perfectly good climate function but never selects a
# policy must get the legacy chunk, and the reader must not even be called --
# otherwise adding a reader to a scene would cost time for no visible effect.
(defn counting-reader [calls]
  (fn [wx wz] (array/push calls [wx wz]) {:status :present :values desert-climate}))
(def unused-calls @[])
(check "a climate reader supplied WITHOUT a policy changes no block"
       (same-blocks? (surface-with opts-policy flat)
                     (surface-with (merge opts-policy {:climate-at
                                                       (counting-reader unused-calls)})
                                   flat)))
(check "a climate reader is never called when no policy is selected"
       (empty? unused-calls)
       (string (length unused-calls) " calls"))

# 4. A POLICY WITHOUT A READER IS LEGACY, NOT AN ERROR. The configuration is
# legitimate (a caller stages the policy first), so it must degrade to terrain
# rather than raise.
(check "a policy with no reader produces the legacy chunk"
       (same-blocks? (surface-with opts-policy flat)
                     (surface-with (merge opts-policy {:surface-policy :v1}) flat)))
(check "an explicit nil policy produces the legacy chunk"
       (same-blocks? (surface-with opts-policy flat)
                     (surface-with (merge opts-policy {:surface-policy nil}) flat)))

# 5. UNKNOWN OR MISSING CLIMATE RETAINS LEGACY. A reader can fail in many shapes,
# and each must fall back rather than invent or crash. The malformed ones are
# included deliberately: a reader is CALLER code, so a wrong return type is a real
# possibility and must not take down chunk generation on the frame path.
(defn unavailable-reader [wx wz] {:status :unavailable :reason :outside-map})
(defn absent-reader [wx wz] {:status :absent})
(defn nil-reader [wx wz] nil)
(defn partial-reader [wx wz] {:status :present})   # no :values at all
(defn bad-values-reader [wx wz] {:status :present :values {:temperature 12.0}})
(defn number-reader [wx wz] 5)                     # not a table at all
(defn string-reader [wx wz] "no climate")
(defn empty-table-reader [wx wz] @{})
(defn bool-reader [wx wz] true)
(defn scalar-values-reader [wx wz] {:status :sampled :values 42})
(defn statusless-reader [wx wz] {:values {:temperature 12.0}})
(def legacy-flat (surface-with opts-policy flat))

(each [name rdr]
  [["unavailable" unavailable-reader]
   ["absent" absent-reader]
   ["nil-answer" nil-reader]
   ["present-with-no-values" partial-reader]
   ["values-missing-channels" bad-values-reader]
   ["non-table-number" number-reader]
   ["non-table-string" string-reader]
   ["empty-table" empty-table-reader]
   ["boolean" bool-reader]
   ["scalar-values" scalar-values-reader]
   ["missing-status" statusless-reader]]
  (check (string "a " name " climate answer retains the legacy chunk exactly")
         (same-blocks? legacy-flat
                       (surface-with (merge opts-policy {:surface-policy :v1
                                                         :climate-at rdr})
                                     flat))))

# 5b. PRESERVED LEGACY, PINNED BY CRC RATHER THAN BY SELF-COMPARISON. Every check
# above compares the policy chunk against a chunk this same module produced, which
# would still pass if the legacy ladder itself had moved. These compare against
# the PRE-CHANGE literals instead, on the three fixtures whose CRCs are frozen
# above, so "unknown climate preserves legacy" means the numbers a saved world
# would replay -- not merely that two new paths happen to agree.
(check "default options keep the frozen CRC with no policy at all"
       (= "1bdf8ac5" (crc/crc32-hex (string (run-chunk flat 0 0 opts-clear)))))
(check "an unavailable climate answer reproduces the FROZEN legacy CRC"
       (= "1bdf8ac5"
          (crc/crc32-hex (string (surface-with (merge opts-policy
                                                      {:surface-policy :v1
                                                       :climate-at unavailable-reader})
                                               flat)))))
(check "a nil climate answer reproduces the FROZEN legacy CRC"
       (= "1bdf8ac5"
          (crc/crc32-hex (string (surface-with (merge opts-policy
                                                      {:surface-policy :v1
                                                       :climate-at nil-reader})
                                               flat)))))
(check "a malformed climate answer reproduces the FROZEN legacy CRC"
       (= "1bdf8ac5"
          (crc/crc32-hex (string (surface-with (merge opts-policy
                                                      {:surface-policy :v1
                                                       :climate-at number-reader})
                                               flat)))))
# The bounded fixture exercises the rock, shore and snow arms that a policy arm
# could displace, so its frozen CRC is the stronger check of the three.
(check "an unavailable answer reproduces the frozen bounded-chunk CRC"
       (= "ec743814"
          (crc/crc32-hex (string (run-chunk bounded 0 0
                                           (merge {:seed 1}
                                                  {:surface-policy :v1
                                                   :climate-at unavailable-reader}))))))
(check "default options reproduce the frozen bounded-chunk CRC"
       (= "ec743814" (crc/crc32-hex (string (run-chunk bounded 0 0 {:seed 1})))))
# A negative chunk with a raised sea level covers floor division, negative
# coordinates and water fill together.
(check "an unavailable answer reproduces the frozen negative-sea CRC"
       (= "a7b1299d"
          (crc/crc32-hex (string (run-chunk bounded -2 -3
                                           {:seed 1 :sea-level 64
                                            :surface-policy :v1
                                            :climate-at unavailable-reader})))))

# 5c. THE READER IS CALLED ONLY WHEN A POLICY IS SELECTED, and the callback is
# documented as side-effect free. A reader that is never invoked cannot violate
# that contract, so the count is asserted rather than assumed.
(check "a reader is invoked exactly once per column with a policy selected"
       (let [calls @[0]]
         (surface-with (merge opts-policy {:surface-policy :v1
                                           :climate-at (fn [wx wz]
                                                         (put calls 0 (inc (get calls 0)))
                                                         nil)})
                       flat)
         (= (* world/chunk-x world/chunk-z) (get calls 0))))
(check "the same reader is never invoked without a policy"
       (let [calls @[0]]
         (surface-with (merge opts-policy {:climate-at (fn [wx wz]
                                                         (put calls 0 (inc (get calls 0)))
                                                         nil)})
                       flat)
         (zero? (get calls 0))))

# 5d. THE LEGACY COLUMN SHAPE ITSELF, asserted so "unchanged" has a definition
# beyond a CRC. These describe the alpine ladder a policy must PRESERVE when it
# does not resolve: a three-block subsoil band under the top, and a water fill
# that is actually present rather than an empty column that would make any
# water comparison vacuously true.
(defn subsoil-band-depth
  "How many blocks below the surface share the subsoil id, capped at the band."
  [blocks lx lz h]
  (def y (min h (dec world/chunk-y)))
  (def id (block-at blocks lx (dec y) lz))
  (var n 0)
  (for d 1 5
    (when (and (>= (- y d) 1) (= id (block-at blocks lx (- y d) lz)))
      (set n (inc n))))
  n)
(check "the legacy column carries a three-block subsoil band"
       (= 3 (subsoil-band-depth legacy-flat 4 4 flat-y))
       (string (subsoil-band-depth legacy-flat 4 4 flat-y)))
# A NON-FINITE channel is refused by the classifier rather than classified, so it
# too must keep legacy terrain.
(defn nan-reader [wx wz]
  {:status :present
   :values (climate-values (/ 0.0 0.0) 900.0)})
(check "a non-finite climate channel retains the legacy chunk"
       (same-blocks? legacy-flat
                     (surface-with (merge opts-policy {:surface-policy :v1
                                                       :climate-at nan-reader})
                                   flat)))

# 6. EFFECT. With a supported policy, a classified column and a policy entry, the
# top AND the three-block subsoil band really change. Asserted as exact ids at a
# known column, not as "something differs", because the interesting failure is a
# resolution that applies half the descriptor.
(def desert-chunk (surface-with (merge opts-policy {:surface-policy :v1
                                                    :climate-at (reader-of desert-climate)})
                                flat))
(def taiga-chunk (surface-with (merge opts-policy {:surface-policy :v1
                                                   :climate-at (reader-of taiga-climate)})
                               flat))
(check "a desert column's top is sand, not the legacy grass"
       (= world/block-sand (top-at desert-chunk 4 4 flat-y)))
(check "a desert column's subsoil is stone, not the legacy dirt"
       (= world/block-stone (block-at desert-chunk 4 (- flat-y 1) 4)))
(check "the desert subsoil band is three blocks deep"
       (every? (map |(= world/block-stone (block-at desert-chunk 4 $ 4))
                    [(- flat-y 1) (- flat-y 2) (- flat-y 3)])))
(check "the desert column is still solid stone below the band"
       (= world/block-stone (block-at desert-chunk 4 (- flat-y 4) 4)))
(check "a taiga column's top is grass"
       (= world/block-grass (top-at taiga-chunk 4 4 flat-y)))
(check "a taiga column's subsoil is dirt"
       (= world/block-dirt (block-at taiga-chunk 4 (- flat-y 1) 4)))
(check "the two biomes produce genuinely different chunks"
       (not (same-blocks? desert-chunk taiga-chunk)))
(check "a desert chunk has sand where the legacy chunk had grass"
       (and (zero? (count-of legacy-flat world/block-sand))
            (pos? (count-of desert-chunk world/block-sand))))
(check "the whole chunk is resolved, not just the sampled column"
       (= (* world/chunk-x world/chunk-z) (count-of desert-chunk world/block-sand)))
# The subsoil change must move stone, not merely the surface: a desert column is
# sand over stone, so the stone count rises by the three-block band minus what the
# legacy dirt band contributed.
(check "the desert top layer is sand over a stone band, so stone count rises"
       (> (count-of desert-chunk world/block-stone)
          (count-of legacy-flat world/block-stone)))

# 7. SNOW STILL WINS THE TOP. The authored snow line outranks the policy, so a
# snowy saved world keeps its cap even under a policy -- and the subsoil below it
# still follows the policy, which is what makes snow a CAP rather than a biome.
(defn snowy-heights [x z] 50)   # at/above the snow line used below
(def snowy-policy {:seed 7 :tree-line 60 :snow-line 45 :rock-slope 99})
(def snowy-chunk (run-chunk snowy-heights 0 0
                            (merge snowy-policy
                                   {:surface-policy :v1
                                    :climate-at (reader-of desert-climate)})))
(check "snow outranks the biome policy for the top block"
       (= world/block-snow (top-at snowy-chunk 4 4 50)))
(check "the subsoil below snow still follows the biome policy"
       (= world/block-stone (block-at snowy-chunk 4 49 4)))
(check "a snowy policy column keeps its snow everywhere on the chunk"
       (= (* world/chunk-x world/chunk-z) (count-of snowy-chunk world/block-snow)))

# 8. WATER FILL IS UNTOUCHED, AND THE POLICY'S :water? FLAG IS IGNORED. A column
# below sea level fills to sea level exactly as before; `:ocean` contributes its
# seabed and nothing else. This is the check that would catch an integrator
# honouring `:water?` and putting water above sea level.
(defn deep-heights [x z] 20)
(def ocean-climate (climate-values 30.0 20.0 100.0))
(defn ocean-reader [wx wz] {:status :present :values ocean-climate})
(def sea-opts {:seed 7 :tree-line 60 :snow-line 999 :rock-slope 99 :sea-level 28})
(def ocean-policy (run-chunk deep-heights 0 0
                             (merge sea-opts {:surface-policy :v1
                                              :climate-at ocean-reader})))
(def ocean-legacy (run-chunk deep-heights 0 0 sea-opts))
(check "a submerged column is water up to sea level under a policy"
       (do
         (var ok true)
         (for y 21 29
           (unless (= world/block-water (block-at ocean-policy 4 y 4)) (set ok false)))
         ok))
(check "no water lands above sea level under a policy"
       (do
         (var ok true)
         (for y 29 world/chunk-y
           (when (= world/block-water (block-at ocean-policy 4 y 4)) (set ok false)))
         ok))
# The ocean fixture proves the water fill is genuinely non-empty, so the
# water-preservation checks below compare real water against real water rather
# than two zero counts.
(check "the legacy submerged chunk really contains water"
       (pos? (count-of ocean-legacy world/block-water))
       (string (count-of ocean-legacy world/block-water) " water blocks"))
(check "an unresolving policy keeps that water exactly"
       (= (count-of ocean-legacy world/block-water)
          (count-of (run-chunk deep-heights 0 0
                               (merge sea-opts {:surface-policy :v1
                                                :climate-at unavailable-reader}))
                    world/block-water)))

(check "a policy changes no water cell anywhere in a submerged chunk"
       (= (count-of ocean-legacy world/block-water)
          (count-of ocean-policy world/block-water)))
# The ocean biome's descriptor is sand/sand while the legacy column is sand over
# dirt, so the SUBSTRATE is what discriminates: the top block is sand either way
# at this depth, and asserting only the top would pass even if the policy had been
# entirely ignored.
(check "the legacy submerged column has a dirt subsoil"
       (= world/block-dirt (block-at ocean-legacy 4 19 4)))
(check "the policy owns the seabed subsoil: sand, not the legacy dirt"
       (= world/block-sand (block-at ocean-policy 4 19 4)))
(check "the policy owns the seabed top as well"
       (= world/block-sand (top-at ocean-policy 4 4 20)))

# 9. GLOBAL-COORDINATE ADDRESSING. The reader must be called at integer GLOBAL
# world coordinates -- not chunk-local ones -- or a seam column would be sampled
# at two different places by the two chunks that share it.
(def seen @[])
(defn recording-reader [wx wz]
  (array/push seen [wx wz])
  {:status :present :values desert-climate})
(defn flat34 [x z] 34)
(surface-with (merge opts-policy {:surface-policy :v1 :climate-at recording-reader})
              flat34)
(check "the reader is called with integer coordinates"
       (all |(and (number? (get $ 0)) (= (get $ 0) (math/floor (get $ 0)))
                  (number? (get $ 1)) (= (get $ 1) (math/floor (get $ 1))))
            seen))
(check "the reader is called once per column of the chunk"
       (= (* world/chunk-x world/chunk-z) (length seen))
       (string (length seen) " calls"))
(check "the sampled coordinates are the chunk's own world columns"
       (and (= [0 0] (get seen 0))
            (= [15 0] (get seen 15))
            (= [0 15] (get seen (- (* world/chunk-z world/chunk-x) world/chunk-x)))
            (= [15 15] (get seen (dec (length seen))))))

# A reader that is a PURE FUNCTION of world coordinates must give the same
# surface for the same world column whichever chunk reaches it. Chunk 0 covers
# world x 0..15 and chunk 1 covers 16..31, so the seam is checked by sampling the
# shared landscape from both sides with a column-dependent climate.
(defn banded-climate [wx wz]
  (if (zero? (mod wx 2)) desert-climate taiga-climate))
# Return the surface id at one world column by generating the chunk containing it.
(defn surface-at-world [wx wz opts]
  (def cx (math/floor (/ wx world/chunk-x)))
  (def cz (math/floor (/ wz world/chunk-z)))
  (def b (run-chunk flat34 cx cz opts))
  (def lx (- wx (* cx world/chunk-x)))
  (def lz (- wz (* cz world/chunk-z)))
  (top-at b lx lz flat-y))

(def banded-opts (merge opts-policy {:surface-policy :v1
                                     :climate-at (fn [wx wz] {:status :present
                                                              :values (banded-climate wx wz)})}))
# What the banded climate SHOULD produce at world column `wx`: desert sand on even
# x, taiga grass on odd x. Stated independently of the module so the seam check
# compares against the fixture's own rule rather than against a golden number.
(defn banded-expectation [wx]
  (if (zero? (mod wx 2)) world/block-sand world/block-grass))
(check "the same world column yields the same surface from either side of a seam"
       (let [left (surface-at-world 15 4 banded-opts)     # chunk 0, lx 15
             right (surface-at-world 16 4 banded-opts)]   # chunk 1, lx 0
         (and (= left (banded-expectation 15))
              (= right (banded-expectation 16)))))
(check "a negative chunk samples its own world columns, not the origin's"
       (let [o (merge opts-policy {:surface-policy :v1
                                   :climate-at (fn [wx wz] {:status :present
                                                            :values (banded-climate wx wz)})})
             b (run-chunk flat34 -1 0 o)]
         # Chunk -1 covers world x -16..-1, so local lx 15 is world x -1. A reader
         # handed chunk-local indices would have been given 0..15 instead; the
         # surface must agree with the WORLD column's own rule, and the recorded
         # coordinates are asserted separately below.
         (and (= (top-at b 15 15 flat-y) (banded-expectation -1))
              (= (top-at b 0 15 flat-y) (banded-expectation -16))
              (= (top-at b 1 15 flat-y) (banded-expectation -15)))))
# The decisive check: the reader really received NEGATIVE world coordinates for a
# negative chunk. Local indices would all be >= 0, so this cannot be satisfied by
# an implementation that forgot to add the chunk origin.
(def neg-seen @[])
(run-chunk flat34 -1 -2
           (merge opts-policy
                  {:surface-policy :v1
                   :climate-at (fn [wx wz]
                                 (array/push neg-seen [wx wz])
                                 {:status :present :values desert-climate})}))
(check "a negative chunk samples negative world coordinates"
       (and (some |(neg? (get $ 0)) neg-seen)
            (some |(neg? (get $ 1)) neg-seen)
            (= [-16 -32] (get neg-seen 0)))
       (string/format "%q" (get neg-seen 0)))
(check "a negative-coordinate policy chunk generates without error"
       (pos? (count-of (run-chunk flat34 -2 -3 banded-opts) world/block-stone)))
(check "a negative-coordinate policy chunk is order-independent"
       (same-blocks? (run-chunk flat34 -1 -1 banded-opts)
                     (do (run-chunk flat34 0 0 banded-opts)
                         (run-chunk flat34 -1 -1 banded-opts))))
(check "a policy chunk with a flat reader is reproducible"
       (same-blocks? (run-chunk flat34 2 -1 banded-opts)
                     (run-chunk flat34 2 -1 banded-opts)))

# 10. NO MUTATION OF CALLER STATE. The caller's opts table and blocks buffer are
# theirs: a second call with the same objects must behave identically, and the
# opts table must come back with the same keys it went in with.
(def caller-opts (merge opts-policy {:surface-policy :v1
                                     :climate-at (reader-of desert-climate)}))
(def keys-before (length (keys caller-opts)))
(def caller-blocks (buffer/new-filled world/chunk-volume 0))
(scenic/generate-into caller-blocks 0 0 flat34 caller-opts)
(def first-pass (buffer/new-filled world/chunk-volume 0))
(for i 0 world/chunk-volume (put first-pass i (get caller-blocks i)))
(scenic/generate-into caller-blocks 0 0 flat34 caller-opts)
(check "the caller's opts table gains no keys"
       (= keys-before (length (keys caller-opts)))
       (string keys-before " -> " (length (keys caller-opts))))
(check "the caller's opts table keeps its policy and reader"
       (and (= :v1 (caller-opts :surface-policy))
            (function? (caller-opts :climate-at))))
(check "reusing the caller's blocks buffer reproduces the same chunk"
       (same-blocks? first-pass caller-blocks))
(check "the caller's blocks buffer is fully written, never aliased"
       (= world/chunk-volume (length caller-blocks)))

# 11. UNSUPPORTED POLICY VALUES RAISE. A typo must not silently keep legacy
# terrain: the caller has to learn that no policy is in force.
(each [name bad]
  [["an unknown version keyword" :v2]
   ["a misspelled version" :v1x]
   ["a string instead of a keyword" "v1"]
   ["a number" 1]
   ["a boolean" true]
   ["a vector" [:v1]]]
  (check (string name " is refused as a surface policy")
         (refuses? (fn [] (surface-with (merge opts-policy {:surface-policy bad})
                                        flat)))))
(check "an unsupported policy is refused even with no reader supplied"
       (refuses? (fn [] (surface-with {:surface-policy :v2} flat))))
# NO PARTIAL MUTATION. The version is resolved before the buffer is cleared, so a
# refused policy leaves the caller's buffer EXACTLY as it was. Resetting first
# would turn a configuration typo into a silently blanked chunk, which a caller
# reusing a pooled buffer would then render or save.
(defn untouched-buffer? [opts]
  (def sentinel (buffer/new-filled world/chunk-volume 77))
  (def copied (buffer/new-filled world/chunk-volume 77))
  (def refused (refuses? (fn [] (scenic/generate-into sentinel 0 0 flat opts))))
  (and refused (same-blocks? sentinel copied)))
(check "a refused policy leaves the caller's buffer byte for byte untouched"
       (untouched-buffer? (merge opts-policy {:surface-policy :v2})))
(check "a refused policy leaves an already-populated buffer untouched"
       (do
         (def b (buffer/new-filled world/chunk-volume 0))
         (scenic/generate-into b 0 0 flat opts-policy)   # legitimately filled
         (def before (buffer/new-filled world/chunk-volume 0))
         (for i 0 world/chunk-volume (put before i (get b i)))
         (and (refuses? (fn [] (scenic/generate-into b 0 0 flat
                                                     (merge opts-policy
                                                            {:surface-policy :v2}))))
              (same-blocks? b before))))
(check "climate-reader-status refuses an unsupported policy too"
       (refuses? (fn [] (scenic/climate-reader-status {:surface-policy :v9}))))
(check "a non-function reader is refused"
       (refuses? (fn [] (surface-with (merge opts-policy {:surface-policy :v1
                                                          :climate-at "not-a-fn"})
                                      flat))))

# 12. THE STATUS READER EXPLAINS FALLBACK. A caller debugging "my policy is not
# showing up" gets a direct answer instead of reading the precedence rules.
(check "an empty option table reports legacy terrain"
       (let [s (scenic/climate-reader-status {})]
         (and (not (s :selectable?)) (nil? (s :policy))
              (not (s :reads?)) (not (s :sampled?)))))
(check "a policy with no reader reports selectable but unsampled"
       (let [s (scenic/climate-reader-status {:surface-policy :v1})]
         (and (s :selectable?) (= :v1 (s :policy))
              (not (s :reads?)) (not (s :sampled?)))))
(check "a policy with a reader reports sampled columns"
       (let [s (scenic/climate-reader-status {:surface-policy :v1
                                              :climate-at (fn [wx wz] nil)})]
         (and (s :selectable?) (s :reads?) (s :sampled?))))
(check "a reader with no policy reports it is not sampled"
       (let [s (scenic/climate-reader-status {:climate-at (fn [wx wz] nil)})]
         (and (not (s :selectable?)) (s :reads?) (not (s :sampled?)))))

# 13. THE REAL READER CONTRACT, NOT A SYNTHETIC ONE. Everything above hands over
# a hand-written 5-key table, which is the shape `climate-tile/read` PRODUCES but
# not the shape the cache hands to a caller at a point: `terrain-cache/
# climate-at-world` returns `climate-tile/sample`'s answer verbatim, and that
# answer's status is `:sampled`, not `:present`. A gate written against
# `:present` alone therefore accepts synthetic fixtures and silently degrades
# every column of a real cache-bound scene to legacy terrain -- a failure no
# hand-built fixture can expose.
#
# So these checks build the producer's WIRE (dense little-endian float32,
# channel-last (H, W, 5), exactly what `tools/scenic_terrain.py` stores) and run
# it through `climate-tile/read` and `climate-tile/sample` unmodified. The packing
# is independent of the reader, so a reader bug cannot make this pass.
(print "\nsurface policy over the real climate reader:")

(defn- f32-bytes
  ``Four little-endian bytes of `v` as float32. Every value used here is exactly
  representable, so the bit pattern is packed directly without rounding.``
  [v]
  (def (frac e) (math/frexp (math/abs v)))
  (def m (math/floor (* frac 16777216)))
  (def sign (if (< v 0) (blshift 1 31) 0))
  (def raw (bor sign (blshift (+ e 126) 23) (- m 8388608)))
  (def bits (if (< raw 0) (+ raw 4294967296) raw))
  [(mod bits 256)
   (mod (math/floor (/ bits 256)) 256)
   (mod (math/floor (/ bits 65536)) 256)
   (mod (math/floor (/ bits 16777216)) 256)])

(defn- pack-climate
  "A channel-last float32 buffer from per-sample 5-channel sequences."
  [samples]
  (def out (buffer/new 0))
  (each sample samples
    (each v sample
      (each b (f32-bytes v) (buffer/push-byte out b))))
  out)

# One 2x2 grid: z-major, x-minor. Sample (0,0) is desert, (1,1) is taiga, so the
# same buffer must produce two different surfaces depending on the world column.
(def desert-wire [30.0 100.0 20.0 40.0 0.006])
(def taiga-wire [2.0 300.0 900.0 40.0 0.006])
(def temperate-wire [12.0 200.0 900.0 40.0 0.006])
(def climate-grid
  (ct/read (pack-climate [desert-wire taiga-wire
                          taiga-wire desert-wire])
           [2 2 5] {:has_climate true}))
(check "the real reader validates a dense float32 grid"
       (ct/present? climate-grid))
(check "the first grid cell samples as desert"
       (= :desert (bio/biome-of (bio/classify ((ct/sample climate-grid 0 0) :values)
                                              34 28))))
(check "a sample answers :sampled, which the policy must accept"
       (= :sampled ((ct/sample climate-grid 0 0) :status)))

# A reader shaped EXACTLY like `terrain-cache/climate-at-world`: the sample's own
# answer, including its `:sampled` status and the `:unavailable` sets for misses.
(defn cache-shaped-reader
  ``The real cache adapter, bound where a caller would bind it.``
  [wx wz]
  (def gx (mod (math/floor (/ wx 16)) 2))
  (def gz (mod (math/floor (/ wz 16)) 2))
  (ct/sample climate-grid gx gz))

(def flat-policy (merge opts-policy {:surface-policy :v1
                                     :climate-at cache-shaped-reader}))
(def real-policy-chunk (run-chunk flat 0 0 flat-policy))
(check "a cache-shaped reader changes the surface, not legacy terrain"
       (not (same-blocks? (run-chunk flat 0 0 opts-policy) real-policy-chunk)))
# Chunk 0 is grid cell (0,0): desert -> sand top, stone subsoil.
(check "a cache-shaped reader resolves the desert column to sand"
       (= world/block-sand (top-at real-policy-chunk 4 4 flat-y)))
(check "a cache-shaped reader resolves the desert subsoil to stone"
       (= world/block-stone (block-at real-policy-chunk 4 (- flat-y 1) 4)))
# Chunk (1,1) is grid cell (1,1): desert again by the grid above, so pick chunk
# (1,0) -- grid (0,1) -- which is taiga -> grass/dirt.
(def taiga-cell-chunk (run-chunk flat 1 0 flat-policy))
(check "a cache-shaped reader resolves a taiga column to grass"
       (= world/block-grass (top-at taiga-cell-chunk 4 4 flat-y)))
(check "a cache-shaped reader resolves a taiga subsoil to dirt"
       (= world/block-dirt (block-at taiga-cell-chunk 4 (- flat-y 1) 4)))
(check "the same reader yields different surfaces in different chunks"
       (not (same-blocks? real-policy-chunk taiga-cell-chunk)))
# A cache that answers :unavailable outside its grid must fall back, not crash.
(defn sparse-cache-reader [wx wz]
  (if (and (<= 0 wx 15) (<= 0 wz 15))
    (ct/sample climate-grid 0 0)
    {:status :unavailable :reason :outside-map}))
(check "an :unavailable cache answer falls back to legacy terrain per column"
       (let [mixed (run-chunk flat 1 0 (merge opts-policy
                                              {:surface-policy :v1
                                               :climate-at sparse-cache-reader}))]
         (and (= world/block-grass (top-at mixed 4 4 flat-y))     # legacy arm
              (zero? (count-of mixed world/block-sand)))))
# And the legacy goldens still hold with the widened gate in place.
(check "the widened sample gate leaves the legacy CRC untouched"
       (= "1bdf8ac5" (crc/crc32-hex (string (run-chunk flat 0 0 opts-clear)))))

# 14. TREES AND HEIGHTS ARE UNTOUCHED. The policy changes MATERIAL only: the wood
# and leaf counts of a decorated chunk must be identical to the legacy chunk's,
# because no trunk moved and no height changed.
(check "a policy leaves the wood count of a decorated chunk unchanged"
       (= (count-of legacy-flat world/block-wood)
          (count-of taiga-chunk world/block-wood)))
(check "a policy leaves the leaf count of a decorated chunk unchanged"
       (= (count-of legacy-flat world/block-leaves)
          (count-of taiga-chunk world/block-leaves)))

# 14. NO HEIGHT RE-SAMPLING FOR MATERIALS. The policy decides MATERIAL from the
# climate reader, so selecting it must not add a single height callback: if it
# did, a policy scene would pay a second sampling pass over the terrain to answer
# a question the reader already answered. This also pins that the existing fill
# loop was extended rather than re-run.
(check "selecting a policy adds no height calls"
       (= (height-call-count opts-policy)
          (height-call-count (merge opts-policy {:surface-policy :v1
                                                 :climate-at (reader-of desert-climate)})))
       (string (height-call-count (merge opts-policy
                                         {:surface-policy :v1
                                          :climate-at (reader-of desert-climate)}))
               " vs " (height-call-count opts-policy)))

#
# --- Result -------------------------------------------------------------
#
(print "")
(if (zero? failures)
  (print "ALL CHECKS PASSED  (0 failures)")
  (do (printf "FAILURES: %d" failures) (os/exit 1)))
