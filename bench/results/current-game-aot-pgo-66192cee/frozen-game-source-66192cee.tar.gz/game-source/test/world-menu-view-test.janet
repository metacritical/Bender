# Front-door menu VIEW: text editing, input translation, and painting.
#
# No window: `rl` is a stub table, which is exactly why the view injects it rather
# than importing it. What is tested here is the part that is easy to get wrong and
# invisible in a screenshot -- that typing reaches the right field, that a key
# becomes the action it claims to be, and that a create request is returned rather
# than performed.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/world-menu-view-test.janet

(import ../src/world-menu :as menu)
(import ../src/world-menu-view :as view)
(import ../src/world-seed :as seed)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))


(def keys {:enter 257 :escape 256 :backspace 259 :up 265 :down 264
             :tab 258 :random 291 :dec 91 :inc 93 :left 263 :right 262})

(defn stub-rl
  ``A raylib stand-in.

  `chars` are the codepoints typed this frame; `pressed` the keycodes. Every draw
  call is recorded rather than performed, so a test can assert that something was
  painted without a GPU.``
  [&opt chars pressed]
  (def drawn @[])
  (def queue (array ;(or chars @[])))
  # `pressed` is keyed by SYMBOL (:enter) and the view asks by KEYCODE, so the
  # translation happens once, here, against the same `keys` table the view uses.
  (def down @{})
  (eachp [name on] (or pressed @{})
    (when on (put down (get keys name) true)))
  @{:chars queue
    :pressed down
    :drawn drawn
    :char-pressed (fn []
                    (if (pos? (length queue))
                      (do (def c (get queue 0)) (array/remove queue 0) c)
                      0))
    :key-pressed? (fn [k] (truthy? (get down k)))
    :draw-text (fn [s x y size colour]
                 (array/push drawn {:text s :x x :y y :size size}))
    :draw-rectangle (fn [& _] (array/push drawn {:rect true}))
    :screen-width (fn [] 1280)
    :screen-height (fn [] 800)
    # The menu centres its buttons and its footing line by measuring them, so a
    # stub without this cannot draw at all. A fixed 7px/char is enough to place
    # text; no test asserts pixel-perfect centring, only that drawing works and
    # that the guard rails hold.
    :measure-text (fn [s size] (* (length (string s)) (math/floor (* size 0.5))))
    # No pointer in the default stub: the menu then reports `:mouse-in?` false
    # and shows keyboard instructions only. That is the path every existing test
    # exercises, and it must keep working untouched.
    :mouse-position nil
    :mouse-pressed? nil})

(def providers
  @[@{:id :procedural :label "Procedural" :available true :reason nil :controls @[]}
    @{:id :learned :label "Learned" :available false
      :reason "backend not installed" :controls @[]}])

(def worlds
  @[@{:id "a" :name "Alpha"} @{:id "b" :name "Bravo"}])

(defn form-state [] (menu/step (menu/state-new providers worlds) [:new]))
(defn load-state [] (menu/step (menu/state-new providers worlds) [:load]))

#
# --- Text editing -------------------------------------------------------
#
(print "\ntext editing:")

(check "typing appends to the field"
       (= "ab" (view/insert-text "a" "b" 10)))
(check "the limit stops further text"
       (= "ab" (view/insert-text "ab" "c" 2)))
(check "backspace removes the last character"
       (= "a" (view/backspace "ab")))
(check "backspace on empty stays empty"
       (= "" (view/backspace "")))
(check "a unicode codepoint is kept whole"
       (= "é" (view/insert-text "" "é" 10)))

#
# --- Input translation --------------------------------------------------
#
(print "\ninput:")

# Typing on the name field must reach the NAME and not the seed: the two fields
# share one key stream, which is where a "why is my seed named Bob" bug lives.
(let [r (view/step (form-state) (stub-rl [66 111 98] @{}) keys :name)]
  (check "typing on the name field lands in the name"
         (= "Bob" ((r :state) :name)))
  (check "and leaves the seed alone"
         (= "" ((r :state) :seed-input)))
  (check "no request is produced by typing"
         (nil? (r :request))))
(let [r (view/step (form-state) (stub-rl [49 50 51] @{}) keys :seed)]
  (check "typing on the seed field lands in the seed"
         (= "123" ((r :state) :seed-input)))
  (check "and turns random off, because a literal was typed"
         (not (truthy? ((r :state) :seed-random)))))

# Escape from a sub-screen goes back rather than quitting: a menu that closes on
# the key a player uses to change their mind is a menu nobody trusts.
(check "escape returns from the form to home"
       (= :home (((view/step (form-state) (stub-rl [] {:escape true}) keys :name)
                  :state) :screen)))
(check "escape on home does not quit unexpectedly"
       (= :home (((view/step (menu/state-new providers worlds)
                             (stub-rl [] {:escape true}) keys :name) :state) :screen)))

#
# --- Focus navigation ---------------------------------------------------
#
(print "\nfocus:")

# FOCUS IS THE WHOLE BUG this round: the seed field could only be focused once it
# already had text, and it could only get text when focused, so a custom seed was
# impossible to type. Focus now advances on Enter and toggles on Tab.
(check "focus starts on the name field"
       (= :name (view/seed-field nil)))
(check "the other field is the seed"
       (= :seed (view/other-focus :name)))
(check "the other field of the seed is the name"
       (= :name (view/other-focus :seed)))

(let [r (view/step (form-state) (stub-rl [] {:enter true}) keys :name)]
  (check "enter on the name field moves to the seed instead of submitting"
         (and (nil? (r :request)) (= :seed (r :focus)))))
# From the seed field, Enter submits.
(let [on-seed (view/step (form-state) (stub-rl [] {:enter true}) keys :name)
      r (view/step (on-seed :state) (stub-rl [] {:enter true}) keys (on-seed :focus))]
  (check "enter on the seed field submits"
         (truthy? (menu/request? (r :request)))))
(check "tab moves from the name field to the seed"
       (= :seed ((view/step (form-state) (stub-rl [] {:tab true}) keys :name)
                 :focus)))
# Tab is SYMMETRIC. The first version toggled the random mode from the seed
# field, which made Tab a one-way door -- name to seed worked, seed to name did
# not -- and gave one key two meanings depending on where the caret was.
(check "tab moves from the seed field to the provider"
       (= :provider ((view/step (form-state) (stub-rl [] {:tab true}) keys :seed)
                     :focus)))
(check "tab never changes the random mode"
       (not (truthy? (((view/step (form-state) (stub-rl [] {:tab true}) keys :seed)
                       :state) :seed-random))))
# The mode has its own key, F2, and it works from either field.
(let [r (view/step (form-state) (stub-rl [] {:random true}) keys :seed)]
  (check "F2 toggles the random seed"
         (truthy? ((r :state) :seed-random)))
  (check "F2 does not move focus"
         (= :seed (r :focus))))
(check "F2 also toggles from the name field"
       (truthy? (((view/step (form-state) (stub-rl [] {:random true}) keys :name)
                  :state) :seed-random)))
# Up/Down also move between the two fields on the form.
(check "down moves focus on the form"
       (= :seed ((view/step (form-state) (stub-rl [] {:down true}) keys :name)
                 :focus)))
(check "up moves focus on the form"
       (= :provider ((view/step (form-state) (stub-rl [] {:up true}) keys :seed)
                     :focus)))

# THE FLOW THIS ENABLES: type a name, Enter, type a custom seed, Enter.
(let [typed-name (view/step (form-state) (stub-rl [86 97 108 101]) keys :name)
      moved (view/step (typed-name :state) (stub-rl [] {:enter true})
                       keys (typed-name :focus))
      typed-seed (view/step (moved :state) (stub-rl [49 50 51])
                            keys (moved :focus))
      submitted (view/step (typed-seed :state) (stub-rl [] {:enter true})
                           keys (typed-seed :focus))]
  (check "a keyboard-only player can set the name"
         (= "Vale" ((typed-name :state) :name)))
  (check "and then reach the seed field"
         (= :seed (moved :focus)))
  (check "and type a custom seed there"
         (= "123" ((typed-seed :state) :seed-input)))
  (check "and submit both"
         (and (menu/request? (submitted :request))
              (= "Vale" ((submitted :request) :name))
              (= "123" ((submitted :request) :seed-input)))))

(check "enter on home with worlds opens the load screen"
       (= :load (((view/step (menu/state-new providers worlds)
                             (stub-rl [] {:enter true}) keys :name) :state) :screen)))
(check "enter on home without worlds opens the new screen"
       (= :new (((view/step (menu/state-new providers @[])
                            (stub-rl [] {:enter true}) keys :name) :state) :screen)))

# Down/up move the selection in the catalog.
(let [r (view/step (load-state) (stub-rl [] {:down true}) keys :name)]
  (check "down selects the first world when none is selected"
         (= "a" ((r :state) :selected-world))))
(let [selected (menu/step (load-state) [:select-world "a"])
      r (view/step selected (stub-rl [] {:down true}) keys :name)]
  (check "down advances the selection"
         (= "b" ((r :state) :selected-world))))
(let [selected (menu/step (load-state) [:select-world "b"])
      r (view/step selected (stub-rl [] {:up true}) keys :name)]
  (check "up retreats the selection"
         (= "a" ((r :state) :selected-world))))
# Compared by FIELD, not by `=`: a Janet table compares by identity, so two
# tables with identical contents are never `=`. This is the third time that has
# caught a test here, so it is worth naming once in a comment.
(check "enter on load yields an open request"
       (let [selected (menu/step (load-state) [:select-world "b"])
             r (view/step selected (stub-rl [] {:enter true}) keys :name)
             req (r :request)]
         (and (menu/request? req)
              (= :open (req :kind))
              (= "b" (req :world)))))



# An unavailable provider must be refused at Enter, with its own reason.
(let [blocked (menu/step (form-state) [:change-provider :learned])
      # Two Enters: the first moves focus to the seed, the second submits.
      first-enter (view/step blocked (stub-rl [] {:enter true}) keys :name)
      r (view/step (first-enter :state) (stub-rl [] {:enter true})
                   keys (first-enter :focus))]
  (check "enter with an unavailable provider is refused, not performed"
         (and (indexed? (r :request)) (= :refuse (get (r :request) 0))))
  (check "the refusal repeats the provider's reason"
         (= "backend not installed" (get (r :request) 1))))

#
# --- Painting -----------------------------------------------------------
#
(print "\ndrawing:")

# The painter must not throw on any screen, and must actually draw something --
# a view that renders nothing is indistinguishable from a hang.
(each screen [:home :new :load :error]
  (def state (menu/step (menu/state-new providers worlds)
                        (case screen
                          :home [:new] :new [:new] :load [:load]
                          :error [:update-setting :nope 1])))
  (def placed (if (= screen :error) state
                  (if (= screen :home) (menu/state-new providers worlds) state)))
  (def rl (stub-rl))
  (def ok (try (do (view/draw placed rl :name) true) ([e] false)))
  (check (string "drawing " screen " does not throw") ok)
  (check (string "drawing " screen " paints something")
         (pos? (length (rl :drawn)))))

# The unavailable provider's reason must reach the screen: the honesty rule is
# only real if the view renders it.
(let [rl (stub-rl)]
  (view/draw (menu/step (form-state) [:change-provider :learned]) rl :name)
  (def texts (map |($ :text) (filter |(has-key? $ :text) (rl :drawn))))
  (check "the unavailable provider's reason is rendered"
         (pos? (length (filter |(not (nil? (string/find "backend not installed" $)))
                               texts)))))
# And the name field shows the caret only when it is the focused one.
(let [rl (stub-rl)]
  (view/draw (menu/step (form-state) [:edit-name "Vale"]) rl :name)
  (def texts (map |($ :text) (filter |(has-key? $ :text) (rl :drawn))))
  (check "the focused field shows a caret"
         (pos? (length (filter |(not (nil? (string/find "Vale_" $))) texts)))))
(let [rl (stub-rl)]
  (view/draw (menu/step (form-state) [:edit-name "Vale"]) rl :seed)
  (def texts (map |($ :text) (filter |(has-key? $ :text) (rl :drawn))))
  (check "an unfocused field shows no caret"
         (empty? (filter |(not (nil? (string/find "Vale_" $))) texts))))

#
# --- Provider controls --------------------------------------------------
#
(print "\nprovider controls:")

# The registry's vocabulary is `:type :integer|:number`; the menu's is
# `:kind :int|:number|:choice`. A translation bug here means a control that never
# validates, so both directions are pinned.
(check "an integer control translates to :int"
       (= :int ((view/control-from-provider
                  @{:id :sea-level :label "Sea" :type :integer
                    :min 0 :max 128 :default 28}) :kind)))
(check "a number control translates to :number"
       (= :number ((view/control-from-provider
                     @{:id :height-scale :label "Scale" :type :number
                       :min 0.5 :max 2.0 :default 1.0}) :kind)))
# An unrecognised type is DROPPED, not guessed at: a control the menu cannot
# validate is one it must not offer.
(check "an unknown control type is dropped"
       (nil? (view/control-from-provider
               @{:id :weird :type :matrix :min 0 :max 1})))

(def registry
  @[@{:id :procedural :label "Native procedural" :available true
      :controls @[@{:id :sea-level :label "Sea level" :type :integer
                    :min 0 :max 128 :default 28}]}
    @{:id :terrain-diffusion-native :label "Terrain Diffusion (native)"
      :available false :version 0 :controls @[]
      :reason "no native runtime"}])
(def from-reg (view/providers-from-registry registry))
(check "both registry providers reach the menu"
       (= 2 (length from-reg)))
(check "the unavailable provider keeps ITS OWN reason"
       (= "no native runtime"
          ((first (filter |(= :terrain-diffusion-native ($ :id)) from-reg)) :reason)))
(check "an available provider's controls are translated"
       (= 1 (length ((first (filter |(= :procedural ($ :id)) from-reg)) :controls))))

# Focus cycles name -> seed -> each control -> name, so every editable thing is
# reachable and nothing is unreachable.
(def control-row @[@{:id :sea-level}])
(check "focus starts at the name"
       (= :name (view/cycle-focus nil control-row)))
(check "the seed follows the name"
       (= :seed (view/cycle-focus :name control-row)))
(check "the provider follows the seed"
       (= :provider (view/cycle-focus :seed control-row)))
(check "the first control follows the provider"
       (= :sea-level (view/cycle-focus :provider control-row)))
(check "and the name follows the last control"
       (= :name (view/cycle-focus :sea-level control-row)))
(check "with no controls the provider leads straight back to the name"
       (and (= :provider (view/cycle-focus :seed @[]))
            (= :name (view/cycle-focus :provider @[]))
            (= :seed (view/cycle-focus :name @[]))))
(check "only the two fields count as text fields"
       (and (view/field? :name) (view/field? :seed)
            (not (view/field? :sea-level))))

# `]` raises the focused control by ITS declared step, and clamps at the bound
# rather than producing an error screen.
(defn form-with-controls []
  (menu/step (menu/state-new from-reg @[]) [:new]))
(defn press [st focus key]
  (view/step st (stub-rl [] {key true}) keys focus))
(let [st (form-with-controls)
      r (press st :sea-level :inc)]
  (check "the focused control can be raised"
         (= 29 (((r :state) :settings) :sea-level)))
  (check "raising keeps the form, not an error"
         (= :new ((r :state) :screen))))
(let [st (form-with-controls)
      r (press st :sea-level :dec)]
  (check "the focused control can be lowered"
         (= 27 (((r :state) :settings) :sea-level))))
# Clamping: from the declared maximum, `]` stays there instead of refusing.
(let [st (menu/step (form-with-controls) [:update-setting :sea-level 128])
      r (press st :sea-level :inc)]
  (check "raising past the maximum clamps"
         (= 128 (((r :state) :settings) :sea-level)))
  (check "and does not become an error"
         (= :new ((r :state) :screen))))
(let [st (menu/step (form-with-controls) [:update-setting :sea-level 0])
      r (press st :sea-level :dec)]
  (check "lowering past the minimum clamps"
         (= 0 (((r :state) :settings) :sea-level))))
# A bracket press on a TEXT field must not touch settings.
(let [r (press (form-with-controls) :name :inc)]
  (check "brackets do nothing while a text field has focus"
         (= 28 (((r :state) :settings) :sea-level))))

#
# --- Provider selection --------------------------------------------------
#
(print "\nprovider selection:")

# Two providers, one available and one not, so the cycle has somewhere to go and
# an unavailable choice can still be READ.
(def two-providers
  (view/providers-from-registry
    @[@{:id :terrain-diffusion-python
        :label "Terrain Diffusion - Python (temporary)" :available true
        :controls @[@{:id :size :label "Map size" :type :integer
                      :min 16 :max 512 :default 128}]}
      @{:id :terrain-diffusion-native :label "Terrain Diffusion (native)"
        :available false :controls @[] :reason "pipeline not verified"}]))
(defn two-form [] (menu/step (menu/state-new two-providers @[]) [:new]))

# The provider sits in the focus cycle, BEFORE the controls, because choosing a
# provider decides which controls exist.
(check "focus reaches the provider after the seed"
       (= :provider (view/cycle-focus :seed @[])))
(check "the first control follows the provider"
       (= :size (view/cycle-focus :provider @[@{:id :size}])))
(check "focus returns to the name after the last control"
       (= :name (view/cycle-focus :size @[@{:id :size}])))

# Left/right change provider while it has focus.
(let [st (two-form)
      r (view/step st (stub-rl [] {:right true}) keys :provider)]
  (check "right selects the next provider"
         (= :terrain-diffusion-native ((r :state) :provider)))
  (check "focus stays on the provider after a selection"
         (= :provider (r :focus))))
(let [st (menu/step (two-form) [:change-provider :terrain-diffusion-native])
      r (view/step st (stub-rl [] {:left true}) keys :provider)]
  (check "left selects the previous provider"
         (= :terrain-diffusion-python ((r :state) :provider))))
# Left/right do nothing when the provider is not focused: a key that silently
# changes a provider from the name field would be a surprise edit.
(let [r (view/step (two-form) (stub-rl [] {:right true}) keys :name)]
  (check "left/right are inert off the provider field"
         (= :terrain-diffusion-python ((r :state) :provider))))
# Selection wraps, so both providers are reachable from either direction.
(let [st (menu/step (two-form) [:change-provider :terrain-diffusion-native])
      r (view/step st (stub-rl [] {:right true}) keys :provider)]
  (check "selection wraps around the list"
         (= :terrain-diffusion-python ((r :state) :provider))))

# THE LEAK RULE. Changing provider must discard the previous provider's settings,
# or a world would be generated with values its screen never showed.
# Move OFF the control-declaring provider and back, then check the size returned.
# (Pressing :left while already on the first provider wraps to the LAST one, which
# declares no controls -- an empty settings table is correct there, not a failure.)
(let [there (menu/step (two-form) [:change-provider :terrain-diffusion-native])
      back (menu/step there [:change-provider :terrain-diffusion-python])]
  (check "returning to a provider restores ITS defaults, not the previous ones"
         (= 128 ((back :settings) :size))))
(let [there (menu/step (two-form) [:change-provider :terrain-diffusion-native])]
  (check "a provider with no controls yields empty settings"
         (zero? (length (there :settings)))))
# An unavailable provider can be selected and its reason read, but nothing can be
# created with it.
(let [unavailable (menu/step (two-form) [:change-provider :terrain-diffusion-native])]
  (check "an unavailable provider's reason is visible"
         (= "pipeline not verified"
            ((first (filter |(= :terrain-diffusion-native ($ :id))
                            (menu/provider-rows unavailable))) :reason)))
  (check "creating with it is refused"
         (and (indexed? (menu/create-request unavailable))
              (= :refuse (get (menu/create-request unavailable) 0)))))

#
# --- Catalogue adapter --------------------------------------------------
#
(print "\ncatalogue adapter:")

# The catalogue reports `{:id :status :manifest}`; the menu needs `{:id :name}`.
# The adapter lives in the view because it is a presentation translation, and it
# must DROP what cannot be loaded rather than show it as openable.
(def entries
  @[@{:id "aaa" :status :ready :manifest @{:name "Zulu" :provider :procedural
                                              :seed @{:value 7}}}
    @{:id "bbb" :status :incompatible :reason "corrupt manifest"}
    @{:id "ccc" :status :ready :manifest @{:name "Alpha" :provider :procedural
                                              :seed @{:value 9}}}])
(def rows (view/worlds-of entries))
(check "incompatible slots are dropped from the list"
       (= 2 (length rows)))
(check "a ready slot is carried through with its name"
       (truthy? (first (filter |(= "Alpha" ($ :name)) rows))))
(check "the catalogue id is preserved"
       (truthy? (first (filter |(= "ccc" ($ :id)) rows))))
(check "the seed value is lifted out of its record"
       (= 9 ((first (filter |(= "ccc" ($ :id)) rows)) :seed)))
# Sorted by name, so the list does not reshuffle between launches.
(check "rows are sorted by name"
       (= "Alpha" ((first rows) :name)))

#
# --- Unicode text input ------------------------------------------------
#
# `string/from-bytes` is a BYTE encoder, not a codepoint encoder: it keeps only
# the low 8 bits, so it turned every codepoint above U+00FF into one stray byte.
# These checks pin the real UTF-8 encoding, the scalar-aware backspace, and the
# byte-measured limit.

(check "ascii encodes to one byte" (= "a" (view/utf8-encode 97)))
(check "2-byte scalar encodes to 2 bytes"
       (= "\xC3\xA9" (view/utf8-encode 0xE9)))
(check "3-byte scalar encodes to 3 bytes"
       (= "\xCE\xA9" (view/utf8-encode 0x3A9)))
# U+1F98B BUTTERFLY: the exact character that was silently dropped before.
(check "4-byte scalar encodes to 4 bytes"
       (= "\xF0\x9F\xA6\x8B" (view/utf8-encode 0x1F98B)))
(check "butterfly round-trips through the encoder"
       (= "🦋" (view/utf8-encode 0x1F98B)))
(check "greek letter round-trips" (= "Ω" (view/utf8-encode 0x3A9)))
(check "accented latin round-trips" (= "é" (view/utf8-encode 0xE9)))
# Boundaries of each encoding length.
(check "U+007F is one byte" (= 1 (length (view/utf8-encode 0x7F))))
(check "U+0080 is two bytes" (= 2 (length (view/utf8-encode 0x80))))
(check "U+07FF is two bytes" (= 2 (length (view/utf8-encode 0x7FF))))
(check "U+0800 is three bytes" (= 3 (length (view/utf8-encode 0x800))))
(check "U+FFFF is three bytes" (= 3 (length (view/utf8-encode 0xFFFF))))
(check "U+10000 is four bytes" (= 4 (length (view/utf8-encode 0x10000))))
(check "U+10FFFF is four bytes" (= 4 (length (view/utf8-encode 0x10FFFF))))

# Surrogates are not UTF-8 and must be refused, not encoded.
(check "surrogate D800 is refused" (nil? (view/utf8-encode 0xD800)))
(check "surrogate DBFF is refused" (nil? (view/utf8-encode 0xDBFF)))
(check "surrogate DC00 is refused" (nil? (view/utf8-encode 0xDC00)))
(check "surrogate DFFF is refused" (nil? (view/utf8-encode 0xDFFF)))
(check "U+D7FF is still valid" (truthy? (view/utf8-encode 0xD7FF)))
(check "U+E000 is still valid" (truthy? (view/utf8-encode 0xE000)))
(check "above U+10FFFF is refused" (nil? (view/utf8-encode 0x110000)))
(check "negative is refused" (nil? (view/utf8-encode -1)))
(check "nil is refused" (nil? (view/utf8-encode nil)))

# Encoder output is always well-formed, which is what the seed hasher needs.
(each code [0x41 0xE9 0x3A9 0x1F98B 0x10FFFF 0x7FF 0x800]
  (check (string "encoded U+" (string/format "%X" code) " is valid UTF-8")
         (view/utf8-valid? (view/utf8-encode code))))

# Validation itself: truncated and overlong sequences must be rejected.
(check "bare ascii is valid" (view/utf8-valid? "abc"))
(check "valid mixed text" (view/utf8-valid? "a🦋Ωb"))
(check "truncated 4-byte sequence is invalid"
       (not (view/utf8-valid? "\xF0\x9F\xA6")))
(check "lone continuation byte is invalid" (not (view/utf8-valid? "\x8B")))
(check "lone lead byte is invalid" (not (view/utf8-valid? "\xF0")))
(check "overlong encoding is invalid" (not (view/utf8-valid? "\xC0\xAF")))
(check "surrogate encoded as CESU is invalid"
       (not (view/utf8-valid? "\xED\xA0\x80")))
(check "value above U+10FFFF encoded is invalid"
       (not (view/utf8-valid? "\xF4\x90\x80\x80")))
(check "empty text is valid" (view/utf8-valid? ""))

# Backspace removes a whole scalar, never a byte.
(check "backspace on ascii" (= "ab" (view/backspace "abc")))
(check "backspace removes the whole butterfly"
       (= "a" (view/backspace "a🦋")))
(check "backspace leaves the text before a butterfly intact"
       (= "a🦋" (view/backspace "a🦋b")))
(check "backspace on greek" (= "a" (view/backspace "aΩ")))
# The old implementation sliced one byte, leaving invalid UTF-8 behind.
(check "repeated backspace stays valid"
       (view/utf8-valid? (view/backspace (view/backspace "a🦋b"))))
(check "backspace to empty is valid"
       (view/utf8-valid? (view/backspace "🦋")))
(check "backspace on empty is empty" (= "" (view/backspace "")))
(check "backspace on nil is empty" (= "" (view/backspace nil)))
# Deleting every scalar one at a time never yields invalid UTF-8.
(var acc "a🦋Ωé!")
(while (not (empty? acc))
  (set acc (view/backspace acc))
  (check "each backspace step keeps UTF-8 valid" (view/utf8-valid? acc)))
(check "backspacing everything empties the field" (= "" acc))

# The limit is measured in BYTES after the append, and cannot split a character.
(check "insert into empty" (= "a" (view/insert-text "" "a" 8)))
(check "insert appends" (= "ab" (view/insert-text "a" "b" 8)))
# A 4-byte character needs 4 bytes of room; 3 must refuse it whole.
(check "a butterfly is refused when 3 bytes remain"
       (= "abc" (view/insert-text "abc" "🦋" 6)))
(check "a butterfly fits when 4 bytes remain"
       (= "ab🦋" (view/insert-text "ab" "🦋" 6)))
# Never leaves a partial character behind.
(check "a refused insert leaves valid UTF-8"
       (view/utf8-valid? (view/insert-text "abc" "🦋" 6)))
(check "the limit is not exceeded by one character"
       (<= (length (view/insert-text "ab" "🦋" 6)) 6))
(check "exactly at the limit still appends nothing more"
       (= "🦋" (view/insert-text "🦋" "x" 4)))
(check "insert of empty leaves the text alone" (= "abc" (view/insert-text "abc" "" 8)))
(check "insert refuses invalid UTF-8"
       (= "abc" (view/insert-text "abc" "\xF0\x9F" 99)))
(check "nil text starts empty" (= "a" (view/insert-text nil "a" 8)))
(check "max seed bytes allows a real custom seed" (> view/max-seed 32))
(check "max seed holds several 4-byte characters"
       (>= view/max-seed (* 4 8)))
# The hard ceiling applies even when a caller passes a larger limit.
(check "an oversized limit is clamped"
       (<= (length (view/insert-text
                     "" (string/repeat "a" (* 8 view/max-input-bytes))
                     (* 4 view/max-input-bytes)))
           view/max-input-bytes))

# A codepoint drained from raylib survives as the character the user typed.
(defn typed-seed [codes]
  (def r (view/step (form-state) (stub-rl codes @{}) keys :seed))
  ((r :state) :seed-input))
(check "typing a butterfly reaches the seed field"
       (= "🦋" (typed-seed [0x1F98B])))
(check "typing greek reaches the seed field"
       (= "Ω" (typed-seed [0x3A9])))
(check "typing mixed text reaches the seed field"
       (= "a🦋Ω" (typed-seed [97 0x1F98B 0x3A9])))
(check "typed text is valid UTF-8" (view/utf8-valid? (typed-seed [0x1F98B])))
# Surrogates and control characters are skipped, not replaced.
(check "a surrogate is skipped entirely" (= "" (typed-seed [0xD800])))
(check "a surrogate does not disturb its neighbours"
       (= "ab" (typed-seed [97 0xD800 98])))
(check "control characters are skipped" (= "a" (typed-seed [1 97 31])))
# A custom Unicode seed still parses through the seed contract.
(def unicode-parsed (seed/parse-seed-input (typed-seed [0x1F98B])))
(check "a Unicode seed parses"
       (and (= 1 (unicode-parsed :version))
            (= :text (unicode-parsed :kind))))
(check "a Unicode seed resolves to the decimal its value has"
       (= (string (unicode-parsed :value)) (unicode-parsed :canonical)))
(check "a Unicode seed resolves to a 31-bit value"
       (let [v (unicode-parsed :value)]
         (and (number? v) (<= 0 v) (<= v 2147483647))))
# Backspacing a typed butterfly must leave a field the parser still accepts.
(def after-backspace
  (let [r (view/step (form-state) (stub-rl [97 0x1F98B] @{}) keys :seed)]
    (view/backspace ((r :state) :seed-input))))
(check "backspacing a typed butterfly leaves the preceding text"
       (= "a" after-backspace))
(check "the seed still parses after a Unicode backspace"
       (= :text ((seed/parse-seed-input after-backspace) :kind)))

#
# --- Reaching the form without a keypress -------------------------------
#
(print "\nforced screen:")

# `--menu-screen new` used to write `:screen` directly, which left the provider
# unset and the settings empty -- a state a real menu can never be in, and the
# reason a QA capture showed a title over controls with no values. The QA entry
# point must take the SAME transition a keypress takes.
(def home (menu/state-new providers worlds))
(def formed (menu/step home [:new]))
(check "the new screen can be reached through its transition"
       (= :new (formed :screen)))
(check "it arrives with a provider chosen"
       (not (nil? (formed :provider))))
# A provider that declares no controls correctly yields EMPTY settings, so the
# property is "settings is a table, never nil" -- asserting it were non-empty
# would demand a control the provider never declared.
(check "it arrives with a settings table, not nil"
       (table? (formed :settings)))
# A provider that DOES declare controls arrives with their defaults filled in.
# NB: this file binds `keys` to the keycode table, which SHADOWS the builtin
# `keys` function -- so settings are inspected field by field here rather than
# through `(keys ...)`, which would try to index that table with a keyword.
(def with-controls (menu/step (menu/state-new from-reg @[]) [:new]))
(check "declared controls arrive with their declared default"
       (= 28 ((with-controls :settings) :sea-level)))
(check "the name field starts empty rather than nil"
       (= "" (formed :name)))
(check "the seed field starts empty rather than nil"
       (= "" (formed :seed-input)))
# And the screen actually paints text: a capture of a blank frame is indistinguishable
# from a crash, so the drawing is asserted rather than assumed.
(let [rl (stub-rl)]
  (view/draw (menu/step (menu/state-new from-reg @[]) [:new]) rl :name)
  (def texts (map |($ :text) (filter |(has-key? $ :text) (rl :drawn))))
  (check "the form paints its title"
         (pos? (length (filter |(= "New world" $) texts))))
  (check "the form paints a field label"
         (pos? (length (filter |(= "Name" $) texts))))
  (check "the form paints its controls when the provider declares them"
         (pos? (length (filter |(= "Generation" $) texts)))))


#
# --- Injected artwork (shared presenter, injected callback) -------------
#
# The menu must not know what the art IS. It asks a callback to fill the frame
# and then guarantees its own text is readable over whatever came back. These
# pin that contract without a GPU: the callback is a plain function, and the
# assertions are about WHEN it is called and what the menu does afterwards.
#
(print "\ninjected artwork:")

(defn art-recorder
  "A stand-in presenter: records each call and paints one rect."
  []
  (def calls @[])
  @{:calls calls
    :fn (fn [w h] (array/push calls {:w w :h h}))})

(def rec (art-recorder))
(def st (menu/state-new providers worlds))
(def rl-cb (stub-rl [] @{}))
(view/draw st rl-cb :name nil (rec :fn))

(check "the background callback is invoked once per draw"
       (= 1 (length (rec :calls))) (string (length (rec :calls))))
(check "it receives the framebuffer size"
       (= {:w 1280 :h 800} (get (rec :calls) 0)))
# Order matters: the scrim must land AFTER the callback's art, or the text is
# painted on unscrimmed artwork and becomes unreadable over a bright sky.
(check "the scrim is painted after the artwork"
       (and (> (length (rl-cb :drawn)) 0)
            (get (get (rl-cb :drawn) 0) :rect)))
(check "text is painted after the scrim"
       (pos? (length (filter |(get $ :text) (rl-cb :drawn)))))

# No callback: no scrim, and the menu still draws. This is the headless and
# no-assets path, and it must not depend on art existing.
(def rl-plain (stub-rl [] @{}))
(view/draw st rl-plain :name nil)
(check "without a callback the menu still paints text"
       (pos? (length (filter |(get $ :text) (rl-plain :drawn)))))

# run-menu! threads the same callback through its loop, so the menu and the
# loading screen share one presenter rather than starting a second one.
(def rec2 (art-recorder))
(defn loop-fns
  "run-menu! needs the adapter plus the four frame functions, named explicitly."
  [stub]
  @{:measure-text (stub :measure-text)
    :char-pressed (stub :char-pressed)
    :key-pressed? (stub :key-pressed?)
    :draw-text (stub :draw-text)
    :draw-rectangle (stub :draw-rectangle)
    :screen-width (stub :screen-width)
    :screen-height (stub :screen-height)
    :begin-drawing (fn [] nil)
    :end-drawing (fn [] nil)
    :clear-background (fn [c] nil)
    :window-should-close (fn [] false)})
(def looped (view/run-menu! (loop-fns (stub-rl [] @{}))
                            st keys 2 nil (rec2 :fn)))
(check "run-menu! invokes the background callback on each frame"
       (= 2 (length (rec2 :calls))) (string (length (rec2 :calls))))

# The scrim alpha must keep the dim grey legible over the worst case a photo
# can present: a pure white sky.
(defn- srgb-lin [c]
  (def v (/ c 255))
  (if (<= v 0.03928) (/ v 12.92) (math/pow (/ (+ v 0.055) 1.055) 2.4)))
(defn- lum [rgb]
  (+ (* 0.2126 (srgb-lin (get rgb 0))) (* 0.7152 (srgb-lin (get rgb 1)))
     (* 0.0722 (srgb-lin (get rgb 2)))))
(defn- contrast [fg bg]
  (def a (lum fg)) (def b (lum bg))
  (/ (+ (max a b) 0.05) (+ (min a b) 0.05)))
(def scrim-alpha (get (view/palette :scrim) 3))
(def worst-bg
  (let [f (/ scrim-alpha 255)]
    (tuple (* 255 (- 1 f)) (* 255 (- 1 f)) (* 255 (- 1 f)))))
(check "dim menu text clears WCAG AA over a white sky"
       (>= (contrast [138 148 166] worst-bg) 4.5)
       (string/format "%.2f" (contrast [138 148 166] worst-bg)))
(check "body text clears AA over a white sky"
       (>= (contrast [230 234 242] worst-bg) 4.5))
# 6.95 rather than 7.0: the computed ratio lands on 7.00 to two decimals, and
# an exact-boundary assert on a floating-point ratio is a coin flip. AAA is the
# intent; this pins "did not regress below it", not the last bit of the mantissa.
(check "the accent clears AAA over a white sky"
       (>= (contrast [96 186 255] worst-bg) 6.95)
       (string/format "%.3f" (contrast [96 186 255] worst-bg)))


#
# --- Home layout: poster art, stone buttons, no full wash ----------------
#
(print "\nhome layout:")

(defn texts-of [rl] (map |(get $ :text) (filter |(get $ :text) (rl :drawn))))
(defn rects-of [rl] (length (filter |(get $ :rect) (rl :drawn))))

# Home shows the artwork. A full-frame scrim over it would turn a designed
# poster into a dark rectangle, which is the failure this layout exists to
# avoid -- so the veil is a band, not the frame.
(def art-calls @[])
(def home-rl (stub-rl [] @{}))
(view/draw (menu/state-new providers @[]) home-rl :name nil
           (fn [w h] (array/push art-calls [w h])))
(check "home invokes the artwork callback"
       (= 1 (length art-calls)))
(check "home still paints text over it"
       (pos? (length (texts-of home-rl))))

# Both actions are always offered. Load is VISIBLE with no saves, and explains
# itself -- a hidden button reads as a missing feature.
(def home-texts (texts-of home-rl))
(check "home shows a New Game button"
       (some |(string/find "New Game" $) home-texts))
(check "home shows a Load Game button even with no saves"
       (some |(string/find "Load Game" $) home-texts))
(check "and explains why Load is empty"
       (some |(string/find "No saved worlds" $) home-texts))

# With saves present the explanation must go away, or it becomes a lie.
(def with-world (menu/state-new providers @[@{:id "a" :name "Alpha"}]))
(def saved-rl (stub-rl [] @{}))
(view/draw with-world saved-rl :name nil nil)
(def saved-texts (texts-of saved-rl))
(check "with saves the empty-list explanation is not shown"
       (not (some |(string/find "No saved worlds" $) saved-texts)))
(check "with saves Load Game is still shown"
       (some |(string/find "Load Game" $) saved-texts))

# The forms may dim the whole frame: on :new the artwork has no logo left to
# protect because the form is the subject.
(def form-rl (stub-rl [] @{}))
(view/draw (form-state) form-rl :name nil (fn [w h] nil))
(check "the new form paints over its own dim"
       (pos? (rects-of form-rl)))


#
# --- Mouse: optional, and honest when absent ----------------------------
#
(print "\npointer:")

# With no pointer injected the instructions must not mention clicking. A build
# that cannot handle a click must not advertise one.
(def no-mouse (stub-rl [] @{}))
(view/draw (menu/state-new providers @[]) no-mouse :name nil nil)
(def no-mouse-texts (map |(get $ :text) (filter |(get $ :text) (no-mouse :drawn))))
(check "without a pointer the footer says Enter, not Click"
       (and (some |(string/find "Enter" $) no-mouse-texts)
            (not (some |(string/find "Click" $) no-mouse-texts))))

# With a pointer injected, clicking New Game must produce the same request the
# keyboard would -- the button has to be real, not decoration.
(defn mouse-stub [pos click?]
  (def s (stub-rl [] @{}))
  (put s :mouse-position (fn [] pos))
  (put s :mouse-pressed? (fn [b] click?))
  s)

# Home buttons sit at x 490..790 (300 wide, centred in 1280) at 43% and 55%.
(def click-pos [640 350])
(def clicked (view/run-menu!
               (merge (loop-fns (mouse-stub click-pos true))
                      {:mouse-position (fn [] click-pos)
                       :mouse-pressed? (fn [b] true)})
               (menu/state-new providers @[]) keys 3 nil nil))
(check "clicking New Game reaches the new-world screen"
       (and clicked (= :new ((clicked :state) :screen)))
       (string (clicked :state)))

# A click nowhere near a button must not open anything.
(def miss (view/run-menu!
            (merge (loop-fns (mouse-stub [5 5] true))
                   {:mouse-position (fn [] [5 5])
                    :mouse-pressed? (fn [b] true)})
            (menu/state-new providers @[]) keys 2 nil nil))
(check "a click outside the buttons opens nothing"
       (or (nil? miss) (not= :new ((miss :state) :screen))))


#
# --- Degraded renderers: a caller that injected less -------------------
#
# `main` hands the view a fixed set of functions. When the view starts needing
# one that is not in that set, the shipped build crashes on the FIRST frame that
# reaches it -- and a test using its own richer stub never sees it. These draw
# with exactly the fns `main` injects, so a newly required function is caught
# here rather than by a runtime nil.
#
(print "\ndegraded renderers:")

(defn main-fns
  "The exact surface main.janet injects into run-menu!. No more, no less."
  []
  @{:char-pressed (fn [] 0)
    :key-pressed? (fn [k] false)
    :draw-text (fn [s x y size colour] nil)
    :draw-rectangle (fn [& _] nil)
    :screen-width (fn [] 1280)
    :screen-height (fn [] 800)})

(check "home draws with only the functions main injects"
       (do (view/draw (menu/state-new providers @[]) (main-fns) :name nil nil)
           true))
(check "new form draws with only what main injects"
       (do (view/draw (form-state) (main-fns) :name nil nil) true))
(check "load form draws with only what main injects"
       (do (view/draw (load-state) (main-fns) :name nil nil) true))

# A table with NOTHING but the bare minimum must not crash either: measurement
# falls back to an estimate rather than calling nil.
(check "drawing survives an empty rl table"
       (do (view/draw (menu/state-new providers @[])
                      @{:draw-text (fn [& _] nil)
                        :draw-rectangle (fn [& _] nil)
                        :screen-width (fn [] 1280)
                        :screen-height (fn [] 800)}
                      :name nil nil)
           true))


#
# --- stone-button arity ------------------------------------------------
#
# The native build reported `stone-button called with 2, expected 3`. Both call
# sites in the source pass three, so the failure came from an older compiled
# tree -- but a signature that CRASHES the whole frame because one argument was
# omitted is the wrong shape for a painter. `action` is optional now, and these
# pin all three arities so the native path has nothing left to disagree about.
#
(print "\nbutton arity:")

# Draw each arity through the real draw path and a minimal stub.
(defn draw-with [state]
  (def rl @{:measure-text (fn [s size] 10)
            :draw-text (fn [& _] nil)
            :draw-rectangle (fn [& _] nil)
            :screen-width (fn [] 1280)
            :screen-height (fn [] 800)})
  (view/draw state rl :name nil nil))

(check "home draws with the shipped 3-argument buttons"
       (do (draw-with (menu/state-new providers @[])) true))
(check "home draws with no saves and still shows both actions"
       (let [drawn @[]
             rl @{:measure-text (fn [s size] 10)
                  :draw-text (fn [s x y sz c] (array/push drawn s))
                  :draw-rectangle (fn [& _] nil)
                  :screen-width (fn [] 1280)
                  :screen-height (fn [] 800)}]
         (view/draw (menu/state-new providers @[]) rl :name nil nil)
         (and (some |(string/find "New Game" $) drawn)
              (some |(string/find "Load Game" $) drawn)
              (some |(string/find "No saved worlds" $) drawn))))
(check "home draws with saves and drops the empty explanation"
       (let [drawn @[]
             rl @{:measure-text (fn [s size] 10)
                  :draw-text (fn [s x y sz c] (array/push drawn s))
                  :draw-rectangle (fn [& _] nil)
                  :screen-width (fn [] 1280)
                  :screen-height (fn [] 800)}]
         (view/draw (menu/state-new providers @[@{:id "a" :name "Alpha"}])
                    rl :name nil nil)
         (and (some |(string/find "Load Game" $) drawn)
              (not (some |(string/find "No saved worlds" $) drawn)))))

#
# --- Settings version through the adapter -------------------------------
#
# The adapter decides which settings contract a row advertises, and the FIRST
# requirement is that adding that choice did not change what an existing caller
# gets: no version argument still means version 1 with the v1 control list.
#
(print "\nsettings version adapter:")

(def versioned-registry
  @[@{:id :procedural :label "Native procedural" :available true :version 1
      :controls @[@{:id :sea-level :label "Sea level" :type :integer
                    :min 0 :max 128 :default 28}
                  @{:id :forest-density :label "Forest" :type :integer
                    :min 0 :max 100 :default 0}]
      :settings-versions [1 2]
      :controls-v2 @[@{:id :sea-level :label "Sea level" :type :integer
                       :min 0 :max 128 :default 28}
                     @{:id :forest-density :label "Forest" :type :integer
                       :min 0 :max 100 :default 0}
                     @{:id :clearing-density :label "Clearings" :type :integer
                       :min 0 :max 100 :default 0}]}
    @{:id :terrain-diffusion-python
      :label "Terrain Diffusion - Python (temporary)" :available false
      :reason "not verified"
      :controls @[@{:id :size :label "Map size" :type :integer
                    :min 16 :max 512 :default 128}]}])

# The default call is the compatibility contract.
(def default-rows (view/providers-from-registry versioned-registry))
(check "the default call still yields the v1 control list"
       (= 2 (length ((first default-rows) :controls))))
(check "the default call reports settings version 1"
       (= 1 ((first default-rows) :settings-version)))
(check "the default call does not offer a clearing control"
       (not (some |(= :clearing-density ($ :id)) ((first default-rows) :controls))))

# Explicit v2 is what the parent's adapter will pass.
(def v2-rows (view/providers-from-registry versioned-registry 2))
(check "an explicit v2 call yields the five-control list"
       (= 3 (length ((first v2-rows) :controls))))
(check "an explicit v2 call reports settings version 2"
       (= 2 ((first v2-rows) :settings-version)))
(check "the fifth control reaches the menu with its bounds"
       (let [c (first (filter |(= :clearing-density ($ :id)) ((first v2-rows) :controls)))]
         (and c (= :int (c :kind)) (= 0 (c :min)) (= 100 (c :max)) (= 0 (c :default)))))
# A provider that declares no v2 stays v1 even when the caller asks for v2, so the
# menu can never show a contract that provider would refuse.
(def py-row (first (filter |(= :terrain-diffusion-python ($ :id)) v2-rows)))
(check "a provider without a v2 list stays at version 1"
       (= 1 (py-row :settings-version)))
(check "a provider without a v2 list keeps its own control count"
       (= 1 (length (py-row :controls))))

# THE PREFERRED FORM IS A MAP, and its whole point is that a MIXED registry works:
# asking for v2 on a provider that does not have it must fall back to that
# provider's declared version rather than raising. A single scalar would have to
# guess which provider it means.
(def map-rows (view/providers-from-registry versioned-registry {:procedural 2}))
(check "a map override lifts only the named provider"
       (and (= 2 ((first (filter |(= :procedural ($ :id)) map-rows)) :settings-version))
            (= 1 ((first (filter |(= :terrain-diffusion-python ($ :id)) map-rows))
                  :settings-version))))
(check "a map override leaves an unnamed provider's controls alone"
       (= 1 (length ((first (filter |(= :terrain-diffusion-python ($ :id)) map-rows))
                     :controls))))
# An explicit request for an undeclared version FALLS BACK, it does not error.
(check "requesting v2 for a provider without it falls back instead of failing"
       (= 1 ((first (filter |(= :terrain-diffusion-python ($ :id))
                            (view/providers-from-registry
                              versioned-registry {:terrain-diffusion-python 2})))
             :settings-version)))
# The scalar form stays supported for a single-provider registry, and it must not
# lift an unrelated provider either.
(check "the scalar form does not lift an unrelated provider"
       (= 1 ((first (filter |(= :terrain-diffusion-python ($ :id))
                            (view/providers-from-registry versioned-registry 2)))
             :settings-version)))

# An EMPTY override is the same as no preference, so a caller may always pass a map.
(def empty-map-rows (view/providers-from-registry versioned-registry {}))
(check "an empty preference map equals no preference"
       (and (= 1 ((first empty-map-rows) :settings-version))
            (= 2 (length ((first empty-map-rows) :controls)))))

# THE NUMBER FORM, which is what main actually calls. `2` means "procedural at
# settings version 2": the procedural row lifts to five controls while the Python
# row keeps its own three AT VERSION 1, with no error from being asked for a
# version it does not have. That fallback is the property that lets one number
# cover a mixed registry.
(def number-rows (view/providers-from-registry versioned-registry 2))
(def number-proc (first (filter |(= :procedural ($ :id)) number-rows)))
(def number-py (first (filter |(= :terrain-diffusion-python ($ :id)) number-rows)))
(check "the number form gives procedural five controls at version 2"
       (and (= 2 (number-proc :settings-version))
            (= 3 (length (number-proc :controls)))))
(check "the number form preserves the Python provider at version 1"
       (= 1 (number-py :settings-version)))
(check "the number form preserves the Python provider's three controls"
       (= 1 (length (number-py :controls))))
(check "the number form raises no error for the unsupported provider"
       (not (number-py :error)))
# And the legacy default must still be exactly four controls at version 1: this is
# the assertion the old menu relies on and it must not drift.
(check "the default remains four procedural controls at version 1"
       (let [r (first (view/providers-from-registry versioned-registry))]
         (and (= 1 (r :settings-version))
              (= 2 (length (r :controls))))))

# A provider advertising a version it does not DECLARE is not honoured, even when
# the caller asks for it: the row falls back rather than forwarding a contract the
# provider would refuse.
(def undeclared
  @[@{:id :procedural :label "Procedural" :available true :version 1
      :controls @[@{:id :sea-level :label "Sea level" :type :integer
                    :min 0 :max 128 :default 28}]
      # No :settings-versions and no :controls-v2: a legacy descriptor.
      }])
(check "a legacy descriptor asked for v2 stays at version 1"
       (= 1 ((first (view/providers-from-registry undeclared 2)) :settings-version)))
(check "a legacy descriptor keeps its own control count"
       (= 1 (length ((first (view/providers-from-registry undeclared 2)) :controls))))

#
# --- The submit line names what Enter will do ---------------------------
#
# The form used to end with "[Enter] create" -- a verb with no object. A player who
# never read the provider row pressed Enter and got a procedural world with a
# random seed, having believed they had asked for Terrain Diffusion. The provider
# and the seed were both on screen; neither was attached to the action. These
# pin the repair: the footer now names BOTH, from the layout's own data.
#
(print "\nsubmit line:")

# The same 0.5em-per-character estimate the drawing stub uses, so a test can say
# "this line fits" without a font.
(defn stub-measure [s size] (* (length (string s)) (math/floor (* size 0.5))))
(def frame-width 1184)                  # 1280 - 2*48 padding

(def submit-registry
  @[@{:id :procedural :label "Native procedural" :available true
      :controls @[@{:id :sea-level :label "Sea level" :type :integer
                    :min 0 :max 128 :default 28}]}
    @{:id :terrain-diffusion-python
      :label "Terrain Diffusion - Python (temporary)" :available true
      :controls @[@{:id :size :label "Map size" :type :integer
                    :min 16 :max 512 :default 128}]}])
(def submit-rows (view/providers-from-registry submit-registry))
(defn submit-form [] (menu/step (menu/state-new submit-rows @[]) [:new]))
(defn joined [L &opt width]
  (string/join (view/submit-lines L stub-measure (or width frame-width)) " | "))

# THE ACCIDENTAL WORLD. Default provider, blank seed: the footer must say
# "Native procedural" and "random", so the player sees the difference between what
# they assumed and what is about to run BEFORE pressing Enter.
(let [L (menu/layout (submit-form))]
  (def line (joined L))
  (check "the default form names the procedural provider it will run"
         (truthy? (string/find "Native procedural" line)))
  (check "the default form says the seed is random"
         (truthy? (string/find "seed: random" line)))
  (check "the default form still names the key that submits"
         (truthy? (string/find "[Enter] Create" line)))
  (check "the default form still offers the way out"
         (truthy? (string/find "[Esc] back" line))))

# A CHOSEN PROVIDER AND A TYPED SEED. Switching to the long python label and typing
# 12345 must change the footer to exactly that -- the label is derived, never
# hardcoded.
(def chosen
  (-> (submit-form)
      (menu/step [:change-provider :terrain-diffusion-python])
      (menu/step [:edit-seed "12345"])))
(let [L (menu/layout chosen)
      line (joined L)]
  (check "a chosen provider is named in full, however long its label"
         (truthy? (string/find "Terrain Diffusion - Python (temporary)" line)))
  (check "a typed seed appears as typed"
         (truthy? (string/find "seed: 12345" line)))
  (check "the procedural name is gone once another provider is chosen"
         (not (string/find "Native procedural" line))))

# A seed is TEXT. "007" must read as 007 -- parsing it for the label would show 7
# and describe a world the player did not ask for.
(check "a zero-prefixed seed keeps its zeros"
       (truthy? (string/find "seed: 007"
                             (joined (menu/layout
                                       (menu/step chosen [:edit-seed "007"]))))))

# F2 overrides typed text: the mode, not the string, decides.
(check "the random seed toggle wins over typed text"
       (truthy? (string/find "seed: random"
                             (joined (menu/layout
                                       (menu/step chosen [:random-seed true]))))))
(check "and turning it back off restores the typed seed"
       (truthy? (string/find "seed: 12345"
                             (joined (menu/layout
                                       (menu/step
                                         (menu/step chosen [:random-seed true])
                                         [:random-seed false]))))))

# HONEST LABELS. A provider that cannot run says so, and a form with nothing
# selected does not invent an id.
(def unavailable-L
  (menu/layout (menu/step (menu/state-new
                            (view/providers-from-registry
                              @[@{:id :procedural :label "Native procedural" :available true}
                                @{:id :terrain-diffusion-native
                                  :label "Terrain Diffusion (native)" :available false
                                  :controls @[] :reason "pipeline not verified"}])
                            @[])
                          [:new])))
(check "an available row carries no unavailable marker"
       (not (string/find "unavailable"
                         (view/provider-submit-label
                           (merge unavailable-L
                                  {:selected-provider :procedural})))))
(check "an unavailable row is labelled unavailable"
       (truthy? (string/find " - unavailable"
                             (view/provider-submit-label
                               (merge unavailable-L
                                      {:selected-provider :terrain-diffusion-native})))))
(check "no selection is stated, not invented"
       # `merge` DROPS nil-valued keys, so the selection is cleared by cloning and
       # putting nil -- which is also how a real no-available-provider form looks.
       (= "no provider selected"
          (view/provider-submit-label
            (let [L (table/clone unavailable-L)]
              (put L :selected-provider nil)
              L))))

# A seed containing the quote the footer wraps the provider in must not break the
# line, and a Unicode seed must survive both the label and a truncation.
(check "a quote in a seed is escaped"
       (= "a\\\"b" (view/escape-quoted "a\"b")))
(check "a Unicode seed passes through the label intact"
       (= "a🦋" (view/seed-submit-label @{:seed-input "a🦋" :seed-random false})))
(check "a Unicode seed survives the fitting path"
       (= "a🦋" (view/fit-text "a🦋" stub-measure 14 frame-width)))

# WRAPPING. One line when it measures, exactly two when it does not, and every
# returned line still fits -- which is the only property the drawing relies on.
(let [L (menu/layout chosen)
      wide (view/submit-lines L stub-measure frame-width)
      narrow (view/submit-lines L stub-measure 400)]
  (check "a wide frame keeps the footer on one line"
         (= 1 (length wide)))
  (check "a narrow frame splits it into exactly two"
         (= 2 (length narrow)))
  (check "no line ever exceeds the width it was given"
         (truthy? (all |(<= (stub-measure $ 14) 400) narrow)))
  (check "the second line keeps the way out"
         (truthy? (string/find "[Esc] back" (get narrow 1)))))

# A seed longer than any footer could show is shortened with an ellipsis, by whole
# characters -- a half-cut multi-byte character would draw as garbage.
(let [long-seed (string/repeat "x" 200)
      L (menu/layout (menu/step chosen [:edit-seed long-seed]))
      lines (view/submit-lines L stub-measure 400)
      seed-line (get lines 1)]
  (check "an overlong seed is ellipsised"
         (truthy? (string/find "..." seed-line)))
  (check "the ellipsised line still fits"
         (<= (stub-measure seed-line 14) 400))
  (check "the ellipsised line is still valid UTF-8"
         (truthy? (view/utf8-valid? seed-line))))
(let [long-unicode (string/repeat "🦋" 80)
      L (menu/layout (menu/step chosen [:edit-seed long-unicode]))
      seed-line (get (view/submit-lines L stub-measure 400) 1)]
  (check "truncating a multi-byte seed stays valid UTF-8"
         (truthy? (view/utf8-valid? seed-line)))
  (check "and it is shorter than what was typed"
         (< (length seed-line) (length long-unicode))))

# AND IT IS ON SCREEN. A footer nobody paints is a footer nobody reads, so the
# drawing itself is asserted against the recorded draw calls.
(let [rl (stub-rl)
      state (-> (submit-form)
                (menu/step [:change-provider :terrain-diffusion-python])
                (menu/step [:edit-seed "12345"]))]
  (view/draw state rl :seed)
  (def texts (map |($ :text) (filter |(has-key? $ :text) (rl :drawn))))
  (check "the form paints the provider in the submit line"
         (some |(string/find "Terrain Diffusion - Python (temporary)" $) texts))
  (check "the form paints the seed in the submit line"
         (some |(string/find "seed: 12345" $) texts))
  (check "the generic create verb is gone"
         (not (some |(= "[Enter] create   [Esc] back" $) texts))))

#
# --- Result -------------------------------------------------------------
#
(if (zero? failures)
  (print "\nworld menu view: ALL CHECKS PASSED")
  (do (printf "\nworld menu view: %d FAILED" failures) (os/exit 1)))
