"""Model-free tests for the progressive world contract.

Nothing here loads a model, touches a GPU, spawns a process or writes an
artifact. The contract is pure Python over dicts, so these tests pin the
IDENTITY and STATE-MACHINE properties the design document claims -- and nothing
about seam quality, which is explicitly unproven.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "tools"))

import progressive_world as pw     # noqa: E402
import terrain_cache as tc         # noqa: E402


class _Query:
    """A minimal stand-in for terrain_backend.Query's identity record.

    Defaults are version 1's fixed staging geometry, so a test that does not care
    about geometry gets a legal contract rather than an arbitrary one.
    """

    def __init__(self, *, window_chunks=pw.CORE_WINDOW_CHUNKS,
                 pixels_per_voxel=pw.PIXELS_PER_VOXEL_V1,
                 origin=(0, 0), max_samples=pw.MIN_MAX_SAMPLES,
                 halo_voxels=pw.HALO_VOXELS, strategy=pw.STRATEGY):
        self._record = {
            "strategy": strategy,
            "origin_pixels": list(origin),
            "window_chunks": window_chunks,
            "window_pixels": window_chunks * tc.TILE_SIZE * pixels_per_voxel,
            "max_samples": max_samples,
            "pixels_per_voxel": pixels_per_voxel,
            "halo_voxels": halo_voxels,
        }

    def identity_record(self):
        return dict(self._record)


MODEL = {
    "repo": "xandergos/terrain-diffusion-30m",
    "revision": "9ef8030cb805b433b98ec25c5dddefbac07a9e26",
    "stats_sha256": "a" * 64,
}
MAPPING = tc.HeightMapping()


def world(**overrides):
    kwargs = {
        "seed": 12345,
        "model": MODEL,
        "query": _Query(),
        "mapping": MAPPING,
        "climate": pw.climate_record(policy_version=None, container_version=None),
    }
    kwargs.update(overrides)
    return pw.world_identity(**kwargs)


# ---------------------------------------------------------------------------
# Canonical anchors: the corrected floor behaviour
# ---------------------------------------------------------------------------


class AnchorTests(unittest.TestCase):
    def test_floor_division_includes_the_negative_side(self):
        self.assertEqual(pw.anchor(-9, 4), -12)
        self.assertEqual(pw.anchor(-5, 4), -8)
        self.assertEqual(pw.anchor(-4, 4), -4)
        self.assertEqual(pw.anchor(-1, 4), -4)
        self.assertEqual(pw.anchor(0, 4), 0)
        self.assertEqual(pw.anchor(3, 4), 0)
        self.assertEqual(pw.anchor(4, 4), 4)

    def test_minus_one_and_zero_do_not_share_a_window(self):
        """The earlier audit claim was wrong; this pins the real behaviour."""
        self.assertNotEqual(pw.anchor(-1, 4), pw.anchor(0, 4))
        self.assertEqual(pw.anchor(-1, 4), -4)
        self.assertEqual(pw.anchor(0, 4), 0)

    def test_anchor_is_stable_for_every_chunk_within_one_window(self):
        for chunk in (-4, -3, -2, -1):
            self.assertEqual(pw.anchor(chunk, 4), -4)
        for chunk in (0, 1, 2, 3):
            self.assertEqual(pw.anchor(chunk, 4), 0)

    def test_anchor_pair_reports_both_axes(self):
        self.assertEqual(pw.anchor_pair(-1, 5, 4), (-4, 4))

    def test_window_size_must_be_positive(self):
        for bad in (0, -1, 1.5, True):
            with self.assertRaises(pw.ProgressiveContractError):
                pw.anchor(0, bad)

    def test_out_of_range_chunk_is_refused(self):
        with self.assertRaises((TypeError, ValueError)):
            pw.anchor(2 ** 31, 4)


# ---------------------------------------------------------------------------
# World identity: frozen, positional-free, canonical
# ---------------------------------------------------------------------------


class WorldIdentityTests(unittest.TestCase):
    def test_identity_is_a_lowercase_hex_digest(self):
        digest = world()
        self.assertEqual(len(digest), 64)
        self.assertTrue(all(c in "0123456789abcdef" for c in digest))

    def test_identity_is_stable_for_the_same_inputs(self):
        self.assertEqual(world(), world())

    def test_identity_changes_with_the_seed(self):
        self.assertNotEqual(world(), world(seed=2026))

    def test_identity_changes_with_the_mapping(self):
        other = tc.HeightMapping(meters_per_voxel=100.0, sea_level=128)
        self.assertNotEqual(world(), world(mapping=other))

    def test_identity_changes_with_the_query_geometry(self):
        self.assertNotEqual(world(), world(query=_Query(origin=(16, 0))))

    def test_identity_changes_with_the_climate_policy(self):
        self.assertNotEqual(
            world(),
            world(climate=pw.climate_record(policy_version=1,
                                            container_version=1)),
        )

    def test_identity_changes_with_the_model_pins(self):
        drifted = dict(MODEL, stats_sha256="b" * 64)
        self.assertNotEqual(world(), world(model=drifted))

    def test_identity_carries_no_positional_field(self):
        """A world identity must not encode a coordinate or a request plan."""
        descriptor = pw.world_descriptor(
            seed=12345, model=MODEL, query=_Query(), mapping=MAPPING,
            climate=pw.climate_record(policy_version=None, container_version=None),
        )
        self.assertEqual(
            set(descriptor), {"contract", "seed", "model", "query", "mapping",
                              "climate"}
        )
        for forbidden in ("cx", "cz", "chunk", "origin_world", "revision", "ts"):
            self.assertNotIn(forbidden, descriptor)

    def test_digest_uses_terrain_cache_canonical_hashing(self):
        """No second hasher: the digest equals a direct canonical SHA-256."""
        import hashlib

        descriptor = pw.world_descriptor(
            seed=12345, model=MODEL, query=_Query(), mapping=MAPPING,
            climate=pw.climate_record(policy_version=None, container_version=None),
        )
        expected = hashlib.sha256(
            tc._canonical_json(descriptor)
        ).hexdigest()
        self.assertEqual(world(), expected)

    def test_contract_string_is_not_a_legacy_magic(self):
        self.assertEqual(pw.CONTRACT, "tds4-progressive/1")
        self.assertNotEqual(pw.CONTRACT, tc.MAGIC.decode("ascii"))

    def test_negative_seed_is_refused(self):
        with self.assertRaises(pw.ProgressiveContractError):
            world(seed=-1)

    def test_model_block_must_carry_its_pins(self):
        with self.assertRaises(pw.ProgressiveContractError):
            world(model={"repo": "x"})


# ---------------------------------------------------------------------------
# Patch identity: batch-free, coordinate-addressed
# ---------------------------------------------------------------------------


class PatchIdentityTests(unittest.TestCase):
    def setUp(self):
        self.world = world()
        self.query = _Query()

    def patch(self, cx, cz, **kwargs):
        kwargs.setdefault("query", self.query)
        kwargs.setdefault("halo_chunks", pw.HALO_CHUNKS)
        return pw.patch_identity(
            world_identity_digest=self.world, cx=cx, cz=cz, **kwargs
        )

    def test_patch_identity_is_coordinate_addressed(self):
        self.assertEqual(self.patch(0, 0), self.patch(0, 0))
        self.assertNotEqual(self.patch(0, 0), self.patch(1, 0))
        self.assertNotEqual(self.patch(0, 0), self.patch(0, 1))
        self.assertNotEqual(self.patch(-1, 0), self.patch(0, 0))

    def test_patch_identity_carries_no_batch_or_order_field(self):
        """Request composition must not reach the patch identity."""
        descriptor = pw.patch_descriptor(
            world_identity_digest=self.world, cx=0, cz=0,
            query=self.query, halo_chunks=pw.HALO_CHUNKS,
        )
        self.assertEqual(
            set(descriptor), {"contract", "world_identity", "cx", "cz", "staging"}
        )
        for forbidden in ("batch", "order", "index", "timestamp", "requested"):
            self.assertNotIn(forbidden, descriptor)

    def test_patch_identity_is_independent_of_neighbours(self):
        """The same patch computed 'alone' equals it computed 'in a batch'."""
        alone = self.patch(2, 2)
        # Computing neighbours changes nothing about this patch's identity,
        # because nothing about them is an input.
        for cx, cz in ((0, 0), (1, 1), (3, 3), (2, 3), (3, 2)):
            self.patch(cx, cz)
        self.assertEqual(alone, self.patch(2, 2))

    def test_patch_identity_changes_with_the_world(self):
        other_world = world(seed=2026)
        self.assertNotEqual(
            self.patch(0, 0),
            pw.patch_identity(world_identity_digest=other_world, cx=0, cz=0,
                              query=self.query, halo_chunks=pw.HALO_CHUNKS),
        )

    def test_a_staging_halo_that_disagrees_with_the_world_is_refused(self):
        """The halo is world-pinned, so a patch may not choose its own."""
        with self.assertRaises(pw.ProgressiveContractError) as caught:
            self.patch(0, 0, halo_chunks=0)
        self.assertIn("pinned halo", str(caught.exception))
        with self.assertRaises(pw.ProgressiveContractError):
            self.patch(0, 0, halo_chunks=2)

    def test_world_digest_is_required_to_be_a_real_digest(self):
        with self.assertRaises((TypeError, ValueError)):
            pw.patch_identity(world_identity_digest="not-a-digest", cx=0, cz=0,
                              query=self.query, halo_chunks=pw.HALO_CHUNKS)

    def test_patch_coordinate_must_be_signed_int32(self):
        for bad in (2 ** 31, -2 ** 31 - 1):
            with self.assertRaises((TypeError, ValueError)):
                self.patch(bad, 0)


# ---------------------------------------------------------------------------
# Bounded geometry
# ---------------------------------------------------------------------------


class StagingTests(unittest.TestCase):
    def test_max_samples_below_the_witness_window_is_refused(self):
        with self.assertRaises(pw.ProgressiveContractError) as caught:
            pw.query_record(_Query(max_samples=64))
        self.assertIn("max_samples", str(caught.exception))

    def test_max_samples_above_the_mps_ceiling_is_refused(self):
        with self.assertRaises(pw.ProgressiveContractError) as caught:
            pw.query_record(_Query(max_samples=256))
        self.assertIn("max_samples", str(caught.exception))

    def test_the_witness_window_must_fit_inside_max_samples(self):
        record = pw.default_query_record()
        record["max_samples"] = 64          # below the 96 px witness window
        with self.assertRaises(pw.ProgressiveContractError) as caught:
            pw.query_record(record)
        self.assertIn("max_samples", str(caught.exception))

    def test_a_window_chunk_count_other_than_four_is_refused(self):
        record = pw.default_query_record()
        record["window_chunks"] = 8
        with self.assertRaises(pw.ProgressiveContractError) as caught:
            pw.query_record(record)
        self.assertIn("window_chunks", str(caught.exception))

    def test_a_non_native_lattice_is_refused(self):
        record = pw.default_query_record()
        record["pixels_per_voxel"] = 2
        with self.assertRaises(pw.ProgressiveContractError) as caught:
            pw.query_record(record)
        self.assertIn("native integer lattice", str(caught.exception))

    def test_the_finite_macrotile_strategy_is_not_accepted(self):
        """A finite window strategy cannot repeat across adjacent patches."""
        record = pw.default_query_record()
        record["strategy"] = "canonical-macrotile-v1"
        with self.assertRaises(pw.ProgressiveContractError) as caught:
            pw.query_record(record)
        self.assertIn("macrotile", str(caught.exception))

    def test_a_halo_other_than_one_chunk_is_refused(self):
        record = pw.default_query_record()
        record["halo_voxels"] = 0
        with self.assertRaises(pw.ProgressiveContractError) as caught:
            pw.query_record(record)
        self.assertIn("halo_voxels", str(caught.exception))

    def test_window_pixels_must_agree_with_its_parts(self):
        record = _Query().identity_record()
        record["window_pixels"] = 999
        with self.assertRaises(pw.ProgressiveContractError):
            pw.query_record(record)

    def test_negative_halo_is_refused(self):
        with self.assertRaises(pw.ProgressiveContractError):
            pw.staging_record(query=_Query(), halo_chunks=-1)

    def test_staging_records_the_world_pinned_geometry(self):
        staging = pw.staging_record(query=_Query(), halo_chunks=pw.HALO_CHUNKS)
        self.assertEqual(staging["version"], pw.CONTRACT_VERSION)
        self.assertEqual(staging["halo_chunks"], pw.HALO_CHUNKS)
        self.assertEqual(staging["query"]["window_chunks"], pw.CORE_WINDOW_CHUNKS)
        self.assertEqual(staging["query"]["halo_voxels"], pw.HALO_VOXELS)

    def test_geometry_is_the_agreed_96_against_128(self):
        record = pw.query_record(pw.default_query_record())
        self.assertEqual(record["window_pixels"], 64)
        self.assertEqual(record["witness_window_pixels"], 96)
        self.assertEqual(record["max_samples"], pw.MAX_MAX_SAMPLES)
        self.assertEqual(record["halo_voxels"], 16)
        self.assertEqual(record["address"], {"kind": "global-affine-v1",
                                             "num": 1, "den": 1})


# ---------------------------------------------------------------------------
# Climate policy
# ---------------------------------------------------------------------------


class ClimatePolicyTests(unittest.TestCase):
    def test_no_policy_is_a_legal_inert_world(self):
        record = pw.climate_record(policy_version=None, container_version=None)
        self.assertIsNone(record["policy_version"])
        self.assertIsNone(record["container_version"])

    def test_a_policy_must_name_its_container(self):
        with self.assertRaises(pw.ProgressiveContractError):
            pw.climate_record(policy_version=1, container_version=None)

    def test_a_container_alone_is_not_a_world_state(self):
        with self.assertRaises(pw.ProgressiveContractError):
            pw.climate_record(policy_version=None, container_version=1)


# ---------------------------------------------------------------------------
# The state machine
# ---------------------------------------------------------------------------


class StateMachineTests(unittest.TestCase):
    def setUp(self):
        self.identity = pw.patch_identity(
            world_identity_digest=world(), cx=0, cz=0,
            query=_Query(), halo_chunks=pw.HALO_CHUNKS,
        )

    def patch(self, **kwargs):
        return pw.PatchState(self.identity, **kwargs)

    def test_happy_path_reaches_published(self):
        patch = self.patch()
        patch.claim(revision=1)
        patch.validate()
        patch.publish()
        self.assertEqual(patch.state, pw.PUBLISHED)
        self.assertTrue(patch.terminal)
        self.assertEqual(patch.history,
                         [pw.QUEUED, pw.INFLIGHT, pw.VALIDATED, pw.PUBLISHED])

    def test_publication_is_unreachable_before_validation(self):
        for setup in (lambda p: None,
                      lambda p: p.claim(revision=1)):
            patch = self.patch()
            setup(patch)
            with self.assertRaises(pw.ProgressiveContractError):
                patch.publish()
            self.assertNotEqual(patch.state, pw.PUBLISHED)

    def test_an_inflight_patch_cannot_skip_to_published(self):
        patch = self.patch()
        patch.claim(revision=1)
        with self.assertRaises(pw.ProgressiveContractError):
            patch.transition(pw.PUBLISHED)

    def test_failed_and_cancelled_are_terminal(self):
        for terminal in (pw.FAILED, pw.CANCELLED):
            patch = self.patch()
            patch.claim(revision=1)
            if terminal == pw.FAILED:
                patch.fail("all clipped")
            else:
                patch.cancel()
            self.assertTrue(patch.terminal)
            with self.assertRaises(pw.ProgressiveContractError):
                patch.transition(pw.VALIDATED)

    def test_published_is_terminal(self):
        patch = self.patch()
        patch.claim(revision=1)
        patch.validate()
        patch.publish()
        for target in (pw.QUEUED, pw.INFLIGHT, pw.VALIDATED, pw.FAILED):
            with self.assertRaises(pw.ProgressiveContractError):
                patch.transition(target)

    def test_a_stale_revision_cannot_advance_a_patch(self):
        patch = self.patch(revision=1)
        patch.claim(revision=1)
        with self.assertRaises(pw.ProgressiveContractError) as caught:
            patch.transition(pw.VALIDATED, revision=2)
        self.assertIn("revision", str(caught.exception))
        self.assertEqual(patch.state, pw.INFLIGHT)

    def test_a_new_revision_may_cancel_stale_work(self):
        patch = self.patch(revision=1)
        patch.claim(revision=1)
        patch.cancel(revision=2)
        self.assertEqual(patch.state, pw.CANCELLED)
        self.assertEqual(patch.revision, 2)

    def test_a_cancelled_patch_can_never_publish(self):
        patch = self.patch(revision=1)
        patch.claim(revision=1)
        patch.validate()
        patch.cancel(revision=2)
        with self.assertRaises(pw.ProgressiveContractError):
            patch.publish()

    def test_unknown_states_are_refused(self):
        patch = self.patch()
        with self.assertRaises(pw.ProgressiveContractError):
            patch.transition("published-ish")

    def test_every_state_has_a_transition_entry(self):
        self.assertEqual(set(pw.TRANSITIONS), set(pw.STATES))
        self.assertEqual(set(pw.TERMINAL),
                         {pw.PUBLISHED, pw.FAILED, pw.CANCELLED})

    def test_transition_table_never_allows_a_shortcut_to_publish(self):
        for state, targets in pw.TRANSITIONS.items():
            if state in (pw.QUEUED, pw.INFLIGHT):
                self.assertNotIn(pw.PUBLISHED, targets)


# ---------------------------------------------------------------------------
# Band refusal
# ---------------------------------------------------------------------------


class BandAssessmentTests(unittest.TestCase):
    def test_land_within_band_is_not_clipped(self):
        record = pw.band_assessment([[850.0, 1200.0], [1600.0, 900.0]],
                                    mapping=MAPPING)
        self.assertFalse(record["all_clipped"])
        self.assertIsNone(record["bound"])

    def test_a_whole_patch_below_the_band_is_all_clipped(self):
        """The honest seed-42 answer: not land, not a flat world."""
        record = pw.band_assessment([[-1840.0, -1296.0]], mapping=MAPPING)
        self.assertTrue(record["all_clipped"])
        self.assertEqual(record["bound"], "min")

    def test_a_whole_patch_above_the_band_is_all_clipped(self):
        record = pw.band_assessment([[9000.0, 12000.0]], mapping=MAPPING)
        self.assertTrue(record["all_clipped"])
        self.assertEqual(record["bound"], "max")

    def test_an_empty_patch_is_refused(self):
        with self.assertRaises(pw.ProgressiveContractError):
            pw.band_assessment([], mapping=MAPPING)


class ImportDisciplineTests(unittest.TestCase):
    def test_module_imports_without_torch_or_numpy(self):
        import subprocess

        code = (
            "import sys; sys.path.insert(0, 'tools'); "
            "import progressive_world; "
            "print('torch' in sys.modules or 'numpy' in sys.modules)"
        )
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        out = subprocess.run(["python3", "-c", code], cwd=root,
                             capture_output=True, text=True)
        self.assertEqual(out.returncode, 0, out.stderr)
        self.assertEqual(out.stdout.strip(), "False")


if __name__ == "__main__":
    unittest.main()
