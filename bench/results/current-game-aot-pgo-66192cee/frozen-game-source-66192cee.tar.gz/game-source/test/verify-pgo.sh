#!/usr/bin/env bash
# Run from any directory: a short real-render parity probe for the AOT oracle.
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
bender="${BENDER:-$root/../../janet/build/bender}"
scratch="$(mktemp -d "${TMPDIR:-/tmp}/trinecraft-verify-pgo.XXXXXX")"
trap 'rm -rf "$scratch"' EXIT
cd "$root"
for run in one two; do
  JANET_NO_PROFILE=1 "$bender" main.janet --verify-pgo --frames 120 --radius 6 --uncapped \
    >"$scratch/$run.out" 2>"$scratch/$run.err"
done
cmp "$scratch/one.out" "$scratch/two.out"
test "$(wc -l <"$scratch/one.out")" -eq 1
awk '
  /^verify-pgo frames=120 seed=4 radius=6 chunks=[0-9]+ blocks=[0-9]+ vertices=[0-9]+ edits=[0-9]+ hash=[0-9]+$/ {
    for (i = 1; i <= NF; i++) {
      split($i, pair, "="); value[pair[1]] = pair[2]
    }
    if (value["chunks"] >= 25 && value["blocks"] >= 409600 && value["vertices"] > 0 && value["edits"] > 0) valid = 1
  }
  END { exit !valid }
' "$scratch/one.out"
JANET_NO_PROFILE=1 "$bender" main.janet --verify-pgo --frames 19 --radius 2 --uncapped \
  >"$scratch/before-edit.out" 2>"$scratch/before-edit.err"
# Frame 20 begins the scheduled break/place path. Hash includes frame count,
# so require a separate changed-state signal: the edit count must increase.
awk '/^verify-pgo / { for (i = 1; i <= NF; i++) { split($i, field, "="); if (field[1] == "edits") exit !(field[2] == 0) } exit 1 } END { if (NR != 1) exit 1 }' "$scratch/before-edit.out"
awk '/^verify-pgo / { for (i = 1; i <= NF; i++) { split($i, field, "="); if (field[1] == "edits") exit !(field[2] > 0) } exit 1 } END { if (NR != 1) exit 1 }' "$scratch/one.out"
printf 'verify-pgo: repeat parity and scheduled world-edit control passed\n'
