# Pure interpreter tests: no graphics, world, app, or native library imports.
(import ../src/sky-cycle :as sky)

(defn near [a b tolerance] (<= (math/abs (- a b)) tolerance))
(defn vector-near [a b tolerance]
  (every? (map |(near $0 $1 tolerance) a b)))
(defn bounded [xs]
  (every? (map |(and (<= 0 $) (<= $ 1)) xs)))

(let [duration 1200
      sunrise (sky/frame 0 {:star-count 4})
      noon (sky/frame 300 {:star-count 4})
      sunset (sky/frame 600 {:star-count 4})
      night (sky/frame 900 {:star-count 4})]
  (assert (= 0 (sunrise :phase)))
  (assert (= 0.25 (noon :phase)))
  (assert (= 0.5 (sunset :phase)))
  (assert (= 0.75 (night :phase)))
  (assert (> ((noon :sun-direction) 1) 0.99))
  (assert (< ((night :sun-direction) 1) -0.99))
  (assert (> (noon :sun-intensity) (night :sun-intensity)))
  (assert (> (night :star-intensity) (noon :star-intensity)))
  (assert (near ((sky/frame duration {:star-count 4}) :phase) 0 0.000001))
  (assert (vector-near (noon :sun-direction) ((sky/frame (+ duration 300) {:star-count 4}) :sun-direction) 0.000001)))

# Twilight remains blue above and warm at the horizon on both sides of noon.
(each phase [0.03 0.47]
  (let [sample (sky/frame (* 1200 phase) {:star-count 0})
        zenith (sample :zenith)
        horizon (sample :horizon)]
    (assert (> (zenith 2) (zenith 0)) "twilight zenith must remain blue")
    (assert (> (horizon 0) (horizon 2)) "twilight horizon must remain orange")
    (assert (< (math/abs ((sample :sun-direction) 1)) 0.25)
            "twilight sun must approach the horizon")))

# Explicit time offset and duration tune phase without introducing state.
(assert (near ((sky/frame 50 {:duration 400 :time-offset 50 :star-count 0}) :phase) 0.25 0.000001))
(assert (near ((sky/frame -100 {:duration 400 :star-count 0}) :phase) 0.75 0.000001))
(assert (= 0.25 ((sky/frame 300 {:duration -1 :star-count 0}) :phase)))

(let [before (sky/frame 599.999 {:star-count 0})
      after (sky/frame 600.001 {:star-count 0})
      end (sky/frame 1199.999 {:star-count 0})
      start (sky/frame 0.001 {:star-count 0})]
  (each key [:sun-direction :moon-direction :zenith :horizon :fog :ambient-color :sun-color]
    (assert (vector-near (get before key) (get after key) 0.001) "sunset discontinuity")
    (assert (vector-near (get end key) (get start key) 0.001) "cycle seam discontinuity")))

(let [a (sky/frame 123 {:seed 18 :star-count 32})
      b (sky/frame 832 {:seed 18 :star-count 32})
      c (sky/frame 123 {:seed 19 :star-count 32})]
  (for i 0 32
    (assert (vector-near (((a :stars) i) :direction)
                         (((b :stars) i) :direction) 0.000000001)
            "stars must remain fixed in world space"))
  (assert (not (vector-near (((a :stars) 0) :direction)
                            (((c :stars) 0) :direction) 0.000000001))
          "seed must affect star directions")
  (assert (= 32 (length (a :stars))))
  (assert (= 0 (length (sky/stars 7 -1))))
  (assert (= 1024 (length (sky/stars 7 9999))))
  (each star (a :stars)
    (let [v (star :direction)]
      (assert (near (+ (* (v 0) (v 0)) (* (v 1) (v 1)) (* (v 2) (v 2))) 1 0.000001))
      (assert (> (v 1) 0))
      (assert (bounded [(star :brightness)])))))

# Equal-area azimuth/elevation bins catch clumping; adjacent angles and
# triple-step angular drift catch the dotted diagonal seen in the night view.
(each seed [1 18 741]
  (let [catalog (sky/stars seed 512)
        bins (array/new-filled 64 0)
        angles @[]
        quadrant (array/new-filled 4 0)]
    (each star catalog
      (let [v (star :direction)
            angle (math/atan2 (v 2) (v 0))
            azimuth (if (neg? angle) (+ angle (* 2 3.141592653589793)) angle)
            az-bin (min 7 (math/floor (* 8 (/ azimuth (* 2 3.141592653589793)))))
            el-bin (min 7 (math/floor (* 8 (/ (- (v 1) 0.08) 0.92))))
            slot (+ az-bin (* 8 el-bin))]
        (array/push angles azimuth)
        (put bins slot (+ 1 (bins slot)))
        (put quadrant (math/floor (/ az-bin 2))
             (+ 1 (quadrant (math/floor (/ az-bin 2)))))))
    (var occupied 0)
    (each hits bins (when (> hits 0) (set occupied (+ occupied 1))))
    (assert (>= occupied 58) "stars should populate most sky cells")
    (each hits quadrant
      (assert (and (> hits 80) (< hits 180)) "azimuth spread is lopsided"))
    (var near-linear 0)
    (for i 0 510
      (let [first (mod (- (angles (+ i 1)) (angles i)) (* 2 3.141592653589793))
            second (mod (- (angles (+ i 2)) (angles (+ i 1))) (* 2 3.141592653589793))
            delta (math/abs (- first second))]
        (when (< (min delta (- (* 2 3.141592653589793) delta)) 0.015)
          (set near-linear (+ near-linear 1)))))
    (assert (< near-linear 15) "sequential stars form repeated angular lines")))

(for i -500 501
  (let [sample (sky/frame (* i 17.37) {:duration 37 :seed 9 :star-count 0})]
    (assert (bounded [(sample :phase) (sample :ambient-intensity)
                      (sample :sun-intensity) (sample :star-intensity)]))
    (assert (bounded (sample :cloud-offset)))
    (each key [:zenith :horizon :fog :ambient-color :sun-color]
      (assert (bounded (get sample key)) "color outside unit range"))
    (assert (vector-near (sample :moon-direction)
                         (map |(- $) (sample :sun-direction)) 0.000001))))

(print "sky-cycle: ok")
