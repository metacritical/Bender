# Headless sky geometry; no draw/window calls are made.
(import ../src/sky-render :as sky)
(import ../src/sky-cycle :as cycle)

(def frame {:sun-direction [1 0 0]
            :moon-direction [0 0 1]
            :stars [[1 0.1 0 1] [1 0.2 0.2 0.6] [0 0 -1]]
            :sky-zenith [0.13 0.29 0.62]
            :sky-horizon [0.66 0.78 0.92]
            :night-strength 0.8
            :cloud-offset 0})
(def width 800)
(def height 600)
# Twilight must transition from warm horizon to blue upper sky in the
# actual perspective viewport, rather than painting the whole screen orange.
(def dusk (cycle/frame 0.47 {:duration 1 :star-count 0}))
(def bands (sky/commands dusk 0 0 width height))
(def top-color (get (first bands) 5))
(def middle-color (get (get bands (math/floor (/ (length bands) 2))) 5))
(assert (> (get top-color 2) (get top-color 0)))
(assert (> (get middle-color 0) (get middle-color 2)))
# The top is exactly zenith at pitch=0, while even a modest positive
# altitude rapidly leaves the warm band; below the horizon stays warm.
(for channel 0 3
  (assert (<= (math/abs (- (top-color channel)
                           (math/floor (+ 0.5 (* 255 ((dusk :zenith) channel)))))) 2)))
(def gradient-frame (merge frame {:sun-direction [-1 -1 0]
                                  :moon-direction [-1 -1 0]
                                  :stars [] :night-strength 0
                                  :sky-zenith [0.08 0.14 0.8]
                                  :sky-horizon [0.95 0.29 0.08]}))
(def gradient (sky/commands gradient-frame 0 0 width height))

(defn color-at-row
  "The gradient colour covering ROW.

  Commands are BANDS, not rows: each rect is `band` rows tall, so indexing the
  command list by row number was only ever valid while the loop wrongly drew
  one rect per row. Looking the band up by its coverage is both correct and
  independent of how the gradient is subdivided."
  [commands row]
  (var found nil)
  (each c commands
    (when (and (nil? found) (= (get c 0) :rect))
      (let [top (get c 2) h (get c 4)]
        (when (and (<= top row) (< row (+ top h)))
          (set found (get c 5))))))
  found)

(def upper-color (color-at-row gradient (math/floor (* height 0.25))))
(def lower-color (color-at-row gradient (math/floor (* height 0.65))))
(assert (> (upper-color 2) (upper-color 0)))
(assert (> (lower-color 0) (lower-color 2)))
(def pitched-gradient (sky/commands gradient-frame 0 0.2 width height))
(assert (> ((color-at-row pitched-gradient (math/floor (* height 0.55))) 2)
           ((color-at-row gradient (math/floor (* height 0.55))) 2)))
(def center (sky/project [1 0 0] 0 0 width height))
(assert (= [400 300] center))
(assert (nil? (sky/project [-1 0 0] 0 0 width height)))
(assert (nil? (sky/project [0 0 1] 0 0 width height)))
(assert (> (get (sky/project [1 0 0.3] 0 0 width height) 0) 400))
(assert (< (get (sky/project [1 0.3 0] 0 0 width height) 1) 300))
(assert (= center (sky/project [0 0 1] (/ math/pi 2) 0 width height)))
(assert (< (math/abs (- (get (sky/project [1 1 0] 0 (/ math/pi 4)
                                             width height) 1) 300)) 1e-9))
(assert (< (math/abs (- (get (sky/project [1 0 0] (* 2 math/pi) 0
                                             width height) 0) 400)) 1e-9))
# Horizontal edge derives from aspect and vertical 70-degree camera FOV.
(def edge-z (* (/ width height) (math/tan (* 70 (/ math/pi 360)))))
(assert (= width (get (sky/project [1 0 edge-z] 0 0 width height) 0)))
(assert (nil? (sky/project [1 0 (* 1.01 edge-z)] 0 0 width height)))
(assert (= height (get (sky/project [1 (- (math/tan (* 70 (/ math/pi 360)))) 0]
                                    0 0 width height) 1)))

(def commands (sky/commands frame 0 0 width height))
(assert (deep= commands (sky/commands frame 0 0 width height)))
(assert (> (length commands) 50))
(each command commands
  (assert (= :rect (command 0)))
  (assert (= 6 (length command)))
  (assert (<= 0 (command 1)))
  (assert (<= 0 (command 2)))
  (assert (<= (+ (command 1) (command 3)) width))
  (assert (<= (+ (command 2) (command 4)) height))
  (assert (pos? (command 3)))
  (assert (pos? (command 4)))
  (each channel (command 5) (assert (<= 0 channel 255))))
(assert (empty? (sky/commands frame 0 0 0 height)))
(assert (not (deep= commands (sky/commands frame (/ math/pi 2) 0 width height))))
(assert (not (deep= commands (sky/commands (merge frame {:cloud-offset 0.2})
                                           0 0 width height))))
(assert (not (deep= commands (sky/commands (merge frame {:night-strength 0})
                                           0 0 width height))))
# Real producer output is consumed as data, without importing it in renderer.
(def cycle-frame (cycle/frame 900 {:star-count 96}))
(def cycle-commands (sky/commands cycle-frame 0 0 width height))
(assert (> (length cycle-commands) 48))
(assert (deep= cycle-commands (sky/commands cycle-frame 0 0 width height)))
(assert (not (deep= cycle-commands
                    (sky/commands (merge cycle-frame {:cloud-offset [0.2 0.4]})
                                  0 0 width height))))
(assert (not (deep= cycle-commands
                    (sky/commands (merge cycle-frame {:star-intensity 0})
                                  0 0 width height))))
(assert (get (first (cycle-frame :stars)) :direction))

# A camera pitched down can project a below-horizon body into its viewport.
# Its world-space altitude must still suppress that body and its glow.
(def empty-celestial (merge frame {:sun-direction [-1 -1 0]
                                   :moon-direction [-1 -1 0]
                                   :stars [] :night-strength 0}))
(def buried (sky/commands empty-celestial math/pi -0.6 width height))
(def raised (sky/commands (merge empty-celestial {:sun-direction [-1 1 0]
                                                   :moon-direction [-1 1 0]})
                          math/pi 0.6 width height))
(assert (nil? (sky/project [-1 1 0] math/pi -0.6 width height)))
(assert (sky/project [-1 -1 0] math/pi -0.6 width height))
(assert (deep= buried
               (sky/commands (merge empty-celestial {:sun-direction [1 1 0]
                                                       :moon-direction [1 1 0]})
                             math/pi -0.6 width height)))
(assert (> (length raised) (length buried)))
# Fog horizon below zero altitude stays precisely the supplied horizon RGB.
(def low-frame (merge empty-celestial {:sky-zenith [1 0 0]
                                       :sky-horizon [0 0.5 1]}))
(def low (sky/commands low-frame 0 -0.9 width height))
(assert (= [0 128 255 255] ((first low) 5)))

# Isolate sky pixels from cloud geometry with directions outside camera view.
(def sky-only (merge frame {:sun-direction [-1 -1 0]
                            :moon-direction [-1 -1 0]
                            :stars [] :night-strength 0}))
(def stars (array/new-filled 240 {:direction [1 0.3 0] :brightness 1}))
(def star-frame (merge sky-only {:night-strength 1 :stars stars}))
(def star-draws (sky/commands star-frame 0 0 width height))
# Planet/cloud geometry also draws, so compare against identical night frame
# without stars to isolate count and square pixel dimensions.
(def night-base (sky/commands (merge star-frame {:stars []}) 0 0 width height))
(assert (= 96 (- (length star-draws) (length night-base))))
(def star-pixels (filter |(and (<= 1 ($ 3) 2) (= ($ 3) ($ 4))) star-draws))
(assert (<= 96 (length star-pixels)))
(assert (= 96 (length (filter |(= 2 ($ 3)) star-pixels))))
# Night cloud shadow remains colored, not nearly black, even on a dark horizon.
(def dark-frame (merge sky-only {:sky-zenith [0.01 0.02 0.05]
                                   :sky-horizon [0.02 0.03 0.06]}))
(def dark-commands (sky/commands dark-frame 0 0 width height))
(assert (some |(and (= 166 (($ 5) 3)) (> (($ 5) 2) 40)) dark-commands))
(print "sky renderer geometry: passed")
