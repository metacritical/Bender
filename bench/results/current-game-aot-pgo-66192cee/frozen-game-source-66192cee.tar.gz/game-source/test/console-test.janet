# Headless console tests. No window, no GPU: everything above the rendering
# section of src/console.janet is pure logic over a state table.
# Run: ./run.sh test, or BENDER test/console-test.janet

(import ./../src/console :as console)
(import ./../src/world :as world)
(import ./../src/rl :as rl)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(defn fresh []
  (def c (console/console-new))
  (console/bind! c @{'world (world/world-new) 'answer 42} (curenv))
  c)

(defn last-line [c] (get (last (c :lines)) :text))
(defn last-kind [c] (get (last (c :lines)) :kind))
(defn type-in [c text]
  (each b text (console/insert-char c b))
  c)

#
# --- Evaluation ---------------------------------------------------------
#
(print "evaluation:")
(def c (fresh))

(def r (console/evaluate c "(+ 1 2)"))
(check "evaluates an expression" (and (r :ok) (= 3 (r :value))))

(def r2 (console/evaluate c "answer"))
(check "sees an injected binding" (= 42 (r2 :value)))

(def r3 (console/evaluate c "(print \"hi\") 5"))
(check "captures printed output" (= "hi\n" (r3 :output)))
(check "and still returns the value" (= 5 (r3 :value)))

# A runtime error must be trapped, not propagated: a typo at the console
# cannot be allowed to take the game down.
(def r4 (console/evaluate c "(error \"boom\")"))
(check "traps a runtime error" (not (r4 :ok)))
(check "reports the error value" (= "boom" (r4 :error)))

# Compile errors arrive through the same fiber, not as a thrown exception.
(def r5 (console/evaluate c "(((("))
(check "traps a compile error" (not (r5 :ok)))

(def r6 (console/evaluate c "(undefined-symbol-xyz)"))
(check "traps an unknown symbol" (not (r6 :ok)))

# Definitions must survive between submissions, or it is not a REPL.
(console/evaluate c "(def persisted 99)")
(def r7 (console/evaluate c "persisted"))
(check "definitions persist across evaluations" (= 99 (r7 :value)))

(console/evaluate c "(var counter 0)")
(console/evaluate c "(set counter (+ counter 1))")
(console/evaluate c "(set counter (+ counter 1))")
(check "mutable state persists too" (= 2 ((console/evaluate c "counter") :value)))

#
# --- Live mutation ------------------------------------------------------
#
(print "\nlive game state:")
(def lc (console/console-new))
(def w (world/world-new))
(world/world-put-chunk w (world/chunk-new 0 0))
(console/bind! lc @{'world w} (curenv))

(check "reads live state through the binding"
       (= 1 ((console/evaluate lc "(world/world-chunk-count world)") :value)))

(console/evaluate lc "(world/world-set-block world 1 5 1 3)")
(check "a console edit mutates the real world"
       (= 3 (world/world-get-block w 1 5 1)))

(console/evaluate lc "(put world :seed 777)")
(check "mutating the world table is visible outside" (= 777 (w :seed)))

#
# --- Submit, echo and scrollback ----------------------------------------
#
(print "\nsubmit and scrollback:")
(def sc (fresh))
(type-in sc "(+ 2 3)")
(console/submit sc)
(check "submitting clears the input line" (= "" (string (sc :input))))
(check "the caret returns home" (zero? (sc :cursor)))
(check "the result is shown" (= "5" (last-line sc)))
(check "the result is tagged as a value" (= :value (last-kind sc)))
(check "the input was echoed" (string/has-prefix? "> (+ 2 3)"
                                                  (get (get (sc :lines) 0) :text)))

(def ec (fresh))
(type-in ec "(error \"nope\")")
(console/submit ec)
(check "an error is shown as an error line" (= :error (last-kind ec)))
(check "the message names the cause" (string/find "nope" (last-line ec)))

# nil results print nothing: a console full of "nil" after every mutation is
# noise, and most dev verbs return nil.
(def nc (fresh))
(type-in nc "(do nil)")
(def before-lines (length (nc :lines)))
(console/submit nc)
(check "a nil result adds only the echo" (= (+ 1 before-lines) (length (nc :lines))))

(def bc (fresh))
(def blank-before (length (bc :lines)))
(console/submit bc)
(check "a blank line is ignored" (= blank-before (length (bc :lines))))

# Scrollback must be capped or a runaway print loop exhausts memory.
(def cap (fresh))
(for i 0 (+ console/max-scrollback 50) (console/emit cap (string "line " i)))
(check "scrollback is capped" (= console/max-scrollback (length (cap :lines))))
(check "the cap discards the oldest lines first"
       (= "line 50" (get (get (cap :lines) 0) :text)))

# Multi-line output must become multiple lines, not one with newlines in it.
(def mc (fresh))
(console/emit mc "a\nb\nc")
(check "multi-line text splits into lines" (= 3 (length (mc :lines))))

#
# --- Line editing -------------------------------------------------------
#
(print "\nline editing:")
(def lec (fresh))
(type-in lec "hello")
(check "typing builds the line" (= "hello" (string (lec :input))))
(check "the caret tracks the end" (= 5 (lec :cursor)))

(console/backspace lec)
(check "backspace removes the last char" (= "hell" (string (lec :input))))

(console/cursor-home lec)
(check "home moves to the start" (zero? (lec :cursor)))
(console/insert-char lec 88)   # X
(check "insertion happens at the caret" (= "Xhell" (string (lec :input))))

(console/delete-forward lec)
(check "delete removes forward at the caret" (= "Xell" (string (lec :input))))

(console/cursor-end lec)
(check "end moves past the last char" (= 4 (lec :cursor)))

# The caret must never leave the string, however hard it is pushed.
(console/move-cursor lec 100)
(check "the caret clamps to the end" (= (length (lec :input)) (lec :cursor)))
(console/move-cursor lec -100)
(check "the caret clamps to the start" (zero? (lec :cursor)))
(console/backspace lec)
(check "backspace at the start is a no-op" (= "Xell" (string (lec :input))))
(console/cursor-end lec)
(console/delete-forward lec)
(check "delete at the end is a no-op" (= "Xell" (string (lec :input))))

(console/kill-line lec)
(check "kill-line empties the input" (= "" (string (lec :input))))

#
# --- History ------------------------------------------------------------
#
(print "\nhistory:")
(def hc (fresh))
(each code ["(+ 1 1)" "(+ 2 2)" "(+ 3 3)"]
  (type-in hc code)
  (console/submit hc))
(check "history records submissions" (= 3 (length (hc :history))))

(console/history-prev hc)
(check "up recalls the newest entry" (= "(+ 3 3)" (string (hc :input))))
(console/history-prev hc)
(check "up again goes further back" (= "(+ 2 2)" (string (hc :input))))
(console/history-next hc)
(check "down returns toward the newest" (= "(+ 3 3)" (string (hc :input))))
(console/history-next hc)
(check "down past the newest clears the line" (= "" (string (hc :input))))

# A half-typed line must survive a trip through history.
(def sc2 (fresh))
(type-in sc2 "(+ 9 9)")
(console/submit sc2)
(type-in sc2 "half-typed")
(console/history-prev sc2)
(check "browsing history replaces the line" (= "(+ 9 9)" (string (sc2 :input))))
(console/history-next sc2)
(check "returning restores the half-typed line"
       (= "half-typed" (string (sc2 :input))))

(def dc (fresh))
(type-in dc "(+ 1 1)")
(console/submit dc)
(type-in dc "(+ 1 1)")
(console/submit dc)
(check "consecutive duplicates are not repeated in history"
       (= 1 (length (dc :history))))

(def ehc (fresh))
(console/history-prev ehc)
(check "up on empty history is harmless" (= "" (string (ehc :input))))
(console/history-next ehc)
(check "down on empty history is harmless" (= "" (string (ehc :input))))

#
# --- Scrolling ----------------------------------------------------------
#
(print "\nscrolling:")
(def vc (fresh))
(for i 0 50 (console/emit vc (string "L" i)))
(check "visible-lines returns the tail by default"
       (= "L49" (get (last (console/visible-lines vc 10)) :text)))
(console/scroll-by vc 5 10)
(check "scrolling back moves the window"
       (= "L44" (get (last (console/visible-lines vc 10)) :text)))
(console/scroll-by vc -100 10)
(check "scrolling forward clamps at the bottom" (zero? (vc :scroll)))
(console/scroll-by vc 10000 10)
(check "scrolling back clamps at the top" (= 40 (vc :scroll)))
(check "a short buffer cannot scroll"
       (do (def tiny (fresh))
           (console/emit tiny "only")
           (console/scroll-by tiny 10 10)
           (zero? (tiny :scroll))))

#
# --- Key dispatch -------------------------------------------------------
#
(print "\nkey dispatch:")
(def kc (fresh))
(set (kc :open) true)
(type-in kc "(+ 4 4)")
(console/handle-key kc rl/key-enter 10)
(check "enter submits" (= "8" (last-line kc)))

(check "escape closes" (= :closed (console/handle-key kc rl/key-escape 10)))
(check "and marks the console closed" (not (kc :open)))
(set (kc :open) true)
(check "grave closes too" (= :closed (console/handle-key kc rl/key-grave 10)))

(set (kc :open) true)
(check "an unmapped key is ignored" (nil? (console/handle-key kc 999 10)))

(console/toggle! kc)
(check "toggle flips open" (not (kc :open)))
(console/toggle! kc)
(check "toggle flips back" (kc :open))

#
# --- Guard: the console must not be able to kill the game ---------------
#
(print "\nrobustness:")
(def gc (fresh))
(each hostile ["(error \"x\")" "((((" "(1 2 3)" "(/ 1 0)" "nonexistent"
               "(assert false)" "(string/slice \"a\" 99 100)"]
  (type-in gc hostile)
  (console/submit gc))
(check "hostile input never escapes the console" true)
(check "the console still evaluates afterwards"
       (= 7 ((console/evaluate gc "(+ 3 4)") :value)))

(printf "\n%s  (%d failure%s)"
        (if (zero? failures) "ALL CHECKS PASSED" "CHECKS FAILED")
        failures (if (= 1 failures) "" "s"))
(os/exit (if (zero? failures) 0 1))
