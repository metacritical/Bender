"""Dependency-free tests for :mod:`tools.terrain_backend`.

Run from anywhere::

    PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s test \
        -p 'test_terrain_backend.py' -v

Nothing here loads a diffusion model and nothing imports torch.  The sampler is
:class:`FakeSampler`, an explicitly non-diffusion fixture whose elevation is a
closed-form function of the global pixel coordinate.  It proves the *plumbing*:
coordinate order, quantization, wire format, publish semantics and identity
rejection.  It proves nothing whatsoever about what the real model generates, and
it must never be cited as evidence that it does.

The suite imports the module by path relative to this file, so the working
directory never matters, and disables bytecode writing before that import so a
run leaves no ``__pycache__`` in the shared checkout.
"""

import contextlib
import hashlib
import io
import json
import os
import shutil
import struct
import sys
import tempfile
import unittest
import zlib
from unittest import mock

sys.dont_write_bytecode = True

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_TOOLS_DIR = os.path.join(_REPO_ROOT, "tools")
if _TOOLS_DIR not in sys.path:
    sys.path.insert(0, _TOOLS_DIR)

import terrain_cache as tc  # noqa: E402
import terrain_backend as tb  # noqa: E402


# ---------------------------------------------------------------------------
# The fake sampler: a fixture, never a stand-in for the model
# ---------------------------------------------------------------------------


class FakeSampler:
    """A deterministic, explicitly NON-diffusion elevation field.

    ``elevation(px, pz)`` is a closed form of the global pixel coordinates, so a
    test can predict every payload byte without an inference stack.  It also
    records each request so a test can prove the row/column order and that a
    rectangle was fetched in one call rather than per chunk.

    It is a fixture.  It is not terrain, not a model, and not evidence about the
    real backend's output.
    """

    def __init__(self, failure=None):
        self.calls = []
        self.failure = failure

    @staticmethod
    def elevation(px, pz):
        # 50 m per voxel, sea level 28: elevation == px means voxel 28 + px.
        # The pz term is a small, sign-preserving offset so a transposed read is
        # detectable instead of colliding with the correct one.
        return float(px) + float(pz) * 0.5

    def get(self, i1, j1, i2, j2):
        if self.failure is not None:
            raise self.failure
        self.calls.append((i1, j1, i2, j2))
        if i2 <= i1 or j2 <= j1:
            raise AssertionError("sampler asked for an empty region")
        # i == row == z, j == column == x, matching upstream's (rows, cols).
        rows = [[self.elevation(j, i) for j in range(j1, j2)] for i in range(i1, i2)]
        return {"elev": rows}

    def close(self):
        pass


def _expected_payload(sampler, cx, cz, pixels_per_voxel, origin=(0, 0)):
    """The payload a correct backend must produce, x-fastest."""
    heights = []
    for z in range(tc.TILE_SIZE):
        pz = origin[1] + (cz * tc.TILE_SIZE + z) * pixels_per_voxel
        for x in range(tc.TILE_SIZE):
            px = origin[0] + (cx * tc.TILE_SIZE + x) * pixels_per_voxel
            heights.append(tc.quantize_height(sampler.elevation(px, pz)))
    return bytes(heights)


def _q(pixels_per_voxel=1, origin=(0, 0), window_chunks=1, max_samples=64):
    """A Query with a one-chunk window unless a test says otherwise.

    ``window_chunks=1`` makes the fetched window exactly the requested chunk, so
    assertions about the *exact* call remain sharp; the canonical-window tests
    below deliberately use a wider window.
    """
    return tb.Query(
        pixels_per_voxel=pixels_per_voxel,
        origin_pixels=origin,
        window_chunks=window_chunks,
        max_samples=max_samples,
    )


# ---------------------------------------------------------------------------
# A synthetic identity directory: no weights, no snapshot, no network
# ---------------------------------------------------------------------------


_FAKE_WEIGHT_FILES = (
    "coarse_model/diffusion_pytorch_model.safetensors",
    "base_model/diffusion_pytorch_model.safetensors",
    "decoder_model/diffusion_pytorch_model.safetensors",
)

_FAKE_CONFIG_FILES = (
    "config.json",
    "coarse_model/config.json",
    "base_model/config.json",
    "decoder_model/config.json",
)

_FAKE_CONFIG = dict(tb.EXPECTED_CONFIG)
_FAKE_CONFIG["_class_name"] = "WorldPipeline"

_FAKE_STATS = {
    "n_quantiles": 64,
    "noise_quantile_tables": [[float(i) for i in range(64)] for _ in range(5)],
    "data_quantile_tables": [[float(i) * 2.0 for i in range(64)] for _ in range(5)],
    "a_temp_std": -34.75522148,
    "b_temp_std": 1189.49646289,
    "temp_std_p1": -900.94322882,
    "temp_std_p99": 630.01483608,
}


class _TempCase(unittest.TestCase):
    """Creates an isolated cache root, snapshot directory and stats file."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="tb-test-")
        self.cache_root = os.path.join(self.tmp, "cache")
        self.snapshot = os.path.join(self.tmp, "snapshot")
        os.makedirs(self.snapshot)
        # The device lock is machine-wide by design; isolate it per case so tests
        # never contend with a real producer (or each other) on this machine.
        runtime = os.path.join(self.tmp, "runtime")
        patcher = mock.patch.dict(
            os.environ, {"TRINECRAFT_RUNTIME_DIR": runtime}
        )
        patcher.start()
        self.addCleanup(patcher.stop)
        self.stats_path = os.path.join(self.tmp, "pd.json")
        with open(os.path.join(self.snapshot, "config.json"), "w") as handle:
            json.dump(_FAKE_CONFIG, handle)
        with open(self.stats_path, "w") as handle:
            json.dump(_FAKE_STATS, handle)
        # `extract_frozen_stats` refuses anything that is not the pinned table, and
        # `_FAKE_STATS` is deliberately not it. Point the pin at the fixture's own
        # digest so the ordinary tests run the production code path rather than an
        # opt-out flag; OfficialStatsTests restores the real constant and proves the
        # official table passes while a substituted one does not.
        self.stats_pin = tb._sha256_bytes(tb.canonical_json(_FAKE_STATS))
        patcher = mock.patch.object(tb, "OFFICIAL_STATS_SHA256", self.stats_pin)
        patcher.start()
        self.addCleanup(patcher.stop)
        # Synthetic weight files plus a matching pin table: the real digests are
        # 1.1 GB of safetensors, and these tests must not depend on a download.
        # The *mechanism* under test (bytes are hashed, not merely declared) is
        # identical; only the expected digests are fixtures.
        self.weights = {}
        self.weight_pins = {}
        for relative in _FAKE_WEIGHT_FILES:
            path = os.path.join(self.snapshot, relative)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            payload = ("fixture weights: %s" % relative).encode("utf-8")
            with open(path, "wb") as handle:
                handle.write(payload)
            self.weights[relative] = payload
            self.weight_pins[relative] = {
                "sha256": hashlib.sha256(payload).hexdigest(),
                "bytes": len(payload),
            }
        self._weights_pin = mock.patch.object(
            tb, "MODEL_WEIGHTS", self.weight_pins
        )
        self._weights_pin.start()
        self.addCleanup(lambda: self._weights_pin.stop())

        # The submodel configs are equally pinned. Real ones are 609-828 bytes,
        # so the fixture writes its own and pins those; the mechanism under test
        # (a shape-neutral config edit mints a new identity) is unchanged.
        self.config_pins = {}
        for relative in _FAKE_CONFIG_FILES:
            path = os.path.join(self.snapshot, relative)
            if relative != "config.json":
                # config.json already holds _FAKE_CONFIG, which check_config
                # validates; only the submodels need synthetic bytes.
                os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
                with open(path, "wb") as handle:
                    handle.write(
                        json.dumps({"fixture": relative}, sort_keys=True).encode()
                    )
            with open(path, "rb") as handle:
                payload = handle.read()
            self.config_pins[relative] = {
                "sha256": hashlib.sha256(payload).hexdigest(),
                "bytes": len(payload),
            }
        self._configs_pin = mock.patch.object(
            tb, "MODEL_CONFIGS", self.config_pins
        )
        self._configs_pin.start()
        self.addCleanup(lambda: self._configs_pin.stop())

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def identity(self, **overrides):
        """A complete identity built from local fixtures only."""
        kwargs = {
            "seed": 1234,
            "pixels_per_voxel": 1,
            "dtype": "fp32",
            "device": "mps",
            "snapshot": self.snapshot,
            "config": tb.read_snapshot_config(self.snapshot),
            "pin": {"pin_verified_by": "source-hash",
                    "source_sha256": tb.UPSTREAM_SOURCE_SHA256},
            "stats": tb.extract_frozen_stats(self.stats_path),
            # A synthetic record: the compiled pyfastnoiselite build is a runtime
            # artifact, and these tests must not depend on it being installed.
            # Production callers omit this and get the real binary digest.
            "noise_lib": {
                "sha256": "b" * 64,
                "dist_info": False,
                "note": "test fixture, not a measured build",
            },
            "origin_pixels": (0, 0),
            "window_chunks": 1,
            "max_samples": 64,
            "decoder_geometry": (512, 384),
            # There is no opt-out: `setUp` points the pin at this fixture's own
            # digest, so every test exercises the production gate. Tests for the
            # real pin live in OfficialStatsTests and use the committed fixture.
        }
        stats_override = overrides.pop("stats", None)
        if stats_override is not None:
            kwargs["stats"] = stats_override
        kwargs.update(overrides)
        return tb.build_identity(**kwargs)

    def layout(self, **overrides):
        """A written identity directory plus its layout."""
        identity = self.identity(**overrides)
        digest, layout = tb.write_identity(
            self.cache_root, identity, stats_source=self.stats_path
        )
        # Re-open so tests exercise the manifest round trip, not a cached object.
        _, layout = tb.open_identity(self.cache_root, digest)
        return identity, layout


# ---------------------------------------------------------------------------
# Coordinate order and quantization
# ---------------------------------------------------------------------------


class CoordinateOrderTests(_TempCase):
    def test_payload_is_x_fastest(self):
        """Payload index x + 16*z holds pixel (x, z), never the transpose."""
        _, layout = self.layout()
        sampler = FakeSampler()
        heights = tb.sample_chunk(sampler, 0, 0, _q())
        self.assertEqual(bytes(heights), _expected_payload(sampler, 0, 0, 1))
        # Explicit spot checks tie the index rule to the coordinate rule.
        for (x, z) in ((0, 0), (1, 0), (0, 1), (15, 15), (5, 9)):
            expected = tc.quantize_height(FakeSampler.elevation(x, z))
            self.assertEqual(heights[x + tc.TILE_SIZE * z], expected,
                             "index %d should hold pixel (%d, %d)"
                             % (x + 16 * z, x, z))

    def test_sampler_is_asked_in_row_then_column_order(self):
        """The one fetch must be get(pz0, px0, pz1, px1)."""
        sampler = FakeSampler()
        tb.sample_chunk(sampler, 2, 3, _q())
        self.assertEqual(sampler.calls, [(48, 32, 64, 48)])

    def test_negative_chunk_coordinates_keep_their_sign(self):
        sampler = FakeSampler()
        heights = tb.sample_chunk(sampler, -3, -2, _q())
        self.assertEqual(bytes(heights), _expected_payload(sampler, -3, -2, 1))
        self.assertEqual(sampler.calls, [(-32, -48, -16, -32)])

    def test_pixels_per_voxel_scales_sampled_coordinates(self):
        sampler = FakeSampler()
        heights = tb.sample_chunk(sampler, -1, 2, _q(pixels_per_voxel=4))
        self.assertEqual(bytes(heights), _expected_payload(sampler, -1, 2, 4))
        # Chunk (-1, 2) at 4 px/voxel: px spans [-64, 0), pz spans [128, 192).
        self.assertEqual(sampler.calls, [(128, -64, 192, 0)])

    def test_quantize_uses_the_shared_global_transfer(self):
        """Zero metres is sea level 28 and the band is clamped, world-wide."""
        self.assertEqual(tc.quantize_height(0.0), 28)
        self.assertEqual(tc.quantize_height(-1e6), tc.HEIGHT_MIN)
        self.assertEqual(tc.quantize_height(1e6), tc.HEIGHT_MAX)


class CanonicalWindowTests(_TempCase):
    """The window depends on the macrotile index alone, never on the request."""

    def test_chunk_baked_alone_equals_chunk_baked_in_a_rectangle(self):
        """Grouping must not change a single payload byte."""
        alone = tb.sample_chunks(FakeSampler(), 1, 1, 2, 2, _q(window_chunks=4))
        group = tb.sample_chunks(FakeSampler(), -1, -1, 4, 4, _q(window_chunks=4))
        self.assertEqual(alone[(1, 1)], group[(1, 1)])

    def test_isolated_batched_and_reordered_requests_send_identical_windows(self):
        """The three shapes a real spawn produces must query the same pixels.

        This is the regression test for the MPS watchdog: a request-anchored
        window sends the model a different rectangle for the same chunk
        depending on what else was in the batch.
        """
        query = _q(window_chunks=4)
        alone = FakeSampler()
        tb.sample_chunks(alone, 1, 1, 2, 2, query)

        batched = FakeSampler()
        tb.sample_chunks(batched, -1, -1, 4, 4, query)

        # The same five chunks, supplied one at a time in a different order.
        reordered = FakeSampler()
        for cx, cz in ((3, 3), (0, 0), (2, 1), (-1, 3), (1, 1)):
            tb.sample_chunks(reordered, cx, cz, cx + 1, cz + 1, query)

        # The invariant that matters: the window CONTAINING a given chunk is the
        # same no matter how that chunk was requested. An isolated chunk needs one
        # window and a 5x5 batch needs four, so the full call lists legitimately
        # differ -- comparing those would test the batch size, not the contract.
        window_of_chunk = (0, 0, 64, 64)  # canonical window holding chunk (1, 1)
        for name, sampler in (("alone", alone), ("batched", batched),
                              ("reordered", reordered)):
            self.assertIn(
                window_of_chunk, sampler.calls,
                "%s never fetched the canonical window for chunk (1,1): %r"
                % (name, sampler.calls),
            )

        # A permuted batch must still produce the identical call list.
        permuted = FakeSampler()
        for cx, cz in ((3, 3), (2, 1), (0, 0), (-1, 3), (1, 1)):
            tb.sample_chunks(permuted, cx, cz, cx + 1, cz + 1, query)
        self.assertEqual(sorted(permuted.calls), sorted(reordered.calls))

        # And the isolated fetch is exactly that one canonical window.
        self.assertEqual(alone.calls, [window_of_chunk])

    def test_wide_window_fetches_the_full_window_for_one_chunk(self):
        """A lone chunk still pays for the whole canonical window, on purpose."""
        sampler = FakeSampler()
        tb.sample_chunks(sampler, 1, 1, 2, 2, _q(window_chunks=4))
        # Window anchor for chunk 1 is 0; the window spans 4 chunks = 64 px.
        self.assertEqual(sampler.calls, [(0, 0, 64, 64)])

    def test_negative_chunks_anchor_to_the_global_grid(self):
        """-1 and 0 share window -4; -5 anchors at -8."""
        query = _q(window_chunks=4)
        self.assertEqual(query.anchor(-1), -4)
        self.assertEqual(query.anchor(0), 0)
        self.assertEqual(query.anchor(-5), -8)
        self.assertEqual(query.anchor(-4), -4)
        self.assertEqual(query.anchor(3), 0)
        self.assertEqual(query.anchor(4), 4)

    def test_one_window_is_emitted_once_for_a_scattered_batch(self):
        """Many requested chunks inside one window cost exactly one fetch."""
        sampler = FakeSampler()
        tb.sample_chunks(sampler, 0, 0, 4, 4, _q(window_chunks=4))
        self.assertEqual(len(sampler.calls), 1)
        self.assertEqual(sampler.calls[0], (0, 0, 64, 64))

    def test_windows_for_deduplicates_and_orders_deterministically(self):
        query = _q(window_chunks=4)
        anchors = tb.windows_for(-1, -1, 2, 2, query)
        self.assertEqual(anchors, [(-4, -4), (0, -4), (-4, 0), (0, 0)])

    def test_baked_tiles_match_the_pure_column_rule(self):
        """Publishing through the whole pipeline keeps every byte honest."""
        identity, layout = self.layout()
        sampler = FakeSampler()
        paths = tb.bake_chunks(layout, sampler, cx0=-2, cz0=-1, cx1=1, cz1=1,
                               query=_q())
        self.assertEqual(len(paths), 6)
        for cx in (-2, -1, 0):
            for cz in (-1, 0):
                _, _, payload = tc.read_tile(self.cache_root, layout.digest, cx, cz)
                self.assertEqual(payload, _expected_payload(sampler, cx, cz, 1))


class OriginTests(_TempCase):
    """The world origin shifts every sampled pixel and is part of the identity."""

    def test_origin_shifts_every_sampled_pixel(self):
        sampler = FakeSampler()
        query = _q(origin=(100000, 100000))
        heights = tb.sample_chunk(sampler, 0, 0, query)
        self.assertEqual(
            bytes(heights), _expected_payload(sampler, 0, 0, 1, origin=(100000, 100000))
        )
        # The window for chunk 0 starts exactly at the origin.
        self.assertEqual(sampler.calls, [(100000, 100000, 100016, 100016)])

    def test_origin_shifts_negative_chunks_too(self):
        query = _q(origin=(100000, 100000))
        sampler = FakeSampler()
        heights = tb.sample_chunk(sampler, -1, -1, query)
        self.assertEqual(
            bytes(heights),
            _expected_payload(sampler, -1, -1, 1, origin=(100000, 100000)),
        )

    def test_origin_changes_the_identity_digest(self):
        base = tc.identity_digest(self.identity())
        shifted = tc.identity_digest(self.identity(origin_pixels=(100000, 100000)))
        self.assertNotEqual(base, shifted)
        self.assertNotEqual(
            shifted,
            tc.identity_digest(self.identity(origin_pixels=(0, 100000))),
        )

    def test_origin_is_rejected_when_not_two_integers(self):
        for origin in ((1,), (1, 2, 3), (0.5, 0), ("0", 0), (True, 0)):
            with self.assertRaises(tb.BackendError):
                self.identity(origin_pixels=origin)

    def test_origin_zero_is_the_default_and_is_pinned_explicitly(self):
        identity = self.identity()
        self.assertEqual(identity["query"]["origin_pixels"], [0, 0])
        self.assertEqual(tb.Query.from_identity(identity).origin_pixels, (0, 0))

    def test_query_round_trips_through_the_identity(self):
        identity = self.identity(
            origin_pixels=(100000, 100000), window_chunks=8, max_samples=128
        )
        query = tb.Query.from_identity(identity)
        self.assertEqual(query.origin_pixels, (100000, 100000))
        self.assertEqual(query.window_chunks, 8)
        self.assertEqual(query.max_samples, 128)
        self.assertEqual(query.window_pixels, 8 * 16 * 1)


class QueryGeometryTests(_TempCase):
    """An over-large or mismatched window fails closed, never clamps silently."""

    def test_window_larger_than_max_samples_is_rejected_with_advice(self):
        with self.assertRaises(tb.BackendError) as caught:
            _q(window_chunks=4, max_samples=32)
        message = str(caught.exception)
        self.assertIn("64", message)
        self.assertIn("--max-samples", message)

    def test_exact_fit_is_accepted(self):
        query = _q(window_chunks=4, max_samples=64)
        self.assertEqual(query.window_pixels, 64)

    def test_window_pixels_scale_with_pixels_per_voxel(self):
        self.assertEqual(_q(pixels_per_voxel=4, window_chunks=1).window_pixels, 64)
        with self.assertRaises(tb.BackendError):
            _q(pixels_per_voxel=4, window_chunks=4, max_samples=64)

    def test_query_geometry_is_hashed(self):
        """A different window is a different trail; caches cannot be mixed."""
        base = tc.identity_digest(self.identity())
        for overrides in (
            {"window_chunks": 8, "max_samples": 128},
            {"max_samples": 128},
        ):
            self.assertNotEqual(
                base, tc.identity_digest(self.identity(**overrides)),
                "%r must change the identity digest" % (overrides,),
            )

    def test_query_strategy_is_pinned_and_checked(self):
        identity = self.identity()
        self.assertEqual(identity["query"]["strategy"], tb.QUERY_STRATEGY)
        tampered = json.loads(json.dumps(identity))
        tampered["query"]["strategy"] = "request-anchored-v0"
        with self.assertRaises(tb.BackendError) as caught:
            tb.Query.from_identity(tampered)
        self.assertIn("strategy", str(caught.exception))

    def test_identity_without_query_geometry_is_refused(self):
        identity = self.identity()
        del identity["query"]
        with self.assertRaises(tb.BackendError):
            tb.Query.from_identity(identity)

    def test_pixels_per_voxel_disagreement_is_refused(self):
        identity = self.identity()
        identity["query"]["pixels_per_voxel"] = 4
        with self.assertRaises(tb.BackendError):
            tb.Query.from_identity(identity)

    def test_decoder_geometry_is_pinned_and_restricted(self):
        default = self.identity()["sampler"]
        self.assertEqual((default["decoder_window"], default["decoder_stride"]),
                         (512, 384))
        alternate = self.identity(decoder_geometry=(256, 192))["sampler"]
        self.assertEqual((alternate["decoder_window"], alternate["decoder_stride"]),
                         (256, 192))
        self.assertNotEqual(tc.identity_digest(self.identity()),
                            tc.identity_digest(self.identity(
                                decoder_geometry=(256, 192))))
        with self.assertRaises(tb.BackendError):
            self.identity(decoder_geometry=(128, 96))


# ---------------------------------------------------------------------------
# Wire format
# ---------------------------------------------------------------------------


class WireFormatTests(_TempCase):
    def test_tile_is_308_bytes_with_a_verifiable_header(self):
        identity, layout = self.layout()
        tb.bake_chunks(layout, FakeSampler(), cx0=0, cz0=0, cx1=1, cz1=1,
                       query=_q())
        path = layout.tile_path(0, 0)
        with open(path, "rb") as handle:
            raw = handle.read()
        self.assertEqual(len(raw), tc.TILE_BYTES)
        self.assertEqual(len(raw), 308)

        magic, cx, cz, length, crc, sha = tc.HEADER_STRUCT.unpack(raw[:52])
        payload = raw[52:]
        self.assertEqual(magic, b"TDH2")
        self.assertEqual((cx, cz), (0, 0))
        self.assertEqual(length, 256)
        self.assertEqual(len(payload), 256)
        self.assertEqual(crc, zlib.crc32(payload) & 0xFFFFFFFF)
        import hashlib

        self.assertEqual(sha, hashlib.sha256(payload).digest())
        self.assertTrue(all(tc.HEIGHT_MIN <= value <= tc.HEIGHT_MAX
                            for value in payload))

    def test_header_coordinates_are_signed(self):
        _, layout = self.layout()
        tb.bake_chunks(layout, FakeSampler(), cx0=-4, cz0=-7, cx1=-3, cz1=-6,
                       query=_q())
        with open(layout.tile_path(-4, -7), "rb") as handle:
            raw = handle.read()
        _, cx, cz, _, _, _ = tc.HEADER_STRUCT.unpack(raw[:52])
        self.assertEqual((cx, cz), (-4, -7))

    def test_a_tampered_tile_is_rejected(self):
        _, layout = self.layout()
        tb.bake_chunks(layout, FakeSampler(), cx0=0, cz0=0, cx1=1, cz1=1,
                       query=_q())
        path = layout.tile_path(0, 0)
        with open(path, "rb") as handle:
            raw = bytearray(handle.read())
        raw[-1] = (raw[-1] + 1) % 256
        with open(path, "wb") as handle:
            handle.write(bytes(raw))
        with self.assertRaises(tc.TileCorruptError):
            tc.read_tile(self.cache_root, layout.digest, 0, 0)


# ---------------------------------------------------------------------------
# Manifest bridge
# ---------------------------------------------------------------------------


class ManifestBridgeTests(_TempCase):
    def test_janet_bridge_is_byte_exact(self):
        identity, layout = self.layout()
        path = os.path.join(layout.root, tb.MANIFEST_JANET_NAME)
        with open(path, "rb") as handle:
            text = handle.read().decode("ascii")
        expected = (
            '{:format 2 :magic "TDH2" :identity "%s" :seed %d '
            ":payload-bytes 256 :tile-bytes 308}\n"
            % (layout.digest, identity["seed"])
        )
        self.assertEqual(text, expected)
        self.assertEqual(len(layout.digest), 64)
        self.assertTrue(all(c in "0123456789abcdef" for c in layout.digest))
        self.assertLess(len(text), 4096)

    def test_python_manifest_agrees_with_the_cache_module(self):
        identity, layout = self.layout()
        record = tc.read_manifest(self.cache_root, layout.digest)
        self.assertEqual(record["identity_digest"], layout.digest)
        self.assertEqual(record["tile_bytes"], tc.TILE_BYTES)
        self.assertEqual(record["payload_bytes"], tc.TILE_PAYLOAD_SIZE)
        self.assertEqual(record["identity"], tc.identity_descriptor(identity))

    def test_bridge_seed_matches_the_identity_seed(self):
        identity, layout = self.layout(seed=99)
        with open(os.path.join(layout.root, tb.MANIFEST_JANET_NAME)) as handle:
            text = handle.read()
        self.assertIn(":seed 99 ", text)
        self.assertEqual(identity["seed"], 99)

    def test_identity_record_round_trips(self):
        identity, layout = self.layout()
        with open(os.path.join(layout.root, tb.IDENTITY_RECORD)) as handle:
            record = json.load(handle)
        self.assertEqual(record["identity_digest"], layout.digest)
        self.assertEqual(record["identity"], identity)

    def test_stats_copy_is_the_canonical_subset(self):
        identity, layout = self.layout()
        with open(layout.stats_path()) as handle:
            written = json.load(handle)
        self.assertEqual(written, tb.extract_frozen_stats(self.stats_path))
        self.assertEqual(sorted(written), sorted(tb.STATS_KEYS))


# ---------------------------------------------------------------------------
# Request and error semantics
# ---------------------------------------------------------------------------


class RequestTests(_TempCase):
    def test_request_marker_is_an_empty_file_named_by_coordinate(self):
        _, layout = self.layout()
        self.assertEqual(tb.write_request(layout, -3, 12), "requested")
        path = layout.request_path(-3, 12)
        self.assertTrue(os.path.exists(path))
        self.assertEqual(os.path.getsize(path), 0)
        self.assertEqual(os.path.basename(path), "-3_12.req")

    def test_repeat_request_is_idempotent(self):
        _, layout = self.layout()
        self.assertEqual(tb.write_request(layout, 1, 1), "requested")
        self.assertEqual(tb.write_request(layout, 1, 1), "queued")
        self.assertEqual(tb.read_requests(layout), [(1, 1)])

    def test_request_is_suppressed_by_a_tile(self):
        _, layout = self.layout()
        tb.bake_chunks(layout, FakeSampler(), cx0=0, cz0=0, cx1=1, cz1=1,
                       query=_q())
        self.assertEqual(tb.write_request(layout, 0, 0), "ready")
        self.assertFalse(os.path.exists(layout.request_path(0, 0)))

    def test_request_is_suppressed_by_a_terminal_error(self):
        _, layout = self.layout()
        tb.mark_error(layout, 5, 5, "boom")
        self.assertEqual(tb.write_request(layout, 5, 5), "suppressed")

    def test_read_requests_ignores_foreign_and_partial_names(self):
        _, layout = self.layout()
        tb.write_request(layout, 2, 4)
        requests = os.path.join(layout.root, tb.REQUESTS_DIR_NAME)
        for name in ("notes.txt", ".hidden.req", "junk.req", "1.req"):
            with open(os.path.join(requests, name), "w") as handle:
                handle.write("x")
        self.assertEqual(tb.read_requests(layout), [(2, 4)])

    def test_worker_deletes_a_marker_only_after_the_tile_exists(self):
        identity, layout = self.layout()
        tb.write_request(layout, 0, 0)
        summary = tb.run_worker(
            layout,
            stop_after=1,
            idle_sleep=0.0,
            sampler_factory=lambda _identity, _layout: FakeSampler(),
        )
        self.assertEqual(summary["tiles"], 1)
        self.assertTrue(layout.has_tile(0, 0))
        self.assertFalse(os.path.exists(layout.request_path(0, 0)))
        self.assertEqual(tb.pending_state(layout, 0, 0), "ready")

    def test_worker_is_serial_and_reuses_one_sampler(self):
        _, layout = self.layout()
        for coord in ((0, 0), (0, 1), (1, 0)):
            tb.write_request(layout, *coord)
        built = []

        def factory(_identity, _layout):
            sampler = FakeSampler()
            built.append(sampler)
            return sampler

        summary = tb.run_worker(layout, stop_after=1, idle_sleep=0.0,
                                sampler_factory=factory)
        self.assertEqual(len(built), 1)
        self.assertEqual(summary["tiles"], 3)
        for coord in ((0, 0), (0, 1), (1, 0)):
            self.assertTrue(layout.has_tile(*coord))


class TerminalErrorTests(_TempCase):
    def test_mark_error_is_terminal_and_never_overwritten(self):
        _, layout = self.layout()
        path = tb.mark_error(layout, 1, 2, "first")
        with open(path) as handle:
            self.assertEqual(handle.read(), "first")
        with self.assertRaises(tb.BackendError):
            tb.mark_error(layout, 1, 2, "second")
        with open(path) as handle:
            self.assertEqual(handle.read(), "first")

    def test_publishing_refuses_to_shadow_a_tile_or_an_error(self):
        identity, layout = self.layout()
        heights = [28] * tc.TILE_PAYLOAD_SIZE
        tb.publish_tile(layout, 0, 0, heights)
        with self.assertRaises(tb.BackendError):
            tb.publish_tile(layout, 0, 0, heights)
        tb.mark_error(layout, 1, 1, "boom")
        with self.assertRaises(tb.BackendError):
            tb.publish_tile(layout, 1, 1, heights)

    def test_bake_refuses_a_rectangle_containing_a_terminal_error(self):
        _, layout = self.layout()
        tb.mark_error(layout, 1, 0, "boom")
        with self.assertRaises(tb.BackendError):
            tb.bake_chunks(layout, FakeSampler(), cx0=0, cz0=0, cx1=2, cz1=1,
                           query=_q())
        # The healthy neighbour in the same rectangle must NOT have been written.
        self.assertFalse(layout.has_tile(0, 0))

    def test_bake_skips_completed_tiles(self):
        _, layout = self.layout()
        first = tb.bake_chunks(layout, FakeSampler(), cx0=0, cz0=0, cx1=1, cz1=1,
                               query=_q())
        self.assertEqual(len(first), 1)
        again = tb.bake_chunks(layout, FakeSampler(), cx0=0, cz0=0, cx1=1, cz1=1,
                               query=_q())
        self.assertEqual(again, [])

    def test_worker_marks_a_failure_terminal_and_does_not_retry(self):
        _, layout = self.layout()
        tb.write_request(layout, 0, 0)
        calls = []

        def factory(_identity, _layout):
            calls.append(1)

            class Boom(FakeSampler):
                def get(self, i1, j1, i2, j2):
                    raise RuntimeError("inference exploded")

            return Boom()

        summary = tb.run_worker(layout, stop_after=3, idle_sleep=0.0,
                                sampler_factory=factory)
        self.assertEqual(summary["errors"], 1)
        self.assertEqual(len(calls), 1)
        self.assertTrue(layout.has_error(0, 0))
        self.assertFalse(layout.has_tile(0, 0))
        self.assertFalse(os.path.exists(layout.request_path(0, 0)))
        with open(layout.error_path(0, 0)) as handle:
            self.assertIn("inference exploded", handle.read())


# ---------------------------------------------------------------------------
# Identity rejection
# ---------------------------------------------------------------------------


class IdentityRejectionTests(_TempCase):
    def test_seed_zero_is_refused(self):
        with self.assertRaises(tb.BackendError) as caught:
            self.identity(seed=0)
        self.assertIn("seed 0", str(caught.exception))

    def test_negative_and_oversized_seeds_are_refused(self):
        for seed in (-1, 2 ** 64):
            with self.assertRaises(tb.BackendError):
                self.identity(seed=seed)

    def test_non_pinned_pixels_per_voxel_is_refused(self):
        for value in (0, 3, 5, 16, -1):
            with self.assertRaises(tb.BackendError):
                self.identity(pixels_per_voxel=value)

    def test_unknown_dtype_and_device_are_refused(self):
        with self.assertRaises(tb.BackendError):
            self.identity(dtype="float64")
        with self.assertRaises(tb.BackendError):
            self.identity(device="tpu")

    def test_missing_snapshot_is_refused(self):
        with self.assertRaises(tb.BackendError):
            self.identity(snapshot=os.path.join(self.tmp, "nope"))

    def test_config_mismatch_is_refused(self):
        config = tb.read_snapshot_config(self.snapshot)
        config["native_resolution"] = 90
        with self.assertRaises(tb.BackendError) as caught:
            self.identity(config=config)
        self.assertIn("native_resolution", str(caught.exception))

    def test_config_frequency_mult_change_is_refused(self):
        """The 56143fe -> 9ef8030 change is config-only and still a new world."""
        config = tb.read_snapshot_config(self.snapshot)
        config["frequency_mult"] = [2.0] * 5
        with self.assertRaises(tb.BackendError):
            self.identity(config=config)

    def test_missing_config_field_is_refused(self):
        config = tb.read_snapshot_config(self.snapshot)
        del config["cond_snr"]
        with self.assertRaises(tb.BackendError) as caught:
            self.identity(config=config)
        self.assertIn("cond_snr", str(caught.exception))

    def test_source_hash_mismatch_is_refused(self):
        with self.assertRaises(tb.BackendError) as caught:
            self.identity(pin={"pin_verified_by": "source-hash",
                               "source_sha256": "0" * 64})
        self.assertIn("source digest", str(caught.exception))

    def test_tampered_stats_are_refused(self):
        stats = tb.extract_frozen_stats(self.stats_path)
        stats["n_quantiles"] = 32
        with self.assertRaises(tb.BackendError):
            self.identity(stats=stats)

    def test_partial_stats_fail_closed(self):
        for key in tb.STATS_KEYS:
            stats = tb.extract_frozen_stats(self.stats_path)
            del stats[key]
            with self.assertRaises(tb.BackendError):
                tb.extract_frozen_stats(stats)

    def test_short_quantile_table_fails_closed(self):
        stats = tb.extract_frozen_stats(self.stats_path)
        stats["noise_quantile_tables"][2] = stats["noise_quantile_tables"][2][:8]
        with self.assertRaises(tb.BackendError):
            tb.extract_frozen_stats(stats)

    def test_it_is_not_seed_zero_only_because_stats_are_checked(self):
        """A valid identity still hashes stable, so rejections are real."""
        first = tc.identity_digest(self.identity())
        second = tc.identity_digest(self.identity())
        self.assertEqual(first, second)
        self.assertNotEqual(first, tc.identity_digest(self.identity(seed=1235)))
        self.assertNotEqual(first, tc.identity_digest(self.identity(pixels_per_voxel=4)))
        self.assertNotEqual(first, tc.identity_digest(self.identity(device="cpu")))
        self.assertNotEqual(first, tc.identity_digest(self.identity(dtype="fp16")))

    def test_stats_digest_is_stable_and_ignores_extra_keys(self):
        base = self.identity()["stats_sha256"]
        stats = tb.extract_frozen_stats(self.stats_path)
        stats["extra_bookkeeping"] = "ignored"
        self.assertEqual(self.identity(stats=stats)["stats_sha256"], base)


# ---------------------------------------------------------------------------
# Sampler contract and CLI surface
# ---------------------------------------------------------------------------


class SamplerContractTests(_TempCase):
    def test_wrong_shape_is_rejected_rather_than_silently_reshaped(self):
        _, layout = self.layout()

        class Transposed(FakeSampler):
            def get(self, i1, j1, i2, j2):
                return {"elev": [[0.0] * 8 for _ in range(8)]}

        with self.assertRaises(tb.BackendError):
            tb.sample_chunk(Transposed(), 0, 0, _q())

    def test_numeric_scalars_are_coerced_but_bools_and_junk_are_not(self):
        """A numpy/torch scalar quantizes; a bool or a non-number never becomes terrain."""

        class _Scalar:
            """Mimics a numpy/torch scalar: float()-able, not an int/float."""

            def __init__(self, value):
                self._value = value

            def __float__(self):
                return self._value

        class ScalarSampler(FakeSampler):
            def get(self, i1, j1, i2, j2):
                return {"elev": [
                    [_Scalar(self.elevation(j, i)) for j in range(j1, j2)]
                    for i in range(i1, i2)
                ]}

        heights = tb.sample_chunk(ScalarSampler(), 0, 0, _q())
        self.assertEqual(bytes(heights), _expected_payload(FakeSampler(), 0, 0, 1))

        class BoolSampler(FakeSampler):
            def get(self, i1, j1, i2, j2):
                return {"elev": [[True for _ in range(j1, j2)] for _ in range(i1, i2)]}

        with self.assertRaises(tb.BackendError):
            tb.sample_chunk(BoolSampler(), 0, 0, _q())

        class JunkSampler(FakeSampler):
            def get(self, i1, j1, i2, j2):
                return {"elev": [["high" for _ in range(j1, j2)] for _ in range(i1, i2)]}

        with self.assertRaises(tb.BackendError):
            tb.sample_chunk(JunkSampler(), 0, 0, _q())

    def test_missing_elevation_is_rejected(self):
        class Empty(FakeSampler):
            def get(self, i1, j1, i2, j2):
                return {}

        with self.assertRaises(tb.BackendError):
            tb.sample_chunk(Empty(), 0, 0, _q())

    def test_empty_rectangle_is_rejected(self):
        with self.assertRaises(tb.BackendError):
            tb.sample_chunks(FakeSampler(), 0, 0, 0, 1, _q())
        with self.assertRaises(tb.BackendError):
            tb.bake_chunks(self.layout()[1], FakeSampler(), cx0=0, cz0=0, cx1=0,
                           cz1=1, query=_q())

    def test_tile_cannot_be_published_without_a_manifest(self):
        identity = self.identity()
        digest = tc.identity_digest(identity)
        orphan = tb.Layout.open(self.cache_root, digest)
        with self.assertRaises(tb.BackendError):
            tb.bake_chunks(orphan, FakeSampler(), cx0=0, cz0=0, cx1=1, cz1=1,
                           query=_q())


class PipelineSamplerFlagTests(unittest.TestCase):
    """`PipelineSampler` forwards `with_climate`; it does not pin it.

    The flag is a pass-through, so the only thing worth asserting is what the
    wrapped pipeline was actually asked -- a stub that merely tolerates the
    keyword would pass even if the adapter dropped it.
    """

    class _Strict:
        """Accepts ONLY the exact flag it was told to expect."""

        def __init__(self, expected):
            self.expected = expected
            self.seen = []

        def get(self, i1, j1, i2, j2, with_climate=False):
            if with_climate is not self.expected:
                raise AssertionError(
                    "adapter passed with_climate=%r, expected %r"
                    % (with_climate, self.expected)
                )
            self.seen.append((i1, j1, i2, j2))
            return {"elev": [[0.0]], "climate": None}

        def close(self):
            pass

    def test_default_is_false_so_the_chunk_cache_pays_nothing_new(self):
        strict = self._Strict(False)
        tb.PipelineSampler(strict).get(0, 0, 1, 1)
        self.assertEqual(strict.seen, [(0, 0, 1, 1)])

    def test_true_reaches_the_underlying_pipeline(self):
        strict = self._Strict(True)
        result = tb.PipelineSampler(strict).get(4, 5, 6, 7, with_climate=True)
        self.assertEqual(strict.seen, [(4, 5, 6, 7)])
        self.assertIsNone(result["climate"])

    def test_flag_is_forwarded_by_keyword_even_when_false(self):
        """An explicit `with_climate=False` must not be swallowed either."""
        strict = self._Strict(False)
        tb.PipelineSampler(strict).get(0, 0, 2, 2, with_climate=False)
        self.assertEqual(strict.seen, [(0, 0, 2, 2)])


class WeightPinTests(_TempCase):
    """Byte-different weights must never share a cache identity."""

    def test_weight_bytes_are_hashed_into_the_identity(self):
        base = tc.identity_digest(self.identity())
        path = os.path.join(
            self.snapshot, "coarse_model/diffusion_pytorch_model.safetensors"
        )
        with open(path, "wb") as handle:
            handle.write(b"different weights entirely")
        self.weight_pins["coarse_model/diffusion_pytorch_model.safetensors"] = {
            "sha256": hashlib.sha256(b"different weights entirely").hexdigest(),
            "bytes": len(b"different weights entirely"),
        }
        self.assertNotEqual(
            base, tc.identity_digest(self.identity()),
            "a different weight file produced the SAME identity digest",
        )

    def test_identity_carries_the_weights_digest(self):
        self.assertIn("weights_sha256", self.identity())

    def test_foreign_weights_are_refused(self):
        """A snapshot whose bytes do not match the pin is rejected, not relabelled."""
        real_pin = {
            "coarse_model/diffusion_pytorch_model.safetensors": {
                "sha256": "f88cdc26c70a2c73ee4c91088b8cec3f45202fc452682ac759554b099c5c2f33",
                "bytes": 11200936,
            }
        }
        with self.assertRaises(tb.BackendError) as caught:
            tb.verify_weights(self.snapshot, expected=real_pin)
        self.assertIn("bytes", str(caught.exception))

    def test_short_weight_file_fails_before_hashing(self):
        path = os.path.join(
            self.snapshot, "base_model/diffusion_pytorch_model.safetensors"
        )
        with open(path, "wb") as handle:
            handle.write(b"truncated")
        with self.assertRaises(tb.BackendError) as caught:
            tb.verify_weights(self.snapshot)
        self.assertIn("bytes", str(caught.exception))


class SubmodelConfigTests(_TempCase):
    """A shape-neutral config edit must mint a new identity, not share a cache.

    `concat_balance`, `fourier_scale` and `disable_out_gain` are read by
    `diffusers.from_pretrained` and change the output without changing any tensor
    shape, so a weights-only check cannot see them. Review 330 reproduced exactly
    this: two worlds, one identity digest.
    """

    def _mutate_submodel_config(self, relative, payload):
        path = os.path.join(self.snapshot, relative)
        with open(path, "wb") as handle:
            handle.write(payload)
        self.config_pins[relative] = {
            "sha256": hashlib.sha256(payload).hexdigest(),
            "bytes": len(payload),
        }

    def test_submodel_config_is_hashed_into_the_identity(self):
        base = tc.identity_digest(self.identity())
        self._mutate_submodel_config(
            "base_model/config.json", b'{"concat_balance": 0.9}'
        )
        self.assertNotEqual(
            base, tc.identity_digest(self.identity()),
            "a shape-neutral submodel config edit produced the SAME identity",
        )

    def test_identity_carries_the_configs_digest(self):
        identity = self.identity()
        self.assertIn("configs_sha256", identity)

    def test_weights_and_configs_are_verified_together(self):
        """One call returns both blocks, so neither can be checked alone."""
        block = tb.verify_snapshot(self.snapshot)
        self.assertIn("weights_sha256", block)
        self.assertIn("configs_sha256", block)

    def test_a_config_change_alone_changes_the_configs_digest(self):
        before = tb.verify_configs(self.snapshot)["configs_sha256"]
        self._mutate_submodel_config(
            "decoder_model/config.json", b'{"disable_out_gain": true}'
        )
        after = tb.verify_configs(self.snapshot)["configs_sha256"]
        self.assertNotEqual(before, after)
        # Weights are untouched, which is precisely why they alone were not enough.
        self.assertEqual(
            tb.verify_weights(self.snapshot)["weights_sha256"],
            tb.verify_weights(self.snapshot)["weights_sha256"],
        )

    def test_real_pins_reject_a_foreign_snapshot(self):
        real = {
            "base_model/config.json": {
                "sha256": "2400da3c7bed5dbc331a0cfabd3f4a5a3c5c977d4c4b3fb1037f4e285d320598",
                "bytes": 682,
            }
        }
        with self.assertRaises(tb.BackendError):
            tb.verify_configs(self.snapshot, expected=real)

    def test_an_empty_pin_table_verifies_nothing_and_is_refused(self):
        """An empty table would hash to a constant and admit any snapshot."""
        # None means "use the module pins", which is the correct default and is
        # covered by every other test here. Empty containers mean "verify
        # nothing", which is the failure.
        for pins in ({}, []):
            with self.assertRaises(tb.BackendError) as caught:
                tb.verify_configs(self.snapshot, expected=pins)
            self.assertIn("pin table", str(caught.exception))
            with self.assertRaises(tb.BackendError):
                tb.verify_weights(self.snapshot, expected=pins)
        # And None really does fall back to the pinned tables.
        self.assertIn("configs_sha256",
                      tb.verify_configs(self.snapshot, expected=None))

    def test_a_caller_cannot_weaken_the_pins_through_build_identity(self):
        """Passing an empty table must not produce a pin-free identity."""
        identity = self.identity()
        with self.assertRaises(tb.BackendError):
            tb.build_identity(
                seed=1234, pixels_per_voxel=1, dtype="fp32", device="mps",
                snapshot=self.snapshot,
                config=tb.read_snapshot_config(self.snapshot),
                pin={"pin_verified_by": "source-hash",
                     "source_sha256": tb.UPSTREAM_SOURCE_SHA256},
                stats=tb.extract_frozen_stats(self.stats_path),
                noise_lib={"sha256": "b" * 64, "dist_info": False,
                           "note": "test fixture, not a measured build"},
                origin_pixels=(0, 0), window_chunks=1, max_samples=64,
                decoder_geometry=(512, 384),
                configs={}, weights={},
            )
        # And the ordinary path still records real digests, not constants.
        self.assertNotEqual(identity["configs_sha256"], "0" * 64)
        self.assertIn("configs_sha256", identity)

    def test_missing_submodel_config_is_refused(self):
        os.unlink(os.path.join(self.snapshot, "coarse_model/config.json"))
        with self.assertRaises(tb.BackendError) as caught:
            tb.verify_configs(self.snapshot)
        self.assertIn("coarse_model/config.json", str(caught.exception))

    def _mutate_keeping_pins(self, relative, old, new):
        """Rewrite config bytes WITHOUT updating the pin table.

        Every other test here mutates the pins along with the file, which proves
        only that `configs_sha256` tracks content. It cannot prove rejection: the
        mutation is pre-approved. This helper keeps the pinned digests fixed, so
        the pin has to actually fail. Same byte length on purpose, so the size
        check cannot be what catches it.
        """
        path = os.path.join(self.snapshot, relative)
        with open(path, "rb") as handle:
            payload = handle.read()
        self.assertIn(old, payload)
        mutated = payload.replace(old, new)
        self.assertEqual(len(mutated), len(payload))
        with open(path, "wb") as handle:
            handle.write(mutated)
        return mutated

    def test_same_size_config_mutation_is_rejected_by_the_pin(self):
        """The reproduced P1: numerics change, shapes and sizes do not."""
        # The fixture submodel payload is `{"fixture": "<path>"}`; flipping one
        # character keeps the length identical.
        self._mutate_keeping_pins(
            "base_model/config.json", b'"fixture"', b'"fixturE"'
        )
        with self.assertRaises(tb.BackendError) as caught:
            tb.build_identity(
                seed=1234, pixels_per_voxel=1, dtype="fp32", device="mps",
                snapshot=self.snapshot,
                config=tb.read_snapshot_config(self.snapshot),
                pin={"pin_verified_by": "source-hash",
                     "source_sha256": tb.UPSTREAM_SOURCE_SHA256},
                stats=tb.extract_frozen_stats(self.stats_path),
                noise_lib={"sha256": "b" * 64, "dist_info": False,
                           "note": "test fixture, not a measured build"},
                origin_pixels=(0, 0), window_chunks=1, max_samples=64,
                decoder_geometry=(512, 384),
            )
        self.assertIn("base_model/config.json", str(caught.exception))

    def test_build_identity_records_the_configs_digest(self):
        identity = self.identity()
        self.assertEqual(
            identity["configs_sha256"],
            tb.verify_configs(self.snapshot)["configs_sha256"],
        )

    def test_loader_refuses_a_config_mutation_before_importing_torch(self):
        """`load_sampler` re-checks the pin, and does so before any model import.

        Ordering is the point: a refusal that arrives after `import torch` has
        already cost the load, and on MPS has already touched the GPU.
        """
        self.assertNotIn("torch", sys.modules)
        # Build the identity BEFORE mutating. Calling self.identity() after the
        # mutation raises inside build_identity, so load_sampler is never
        # reached and the test would assert nothing about the loader.
        identity, layout = self.layout()
        self._mutate_keeping_pins(
            "decoder_model/config.json", b'"fixture"',
            b'"fixturE"',
        )
        with self.assertRaises(tb.BackendError) as caught:
            tb.load_sampler(identity, layout)
        self.assertIn("config", str(caught.exception))
        self.assertNotIn("torch", sys.modules,
                         "load_sampler imported torch before refusing the pin")


class WorkerFaultTests(_TempCase):
    """A failing pipeline load must be reported, never raised out of the loop."""

    def test_sampler_factory_failure_is_terminal_not_a_raise(self):
        _, layout = self.layout()
        tb.write_request(layout, 0, 0)
        tb.write_request(layout, 1, 1)

        def raiser(_identity, _layout):
            raise tb.BackendError("MPS unavailable")

        summary = tb.run_worker(layout, stop_after=1, idle_sleep=0.0,
                                sampler_factory=raiser)
        self.assertEqual(summary["stopped"], "load-failed")
        self.assertEqual(summary["errors"], 2)
        self.assertIn("MPS unavailable", summary["load_failure"])
        for coord in ((0, 0), (1, 1)):
            self.assertTrue(layout.has_error(*coord))
            self.assertFalse(os.path.exists(layout.request_path(*coord)))


class RequestNameTests(_TempCase):
    """A malformed marker must never kill the worker or alias a real coordinate."""

    def test_out_of_range_coordinates_are_skipped(self):
        _, layout = self.layout()
        tb.write_request(layout, 0, 0)
        requests = os.path.join(layout.root, tb.REQUESTS_DIR_NAME)
        for name in ("99999999999_0.req", "0_99999999999.req", "007_3.req"):
            with open(os.path.join(requests, name), "w") as handle:
                handle.write("")
        seen = []
        coords = tb.read_requests(layout, on_invalid=lambda n, why: seen.append(n))
        self.assertEqual(coords, [(0, 0)])
        self.assertEqual(len(seen), 3)

    def test_worker_survives_a_hostile_marker(self):
        _, layout = self.layout()
        tb.write_request(layout, 0, 0)
        with open(os.path.join(layout.root, tb.REQUESTS_DIR_NAME,
                               "99999999999_0.req"), "w") as handle:
            handle.write("")
        summary = tb.run_worker(
            layout, stop_after=1, idle_sleep=0.0,
            sampler_factory=lambda _i, _l: FakeSampler(),
        )
        self.assertEqual(summary["tiles"], 1)
        self.assertIn("99999999999_0.req", summary["invalid_markers"][0])

    def test_workers_fetch_a_store_request(self):
        """A bootstrap path that used to crash before running."""
        out = os.path.join(self.tmp, "fetched.json")
        payload = json.dumps(_FAKE_STATS).encode("utf-8")
        with mock.patch.object(tb, "fetch_frozen_stats", return_value=payload):
            code = tb.main(["fetch-stats", "--out", out])
        self.assertEqual(code, 0)
        with open(out) as handle:
            written = json.load(handle)
        self.assertEqual(written, tb.extract_frozen_stats(self.stats_path))


class IdentityForkTests(_TempCase):
    """A drifted flag must not silently write a cache the game is not reading."""

    def test_first_identity_is_created(self):
        identity = self.identity()
        digest, layout = tb.open_or_create_identity(
            self.cache_root, identity, stats_source=self.stats_path
        )
        self.assertEqual(digest, tc.identity_digest(identity))
        self.assertTrue(os.path.isdir(layout.root))

    def test_second_different_identity_is_refused(self):
        tb.open_or_create_identity(self.cache_root, self.identity(),
                                   stats_source=self.stats_path)
        with self.assertRaises(tb.BackendError) as caught:
            tb.open_or_create_identity(
                self.cache_root, self.identity(seed=9999),
                stats_source=self.stats_path,
            )
        message = str(caught.exception)
        self.assertIn("Refusing to create a second generation", message)
        self.assertIn("init", message)
        # The original identity is untouched and no second dir appeared.
        self.assertEqual(len(tb.existing_identities(self.cache_root)), 1)

    def test_same_identity_is_idempotent(self):
        first, _ = tb.open_or_create_identity(
            self.cache_root, self.identity(), stats_source=self.stats_path)
        second, _ = tb.open_or_create_identity(
            self.cache_root, self.identity(), stats_source=self.stats_path)
        self.assertEqual(first, second)

    def test_init_may_still_add_a_generation_deliberately(self):
        identity = self.identity()
        digest, layout = tb.write_identity(
            self.cache_root, identity, stats_source=self.stats_path)
        other = self.identity(seed=9999)
        other_digest, _ = tb.write_identity(
            self.cache_root, other, stats_source=self.stats_path)
        self.assertEqual(len(tb.existing_identities(self.cache_root)), 2)
        self.assertNotEqual(digest, other_digest)


class OfficialStatsTests(_TempCase):
    """The official table is the only one production accepts.

    These tests restore the real constant that ``_TempCase`` patched, and use the
    committed fixture at ``test/fixtures/pipeline_data.json`` -- a byte-for-byte
    copy of the pinned HF revision. A skip here would prove nothing about the pin,
    so nothing is skipped.
    """

    OFFICIAL_FIXTURE = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "fixtures", "pipeline_data.json"
    )

    def setUp(self):
        super().setUp()
        # Override _TempCase's fixture pin: these tests are about the real value.
        self._restore_official_pin()

    def _restore_official_pin(self):
        """Undo ``_TempCase``'s fixture pin by restoring the module's own value.

        Patching back a *copy* of the expected constant would be self-defeating:
        if the shipped constant drifts, the copy still matches the fixture and the
        suite passes against a wrong production value. Restoring what the module
        actually holds means `test_the_shipped_constant_is_the_official_table`
        below is the only thing that has to know the real digest.
        """
        patcher = mock.patch.object(tb, "OFFICIAL_STATS_SHA256", self.real_pin)
        patcher.start()
        self.addCleanup(patcher.stop)

    @classmethod
    def setUpClass(cls):
        # Captured before any patching, so it is the shipped value rather than a
        # fixture's.
        cls.real_pin = tb.OFFICIAL_STATS_SHA256

    def test_fixture_is_the_official_file(self):
        with open(self.OFFICIAL_FIXTURE, "rb") as handle:
            payload = handle.read()
        self.assertEqual(len(payload), 12226)
        self.assertEqual(
            hashlib.sha256(payload).hexdigest(),
            "e3132c3ef0c65d8613615f9278ffe23bbd9363ddcd87f1cc6f18456bcc9efe5c",
        )

    def test_the_shipped_constant_is_the_official_table(self):
        """The one place that knows the real digest, so drift cannot hide.

        ``_TempCase`` patches the constant for every other test; if this assertion
        lived only there it would compare a patched value against itself.
        """
        self.assertEqual(
            self.real_pin,
            "528754ea8203928364cccd931686ec87612b1eefba44ef7956293f33a68bdbe3",
        )

    def test_official_table_from_the_committed_fixture_passes(self):
        stats = tb.extract_frozen_stats(self.OFFICIAL_FIXTURE)
        self.assertEqual(tb._require_official_stats(stats), self.real_pin)

    def test_substituted_table_is_refused(self):
        with self.assertRaises(tb.BackendError) as caught:
            tb.extract_frozen_stats(self.stats_path)
        self.assertIn("different world", str(caught.exception))

    def test_shape_alone_does_not_satisfy_the_pin(self):
        """A locally recomputed table is well formed and still refused."""
        altered = tb.extract_frozen_stats(
            self.OFFICIAL_FIXTURE
        )
        altered["data_quantile_tables"][0][0] -= 69.1
        with self.assertRaises(tb.BackendError):
            tb.extract_frozen_stats(altered)

    def test_a_forged_table_cannot_reach_an_identity(self):
        """The pin is inside extract, so build_identity refuses before hashing."""
        forged = tb.extract_frozen_stats(
            self.OFFICIAL_FIXTURE
        )
        forged["data_quantile_tables"][0] = [0.0] * 64
        with self.assertRaises(tb.BackendError):
            self.identity(stats=forged)


class LibrarySurfaceTests(_TempCase):
    @property
    def upstream_dir(self):
        """A directory that verifies against the pin, else the pinned one.

        The tests must pass on a machine without the pinned checkout, so the
        digest is swapped for the fixture value when it is absent; that is a
        fixture decision, identical in spirit to FakeSampler.
        """
        pinned = tb.DEFAULT_UPSTREAM
        if os.path.isdir(pinned):
            try:
                tb.verify_upstream(pinned)
                return pinned
            except tb.BackendError:
                pass
        raise unittest.SkipTest("pinned upstream checkout is not available")

    def test_import_pulls_in_no_inference_stack(self):
        """Importing the backend must not drag in the inference stack.

        This has to run in a FRESH interpreter. Asserting on this process's
        ``sys.modules`` proves nothing about `terrain_backend`, because anything
        else imported earlier in the same run -- the scenic tests legitimately
        load numpy -- is already there. A subprocess makes the claim about the
        import itself rather than about test ordering.
        """
        import subprocess

        program = (
            "import sys\n"
            "sys.path.insert(0, %r)\n"
            "import terrain_backend\n"
            "leaked = [n for n in ('torch', 'numpy', 'diffusion', 'terrain_diffusion')\n"
            "          if n in sys.modules]\n"
            "print(','.join(leaked))\n"
        ) % os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"
        )
        result = subprocess.run(
            [sys.executable, "-c", program],
            capture_output=True, text=True, timeout=120,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
        )
        self.assertEqual(
            result.returncode, 0,
            "a fresh interpreter could not import terrain_backend: %s"
            % result.stderr.strip()[:400],
        )
        leaked = [n for n in result.stdout.strip().split(",") if n]
        self.assertEqual(
            leaked, [],
            "terrain_backend imported %s at import time" % ", ".join(leaked),
        )

    def test_doctor_reports_both_pin_blocks(self):
        """Doctor must surface configs as well as weights, or it hides the gap."""
        self._fixture_stats_pin()
        report = tb.doctor(cache_root=self.cache_root, snapshot=self.snapshot,
                           stats_source=self.stats_path,
                           upstream=tb.DEFAULT_UPSTREAM)
        pins = report["checks"]["pins"]
        self.assertTrue(pins["ok"], pins)
        self.assertIn("configs_sha256", pins)
        self.assertIn("weights_sha256", pins)
        self.assertEqual(len(pins["configs_sha256"]), 64)

    def test_doctor_flags_a_drifted_submodel_config(self):
        self._fixture_stats_pin()
        path = os.path.join(self.snapshot, "decoder_model/config.json")
        with open(path, "wb") as handle:
            handle.write(b'{"disable_out_gain": true}')
        report = tb.doctor(cache_root=self.cache_root, snapshot=self.snapshot,
                           stats_source=self.stats_path,
                           upstream=tb.DEFAULT_UPSTREAM)
        self.assertFalse(report["checks"]["pins"]["ok"])
        self.assertFalse(report["ok"])

    def test_doctor_runs_without_torch_and_reports_every_check(self):
        report = tb.doctor(cache_root=self.cache_root, snapshot=self.snapshot,
                           stats_source=self.stats_path,
                           upstream=tb.DEFAULT_UPSTREAM)
        for name in ("snapshot", "config", "stats", "noise_lib", "cache"):
            self.assertIn(name, report["checks"])
        self.assertIsInstance(report["problems"], list)

    def _fixture_stats_pin(self):
        """Let CLI tests use the fixture stats table instead of the official one."""
        stats = tb.extract_frozen_stats(self.stats_path)
        digest = hashlib.sha256(
            json.dumps(stats, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        patcher = mock.patch.object(tb, "OFFICIAL_STATS_SHA256", digest)
        patcher.start()
        self.addCleanup(patcher.stop)
        return patcher

    def _noise_stub(self):
        """Point the noise digest at a fixture file instead of the .so build.

        The compiled ``pyfastnoiselite`` module is a runtime artifact of the
        inference environment; these CLI tests prove the *command* wiring, not
        the numerics of that binary.  Substituting a file is the same explicit
        fixture decision as :class:`FakeSampler`, and is never used in
        production, where the installed binary is digested.
        """
        stub = os.path.join(self.tmp, "pyfastnoiselite_stub.so")
        with open(stub, "wb") as handle:
            handle.write(b"fixture-not-a-build")
        return mock.patch.object(tb, "_noise_module_file", return_value=stub)

    def test_descriptor_cli_needs_only_the_stdlib(self):
        """``descriptor`` prints a JSON identity without touching a model."""
        import contextlib
        import io

        self._fixture_stats_pin()
        patcher = self._noise_stub()
        patcher.start()
        self.addCleanup(patcher.stop)
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = tb.main([
                "--cache-root", self.cache_root,
                "descriptor",
                "--snapshot", self.snapshot,
                "--stats-json", self.stats_path,
                "--upstream", tb.DEFAULT_UPSTREAM,
            ])
        self.assertEqual(code, 0)
        payload = json.loads(buffer.getvalue())
        self.assertEqual(len(payload["identity_digest"]), 64)
        for key in tc.IDENTITY_KEYS:
            self.assertIn(key, payload["identity"])

    def test_parser_accepts_cache_root_before_or_after_the_subcommand(self):
        parser = tb.build_parser()
        before = parser.parse_args(["--cache-root", "/x", "descriptor"])
        after = parser.parse_args(["descriptor", "--cache-root", "/x"])
        self.assertEqual(tb._resolve_cache_root(before), os.path.abspath("/x"))
        self.assertEqual(tb._resolve_cache_root(after), os.path.abspath("/x"))

    def test_cli_origin_window_and_decoder_each_change_the_digest(self):
        """The flags reach the identity, so each one selects a different cache."""

        def digest(*flags):
            self._fixture_stats_pin()
            patcher = self._noise_stub()
            patcher.start()
            try:
                buffer = io.StringIO()
                with contextlib.redirect_stdout(buffer):
                    code = tb.main([
                        "--cache-root", self.cache_root, "descriptor",
                        "--snapshot", self.snapshot,
                        "--stats-json", self.stats_path,
                        "--upstream", self.upstream_dir,
                    ] + list(flags))
                self.assertEqual(code, 0)
                return json.loads(buffer.getvalue())["identity_digest"]
            finally:
                patcher.stop()

        base = digest("--seed", "12345")
        variants = {
            "origin": digest("--seed", "12345",
                             "--origin-x", "100000", "--origin-z", "100000"),
            "window": digest("--seed", "12345",
                             "--window-chunks", "8", "--max-samples", "128"),
            "decoder": digest("--seed", "12345",
                              "--decoder-tile", "256", "--decoder-stride", "192"),
        }
        self.assertEqual(len({base, *variants.values()}), 4,
                         "each geometry axis must select its own cache: %r"
                         % (variants,))

    def test_cli_rejects_an_over_large_window_with_advice(self):
        self._fixture_stats_pin()
        patcher = self._noise_stub()
        patcher.start()
        self.addCleanup(patcher.stop)
        with self.assertRaises(tb.BackendError) as caught:
            tb.main([
                "--cache-root", self.cache_root, "descriptor",
                "--snapshot", self.snapshot,
                "--stats-json", self.stats_path,
                "--upstream", self.upstream_dir,
                "--window-chunks", "8",
            ])
        self.assertIn("--max-samples", str(caught.exception))

    def test_init_writes_the_documented_layout(self):
        import contextlib
        import io

        self._fixture_stats_pin()
        patcher = self._noise_stub()
        patcher.start()
        self.addCleanup(patcher.stop)
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = tb.main([
                "--cache-root", self.cache_root,
                "init",
                "--snapshot", self.snapshot,
                "--stats-json", self.stats_path,
                "--upstream", tb.DEFAULT_UPSTREAM,
            ])
        self.assertEqual(code, 0)
        digest = json.loads(buffer.getvalue())["identity_digest"]
        root = tc.cache_dir(self.cache_root, digest)
        for name in (tc.MANIFEST_NAME, tb.MANIFEST_JANET_NAME, tb.STATS_NAME,
                     tb.IDENTITY_RECORD, tc.TILE_DIR_NAME,
                     tb.REQUESTS_DIR_NAME, tb.ERRORS_DIR_NAME):
            self.assertTrue(os.path.exists(os.path.join(root, name)),
                            "init must create %s" % name)
        with open(os.path.join(root, tb.MANIFEST_JANET_NAME), "rb") as handle:
            self.assertTrue(handle.read().startswith(b'{:format 2 :magic "TDH2"'))


class WorkerIdentityTests(_TempCase):
    """A worker consumes an existing queue; it never invents one."""

    def test_bake_contention_exits_locked(self):
        """`bake` shares the identity lock, so it contends on the same file."""
        # Create the identity with the CLI's own flags, so the lock this test
        # holds is the one the command will resolve.
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            self.assertEqual(self._run_cli(*self._init_argv()), 0)
        layout = tb.Layout.open(
            self.cache_root, json.loads(buffer.getvalue())["identity_digest"]
        )
        holder = tb.ProcessLock(tb.identity_lock_path(layout), "mps")
        holder.acquire()
        try:
            stderr = io.StringIO()
            with contextlib.redirect_stderr(stderr):
                code = self._run_cli(
                    *self._init_argv(first="bake", chunks=("0", "0", "1", "1"))
                )
            self.assertEqual(code, tb.EXIT_LOCKED, stderr.getvalue())
        finally:
            holder.release()

    def _noise_stub(self):
        """Point the noise digest at a fixture file instead of the .so build."""
        stub = os.path.join(self.tmp, "pyfastnoiselite_stub.so")
        with open(stub, "wb") as handle:
            handle.write(b"fixture-not-a-build")
        return mock.patch.object(tb, "_noise_module_file", return_value=stub)

    def _run_cli(self, *argv):
        """Run the CLI with the flags every command needs, plus the extras.

        The noise digest is stubbed for the same reason the other CLI tests stub
        it: the compiled build is a runtime artifact. The identity these commands
        resolve is therefore the CLI's own, which is exactly what must match.
        """
        noise = self._noise_stub()
        noise.start()
        self.addCleanup(noise.stop)
        return tb.main(list(argv))

    def _init_argv(self, first=None, chunks=None):
        """The flags `init` and `bake` share, so they resolve one identity."""
        verb = first or "init"
        argv = [
            verb,
            "--cache-root", self.cache_root,
            "--snapshot", self.snapshot,
            "--stats-json", self.stats_path,
            "--upstream", tb.DEFAULT_UPSTREAM,
            "--seed", "1234",
            "--pixels-per-voxel", "1",
            "--window-chunks", "1",
            "--max-samples", "64",
            "--decoder-tile", "512",
            "--decoder-stride", "384",
        ]
        if chunks:
            # `--chunks` belongs to the `bake` subparser, so it follows the verb.
            argv.extend(["--chunks", *chunks])
        return argv

    def _worker_argv(self, **flags):
        argv = [
            "--cache-root", self.cache_root,
            "worker",
            "--snapshot", self.snapshot,
            "--stats-json", self.stats_path,
            "--upstream", tb.DEFAULT_UPSTREAM,
            "--seed", "1234",
            "--pixels-per-voxel", "1",
            "--window-chunks", "1",
            "--max-samples", "64",
            "--decoder-tile", "512",
            "--decoder-stride", "384",
            "--stop-after", "1",
            "--idle-sleep", "0",
        ]
        for key, value in flags.items():
            argv.extend(["--" + key.replace("_", "-"), str(value)])
        return argv

    def _run_worker_cli(self, **flags):
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = self._run_cli(*self._worker_argv(**flags))
        return code, buffer.getvalue()

    def test_worker_does_not_create_an_identity(self):
        """No cache root at all: refuse, and leave nothing behind."""
        self.assertFalse(os.path.isdir(self.cache_root))
        with self.assertRaises(tb.BackendError) as caught:
            self._run_worker_cli()
        self.assertIn("no identity directory", str(caught.exception))
        self.assertFalse(
            os.path.exists(tc.cache_dir(
                self.cache_root, tc.identity_digest(self.identity()))),
            "a worker must not create an identity directory when it finds none",
        )

    def test_worker_refuses_drifted_flags_instead_of_forking(self):
        """An existing identity plus different flags must not mint a second one."""
        _, layout = self.layout()
        before = tb.existing_identities(self.cache_root)
        self.assertEqual(len(before), 1)
        with self.assertRaises(tb.BackendError) as caught:
            self._run_worker_cli(origin_x=99999)
        message = str(caught.exception)
        self.assertIn("no identity directory", message)
        self.assertEqual(
            tb.existing_identities(self.cache_root), before,
            "drifted worker flags created a new identity directory",
        )

    def test_worker_runs_against_the_existing_identity(self):
        """`init` creates under the CLI's own flags; `worker` then joins it."""
        noise = self._noise_stub()
        noise.start()
        self.addCleanup(noise.stop)
        init_argv = [
            "--cache-root", self.cache_root,
            "init",
            "--snapshot", self.snapshot,
            "--stats-json", self.stats_path,
            "--upstream", tb.DEFAULT_UPSTREAM,
            "--seed", "1234",
            "--pixels-per-voxel", "1",
            "--window-chunks", "1",
            "--max-samples", "64",
            "--decoder-tile", "512",
            "--decoder-stride", "384",
        ]
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            self.assertEqual(tb.main(init_argv), 0)
        digest = json.loads(buffer.getvalue())["identity_digest"]
        layout = tb.Layout.open(self.cache_root, digest)
        tb.write_request(layout, 0, 0)
        code, output = self._run_worker_cli()
        self.assertEqual(code, 0)
        summary = json.loads(output)
        # The worker reached the loader on the identity `init` created. That it
        # got that far is the property under test: it opened the existing identity
        # instead of minting one of its own.
        #
        # It fails at the first pin the loader checks. `run_worker` takes no
        # snapshot argument, so `load_sampler` falls back to DEFAULT_SNAPSHOT and
        # the fixture identity's pins cannot match it. Which pin trips first is an
        # implementation detail -- asserting one specific phrase made this test
        # pass here and fail wherever the pin order differed.
        self.assertEqual(summary["stopped"], "load-failed")
        failure = summary["load_failure"]
        self.assertTrue(
            "pinned revision" in failure or "do not match the identity" in failure,
            "the worker failed somewhere other than pin verification: %r" % (failure,),
        )
        self.assertTrue(
            "config" in failure or "weight" in failure,
            "expected a config or weight pin failure, got %r" % (failure,),
        )

    def test_worker_drains_a_queued_marker_with_a_fake_sampler(self):
        """The same command, with the loader replaced, publishes the tile."""
        digest, layout = tb.open_or_create_identity(
            self.cache_root, self.identity(), stats_source=self.stats_path
        )
        tb.write_request(layout, 0, 0)
        summary = tb.run_worker(
            layout, stop_after=1, idle_sleep=0.0,
            sampler_factory=lambda _identity, _layout: FakeSampler(),
        )
        self.assertEqual(summary["tiles"], 1)
        self.assertTrue(layout.has_tile(0, 0))

    def test_bake_may_still_create_the_first_identity(self):
        """bake is the documented bounded command that may bootstrap a cache."""
        identity = self.identity()
        digest, layout = tb.open_or_create_identity(
            self.cache_root, identity, stats_source=self.stats_path
        )
        self.assertEqual(tb.existing_identities(self.cache_root), [digest])


class StrictQuantileCountTests(_TempCase):
    """`n_quantiles` must be the integer 64, not merely something int()-equal."""

    def _stats(self):
        return tb.extract_frozen_stats(self.stats_path)

    def test_a_float_near_64_is_refused(self):
        for value in (64.9, 64.0001, 63.9999):
            stats = self._stats()
            stats["n_quantiles"] = value
            with self.assertRaises(tb.BackendError) as caught:
                tb.extract_frozen_stats(stats)
            self.assertIn("must be an int", str(caught.exception))

    def test_a_bool_is_refused(self):
        for value in (True, False):
            stats = self._stats()
            stats["n_quantiles"] = value
            with self.assertRaises(tb.BackendError):
                tb.extract_frozen_stats(stats)

    def test_the_integer_64_is_accepted(self):
        stats = self._stats()
        stats["n_quantiles"] = 64
        self.assertEqual(tb.extract_frozen_stats(stats)["n_quantiles"], 64)

    def test_a_wrong_integer_is_refused_by_count(self):
        stats = self._stats()
        stats["n_quantiles"] = 32
        with self.assertRaises(tb.BackendError) as caught:
            tb.extract_frozen_stats(stats)
        self.assertIn("must be 64", str(caught.exception))


class FetchStatsPinTests(_TempCase):
    """`fetch-stats` must not write a downloaded table it would then refuse."""

    def test_a_tampered_download_is_refused_and_not_written(self):
        out = os.path.join(self.tmp, "fetched.json")
        tampered = json.loads(json.dumps(_FAKE_STATS))
        tampered["data_quantile_tables"][0][0] -= 69.1
        payload = json.dumps(tampered).encode("utf-8")
        with mock.patch.object(tb, "fetch_frozen_stats", return_value=payload):
            with self.assertRaises(tb.BackendError):
                tb.main(["fetch-stats", "--out", out])
        self.assertFalse(
            os.path.exists(out),
            "fetch-stats wrote a table it refuses to load",
        )

    def test_a_hostile_download_is_refused(self):
        out = os.path.join(self.tmp, "fetched.json")
        with mock.patch.object(
            tb, "fetch_frozen_stats", return_value=b"not json at all"
        ):
            with self.assertRaises((tb.BackendError, ValueError)):
                tb.main(["fetch-stats", "--out", out])
        self.assertFalse(os.path.exists(out))


class StatusBridgeTests(_TempCase):
    """The load-time bridge must be inert Janet data the game can parse."""

    def test_render_is_a_parsable_janet_table(self):
        payload = tb.render_status(
            {
                "state": "generating",
                "identity_digest": "a" * 64,
                "pid": 4242,
                "completed": 7,
                "message": 'quoted "x"',
            }
        ).decode("utf-8")
        self.assertIn(":version 1", payload)
        self.assertIn(":state :generating", payload)
        self.assertIn(":pid 4242", payload)
        self.assertIn(":completed 7", payload)
        # Escaped, not raw: an unescaped quote would make the file unparsable.
        # The backslash itself is what must be present, hence the raw literal.
        self.assertIn(r'\"x\"', payload)
        self.assertNotIn('"quoted "x""', payload)
        self.assertTrue(payload.endswith("}\n"))

    def test_every_declared_state_renders_and_unknown_is_refused(self):
        for state in tb.STATUS_STATES:
            payload = tb.render_status(
                {
                    "state": state,
                    "identity_digest": "b" * 64,
                    "pid": 1,
                    "completed": 0,
                    "message": "",
                }
            ).decode("utf-8")
            self.assertIn(":state :%s" % state, payload)
        with self.assertRaises(tb.BackendError):
            tb.render_status(
                {
                    "state": "made-up",
                    "identity_digest": "b" * 64,
                    "pid": 1,
                    "completed": 0,
                    "message": "",
                }
            )

    def test_owner_token_is_optional(self):
        base = {
            "state": "starting",
            "identity_digest": "c" * 64,
            "pid": 2,
            "completed": 0,
            "message": "",
        }
        self.assertNotIn(":owner-token", tb.render_status(dict(base)).decode())
        with_token = tb.render_status(dict(base, owner_token="launch-7")).decode()
        self.assertIn(':owner-token "launch-7"', with_token)

    def test_status_write_is_atomic_and_bounded(self):
        _, layout = self.layout()
        writer = tb.StatusWriter(layout, layout.digest)
        writer.write("starting", 0, "first")
        first = tb.read_status(layout)
        writer.write("generating", 3, "second")
        second = tb.read_status(layout)
        self.assertIn(":state :starting", first)
        self.assertIn(":state :generating", second)
        self.assertIn(":completed 3", second)
        self.assertLessEqual(len(second.encode()), tb.STATUS_MAX_BYTES)
        self.assertFalse(
            os.path.exists(os.path.join(layout.root, tb.STATUS_NAME + ".tmp"))
        )


class FromIdentityTests(_TempCase):
    """A launcher names a directory; every parameter is re-derived from it."""

    def _rebuild(self, directory):
        """Rebuild with THIS case's fixture pins, not the machine's real ones."""
        return tb.identity_from_stored_dir(
            directory, snapshot=self.snapshot, stats_source=self.stats_path
        )

    def test_recomputes_and_validates_the_stored_identity(self):
        identity, layout = self.layout()
        rebuilt, cache_root, reopened = self._rebuild(layout.root)
        self.assertEqual(reopened.digest, layout.digest)
        self.assertEqual(cache_root, self.cache_root)
        self.assertEqual(rebuilt["seed"], identity["seed"])
        self.assertEqual(
            rebuilt["query"]["origin_pixels"], identity["query"]["origin_pixels"]
        )

    def test_flags_cannot_override_the_stored_geometry(self):
        """The whole point: no CLI flag is consulted on this path."""
        identity, layout = self.layout()
        args = tb.build_parser().parse_args(
            ["--cache-root", self.cache_root, "worker",
             "--from-identity", layout.root,
             "--seed", "4", "--origin-x", "0", "--origin-z", "0"]
        )
        rebuilt, _, _ = self._rebuild(args.from_identity)
        self.assertEqual(rebuilt["seed"], identity["seed"])
        self.assertNotEqual(rebuilt["seed"], 4)

    def test_tampered_record_is_refused(self):
        _, layout = self.layout()
        path = os.path.join(layout.root, tb.IDENTITY_RECORD)
        with open(path) as handle:
            record = json.load(handle)
        record["identity"]["seed"] = 999
        with open(path, "w") as handle:
            json.dump(record, handle)
        with self.assertRaises(tb.BackendError) as caught:
            self._rebuild(layout.root)
        self.assertIn("does not match the pins it stores", str(caught.exception))

    def test_renamed_directory_is_refused(self):
        _, layout = self.layout()
        moved = os.path.join(self.cache_root, "0" * 64)
        os.rename(layout.root, moved)
        with self.assertRaises(tb.BackendError):
            self._rebuild(moved)

    def test_missing_directory_is_refused(self):
        with self.assertRaises(tb.BackendError) as caught:
            self._rebuild(os.path.join(self.tmp, "nope"))
        self.assertIn("identity directory is missing", str(caught.exception))


class FromIdentityCliTests(_TempCase):
    """The CLI path, not just the function: explicit artefact paths must count."""

    def _argv(self, directory, **extra):
        argv = ["worker", "--from-identity", directory,
                "--stop-after", "1", "--idle-sleep", "0"]
        for key, value in extra.items():
            argv.extend(["--" + key.replace("_", "-"), str(value)])
        return argv

    def _run(self, directory, **extra):
        """Run through the real entry point so exit codes, not exceptions, decide.

        `main()` raises `BackendError`; the `__main__` handler is what turns that
        into a status. Driving the handler here tests what a launcher sees.
        """
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            try:
                code = tb.main(self._argv(directory, **extra))
            except tb.BackendError as exc:
                print("terrain_backend: %s" % exc, file=stderr)
                code = 2
        return code, stderr.getvalue()

    def test_cli_honours_explicit_snapshot_and_stats(self):
        """A launcher keeping its snapshot elsewhere must not be ignored."""
        _, layout = self.layout()
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = tb.main(
                self._argv(
                    layout.root,
                    snapshot=self.snapshot,
                    stats_json=self.stats_path,
                    upstream=tb.DEFAULT_UPSTREAM,
                )
            )
        self.assertEqual(code, 0, buffer.getvalue())
        self.assertEqual(json.loads(buffer.getvalue())["ticks"], 1)

    def test_cli_refuses_a_snapshot_that_cannot_reproduce_the_pins(self):
        """A wrong explicit snapshot is an error, never a silent fallback."""
        _, layout = self.layout()
        empty = os.path.join(self.tmp, "empty-snapshot")
        os.makedirs(empty)
        code, stderr = self._run(
            layout.root,
            snapshot=empty,
            stats_json=self.stats_path,
            upstream=tb.DEFAULT_UPSTREAM,
        )
        self.assertNotEqual(code, 0)
        self.assertIn("config", stderr.lower())

    def test_cli_refuses_a_missing_stats_path_instead_of_defaulting(self):
        _, layout = self.layout()
        code, stderr = self._run(
            layout.root,
            snapshot=self.snapshot,
            stats_json=os.path.join(self.tmp, "absent.json"),
            upstream=tb.DEFAULT_UPSTREAM,
        )
        self.assertNotEqual(code, 0)
        self.assertIn("stats", stderr.lower())

    def test_cli_refuses_a_missing_snapshot_directory(self):
        _, layout = self.layout()
        code, stderr = self._run(
            layout.root,
            snapshot=os.path.join(self.tmp, "no-such-snapshot"),
            stats_json=self.stats_path,
            upstream=tb.DEFAULT_UPSTREAM,
        )
        self.assertNotEqual(code, 0)
        self.assertIn("snapshot directory is missing", stderr)


class LaunchReceiptTests(_TempCase):
    """A per-launch receipt records the outcome, at a path the launcher named.

    The receipt is the only way a launcher learns *who* serves the cache: a
    freshly spawned child has a different pid from an existing owner, so a
    receipt naming only the child could never authorise reuse.
    """

    TOKEN = "launch-7"

    def _argv(self, directory, **extra):
        argv = ["worker", "--from-identity", directory,
                "--snapshot", self.snapshot, "--stats-json", self.stats_path,
                "--upstream", tb.DEFAULT_UPSTREAM,
                "--stop-after", "1", "--idle-sleep", "0",
                "--owner-token", self.TOKEN]
        for key, value in extra.items():
            argv.extend(["--" + key.replace("_", "-"), str(value)])
        return argv

    def _receipt(self, layout):
        return tb.read_launch_receipt(layout, self.TOKEN)

    def test_token_validation_rejects_unsafe_values(self):
        """The token becomes a path component, so traversal must be impossible."""
        for bad in ("../escape", "a/b", "with space", "", "x" * 129, "dot.dot",
                    "new\nline", None):
            with self.assertRaises(tb.BackendError):
                tb.validate_token(bad)
        for good in ("launch-7", "A_b-9", "x" * 128, "0"):
            self.assertEqual(tb.validate_token(good), good)

    def test_receipts_are_per_token_not_shared(self):
        """Two launches must not clobber one another."""
        _, layout = self.layout()
        tb.write_launch_receipt(layout, layout.digest, "aaa", "launched")
        tb.write_launch_receipt(layout, layout.digest, "bbb", "started",
                                worker_pid=42)
        first = tb.read_launch_receipt(layout, "aaa")
        second = tb.read_launch_receipt(layout, "bbb")
        self.assertIn(":state :launched", first)
        self.assertIn(":state :started", second)
        self.assertIn(":worker-pid 42", second)
        self.assertNotIn(":worker-pid 42", first)

    def test_receipt_carries_both_pids_and_tokens(self):
        _, layout = self.layout()
        tb.write_launch_receipt(
            layout, layout.digest, self.TOKEN, "reused",
            worker_pid=999, worker_token="other-launch",
            message="identity already served",
        )
        receipt = self._receipt(layout)
        self.assertIn(":launcher-pid %d" % os.getpid(), receipt)
        self.assertIn(":worker-pid 999", receipt)          # the *existing* owner
        self.assertIn(':owner-token "%s"' % self.TOKEN, receipt)
        self.assertIn(':worker-token "other-launch"', receipt)

    def test_failed_validation_still_publishes_an_outcome(self):
        _, layout = self.layout()
        record = os.path.join(layout.root, tb.IDENTITY_RECORD)
        with open(record) as handle:
            rec = json.load(handle)
        rec["identity"]["seed"] = 999
        with open(record, "w") as handle:
            json.dump(rec, handle)

        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            code = tb.main(self._argv(layout.root))
        self.assertEqual(code, 2)
        receipt = self._receipt(layout)
        self.assertIsNotNone(receipt, "a failed launch left no outcome")
        self.assertIn(":state :failed", receipt)
        self.assertIn(":message", receipt)

    def test_contention_reports_reused_with_the_owner_pid(self):
        """The P1: reuse must name the live owner, never this child."""
        _, layout = self.layout()
        owner = tb.StatusWriter(layout, layout.digest, owner_token="prior-launch")
        owner.write("generating", 4, "owner alive")
        holder = tb.ProcessLock(tb.identity_lock_path(layout), "mps")
        holder.acquire()
        try:
            stderr = io.StringIO()
            with contextlib.redirect_stderr(stderr):
                code = tb.main(self._argv(layout.root))
            self.assertEqual(code, tb.EXIT_LOCKED, stderr.getvalue())
        finally:
            holder.release()
        receipt = self._receipt(layout)
        self.assertIn(":state :reused", receipt)
        # This process wrote the receipt; the worker is somebody else.
        self.assertIn(":launcher-pid %d" % os.getpid(), receipt)
        self.assertIn(":worker-pid %d" % os.getpid(), receipt)
        self.assertIn(':worker-token "prior-launch"', receipt)

    def test_device_contention_on_another_identity_is_failed_not_reused(self):
        """A different identity holding the GPU is not reuse of this cache."""
        _, layout = self.layout()
        other = os.path.join(self.tmp, "other-root")
        os.makedirs(other)
        tb.write_identity(other, self.identity(seed=4321),
                          stats_source=self.stats_path)
        holder = tb.ProcessLock(tb.device_lock_path("mps"), "mps")
        holder.acquire()
        try:
            stderr = io.StringIO()
            with contextlib.redirect_stderr(stderr):
                code = tb.main(self._argv(layout.root))
            self.assertEqual(code, tb.EXIT_LOCKED)
        finally:
            holder.release()
        receipt = self._receipt(layout)
        self.assertIn(":state :failed", receipt)
        self.assertIn("device-busy", receipt)
        self.assertNotIn(":state :reused", receipt)

    def test_started_receipt_names_this_process(self):
        _, layout = self.layout()
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = tb.main(self._argv(layout.root))
        self.assertEqual(code, 0, buffer.getvalue())
        receipt = self._receipt(layout)
        self.assertIn(":state :started", receipt)
        self.assertIn(":worker-pid %d" % os.getpid(), receipt)

    def test_receipt_is_retained_after_a_clean_exit(self):
        """It is an outcome, not liveness; the launcher removes its own file."""
        _, layout = self.layout()
        with contextlib.redirect_stdout(io.StringIO()):
            tb.main(self._argv(layout.root))
        self.assertIsNotNone(self._receipt(layout))
        tb.remove_launch_receipt(layout, self.TOKEN)
        self.assertIsNone(self._receipt(layout))

    def test_receipt_is_parsable_inert_data_with_escapes(self):
        _, layout = self.layout()
        tb.write_launch_receipt(layout, layout.digest, self.TOKEN, "failed",
                                message='bad "quote" here')
        receipt = self._receipt(layout)
        self.assertTrue(receipt.startswith("{:version "))
        self.assertTrue(receipt.endswith("}\n"))
        self.assertIn(r'\"quote\"', receipt)


class TwoProcessReuseTests(_TempCase):
    """The decisive case: a real second process must name the real owner.

    A freshly spawned child has a different pid from the existing owner, so a
    receipt that reported only the child could never authorise reuse. This drives
    two real OS processes and asserts the receipt carries the *owner's* pid.
    """

    HOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "_holder_fixture.py")

    def _start_owner(self, layout, token):
        import subprocess

        process = subprocess.Popen(
            [sys.executable, self.HOLDER, layout.root, token],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True,
            cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        )
        self.addCleanup(self._stop_owner, process)
        return process, int(process.stdout.readline().strip())

    @staticmethod
    def _stop_owner(process):
        import subprocess

        try:
            if process.poll() is None:
                try:
                    process.stdin.write("go\n")
                    process.stdin.flush()
                except (OSError, ValueError):
                    pass
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
        finally:
            for stream in (process.stdin, process.stdout):
                try:
                    stream.close()
                except (OSError, ValueError):
                    pass

    def test_second_launch_reports_reused_with_the_owner_pid(self):
        identity, layout = self.layout()
        owner, owner_pid = self._start_owner(layout, "prior-launch")
        self.assertNotEqual(owner_pid, os.getpid())

        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            code = tb.main(
                self._worker_receipt_argv(layout.root, "second-launch")
            )
        self.assertEqual(code, tb.EXIT_LOCKED, stderr.getvalue())

        receipt = tb.read_launch_receipt(layout, "second-launch")
        self.assertIn(":state :reused", receipt)
        # The crux: the receipt names the OWNER, not this process.
        self.assertIn(":worker-pid %d" % owner_pid, receipt)
        self.assertIn(':worker-token "prior-launch"', receipt)
        self.assertIn(":launcher-pid %d" % os.getpid(), receipt)
        self.assertIsNone(owner.poll(), "the contender killed the owner")

    def test_owner_still_serves_after_a_contender_is_refused(self):
        """Reuse must not disturb the running owner: it keeps its status."""
        identity, layout = self.layout()
        tb.write_request(layout, 0, 0)
        owner, owner_pid = self._start_owner(layout, "prior-launch")
        before = tb.read_status(layout)

        with contextlib.redirect_stderr(io.StringIO()):
            code = tb.main(self._worker_receipt_argv(layout.root, "contender"))
        self.assertEqual(code, tb.EXIT_LOCKED)
        self.assertEqual(
            tb.read_status(layout), before,
            "a refused contender overwrote the owner's status",
        )
        self.assertIsNone(owner.poll())

    def _worker_receipt_argv(self, directory, token):
        return ["worker", "--from-identity", directory,
                "--snapshot", self.snapshot, "--stats-json", self.stats_path,
                "--upstream", tb.DEFAULT_UPSTREAM,
                "--stop-after", "1", "--idle-sleep", "0",
                "--owner-token", token]

    """75 means contention only; any other fault must not look like it."""

    def _worker_argv_for(self, directory):
        return ["worker", "--from-identity", directory,
                "--snapshot", self.snapshot, "--stats-json", self.stats_path,
                "--upstream", tb.DEFAULT_UPSTREAM,
                "--stop-after", "1", "--idle-sleep", "0"]

    def test_lock_contention_exits_locked(self):
        _, layout = self.layout()
        holder = tb.ProcessLock(tb.identity_lock_path(layout), "mps")
        holder.acquire()
        try:
            stderr = io.StringIO()
            with contextlib.redirect_stderr(stderr):
                code = tb.main(self._worker_argv_for(layout.root))
            self.assertEqual(code, tb.EXIT_LOCKED)
            self.assertIn("already in use", stderr.getvalue())
        finally:
            holder.release()

    def test_status_write_failure_is_not_lock_busy(self):
        """The P1: a broken status write must not report 'someone else has it'."""
        _, layout = self.layout()

        def explode(*_args, **_kwargs):
            raise OSError("disk went away")

        with mock.patch.object(tb, "_atomic_write", side_effect=explode):
            stderr = io.StringIO()
            with contextlib.redirect_stderr(stderr):
                code = tb.main(self._worker_argv_for(layout.root))
        self.assertNotEqual(
            code, tb.EXIT_LOCKED,
            "a status-write failure was reported as lock contention",
        )
        self.assertNotIn("Traceback", stderr.getvalue())

    def test_lock_busy_is_a_backend_error_subclass(self):
        """Existing callers catching BackendError keep working."""
        self.assertTrue(issubclass(tb.LockBusy, tb.BackendError))


class ProducerLockTests(_TempCase):
    """Ownership is exclusive and never silently shared."""

    def test_second_identity_lock_is_refused(self):
        _, layout = self.layout()
        first = tb.ProcessLock(tb.identity_lock_path(layout), "mps")
        first.acquire()
        try:
            second = tb.ProcessLock(tb.identity_lock_path(layout), "mps")
            with self.assertRaises(tb.BackendError) as caught:
                second.acquire()
            self.assertIn("already in use", str(caught.exception))
        finally:
            first.release()

    def test_lock_is_released_and_reacquirable(self):
        _, layout = self.layout()
        lock = tb.ProcessLock(tb.identity_lock_path(layout), "mps")
        lock.acquire()
        lock.release()
        again = tb.ProcessLock(tb.identity_lock_path(layout), "mps")
        again.acquire()
        again.release()

    def test_device_lock_is_global_not_per_identity(self):
        """Two different identities must still contend for one device."""
        _, layout_a = self.layout()
        other = os.path.join(self.tmp, "other")
        os.makedirs(other)
        digest_b, layout_b = tb.write_identity(
            other, self.identity(seed=4321), stats_source=self.stats_path
        )
        self.assertNotEqual(layout_a.digest, digest_b)
        # Different paths, one device lock: that is the exclusivity that matters.
        self.assertEqual(
            tb.device_lock_path("mps"), tb.device_lock_path("mps")
        )
        first = tb.ProcessLock(tb.device_lock_path("mps"), "mps")
        first.acquire()
        try:
            second = tb.ProcessLock(tb.device_lock_path("mps"), "mps")
            with self.assertRaises(tb.BackendError):
                second.acquire()
        finally:
            first.release()

    def test_both_locks_released_when_the_device_lock_fails(self):
        """A half-acquired pair must not strand the identity lock."""
        _, layout = self.layout()
        device = tb.ProcessLock(tb.device_lock_path("mps"), "mps")
        device.acquire()
        try:
            with self.assertRaises(tb.BackendError):
                tb.acquire_producer_locks(layout, "mps")
            # The identity lock must be free again.
            probe = tb.ProcessLock(tb.identity_lock_path(layout), "mps")
            probe.acquire()
            probe.release()
        finally:
            device.release()


class WorkerStatusLifecycleTests(_TempCase):
    """Stage transitions are real; nothing publishes a fake percentage."""

    def test_status_stages_and_published_count(self):
        _, layout = self.layout()
        tb.write_request(layout, 0, 0)
        seen = []

        def factory(_identity, _layout):
            # The pre-load stage must already be on disk when the loader is
            # entered, so a window can show "loading" instead of a blank screen.
            seen.append(tb.read_status(layout))
            return FakeSampler()

        summary = tb.run_worker_command(
            layout,
            self.identity(),
            sampler_factory=factory,
            stop_after=1,
            idle_sleep=0,
        )
        self.assertEqual(summary["tiles"], 1)
        final = tb.read_status(layout)
        self.assertIn(":state :idle", final)
        self.assertIn(":completed 1", final)
        # The pre-load stage is published before the factory runs, which is what
        # lets a window show "loading" rather than an empty screen.
        self.assertIn(":state :loading-model", seen[0])

    def test_lock_refusal_does_not_clobber_the_owner_status(self):
        _, layout = self.layout()
        owner = tb.StatusWriter(layout, layout.digest)
        owner.write("generating", 5, "owner is alive")
        before = tb.read_status(layout)

        holder = tb.ProcessLock(tb.identity_lock_path(layout), "mps")
        holder.acquire()
        try:
            with self.assertRaises(tb.BackendError):
                tb.run_worker_command(layout, self.identity(), stop_after=1)
        finally:
            holder.release()
        self.assertEqual(
            tb.read_status(layout), before,
            "a refused second launch overwrote the live owner's status",
        )

    def test_failed_load_is_reported_as_failed(self):
        _, layout = self.layout()
        # The loader is only reached when a marker needs answering.
        tb.write_request(layout, 0, 0)

        def broken(_identity, _layout):
            raise tb.BackendError("MPS unavailable")

        summary = tb.run_worker_command(
            layout, self.identity(), sampler_factory=broken, stop_after=1,
            idle_sleep=0,
        )
        self.assertEqual(summary["stopped"], "load-failed")
        self.assertIn(":state :failed", tb.read_status(layout))

    def test_stop_event_releases_locks_and_reports_stopping(self):
        import threading

        _, layout = self.layout()
        stop = threading.Event()
        stop.set()
        summary = tb.run_worker_command(
            layout, self.identity(), stop_event=stop, idle_sleep=0,
        )
        self.assertEqual(summary["stopped"], "requested")
        # Locks are gone, so the next launch can take them.
        probe = tb.acquire_producer_locks(layout, "mps")
        for lock in probe:
            lock.release()


if __name__ == "__main__":
    unittest.main()
