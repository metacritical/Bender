# Headless terrain-cache consumer tests. No window, no GPU, no Python.
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/terrain-cache-test.janet
#
# The fixture writer builds TDH2 bytes with EXPLICIT little-endian arithmetic
# instead of ffi/write. That is deliberate: the module under test also decodes
# by hand, and a fixture using ffi's native order would pass on a big-endian
# host while the real Python writer produced unreadable files. The CRC comes
# from the shared implementation, so both sides agree on the field the module
# actually verifies.

(import ../src/terrain-cache :as tc)
(import ../src/terrain-integrity :as integrity)
(import ../src/climate-tile :as ct)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(var scratch-counter 0)
(defn scratch-dir []
  (++ scratch-counter)
  (def base (or (os/getenv "TMPDIR") "/tmp"))
  (def path (string base "/trinecraft-tc-" (os/getpid) "-" scratch-counter))
  (os/mkdir path)
  path)

(defn rm-tree [path]
  (when (os/stat path)
    (each name (try (os/dir path) ([e] @[]))
      (def child (string path "/" name))
      (if (= :directory (os/stat child :mode))
        (rm-tree child)
        (try (os/rm child) ([e] nil))))
    (try (os/rm path) ([e] nil))))

#
# --- Fixture ------------------------------------------------------------
#

# Plain division and modulo rather than band/brshift: bender's bit operations
# are 32-bit SIGNED and reject anything outside that range, so a fixture built
# on them could not encode -1 as 0xFFFFFFFF at all.
(defn- put-le-u32 [buf offset value]
  (put buf offset (% value 256))
  (put buf (+ offset 1) (% (math/floor (/ value 256)) 256))
  (put buf (+ offset 2) (% (math/floor (/ value 65536)) 256))
  (put buf (+ offset 3) (% (math/floor (/ value 16777216)) 256)))

(defn- put-le-i32 [buf offset value]
  (put-le-u32 buf offset (if (neg? value) (+ value 4294967296) value)))

(defn payload-of
  "256 heights that vary per column, so a transposed or shifted payload fails."
  [&opt base]
  (def b (or base 8))
  (def out (buffer/new-filled tc/payload-bytes 0))
  (for z 0 16
    (for x 0 16
      (def span (- tc/height-max tc/height-min))
      (put out (+ x (* 16 z)) (min tc/height-max (+ b (% (+ (* z 3) x) span))))))
  out)

(defn tile-for
  ``Build a well-formed TDH2 tile for `(cx cz)`.

  The SHA-256 field is a recognisable pattern: the consumer must skip those 32
  bytes, and a fixture holding a real digest would quietly let a future
  "verify it here" change look correct.``
  [cx cz heights]
  (def out (buffer/new-filled tc/tile-bytes 0))
  (put out 0 84) (put out 1 68) (put out 2 72) (put out 3 50)   # TDH2
  (put-le-i32 out 4 cx)
  (put-le-i32 out 8 cz)
  (put-le-u32 out 12 tc/payload-bytes)
  (put-le-u32 out 16 (integrity/crc32 (string heights)))
  (for i 0 32 (put out (+ 20 i) (% (+ i 7) 256)))
  (for i 0 tc/payload-bytes (put out (+ tc/header-bytes i) (get heights i)))
  out)

(defn copy-tile [bytes]
  (def out (buffer/new-filled tc/tile-bytes 0))
  (for i 0 tc/tile-bytes (put out i (get bytes i)))
  out)

(defn write-bytes [path bytes]
  (def f (file/open path :wbn))
  (file/write f bytes)
  (file/close f))

(defn write-tile [dir cx cz heights]
  # The consumer only ever creates requests/, so a fixture that writes into
  # tiles/ must make that directory itself, exactly as a real backend would.
  (try (os/mkdir (tc/tiles-dir dir)) ([e] nil))
  (write-bytes (tc/tile-path dir cx cz) (tile-for cx cz heights)))

(defn write-manifest [dir &opt identity seed]
  (write-bytes (string dir "/manifest.janet")
               (string "{:format 2 :magic \"TDH2\" :identity \""
                      (or identity (string/repeat "a" 64))
                      "\" :seed " (or seed 1234)
                      " :payload-bytes 256 :tile-bytes 308}")))

(defn rejects? [bytes cx cz]
  (not (get (protect (tc/decode-tile bytes cx cz)) 0)))

(defn message-of [thunk]
  (def r (protect (thunk)))
  (if (get r 0) nil (string (get r 1))))

(defn throws? [thunk]
  (not (get (protect (thunk)) 0)))

#
# --- Decode round trip --------------------------------------------------
#
(print "decode round trip:")
(def payload (payload-of))
(def tile (tile-for 0 0 payload))
(def decoded (tc/decode-tile tile 0 0))
(check "a well-formed tile decodes" (not (nil? decoded)))
(check "the payload is a 256-byte buffer"
       (and (= :buffer (type decoded)) (= tc/payload-bytes (length decoded))))
(check "every height survives the round trip"
       (do (var ok true)
           (for i 0 tc/payload-bytes
             (unless (= (get payload i) (get decoded i)) (set ok false)))
           ok))
(check "the tile is exactly 308 bytes" (= 308 (length tile)))
(check "header-bytes is 52" (= 52 tc/header-bytes))
(check "a decoded buffer is independent of the file bytes"
       (do (put tile tc/header-bytes 0)
           (= (get payload 0) (get decoded 0))))
(def neg-tile (tile-for -3 12 (payload-of 20)))
(check "negative coordinates decode" (= 20 (get (tc/decode-tile neg-tile -3 12) 0)))
(check "a negative coordinate stamps a signed filename"
       (string/has-suffix? "/-3_12.tdh" (tc/tile-path "d" -3 12)))
(check "x-fastest indexing is preserved"
       (= (get payload (+ 1 (* 16 2))) (get decoded (+ 1 (* 16 2)))))

#
# --- Cross-language fixture ---------------------------------------------
#
# The 52-byte header below was produced by the Python writer, not by this
# fixture:
#
#   python3 -c "import sys; sys.path.insert(0,'tools'); import terrain_cache \
#     as tc; print(tc.encode_tile(-2, 5, bytes([30])*256)[:52].hex())"
#   -> 54444832feffffff05000000000100008aa2081230682b91e560e2f8a51dc49fd795
#      34c0609f1711521b8eecdf112e135d3e083b
#
# Byte-for-byte agreement here is the cross-language contract: the same magic,
# the same little-endian -2 and 5, the same length 256, the same CRC-32
# (0x1208a28a) and the same SHA-256. This side verifies everything except the
# SHA-256, which it must skip rather than recompute. The payload is 256 x 0x1e.
(print "cross-language fixture:")
(def python-header
  "54444832feffffff05000000000100008aa2081230682b91e560e2f8a51dc49fd79534c0609f1711521b8eecdf112e135d3e083b")
(defn unhex [s]
  (def out (buffer/new-filled (/ (length s) 2) 0))
  (for i 0 (length out)
    (put out i (scan-number (string "0x" (string/slice s (* 2 i) (+ 2 (* 2 i)))))))
  out)
(def python-tile (buffer/new-filled tc/tile-bytes 0))
(for i 0 52 (put python-tile i (get (unhex python-header) i)))
(for i 0 tc/payload-bytes (put python-tile (+ tc/header-bytes i) 30))
(def python-decoded (tc/decode-tile python-tile -2 5))
(check "a Python-written header decodes here"
       (= tc/payload-bytes (length python-decoded)))
(check "its payload reads back exactly" (and (= 30 (get python-decoded 0))
                                             (= 30 (get python-decoded 255))))
(check "the shared CRC-32 agrees with Python's 0x1208a28a"
       (= 302555786 (integrity/crc32 (string/slice python-tile tc/header-bytes tc/tile-bytes))))
(check "the Python tile is accepted for its own chunk"
       (not (rejects? python-tile -2 5)))
(check "the Python tile is refused for another chunk"
       (rejects? python-tile -2 6))

#
# --- Decode rejections --------------------------------------------------
#
(print "decode rejections:")
(check "a 304-byte TDH1-sized file is rejected"
       (rejects? (buffer/new-filled 304 0) 0 0))
(check "a short header is rejected" (rejects? (buffer/new-filled 20 0) 0 0))
(check "trailing bytes are rejected"
       (let [big (buffer/new-filled (+ tc/tile-bytes 1) 0)]
         (for i 0 tc/tile-bytes (put big i (get tile i)))
         (rejects? big 0 0)))
(check "a TDH1 magic is rejected"
       (let [old (copy-tile tile)]
         (put old 3 49)
         (rejects? old 0 0)))
(check "another magic is rejected"
       (let [bad (copy-tile tile)]
         (put bad 0 88)
         (rejects? bad 0 0)))
(check "mismatched header coordinates are rejected"
       (rejects? (tile-for 1 2 payload) 1 3))
(check "a wrong payload length is rejected"
       (let [bad (copy-tile tile)]
         (put-le-u32 bad 12 255)
         (rejects? bad 0 0)))
(check "a corrupted payload byte fails the CRC"
       (let [bad (copy-tile tile)]
         (put bad (+ tc/header-bytes 200) (+ 1 (get bad (+ tc/header-bytes 200))))
         (rejects? bad 0 0)))
(check "a corrupted CRC field fails"
       (let [bad (copy-tile tile)]
         (put-le-u32 bad 16 0)
         (rejects? bad 0 0)))
(check "a height below the band is rejected"
       (let [h (payload-of)]
         (put h 5 3)
         (rejects? (tile-for 0 0 h) 0 0)))
(check "a height above the band is rejected"
       (let [h (payload-of)]
         (put h 5 61)
         (rejects? (tile-for 0 0 h) 0 0)))
(check "non-integer requested coordinates are rejected"
       (throws? (fn [] (tc/decode-tile tile 0.5 0))))
(check "out-of-range requested coordinates are rejected"
       (throws? (fn [] (tc/decode-tile tile 2147483648 0))))
(check "the CRC rejection names the CRC"
       (string/find "CRC-32"
                    (message-of (fn []
                                  (def bad (copy-tile tile))
                                  (put bad (+ tc/header-bytes 1)
                                       (+ 1 (get bad (+ tc/header-bytes 1))))
                                  (tc/decode-tile bad 0 0)))))
(check "the magic rejection names TDH2"
       (string/find "TDH2"
                    (message-of (fn []
                                  (def bad (copy-tile tile))
                                  (put bad 0 88)
                                  (tc/decode-tile bad 0 0)))))

#
# --- Manifest -----------------------------------------------------------
#
(print "manifest:")
(def root (scratch-dir))
(def identity (string/repeat "b" 64))
(write-manifest root identity 777)
(def record (tc/load-manifest root))
(check "a valid manifest loads" (= identity (record :identity)))
(check "the record is frozen" (= :struct (type record)))
(check "the format version is pinned" (= 2 (record :format)))
(check "the seed is carried" (= 777 (record :seed)))
(check "the magic is echoed" (= "TDH2" (record :magic)))

(def mroot (scratch-dir))
(check "a missing manifest is actionable"
       (string/find "no manifest.janet"
                    (message-of (fn [] (tc/load-manifest mroot)))))
(defn manifest-error [text]
  (write-bytes (string mroot "/manifest.janet") text)
  (message-of (fn [] (tc/load-manifest mroot))))
(def hex (string/repeat "b" 64))
(check "a short identity is refused"
       (not (nil? (manifest-error
                   (string "{:format 2 :magic \"TDH2\" :identity \"abc\" :seed 1"
                           " :payload-bytes 256 :tile-bytes 308}")))))
(check "an unexpected key is refused"
       (not (nil? (manifest-error
                   (string "{:format 2 :magic \"TDH2\" :identity \"" hex
                           "\" :seed 1 :payload-bytes 256 :tile-bytes 308 :extra 1}")))))
(check "a missing key is refused"
       (not (nil? (manifest-error (string "{:format 2 :identity \"" hex "\" :seed 1}")))))
(check "the obsolete format number is refused"
       (not (nil? (manifest-error
                   (string "{:format 1 :magic \"TDH2\" :identity \"" hex
                           "\" :seed 1 :payload-bytes 256 :tile-bytes 308}")))))
(check "the obsolete magic is refused"
       (not (nil? (manifest-error
                   (string "{:format 2 :magic \"TDH1\" :identity \"" hex
                           "\" :seed 1 :payload-bytes 256 :tile-bytes 308}")))))
(check "the obsolete tile size is refused"
       (not (nil? (manifest-error
                   (string "{:format 2 :magic \"TDH2\" :identity \"" hex
                           "\" :seed 1 :payload-bytes 256 :tile-bytes 304}")))))
(check "a non-integer seed is refused"
       (not (nil? (manifest-error
                   (string "{:format 2 :magic \"TDH2\" :identity \"" hex
                           "\" :seed 1.5 :payload-bytes 256 :tile-bytes 308}")))))
(check "a valid manifest is accepted after the failures"
       (= 1 ((do (write-bytes (string mroot "/manifest.janet")
                              (string "{:format 2 :magic \"TDH2\" :identity \"" hex
                                      "\" :seed 1 :payload-bytes 256 :tile-bytes 308}"))
                  (tc/load-manifest mroot))
             :seed)))

# A form is data to the reader, so the refusal must come from the plain-data
# gate -- and nothing may have been evaluated, which would have removed the
# marker file.
(def inert-root (scratch-dir))
(def marker (string inert-root "/executed.marker"))
(write-bytes (string inert-root "/manifest.janet")
             (string "{:format 2 :magic (do (os/rm \"" marker "\") \"TDH2\")"
                     " :identity \"" hex "\" :seed 1 :payload-bytes 256"
                     " :tile-bytes 308}"))
(check "a manifest holding a form is refused"
       (string/find "non-data"
                    (message-of (fn [] (tc/load-manifest inert-root)))))
(check "the refused manifest was never evaluated" (nil? (os/stat marker)))
(write-bytes (string inert-root "/manifest.janet") "{:a 1} {:b 2}")
(check "two forms are refused" (throws? (fn [] (tc/load-manifest inert-root))))
(write-bytes (string inert-root "/manifest.janet") ":just-a-keyword")
(check "a non-table form is refused" (throws? (fn [] (tc/load-manifest inert-root))))

#
# --- Consumer construction ---------------------------------------------
#
(print "consumer:")
(def cache (tc/cache-new root 777))
(check "a matching seed opens" (= 777 (cache :seed)))
(check "opening wrote no requests directory"
       (nil? (os/stat (tc/requests-dir root))))
(check "capacity defaults to 64" (= 64 (cache :capacity)))
(check "a mismatched seed is refused"
       (string/find "baked for seed" (message-of (fn [] (tc/cache-new root 778)))))
(def small (tc/cache-new root 777 1))
(check "capacity is honoured" (= 1 (small :capacity)))
(check "capacity above the hard cap is refused"
       (throws? (fn [] (tc/cache-new root 777 129))))
(check "zero capacity is refused"
       (throws? (fn [] (tc/cache-new root 777 0))))

#
# --- Reading ------------------------------------------------------------
#
(print "reading:")
(check "an absent tile reads as nil" (nil? (tc/read-height-tile cache 5 6)))
(def heights (payload-of 30))
(write-tile root 5 6 heights)
(def read-back (tc/read-height-tile cache 5 6))
(check "a written tile reads back" (not (nil? read-back)))
(check "the read heights match"
       (do (var ok true)
           (for i 0 tc/payload-bytes
             (unless (= (get heights i) (get read-back i)) (set ok false)))
           ok))
(write-tile root -1 -2 (payload-of 12))
(check "a negative coordinate reads back"
       (= 12 (get (tc/read-height-tile cache -1 -2) 0)))
(check "available? tracks a successful read" (tc/available? cache 5 6))

(def corrupt-root (scratch-dir))
(write-manifest corrupt-root identity 55)
(def corrupt-cache (tc/cache-new corrupt-root 55))
(try (os/mkdir (tc/tiles-dir corrupt-root)) ([e] nil))
(write-bytes (tc/tile-path corrupt-root 0 0) (buffer/new-filled 3 7))
(check "a corrupt tile throws instead of reading as absent"
       (throws? (fn [] (tc/read-height-tile corrupt-cache 0 0))))
(check "the corrupt tile error is actionable"
       (string/find "truncated"
                    (message-of (fn [] (tc/read-height-tile corrupt-cache 0 0)))))

# A runaway writer must not be able to make one frame read an unbounded file:
# the read is capped at 309 bytes and the oversize tile is refused.
(write-bytes (tc/tile-path corrupt-root 0 1) (buffer/new-filled 5000000 30))
(check "an oversized tile is refused, not truncated into a valid one"
       (string/find "larger than"
                    (message-of (fn [] (tc/read-height-tile corrupt-cache 0 1)))))
(write-bytes (tc/tile-path corrupt-root 0 2) (buffer/new-filled 309 30))
(check "one byte over 308 is refused before decoding"
       (string/find "larger than"
                    (message-of (fn [] (tc/read-height-tile corrupt-cache 0 2)))))
# The cap is 309 bytes, so a huge tile costs at most 309 bytes of memory but is
# never accepted: the oversize check fires on the capped read, not on the size
# the file reports.
(check "the oversized read is capped at 309 bytes"
       (= 309 (+ 1 tc/tile-bytes)))

(def error-root (scratch-dir))
(write-manifest error-root identity 66)
(def error-cache (tc/cache-new error-root 66))
(try (os/mkdir (tc/errors-dir error-root)) ([e] nil))
(write-bytes (tc/error-path error-root 1 1) "backend crashed\n")
(check "a terminal backend error throws rather than reading as absent"
       (throws? (fn [] (tc/read-height-tile error-cache 1 1))))
(check "the terminal error carries the backend text"
       (string/find "backend crashed"
                    (message-of (fn [] (tc/read-height-tile error-cache 1 1)))))

(write-bytes (tc/error-path error-root 2 2)
             (string (string/repeat "x" 400) "\n"))
(check "an oversized error file is capped, not swallowed whole"
       (let [msg (message-of (fn [] (tc/read-height-tile error-cache 2 2)))]
         (and (< (length msg) 260) (string/find "..." msg))))

#
# --- Requests -----------------------------------------------------------
#
(print "requests:")
(def qroot (scratch-dir))
(write-manifest qroot identity 99)
(def q (tc/cache-new qroot 99))
(check "a first request is published" (= :requested (tc/request q 2 3)))
(check "the marker file exists"
       (not (nil? (os/stat (tc/request-path qroot 2 3)))))
(check "the marker body is an echo, not a message"
       (string/find "format=TDH2"
                    (string (try (file/read (file/open (tc/request-path qroot 2 3) :rb)
                                            :all)
                                 ([e] "")))))
(check "repeating a request is suppressed" (= :suppressed (tc/request q 2 3)))
(check "only one pending entry exists" (= 1 ((tc/status q) :pending)))
(check "negative coordinates stamp a signed marker"
       (and (= :requested (tc/request q -7 8))
            (not (nil? (os/stat (tc/request-path qroot -7 8))))))
(check "a present tile is :ready, not requested"
       (do (write-tile qroot 9 9 (payload-of))
           (= :ready (tc/request q 9 9))))
(check "a terminally failed coordinate is suppressed"
       (do (try (os/mkdir (tc/errors-dir qroot)) ([e] nil))
           (write-bytes (tc/error-path qroot 11 11) "nope\n")
           (= :suppressed (tc/request q 11 11))))
(check "cancel removes a pending coordinate" (true? (tc/cancel q 2 3)))
(check "cancelling an unknown coordinate is false" (false? (tc/cancel q 2 3)))
(check "the marker survives cancellation"
       (not (nil? (os/stat (tc/request-path qroot 2 3)))))
(check "a full pending set answers :queued"
       (do (= :requested (tc/request small 20 20))
           (= :queued (tc/request small 21 21))))

#
# --- Poll ---------------------------------------------------------------
#
(print "poll:")
(def proot (scratch-dir))
(write-manifest proot identity 1234)
(def p (tc/cache-new proot 1234))
(for i 0 6 (tc/request p i 0))
(check "six coordinates are pending" (= 6 ((tc/status p) :pending)))
(check "an empty poll before anything is ready" (empty? (tc/poll p)))
(check "poll does not change the pending count" (= 6 ((tc/status p) :pending)))
# Only the LAST queued coordinate becomes ready. A poll that always started at
# the head would never reach it.
(write-tile proot 5 0 (payload-of 40))
(var rounds 0)
(var found nil)
(while (and (nil? found) (< rounds 8))
  (++ rounds)
  (each r (tc/poll p 1)
    (when (= :ready (get r 0)) (set found r))))
(check "rotation reaches a ready coordinate behind unanswered ones"
       (not (nil? found)))
(check "the collected heights are correct" (= 40 (get (get found 3) 0)))
(check "a collected coordinate left the pending set" (= 5 ((tc/status p) :pending)))

(def eroot (scratch-dir))
(write-manifest eroot identity 4321)
(def e (tc/cache-new eroot 4321))
(tc/request e 3 3)
(try (os/mkdir (tc/errors-dir eroot)) ([e2] nil))
(write-bytes (tc/error-path eroot 3 3) "sampler died\n")
(def polled (tc/poll e))
(check "a backend error surfaces from poll" (= :error (get (get polled 0) 0)))
(check "the polled error carries the reason"
       (string/find "sampler died" (get (get polled 0) 3)))
(check "an error is terminal in the cache" (tc/failed? e 3 3))
(check "the failed coordinate left the pending set" (= 0 ((tc/status e) :pending)))
(check "a failed coordinate is never re-requested" (= :suppressed (tc/request e 3 3)))

(def broot (scratch-dir))
(write-manifest broot identity 555)
(def b (tc/cache-new broot 555))
(tc/request b 4 4)
(try (os/mkdir (tc/tiles-dir broot)) ([e3] nil))
(write-bytes (tc/tile-path broot 4 4) (buffer/new-filled tc/tile-bytes 0))
(def bad-poll (tc/poll b))
(check "a corrupt tile surfaces as a poll error" (= :error (get (get bad-poll 0) 0)))
(check "poll never threw on the corrupt tile" (tc/failed? b 4 4))
(check "poll on a closed cache returns nothing"
       (do (tc/close b) (empty? (tc/poll b))))
(check "request on a closed cache answers :closed" (= :closed (tc/request b 6 6)))
(check "the closed flag is reported" (true? ((tc/status b) :closed)))

#
# --- Scenic (TDS3) -------------------------------------------------------
#
# A scenic map is one finite artifact with a taller band. Everything below is
# built from the documented format-3 contract; the producer's own twin is not
# used because it does not yet carry bounds or a JSON binding.
#
(print "scenic:")
(def sr (scratch-dir))
(def sident (string/repeat "c" 64))
(def sjson (string "{\"profile\": \"scenic\", \"seed\": 2024}\n"))
(def scrc (integrity/crc32 sjson))

(defn write-scenic
  [dir &opt opts]
  (def o (or opts @{}))
  (def bounds (get o :bounds [0 0 3 2]))
  (def origin (get o :origin [64 -32]))
  (def lo (get o :height-min 4))
  (def hi (get o :height-max 252))
  (def jbytes (get o :json-bytes (length sjson)))
  (def jcrc (get o :json-crc32 scrc))
  (write-bytes (tc/scenic-json-path dir) (or (get o :json) sjson))
  (write-bytes (string dir "/manifest.janet")
               (string "{:format 3 :magic \"TDS3\" :identity \""
                      (or (get o :identity) sident)
                      "\" :seed " (or (get o :seed) 2024)
                      " :payload-bytes 256 :tile-bytes 308"
                      " :height-min " lo " :height-max " hi
                      " :bounds [" (get bounds 0) " " (get bounds 1) " "
                      (get bounds 2) " " (get bounds 3) "]"
                      " :origin [" (get origin 0) " " (get origin 1) "]"
                      " :json-bytes " jbytes " :json-crc32 " jcrc "}")))

# A scenic tile: same 308-byte envelope, magic TDS3, heights in 4..252.
(defn scenic-tile-for
  [cx cz heights]
  (def out (buffer/new-filled tc/tile-bytes 0))
  (put out 0 84) (put out 1 68) (put out 2 83) (put out 3 51)   # TDS3
  (put-le-i32 out 4 cx)
  (put-le-i32 out 8 cz)
  (put-le-u32 out 12 tc/payload-bytes)
  (put-le-u32 out 16 (integrity/crc32 (string heights)))
  (for i 0 32 (put out (+ 20 i) (% (+ i 11) 256)))
  (for i 0 tc/payload-bytes (put out (+ tc/header-bytes i) (get heights i)))
  out)

(defn scenic-heights
  ``256 heights that really span 4..252, so a legacy 4..60 clamp fails loudly.

  Includes both ends explicitly: the whole point of the wider band is that 252
  survives a round trip, and a fixture that topped out at 129 would pass even if
  the decoder silently clamped.``
  [&opt base]
  (def b (or base 40))
  (def out (buffer/new-filled tc/payload-bytes 0))
  (for i 0 tc/payload-bytes
    (put out i (+ 4 (% (+ (* i 17) b) 249))))       # 4..252
  (put out 0 tc/height-min)
  (put out 1 tc/scenic-height-max)
  (put out 2 (+ 1 tc/height-max))                   # above the legacy ceiling
  out)

(write-scenic sr)
(def sm (tc/load-manifest sr))
(check "a scenic manifest loads" (= :scenic (sm :profile)))
(check "the scenic profile is reported by the record" (= 3 (sm :format)))
(check "bounds are read as [cx0 cz0 cx1 cz1]" (= [0 0 3 2] (sm :bounds)))
(check "the fixed global origin is carried" (= [64 -32] (sm :origin)))
(check "the scenic band is read, not assumed" (and (= 4 (sm :height-min))
                                                  (= 252 (sm :height-max))))
(check "the record binds the JSON by size and CRC"
       (and (= (length sjson) (sm :json-bytes)) (= scrc (sm :json-crc32))))

# --- the band is the point of the format ------------------------------
(def hi-h (buffer/new-filled tc/payload-bytes 252))
(def hi-tile (scenic-tile-for 0 0 hi-h))
(check "252 is accepted by TDS3" (not (rejects? hi-tile 0 0)))
(put hi-h 0 253)
(check "253 is refused by TDS3 (reserved)" (rejects? (scenic-tile-for 0 0 hi-h) 0 0))
(put hi-h 0 255)
(check "255 is refused by TDS3" (rejects? (scenic-tile-for 0 0 hi-h) 0 0))
(def low-h (buffer/new-filled tc/payload-bytes 4))
(put low-h 3 3)
(check "3 is refused by TDS3 (band floor)" (rejects? (scenic-tile-for 0 0 low-h) 0 0))
(check "the scenic band is derived from the magic, not a manifest"
       (= :scenic (tc/tile-profile hi-tile)))
(check "a legacy tile is still profiled as legacy" (= :legacy (tc/tile-profile tile)))

# --- profile agreement -------------------------------------------------
(check "a TDH2 tile is refused by decode-tile-for :scenic"
       (throws? (fn [] (tc/decode-tile-for :scenic tile 0 0))))
(check "a TDS3 tile is refused by decode-tile-for :legacy"
       (throws? (fn [] (tc/decode-tile-for :legacy hi-tile 0 0))))
(check "the profile refusal names the expected magic"
       (string/find "TDS3"
                    (message-of (fn [] (tc/decode-tile-for :scenic tile 0 0)))))
# `tile` was deliberately corrupted above by the independence check, so this
# builds fresh bytes rather than reusing a mutated buffer.
(check "decode-tile alone still accepts either profile"
       (and (not (rejects? (tile-for 0 0 payload) 0 0))
            (not (rejects? (scenic-tile-for 0 0 (scenic-heights)) 0 0))))

# --- manifest key sets -------------------------------------------------
(def nat (scratch-dir))
(defn scenic-error [dir text &opt json]
  (write-bytes (tc/scenic-json-path dir) (or json sjson))
  (write-bytes (string dir "/manifest.janet") text)
  (message-of (fn [] (tc/load-manifest dir))))
(defn twin [overrides]
  (string "{:format 3 :magic \"TDS3\" :identity \"" sident "\" :seed 2024"
          " :payload-bytes 256 :tile-bytes 308 :height-min 4 :height-max 252"
          " :bounds [0 0 3 2] :origin [64 -32]"
          " :json-bytes " (length sjson) " :json-crc32 " scrc " " overrides "}"))
(check "a scenic twin without bounds is refused"
       (string/find "bounds"
                    (scenic-error nat (string "{:format 3 :magic \"TDS3\" :identity \""
                                              sident "\" :seed 2024 :payload-bytes 256"
                                              " :tile-bytes 308 :height-min 4"
                                              " :height-max 252 :origin [64 -32]"
                                              " :json-bytes " (length sjson)
                                              " :json-crc32 " scrc "}"))))
(check "a scenic twin with an extra key is refused"
       (string/find "unexpected key"
                    (scenic-error nat (string (twin ":extra 1")))))
(check "a scenic twin claiming format 2 is refused"
       (string/find "format"
                    (scenic-error nat (string/replace "{:format 3" "{:format 2"
                                                      (twin "")))))
# Swapping the magic selects the LEGACY profile, whose six-key set cannot hold
# a scenic twin -- so the refusal comes from the key set, which is the point:
# a magic swap cannot smuggle scenic fields past a legacy reader.
(check "a scenic twin claiming a legacy magic is refused"
       (string/find "unexpected key"
                    (scenic-error nat (string/replace "\"TDS3\"" "\"TDH2\""
                                                      (twin "")))))
(check "a TDH2 twin cannot smuggle a bounds field"
       (string/find "unexpected key"
                    (scenic-error nat
                                  (string "{:format 2 :magic \"TDH2\" :identity \""
                                          sident "\" :seed 2024 :payload-bytes 256"
                                          " :tile-bytes 308 :bounds [0 0 1 1]}"))))
(check "a scenic twin declaring an over-wide band is refused"
       (string/find "outside the TDS3 band"
                    (scenic-error nat (string/replace ":height-max 252" ":height-max 255"
                                                      (twin "")))))
# Narrowing is legitimate -- a map that really tops out lower may say so. Only
# WIDENING is refused, because the ceiling belongs to the format.
(check "a narrower scenic band is accepted"
       (do (scenic-error nat (string/replace ":height-max 252" ":height-max 200"
                                             (twin "")))
           (= 200 (get (tc/load-manifest nat) :height-max))))
(check "a raised band floor is accepted"
       (do (scenic-error nat (string/replace ":height-min 4" ":height-min 20"
                                             (twin "")))
           (= 20 (get (tc/load-manifest nat) :height-min))))
(check "an inverted band is refused"
       (let [text (string/replace ":height-min 4" ":height-min 200"
                                  (string/replace ":height-max 252" ":height-max 100"
                                                  (twin "")))]
         (and (string/find "outside the TDS3 band"
                           (scenic-error nat text)) true)))
(check "a scenic twin with a 3-element bounds vector is refused"
       (string/find "four-element"
                    (scenic-error nat (string/replace "[0 0 3 2]" "[0 0 3]" (twin "")))))
(check "reversed bounds are refused"
       (string/find "cx0<=cx1"
                    (scenic-error nat (string/replace "[0 0 3 2]" "[5 0 3 2]" (twin "")))))
(check "reversed z bounds are refused"
       (string/find "cz0<=cz1"
                    (scenic-error nat (string/replace "[0 0 3 2]" "[0 9 3 2]" (twin "")))))
(check "a single-element origin is refused"
       (string/find "two-element"
                    (scenic-error nat (string/replace "[64 -32]" "[64]" (twin "")))))
(check "a non-integer bound is refused"
       (string/find "signed 32-bit"
                    (scenic-error nat (string/replace "[0 0 3 2]" "[0 0 3.5 2]" (twin "")))))

# --- the JSON binding --------------------------------------------------
(check "a missing provenance.json is refused"
       (string/find "no provenance.json"
                    (do (os/rm (tc/scenic-json-path nat))
                        (write-bytes (string nat "/manifest.janet") (twin ""))
                        (message-of (fn [] (tc/load-manifest nat))))))
# A same-length tamper isolates the CRC check from the size check.
(def tampered (string/replace "scenic" "SCENIC" sjson))
(check "a same-size tampered JSON fails the CRC"
       (= (length sjson) (length tampered)))
(check "a JSON CRC mismatch is refused"
       (string/find "CRC-32"
                    (scenic-error nat (twin "") tampered)))
(check "a different-length JSON fails the size check first"
       (string/find "bytes"
                    (scenic-error nat (twin "") (string "{\"profile\": 1}\n"))))
(check "a JSON size mismatch is refused"
       (string/find "bytes"
                    (scenic-error nat (string/replace (string " :json-bytes "
                                                              (length sjson))
                                                      " :json-bytes 40" (twin "")))))
(check "a truncated JSON is refused"
       (let [partial (string/slice sjson 0 10)]
         (string/find "bytes"
                      (scenic-error nat
                                    (string "{:format 3 :magic \"TDS3\" :identity \""
                                            sident "\" :seed 2024 :payload-bytes 256"
                                            " :tile-bytes 308 :height-min 4"
                                            " :height-max 252 :bounds [0 0 3 2]"
                                            " :origin [64 -32] :json-bytes "
                                            (length sjson) " :json-crc32 " scrc "}")
                                    partial))))
(check "the untampered pair loads again" (= :scenic ((tc/load-manifest sr) :profile)))

# --- consumer ----------------------------------------------------------
(def sc (tc/cache-new sr 2024))
(check "a scenic cache opens" (= :scenic (tc/cache-profile sc)))
(check "cache-bounds reports the declared map" (= [0 0 3 2] (tc/cache-bounds sc)))
(check "cache-meta is frozen" (= :struct (type (tc/cache-meta sc))))
(check "cache-meta carries the origin" (= [64 -32] ((tc/cache-meta sc) :origin)))
(check "a mismatched seed is still refused for a scenic cache"
       (string/find "baked for seed"
                    (message-of (fn [] (tc/cache-new sr 999)))))
(def lg (tc/cache-new root 777))
(check "a legacy cache reports :legacy" (= :legacy (tc/cache-profile lg)))
(check "a legacy cache has no bounds" (nil? (tc/cache-bounds lg)))
(check "a legacy cache is unbounded" (and (tc/in-bounds? lg -999 999)))
(check "in-bounds? accepts the map corners"
       (and (tc/in-bounds? sc 0 0) (tc/in-bounds? sc 3 2)))
(check "in-bounds? rejects just outside"
       (and (not (tc/in-bounds? sc -1 0)) (not (tc/in-bounds? sc 4 2))
            (not (tc/in-bounds? sc 0 3))))

(check "a scenic tile reads back with its tall heights"
       (do (try (os/mkdir (tc/tiles-dir sr)) ([e] nil))
           (write-bytes (tc/tile-path sr 1 1) (scenic-tile-for 1 1 (scenic-heights)))
           (= 252 (apply max (map (fn [i] (get (tc/read-height-tile sc 1 1) i))
                                  (range tc/payload-bytes))))))
(check "a legacy tile in a scenic cache is refused"
       (do (write-bytes (tc/tile-path sr 2 2) (tile-for 2 2 (payload-of 30)))
           (throws? (fn [] (tc/read-height-tile sc 2 2)))))
(check "that refusal names the profile's magic"
       (string/find "TDS3"
                    (message-of (fn [] (tc/read-height-tile sc 2 2)))))
(check "a scenic tile in a legacy cache is refused"
       (do (try (os/mkdir (tc/tiles-dir root)) ([e] nil))
           (write-bytes (tc/tile-path root 40 40) (scenic-tile-for 40 40 hi-h))
           (throws? (fn [] (tc/read-height-tile lg 40 40)))))
(check "a tile beyond the map bounds is refused, not served"
       (do (write-bytes (tc/tile-path sr 9 9) (scenic-tile-for 9 9 (scenic-heights)))
           (string/find "outside the declared map bounds"
                        (message-of (fn [] (tc/read-height-tile sc 9 9))))))
(check "absent and out of bounds is nil, not an error"
       (nil? (tc/read-height-tile sc 8 8)))

(check "request outside the map is :out-of-bounds"
       (= :out-of-bounds (tc/request sc -1 0)))
(check "an out-of-bounds request writes no marker"
       (nil? (os/stat (tc/request-path sr -1 0))))
(check "an out-of-bounds request does not add to the queue"
       (= 0 ((tc/status sc) :pending)))
(check "request inside the map still works" (= :requested (tc/request sc 2 1)))
(check "status reports the profile" (= :scenic ((tc/status sc) :profile)))
(check "status reports the bounds" (= [0 0 3 2] ((tc/status sc) :bounds)))

#
# --- Optional climate: explicit projection ------------------------------
#
# The buffers below are the PRODUCER's wire, packed here byte by byte as
# little-endian channel-last float32 in (H, W, 5) order -- exactly what
# `tools/scenic_terrain.py` stores as `arrays["climate"]`. Nothing here builds
# them through `climate-tile`, so a reader bug cannot make its own test pass.
#
# Every value is an integer below 2^24, which float32 holds EXACTLY, so a cell
# assertion is an identity rather than a tolerance.
#
(print "climate attachment:")

(defn- f32-into
  ``Write `v` into `buf` at `offset` as little-endian float32.

  `math/frexp` cannot express zero (it would write a denormal), so zero is
  handled explicitly.``
  [buf offset v]
  (def bits
    (cond
      (= v 0) 0
      true
      (let [[frac e] (math/frexp (math/abs v))
            m (math/floor (* frac 16777216))
            sign (if (< v 0) (blshift 1 31) 0)
            raw (bor sign (blshift (+ e 126) 23) (- m 8388608))]
        (if (< raw 0) (+ raw 4294967296) raw))))
  (put buf offset (% bits 256))
  (put buf (+ offset 1) (% (math/floor (/ bits 256)) 256))
  (put buf (+ offset 2) (% (math/floor (/ bits 65536)) 256))
  (put buf (+ offset 3) (% (math/floor (/ bits 16777216)) 256)))

(defn- climate-buffer
  "A channel-last (h w 5) float32 buffer where channel c is `c*100000 + x + 1000z`."
  [h w &opt shift]
  (def s (or shift 0))
  (def buf (buffer/new-filled (* h w 5 4) 0))
  (for z 0 h
    (for x 0 w
      (for c 0 5
        (f32-into buf (* (+ (* (+ (* z w) x) 5) c) 4)
                  (+ s (* c 100000) x (* 1000 z))))))
  buf)

(defn- channel-value
  "The reference value `climate-buffer` writes at grid cell (x, z), channel c."
  [x z c] (+ (* c 100000) x (* 1000 z)))

(defn- nan-buffer
  "The same grid, but the first channel of sample 2 is a quiet NaN (0x7FC00000)."
  [h w]
  (def buf (climate-buffer h w))
  (def off (* (* 2 5) 4))
  (for i 0 4 (put buf (+ off i) 0))
  (put buf (+ off 2) 192)
  (put buf (+ off 3) 127)
  buf)

(def climate-meta @{:has_climate true})
(def no-climate-meta @{:has_climate false})

# The primary map is the SHAPE OF A REAL ARTIFACT on disk
# (`worlds-v1/15f2268d.../provenance.json` records bounds [-1 -1 6 6] and
# origin [-16 -16]): 8 x 8 chunks -> 128 x 128 cells, anchored at world -16.
# `sr` declares [0 0 3 2] instead, so it is used where bounds alone suffice.
(def map-shape [128 128 5])
(def map-buffer (climate-buffer 128 128))

(def artroot (scratch-dir))
(write-scenic artroot @{:bounds [-1 -1 6 6] :origin [-16 -16]})
(def art (tc/cache-new artroot 2024))

# Heights read BEFORE any climate exists. An optional product that changed this
# would not be optional.
(def heights-before (tc/read-height-tile sc 1 1))

(check "climate-extent reports chunks and cells"
       (= [8 8 128 128] (tc/climate-extent art)))
(check "climate-shape is the 1:1 grid for that extent"
       (= map-shape (tc/climate-shape art)))
(check "a legacy cache has no extent" (nil? (tc/climate-extent lg)))
(check "a legacy cache has no climate shape" (nil? (tc/climate-shape lg)))
(check "an unattached cache reports :not-attached"
       (= :not-attached ((tc/cache-climate art) :reason)))
(check "an unattached cache has no projection"
       (nil? (tc/climate-projection art)))
(check "the not-attached record carries no values key"
       (nil? (get tc/not-attached :values)))
(check "unattached climate-at is unavailable, not an error"
       (= :not-attached ((tc/climate-at art -1 -1) :reason)))

# --- attachment -------------------------------------------------------
(def decoded (ct/read map-buffer map-shape climate-meta))
(check "attach-climate! accepts a validated 1:1 result"
       (= :present ((tc/attach-climate! art decoded [-16 -16] 1) :status)))
(check "the projection is stored, not inferred"
       (let [p (tc/climate-projection art)]
         (and (deep= [-16 -16] (p :origin)) (= 1 (p :scale)))))
(check "status reports :present" (= :present ((tc/status art) :climate)))

# --- absence changes nothing about height access ----------------------
(check "heights read identically after attaching climate"
       (let [after (tc/read-height-tile sc 1 1)]
         (and (= (length heights-before) (length after))
              (do (var same true)
                  (for i 0 tc/payload-bytes
                    (unless (= (get heights-before i) (get after i))
                      (set same false)))
                  same))))
(check "attaching climate did not change the loaded manifest"
       (and (= :scenic ((tc/load-manifest artroot) :profile))
            (nil? (get (tc/load-manifest artroot) :climate))))
(check "every other status key is unchanged"
       (let [s (tc/status art)]
         (and (= :scenic (s :profile)) (= [-1 -1 6 6] (s :bounds))
              (= 2024 (s :seed)))))

# --- world-space sampling through the projection ----------------------
# Origin (-16,-16) is grid cell (0,0); one world cell is one grid cell here.
(check "the world origin samples grid cell (0,0)"
       (let [r (tc/climate-at-world art -16 -16)]
         (and (= :sampled (r :status)) (= 0 (r :x)) (= 0 (r :z)) (= 0 (r :index)))))
(check "one world cell in moves one grid cell"
       (= [1 0] (let [r (tc/climate-at-world art -15 -16)] [(r :x) (r :z)])))
(check "the grid corner is the last world cell"
       (let [r (tc/climate-at-world art 111 111)]
         (and (= 127 (r :x)) (= 127 (r :z)))))
(check "a sampled value equals the fixture's own cell"
       (let [r (tc/climate-at-world art 0 0)]
         (and (= (channel-value 16 16 0) ((r :values) :temperature))
              (= (channel-value 16 16 4) ((r :values) :lapse-rate)))))
(check "x-fastest indexing holds inside the grid"
       (= (+ 3 (* 5 128)) (let [r (tc/climate-at-world art -13 -11)] (r :index))))

# --- chunks map through the same projection ---------------------------
(check "chunk -1 is the map's first chunk and grid tile 0"
       (= [0 0] (tc/climate-cell art -1 -1)))
(check "chunk -1 with an in-chunk offset stays inside tile 0"
       (= [15 15] (tc/climate-cell art -1 -1 15 15)))
(check "chunk 0 starts at grid cell (16,16)" (= [16 16] (tc/climate-cell art 0 0)))
(check "the far corner chunk starts at the last tile"
       (= [112 112] (tc/climate-cell art 6 6)))
(check "chunk coordinates agree with world coordinates"
       (let [r (tc/climate-at-world art (+ (* 2 16) 5) (+ (* 1 16) 7))]
         (= (tc/climate-cell art 2 1 5 7) [(r :x) (r :z)])))
(check "a chunk sample equals the world sample at that position"
       (let [by-chunk (tc/climate-at art 2 1 5 7)
             by-world (tc/climate-at-world art (+ (* 2 16) 5) (+ (* 1 16) 7))]
         (and (= :sampled (by-chunk :status))
              (= (by-chunk :values) (by-world :values))
              (= (by-chunk :index) (by-world :index)))))

# --- off the grid is unavailable, never clamped -----------------------
(check "one world cell before the origin is unavailable"
       (= :outside-map ((tc/climate-at-world art -17 -16) :reason)))
(check "one world cell past the far edge is unavailable"
       (= :outside-map ((tc/climate-at-world art 112 111) :reason)))
(check "a chunk before the map is unavailable"
       (= :outside-map ((tc/climate-at art -2 -1) :reason)))
(check "a chunk after the map is unavailable"
       (= :outside-map ((tc/climate-at art 7 6) :reason)))
(check "an outside-map query carries no values"
       (nil? (get (tc/climate-at art 9 9) :values)))
(check "climate-cell answers nil outside the map"
       (nil? (tc/climate-cell art 9 9)))
(check "outside the map is not clamped to an edge cell"
       (and (nil? (tc/climate-cell art -2 -1)) (nil? (tc/climate-cell art 7 6 0 0))))
(check "an in-chunk offset outside 0..15 is refused"
       (throws? (fn [] (tc/climate-cell art 0 0 16 0))))
(check "a non-integer in-chunk offset is refused"
       (throws? (fn [] (tc/climate-cell art 0 0 1.5 0))))
(check "a non-finite world coordinate is refused"
       (throws? (fn [] (tc/climate-at-world art (/ 0 0) 0))))

# --- THE PROJECTION IS NEVER INFERRED ---------------------------------
# A 128x128 climate grid cannot honestly back a 512x512 world: that is the real
# "512 upsampled height from 128 climate raw" case, and it must be REFUSED with
# both extents named rather than stretched over four world cells per sample.
(def bigroot (scratch-dir))
(write-scenic bigroot @{:bounds [0 0 31 31] :origin [0 0]})
(def bigcache (tc/cache-new bigroot 2024))
(check "a 32x32-chunk map has a 512x512 climate extent"
       (= [32 32 512 512] (tc/climate-extent bigcache)))
(def small (ct/read (climate-buffer 128 128) [128 128 5] climate-meta))
(check "a 128 grid over a 512 map at scale 1 is refused"
       (string/find "refused rather than resampled"
                    (message-of (fn [] (tc/attach-climate! bigcache small [0 0] 1)))))
(check "that refusal names the grid, its coverage and the map extent"
       (let [m (message-of (fn [] (tc/attach-climate! bigcache small [0 0] 1)))]
         (and (string/find "128x128" m) (string/find "512x512" m))))
# Scale is the honest coarse-mapping path: a 128 grid over a 512 map is one
# sample per four columns, which is a COVERAGE statement, not a resample.
(check "a coarse grid is accepted at the scale that covers the map"
       (= :present ((tc/attach-climate bigcache (climate-buffer 128 128)
                                       [128 128 5] climate-meta [0 0] 4) :status)))
(check "the coarse projection is stored"
       (let [p (tc/climate-projection bigcache)]
         (and (= 4 (p :scale)) (deep= [0 0] (p :origin)))))
(check "one coarse sample spans four world cells"
       (and (= 0 (let [r (tc/climate-at-world bigcache 3 0)] (r :x)))
            (= 1 (let [r (tc/climate-at-world bigcache 4 0)] (r :x)))))
(check "the far edge of a coarse map is the last sample"
       (and (= 127 (let [r (tc/climate-at-world bigcache 508 0)] (r :x)))
            (= 127 (let [r (tc/climate-at-world bigcache 511 0)] (r :x)))))
(check "a coarse map still refuses one world cell past its edge"
       (= :outside-map ((tc/climate-at-world bigcache 512 0) :reason)))
(check "a coarse map still refuses a negative world coordinate"
       (= :outside-map ((tc/climate-at-world bigcache -1 0) :reason)))
(check "a scale that leaves a remainder is refused, not resampled"
       (string/find "refused rather than resampled"
                    (message-of (fn [] (tc/attach-climate
                                        (tc/cache-new bigroot 2024)
                                        (climate-buffer 100 100) [100 100 5]
                                        climate-meta [0 0] 5)))))
(check "scale 1 over a coarse map is still refused"
       (string/find "refused rather than resampled"
                    (message-of (fn [] (tc/attach-climate
                                        (tc/cache-new bigroot 2024)
                                        (climate-buffer 128 128) [128 128 5]
                                        climate-meta [0 0] 1)))))
(check "a non-positive scale is refused"
       (string/find "positive integer"
                    (message-of (fn [] (tc/attach-climate! bigcache small [0 0] 0)))))
(check "a non-integer scale is refused"
       (string/find "positive integer"
                    (message-of (fn [] (tc/attach-climate! bigcache small [0 0] 1.5)))))
(check "a mismatched origin is refused rather than reprojected"
       (string/find "refused rather than reprojected"
                    (message-of (fn [] (tc/attach-climate! bigcache small [8 8] 1)))))
(check "a malformed origin is refused"
       (string/find "two signed integers"
                    (message-of (fn [] (tc/attach-climate! bigcache small [8] 1)))))
(check "a decoded result that is not a climate result is refused"
       (string/find "climate-tile result"
                    (message-of (fn [] (tc/attach-climate! bigcache @{:status :nope}
                                                          [0 0] 1)))))
# A refusal must not partially attach: check on a cache that never succeeded.
(def untouched (tc/cache-new bigroot 2024))
(message-of (fn [] (tc/attach-climate! untouched small [0 0] 3)))
(check "a refused attachment left the cache untouched"
       (and (= :absent ((tc/status untouched) :climate))
            (= :not-attached ((tc/cache-climate untouched) :reason))
            (nil? (tc/climate-projection untouched))))

# --- the explicit bytes+shape entry point still validates -------------
(def fresh-a (tc/cache-new artroot 2024))
(defn attach-error [cache values shape meta &opt origin scale]
  (message-of (fn [] (tc/attach-climate cache values shape meta origin scale))))
(check "a buffer of the wrong length is refused"
       (string/find "requires exactly"
                    (attach-error fresh-a (climate-buffer 128 127) map-shape
                                  climate-meta)))
(check "a two-axis shape is refused (elevation is not climate)"
       (string/find "shape must be"
                    (attach-error fresh-a map-buffer [128 128] climate-meta)))
(check "a four-channel shape is refused"
       (string/find "shape must be"
                    (attach-error fresh-a map-buffer [128 128 4] climate-meta)))
(check "a NaN sample is refused"
       (string/find "NaN or infinite"
                    (attach-error fresh-a (nan-buffer 128 128) map-shape climate-meta)))
(check "a grid that under-covers the map is refused"
       (string/find "refused rather than resampled"
                    (attach-error fresh-a (climate-buffer 64 64) [64 64 5]
                                  climate-meta)))
(check "a grid that over-covers the map is refused too"
       (string/find "refused rather than resampled"
                    (attach-error fresh-a (climate-buffer 128 160) [128 160 5]
                                  climate-meta)))
(check "a sidecar declaring climate with no buffer is refused"
       (string/find "declares climate"
                    (attach-error fresh-a nil nil climate-meta)))
(check "a buffer with a sidecar denying climate is refused"
       (string/find "declares no climate"
                    (attach-error fresh-a map-buffer map-shape no-climate-meta)))
(check "a non-boolean presence flag is refused"
       (string/find "boolean"
                    (attach-error fresh-a map-buffer map-shape @{:has_climate "true"})))
(check "a legacy cache refuses a present climate (no map to check it against)"
       (string/find "bounded scenic cache"
                    (attach-error lg map-buffer map-shape climate-meta)))
(check "a defaulted origin is the map's own origin, so 1:1 attaches"
       (= :present ((tc/attach-climate fresh-a map-buffer map-shape climate-meta) :status)))
(check "a closed cache refuses attachment"
       (let [c (tc/cache-new artroot 2024)]
         (tc/close c)
         (string/find "closed" (attach-error c map-buffer map-shape climate-meta))))

# --- the producer wrote no climate: a legitimate, memorable answer -----
(def fresh-b (tc/cache-new artroot 2024))
(check "attaching the no-climate form succeeds"
       (let [r (tc/attach-climate fresh-b nil nil no-climate-meta)]
         (and (= :unavailable (r :status)) (= :absent (r :reason)))))
(check "its status says :unavailable" (= :unavailable ((tc/status fresh-b) :climate)))
(check "its climate-at says :absent, not :not-attached"
       (= :absent ((tc/climate-at fresh-b -1 -1) :reason)))
(check "a no-climate cache still reads its heights"
       (do
         (try (os/mkdir (tc/tiles-dir artroot)) ([e] nil))
         (write-bytes (tc/tile-path artroot 0 0) (scenic-tile-for 0 0 (scenic-heights)))
         (= tc/height-min (get (tc/read-height-tile fresh-b 0 0) 0))))
(check "a nil sidecar with no buffer means no claim, so it attaches as absent"
       (= :absent ((tc/attach-climate (tc/cache-new artroot 2024) nil nil nil) :reason)))
(check "idempotent: attaching the same decoded result twice is accepted"
       (= :present ((tc/attach-climate! art decoded [-16 -16] 1) :status)))
(check "attaching different data to the same cache is refused"
       (string/find "already attached"
                    (message-of (fn [] (tc/attach-climate! art
                                                           (ct/read (climate-buffer 128 128 1)
                                                                    map-shape climate-meta)
                                                           [-16 -16] 1)))))
(check "the refused re-attachment left the original data in place"
       (= (channel-value 0 0 0) (((tc/climate-at-world art -16 -16) :values) :temperature)))

# --- negative chunk coordinates ---------------------------------------
# A map whose bounds START at a negative chunk: [-3 1 1 2] is 5 x 2 chunks ->
# (80 32) cells, and chunk -3 is grid column 0.
(def negroot (scratch-dir))
# The origin is the world position of chunk_min, so a map starting at chunk
# (-3, 1) begins at world (-48, 16). Declaring anything else here would be a
# mis-declaration, and the module refuses exactly that.
(write-scenic negroot @{:bounds [-3 1 1 2] :origin [-48 16]})
(def neg-cache (tc/cache-new negroot 2024))
(def neg-shape [32 80 5])
(check "a negative-bounds map derives its own extent"
       (= [5 2 80 32] (tc/climate-extent neg-cache)))
(check "its 1:1 shape is (height width channels) of that extent"
       (= neg-shape (tc/climate-shape neg-cache)))
(check "the negative-bounds map attaches a matching grid"
       (= :present ((tc/attach-climate neg-cache (climate-buffer 32 80) neg-shape
                                       climate-meta) :status)))
(check "chunk -3 is grid column 0 (world -48 is cell 0)"
       (= [0 0] (tc/climate-cell neg-cache -3 1)))
(check "chunk -3 with an in-chunk offset stays inside tile 0"
       (= [15 15] (tc/climate-cell neg-cache -3 1 15 15)))
(check "chunk -2 starts at cell 16" (= [16 0] (tc/climate-cell neg-cache -2 1)))
(check "the positive end of a negative-bounds map is the last tile"
       (= [64 31] (tc/climate-cell neg-cache 1 2 0 15)))
(check "a sample at a negative chunk reads its own cell"
       (let [r (tc/climate-at neg-cache -3 1 5 4)]
         (and (= :sampled (r :status))
              (= [5 4] [(r :x) (r :z)])
              (= (channel-value 5 4 0) ((r :values) :temperature)))))
(check "one chunk before a negative-bounds map is unavailable"
       (= :outside-map ((tc/climate-at neg-cache -4 1) :reason)))
(check "one chunk below the negative map's z edge is unavailable"
       (= :outside-map ((tc/climate-at neg-cache -3 0) :reason)))
(check "a negative world point maps to the right grid cell"
       (= [0 0] (let [r (tc/climate-at-world neg-cache -48 16)] [(r :x) (r :z)])))
(check "one world cell before that map is unavailable"
       (= :outside-map ((tc/climate-at-world neg-cache -49 16) :reason)))
(check "the tile path for a negative chunk is still signed"
       (string/has-suffix? "/-3_1.tdh" (tc/tile-path negroot -3 1)))

# --- ownership: the cache keeps its own copy --------------------------
# `climate-tile/read` returns a MUTABLE table. If the cache stored the caller's
# object, that caller could `put` a new :status or wipe :values afterwards and
# silently change what a later classification reads. Attachment therefore owns
# a frozen copy, and everything a query hands back is immutable.
(def ownroot (scratch-dir))
(write-scenic ownroot @{:bounds [0 0 1 1] :origin [0 0]})
(def own-cache (tc/cache-new ownroot 2024))
(def caller-result (ct/read (climate-buffer 32 32) [32 32 5] climate-meta))
(check "the caller's climate result really is a mutable table"
       (= :table (type caller-result)))
(check "attach returns an owned struct"
       (= :struct (type (tc/attach-climate! own-cache caller-result [0 0] 1))))
(check "the owned copy's channel arrays are immutable tuples"
       (= :tuple (type (((tc/cache-climate own-cache) :values) :temperature))))
(check "mutating the caller's table after attach cannot corrupt the cache"
       (do (put caller-result :status :tampered)
           (put caller-result :values nil)
           (and (= :present ((tc/cache-climate own-cache) :status))
                (not (nil? ((tc/cache-climate own-cache) :values))))))
(check "the cache still samples correctly after the caller tampered"
       (let [r (tc/climate-at own-cache 0 0)]
         (and (= :sampled (r :status))
              (= (channel-value 0 0 0) ((r :values) :temperature)))))
(check "a query result cannot be mutated"
       (throws? (fn [] (put ((tc/cache-climate own-cache) :values) :temperature nil))))
(check "a query result's outer table cannot be mutated either"
       (throws? (fn [] (put (tc/climate-at own-cache 0 0) :status :tampered))))
(check "a sample's scalar values are plain numbers, not shared references"
       (let [v ((tc/climate-at own-cache 0 0) :values)]
         (and (= :number (type (v :temperature)))
              (= :number (type (v :lapse-rate)))
              (every? (map (fn [c] (= :number (type (get v c))))
                           [:temperature :temperature-seasonality :precipitation
                            :precipitation-variability :lapse-rate])))))
(check "two samples of the same cache agree, so sharing cannot drift"
       (= ((tc/climate-at own-cache 0 0) :values)
          ((tc/climate-at own-cache 0 0) :values)))

(check "a struct wrapping a mutable array is copied, not shared"
       (let [live @[7 8 9]
             wrapped (struct :status :present :height 32 :width 32
                             :bytes 20480 :samples 1024 :shape (tuple 32 32 5)
                             :values (struct :temperature live))
             croot (scratch-dir)]
         (write-scenic croot @{:bounds [0 0 1 1] :origin [0 0]})
         (def wrapped-cache (tc/cache-new croot 2024))
         (tc/attach-climate! wrapped-cache wrapped [0 0] 1)
         (def kept (get (tc/cache-climate wrapped-cache) :values))
         # Immutability alone is not ownership: a struct can be read-only and
         # still hold a live array, so the copy must reach the leaves.
         (def owned? (and (= :tuple (type (get kept :temperature)))
                          (= 7 (get (get kept :temperature) 0))))
         (put live 0 12345)
         (def unchanged? (= 7 (get (get kept :temperature) 0)))
         (rm-tree croot)
         (and owned? unchanged?)))

# --- the grid is bounded: a 512x512 map, five channels, is the ceiling
(check "the climate cap is a 512x512 grid"
       (and (= 262144 tc/climate-max-cells) (= 5242880 tc/climate-max-bytes)))
(check "a grid at exactly the cap is accepted"
       (let [caproot (scratch-dir)]
         (write-scenic caproot @{:bounds [0 0 31 31] :origin [0 0]})
         (def cap-cache (tc/cache-new caproot 2024))
         (def r (ct/read (buffer/new-filled tc/climate-max-bytes 0) [512 512 5]
                         climate-meta))
         (def out (tc/attach-climate! cap-cache r [0 0] 1))
         (rm-tree caproot)
         (= 262144 (out :samples))))
(check "the cap is a product limit, tighter than the reader's own"
       (= tc/climate-max-bytes (* tc/climate-max-cells ct/channel-count 4)))

# --- no discovery: a climate file beside the cache is not loaded ------
(def mixed (scratch-dir))
(write-scenic mixed @{:bounds [0 0 1 1]})
(write-bytes (string mixed "/climate.json") "{\"has_climate\": true}\n")
(write-bytes (string mixed "/climate.npz") "PK\u0003\u0004not really a zip")
(check "a cache with climate sidecars beside it still opens"
       (= :scenic ((tc/load-manifest mixed) :profile)))
(def mixed-cache (tc/cache-new mixed 2024))
(check "the sidecars were not discovered: climate is unattached"
       (= :not-attached ((tc/cache-climate mixed-cache) :reason)))
(check "status calls it :absent, not :present"
       (= :absent ((tc/status mixed-cache) :climate)))
(check "the attached projection is nil, so nothing was reconstructed"
       (nil? (tc/climate-projection mixed-cache)))
(check "the sidecar files are still on disk, untouched"
       (and (not (nil? (os/stat (string mixed "/climate.json"))))
            (not (nil? (os/stat (string mixed "/climate.npz"))))))

# --- attaching writes nothing ----------------------------------------
(defn read-all [path cap]
  (def f (file/open path :rb))
  (def d (file/read f cap))
  (file/close f)
  (string d))
(def manifest-before (read-all (string negroot "/manifest.janet") 4096))
(def json-before (read-all (tc/scenic-json-path negroot) 65536))
(tc/attach-climate (tc/cache-new negroot 2024) (climate-buffer 32 80) neg-shape
                   climate-meta)
(check "manifest.janet is byte-identical after another attach"
       (= manifest-before (read-all (string negroot "/manifest.janet") 4096)))
(check "provenance.json is byte-identical after another attach"
       (= json-before (read-all (tc/scenic-json-path negroot) 65536)))
(check "attaching wrote no new file into the identity directory"
       (deep= @["manifest.janet" "provenance.json"]
              (sort (array/slice (os/dir negroot)))))
(check "the tile format is untouched: a 308-byte tile still decodes"
       (= tc/tile-bytes (length (scenic-tile-for 0 0 (scenic-heights)))))

# --- the producer's twin is not yet sufficient -------------------------
(def proot (scratch-dir))
(write-bytes (string proot "/manifest.janet")
             (string "{:format 3 :magic \"TDS3\" :identity \"" sident "\""
                     " :seed 2024 :payload-bytes 256 :tile-bytes 308"
                     " :height-min 4 :height-max 252}\n"))
(check "the producer's current 8-key twin is refused for lacking bounds"
       (string/find "bounds"
                    (message-of (fn [] (tc/load-manifest proot)))))

#
# --- Cleanup ------------------------------------------------------------
#
(tc/close q)
(tc/close lg)
(def dirs [root mroot inert-root corrupt-root error-root qroot proot eroot broot
            sr nat negroot mixed artroot bigroot ownroot])
(each dir dirs (rm-tree dir))
(check "scratch directories were removed under TMPDIR"
       (every? (map (fn [d] (nil? (os/stat d))) dirs)))

(if (zero? failures)
  (print "terrain cache (TDH2/TDS3): ALL CHECKS PASSED")
  (do (printf "terrain cache (TDH2/TDS3): %d FAILURE(S)" failures)
      (os/exit 1)))
