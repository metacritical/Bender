# Standalone CPU-only tests for versioned procedural recipes.
(import ../src/material-recipes :as materials)

(def kinds [:grain :noise :voronoi :wave :checker :brick :speckle])
(assert (= materials/version 1))
(assert (materials/validate materials/fallback))
(defn reference-speckle [seed x y base dark light]
  (let [n (mod (+ (* (+ x seed) 73856093) (* (+ y seed) 19349663)
                  (* (+ x seed) (+ y seed) 83492791)) 17)]
    (if (< n 2) dark (if (> n 14) light base))))
(each [name seed] [[:grass 3] [:sand 5]]
  (let [r (get materials/recipes name)]
    (assert (= :speckle (get r :kind)))
    (for y 0 16
      (for x 0 16
        (assert (= (reference-speckle seed x y (get r :base) (get r :dark) (get r :light))
                   (materials/sample r x y)))))))
(assert (= (materials/resolve :missing) materials/fallback))
(assert (= (materials/resolve {:version 2 :kind :checker}) materials/fallback))
(assert (= (materials/resolve nil) materials/fallback))

(each [name recipe] (pairs materials/recipes)
  (assert (materials/validate recipe) (string "invalid built-in " name))
  (assert (= recipe (materials/resolve name)))
  (assert (some |(= (get recipe :kind) $) kinds)))

(defn recipe [kind seed scale]
  {:version 1 :kind kind :seed seed :scale scale
   :base [120 130 140 255] :dark [20 30 40 255] :light [220 230 240 255]})

(each kind kinds
  (let [r (recipe kind 19 3)
        samples (map (fn [xy] (materials/sample r (get xy 0) (get xy 1)))
                     [[0 0] [1 7] [8 2] [13 11]])]
    (assert (materials/validate r))
    (assert (deep= samples
                   (map (fn [xy] (materials/sample r (get xy 0) (get xy 1)))
                        [[0 0] [1 7] [8 2] [13 11]])))
    (each color samples
      (assert (= (length color) 4))
      (each channel color (assert (and (<= 0 channel) (<= channel 255)))))))

# At least one pixel differs when the seed changes for stochastic generators.
(each kind [:grain :noise :voronoi :wave :brick]
  (let [a (recipe kind 19 3) b (recipe kind 91 3)]
    (assert (some (fn [xy] (not= (materials/sample a (get xy 0) (get xy 1))
                                 (materials/sample b (get xy 0) (get xy 1))))
                  [[0 0] [1 7] [8 2] [13 11] [22 29] [31 4]]))))

(each bad [{:version 2 :kind :noise :seed 1 :scale 3 :base [0 0 0 255] :dark [0 0 0 255] :light [0 0 0 255]}
           (recipe :unknown 1 3)
           (recipe :noise 1 0)
           (recipe :noise 1 -1)
           (recipe :noise 1 4097)
           (recipe :noise 1 :invalid)
           (recipe :noise 1.5 3)
           {:version 1 :kind :noise :seed 1 :scale 3 :base [256 0 0 255] :dark [0 0 0 255] :light [0 0 0 255]}
           nil]
  (assert (not (materials/validate bad)))
  (assert (= materials/fallback (materials/resolve bad)))
  (assert (= (materials/sample materials/fallback 5 8)
             (materials/sample bad 5 8))))

# Tile-local coordinates reproduce pixels regardless of which atlas slot calls sample.
(assert (= (materials/sample :stone 3 5) (materials/sample (get materials/recipes :stone) 3 5)))
# Editable file data is read as inert forms; invalid entries use built-in defaults.
(def loaded (materials/load))
(assert (deep= (get loaded :stone) (get materials/recipes :stone)))
(assert (deep= (get loaded :grass) (get materials/recipes :grass)))

(defn changed [entry key value]
  (let [out (table)]
    (each [k v] (pairs entry) (put out k v))
    (put out key value)
    out))
# The tracked pre-speckle defaults migrate only on exact match, in memory.
(each name [:grass :sand]
  (assert (= (get materials/recipes name) (get loaded name)))
  (let [path (string "/tmp/trinecraft-authored-" name "-" (os/getpid) ".janet")
        authored (changed (get materials/legacy-speckle-defaults name) :brightness 1.2)
        saved (materials/save {name authored} path)]
    (assert (deep= authored (get saved name)))
    (assert (deep= authored (get (materials/load path) name)))
    (os/rm path)))
# Exact tracked defaults are shadowing data, not authored changes; missing and
# invalid entries also fall back to current builtins without rewriting the file.
(let [path (string "/tmp/trinecraft-precedence-" (os/getpid) ".janet")
      f (file/open path :wb)]
  (file/write f (string/format "%j\n" {:version 1 :recipes
                                          {:grass (get materials/legacy-speckle-defaults :grass)
                                           :sand (changed (get materials/legacy-speckle-defaults :sand) :scale 0)}}))
  (file/close f)
  (let [loaded-precedence (materials/load path)]
    (assert (deep= (get loaded-precedence :grass) (get materials/recipes :grass)))
    (assert (deep= (get loaded-precedence :sand) (get materials/recipes :sand)))
    (assert (deep= (get loaded-precedence :stone) (get materials/recipes :stone))))
  (os/rm path))
(def bright (changed (get loaded :stone) :brightness 1.5))
(def coarse (changed (get loaded :stone) :pixel-size 3))
(def dense (changed (get loaded :wood) :grain-density 6))
(assert (materials/validate bright))
(assert (materials/validate coarse))
(assert (materials/validate dense))
(assert (not= (materials/sample bright 2 4) (materials/sample (get loaded :stone) 2 4)))
(assert (= (materials/sample coarse 3 4) (materials/sample coarse 5 4)))
(assert (some (fn [xy] (not= (materials/sample dense (get xy 0) (get xy 1))
                             (materials/sample (get loaded :wood) (get xy 0) (get xy 1))))
              [[0 0] [4 5] [9 8] [13 11]]))
(each [key value] [[:brightness -0.1] [:brightness 2.1] [:grain-density -1]
                   [:grain-density 17] [:pixel-size 0] [:pixel-size 65]
                   [:pixel-size 1.5]]
  (let [bad (changed (get loaded :stone) key value)]
    (assert (not (materials/validate bad)))
    (assert (= materials/fallback (materials/resolve bad)))))

(def test-path (string "/tmp/trinecraft-material-recipes-test-" (os/getpid) ".janet"))
(def entries (table))
(each [k v] (pairs loaded) (put entries k v))
(put entries :stone bright)
(def custom (recipe :noise 471 7))
(put entries :custom-stone custom)
(put entries :invalid-custom (changed custom :scale 0))
(put entries "not-a-keyword" custom)
(put entries :grass (changed (get loaded :grass) :brightness 9))
(let [saved (materials/save entries test-path)
      reloaded (materials/load test-path)]
  (assert (deep= bright (get saved :stone)))
  (assert (deep= (get materials/recipes :grass) (get saved :grass)))
  (assert (deep= bright (get reloaded :stone)))
  (assert (deep= custom (get saved :custom-stone)))
  (assert (deep= custom (get reloaded :custom-stone)))
  (assert (nil? (get reloaded :invalid-custom)))
  (assert (nil? (get reloaded "not-a-keyword")))
  (assert (deep= (map (fn [xy] (materials/sample (get saved :custom-stone) (get xy 0) (get xy 1)))
                      [[0 0] [1 7] [8 2] [13 11]])
                 (map (fn [xy] (materials/sample (get reloaded :custom-stone) (get xy 0) (get xy 1)))
                      [[0 0] [1 7] [8 2] [13 11]])))
  (assert (deep= (get materials/recipes :grass) (get reloaded :grass))))
(let [state (materials/source test-path)]
  (assert (= test-path (get state :path)))
  (assert (deep= (get (materials/current state) :stone) bright))
  (let [updated (table)]
    (each [k v] (pairs (materials/current state)) (put updated k v))
    (put updated :stone (changed bright :brightness 0.5))
    (materials/save updated test-path)
    (let [next-state (materials/reload state)]
      (assert (deep= (get (materials/current next-state) :stone)
                     (changed bright :brightness 0.5)))
      (assert (deep= (get (materials/current state) :stone) bright))))
  # A rejected file cannot replace the last successfully loaded state.
  (let [f (file/open test-path :wb)]
    (file/write f "{:version 999 :recipes {}}")
    (file/close f))
  (assert (try (do (materials/reload state) false) ([err] true)))
  (assert (deep= (get (materials/current state) :stone) bright)))
(os/rm test-path)
(print "material recipes: pass")

#
# --- Saved file is human-editable ---------------------------------------
#
# The saved file is the AUTHORING surface: a developer edits colours by hand.
# `%j` round-trips correctly but writes one unreadable line, so the writer
# emits a layout. These assertions pin that layout, because a save that
# destroys readability destroys the editing loop.

(defn slurp [path]
  (def f (file/open path :rb))
  (def t (file/read f :all))
  (file/close f)
  t)
(let [d (string "tmp/format-test-" (os/getpid) ".janet")]
  (materials/save materials/recipes d)
  (def text (slurp d))
  (assert (string/find "# Trinecraft material recipes" text))   # header survives
  (assert (string/find ":recipes" text))
  (assert (string/find ":stone" text))                          # key keeps its colon
  (assert (string/find ":kind :noise" text))                    # kind keeps its colon
  (assert (> (length (string/split "\n" text)) 8))             # genuinely multi-line
  # Content must survive the layout exactly.
  (def back (materials/load d))
  (assert (= (length (keys materials/recipes)) (length (keys back))))
  (assert (every? (map (fn [k] (deep= (get materials/recipes k) (get back k)))
                       (keys materials/recipes))))
  # A custom recipe is written after the built-ins and read back intact.
  (def custom {:version 1 :kind :brick :base [1 2 3 255] :dark [0 0 0 255]
               :light [255 255 255 255] :scale 4 :seed 11})
  (materials/save (merge materials/recipes {:mybrick custom}) d)
  (def with-custom (materials/load d))
  (assert (deep= custom (get with-custom :mybrick)))
  (print "saved file layout: pass")
  (os/rm d))

# --- Snow recipe (block 8 material) -------------------------------------
# Snow ships as a built-in, an authored default AND a save-order entry. All
# three have to agree or a save silently normalises the file into a spurious
# diff on the next commit.
(print "snow recipe: ")
(assert (has-key? materials/recipes :snow) "builtin :snow is missing")
(let [snow (get materials/recipes :snow)]
  (assert (materials/validate snow) "builtin :snow does not validate")
  # Off-white, not pure white: 255 on all three channels would clip against the
  # vertex-shade multiplier and read as a hole rather than a surface.
  (each c [0 1 2]
    (assert (< (get (snow :base) c) 255)
            (string "snow base channel " c " must not be pure white"))
    (assert (>= (get (snow :base) c) 200)
            (string "snow base channel " c " is too dark to read as snow")))
  # Cool cast: blue at least as strong as red on every tone.
  (each tone [:base :dark :light]
    (assert (>= (get (snow tone) 2) (get (snow tone) 0))
            (string "snow " tone " should be cool (blue >= red)")))
  # Low contrast across the three tones -- snow is a low-variance surface.
  (each c [0 1 2]
    (assert (<= (- (get (snow :light) c) (get (snow :dark) c)) 50)
            (string "snow channel " c " has more than 50 levels of contrast"))))
(print "  validated, off-white, cool, low contrast: pass")

# material-order drives save layout. Snow must appear in it, or saving moves
# the recipe to the custom tail and produces a diff that looks like an edit.
# `find` with a predicate returns the matching VALUE, not its index, so the
# position has to come from find-index.
(def snow-at (find-index |(= $ :snow) materials/material-order))
(assert snow-at ":snow is missing from material-order")
# And it must sit before :masonry, matching the authored file's order.
(assert (< snow-at (find-index |(= $ :masonry) materials/material-order))
        ":snow should be ordered before :masonry to match the authored file")
(print "  present in material-order at the authored position: pass")

# The authored file on disk must match the builtin exactly. A mismatch means
# the game uses one tone and the editable file claims another.
# Explicit path: `source` defaults to a cwd-relative "data/materials.janet",
# and this suite may be run from elsewhere. Same file, unambiguous path.
(let [on-disk (materials/source "data/materials.janet")]
  (assert (get on-disk :recipes)
          "data/materials.janet did not load")
  (assert (get (get on-disk :recipes) :snow)
          "data/materials.janet has no :snow recipe")
  (assert (deep= (materials/resolve :snow)
                 (get (get on-disk :recipes) :snow))
          "data/materials.janet :snow disagrees with the builtin"))
(print "  data/materials.janet matches the builtin: pass")

# Round-trip: saving must reproduce snow in place, not relocate it.
(let [d (string "/tmp/trinecraft-snow-" (os/getpid) ".janet")]
  (materials/save materials/recipes d)
  (def text (slurp d))
  (assert (string/find ":snow" text) "saved file dropped :snow")
  (assert (< (string/find ":snow" text) (string/find ":masonry" text))
          "save reordered :snow after :masonry")
  (def back (materials/load d))
  (assert (deep= (materials/resolve :snow) (get back :snow)))
  (os/rm d)
  (print "  save round-trips :snow in place: pass"))



