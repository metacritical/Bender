# Headless tests for the bound climate reader.
#
# No GL, no window, no model, no inference, no subprocess, no filesystem. This
# suite cannot change a saved world: the module under test holds no state, reads
# no file, and is imported by no save path.
#
# THE FIXTURES ARE THE PRODUCER'S WIRE, NOT THIS MODULE'S. Every buffer below is
# assembled byte by byte as little-endian float32 in channel-last (H, W, 5) order
# -- exactly what `tools/scenic_terrain.py` `export_raw(..., climate=)` stores as
# `arrays["climate"]` with `dtype=np.float32` and `shape[:2] == elevation.shape`.
# The packing is done here, independently of the reader, so a reader bug cannot
# make its own test pass.
#
# Run: JANET_NO_PROFILE=1 ../../janet/build/bender test/climate-tile-test.janet

(import ../src/climate-tile :as ct)

(var failures 0)
(defn check [name ok &opt detail]
  (if ok
    (printf "  ok   %s" name)
    (do (++ failures)
        (printf "  FAIL %s%s" name (if detail (string " -- " detail) "")))))

(defn raises? [f] (try (do (f) false) ([e] true)))
(defn message-of [f] (try (do (f) "") ([e] (string e))))
(defn has-message? [f needle] (string/find needle (message-of f)))

#
# --- Writing the producer's wire ---------------------------------------
#

(defn- f32-bytes
  ``Four little-endian bytes of `v` as float32.

  Values in this suite are all exactly representable (halves and small integers),
  so this packs the bit pattern directly without needing to round.``
  [v]
  (def (frac e) (math/frexp (math/abs v)))
  (def m (math/floor (* frac 16777216)))
  (def sign (if (< v 0) (blshift 1 31) 0))
  (def raw (bor sign (blshift (+ e 126) 23) (- m 8388608)))
  (def bits (if (< raw 0) (+ raw 4294967296) raw))
  [(mod bits 256)
   (mod (math/floor (/ bits 256)) 256)
   (mod (math/floor (/ bits 65536)) 256)
   (mod (math/floor (/ bits 16777216)) 256)])

(defn- pack
  ``A channel-last float32 buffer from per-sample channel sequences.

  `samples` is a flat sequence of 5-element sequences in z-major, x-minor order,
  which is the producer's row order.``
  [samples]
  (def out (buffer/new 0))
  (each sample samples
    (each v sample
      (each b (f32-bytes v) (buffer/push-byte out b))))
  out)

(defn value-at
  "The reference value this suite uses for grid cell (x,z), channel c."
  [z x c]
  (+ 1.0 (* 10 z) x (* 0.5 c)))

(defn grid-samples
  "Flat samples for an h x w grid, populated by `value-at`."
  [h w]
  (def out @[])
  (for z 0 h
    (for x 0 w
      (def s @[])
      (for c 0 5 (array/push s (value-at z x c)))
      (array/push out s)))
  out)

(defn meta-with [has] @{:has_climate has})

#
# --- The shape contract -------------------------------------------------
#

(print "\nshape:")

(check "five channels are declared" (= 5 ct/channel-count))

(check "the channel order is the producer's last-axis order"
       (= ct/channels
          [:temperature :temperature-seasonality :precipitation
           :precipitation-variability :lapse-rate]))

(check "lapse rate is channel 4 and is not named humidity or moisture"
       (and (= :lapse-rate (get ct/channels 4))
            (nil? (some |(string/find "humid" (string $)) ct/channels))
            (nil? (some |(string/find "moist" (string $)) ct/channels))))

(check "a channel-last 3-axis shape is accepted" (ct/shape? [2 3 5]))

(check "a shape without a channel axis is refused, not guessed"
       (not (ct/shape? [2 3])))

(check "a shape with a leading channel axis is refused"
       (not (ct/shape? [5 2 3])))

(check "a shape with four channels is refused" (not (ct/shape? [2 3 4])))
(check "a shape with six channels is refused" (not (ct/shape? [2 3 6])))
(check "a non-integer extent is refused" (not (ct/shape? [2.5 3 5])))
(check "a zero extent is refused" (not (ct/shape? [0 3 5])))
(check "a negative extent is refused" (not (ct/shape? [2 -3 5])))

(check "sample count is height * width" (= 6 (ct/sample-count [2 3 5])))
(check "expected bytes is samples * 5 * 4" (= 120 (ct/expected-bytes [2 3 5])))
(check "expected-bytes is nil for an invalid shape"
       (nil? (ct/expected-bytes [2 3])))

#
# --- The bound read -----------------------------------------------------
#

(print "\nread:")

(def buf (pack (grid-samples 2 3)))
(def result (ct/read buf [2 3 5] {:has_climate true}))

(check "the fixture is exactly the byte length the shape requires"
       (= 120 (length buf)))
(check "a valid buffer reads as present" (ct/present? result))
(check "the result reports the declared shape" (deep= [2 3 5] (result :shape)))
(check "the result reports height, width and sample count"
       (and (= 2 (result :height)) (= 3 (result :width)) (= 6 (result :samples))))
(check "the result reports the byte length" (= 120 (result :bytes)))
(check "the result carries all five channels"
       (= 5 (length (keys (result :values)))))

# The single most important check: every sample must land at the index the
# producer's channel-last row-major order says it should.
(check "every sample and channel round-trips to its declared value"
       (let [values (result :values)]
         (var ok true)
         (for z 0 2
           (for x 0 3
             (for c 0 5
               (def idx (+ x (* z 3)))
               (def channel (get ct/channels c))
               (def got (get (get values channel) idx))
               (unless (= got (value-at z x c)) (set ok false)))))
         ok))

(check "channel-last order is honoured: sample 1 ch0 differs from sample 0 ch1"
       (let [values (result :values)]
         (not= (get (get values :temperature) 1)
               (get (get values :temperature-seasonality) 0))))

(check "the extracted channels are not writable buffers"
       (not (buffer? (get (result :values) :temperature))))

#
# --- Absence is not an error -------------------------------------------
#

(print "\nabsence:")

(def absent (ct/read nil nil {:has_climate false}))

(check "no buffer and no claim reads as unavailable" (ct/unavailable? absent))
(check "absent reports the reason as absent" (= :absent (absent :reason)))
(check "absent carries no values key" (nil? (absent :values)))
(check "absent is NOT an empty grid of zeros"
       (nil? ((ct/read nil nil {}) :values)))
(check "a nil metadata record is treated as no claim"
       (ct/unavailable? (ct/read nil nil nil)))

# The sidecar is the producer's own record of what it wrote. A contradiction
# means the pair does not belong together.
(check "metadata claiming climate with no buffer is refused"
       (has-message? (fn [] (ct/read nil nil {:has_climate true})) "no buffer"))
(check "metadata disclaiming climate with a buffer is refused"
       (has-message? (fn [] (ct/read buf [2 3 5] {:has_climate false})) "no climate"))

# `read` is the only entry point a cache layer needs, and the two call shapes
# are the whole contract. These pin that it delegates rather than differing from
# `validate`, so the two cannot drift into disagreeing answers.
(check "read and validate agree for the same present buffer"
       (deep= (ct/read buf [2 3 5] {:has_climate true})
              (ct/validate buf [2 3 5] true)))

(check "read and validate agree for absence"
       (deep= (ct/read nil nil {:has_climate false})
              (ct/validate nil nil false)))

# MISSING CLIMATE MUST NEVER BECOME ZEROS. A zero tile would be indistinguishable
# from a real datum, and would silently claim the model said "0 mm/yr".
(check "absent result has no :values key at all, so a caller cannot read zeros"
       (nil? (absent :values)))

(check "absent result has no width, height or sample count to iterate"
       (and (nil? (absent :width)) (nil? (absent :height))
            (nil? (absent :samples))))

(check "sampling an absent result refuses rather than returning zeros"
       (raises? (fn [] (ct/sample absent 0 0))))

(check "the reason is :absent, not a silent nil"
       (= :absent (absent :reason)))

(check "absence is reported through :status, so a caller must look at it"
       (and (= :unavailable (absent :status))
            (not (ct/present? absent))))

# validate refuses an unparsed flag rather than guessing what it means; parse-meta
# is the single place metadata becomes a boolean.
(check "validate refuses a raw metadata table, directing the caller to read"
       (has-message? (fn [] (ct/validate buf [2 3 5] {:has_climate true}))
                     "boolean"))

(check "validate accepts an explicit boolean"
       (ct/present? (ct/validate buf [2 3 5] true)))

#
# --- Integrity anchors already exist; none is invented here ------------
#
# The producer already records `raw_sha256` over the exact npz bytes and the
# scenic identity already hashes the whole descriptor, so this module adds no
# checksum of its own. What it does pin: the sidecar fields a caller will rely on
# are carried in the record it is handed, and a record that contradicts itself is
# refused rather than reconciled.
#

(print "\nintegrity:")

(check "a sidecar carrying a raw digest is accepted and untouched"
       (let [meta @{:has_climate true
                    :raw_sha256 (string/repeat "a" 64)
                    :quantized false}]
         (ct/present? (ct/read buf [2 3 5] meta))))

(check "the reader does not rewrite the metadata it was given"
       (let [meta @{:has_climate true :raw_sha256 "keep"}]
         (ct/read buf [2 3 5] meta)
         (= "keep" (get meta :raw_sha256))))

(check "a quantized flag does not change whether a buffer is readable"
       (ct/present? (ct/read buf [2 3 5] @{:has_climate true :quantized true})))

#
# --- Refusals -----------------------------------------------------------
#

(print "\nrefusals:")

(check "a truncated buffer is refused"
       (has-message? (fn [] (ct/validate (string/slice (string buf) 0 116)
                                         [2 3 5] true))
                     "requires exactly"))

(check "a buffer with trailing bytes is refused"
       (raises? (fn [] (ct/validate (string buf 0 0) [2 3 5] true))))

# A 3x2 grid has the same sample count as 2x3, so the byte length is identical
# and the reader CANNOT tell them apart -- it validates length and shape, and the
# declared shape governs indexing. That is deliberate: the producer hands over an
# already-decoded array whose extent it declares, and inventing a disagreement
# from a byte count that matches would refuse real data.
(check "an equal-count transposed shape is accepted, and the DECLARED shape governs"
       (let [r (ct/validate buf [3 2 5] true)]
         # shape is (height width channels): [3 2 5] is 3 tall, 2 wide.
         (and (ct/present? r)
              (= 3 (r :height)) (= 2 (r :width))
              (= 1 (ct/sample-index r 1 0))
              (= 2 (ct/sample-index r 0 1))
              (nil? (ct/sample-index r 2 0)))))

(check "a shape needing a different sample count is refused"
       (raises? (fn [] (ct/validate buf [2 2 5] true))))

(check "a non-buffer value is refused"
       (raises? (fn [] (ct/validate 42 [2 3 5] true))))

(check "a nil shape with a buffer is refused"
       (raises? (fn [] (ct/validate buf nil true))))

(check "an invalid metadata type is refused"
       (raises? (fn [] (ct/read buf [2 3 5] 42))))

# A NaN in the data must not become a zero, and must not be silently skipped.
(defn nan-buffer []
  (def b (pack (grid-samples 2 3)))
  # 0x7FC00000 little-endian at byte 0 is a quiet NaN.
  (put b 0 0) (put b 1 0) (put b 2 192) (put b 3 127)
  b)

(check "a NaN sample is refused, never turned into zero"
       (has-message? (fn [] (ct/validate (nan-buffer) [2 3 5] true))
                     "NaN"))

(defn inf-buffer []
  (def b (pack (grid-samples 2 3)))
  # 0x7F800000 little-endian at byte 0 is positive infinity.
  (put b 0 0) (put b 1 0) (put b 2 128) (put b 3 127)
  b)

(check "a positive infinity sample is refused"
       (has-message? (fn [] (ct/validate (inf-buffer) [2 3 5] true))
                     "infinite"))

(check "the refusal names the offending sample index"
       (string/find "sample 0"
                    (message-of (fn [] (ct/validate (nan-buffer) [2 3 5]
                                                    true)))))

(check "a zero sample is ACCEPTED: a reader must not refuse real data"
       (let [b (pack (grid-samples 2 3))]
         (put b 0 0) (put b 1 0) (put b 2 0) (put b 3 0)
         (ct/present? (ct/validate b [2 3 5] true))))

(check "a negative sample is accepted"
       (let [b (pack (grid-samples 2 3))]
         (each i [0 1 2 3] (put b i (get (f32-bytes -4.5) i)))
         (= -4.5 (get (get ((ct/validate b [2 3 5] true) :values)
                           :temperature)
                      0))))

#
# --- Deterministic sampling --------------------------------------------
#

(print "\nsampling:")

(check "grid (0,0) is sample 0" (= 0 (ct/sample-index result 0 0)))
(check "samples are x-fastest: (2,0) is index 2"
       (= 2 (ct/sample-index result 2 0)))
(check "samples are z-major: (0,1) is index 3"
       (= 3 (ct/sample-index result 0 1)))
(check "the last cell is index 5" (= 5 (ct/sample-index result 2 1)))
(check "a fractional cell floors to the cell containing it"
       (= 0 (ct/sample-index result 0.9 0.9)))
(check "a cell one past the width is nil, never clamped"
       (nil? (ct/sample-index result 3 0)))
(check "a cell one past the height is nil, never clamped"
       (nil? (ct/sample-index result 0 2)))
(check "a negative cell is nil" (nil? (ct/sample-index result -1 0)))
(check "an infinite coordinate is nil" (nil? (ct/sample-index result (/ 1 0) 0)))

(check "sample returns all five channels for a cell"
       (let [s (ct/sample result 0 0)]
         (and (ct/sampled? s) (= 5 (length (keys (s :values)))))))

(check "sample returns the value the producer wrote at that cell"
       (= (value-at 1 2 0) (get ((ct/sample result 2 1) :values) :temperature)))

(check "sample reports the index it read" (= 5 ((ct/sample result 2 1) :index)))

(check "a cell outside the grid is unavailable, never a neighbour's value"
       (let [s (ct/sample result 3 0)]
         (and (ct/unavailable? s) (= :outside-grid (s :reason)))))

(check "sample refuses a result that is not present"
       (raises? (fn [] (ct/sample absent 0 0))))

(check "sampling is deterministic across repeated calls"
       (every? (map (fn [_] (deep= (ct/sample result 1 1) (ct/sample result 1 1)))
                    (range 10))))

(check "sampling does not mutate the result"
       (let [before (string/format "%q" (result :values))]
         (ct/sample result 2 1)
         (= before (string/format "%q" (result :values)))))

#
# --- The unit contract is data -----------------------------------------
#

(print "\nunit contract:")

(check "the basis is source-derived, neither measured nor unknown"
       (= :source-derived ct/unit-basis))

# The dimensions are known from source, so READING is licensed. Calibration is
# not claimed, and the two are separate questions -- conflating them would make
# a usable reader look unusable.
(check "the units are established well enough to READ with"
       (true? (ct/units-verified?)))
(check "units-known? agrees that reading is licensed"
       (true? (ct/units-known?)))
(check "calibration is NOT claimed: no sample has been measured"
       (false? (ct/units-measured?)))

(check "every channel exposes the citation for its unit"
       (every? (map (fn [ch]
                      (let [b (ct/channel-basis ch)]
                        (and (string? b) (pos? (length b)))))
                    ct/channels)))
(check "temperature is degrees C" (= :celsius (ct/channel-unit :temperature)))
(check "precipitation is millimetres per year"
       (= :millimetres-per-year (ct/channel-unit :precipitation)))
(check "seasonality is a standard deviation, not a temperature"
       (= :standard-deviation-celsius (ct/channel-unit :temperature-seasonality)))
(check "precipitation variability is a percent coefficient"
       (= :percent (ct/channel-unit :precipitation-variability)))
(check "lapse rate is a coefficient in C per metre"
       (= :celsius-per-metre (ct/channel-unit :lapse-rate)))

(check "every channel names a unit and cites a basis"
       (every? (map (fn [ch]
                      (let [e (get ct/unit-contract ch)]
                        (and (keyword? (get e :unit))
                             (keyword? (get e :confidence))
                             (string? (get e :basis))
                             (pos? (length (get e :basis))))))
                    ct/channels)))

(check "no channel claims measured confidence"
       (every? (map (fn [ch]
                      (not= :measured (get (get ct/unit-contract ch) :confidence)))
                    ct/channels)))

(check "the contract covers exactly the five channels"
       (deep= (sort (map string (keys ct/unit-contract)))
              (sort (map string ct/channels))))

(check "an unknown channel has no unit" (nil? (ct/channel-unit :humidity)))

#
# --- The module owns no format -----------------------------------------
#

(print "\nno invented format:")

# The earlier TDC1 file format was deleted. These assert it did not creep back:
# a bound reader must expose no encoder, no magic, and no path helper.
# A deleted format must not creep back. `bender` exposes an imported module only
# through its `alias/name` form, so absence is proven by reading the source text
# rather than by a runtime lookup: a reintroduced encoder or magic would show up
# here immediately.
# The suite is normally run from the repository root, but a candidate path list
# keeps it working from `test/` too rather than silently asserting against "".
(defn slurp [path]
  (try
    (let [f (file/open path :rb)]
      (if (nil? f)
        nil
        (let [t (file/read f :all)] (file/close f) t)))
    ([e] nil)))

(def source-text
  (or (slurp "src/climate-tile.janet")
      (slurp "../src/climate-tile.janet")
      ""))

(check "the module source is readable, so these checks are real"
       (pos? (length source-text)))

# The source legitimately NAMES the deleted format once, in the comment that
# records why it was removed. What must be absent is any CODE defining it, so
# these checks look for a definition rather than for the word.
(check "the deleted format is recorded as deleted, not redefined"
       (and (string/find "has been deleted" source-text)
            (nil? (string/find "def magic" source-text))))

(check "the source does not define a magic constant"
       (nil? (string/find "(def magic" source-text)))

(check "there is no fixed tile byte length in the source"
       (nil? (string/find "tile-bytes" source-text)))

(check "there is no encoder left in the source"
       (nil? (string/find "(defn encode" source-text)))

(check "there is no decoder left in the source"
       (nil? (string/find "(defn decode" source-text)))

# `read` now exists and is CORRECT -- it parses a handed-over buffer, not a
# file. What must be absent is filesystem access, which is the actual property.
(check "the reader computes no checksum of its own; the producer already hashes"
       (nil? (string/find "sha256" source-text)))

(check "the module performs no filesystem access at all"
       (and (nil? (string/find "file/open" source-text))
            (nil? (string/find "os/lstat" source-text))
            (nil? (string/find "(defn write" source-text))))

(check "the reader is present in the source"
       (not (nil? (string/find "(defn read" source-text))))

(check "there is no tile-path helper left in the source"
       (nil? (string/find "tile-path" source-text)))

#
# --- parse-meta: the producer's sidecar shape --------------------------
#
# `tools/scenic_terrain.py:212` writes `"has_climate": climate is not None`, so a
# cache layer may hand over either a parsed boolean or a record predating the
# key. These pin both, and every way the flag can be wrong.
#

(print "\nmetadata:")

(check "a true flag parses true" (= true (ct/parse-meta @{:has_climate true})))
(check "a false flag parses false" (= false (ct/parse-meta @{:has_climate false})))

(check "a record without the key means no claim, not true"
       (= false (ct/parse-meta @{})))

(check "a nil record means no claim" (= false (ct/parse-meta nil)))

(check "a record from before the climate key still reads as absent"
       (ct/unavailable? (ct/read nil nil @{:source "scenic-raw-export"})))

(check "the producer's real record shape is accepted end to end"
       (ct/present? (ct/read buf [2 3 5]
                             @{:source "scenic-raw-export" :format 3
                               :has_climate true :quantized false})))

(check "a string \"false\" is refused, not coerced to false"
       (raises? (fn [] (ct/parse-meta @{:has_climate "false"}))))

(check "a number flag is refused, not coerced"
       (raises? (fn [] (ct/parse-meta @{:has_climate 0}))))

(check "a non-table metadata value is refused"
       (raises? (fn [] (ct/parse-meta "true"))))

(check "read refuses a truthy-but-not-true flag rather than reading a buffer"
       (raises? (fn [] (ct/read buf [2 3 5] @{:has_climate 1}))))

#
# --- Malformed input: positive and negative ----------------------------
#

(print "\nmalformed:")

# Positive control: the SAME bytes with the same metadata must keep working, so a
# refusal below is caused by the mutation and not by a broken fixture.
(check "the unmutated fixture still reads as present"
       (ct/present? (ct/read buf [2 3 5] @{:has_climate true})))

(check "flipping one byte changes a value but keeps the buffer valid"
       (let [b (pack (grid-samples 2 3))]
         # 0x7F800000 -> a large finite value stays finite; mutate to 2.0 instead.
         (each i [0 1 2 3] (put b i (get (f32-bytes 2.0) i)))
         (let [r (ct/read b [2 3 5] @{:has_climate true})]
           (and (ct/present? r) (= 2.0 (get (get (r :values) :temperature) 0))))))

(check "a buffer that is one byte short of the shape is refused"
       (raises? (fn [] (ct/read (string/slice (string buf) 0 119)
                                [2 3 5] @{:has_climate true}))))

(check "a buffer that is one byte long of the shape is refused"
       (raises? (fn [] (ct/read (buffer/push buf 0) [2 3 5] @{:has_climate true}))))

(check "a two-dimensional shape is refused, so elevation cannot be read as climate"
       (raises? (fn [] (ct/read buf [2 3] @{:has_climate true}))))

(check "a six-channel shape is refused"
       (raises? (fn [] (ct/read buf [2 3 6] @{:has_climate true}))))

# Every position of NaN and infinity must be caught, not just the first -- a
# single early check would let a later one through.
(check "a NaN in the LAST sample is caught as well as in the first"
       (let [b (pack (grid-samples 2 3))
             last-idx (* 5 5 4)]       # last sample, channel 0
         (put b last-idx 0) (put b (+ last-idx 1) 0)
         (put b (+ last-idx 2) 192) (put b (+ last-idx 3) 127)
         (has-message? (fn [] (ct/read b [2 3 5] @{:has_climate true})) "NaN")))

(check "a negative infinity is refused too"
       (let [b (pack (grid-samples 2 3))]
         (put b 0 0) (put b 1 0) (put b 2 128) (put b 3 255)
         (has-message? (fn [] (ct/read b [2 3 5] @{:has_climate true}))
                       "infinite")))

#
# --- Summary ------------------------------------------------------------
#

(if (zero? failures)
  (print "\nclimate reader tests: pass")
  (do (printf "\n%d check(s) failed" failures)
      (error "climate reader tests failed")))
