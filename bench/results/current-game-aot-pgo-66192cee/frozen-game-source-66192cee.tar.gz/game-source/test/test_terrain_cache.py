"""Dependency-free unit tests for :mod:`tools.terrain_cache`.

Run from anywhere::

    PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s test -p 'test_terrain_cache.py' -v

The suite imports the module by path relative to this file, so the working
directory never matters.  Bytecode writing is disabled before that import, so a
run leaves no ``__pycache__`` in the shared checkout; the test never deletes
repository artifacts.
"""

import errno
import hashlib
import json
import os
import struct
import sys
import zlib
import tempfile
import unittest

# Importing terrain_cache would otherwise write tools/__pycache__ into a shared
# working tree. This test owns only its own artifacts, so suppress it here
# rather than editing the repository's shared .gitignore.
sys.dont_write_bytecode = True

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_TOOLS_DIR = os.path.join(_REPO_ROOT, "tools")
if _TOOLS_DIR not in sys.path:
    sys.path.insert(0, _TOOLS_DIR)

import terrain_cache as tc  # noqa: E402


def _build_tile(cx, cz, payload, fields=None):
    """Assemble a raw tile; ``fields`` overrides (crc, sha256) defaults."""
    crc, digest = fields or (
        zlib.crc32(payload) & 0xFFFFFFFF,
        hashlib.sha256(payload).digest(),
    )
    return tc.HEADER_STRUCT.pack(
        tc.MAGIC, cx, cz, len(payload), crc, digest
    ) + payload


def _flat_heights(value=30):
    return bytes([value]) * tc.TILE_PAYLOAD_SIZE


# The full sampler/inference geometry a production descriptor must pin.
_SAMPLER_DEFAULTS = {
    "name": "dpm-solver++",
    "steps": 20,
    "guidance": 1.0,
    "scheduler": "karras",
    "T": 2,
    "coarse_window": 64,
    "coarse_stride": 48,
    "latent_window": 64,
    "latent_stride": 32,
    "decoder_window": 512,
    "decoder_stride": 384,
}


def _sampler(**overrides):
    return dict(_SAMPLER_DEFAULTS, **overrides)


def _descriptor(**overrides):
    base = {
        "model": "terrain-diffusion-30m",
        "model_revision": "hf-rev-1",
        "upstream_revision": "e8dcb4b1a834ab2f6b1a6f5256ed7c9f2f3e8230",
        "seed": 1234,
        "sampler": _sampler(),
        "pixels_per_voxel": 1,
        "mapping": "heights",
        "units": "meters",
        "dtype": "fp16",
        "device": "cpu",
    }
    base.update(overrides)
    return base


class TileRoundTripTests(unittest.TestCase):
    def test_size_and_header_fields(self):
        heights = bytes(range(tc.HEIGHT_MIN, tc.HEIGHT_MIN + 56)) + _flat_heights(12)
        heights = heights[: tc.TILE_PAYLOAD_SIZE]
        data = tc.encode_tile(-3, 7, heights)
        self.assertEqual(len(data), 308)
        self.assertEqual(len(data), tc.TILE_BYTES)
        magic, cx, cz, length, crc, digest = tc.HEADER_STRUCT.unpack_from(data)
        self.assertEqual(magic, b"TDH2")
        self.assertEqual((cx, cz), (-3, 7))
        self.assertEqual(length, 256)
        self.assertEqual(crc, zlib.crc32(heights) & 0xFFFFFFFF)
        self.assertEqual(digest, hashlib.sha256(heights).digest())
        self.assertEqual(data[tc.HEADER_STRUCT.size:], heights)

    def test_header_struct_is_52_bytes(self):
        self.assertEqual(tc.HEADER_STRUCT.size, 52)
        self.assertEqual(tc.HEADER_STRUCT.size + 256, 308)
        self.assertEqual(struct.calcsize("<4siiII32s"), 52)
        self.assertEqual(tc.MAGIC, b"TDH2")
        self.assertEqual(tc.FORMAT_VERSION, 2)

    def test_roundtrip_returns_payload(self):
        heights = bytes([4 + (i % 57) for i in range(tc.TILE_PAYLOAD_SIZE)])
        data = tc.encode_tile(0, 0, heights)
        cx, cz, payload = tc.decode_tile(data, 0, 0)
        self.assertEqual((cx, cz), (0, 0))
        self.assertEqual(payload, heights)

    def test_x_fastest_indexing(self):
        heights = bytearray(_flat_heights(10))
        heights[3 + 16 * 5] = 42  # x=3, z=5
        data = tc.encode_tile(1, 1, bytes(heights))
        _, _, payload = tc.decode_tile(data, 1, 1)
        self.assertEqual(payload[3 + 16 * 5], 42)
        self.assertEqual(payload[5 + 16 * 3], 10)

    def test_boundary_heights_accepted(self):
        heights = bytearray(_flat_heights(tc.HEIGHT_MIN))
        heights[0] = tc.HEIGHT_MAX
        data = tc.encode_tile(0, 0, bytes(heights))
        _, _, payload = tc.decode_tile(data, 0, 0)
        self.assertEqual(payload[0], tc.HEIGHT_MAX)
        self.assertEqual(payload[1], tc.HEIGHT_MIN)

    def test_negative_coordinates_roundtrip(self):
        data = tc.encode_tile(-7, -9, _flat_heights())
        self.assertEqual(tc.decode_tile(data, -7, -9)[:2], (-7, -9))

    def test_int32_limits(self):
        for coord in (-(2 ** 31), 2 ** 31 - 1):
            data = tc.encode_tile(coord, coord, _flat_heights())
            self.assertEqual(tc.decode_tile(data, coord, coord)[:2], (coord, coord))
        with self.assertRaises(ValueError):
            tc.encode_tile(2 ** 31, 0, _flat_heights())


class TileIntegrityFieldTests(unittest.TestCase):
    def test_crc32_matches_standard_conformance_vectors(self):
        # These are the values a Janet CRC-32 implementation must reproduce.
        self.assertEqual(zlib.crc32(b"123456789") & 0xFFFFFFFF, 0xCBF43926)
        self.assertEqual(zlib.crc32(b"") & 0xFFFFFFFF, 0x00000000)
        self.assertEqual(zlib.crc32(bytes(256)) & 0xFFFFFFFF, 0x0D968558)
        self.assertEqual(zlib.crc32(_flat_heights(30)) & 0xFFFFFFFF, 0x1208A28A)

    def test_crc_field_matches_payload_on_wire(self):
        heights = _flat_heights(30)
        data = tc.encode_tile(0, 0, heights)
        crc = struct.unpack_from("<I", data, 16)[0]
        self.assertEqual(crc, zlib.crc32(heights) & 0xFFFFFFFF)
        self.assertEqual(crc, 0x1208A28A)
        self.assertEqual(data[52:], heights)

    def test_sha256_field_matches_payload_on_wire(self):
        heights = _flat_heights(30)
        data = tc.encode_tile(0, 0, heights)
        self.assertEqual(data[20:52], hashlib.sha256(heights).digest())


class TileCorruptionTests(unittest.TestCase):
    def setUp(self):
        self.data = tc.encode_tile(2, -4, _flat_heights())

    def test_truncated(self):
        for length in (0, 10, 51, 52, 307):
            with self.assertRaises(tc.TileCorruptError):
                tc.decode_tile(self.data[:length], 2, -4)

    def test_trailing_bytes(self):
        with self.assertRaises(tc.TileCorruptError):
            tc.decode_tile(self.data + b"\x00", 2, -4)

    def test_bad_magic(self):
        broken = b"TDH9" + self.data[4:]
        with self.assertRaises(tc.TileCorruptError):
            tc.decode_tile(broken, 2, -4)

    def test_obsolete_tdh1_rejected(self):
        # A 304-byte TDH1 file must not be accepted by the TDH2 reader.
        payload = _flat_heights()
        legacy = struct.pack(
            "<4siiI32s", b"TDH1", 2, -4, 256, hashlib.sha256(payload).digest()
        ) + payload
        self.assertEqual(len(legacy), 304)
        with self.assertRaises(tc.TileCorruptError):
            tc.decode_tile(legacy, 2, -4)

    def test_bad_payload_length(self):
        header = tc.HEADER_STRUCT.pack(
            b"TDH2", 2, -4, 255, 0, hashlib.sha256(_flat_heights()).digest()
        )
        with self.assertRaises(tc.TileCorruptError):
            tc.decode_tile(header + self.data[52:], 2, -4)

    def test_wrong_requested_coordinates(self):
        for cx, cz in ((2, -3), (3, -4), (0, 0)):
            with self.assertRaises(tc.TileCorruptError):
                tc.decode_tile(self.data, cx, cz)

class TilePayloadIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.data = tc.encode_tile(2, -4, _flat_heights())

    def test_flipped_payload_byte_fails_digest(self):
        broken = bytearray(self.data)
        broken[60] = 55
        with self.assertRaises(tc.TileCorruptError):
            tc.decode_tile(bytes(broken), 2, -4)

    def test_flipped_header_integrity_bytes(self):
        # CRC-32 lives at offset 16, the SHA-256 digest at 20..51.
        for offset in (16, 20, 40, 51):
            with self.subTest(offset=offset):
                broken = bytearray(self.data)
                broken[offset] ^= 0xFF
                with self.assertRaises(tc.TileCorruptError):
                    tc.decode_tile(bytes(broken), 2, -4)

    def test_forged_crc_still_fails_sha256(self):
        # Both fields are checked; a correct CRC alone is not enough.
        payload = bytes([31]) + _flat_heights()[1:]
        forged = _build_tile(
            2, -4, payload,
            (zlib.crc32(payload) & 0xFFFFFFFF,
             hashlib.sha256(_flat_heights()).digest()),
        )
        with self.assertRaises(tc.TileCorruptError):
            tc.decode_tile(forged, 2, -4)

    def test_out_of_range_height_in_payload(self):
        # A self-consistent file whose payload itself is out of band.
        payload = bytes([61]) + _flat_heights()[1:]
        data = _build_tile(2, -4, payload)
        with self.assertRaises(tc.TileCorruptError):
            tc.decode_tile(data, 2, -4)

    def test_non_bytes_rejected(self):
        with self.assertRaises(TypeError):
            tc.decode_tile("not bytes", 2, -4)


class EncodeValidationTests(unittest.TestCase):
    def test_wrong_length(self):
        for bad in ("", "x" * 255, "x" * 257):
            with self.assertRaises(ValueError):
                tc.encode_tile(0, 0, list(bad))

    def test_bool_height_rejected(self):
        heights = list(_flat_heights())
        heights[0] = True
        with self.assertRaises(TypeError):
            tc.encode_tile(0, 0, heights)

    def test_non_int_height_rejected(self):
        heights = list(_flat_heights())
        heights[0] = 30.0
        with self.assertRaises(TypeError):
            tc.encode_tile(0, 0, heights)

    def test_out_of_range_heights_rejected(self):
        for value in (tc.HEIGHT_MIN - 1, tc.HEIGHT_MAX + 1, 0, 255):
            heights = list(_flat_heights())
            heights[5] = value
            with self.assertRaises(ValueError):
                tc.encode_tile(0, 0, heights)

    def test_bool_and_float_coordinates_rejected(self):
        for cx in (True, 1.0, "1"):
            with self.assertRaises(TypeError):
                tc.encode_tile(cx, 0, _flat_heights())
        with self.assertRaises(TypeError):
            tc.encode_tile(0, False, _flat_heights())

    def test_accepts_bytes_and_lists(self):
        self.assertEqual(
            tc.encode_tile(0, 0, _flat_heights()),
            tc.encode_tile(0, 0, list(_flat_heights())),
        )


class IdentityTests(unittest.TestCase):
    def test_digest_is_sha256_of_canonical_json(self):
        descriptor = _descriptor()
        record = tc.identity_descriptor(descriptor)
        canonical = json.dumps(record, sort_keys=True, separators=(",", ":"))
        expected = hashlib.sha256(canonical.encode("ascii")).hexdigest()
        self.assertEqual(tc.identity_digest(descriptor), expected)
        self.assertEqual(len(expected), 64)

    def test_key_order_does_not_matter(self):
        first = _descriptor()
        second = dict(reversed(list(first.items())))
        self.assertEqual(tc.identity_digest(first), tc.identity_digest(second))

    def test_every_relevant_field_changes_digest(self):
        base = tc.identity_digest(_descriptor())
        changes = {
            "model": "terrain-diffusion-90m",
            "model_revision": "hf-rev-2",
            "seed": 1235,
            "sampler": _sampler(name="euler-b"),
            "mapping": "diffusion",
            "upstream_revision": "other-upstream",
            "pixels_per_voxel": 2,
            "units": "feet",
            "dtype": "fp32",
            "device": "cuda",
        }
        self.assertEqual(set(changes), set(tc.IDENTITY_KEYS))
        for key, value in changes.items():
            with self.subTest(key=key):
                self.assertNotEqual(base, tc.identity_digest(_descriptor(**{key: value})))

    def test_missing_field_rejected(self):
        descriptor = _descriptor()
        for key in tc.IDENTITY_KEYS:
            partial = dict(descriptor)
            del partial[key]
            with self.assertRaises(ValueError):
                tc.identity_digest(partial)

    def test_nan_seed_rejected(self):
        with self.assertRaises((TypeError, ValueError)):
            tc.identity_digest(_descriptor(seed=float("nan")))

    def test_descriptor_fields_are_typed(self):
        with self.assertRaises(TypeError):
            tc.identity_digest(_descriptor(seed="1234"))
        with self.assertRaises(TypeError):
            tc.identity_digest(_descriptor(seed=True))
        for key in ("model", "model_revision", "upstream_revision", "sampler",
                    "mapping", "units", "dtype", "device"):
            with self.subTest(key=key):
                with self.assertRaises(TypeError):
                    tc.identity_digest(_descriptor(**{key: 5}))
                with self.assertRaises((TypeError, ValueError)):
                    tc.identity_digest(_descriptor(**{key: ""}))


class IdentityValidationTests(unittest.TestCase):
    def test_upstream_revision_is_required(self):
        # A backend that forgets the upstream pin must not silently land on a
        # different generation's identity.
        partial = _descriptor()
        del partial["upstream_revision"]
        with self.assertRaises(ValueError):
            tc.identity_digest(partial)
        base = tc.identity_digest(_descriptor())
        self.assertNotEqual(
            base, tc.identity_digest(_descriptor(upstream_revision="ffffffff"))
        )

    def test_pixels_per_voxel_is_required_and_hashed(self):
        partial = _descriptor()
        del partial["pixels_per_voxel"]
        with self.assertRaises(ValueError):
            tc.identity_digest(partial)
        for bad in (0, -1, True, 1.0, "1"):
            with self.subTest(value=bad):
                with self.assertRaises((TypeError, ValueError)):
                    tc.identity_digest(_descriptor(pixels_per_voxel=bad))
        base = tc.identity_digest(_descriptor())
        self.assertNotEqual(base, tc.identity_digest(_descriptor(pixels_per_voxel=2)))

    def test_mapping_accepts_structured_pins(self):
        structured = _descriptor(mapping={"quantization": "none", "resolution": 1})
        digest = tc.identity_digest(structured)
        self.assertEqual(len(digest), 64)
        self.assertEqual(
            tc.identity_descriptor(structured)["mapping"]["resolution"], 1
        )
        self.assertNotEqual(
            digest,
            tc.identity_digest(_descriptor(mapping={"quantization": "sqrt"})),
        )

class SamplerGeometryTests(unittest.TestCase):
    def test_sampler_must_pin_full_geometry(self):
        # A bare string does not pin window/stride, so it is refused outright.
        for bad in ("DPM++", "dpm-solver++", {}, None, 20):
            with self.subTest(sampler=bad):
                with self.assertRaises((TypeError, ValueError)):
                    tc.identity_digest(_descriptor(sampler=bad))
        for key in tc.SAMPLER_GEOMETRY_KEYS:
            with self.subTest(missing=key):
                partial = _sampler()
                del partial[key]
                with self.assertRaises(ValueError):
                    tc.identity_digest(_descriptor(sampler=partial))

    def test_window_and_stride_changes_change_identity(self):
        # These change sampled output, so they must never share a directory.
        base = tc.identity_digest(_descriptor())
        for key, value in (
            ("coarse_window", 128), ("coarse_stride", 96),
            ("latent_window", 32), ("latent_stride", 16),
            ("decoder_window", 256), ("decoder_stride", 192),
            ("T", 1), ("steps", 30),
        ):
            with self.subTest(key=key):
                self.assertNotEqual(
                    base, tc.identity_digest(_descriptor(sampler=_sampler(**{key: value})))
                )


class IdentityPinTests(unittest.TestCase):
    def test_quantization_is_pinned_into_identity(self):
        fmt = tc.identity_descriptor(_descriptor())["format"]
        self.assertEqual(fmt["sea_level"], tc.SEA_LEVEL)
        self.assertEqual(fmt["meters_per_voxel"], tc.METERS_PER_VOXEL)
        self.assertEqual(fmt["baseline_elevation_m"], tc.BASELINE_ELEVATION_M)

    def test_reserved_format_key_rejected(self):
        with self.assertRaises(ValueError):
            tc.identity_digest(_descriptor(format={"version": 99}))

    def test_extra_keys_pin_sampling_geometry(self):
        base = _descriptor()
        full = tc.identity_digest(
            dict(base, geometry={"T": 2, "decoder": [512, 384]})
        )
        other = tc.identity_digest(
            dict(base, geometry={"T": 2, "decoder": [256, 192]})
        )
        self.assertNotEqual(tc.identity_digest(base), full)
        self.assertNotEqual(full, other)
        self.assertEqual(
            tc.identity_descriptor(dict(base, geometry={"T": 2}))["geometry"],
            {"T": 2},
        )
        # Extras are still subject to canonical-JSON rules.
        with self.assertRaises(ValueError):
            tc.identity_digest(dict(base, geometry={"T": float("nan")}))


class IdentityFormatTests(unittest.TestCase):
    def test_identity_is_position_independent(self):
        # Nothing about the tile being requested may leak into the identity.
        descriptor = _descriptor()
        digest = tc.identity_digest(descriptor)
        for cx, cz in ((0, 0), (5, -3), (-1000, 4000)):
            self.assertEqual(tc.identity_digest(descriptor), digest)
            tc.world_voxel(cx, cz, 0, 0)
        self.assertEqual(tc.identity_digest(descriptor), digest)

    def test_format_block_pinned(self):
        record = tc.identity_descriptor(_descriptor())
        self.assertEqual(record["format"]["version"], tc.FORMAT_VERSION)
        self.assertEqual(record["format"]["magic"], "TDH2")
        self.assertEqual(record["format"]["tile_size"], 16)
        self.assertEqual(record["format"]["height_min"], tc.HEIGHT_MIN)
        self.assertEqual(record["format"]["height_max"], tc.HEIGHT_MAX)


class _ManifestFixture(unittest.TestCase):
    """A temporary cache root plus the descriptor used by manifest tests."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = self._tmp.name
        self.descriptor = _descriptor()

    def tearDown(self):
        self._tmp.cleanup()

    def _manifest_path(self, digest):
        return os.path.join(self.root, digest, tc.MANIFEST_NAME)

    def _rewrite_manifest(self, digest, mutate):
        path = self._manifest_path(digest)
        with open(path, "rb") as handle:
            record = json.loads(handle.read())
        mutate(record)
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(record, handle)
        return path


class ManifestTests(_ManifestFixture):
    def test_write_then_read(self):
        digest = tc.write_manifest(self.root, self.descriptor)
        self.assertEqual(digest, tc.identity_digest(self.descriptor))
        record = tc.read_manifest(self.root, digest)
        self.assertEqual(record["identity"], tc.identity_descriptor(self.descriptor))
        self.assertEqual(record["identity_digest"], digest)
        self.assertEqual(record["payload_bytes"], 256)
        self.assertEqual(record["tile_bytes"], 308)
        self.assertTrue(
            os.path.isfile(os.path.join(self.root, digest, "manifest.json"))
        )

    def test_rewrite_is_noop(self):
        digest = tc.write_manifest(self.root, self.descriptor)
        path = os.path.join(self.root, digest, "manifest.json")
        before = os.stat(path).st_mtime_ns
        with open(path, "rb") as handle:
            before_bytes = handle.read()
        self.assertEqual(tc.write_manifest(self.root, self.descriptor), digest)
        with open(path, "rb") as handle:
            self.assertEqual(handle.read(), before_bytes)
        self.assertEqual(os.stat(path).st_mtime_ns, before)

    def test_conflicting_descriptor_refused(self):
        digest = tc.write_manifest(self.root, self.descriptor)
        path = os.path.join(self.root, digest, "manifest.json")
        with open(path, "rb") as handle:
            original = handle.read()
        # Rewrite the manifest as if a different generation had been pinned to
        # the same directory.
        tampered = json.loads(original)
        tampered["identity"]["seed"] = 9999
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(tampered, handle)
        with self.assertRaises(tc.ManifestConflict):
            tc.read_manifest(self.root, digest)
        with self.assertRaises(tc.ManifestConflict):
            tc.write_manifest(self.root, self.descriptor)

class ManifestTamperTests(_ManifestFixture):
    def test_invalid_json_manifest(self):
        digest = tc.write_manifest(self.root, self.descriptor)
        with open(self._manifest_path(digest), "wb") as handle:
            handle.write(b"{not json")
        with self.assertRaises(tc.ManifestConflict):
            tc.read_manifest(self.root, digest)

    def test_mismatched_explicit_digest(self):
        with self.assertRaises(ValueError):
            tc.write_manifest(self.root, self.descriptor, digest="a" * 64)

    def test_missing_manifest_is_file_not_found(self):
        with self.assertRaises(FileNotFoundError):
            tc.read_manifest(self.root, "b" * 64)


class ManifestInvariantTests(_ManifestFixture):
    def test_tampering_is_rejected_by_read_and_rewrite(self):
        # Each mutation must fail BOTH a read and a repeat write, so a tampered
        # record can never be laundered into a no-op manifest.
        def set_field(record, key, value):
            record[key] = value

        def set_identity(record, key, value):
            record["identity"][key] = value

        mutations = (
            ("unexpected field", lambda r: set_field(r, "unexpected", True)),
            ("tile_bytes", lambda r: set_field(r, "tile_bytes", 304)),
            ("payload_bytes", lambda r: set_field(r, "payload_bytes", 512)),
            ("identity seed", lambda r: set_identity(r, "seed", 9999)),
            ("identity digest", lambda r: set_field(r, "identity_digest", "0" * 64)),
        )
        for label, mutate in mutations:
            with self.subTest(mutation=label):
                digest = tc.write_manifest(self.root, self.descriptor)
                path = os.path.join(self.root, digest, tc.MANIFEST_NAME)
                with open(path, "rb") as handle:
                    original = handle.read()
                self._rewrite_manifest(digest, mutate)
                with self.assertRaises(tc.ManifestConflict):
                    tc.read_manifest(self.root, digest)
                with self.assertRaises(tc.ManifestConflict):
                    tc.write_manifest(self.root, self.descriptor)
                # Restoring the genuine record makes it usable again.
                with open(path, "wb") as handle:
                    handle.write(original)
                self.assertEqual(
                    tc.write_manifest(self.root, self.descriptor), digest
                )

class ManifestPublishFailureTests(_ManifestFixture):
    def test_manifest_publish_fails_closed_without_hardlinks(self):
        # No unsafe direct-write fallback: an unsupported hard link must raise
        # rather than expose a partially written manifest at the final path.
        original = os.link

        def unsupported(*_args, **_kwargs):
            raise OSError(getattr(errno, "ENOTSUP", 45), "unsupported")

        os.link = unsupported
        try:
            with self.assertRaises(tc.AtomicPublishUnsupported):
                tc.write_manifest(self.root, self.descriptor)
        finally:
            os.link = original
        digest = tc.identity_digest(self.descriptor)
        directory = os.path.join(self.root, digest)
        self.assertFalse(os.path.exists(os.path.join(directory, tc.MANIFEST_NAME)))
        self.assertEqual(
            [], [n for n in os.listdir(directory) if n.startswith(".tmp-")]
            if os.path.isdir(directory)
            else [],
        )

    def test_manifest_publish_surfaces_other_io_errors(self):
        # A permission or disk failure is not "no hard links"; it must propagate.
        original = os.link

        def failing(*_args, **_kwargs):
            raise OSError(errno.ENOSPC, "no space")

        os.link = failing
        try:
            with self.assertRaises(OSError) as caught:
                tc.write_manifest(self.root, self.descriptor)
        finally:
            os.link = original
        self.assertNotIsInstance(caught.exception, tc.AtomicPublishUnsupported)
        self.assertEqual(caught.exception.errno, errno.ENOSPC)


class QuantizationTests(unittest.TestCase):
    def test_sea_level_mapping(self):
        self.assertEqual(tc.quantize_height(0), tc.SEA_LEVEL)
        self.assertEqual(tc.SEA_LEVEL, 28)
        self.assertEqual(tc.METERS_PER_VOXEL, 50)

    def test_meter_steps(self):
        self.assertEqual(tc.quantize_height(50), 29)
        self.assertEqual(tc.quantize_height(-50), 27)
        self.assertEqual(tc.quantize_height(25), 29)  # 0.5 rounds up
        self.assertEqual(tc.quantize_height(-25), 28)  # -0.5 rounds up to sea
        self.assertEqual(tc.quantize_height(24.9), 28)

class QuantizationClampTests(unittest.TestCase):
    def test_clamps_at_both_band_edges(self):
        cases = (
            (-100000, tc.HEIGHT_MIN),
            (-1200, tc.HEIGHT_MIN),   # 28 - 24 = 4
            (100000, tc.HEIGHT_MAX),
            (1600, tc.HEIGHT_MAX),    # 28 + 32 = 60
        )
        for elevation, expected in cases:
            with self.subTest(elevation=elevation):
                self.assertEqual(tc.quantize_height(elevation), expected)

    def test_rejects_nan_inf_and_bools(self):
        for value in (float("nan"), float("inf"), float("-inf"), True, False, "1"):
            with self.subTest(value=value):
                with self.assertRaises((TypeError, ValueError)):
                    tc.quantize_height(value)

class HeightMappingTests(unittest.TestCase):
    def test_rejects_bad_meters_per_voxel(self):
        for meters in (0, -50, float("nan"), float("inf"), True, "50"):
            with self.subTest(meters=meters):
                with self.assertRaises((TypeError, ValueError)):
                    tc.HeightMapping(meters_per_voxel=meters)

    def test_rejects_bad_bounds(self):
        with self.assertRaises(ValueError):
            tc.HeightMapping(height_min=70, height_max=4)
        with self.assertRaises(TypeError):
            tc.HeightMapping(height_min=4.0)
        with self.assertRaises(TypeError):
            tc.HeightMapping(sea_level=28.0)

class HeightMappingClampTests(unittest.TestCase):
    def test_mapping_is_immutable(self):
        with self.assertRaises(AttributeError):
            tc.HEIGHT_MAPPING.sea_level = 30

    def test_baseline_and_custom_mapping(self):
        mapping = tc.HeightMapping(
            meters_per_voxel=10,
            sea_level=20,
            baseline_elevation_m=100,
            height_min=0,
            height_max=64,
        )
        self.assertEqual(mapping.quantize(100), 20)
        self.assertEqual(mapping.quantize(110), 21)
        self.assertEqual(mapping.quantize(0), 10)  # (0-100)/10 + 20 = 10
        self.assertEqual(tc.quantize_height(100, mapping), 20)

    def test_overflowing_inputs_raise_value_error(self):
        # Two distinct overflow sources must both surface as ValueError:
        # an int too large for float, and a finite elevation whose ratio to
        # meters_per_voxel exceeds the double range.
        for value in (10 ** 400, -(10 ** 400)):
            with self.subTest(source="huge-int", value=repr(value)[:12]):
                with self.assertRaises(ValueError):
                    tc.quantize_height(value)
        tiny = tc.HeightMapping(meters_per_voxel=1e-300, height_min=0, height_max=64)
        for value in (1e300, -1e300):
            with self.subTest(source="ratio"):
                with self.assertRaises(ValueError):
                    tiny.quantize(value)

    def test_overflow_error_is_not_leaked(self):
        # OverflowError is a ValueError subclass, so assert the type is exactly
        # ValueError by checking the documented message path raises it.
        for value in (10 ** 400, -(10 ** 400)):
            with self.subTest(value=repr(value)[:12]):
                with self.assertRaisesRegex(ValueError, "too large"):
                    tc.quantize_height(value)

    def test_in_band_results_stay_exact_ints(self):
        for value in (0, 25, 50, 1600, -1200, 24.9):
            result = tc.quantize_height(value)
            self.assertIsInstance(result, int)
            self.assertTrue(tc.HEIGHT_MIN <= result <= tc.HEIGHT_MAX)

    def test_default_mapping_matches_module_constants(self):
        mapping = tc.HEIGHT_MAPPING
        self.assertEqual(mapping.sea_level, tc.SEA_LEVEL)
        self.assertEqual(mapping.meters_per_voxel, tc.METERS_PER_VOXEL)
        self.assertEqual(mapping.baseline_elevation_m, tc.BASELINE_ELEVATION_M)
        self.assertEqual(mapping.height_min, tc.HEIGHT_MIN)
        self.assertEqual(mapping.height_max, tc.HEIGHT_MAX)

    def test_same_world_column_across_tiles(self):
        # A world column is quantized from its elevation alone; whichever tile
        # covers it, the stored byte must match.
        elevation = 260.0  # 5.2 voxels above sea => 33
        expected = tc.quantize_height(elevation)
        self.assertEqual(expected, 33)

        with tempfile.TemporaryDirectory() as root:
            digest = tc.write_manifest(root, _descriptor())
            for cx, cz in ((0, 0), (1, 0), (-1, -1), (12, -9)):
                heights = [expected] * tc.TILE_PAYLOAD_SIZE
                tc.write_tile(root, digest, cx, cz, heights)
                _, _, payload = tc.read_tile(root, digest, cx, cz)
                self.assertEqual(payload[0], expected)
                self.assertEqual(payload[-1], expected)


class CoordinateTests(unittest.TestCase):
    def test_tile_local_to_world(self):
        self.assertEqual(tc.world_voxel(0, 0, 0, 0), (0, 0))
        self.assertEqual(tc.world_voxel(0, 0, 15, 15), (15, 15))
        self.assertEqual(tc.world_voxel(1, 2, 3, 4), (19, 36))

    def test_negative_chunks(self):
        self.assertEqual(tc.world_voxel(-1, -1, 0, 0), (-16, -16))
        self.assertEqual(tc.world_voxel(-1, -1, 15, 15), (-1, -1))
        self.assertEqual(tc.world_voxel(-2, 3, 1, 2), (-31, 50))

    def test_pixel_scaling(self):
        self.assertEqual(tc.world_pixel(1, -1, 2, 3, 1), (18, -13))
        self.assertEqual(tc.world_pixel(1, -1, 2, 3, 4), (72, -52))
        self.assertEqual(tc.world_pixel(-1, -1, 15, 15, 8), (-8, -8))

    def test_pixels_per_voxel_validation(self):
        for bad in (0, -1, True, False, 1.0, "1"):
            with self.subTest(value=bad):
                with self.assertRaises((TypeError, ValueError)):
                    tc.world_pixel(0, 0, 0, 0, bad)

    def test_local_bounds_validation(self):
        for x, z in ((-1, 0), (16, 0), (0, -1), (0, 16)):
            with self.assertRaises(ValueError):
                tc.world_voxel(0, 0, x, z)

    def test_tile_path_is_deterministic_and_signed(self):
        digest = "0" * 64
        path = tc.tile_path("/root", digest, -3, 12)
        self.assertEqual(path, os.path.join("/root", digest, "tiles", "-3_12.tdh"))
        self.assertEqual(tc.tile_path("/root", digest, -3, 12), path)
        self.assertNotEqual(path, tc.tile_path("/root", digest, 3, 12))

    def test_invalid_digest_rejected(self):
        for bad in ("", "abc", "A" * 64, "z" * 64, 42):
            with self.assertRaises((TypeError, ValueError)):
                tc.tile_path("/root", bad, 0, 0)


class _CacheFixture(unittest.TestCase):
    """A cache root with one identity already pinned."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = self._tmp.name
        self.digest = tc.write_manifest(self.root, _descriptor())

    def tearDown(self):
        self._tmp.cleanup()

    def _temp_files(self):
        found = []
        for base, _dirs, files in os.walk(self.root):
            found.extend(
                os.path.join(base, name)
                for name in files
                if name.startswith(".tmp-")
            )
        return found


class AtomicWriteTests(_CacheFixture):
    def test_write_read_roundtrip_leaves_no_temp_file(self):
        for cx, cz, level in ((-2, 5, 33), (0, 0, 30), (-1, -7, 41)):
            with self.subTest(cx=cx, cz=cz):
                path = tc.write_tile(self.root, self.digest, cx, cz, _flat_heights(level))
                self.assertTrue(os.path.isfile(path))
                self.assertEqual(os.path.getsize(path), tc.TILE_BYTES)
                self.assertEqual(
                    tc.read_tile(self.root, self.digest, cx, cz)[2],
                    _flat_heights(level),
                )
                self.assertEqual(self._temp_files(), [])

class TilePublishGuardTests(_CacheFixture):
    def test_write_without_manifest_is_refused(self):
        # A tile must never be published into an identity directory that has no
        # manifest, or read_tile would refuse what write_tile just created.
        digest = tc.identity_digest(_descriptor(seed=424242))
        orphan_root = os.path.join(self.root, "orphans")
        with self.assertRaises(FileNotFoundError):
            tc.write_tile(orphan_root, digest, 0, 0, _flat_heights(20))
        self.assertFalse(os.path.exists(os.path.join(orphan_root, digest)))
        self.assertFalse(os.path.exists(orphan_root))
        # And once the manifest exists, the same write succeeds and reads back.
        tc.write_manifest(orphan_root, _descriptor(seed=424242))
        tc.write_tile(orphan_root, digest, 0, 0, _flat_heights(20))
        self.assertEqual(tc.read_tile(orphan_root, digest, 0, 0)[2],
                         _flat_heights(20))

    def test_write_tile_refuses_digest_with_mismatched_manifest(self):
        # Publishing under a digest whose pinned identity differs must not
        # create a tile that a later reader would reject for other reasons.
        other = "f" * 64
        with self.assertRaises((FileNotFoundError, tc.ManifestConflict)):
            tc.write_tile(self.root, other, 1, 1, _flat_heights(20))
        self.assertFalse(os.path.exists(os.path.join(self.root, other)))

    def test_failed_encode_preserves_existing_tile(self):
        path = tc.write_tile(self.root, self.digest, 0, 0, _flat_heights(21))
        with open(path, "rb") as handle:
            original = handle.read()
        bad = list(_flat_heights())
        bad[7] = 99
        with self.assertRaises(ValueError):
            tc.write_tile(self.root, self.digest, 0, 0, bad)
        with open(path, "rb") as handle:
            self.assertEqual(handle.read(), original)
        self.assertEqual(self._temp_files(), [])

    def test_rewrite_replaces_previous_content(self):
        tc.write_tile(self.root, self.digest, 1, 1, _flat_heights(20))
        tc.write_tile(self.root, self.digest, 1, 1, _flat_heights(40))
        self.assertEqual(
            tc.read_tile(self.root, self.digest, 1, 1)[2], _flat_heights(40)
        )

    def test_read_tile_verifies_identity(self):
        tc.write_tile(self.root, self.digest, 0, 0, _flat_heights())
        unknown = "f" * 64
        with self.assertRaises(FileNotFoundError):
            tc.read_tile(self.root, unknown, 0, 0)
        self.assertEqual(tc.read_tile(self.root, self.digest, 0, 0)[2], _flat_heights())

    def test_missing_tile_is_file_not_found(self):
        with self.assertRaises(FileNotFoundError):
            tc.read_tile(self.root, self.digest, 5, 5)

class TileCorruptionOnDiskTests(_CacheFixture):
    def test_corrupt_tile_on_disk_detected(self):
        path = tc.write_tile(self.root, self.digest, 0, 0, _flat_heights(25))
        with open(path, "r+b") as handle:
            handle.seek(tc.HEADER_STRUCT.size + 3)
            handle.write(b"\xff")
        with self.assertRaises(tc.TileCorruptError):
            tc.read_tile(self.root, self.digest, 0, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
