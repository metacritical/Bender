#!/usr/bin/env bash
# Locate the bender interpreter and run Trinecraft with it.
#
# Trinecraft needs the `bender` Janet fork rather than upstream Janet: it
# depends on bender's built-in FFI (ffi/struct, ffi/defbind-alias, unsafe/poke)
# to talk to raylib without any C shim.
#
# Resolution order:
#   1. $BENDER                      explicit override
#   2. ../../janet/build/bender     the sibling checkout this was split from
#   3. bender on $PATH
#
# Usage:  ./run.sh                       launch the engine (interpreter)
#         ./run.sh build [out]           compile a native AOT executable
#         ./run.sh --screenshot out.png  headless capture
#         ./run.sh test                  run every test suite
#         ./run.sh repl                  headless REPL with the engine loaded
set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

find_bender() {
  if [[ -n "${BENDER:-}" ]]; then
    if [[ -x "$BENDER" ]]; then echo "$BENDER"; return 0; fi
    echo "error: \$BENDER is set to '$BENDER' but that is not executable" >&2
    return 1
  fi
  local sibling="$here/../../janet/build/bender"
  if [[ -x "$sibling" ]]; then echo "$sibling"; return 0; fi
  if command -v bender >/dev/null 2>&1; then command -v bender; return 0; fi
  cat >&2 <<'EOF'
error: could not find the `bender` interpreter.

Trinecraft requires the bender Janet fork, not upstream Janet, because it
drives raylib through bender's built-in FFI.

Set BENDER to the binary, for example:
    BENDER=/path/to/janet/build/bender ./run.sh
EOF
  return 1
}

if [[ "${1:-}" == "test-capture-contract" ]]; then
  shift
  if (( $# != 0 )); then
    printf 'usage: %s test-capture-contract (no arguments)\n' "$0" >&2
    exit 2
  fi
  cd "$here"
  # Explicit stdlib-only suites: no model imports, oracle captures or inference.
  failed=0
  for suite in test.test_terrain_stage_capture test.test_validate_stage_capture test.test_stage_capture_contract; do
    # Isolate import-state assertions from other suites' mocked modules.
    if "${PYTHON:-python3}" -m unittest "$suite"; then :; else failed=1; fi
  done
  exit "$failed"
fi

bender="$(find_bender)"

if [[ "${1:-}" == "test-native-arithmetic" ]]; then
  shift
  export BENDER="$bender"
  exec bash "$here/native/proof/test-arithmetic.sh" "$@"
fi

if [[ "${1:-}" == "test" ]]; then
  shift
  failed=0
  for suite in world materials climate-tile climate-biome biome-surface static-hydrology world-seed world-catalog world-session session-exit-save world-provider world-menu world-menu-view worldgen worldgen-heights generation-job generation-loop terrain-runtime terrain-integrity terrain-identity terrain-cache terrain-main-integration scenic-main loading-screen asset-paths spawn scenic-worldgen scenic-climate scenic-climate-integration atlas mesher rl player raycast console stream progressive-stream frustum palette region; do
    printf '=== %s ===\n' "$suite"
    if "$bender" "$here/test/$suite-test.janet" "$@"; then :; else
      failed=1
      printf '!!! %s FAILED\n' "$suite"
    fi
  done
  exit "$failed"
fi


if [[ "${1:-}" == "build" ]]; then
  # Compile the game to a native AOT executable.
  #
  # This is NOT what `./run.sh` (or the Emacs launcher) does: those exec the
  # interpreter against main.janet, so source edits take effect on the next
  # launch with no build step. Compiling is for distribution and for measuring
  # native speed, and it must be re-run after any source edit.
  #
  # The image embeds Janet code only; raylib is still loaded through FFI at
  # runtime, so the binary needs libraylib present just like the interpreter.
  shift
  out="${1:-$here/build/trinexraft-fresh}"
  shift || true
  echo "building $out (native AOT)..." >&2
  JANET_NO_PROFILE=1 "$bender" --aot "$here/main.janet" --native -o "$out" "$@"
  exit $?
fi

if [[ "${1:-}" == "repl" ]]; then
  shift
  exec "$bender" "$here/dev/repl.janet" "$@"
fi

# Gameplay runs with the implicit profiler OFF.
#
# bender auto-starts the interpreter profiler (for PGO training) unless
# JANET_NO_PROFILE is set. That instrumentation costs real frame time -- on
# this game it is ~7.4 ms/frame against ~5.3 ms without it -- and it is
# profiling data nobody asked for during play. Training wants it; playing
# does not.
#
# An explicit JANET_NO_PROFILE or JANET_PROFILE in the environment always
# wins, so `JANET_PROFILE=1 ./run.sh` still profiles deliberately.
if [[ -z "${JANET_NO_PROFILE:-}" && -z "${JANET_PROFILE:-}" ]]; then
  export JANET_NO_PROFILE=1
fi

exec "$bender" "$here/main.janet" "$@"
