# TrineXraft

*Also written Trinecraft / Trinexcraft — same project, same game. The repo
directory is `trinecraft`; the game is TrineXraft.*

A voxel game engine written in Janet, running on the [`bender`](../../janet)
Janet fork and rendering through raylib — with **no C written anywhere**.
Every raylib call goes through bender's built-in FFI.

> **The Minecraft-like world you can play today is the foundation, not the
> destination.** It exists because TrineXraft needs an editable voxel engine
> underneath it, and that had to be built and measured before anything could
> be layered on. The game is what comes next; this is the ground it stands on.

![Trinecraft](docs/screenshot.png)

Today: fly or walk through generated terrain and break or place blocks, with
chunk streaming, frustum culling and persistence. Next: the enchanted look,
three classes, a simulated history and an AI Dungeon Master.

## Running

```sh
./run.sh                        # launch
./run.sh --screenshot out.png   # headless capture
./run.sh test                   # every test suite, headless
./run.sh repl                   # headless REPL with the engine loaded
./run.sh --uncapped             # no vsync, no 60 FPS cap: true frame cost
```

`run.sh` finds the interpreter via `$BENDER`, then the sibling checkout at
`../../janet/build/bender`, then `bender` on `$PATH`.

Requires **raylib 6.2** (`brew install raylib`). Override its location with
`$TRINECRAFT_RAYLIB` if it is not in a standard prefix.

### Native AOT + PGO release

The game uses `run.sh build`, not a game Makefile. Make builds the sibling
Janet runtime/library; the AOT CLI builds this application. Trailing arguments
are forwarded by `run.sh` to that compiler.

From this directory, train and release to the **same output path and cache**:

```sh
export BENDER="$PWD/../../janet/build/bender"
export XDG_CACHE_HOME="$PWD/build/pgo-cache"
./run.sh build "$PWD/build/trinexraft-pgo" --pgo '--verify-pgo --frames 1500 --uncapped'
./run.sh build "$PWD/build/trinexraft-pgo" --release
JANET_NO_PROFILE=1 ./build/trinexraft-pgo --uncapped
```

`--verify-pgo` uses fixed simulation time and a deterministic streaming schedule,
then checksums the world and geometry. Timing diagnostics go to stderr; raylib
warnings/errors remain visible. The compiler still requires parity: do not
ignore a failed training or release command. Normal play does not enable this
verification mode. Run from the game directory so relative data paths resolve.
Rebuild/retrain after source changes. Release disables automatic profiling and
native telemetry; use a separate trained diagnostic companion for `--work-profile`.

### Controls

| | |
|---|---|
| `WASD` + mouse | move and look |
| `Space` | jump, or ascend when flying |
| `Shift` | sprint |
| `F` | toggle fly / walk |
| `Q` | descend when flying |
| Left click | break block |
| Right click | place block |
| `1`–`4` | select block type |
| `` ` `` / `~` | open the developer console |
| `Esc` | close the console, or quit |

## The developer console

`~` opens a Janet REPL over the **live** game state. `def`s persist between
entries, `print` output is captured, and mutating a value mutates the running
game — `(tp 8 46 8)` moves the camera on the next frame.

```
> (stats)
{:chunks 81 :draws 81 :edits 3 :flying false :fps 56 :pos (8 46 8) :seed 4}
> (set-block 8 45 8 :stone)
> (fill 0 40 0 3 world/block-wood)
343
```

Bound values: `world`, `player`, `drawables`, `mesher`, `material`, `seed`.
Verbs: `help`, `tp`, `where`, `set-block`, `fill`, `regen`, `fly`, `walk`,
`stats`, `blocks`, `show-fps`, `fps`, `clear`.

`(show-fps)` toggles a frame-rate readout that stays visible over the console,
so you can watch the cost of what you type. `(fps)` returns the numbers
without drawing anything. The console inherits `main.janet`'s environment,
so every engine module — `world/`, `worldgen/`, `mesher/`, `player/`,
`raycast/`, `atlas/`, `rl/` — is callable too, not just the injected values.

Line editing, command history (Up/Down, with the half-typed line preserved),
and Page Up/Down scrolling all work. A syntax error, an exception or an
unknown symbol prints to the console and leaves the game running.

**It cannot block the frame loop.** raylib's window and GL context belong to
the main thread, so a conventional stdin REPL would freeze the window. The
console instead evaluates between frames and reads raylib's own key and
character queues.

For work that needs no window:

```sh
./run.sh repl    # same modules, terminal REPL, no GL context
```

## What this is becoming

**TrineXraft**: not "Minecraft with AI-generated quests" but Minecraft with
an evolving fantasy mythology and an AI Dungeon Master, where Trine-like
adventures arise naturally from the world itself.

Three pillars — an editable voxel world (done), a Trine-grade look
(volumetric light, glowing crystals, coloured magic, waterfalls, fog, a
hybrid 2.5D/3D camera, three co-op classes), and a living civilisation of
LLM-driven NPCs with memory, motivation and relationships, coordinated by an
AI Dungeon Master.

The world simulates centuries of its own history first — civilisations,
wars, betrayals, vanished cities — and an LLM narrative director *interprets*
that history into adventures, emitting structured specifications the engine
validates and builds from assets it already owns. The LLM never controls the
game.

NPC behaviour is conventional game AI running continuously; LLMs handle
dialogue and narrative direction only. And the player is never obliged to
engage: ignore the mystery and the world evolves without you.

See `docs/PLAN.md` for the phased route and the measurements behind it.

## Why this exists

`bender` is a Janet fork whose thesis is that a dynamic language can be
compiled ahead of time to competitive native code. Trinecraft is a real-time
workload built to test that claim: meshing, worldgen and raycasting are flat
loops over byte buffers, which is exactly the shape the AOT path is supposed
to lower well.

It is **not** a port of a Minecraft clone. The reference used for formats and
algorithms is [`horizon`](../horizon), a 627k-line vanilla-parity Rust client
and server — far too large to reimplement. Trinecraft borrows its *decisions*,
not its code.

## Architecture

```
bender (Janet)                         libraylib.dylib (C)
  world     chunk store, packed bytes
  worldgen  seeded noise -> block ids
  mesher    blocks -> vertex buffers  --ptr-->  UploadMesh / UpdateMeshBuffer
  player    camera, AABB collision              DrawMesh per visible chunk
  raycast   voxel DDA, break/place    <-------  BeginMode3D / EndMode3D
  atlas     block id + face -> UV rect
```

| Module | Responsibility |
|---|---|
| `src/rl.janet` | The only module permitted to touch `ffi/struct`. Binds the raylib 6.2 surface the engine needs. |
| `src/world.janet` | Chunks of 16x64x16 block ids in a flat byte buffer; `O(1)` index math. |
| `src/worldgen.janet` | Seeded value-noise fBm terrain, continuous across chunk seams. |
| `src/mesher.janet` | Face culling into reusable vertex buffers. The hot path. |
| `src/atlas.janet` | Procedural block texture atlas and cached per-face UV rects. |
| `src/player.janet` | Swept AABB collision resolved per axis, gravity, step-up. |
| `src/raycast.janet` | Amanatides-Woo voxel DDA for targeting. |
| `src/console.janet` | In-game REPL over live state; logic is drawing-free and tested headless. |

**The engine never draws a block.** Per-call FFI overhead forbids it, so
geometry is batched into one uploaded mesh per chunk and the whole visible
world costs ~81 draw calls.

## Measured

All interpreted, on an M-series Mac at 1280x800:

| | |
|---|---|
| Frame | 16.7 ms (59 FPS), 81 draw calls, ~288k vertices |
| Mesher | 8.1 ms/chunk — down from 22.4 ms |
| Worldgen | 8.9 ms/chunk |
| Raycast | 7.7 µs/cast |
| Collision | 0.018 ms/tick |
| Face culling | keeps 1.3% of block faces |

Making these numbers fall under `bender --aot --native` is the point of the
exercise, and is still ahead.

## Three bugs worth knowing about

Each was invisible to the tests that existed when it was written, so each is
now pinned by a test that would have caught it.

**raylib's `Matrix` is row-declared.** `float m0, m4, m8, m12;` is the *first
row*, so translation lives at memory indices 3/7/11 — not 12/13/14, which are
the projective row. Identity is unaffected either way, so a wrong reading
stays hidden until the first non-zero chunk offset, then renders the world as
enormous skewed planes.

**`UnloadMesh` frees your buffers.** raylib calls `free()` on
`mesh.vertices`/`texcoords`/`normals`/`indices`. Those point at Janet buffers
owned by the GC, so unloading a mesh corrupted the heap and aborted the
process. Meshes now unload through a struct copy with the CPU pointers nulled,
leaving raylib to release only the VAO and VBOs it allocated itself.

**The noise hash had no avalanche.** `hash2(seed,0,0)` evaluated to exactly
`270369 * seed`, so coordinates near the origin hashed to near-zero: spawn was
permanently ocean and the seed barely mattered. Uniformity over a large
lattice measured perfectly and concealed it — only probing *small* coordinates
exposed it. Related: fBm that averages its octaves concentrates at the mean
and flattens terrain, so octaves are mapped to [-1,1] before summing.

The lesson encoded in `test/worldgen-test.janet`: **determinism tests cannot
detect degeneracy.** Assert relief, seed sensitivity, avalanche on small
inputs, and land/sea balance.

## Status

Done: raylib 3D bindings, chunk store, worldgen, face-culling mesher, texture
atlas, player physics and collision, block break/place with incremental
re-meshing.

Next: frame budget and render distance (chunk streaming, frustum culling,
amortised uploads, GC pause measurement), persistence, and the AOT/native
comparison. See `docs/PLAN.md`.
