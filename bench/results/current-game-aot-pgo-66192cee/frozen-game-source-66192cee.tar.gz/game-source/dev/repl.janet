# Headless Trinecraft REPL.
#
# The same bindings the in-game `~` console exposes, but in a terminal and
# with no window. Use this for work that does not need to see the world:
# probing worldgen, benchmarking the mesher, checking chunk contents.
#
# Run: ./run.sh repl
#
# The in-game console is the tool for inspecting a world you are looking at;
# this is the tool for inspecting one you are reasoning about.

(import ../src/rl :as rl)
(import ../src/world :as world)
(import ../src/worldgen :as worldgen)
(import ../src/mesher :as mesher)
(import ../src/atlas :as atlas)
(import ../src/player :as player)
(import ../src/raycast :as raycast)
(import ../src/console :as console)
(import ../src/region :as region)
(import ../src/palette :as palette)
(import ../src/stream :as stream)
(import ../src/frustum :as frustum)

(def seed 4)
(def radius 2)

(defn build
  "Generate a small world so there is something to poke at immediately."
  [&opt r s]
  (default r radius)
  (default s seed)
  (def w (world/world-new))
  (put w :seed s)
  (for cz (- r) (+ r 1)
    (for cx (- r) (+ r 1)
      (worldgen/generate-chunk w cx cz s)))
  w)

(def world-instance (build))
(def mesher-instance (mesher/mesher-new))
(def player-instance (player/player-new 0.5 40 0.5))
(player/drop-to-ground player-instance world-instance)

(defn stats []
  {:chunks (world/world-chunk-count world-instance)
   :seed seed
   :player (tuple ;(player-instance :pos))})

(defn mesh-one
  "Mesh one chunk and report its geometry, for quick benchmarking."
  [&opt cx cz]
  (default cx 0)
  (default cz 0)
  (def ch (world/world-get-chunk world-instance cx cz))
  (unless ch (error (string "no chunk at " cx "," cz)))
  (def t0 (os/clock))
  (def geo (mesher/mesh-chunk mesher-instance ch world-instance atlas/face-uv))
  (def ms (* 1000 (- (os/clock) t0)))
  (if geo
    {:faces (geo :face-count) :vertices (geo :vertex-count) :ms ms}
    {:faces 0 :ms ms}))

(defn column
  "The block ids of one world column, bottom to top."
  [wx wz]
  (def out @[])
  (for y 0 world/chunk-y
    (array/push out (world/world-get-block world-instance wx y wz)))
  out)

(defn surface
  "Height of the highest non-air block at these world coords."
  [wx wz]
  (var h -1)
  (for y 0 world/chunk-y
    (when (not= world/block-air (world/world-get-block world-instance wx y wz))
      (set h y)))
  h)

(defn help []
  (print "Trinecraft headless REPL")
  (print "  world-instance   the generated world      (world/ ... functions)")
  (print "  player-instance  a player on its surface  (player/ ...)")
  (print "  mesher-instance  reusable mesher          (mesher/ ...)")
  (print "  (build r s)      generate another world")
  (print "  (stats)          world summary")
  (print "  (mesh-one cx cz) mesh a chunk and time it")
  (print "  (column x z)     block ids up one column")
  (print "  (surface x z)    terrain height at x,z")
  (print "  modules: world/ worldgen/ mesher/ atlas/ player/ raycast/ rl/")
  (print "           region/ palette/ stream/ frustum/")
  (print "  (region/save-world path w) / (region/load-world path)")
  (print "  note: rl/ is loaded but no window exists; do not call draw verbs.")
  :ok)

(defn main [&]
  (help)
  (printf "\nready: %d chunks, seed %d\n"
          (world/world-chunk-count world-instance) seed)
  # repl takes the env to evaluate in; passing this module's env is what makes
  # every import above reachable from the prompt.
  (repl nil nil (curenv)))
