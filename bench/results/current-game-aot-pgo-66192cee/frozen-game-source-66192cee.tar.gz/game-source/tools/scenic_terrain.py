"""Scenic terrain: one offline, whole-map artifact with a taller height band.

The streaming TDH2 cache quantizes to a fixed 4..60 band at 50 metres per voxel.
That is right for an explorable world served incrementally, and wrong for a single
hand-picked scenic map: on the real spawn the measured cache clamps 42 % of its
voxels at the ceiling, so the two thirds of the world above 1600 m all render as
one altitude.

This module keeps the two products separate on purpose.

``TDH2`` stays exactly as it is -- 4..60, 50 m/voxel, byte-compatible, and every
existing cache keeps working untouched.

``TDS3`` (SCENIC FORMAT 3) is a new artifact for one map:

* the tile is still 308 bytes and the payload is still 256 one-byte heights, so
  nothing about the wire geometry had to change -- only the *band* is wider;
* the magic is ``TDS3``, not ``TDH2``, so a reader that predates this format
  rejects it at the magic check AND at the manifest key-set check. There is no
  path by which an old reader silently interprets scenic heights as TDH2;
* the band is ``4..252`` rather than ``4..255``: 253..255 stay reserved so a
  future band can widen without ambiguity, and 252 leaves headroom under the
  engine's 256-block column;
* the elevation transfer is a fixed global affine declared in the manifest --
  ``meters_per_voxel``, ``baseline_elevation_m``, ``sea_level`` -- never a
  per-tile or per-window statistic. Every column quantizes identically no matter
  which tile asks for it, which is the same guarantee TDH2 makes.

Raw elevations are exported before quantization, because a quantized cache cannot
report the true range: a voxel pinned at the ceiling only proves "at least this
high". ``export_raw`` writes float32 metres plus provenance; ``import_raw``
chooses the scale once, from the whole map's statistics, and bakes every tile with
that single transfer.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import struct
import zlib

import terrain_cache as tc

#: Scenic wire magic. Deliberately not TDH2: an old reader must fail closed.
SCENIC_MAGIC = b"TDS3"

#: Scenic format version, carried in the manifest and required by readers here.
SCENIC_FORMAT = 3

#: A scenic map is a fixed column range. 253..255 stay reserved.
SCENIC_HEIGHT_MIN = 4
SCENIC_HEIGHT_MAX = 252
SCENIC_RESERVED_TOP = 255

#: The tile envelope is unchanged from TDH2 -- same header struct, same payload.
SCENIC_HEADER_STRUCT = struct.Struct("<4siiII32s")
SCENIC_TILE_BYTES = SCENIC_HEADER_STRUCT.size + tc.TILE_PAYLOAD_SIZE

MANIFEST_NAME = "manifest.json"
RAW_META_NAME = "scenic.json"
PROVENANCE_NAME = "provenance.json"

#: Required keys in a scenic manifest. The Janet gate compares the key COUNT, so
#: this set must never alias TDH2's six-key manifest.
#: The EXACT key set the Janet reader requires (src/terrain-cache.janet
#: `scenic-manifest-keys`). It compares the key COUNT, so this must match one for
#: one: 12 keys, and the JSON map record is bound by size + CRC-32 rather than
#: being parsed there.
SCENIC_MANIFEST_KEYS = (
    "format",
    "magic",
    "identity",
    "seed",
    "payload-bytes",
    "tile-bytes",
    "height-min",
    "height-max",
    "bounds",
    "origin",
    "json-crc32",
    "json-bytes",
)

#: The map record itself, CRC-bound by the twin. Janet does not parse this; it
#: carries everything a human or the importer needs. The reader's binding path is
#: `provenance.json` (src/terrain-cache.janet `scenic-json-path`), so the record
#: IS the provenance file -- one file, not two that could disagree.
SCENIC_JSON_NAME = "provenance.json"

#: Hard cap enforced by the Janet reader.
SCENIC_JSON_MAX_BYTES = 65536


class ScenicError(RuntimeError):
    """A scenic artifact is inconsistent, unprovenanced, or out of band."""


# ---------------------------------------------------------------------------
# Climate container: one optional grid beside the tiles
# ---------------------------------------------------------------------------

#: The climate container's own version. This is the CONTAINER format version,
#: NOT a surface/biome policy version and NOT evidence that a policy ships:
#: nothing in this module classifies a biome, and no reader attaches climate from
#: this file on its own. It exists so a later, explicitly approved revision can
#: say "I understand this layout" instead of guessing.
CLIMATE_CONTAINER_VERSION = 1

#: File written beside the tiles when the producer supplied climate. One flat
#: little-endian float32 buffer, row-major, channel-last -- exactly the bytes
#: ``src/climate-tile.janet`` reads as ``[h w 5]``. No Python is needed to load
#: it; no container format of another language is involved.
CLIMATE_NAME = "climate.f32"

#: The channel contract, copied from `src/climate-tile.janet` `channels` so the
#: record is self-describing. Channel 4 is the LAPSE-RATE coefficient, NOT
#: humidity. ``:basis :source-derived`` says the DIMENSIONS follow from the
#: pinned upstream source; it does NOT say a sample was ever checked against a
#: real range, so these units are not calibration.
CLIMATE_CHANNELS = (
    "temperature",
    "temperature-seasonality",
    "precipitation",
    "precipitation-variability",
    "lapse-rate",
)
CLIMATE_CHANNEL_COUNT = len(CLIMATE_CHANNELS)
CLIMATE_UNITS = {
    "temperature": "degrees C, elevation-adjusted mean",
    "temperature-seasonality": "degrees C, standard deviation",
    "precipitation": "millimetres per year",
    "precipitation-variability": "coefficient of variation, percent",
    "lapse-rate": "degrees C per metre",
}


def climate_projection(*, source_grid, artifact_grid, world_origin_voxels):
    """The source→artifact mapping, recorded rather than assumed.

    Elevation is upsampled with an ENDPOINT-PRESERVING bilinear transform
    (``resample_bilinear``), whose step is ``(n-1)/(n*factor-1)`` source samples
    per output pixel. Climate is NOT resampled here: it is emitted on its own
    cell grid, addressed by ``:scale``. Those two are different coordinate
    semantics, so this function only records the integers and refuses when the
    artifact grid is not an exact integer multiple of the source grid -- an
    unprojectable climate is a refusal, never an implicit resize.
    """
    import numpy as np  # noqa: F401  (parity with the rest of the module)

    src_h, src_w = int(source_grid[0]), int(source_grid[1])
    art_h, art_w = int(artifact_grid[0]), int(artifact_grid[1])
    if min(src_h, src_w, art_h, art_w) <= 0:
        raise ScenicError("climate grids must be positive")
    if art_h % src_h or art_w % src_w:
        raise ScenicError(
            "artifact grid %dx%d is not an integer multiple of the source grid "
            "%dx%d; an unprojectable climate is refused rather than resampled"
            % (art_w, art_h, src_w, src_h)
        )
    scale_h = art_h // src_h
    scale_w = art_w // src_w
    if scale_h != scale_w:
        raise ScenicError(
            "climate projection needs one integer scale, got %d rows and %d "
            "columns" % (scale_h, scale_w)
        )
    origin = [int(v) for v in world_origin_voxels]
    if len(origin) != 2:
        raise ScenicError("world origin must hold two integers")
    return {
        "source-grid": [src_h, src_w],
        "artifact-grid": [art_h, art_w],
        "scale": int(scale_h),
        # The world column of climate sample (0,0): the artifact's own chunk-min
        # corner, not the model's sampling origin.
        "origin": origin,
        "semantics": "cell-grid",
    }


def climate_record(*, shape, projection):
    """The `climate` block of the CRC-bound provenance record.

    Everything a loader needs to validate the buffer WITHOUT opening the npz or
    running Python: the file, its shape, its dtype, the projection that maps it
    onto the world, and the digest/CRC of the exact payload bytes.
    """
    height, width, channels = (int(shape[0]), int(shape[1]), int(shape[2]))
    if channels != CLIMATE_CHANNEL_COUNT:
        raise ScenicError(
            "climate must carry %d channels, got %d"
            % (CLIMATE_CHANNEL_COUNT, channels)
        )
    return {
        "container": "flat-f32-le",
        "container-version": CLIMATE_CONTAINER_VERSION,
        "file": CLIMATE_NAME,
        "shape": [height, width, channels],
        "dtype": "f32<",
        "order": "row-major, channel-last (x fastest within a row)",
        "bytes": height * width * channels * 4,
        "channels": list(CLIMATE_CHANNELS),
        "units": dict(CLIMATE_UNITS),
        # The DIMENSIONS follow from pinned source; no sample has been measured
        # against a real range, so no threshold here is calibrated.
        "basis": "source-derived",
        "calibrated": False,
        "projection": dict(projection),
    }


def validate_climate(climate, *, rows, cols):
    """Validate ``(H, W, 5)`` climate against the elevation grid, or refuse.

    Runs BEFORE anything is written, so a bad array cannot produce an artifact
    that merely lacks climate, and cannot produce one that fails later with the
    tiles already on disk.
    """
    import numpy as np

    values = np.asarray(climate)
    if values.ndim != 3:
        raise ScenicError(
            "climate must be a 3-D (height, width, %d) array, got %d dimensions"
            % (CLIMATE_CHANNEL_COUNT, values.ndim)
        )
    if values.shape[2] != CLIMATE_CHANNEL_COUNT:
        raise ScenicError(
            "climate has %d channels, expected %d"
            % (values.shape[2], CLIMATE_CHANNEL_COUNT)
        )
    if values.shape[:2] != (rows, cols):
        raise ScenicError(
            "climate grid %dx%d does not match the elevation grid %dx%d"
            % (values.shape[0], values.shape[1], rows, cols)
        )
    if values.dtype.kind not in "fiu":
        raise ScenicError(
            "climate must be numeric, got dtype %s" % values.dtype
        )
    floats = values.astype("<f4", copy=False)
    if not np.isfinite(floats).all():
        raise ScenicError("climate contains non-finite samples")
    return floats


def write_climate_payload(directory, climate, *, rows, cols):
    """Write the validated climate bytes and return the record describing them.

    Little-endian float32, row-major, channel-last. The digest and CRC are over
    the EXACT bytes written, so a loader can verify the file it reads without
    trusting the npz it came from.
    """
    floats = validate_climate(climate, rows=rows, cols=cols)
    payload = floats.astype("<f4", copy=False).tobytes(order="C")
    expected = rows * cols * CLIMATE_CHANNEL_COUNT * 4
    if len(payload) != expected:
        raise ScenicError(
            "climate payload is %d bytes, expected %d" % (len(payload), expected)
        )
    path = os.path.join(directory, CLIMATE_NAME)
    with open(path, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    with open(path, "rb") as handle:
        written = handle.read()
    if written != payload:
        raise ScenicError("climate payload read back differs from what was written")
    return {
        "payload": payload,
        "sha256": hashlib.sha256(payload).hexdigest(),
        "crc32": zlib.crc32(payload) & 0xFFFFFFFF,
    }


# ---------------------------------------------------------------------------
# The fixed global transfer
# ---------------------------------------------------------------------------


def scenic_mapping(*, meters_per_voxel, sea_level, baseline_elevation_m=0.0,
                   height_min=SCENIC_HEIGHT_MIN, height_max=SCENIC_HEIGHT_MAX):
    """Build the one transfer every tile of a scenic map shares.

    ``meters_per_voxel`` is chosen once, after the raw export's statistics are
    known, and is then fixed for the whole map. It is never recomputed per tile:
    a local statistic would make a column's height depend on its neighbours, which
    is exactly the request-dependent behaviour the windowed cache exists to avoid.
    """
    if not isinstance(meters_per_voxel, (int, float)) or isinstance(
        meters_per_voxel, bool
    ):
        raise ScenicError("meters_per_voxel must be a number")
    meters = float(meters_per_voxel)
    if not math.isfinite(meters) or meters <= 0:
        raise ScenicError("meters_per_voxel must be finite and positive")
    if not SCENIC_HEIGHT_MIN <= height_min <= height_max <= SCENIC_HEIGHT_MAX:
        raise ScenicError(
            "scenic band must satisfy %d <= min <= max <= %d"
            % (SCENIC_HEIGHT_MIN, SCENIC_HEIGHT_MAX)
        )
    mapping = tc.HeightMapping(
        meters_per_voxel=meters,
        sea_level=int(sea_level),
        baseline_elevation_m=float(baseline_elevation_m),
        height_min=int(height_min),
        height_max=int(height_max),
    )
    return mapping


def mapping_record(mapping, *, profile):
    """The manifest's ``:mapping`` block: the transfer plus its provenance."""
    return {
        "meters_per_voxel": mapping.meters_per_voxel,
        "sea_level": mapping.sea_level,
        "baseline_elevation_m": mapping.baseline_elevation_m,
        "height_min": mapping.height_min,
        "height_max": mapping.height_max,
        "profile": profile,
        "sampling": "offline-import",
    }


# ---------------------------------------------------------------------------
# Raw export
# ---------------------------------------------------------------------------


def export_raw(
    destination,
    elevation_m,
    *,
    origin_pixels,
    seed,
    pixels_per_voxel=1,
    provenance=None,
    climate=None,
):
    """Save raw float32 elevations plus provenance, before any quantization.

    ``elevation_m`` is a 2-D sequence of metres as the model produced them. It is
    stored unquantized and unclamped so a later import can choose a scale from the
    real range instead of guessing from a clipped cache.
    """
    import numpy as np

    values = np.asarray(elevation_m, dtype=np.float32)
    if values.ndim != 2:
        raise ScenicError("elevation must be a 2-D array")
    if not np.isfinite(values).all():
        raise ScenicError("elevation contains non-finite samples")
    origin = tuple(int(v) for v in origin_pixels)
    if len(origin) != 2:
        raise ScenicError("origin_pixels must hold two integers")

    arrays = {
        "elevation_m": values,
        "origin_pixels": np.asarray(origin, dtype=np.int64),
        "seed": np.asarray([int(seed)], dtype=np.int64),
        "pixels_per_voxel": np.asarray([int(pixels_per_voxel)], dtype=np.int64),
    }
    if climate is not None:
        # ONE validation boundary for climate, shared with the importer that
        # writes the container: 3-D, channel-last, exactly five channels, the
        # elevation grid's own shape, numeric, finite. Upstream's (5, H, W)
        # layout is refused here rather than transposed on the caller's behalf.
        arrays["climate"] = validate_climate(
            climate, rows=values.shape[0], cols=values.shape[1]
        )

    os.makedirs(os.path.dirname(os.path.abspath(destination)) or ".", exist_ok=True)
    np.savez_compressed(destination, **arrays)
    with open(destination, "rb") as handle:
        raw_sha = hashlib.sha256(handle.read()).hexdigest()

    meta = {
        "source": "scenic-raw-export",
        "format": SCENIC_FORMAT,
        "raw_sha256": raw_sha,
        "origin_pixels": list(origin),
        "seed": int(seed),
        "pixels_per_voxel": int(pixels_per_voxel),
        "width": int(values.shape[1]),
        "height": int(values.shape[0]),
        "elevation_min_m": float(values.min()),
        "elevation_max_m": float(values.max()),
        "elevation_mean_m": float(values.mean()),
        "quantized": False,
        "has_climate": climate is not None,
        "provenance": provenance or {},
    }
    meta_path = os.path.splitext(destination)[0] + ".json"
    with open(meta_path, "w") as handle:
        json.dump(meta, handle, indent=2, sort_keys=True)
    return meta


GRID_TRANSFORM_IDENTITY = "identity"
GRID_TRANSFORM_BILINEAR = "bilinear"


def resample_to_shape(elevation_m, target_shape):
    """Resample to an exact output shape, preserving both endpoints.

    Sample ``i`` of ``N`` maps to source coordinate ``i * (n-1)/(N-1)``, so the
    first and last source samples land exactly on the first and last output
    samples and the output spans the identical world rectangle. For 128 -> 512
    that is a 127-sample source span spread over 511 intervals.

    This invents no detail: interior values are linear blends of the two real
    neighbouring samples.
    """
    import numpy as np

    values = np.asarray(elevation_m, dtype=np.float32)
    if values.ndim != 2:
        raise ScenicError("elevation must be a 2-D array")
    rows, cols = values.shape
    out_rows, out_cols = int(target_shape[0]), int(target_shape[1])
    if out_rows < 2 or out_cols < 2:
        raise ScenicError("target shape must be at least 2x2")
    ys = np.linspace(0.0, rows - 1, out_rows)
    xs = np.linspace(0.0, cols - 1, out_cols)
    y0 = np.floor(ys).astype(np.int64)
    x0 = np.floor(xs).astype(np.int64)
    y1 = np.clip(y0 + 1, 0, rows - 1)
    x1 = np.clip(x0 + 1, 0, cols - 1)
    wy = (ys - y0).reshape(-1, 1)
    wx = (xs - x0).reshape(1, -1)
    top = values[np.ix_(y0, x0)] * (1 - wx) + values[np.ix_(y0, x1)] * wx
    bottom = values[np.ix_(y1, x0)] * (1 - wx) + values[np.ix_(y1, x1)] * wx
    return (top * (1 - wy) + bottom * wy).astype(np.float32)


def resample_bilinear(elevation_m, factor):
    """Upsample a grid by an integer factor with endpoint-preserving bilinear.

    ``source[0]`` maps exactly to ``out[0]`` and ``source[-1]`` to ``out[-1]``, so
    the output spans the same world rectangle as the input -- the step is
    ``(n-1)/(n*factor-1)`` source pixels, not ``1/factor``. That is deliberate: a
    divisor-based scale would shift the far edge and silently move the map.

    This invents no detail. Between samples the output is a linear blend of the
    two neighbouring real samples, which is recorded in the artifact metadata so
    nobody mistakes a 128-sample watershed for a 512-sample one.
    """
    import numpy as np

    values = np.asarray(elevation_m, dtype=np.float32)
    if values.ndim != 2:
        raise ScenicError("elevation must be a 2-D array")
    if not isinstance(factor, int) or isinstance(factor, bool) or factor < 1:
        raise ScenicError("resample factor must be a positive integer")
    if factor == 1:
        return values.copy()
    rows, cols = values.shape
    out_rows = (rows - 1) * factor + 1
    out_cols = (cols - 1) * factor + 1
    # Endpoint-preserving positions: index i maps to i/factor in source space,
    # so out[-1] == (rows-1) exactly.
    ys = np.arange(out_rows, dtype=np.float64) / factor
    xs = np.arange(out_cols, dtype=np.float64) / factor
    y0 = np.floor(ys).astype(np.int64)
    x0 = np.floor(xs).astype(np.int64)
    y1 = np.clip(y0 + 1, 0, rows - 1)
    x1 = np.clip(x0 + 1, 0, cols - 1)
    wy = (ys - y0).reshape(-1, 1)
    wx = (xs - x0).reshape(1, -1)
    top = values[np.ix_(y0, x0)] * (1 - wx) + values[np.ix_(y0, x1)] * wx
    bottom = values[np.ix_(y1, x0)] * (1 - wx) + values[np.ix_(y1, x1)] * wx
    return (top * (1 - wy) + bottom * wy).astype(np.float32)


def adopt_raw(source_path, destination, *, target_shape=None, factor=None,
               provenance):
    """Re-export a scout artifact through the verified export path.

    The scout that produced real data predates :func:`export_raw`, so its
    metadata used different field names and carried no interpolation record. This
    reads the arrays it actually contains, resamples if asked, and writes a fresh
    export with a digest computed HERE -- it never copies a claim it cannot
    re-verify, and it never invents model metadata (``provenance`` is whatever the
    caller can honestly assert, recorded verbatim).
    """
    import numpy as np

    meta_path = os.path.splitext(source_path)[0] + ".json"
    if not os.path.isfile(meta_path):
        raise ScenicError("source artifact has no metadata: %s" % meta_path)
    with open(meta_path) as handle:
        source_meta = json.load(handle)
    # Verify the bytes against whatever digest the source recorded, under either
    # key. An unverified source must never be adopted, or the new artifact would
    # inherit provenance nobody checked.
    with open(source_path, "rb") as handle:
        actual = hashlib.sha256(handle.read()).hexdigest()
    recorded = source_meta.get("raw_sha256") or source_meta.get("npz_sha256")
    if not recorded:
        raise ScenicError("source artifact records no digest to verify")
    if actual != recorded:
        raise ScenicError(
            "source artifact digest does not match its metadata; refusing to "
            "adopt unverified data"
        )
    with np.load(source_path) as loaded:
        elevation = np.asarray(loaded["elevation_m"], dtype=np.float32)
        origin = [int(v) for v in loaded["origin_pixels"]]
        seed = int(loaded["seed"][0])
        ppv = int(loaded["pixels_per_voxel"][0])
        # Climate travels with the elevation it was sampled alongside. Reading it
        # here and re-emitting it through `export_raw` is a COPY of verified
        # bytes, not new data: no model runs, nothing is resampled or
        # interpolated, and the channel-last layout the exporter uses is exactly
        # the layout the source carries.
        source_climate = (
            np.asarray(loaded["climate"], dtype=np.float32)
            if "climate" in loaded.files else None
        )
    if not np.isfinite(elevation).all():
        raise ScenicError("source elevation contains non-finite samples")

    # The source's own flag and its array must agree before either is adopted; an
    # inconsistent source is refused rather than silently shedding its climate.
    source_has_climate = bool(source_meta.get("has_climate", False))
    if source_has_climate and source_climate is None:
        raise ScenicError(
            "source artifact records has_climate but carries no 'climate' array"
        )
    if source_climate is not None and not source_has_climate:
        raise ScenicError(
            "source artifact carries a 'climate' array but its metadata says "
            "has_climate is false"
        )
    if source_climate is not None:
        # Validation happens BEFORE any resampling, so a corrupt source cannot
        # reach the destination looking merely absent, and no destination file is
        # opened for a source that would have been refused.
        source_climate = validate_climate(
            source_climate,
            rows=int(elevation.shape[0]), cols=int(elevation.shape[1]),
        )

    source_shape = list(elevation.shape)
    if target_shape is not None:
        elevation = resample_to_shape(elevation, target_shape)
        grid_transform = {
            "operation": GRID_TRANSFORM_BILINEAR,
            "mode": "target-shape",
            "source_shape": source_shape,
            "output_shape": list(elevation.shape),
            "source_span_pixels": [source_shape[0] - 1, source_shape[1] - 1],
            "output_span_blocks": [elevation.shape[0] - 1, elevation.shape[1] - 1],
            "endpoint_preserving": True,
            "invents_detail": False,
            "note": "first and last source samples land on the first and last "
                    "output samples, so the output spans the identical world "
                    "rectangle; interior samples are linear blends of real "
                    "neighbours, not new model output",
        }
    elif factor is not None and factor != 1:
        elevation = resample_bilinear(elevation, factor)
        grid_transform = {
            "operation": GRID_TRANSFORM_BILINEAR,
            "mode": "integer-factor",
            "factor": int(factor),
            "source_shape": source_shape,
            "output_shape": list(elevation.shape),
            "endpoint_preserving": True,
            "invents_detail": False,
            "note": "output spans the same world rectangle; interior samples are "
                    "linear blends of real neighbours, not new model output",
        }
    else:
        grid_transform = {
            "operation": GRID_TRANSFORM_IDENTITY,
            "factor": 1,
            "source_shape": source_shape,
            "output_shape": source_shape,
            "endpoint_preserving": True,
            "invents_detail": False,
            "note": "copied unchanged from the sampled grid",
        }

    record = dict(provenance)
    record["adopted_from"] = {
        "path": os.path.basename(source_path),
        "source": source_meta.get("source"),
        "source_metadata": source_meta,
    }
    record["grid_transform"] = grid_transform

    # A resampled elevation no longer shares the source's grid, and climate is
    # carried through UNCHANGED -- it is never resampled or interpolated here.
    # Rather than drop the array or stretch it, a resample of a climate-bearing
    # source is refused: a caller that wants climate at another resolution can
    # re-sample it deliberately at the producer.
    if source_climate is not None and list(elevation.shape) != source_shape:
        raise ScenicError(
            "refusing to resample a climate-bearing source from %dx%d to %dx%d: "
            "climate is carried through unchanged and would no longer share the "
            "elevation grid"
            % (source_shape[0], source_shape[1],
               elevation.shape[0], elevation.shape[1])
        )

    # Never overwrite an artifact or export that already exists: this path writes
    # a NEW raw export at a caller-chosen path, and silently replacing one a
    # loader may be reading is not a recoverable operation.
    for existing in (destination, os.path.splitext(destination)[0] + ".json"):
        if os.path.exists(existing):
            raise ScenicError(
                "refusing to overwrite existing %s; adopt_raw writes a new export"
                % existing
            )

    return export_raw(
        destination,
        elevation,
        origin_pixels=origin,
        seed=seed,
        pixels_per_voxel=ppv,
        provenance=record,
        climate=source_climate,
    )


def read_raw(path):
    """Load a raw export and its metadata, verifying the recorded digest."""
    import numpy as np

    meta_path = os.path.splitext(path)[0] + ".json"
    if not os.path.isfile(meta_path):
        raise ScenicError("raw export is missing its metadata: %s" % meta_path)
    with open(meta_path) as handle:
        meta = json.load(handle)
    if meta.get("quantized"):
        raise ScenicError(
            "raw export is flagged quantized; a scenic scale must be chosen from "
            "unquantized metres"
        )
    with open(path, "rb") as handle:
        digest = hashlib.sha256(handle.read()).hexdigest()
    # A scout written before this module used `npz_sha256`. Accept either key so
    # real data is not refused over a field name, but still verify the bytes.
    recorded = meta.get("raw_sha256") or meta.get("npz_sha256")
    if not recorded:
        raise ScenicError("raw export records no digest to verify")
    if digest != recorded:
        raise ScenicError("raw export digest does not match its metadata")
    with np.load(path) as loaded:
        arrays = {name: loaded[name] for name in loaded.files}
    elevation = arrays["elevation_m"]
    if not np.isfinite(elevation).all():
        raise ScenicError("raw elevation contains non-finite samples")
    return arrays, meta


# ---------------------------------------------------------------------------
# Scenic cache: manifest + tiles
# ---------------------------------------------------------------------------


def _canonical_json(value):
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def scenic_identity_digest(descriptor):
    """The scenic identity: the whole descriptor, mapping included.

    Because the mapping is hashed, choosing a different scale is a *different
    artifact* rather than a reinterpretation of an existing one.
    """
    record = descriptor.get("mapping")
    if not isinstance(record, dict):
        raise ScenicError("scenic identity has no mapping block")
    return hashlib.sha256(_canonical_json(descriptor)).hexdigest()


def _bounds_record(map_bounds):
    """Inclusive chunk bounds as the Janet reader's four-element vector.

    ``bounds`` is ``[cx0 cz0 cx1 cz1]`` half-open in this module's own map_bounds
    (chunk_max is exclusive), and INCLUSIVE for the reader -- so the upper value
    written is ``chunk_max - 1``.
    """
    cx0, cz0 = map_bounds["chunk_min"]
    cx1, cz1 = map_bounds["chunk_max"]
    return [int(cx0), int(cz0), int(cx1) - 1, int(cz1) - 1]


def scenic_manifest(descriptor, *, digest, map_bounds, profile, raw_sha256,
                    json_bytes, json_crc32):
    """The immutable format-3 manifest, keyed EXACTLY as the Janet reader wants."""
    mapping = descriptor["mapping"]
    return {
        "format": SCENIC_FORMAT,
        "magic": "TDS3",
        "identity": digest,
        "seed": int(descriptor["seed"]),
        "payload-bytes": tc.TILE_PAYLOAD_SIZE,
        "tile-bytes": SCENIC_TILE_BYTES,
        "height-min": int(mapping["height_min"]),
        "height-max": int(mapping["height_max"]),
        "bounds": _bounds_record(map_bounds),
        "origin": [int(v) for v in descriptor["origin_voxels"]],
        "json-crc32": int(json_crc32),
        "json-bytes": int(json_bytes),
    }


def scenic_map_record(descriptor, *, map_bounds, profile, raw_sha256, mapping):
    """The CRC-bound map record. Janet never parses this; it is for humans."""
    return {
        "format": SCENIC_FORMAT,
        "magic": "TDS3",
        "profile": profile,
        "seed": int(descriptor["seed"]),
        "origin_voxels": [int(v) for v in descriptor["origin_voxels"]],
        "origin_pixels": [int(v) for v in descriptor["origin_pixels"]],
        "bounds_inclusive": _bounds_record(map_bounds),
        "chunks": [map_bounds["chunks_x"], map_bounds["chunks_z"]],
        "pixels": [map_bounds["width_pixels"], map_bounds["height_pixels"]],
        "mapping": mapping_record(mapping, profile=profile),
        "raw_sha256": raw_sha256,
        "pixels_per_voxel": int(descriptor["pixels_per_voxel"]),
        "elevation_width": map_bounds["width_pixels"],
        "elevation_height": map_bounds["height_pixels"],
        "vertical_unit": "voxels above baseline; world Y == height",
        "sea_level_voxel": int(mapping.sea_level),
        "provenance": descriptor.get("provenance", {}),
        "grid_transform": descriptor.get("grid_transform", {}),
    }


def write_scenic_identity(cache_root, descriptor, *, map_bounds, profile,
                          raw_sha256, mapping, climate=None):
    """Create the scenic identity directory, its twin and its CRC-bound record.

    ``climate`` is an optional validated ``(H, W, 5)`` array. When present, its
    payload is written into the identity directory BEFORE the manifest that
    publishes that identity, and its contract is embedded in the CRC-bound map
    record -- the ONE place a loader reads the container's contract from. The
    twin's twelve keys never change, so an old reader keeps working and an old
    artifact keeps its identity byte for byte.
    """
    digest = scenic_identity_digest(descriptor)
    directory = os.path.join(os.fspath(cache_root), digest)
    os.makedirs(directory, exist_ok=True)

    record = scenic_map_record(
        descriptor, map_bounds=map_bounds, profile=profile,
        raw_sha256=raw_sha256, mapping=mapping,
    )
    if climate is not None:
        # Payload first: the record below binds its exact bytes, so the file must
        # already exist when the manifest publishes this identity.
        payload = write_climate_payload(
            directory, climate,
            rows=map_bounds["height_pixels"], cols=map_bounds["width_pixels"],
        )
        projection = climate_projection(
            source_grid=climate.shape[:2],
            artifact_grid=(map_bounds["height_pixels"],
                           map_bounds["width_pixels"]),
            world_origin_voxels=descriptor["origin_voxels"],
        )
        record["climate"] = dict(
            climate_record(shape=climate.shape, projection=projection),
            **{"sha256": payload["sha256"], "crc32": payload["crc32"]},
        )
    # Canonical bytes, because the twin binds this file's exact size and CRC-32.
    record_bytes = _canonical_json(record) + b"\n"
    if len(record_bytes) > SCENIC_JSON_MAX_BYTES:
        raise ScenicError(
            "map record is %d bytes, over the %d byte cap the reader enforces"
            % (len(record_bytes), SCENIC_JSON_MAX_BYTES)
        )
    json_crc32 = zlib.crc32(record_bytes) & 0xFFFFFFFF

    manifest = scenic_manifest(
        descriptor, digest=digest, map_bounds=map_bounds, profile=profile,
        raw_sha256=raw_sha256, json_bytes=len(record_bytes),
        json_crc32=json_crc32,
    )
    path = os.path.join(directory, MANIFEST_NAME)
    data = _canonical_json(manifest)
    if os.path.exists(path):
        with open(path, "rb") as handle:
            existing = handle.read()
        if existing != data:
            raise ScenicError(
                "scenic identity %s already exists with a different manifest"
                % digest
            )
        return digest, directory

    with open(os.path.join(directory, SCENIC_JSON_NAME), "wb") as handle:
        handle.write(record_bytes)

    temp = path + ".tmp-%d" % os.getpid()
    with open(temp, "wb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp, path)

    bounds = manifest["bounds"]
    origin = manifest["origin"]
    twin = (
        '{:format %d :magic "TDS3" :identity "%s" :seed %d '
        ":payload-bytes %d :tile-bytes %d :height-min %d :height-max %d "
        ":bounds [%d %d %d %d] :origin [%d %d] :json-crc32 %d :json-bytes %d}\n"
        % (
            SCENIC_FORMAT,
            digest,
            manifest["seed"],
            tc.TILE_PAYLOAD_SIZE,
            SCENIC_TILE_BYTES,
            manifest["height-min"],
            manifest["height-max"],
            bounds[0], bounds[1], bounds[2], bounds[3],
            origin[0], origin[1],
            json_crc32,
            len(record_bytes),
        )
    )
    with open(os.path.join(directory, "manifest.janet"), "w") as handle:
        handle.write(twin)
    os.makedirs(os.path.join(directory, tc.TILE_DIR_NAME), exist_ok=True)
    return digest, directory


def read_scenic_manifest(cache_root, digest):
    """Read and validate a format-3 manifest. Mirrors the Janet reader's rules.

    Deliberately checks the same things in the same spirit: exact key set, format
    and magic, a band inside the TDS3 profile, and the map record bound by its
    exact size and CRC-32. A TDH2 manifest cannot pass any of these.
    """
    if not isinstance(digest, str) or len(digest) != 64:
        raise ScenicError("identity must be 64 hex characters")
    directory = os.path.join(os.fspath(cache_root), digest)
    path = os.path.join(directory, MANIFEST_NAME)
    if not os.path.isfile(path):
        raise ScenicError("no scenic manifest at %s" % path)
    with open(path, "rb") as handle:
        record = json.loads(handle.read().decode("utf-8"))
    if record.get("format") != SCENIC_FORMAT:
        raise ScenicError(
            "format %r is not scenic format %d"
            % (record.get("format"), SCENIC_FORMAT)
        )
    if record.get("magic") != "TDS3":
        raise ScenicError("scenic manifest magic must be TDS3")
    if set(record) != set(SCENIC_MANIFEST_KEYS):
        missing = sorted(set(SCENIC_MANIFEST_KEYS) - set(record))
        extra = sorted(set(record) - set(SCENIC_MANIFEST_KEYS))
        raise ScenicError(
            "scenic manifest key set is wrong (missing %s, unexpected %s)"
            % (missing, extra)
        )
    if not (SCENIC_HEIGHT_MIN <= record["height-min"] <= record["height-max"]
            <= SCENIC_HEIGHT_MAX):
        raise ScenicError("scenic manifest band is out of range")
    if record["payload-bytes"] != tc.TILE_PAYLOAD_SIZE:
        raise ScenicError("scenic payload-bytes must be %d" % tc.TILE_PAYLOAD_SIZE)
    if record["tile-bytes"] != SCENIC_TILE_BYTES:
        raise ScenicError("scenic tile-bytes must be %d" % SCENIC_TILE_BYTES)
    bounds = record["bounds"]
    if not (isinstance(bounds, list) and len(bounds) == 4):
        raise ScenicError("bounds must be [cx0 cz0 cx1 cz1]")
    if bounds[0] > bounds[2] or bounds[1] > bounds[3]:
        raise ScenicError("bounds must satisfy cx0<=cx1 and cz0<=cz1")
    origin = record["origin"]
    if not (isinstance(origin, list) and len(origin) == 2):
        raise ScenicError("origin must hold two integers")
    record_path = os.path.join(directory, SCENIC_JSON_NAME)
    if not os.path.isfile(record_path):
        raise ScenicError("no %s in %s" % (SCENIC_JSON_NAME, directory))
    with open(record_path, "rb") as handle:
        record_bytes = handle.read()
    if len(record_bytes) != record["json-bytes"]:
        raise ScenicError(
            "%s is %d bytes, the manifest binds %d"
            % (SCENIC_JSON_NAME, len(record_bytes), record["json-bytes"])
        )
    if zlib.crc32(record_bytes) & 0xFFFFFFFF != record["json-crc32"]:
        raise ScenicError(
            "%s CRC-32 does not match the manifest (record replaced)"
            % SCENIC_JSON_NAME
        )
    return record


def _scenic_payload(heights, height_min, height_max):
    """Build a 256-byte x-fastest payload, enforcing the scenic band only."""
    if isinstance(heights, (bytes, bytearray, memoryview)):
        sequence = list(bytes(heights))
    elif isinstance(heights, (list, tuple)):
        sequence = heights
    else:
        raise ScenicError(
            "heights must be a bytes-like object or a list/tuple"
        )
    if len(sequence) != tc.TILE_PAYLOAD_SIZE:
        raise ScenicError(
            "heights must contain %d values, got %d"
            % (tc.TILE_PAYLOAD_SIZE, len(sequence))
        )
    payload = bytearray(tc.TILE_PAYLOAD_SIZE)
    for index, height in enumerate(sequence):
        if isinstance(height, bool) or not isinstance(height, int):
            raise ScenicError(
                "height[%d] must be an int, not %r"
                % (index, type(height).__name__)
            )
        if not height_min <= height <= height_max:
            raise ScenicError(
                "height[%d]=%d outside scenic band %d..%d"
                % (index, height, height_min, height_max)
            )
        payload[index] = height
    return bytes(payload)


def encode_scenic_tile(cx, cz, heights, *, height_min=SCENIC_HEIGHT_MIN,
                       height_max=SCENIC_HEIGHT_MAX):
    """Encode one TDS3 tile. Same 308 bytes, different magic and wider band."""
    cx, cz = tc._require_chunk_coord(cx, cz)
    payload = _scenic_payload(heights, height_min, height_max)
    crc = zlib.crc32(payload) & 0xFFFFFFFF
    digest = hashlib.sha256(payload).digest()
    return SCENIC_HEADER_STRUCT.pack(
        SCENIC_MAGIC, cx, cz, len(payload), crc, digest
    ) + payload


def decode_scenic_tile(data, cx, cz, *, height_min=SCENIC_HEIGHT_MIN,
                       height_max=SCENIC_HEIGHT_MAX):
    """Decode one TDS3 tile, rejecting TDH2 and any out-of-band height."""
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise ScenicError("tile data must be bytes-like")
    data = bytes(data)
    if len(data) != SCENIC_TILE_BYTES:
        raise ScenicError(
            "tile length %d, expected %d" % (len(data), SCENIC_TILE_BYTES)
        )
    magic, file_cx, file_cz, payload_length, crc, digest = (
        SCENIC_HEADER_STRUCT.unpack_from(data)
    )
    if magic != SCENIC_MAGIC:
        raise ScenicError(
            "bad magic %r; this is not a scenic tile (TDH2 must go through "
            "terrain_cache.read_tile)" % (magic,)
        )
    if payload_length != tc.TILE_PAYLOAD_SIZE:
        raise ScenicError("bad payload length %d" % payload_length)
    if (file_cx, file_cz) != (cx, cz):
        raise ScenicError(
            "tile coordinates (%d,%d) do not match requested (%d,%d)"
            % (file_cx, file_cz, cx, cz)
        )
    payload = data[SCENIC_HEADER_STRUCT.size:]
    if zlib.crc32(payload) & 0xFFFFFFFF != crc:
        raise ScenicError("payload CRC-32 does not match header")
    if hashlib.sha256(payload).digest() != digest:
        raise ScenicError("payload SHA-256 does not match header")
    for index, height in enumerate(payload):
        if not height_min <= height <= height_max:
            raise ScenicError(
                "height[%d]=%d outside scenic band %d..%d"
                % (index, height, height_min, height_max)
            )
    return file_cx, file_cz, payload


# ---------------------------------------------------------------------------
# Import: raw metres -> one scenic cache
# ---------------------------------------------------------------------------


def import_raw(
    raw_path,
    cache_root,
    *,
    meters_per_voxel,
    sea_level,
    baseline_elevation_m=0.0,
    profile,
    height_max=SCENIC_HEIGHT_MAX,
    world_origin_voxels=(0, 0),
):
    """Bake one scenic cache from a raw export using a single global transfer.

    The scale is supplied by the caller, who chose it from the *whole map's*
    statistics; nothing here inspects a tile-local range. Heights are computed
    exactly once per voxel -- ``floor((m - baseline) / scale + sea + 0.5)`` -- and
    written straight to the tile, with no second rounding pass.

    Climate needs NO new caller argument and no separate path: this reads the
    ``climate`` array the raw export already carries (``export_raw(...,
    climate=)``, flagged ``has_climate`` in the sidecar). When it is present it is
    validated and written beside the tiles as ``climate.f32`` and described in
    the CRC-bound record BEFORE the identity is published; when it is absent,
    nothing about this function changes and the record is byte-identical to what
    it wrote before climate existed.
    """
    arrays, meta = read_raw(raw_path)
    elevation = arrays["elevation_m"]
    origin = [int(v) for v in arrays["origin_pixels"]]
    seed = int(arrays["seed"][0])
    ppv = int(arrays["pixels_per_voxel"][0])

    # Validate climate FIRST, before a single byte of the artifact is written.
    # The sidecar's `has_climate` flag and the array itself must agree: a sidecar
    # claiming climate with no array (or the reverse) is an inconsistent export
    # and is refused rather than silently downgraded.
    rows, cols = int(elevation.shape[0]), int(elevation.shape[1])
    climate_values = arrays.get("climate")
    has_climate = bool(meta.get("has_climate", False))
    if has_climate and climate_values is None:
        raise ScenicError(
            "raw export records has_climate but carries no 'climate' array"
        )
    if climate_values is not None and not has_climate:
        raise ScenicError(
            "raw export carries a 'climate' array but its metadata says "
            "has_climate is false"
        )
    if climate_values is not None:
        climate_values = validate_climate(climate_values, rows=rows, cols=cols)

    mapping = scenic_mapping(
        meters_per_voxel=meters_per_voxel,
        sea_level=sea_level,
        baseline_elevation_m=baseline_elevation_m,
        height_max=height_max,
    )
    digest_of_mapping = hashlib.sha256(
        _canonical_json(mapping_record(mapping, profile=profile))
    ).hexdigest()

    world_origin = tuple(int(v) for v in world_origin_voxels)
    if len(world_origin) != 2:
        raise ScenicError("world_origin_voxels must hold two integers")
    # Where the map sits in WORLD voxels is independent of where the model was
    # sampled: `origin` is the raw sampling origin in source pixels, while
    # `world_origin` is the block the map's first tile occupies. A centred map
    # needs world_origin -half_extent, not the sampling origin 100000.
    descriptor = {
        "seed": seed,
        "pixels_per_voxel": ppv,
        "origin_pixels": origin,
        "origin_voxels": list(world_origin),
        "mapping": mapping_record(mapping, profile=profile),
        "raw_sha256": meta["raw_sha256"],
        "raw_grid": [meta["width"], meta["height"]],
        "provenance": meta.get("provenance", {}),
        "grid_transform": meta.get("provenance", {}).get("grid_transform", {}),
    }
    height, width = elevation.shape
    if width % tc.TILE_SIZE or height % tc.TILE_SIZE:
        raise ScenicError(
            "raw grid %dx%d is not a whole number of %d-voxel tiles"
            % (width, height, tc.TILE_SIZE)
        )
    # Chunk coordinates come from the WORLD origin, never the sampling origin.
    if world_origin[0] % tc.TILE_SIZE or world_origin[1] % tc.TILE_SIZE:
        raise ScenicError(
            "world origin %s must be chunk-aligned (%d blocks)"
            % (world_origin, tc.TILE_SIZE)
        )
    chunks_x = width // tc.TILE_SIZE
    chunks_z = height // tc.TILE_SIZE
    map_bounds = {
        "origin_pixels": origin,
        "origin_voxels": list(world_origin),
        "width_pixels": width,
        "height_pixels": height,
        "chunks_x": chunks_x,
        "chunks_z": chunks_z,
        "chunk_min": [world_origin[0] // tc.TILE_SIZE,
                      world_origin[1] // tc.TILE_SIZE],
        "chunk_max": [world_origin[0] // tc.TILE_SIZE + chunks_x,
                      world_origin[1] // tc.TILE_SIZE + chunks_z],
    }

    digest, directory = write_scenic_identity(
        cache_root,
        descriptor,
        map_bounds=map_bounds,
        profile=profile,
        raw_sha256=meta["raw_sha256"],
        mapping=mapping,
        climate=climate_values,
    )

    clamped_low = 0
    clamped_high = 0
    written = 0
    tiles_dir = os.path.join(directory, tc.TILE_DIR_NAME)
    base_cx = map_bounds["chunk_min"][0]
    base_cz = map_bounds["chunk_min"][1]
    for tile_z in range(height // tc.TILE_SIZE):
        for tile_x in range(width // tc.TILE_SIZE):
            heights = bytearray()
            for z in range(tc.TILE_SIZE):
                for x in range(tc.TILE_SIZE):
                    metres = float(
                        elevation[tile_z * tc.TILE_SIZE + z,
                                  tile_x * tc.TILE_SIZE + x]
                    )
                    value = mapping.quantize(metres)
                    if value <= mapping.height_min:
                        clamped_low += 1
                    elif value >= mapping.height_max:
                        clamped_high += 1
                    heights.append(value)
            cx = base_cx + tile_x
            cz = base_cz + tile_z
            data = encode_scenic_tile(
                cx, cz, heights,
                height_min=mapping.height_min, height_max=mapping.height_max,
            )
            path = os.path.join(tiles_dir, "%d_%d.tdh" % (cx, cz))
            with open(path, "wb") as handle:
                handle.write(data)
            written += 1

    summary = {
        "identity": digest,
        "directory": directory,
        "tiles": written,
        "profile": profile,
        "origin_voxels": list(world_origin),
        "bounds_inclusive": _bounds_record(map_bounds),
        "meters_per_voxel": mapping.meters_per_voxel,
        "sea_level": mapping.sea_level,
        "baseline_elevation_m": mapping.baseline_elevation_m,
        "height_min": mapping.height_min,
        "height_max": mapping.height_max,
        "source_min_m": meta["elevation_min_m"],
        "source_max_m": meta["elevation_max_m"],
        "voxels": written * tc.TILE_PAYLOAD_SIZE,
        "clamped_at_min": clamped_low,
        "clamped_at_max": clamped_high,
        "raw_sha256": meta["raw_sha256"],
        "mapping_sha256": digest_of_mapping,
        "has_climate": climate_values is not None,
    }
    with open(os.path.join(directory, "summary.json"), "w") as handle:
        json.dump(summary, handle, indent=2, sort_keys=True)
    return summary


def read_scenic_tile(cache_root, digest, cx, cz):
    """Read and verify one scenic tile against its manifest's declared band."""
    record = read_scenic_manifest(cache_root, digest)
    path = os.path.join(
        os.fspath(cache_root), digest, tc.TILE_DIR_NAME, "%d_%d.tdh" % (cx, cz)
    )
    with open(path, "rb") as handle:
        data = handle.read()
    return decode_scenic_tile(
        data, cx, cz,
        height_min=record["height-min"], height_max=record["height-max"],
    )
