# Rewrite data/materials.janet in the readable authored layout, preserving content.
# Run from the project root: ./run.sh with this file, or the bender binary.
(import ../src/material-recipes :as r)
(def path "data/materials.janet")
(def active (r/load path))
(r/save active path)
(def back (r/load path))
(print "rewritten " path)
(print "content preserved: "
  (and (= (length (keys active)) (length (keys back)))
       (every? (map (fn [k] (deep= (get active k) (get back k))) (keys active)))))
