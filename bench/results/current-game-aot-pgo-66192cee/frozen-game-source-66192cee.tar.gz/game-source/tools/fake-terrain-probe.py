#!/usr/bin/env python3
"""Fake provider for exercising main's generation loop with NO model.

It writes a real, valid TDS3 identity directory so the validator's scan, the
catalogue's inspection and the cache reader all run their real code paths. Only
the inference is absent -- which is the point: the loop, the ownership, the
reaping and the artifact handoff are what is being tested, not the model.

Modes via --mode on the command line, or FAKE_MODE in the environment:
  ok      write a complete artifact and exit 0
  fail    exit 3 with no artifact
  hang    sleep forever (bounded by the caller's frame budget)
"""
import hashlib
import json
import os
import sys
import time

import numpy as np
import tempfile

import scenic_terrain as st

TILE = 16
CHUNKS = 2          # 2x2 tiles -> a 32-pixel map at 1 pixel per voxel


def synthetic_elevation(seed):
    """A deterministic low-relief surface. NO model is loaded or sampled."""
    n = CHUNKS * TILE
    yy, xx = np.mgrid[0:n, 0:n]
    # A smooth ramp plus a ripple, so the terrain is not flat and not random.
    return (120.0
            + 6.0 * np.sin((xx + seed) / 7.0)
            + 4.0 * np.cos((yy - seed) / 9.0)).astype(np.float32)


def main():
    args = sys.argv[1:]
    out = None
    seed = 4
    sea = 28
    profile = "alpine"
    progress = None
    mode = os.environ.get("FAKE_MODE", "ok")
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--out":
            out = args[i + 1]; i += 2
        elif a == "--seed":
            seed = int(args[i + 1]); i += 2
        elif a == "--sea-level":
            sea = int(args[i + 1]); i += 2
        elif a == "--profile":
            profile = args[i + 1]; i += 2
        elif a == "--progress":
            progress = args[i + 1]; i += 2
        elif a == "--mode":
            mode = args[i + 1]; i += 2
        elif a == "--size":
            i += 2
        elif a in ("--check", "--json"):
            i += 1
        else:
            i += 1

    def stage(name, **detail):
        if progress:
            # EXACTLY ONE inert Janet record, atomically replaced per stage. The
            # job parses it, requires :version 1 and 2..5 keys, and never evaluates
            # it -- appending JSON lines would be a different contract.
            os.makedirs(os.path.dirname(progress) or ".", exist_ok=True)
            fields = [':version 1', ':stage :%s' % name]
            for k, v in detail.items():
                fields.append(':%s "%s"' % (k, v) if isinstance(v, str)
                              else ':%s %s' % (k, v))
            tmp = progress + ".tmp"
            with open(tmp, "w") as f:
                f.write("{" + " ".join(fields) + "}\n")
            os.replace(tmp, progress)

    if mode == "hang":
        stage("sample")
        while True:
            time.sleep(0.2)

    if mode == "empty":
        # Exit successfully having written nothing. The caller must treat this as
        # failure: a zero exit is not evidence of an artifact.
        return 0

    if mode == "fail":
        stage("failed")
        return 3

    if out is None:
        return 2

    stage("resolve")
    stage("sample")
    # The REAL exporter writes the artifact: manifest, provenance, tiles and the
    # CRC bindings the catalogue checks. Only the elevation is synthesized, so the
    # artifact is genuinely valid and every reader exercises its real code path.
    # The scratch export MUST live outside the output root: the validator scans
    # that root for exactly one 64-hex identity directory, and a stray file there
    # makes the scan fail. The real provider has the same constraint.
    raw = os.path.join(tempfile.mkdtemp(prefix="fake-terrain-"), "raw.npz")
    st.export_raw(raw, synthetic_elevation(seed),
                  origin_pixels=(100000, 100000), seed=seed,
                  pixels_per_voxel=1,
                  provenance={"provider": "fake-terrain-probe", "temporary": True})
    summary = st.import_raw(raw, out, meters_per_voxel=1.0, sea_level=sea,
                            profile=profile, world_origin_voxels=(0, 0))
    stage("export")
    ready = os.path.join(out, summary["identity"], "READY")
    with open(ready, "w") as f:
        # The marker the catalogue looks for: it requires BOTH "ready": true and
        # "temporary": true, because a temporary provider must never be mistaken
        # for a shipped one.
        json.dump({"ready": True, "temporary": True,
                   "identity": summary["identity"],
                   "tiles": summary["tiles"],
                   "provider": "fake-terrain-probe"}, f, indent=2, sort_keys=True)
    stage("ready")
    try:
        os.remove(raw)
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
