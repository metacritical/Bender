#!/usr/bin/env python3
"""BUILD-TIME ONLY — extract small, stable golden vectors from the big captures.

The stage captures are 65 MB of float32 (158 real forward calls). Committing them
is wrong, and keeping tests dependent on them is fragile. This script carves out
a small, fixed set of golden vectors that are:

  * small enough to commit (~32 KB),
  * stable (indexed by name, not by directory listing order),
  * sufficient to pin each stage's arithmetic and the conditioning map,
  * accompanied by scale statistics so tolerances can be grounded in the data
    rather than asserted.

Run from the repo root:

    tmp/terrain-runtime/venv/bin/python tools/terrain_make_goldens.py

Writes native/proof/fixtures/goldens.json (metadata + checksums) and
native/proof/fixtures/goldens/*.f32 (the small vectors).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys

import numpy as np

STAGE2 = "native/proof/fixtures/stage2"
OUTDIR = "native/proof/fixtures/goldens"


def sha_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def load(path, n=None):
    a = np.fromfile(path, dtype="<f4")
    if n is not None and a.size != n:
        raise SystemExit(f"{path}: expected {n} floats, got {a.size}")
    return a


def stats(a):
    return {
        "n": int(a.size),
        "min": float(a.min()),
        "max": float(a.max()),
        "mean": float(a.mean()),
        "abs_mean": float(np.abs(a).mean()),
        "rms": float(np.sqrt((a * a).mean())),
    }


def emit(name, arr, meta, subdir, limit=None):
    """Write one vector and record its checksum and statistics."""
    # Keep only a bounded prefix per vector so the committed set stays small.
    if limit is not None and arr.size > limit:
        arr = arr[:limit]
    path = os.path.join(subdir, name + ".f32")
    arr.astype("<f4").tofile(path)
    meta[name] = {
        "file": os.path.relpath(path, "native/proof/fixtures"),
        "bytes": os.path.getsize(path),
        "sha256": sha_file(path),
        **stats(arr),
    }


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=512,
                    help="max floats kept per vector (default 512 = 2 KB)")
    args = ap.parse_args(argv)

    if not os.path.isdir(STAGE2):
        raise SystemExit(f"missing {STAGE2}; run terrain_stage_capture.py first")
    os.makedirs(OUTDIR, exist_ok=True)

    meta = {
        "_note": ("Stable golden vectors extracted from real upstream forward calls. "
                  "Build-time only; never read at game runtime. Tolerances must be "
                  "grounded in the abs_mean/rms recorded here, not asserted."),
        "origin": 100000,
        "seed": 12345,
        "model_revision": "9ef8030cb805b433b98ec25c5dddefbac07a9e26",
        "vectors": {},
    }
    meta["upstream_revision"] = "e8dcb4b1a834ab2f6b1a6f5256ed7c9f2f3e8230"

    L = args.limit

    # ---- stage inputs and outputs, truncated to a stable prefix ----------
    for stage, shape in (("coarse", (11, 64, 64)), ("base", (5, 64, 64))):
        x = load(os.path.join(STAGE2, f"{stage}_x.f32"))
        emit(f"{stage}_x", x[:L], meta["vectors"], OUTDIR)
        o = load(os.path.join(STAGE2, f"{stage}_out.f32"))
        emit(f"{stage}_out", o[:L], meta["vectors"], OUTDIR)
        lbl = load(os.path.join(STAGE2, f"{stage}_noise.f32"))
        emit(f"{stage}_noise", lbl, meta["vectors"], OUTDIR, L)

    # coarse has five scalar conds that are identical in the captured call
    c0 = load(os.path.join(STAGE2, "coarse_cond0.f32"))
    emit("coarse_cond", c0, meta["vectors"], OUTDIR, L)

    # base's 58-wide conditioning vector is the interesting one
    bc = load(os.path.join(STAGE2, "base_cond0.f32"), 58)
    emit("base_cond58", bc, meta["vectors"], OUTDIR, L)

    # decoder at 512x512: only keep a prefix, it is 1 MB per channel
    dx = load(os.path.join(STAGE2, "decoder_x.f32"))
    emit("decoder_x", dx, meta["vectors"], OUTDIR, L)
    do = load(os.path.join(STAGE2, "decoder_out.f32"))
    emit("decoder_out", do, meta["vectors"], OUTDIR, L)

    # ---- conditioning map (5x64x64 -> prefix) ---------------------------
    cm = load("native/proof/fixtures/oracle/cond_map.f32")
    if cm.size:
        emit("cond_map", cm, meta["vectors"], OUTDIR, L)

    total = sum(v["bytes"] for v in meta["vectors"].values())
    meta["total_bytes"] = total
    with open("native/proof/fixtures/goldens.json", "w") as f:
        json.dump(meta, f, indent=1)

    print(f"wrote {len(meta['vectors'])} vectors, {total} bytes total")
    for k, v in meta["vectors"].items():
        print(f"  {k:14} {v['n']:6} floats  {v['bytes']:7} B  abs_mean={v['abs_mean']:.4f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
