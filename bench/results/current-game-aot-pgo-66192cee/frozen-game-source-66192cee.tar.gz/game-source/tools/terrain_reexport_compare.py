#!/usr/bin/env python3
"""BUILD-TIME ONLY — re-export the pinned checkpoint to ONNX and compare.

Why this exists: the published `terrain-diffusion-30m-onnx` artifacts disagree
with the PyTorch checkpoint on base (7.9e-03) and decoder (1.7e-04) while sharing
byte-identical weights. That could mean either

  (a) the published export is lossy, or
  (b) the difference is ordinary float32 accumulation through the attention path,
      which would make any re-export drift the same way.

This script distinguishes them: it exports fresh graphs from the pinned
checkpoint at opset 17, then compares fresh-ORT against PyTorch on the exact
captured inputs. If a fresh export drifts the same amount, the published artifact
was never broken and the drift is numerical. Only if fresh is materially better
is the published export at fault.

It never overwrites the published artifacts: output goes to
tmp/native-terrain-proof/reexport/ and each input SHA is recorded.

No network, no downloads. CPU, 2 threads.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys

import numpy as np

SNAP = ("/Users/pankajdoharey/.cache/huggingface/hub/"
        "models--xandergos--terrain-diffusion-30m/snapshots/"
        "9ef8030cb805b433b98ec25c5dddefbac07a9e26")
FX = "native/proof/fixtures/stage2"
PUBLISHED = "tmp/native-terrain-proof"


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def stats(got, want):
    d = got - want
    ad = np.abs(d)
    scale = float(np.abs(want).mean())
    return {
        "max_abs": float(ad.max()),
        "mean_abs": float(ad.mean()),
        "rms": float(np.sqrt((d * d).mean())),
        "relative_to_output_scale": float(ad.max() / max(scale, 1e-12)),
        "output_abs_mean": scale,
        "output_rms": float(np.sqrt((want * want).mean())),
    }


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--upstream", default="tmp/terrain-runtime/repo")
    ap.add_argument("--out", default="tmp/native-terrain-proof/reexport")
    ap.add_argument("--opset", type=int, default=17)
    args = ap.parse_args(argv)

    import torch
    torch.set_num_threads(2)

    upstream = os.path.abspath(args.upstream)
    outdir = os.path.abspath(args.out)
    os.makedirs(outdir, exist_ok=True)
    repo = os.getcwd()
    os.chdir(upstream)
    if upstream not in sys.path:
        sys.path.insert(0, upstream)

    from terrain_diffusion.models.edm_unet import EDMUnet2D
    from terrain_diffusion.onnx.export import export_model

    report = {
        "purpose": "fresh re-export vs published, on captured inputs",
        "opset": args.opset,
        "device": "cpu",
        "torch_threads": 2,
        "model_revision": "9ef8030cb805b433b98ec25c5dddefbac07a9e26",
        "upstream_revision": "e8dcb4b1a834ab2f6b1a6f5256ed7c9f2f3e8230",
        "published_shas": {},
        "fresh_shas": {},
        "results": {},
    }

    import onnxruntime as ort

    def run_case(name, shape, out_shape, conds):
        """Capture fixture -> fresh ONNX -> compare against captured PyTorch."""
        x = np.fromfile(os.path.join(repo, FX, f"{name}_x.f32"), dtype="<f4").reshape(shape)
        lbl = np.fromfile(os.path.join(repo, FX, f"{name}_noise.f32"), dtype="<f4")
        want = np.fromfile(os.path.join(repo, FX, f"{name}_out.f32"),
                           dtype="<f4").reshape(out_shape)

        fresh = os.path.join(outdir, f"{name}_model.onnx")
        model = EDMUnet2D.from_pretrained(os.path.join(SNAP, f"{name}_model")).eval()
        size_override = 64 if name in ("coarse", "base") else None
        export_model(model, fresh, device="cpu", opset=args.opset,
                     image_size=size_override)
        del model

        sess = ort.InferenceSession(fresh, providers=["CPUExecutionProvider"])
        feed = {sess.get_inputs()[0].name: x, sess.get_inputs()[1].name: lbl}
        for i, c in enumerate(conds, start=2):
            feed[sess.get_inputs()[i].name] = c
        got = sess.run(None, feed)[0]

        pub = os.path.join(repo, PUBLISHED, f"{name}_model.onnx")
        pub_sess = ort.InferenceSession(pub, providers=["CPUExecutionProvider"])
        pfeed = {pub_sess.get_inputs()[0].name: x, pub_sess.get_inputs()[1].name: lbl}
        for i, c in enumerate(conds, start=2):
            pfeed[pub_sess.get_inputs()[i].name] = c
        pgot = pub_sess.run(None, pfeed)[0]

        report["published_shas"][name] = sha256(pub)
        report["fresh_shas"][name] = sha256(fresh)
        report["results"][name] = {
            "fresh_onnx_vs_pytorch": stats(got, want),
            "published_onnx_vs_pytorch": stats(pgot, want),
            "fresh_vs_published": stats(got, pgot),
        }
        r = report["results"][name]
        print(f"=== {name} ===")
        for k in ("fresh_onnx_vs_pytorch", "published_onnx_vs_pytorch", "fresh_vs_published"):
            s = r[k]
            print(f"  {k:26} max={s['max_abs']:.3e} rms={s['rms']:.3e} "
                  f"rel={s['relative_to_output_scale']:.3e}")

    # coarse: 5 scalar conds
    c0 = np.fromfile(os.path.join(repo, FX, "coarse_cond0.f32"), dtype="<f4")
    run_case("coarse", (1, 11, 64, 64), (1, 6, 64, 64), [c0] * 5)

    # base: one 58-wide cond
    bc = np.fromfile(os.path.join(repo, FX, "base_cond0.f32"), dtype="<f4").reshape(1, 58)
    run_case("base", (1, 5, 64, 64), (1, 5, 64, 64), [bc])

    # decoder: 512x512, no cond
    run_case("decoder", (1, 5, 512, 512), (1, 1, 512, 512), [])

    out = os.path.join(outdir, "reexport-report.json")
    with open(out, "w") as f:
        json.dump(report, f, indent=1)
    print("\nwrote", out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
