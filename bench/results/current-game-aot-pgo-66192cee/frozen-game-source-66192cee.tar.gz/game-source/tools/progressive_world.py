"""Progressive world contract (``tds4-progressive/1``): identities and states.

This module is a CONTRACT, not a runtime. It defines what a progressive world
and one of its patches are, hashes them, and validates the state machine a
future scheduler must obey before it publishes anything. It starts no process,
loads no model, and imports neither torch nor numpy -- only the standard library
plus :mod:`terrain_cache` for the canonical JSON/SHA-256 and the coordinate and
mapping validators that already exist.

Why this is not part of the finite TDS3 product
-----------------------------------------------
A scenic (TDS3) map is finite by construction: it has edges, and the game
deliberately refuses to start a terrain worker beside one, because streaming
diffusion tiles into a configured world would mix two terrains. A progressive
world is a DIFFERENT product with its own contract string and its own digest, so
nothing here can be mistaken for an existing artifact. TDH2 and TDS3 identities,
tiles, manifests and saves are untouched: this module writes no files and reads
none.

Identity scopes
---------------
``world_identity`` answers "what world is this" and is frozen at creation. No
coordinate, request, batch, timestamp or player position may appear in it.

``patch_identity`` answers "what patch is this", and must NOT vary with which
other patches were requested alongside it, their order, or the batch's shape --
the same property ``sample_chunks`` already guarantees for heights.

Anchors use true floor division (see :func:`anchor`). The consequence at the
origin is a real seam: chunk ``-1`` anchors to ``-4`` and chunk ``0`` to ``0``,
so they do NOT share a window. An earlier audit note claimed they did; the
tests pin the real behaviour.
"""

from __future__ import annotations

import hashlib
import math

import terrain_cache as tc

#: The contract's own identity string. Deliberately not a TDH2/TDS3 magic: a
#: reader that predates this contract rejects it rather than reinterpreting it.
CONTRACT = "tds4-progressive/1"

#: Version of the patch staging record. Bumped if the staging key set changes.
CONTRACT_VERSION = 1

#: Lifecycle states. The set is closed: anything else is not a patch state.
QUEUED = "queued"
INFLIGHT = "inflight"
VALIDATED = "validated"
PUBLISHED = "published"
FAILED = "failed"
CANCELLED = "cancelled"

STATES = (QUEUED, INFLIGHT, VALIDATED, PUBLISHED, FAILED, CANCELLED)

#: Terminal states: nothing may leave them, and nothing may publish from them.
TERMINAL = (PUBLISHED, FAILED, CANCELLED)

#: The ONLY legal transitions. Publication is reachable only from ``validated``,
#: which is what makes "nothing partial is ever published" a rule rather than a
#: hope: there is no edge from ``inflight`` or ``queued`` to ``published``.
TRANSITIONS = {
    QUEUED: (INFLIGHT, CANCELLED),
    INFLIGHT: (VALIDATED, FAILED, CANCELLED),
    VALIDATED: (PUBLISHED, FAILED, CANCELLED),
    PUBLISHED: (),
    FAILED: (),
    CANCELLED: (),
}


class ProgressiveContractError(ValueError):
    """A progressive-world record or transition violates the contract."""


# ---------------------------------------------------------------------------
# Canonical anchors
# ---------------------------------------------------------------------------


def anchor(chunk, window_chunks):
    """Global anchor of the window containing ``chunk``, by FLOOR division.

    Floor is what keeps negative coordinates on the same lattice as positive
    ones. It does not make the origin continuous::

        anchor(-9, 4) == -12      anchor(-4, 4) == -4
        anchor(-5, 4) == -8       anchor(-1, 4) == -4
        anchor( 0, 4) ==  0       anchor( 3, 4) ==  0
        anchor( 4, 4) ==  4

    So ``-1`` and ``0`` are in DIFFERENT windows (``-4`` and ``0``). The window
    grid has a seam at chunk 0; a scheduler must treat it as a real boundary.
    """
    tc._require_chunk_coord(chunk, chunk)
    if isinstance(window_chunks, bool) or not isinstance(window_chunks, int):
        raise ProgressiveContractError("window_chunks must be an int")
    if window_chunks < 1:
        raise ProgressiveContractError("window_chunks must be at least 1")
    return (chunk // window_chunks) * window_chunks


def anchor_pair(cx, cz, window_chunks):
    """The ``(anchor_x, anchor_z)`` pair for a chunk coordinate."""
    tc._require_chunk_coord(cx, cz)
    return (anchor(cx, window_chunks), anchor(cz, window_chunks))


def chunk_coords(cx, cz):
    """Validate a signed int32 chunk coordinate pair and return it as a tuple.

    Signed int32 is required rather than assumed: a coordinate outside it must
    raise rather than wrap, or two different places could share one record.
    """
    return tc._require_chunk_coord(cx, cz)


# ---------------------------------------------------------------------------
# Query and staging geometry
# ---------------------------------------------------------------------------

#: The address law: global voxel -> native source pixel, an EXACT affine rational.
#:
#: This is the correction that makes adjacent patches possible at all. The scenic
#: path upsampled 128 -> 512 with an endpoint-preserving bilinear whose step is
#: (n-1)/(n*factor-1) = 511/127 ~= 4.0236, not 4. That is fine for ONE finite map
#: and cannot repeat: neighbouring patches would sit on different global lattices
#: and drift. Version 1 therefore admits only the integer native lattice,
#: num == den == pixels_per_voxel == 1, so chunk cx owns exactly
#: [cx*16, cx*16+16) and chunk cx+1 starts at (cx+1)*16 with zero drift.
ADDRESS = {"kind": "global-affine-v1", "num": 1, "den": 1}

#: The strategy this contract accepts. The legacy macrotile strategy is NOT
#: accepted: it describes a finite window, not a repeatable global lattice.
STRATEGY = "global-affine-lattice-v1"

#: Version 1's fixed staging geometry.
CORE_WINDOW_CHUNKS = 4          # core patch = 4 x 4 chunks = 64 x 64 voxels
HALO_VOXELS = 16                # one chunk of overlap: sampled, never published
HALO_CHUNKS = HALO_VOXELS // tc.TILE_SIZE
PIXELS_PER_VOXEL_V1 = 1
#: 6 chunks per axis of witness window: core 64 px + 2 x 16 halo px = 96 samples.
WITNESS_WINDOW_CHUNKS = CORE_WINDOW_CHUNKS + 2 * HALO_CHUNKS
MIN_MAX_SAMPLES = 96
MAX_MAX_SAMPLES = 128


def address_record():
    """The pinned address law. Version 1 is the integer native lattice only."""
    return dict(ADDRESS)


def default_query_record():
    """The one staging geometry version 1 defines, as a plain query record."""
    return {
        "strategy": STRATEGY,
        "origin_pixels": [0, 0],
        "window_chunks": CORE_WINDOW_CHUNKS,
        "window_pixels": CORE_WINDOW_CHUNKS * tc.TILE_SIZE * PIXELS_PER_VOXEL_V1,
        "max_samples": MAX_MAX_SAMPLES,
        "pixels_per_voxel": PIXELS_PER_VOXEL_V1,
        "halo_voxels": HALO_VOXELS,
    }




def query_record(query):
    """The pinned sampling geometry, taken from the backend's own ``Query``.

    Accepts the existing ``terrain_backend.Query`` object (or anything exposing
    ``identity_record()``) so this contract cannot drift from the geometry the
    sampler actually uses, and cannot grow a second definition of a window.

    ``halo_voxels`` is REQUIRED and world-pinned. It used to live only in the
    per-patch staging echo, which let two patches under ONE world digest vary the
    overlap -- and a seam witness computed with a varying halo means nothing. No
    TDS4 world exists yet, so pinning it now breaks nothing.
    """
    record = query.identity_record() if hasattr(query, "identity_record") else query
    if not isinstance(record, dict):
        raise ProgressiveContractError("query must be a Query or its record")
    required = ("strategy", "origin_pixels", "window_chunks", "window_pixels",
                "max_samples", "pixels_per_voxel", "halo_voxels")
    missing = [key for key in required if key not in record]
    if missing:
        raise ProgressiveContractError(
            "query record is missing %s" % ", ".join(sorted(missing))
        )
    if record["strategy"] != STRATEGY:
        raise ProgressiveContractError(
            "query strategy %r is not %r; the finite macrotile strategy is not a "
            "global lattice and cannot repeat across adjacent patches"
            % (record["strategy"], STRATEGY)
        )
    window_chunks = record["window_chunks"]
    if isinstance(window_chunks, bool) or not isinstance(window_chunks, int):
        raise ProgressiveContractError("query window_chunks must be an int")
    if window_chunks != CORE_WINDOW_CHUNKS:
        raise ProgressiveContractError(
            "contract version 1 fixes window_chunks at %d, got %d"
            % (CORE_WINDOW_CHUNKS, window_chunks)
        )
    pixels_per_voxel = record["pixels_per_voxel"]
    if isinstance(pixels_per_voxel, bool) or not isinstance(pixels_per_voxel, int):
        raise ProgressiveContractError("query pixels_per_voxel must be an int")
    if pixels_per_voxel != PIXELS_PER_VOXEL_V1:
        raise ProgressiveContractError(
            "contract version 1 admits only the native integer lattice "
            "(pixels_per_voxel %d == address %d/%d). A global resample needs one "
            "shared rational address for every patch and a NEW contract version; "
            "a per-patch stretch is exactly what broke the scenic 128->512 path."
            % (PIXELS_PER_VOXEL_V1, ADDRESS["num"], ADDRESS["den"])
        )
    halo_voxels = record["halo_voxels"]
    if isinstance(halo_voxels, bool) or not isinstance(halo_voxels, int):
        raise ProgressiveContractError("query halo_voxels must be an int")
    if halo_voxels != HALO_VOXELS:
        raise ProgressiveContractError(
            "contract version 1 fixes halo_voxels at %d, got %d"
            % (HALO_VOXELS, halo_voxels)
        )
    # The bound the backend already enforces, re-asserted here so a contract can
    # never declare a window the sampler would refuse to fetch.
    window_pixels = window_chunks * tc.TILE_SIZE * pixels_per_voxel
    if window_pixels != record["window_pixels"]:
        raise ProgressiveContractError(
            "query window_pixels %r disagrees with window_chunks %r x %d x %r"
            % (record["window_pixels"], window_chunks, tc.TILE_SIZE,
               pixels_per_voxel)
        )
    witness_pixels = window_pixels + 2 * halo_voxels * pixels_per_voxel
    max_samples = record["max_samples"]
    if isinstance(max_samples, bool) or not isinstance(max_samples, int):
        raise ProgressiveContractError("query max_samples must be an int")
    if not MIN_MAX_SAMPLES <= max_samples <= MAX_MAX_SAMPLES:
        raise ProgressiveContractError(
            "contract version 1 requires %d <= max_samples <= %d (a %d px witness "
            "window must fit on MPS), got %d"
            % (MIN_MAX_SAMPLES, MAX_MAX_SAMPLES, witness_pixels, max_samples)
        )
    if witness_pixels > max_samples:
        raise ProgressiveContractError(
            "a witness window needs %d samples per axis (%d core + 2 x %d halo) "
            "but max_samples is %d"
            % (witness_pixels, window_pixels, halo_voxels, max_samples)
        )
    return {
        "strategy": STRATEGY,
        "origin_pixels": list(record["origin_pixels"]),
        "window_chunks": window_chunks,
        "window_pixels": window_pixels,
        "witness_window_pixels": witness_pixels,
        "max_samples": max_samples,
        "pixels_per_voxel": pixels_per_voxel,
        "halo_voxels": halo_voxels,
        "address": address_record(),
    }


def staging_record(*, query, halo_chunks):
    """The staging block one patch was produced with.

    ``halo_chunks`` is sampled but NOT published: it exists so adjacent patches
    come from overlapping model input instead of abutting ones. Recording it is
    not a claim that the overlap removes seams (see the design document).

    The echo must EQUAL the world-pinned halo. A patch declaring a different
    staging cannot be produced under this world, so it is refused rather than
    emitting a witness nobody can compare against a neighbour.
    """
    if isinstance(halo_chunks, bool) or not isinstance(halo_chunks, int):
        raise ProgressiveContractError("halo_chunks must be an int")
    if halo_chunks < 0:
        raise ProgressiveContractError("halo_chunks must not be negative")
    record = query_record(query)
    if halo_chunks > record["window_chunks"]:
        raise ProgressiveContractError(
            "halo_chunks %d exceeds the window size %d"
            % (halo_chunks, record["window_chunks"])
        )
    required_chunks = record["halo_voxels"] // tc.TILE_SIZE
    if halo_chunks != required_chunks:
        raise ProgressiveContractError(
            "patch staging halo %d chunks does not match the world's pinned halo "
            "%d chunks (%d voxels)"
            % (halo_chunks, required_chunks, record["halo_voxels"])
        )
    return {
        "version": CONTRACT_VERSION,
        "query": record,
        "halo_chunks": halo_chunks,
    }


# ---------------------------------------------------------------------------
# Mapping and climate policy
# ---------------------------------------------------------------------------


def mapping_record(mapping):
    """The global elevation transfer, validated against the real mapping object.

    A world must not claim one transfer and quantize with another, so the record
    is read FROM the ``terrain_cache.HeightMapping`` (or an equivalent object),
    not asserted beside it.
    """
    for name in ("meters_per_voxel", "sea_level", "baseline_elevation_m",
                 "height_min", "height_max"):
        if not hasattr(mapping, name):
            raise ProgressiveContractError(
                "mapping is missing %s; pass a terrain_cache.HeightMapping" % name
            )
    return {
        "meters_per_voxel": float(mapping.meters_per_voxel),
        "sea_level": int(mapping.sea_level),
        "baseline_elevation_m": float(mapping.baseline_elevation_m),
        "height_min": int(mapping.height_min),
        "height_max": int(mapping.height_max),
    }


def climate_record(*, policy_version, container_version):
    """Which climate policy may ever attach to this world, or none.

    ``policy_version`` None means climate is inert for this world -- the current
    production state. Enabling a policy is a NEW world identity, never a setting
    on an existing world, so a saved result cannot change underneath a player.
    """
    if policy_version is None and container_version is not None:
        raise ProgressiveContractError(
            "a container version without a policy version is not a world state"
        )
    if policy_version is not None and container_version is None:
        raise ProgressiveContractError(
            "a climate policy must name the container version it reads"
        )
    return {
        "policy_version": None if policy_version is None else int(policy_version),
        "container_version": (
            None if container_version is None else int(container_version)
        ),
    }


# ---------------------------------------------------------------------------
# Identities
# ---------------------------------------------------------------------------


def _digest(record):
    """Canonical SHA-256 over ``record``, reusing terrain_cache's encoder."""
    return hashlib.sha256(tc._canonical_json(record)).hexdigest()


def world_descriptor(*, seed, model, query, mapping, climate):
    """The frozen world record whose digest is the world identity.

    Nothing positional belongs here. ``model`` is the pinned provenance block
    (repo, revision, config/configset/weightset/stats digests); it is validated
    for shape but never invented.
    """
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise ProgressiveContractError("seed must be an int")
    if seed < 0:
        raise ProgressiveContractError("seed must not be negative")
    if not isinstance(model, dict) or not model:
        raise ProgressiveContractError("model must be a non-empty provenance block")
    for key in ("repo", "revision", "stats_sha256"):
        if key not in model:
            raise ProgressiveContractError("model block is missing %s" % key)
    if not isinstance(climate, dict) or set(climate) != {
        "policy_version", "container_version"
    }:
        raise ProgressiveContractError(
            "climate must be a climate_record with exactly "
            "policy_version and container_version"
        )
    return {
        "contract": CONTRACT,
        "seed": int(seed),
        "model": dict(model),
        "query": query_record(query),
        "mapping": mapping_record(mapping),
        "climate": dict(climate),
    }


def world_identity(*, seed, model, query, mapping, climate):
    """The world identity digest: a hex SHA-256 over the frozen descriptor."""
    return _digest(world_descriptor(
        seed=seed, model=model, query=query, mapping=mapping, climate=climate
    ))


def patch_descriptor(*, world_identity_digest, cx, cz, query, halo_chunks):
    """The frozen patch record whose digest is the patch identity.

    The batch, request order and any timestamp are deliberately absent: two runs
    that request this patch alone or inside a bigger batch must agree.
    """
    tc._require_digest(world_identity_digest)
    cx, cz = chunk_coords(cx, cz)
    return {
        "contract": CONTRACT,
        "world_identity": world_identity_digest,
        "cx": int(cx),
        "cz": int(cz),
        "staging": staging_record(query=query, halo_chunks=halo_chunks),
    }


def patch_identity(*, world_identity_digest, cx, cz, query, halo_chunks):
    """The patch identity digest: hex SHA-256 over the frozen patch record."""
    return _digest(patch_descriptor(
        world_identity_digest=world_identity_digest, cx=cx, cz=cz,
        query=query, halo_chunks=halo_chunks,
    ))


# ---------------------------------------------------------------------------
# The state machine
# ---------------------------------------------------------------------------


class PatchState:
    """One patch's lifecycle under a single inference owner.

    Ownership is a ``revision`` epoch. A patch produced under a stale revision
    is discarded rather than published, so a restarted owner cannot resurrect
    work that was cancelled while it was inflight.

    Publication is reachable ONLY from ``validated`` (see :data:`TRANSITIONS`),
    which is what makes "no partially written patch is ever observable as
    published" a structural rule: there is no edge from ``queued`` or
    ``inflight`` to ``published``.
    """

    def __init__(self, identity, *, revision=0):
        tc._require_digest(identity)
        if isinstance(revision, bool) or not isinstance(revision, int):
            raise ProgressiveContractError("revision must be an int")
        if revision < 0:
            raise ProgressiveContractError("revision must not be negative")
        self.identity = identity
        self.revision = revision
        self.state = QUEUED
        self.reason = None
        self.history = [QUEUED]

    def can(self, target):
        """Is ``target`` reachable from the current state?"""
        return target in TRANSITIONS[self.state]

    def transition(self, target, *, reason=None, revision=None):
        """Move to ``target`` or refuse.

        A ``revision`` argument that differs from this patch's epoch is refused
        for any non-terminal target: stale work may be cancelled or failed by a
        new owner, never advanced to publication.
        """
        if target not in STATES:
            raise ProgressiveContractError("unknown state %r" % (target,))
        if not self.can(target):
            raise ProgressiveContractError(
                "illegal transition %s -> %s for patch %s"
                % (self.state, target, self.identity[:12])
            )
        if revision is not None and revision != self.revision:
            # A QUEUED patch has no owner yet, so the FIRST claim establishes the
            # epoch. After that, a newer epoch may only terminate stale work --
            # never advance it toward publication, which is what stops a
            # restarted owner from publishing work cancelled while it was
            # inflight.
            if self.state == QUEUED and target == INFLIGHT:
                self.revision = revision
            elif target in (PUBLISHED, VALIDATED, INFLIGHT):
                raise ProgressiveContractError(
                    "revision %r may not advance patch %s (epoch %r)"
                    % (revision, self.identity[:12], self.revision)
                )
            else:
                self.revision = revision
        self.state = target
        if reason is not None:
            self.reason = reason
        self.history.append(target)
        return self.state

    def claim(self, *, revision):
        """Take ownership: ``queued -> inflight`` under a revision epoch."""
        return self.transition(INFLIGHT, revision=revision)

    def validate(self):
        """``inflight -> validated``. Still not visible to any reader."""
        return self.transition(VALIDATED)

    def publish(self):
        """``validated -> published``: the only way a patch becomes visible."""
        return self.transition(PUBLISHED)

    def fail(self, reason):
        """Terminal failure, e.g. a range that is entirely below the band."""
        return self.transition(FAILED, reason=reason)

    def cancel(self, *, revision=None):
        """Terminal cancellation; ownership is released, nothing is published."""
        return self.transition(CANCELLED, revision=revision)

    @property
    def terminal(self):
        return self.state in TERMINAL


# ---------------------------------------------------------------------------
# Band refusal: an all-clipped patch is a failure, never a world
# ---------------------------------------------------------------------------


def band_assessment(elevations, *, mapping):
    """Count heights outside the band using the world's own mapping.

    Mirrors the producer's existing rule: a patch whose every sample falls on one
    side of the band is ``all_clipped`` and must be refused. That is an honest
    "this seed/origin is not land" answer, not something to clamp into a flat
    world and not evidence about any other seed.

    ``HeightMapping.quantize`` CLAMPS to the band, so it can never report a value
    outside it -- using it here would make every patch look in-band and turn this
    check into a no-op. The RAW voxel index is therefore computed with the same
    arithmetic, before clamping, exactly as ``clip_assessment`` does in the
    one-shot producer.
    """
    if not elevations:
        raise ProgressiveContractError("cannot assess an empty patch")
    low = int(mapping.height_min)
    high = int(mapping.height_max)
    metres_per_voxel = float(mapping.meters_per_voxel)
    sea_level = int(mapping.sea_level)
    baseline = float(mapping.baseline_elevation_m)
    if metres_per_voxel <= 0:
        raise ProgressiveContractError("meters_per_voxel must be positive")
    below = 0
    above = 0
    samples = 0
    for row in elevations:
        for metres in row:
            samples += 1
            value = int(math.floor(
                (float(metres) - baseline) / metres_per_voxel + sea_level + 0.5
            ))
            if value < low:
                below += 1
            elif value > high:
                above += 1
    all_clipped = below == samples or above == samples
    return {
        "samples": samples,
        "clipped_below_min": below,
        "clipped_above_max": above,
        "all_clipped": all_clipped,
        "bound": "min" if below == samples else ("max" if above == samples else None),
    }
