#!/usr/bin/env bash
# Verify that a compiled Trinecraft binary computes seed identities exactly as
# the interpreter does.
#
# Scope, stated honestly: this proves PARITY, not native arithmetic. Bender's
# --aot embeds a Janet VM image and compiles only eligible unboxed kernels; for
# this module it reports "native-lib 0 kernels", so every seeded line below is
# executed by the same bytecode the interpreter runs. The check that matters is
# that compiling and embedding the module does not change a single resolved
# seed -- not that a C kernel agrees.
#
# Usage:  tools/verify-world-seed-parity.sh
# Exit:   0 identical output, 1 a difference or a build failure.
#
# No network, no GPU, no game window, no new dependency.
set -uo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
probe="$here/test/world-seed-probe.janet"

# The sibling Janet checkout, resolved the same way run.sh resolves bender.
find_bender() {
  if [[ -n "${BENDER:-}" && -x "${BENDER:-}" ]]; then echo "$BENDER"; return 0; fi
  if [[ -x "$here/../../janet/build/bender" ]]; then echo "$here/../../janet/build/bender"; return 0; fi
  if command -v bender >/dev/null 2>&1; then command -v bender; return 0; fi
  return 1
}

bender="$(find_bender)" || { echo "verify: no bender interpreter found" >&2; exit 1; }
# janetconf.h and janet.h live beside the interpreter that produced it.
janetroot="$(cd "$(dirname "$bender")/.." && pwd)"
[[ -f "$janetroot/src/conf/janetconf.h" ]] || {
  echo "verify: $janetroot/src/conf/janetconf.h not found" >&2; exit 1; }

work="$(mktemp -d "${TMPDIR:-/tmp}/worldseed-parity.XXXXXX")"
trap 'rm -rf "$work"' EXIT

echo "verify: bender   $bender" >&2
echo "verify: janet    $janetroot" >&2
echo "verify: workdir  $work" >&2

"$bender" "$probe" > "$work/interp.txt" 2>/dev/null
interp_rc=$?
if [[ $interp_rc -ne 0 ]]; then
  echo "verify: interpreter run failed ($interp_rc)" >&2; exit 1
fi

# CPATH is what bender's cc invocation needs; it is not passed through the
# compiler command line, so setting it in the environment is the only lever.
CPATH="$janetroot/src/conf:$janetroot/src/include" \
C_INCLUDE_PATH="$janetroot/src/conf:$janetroot/src/include" \
JANET_NO_PROFILE=1 \
  "$bender" --aot "$probe" --native -o "$work/probe-native" > "$work/aot.log" 2>&1
if [[ ! -x "$work/probe-native" ]]; then
  echo "verify: AOT build failed; last lines of the log:" >&2
  grep -v '^native-skip' "$work/aot.log" | tail -20 >&2
  exit 1
fi

"$work/probe-native" > "$work/native.txt" 2>/dev/null
native_rc=$?
if [[ $native_rc -ne 0 ]]; then
  echo "verify: compiled binary run failed ($native_rc)" >&2; exit 1
fi

lines=$(wc -l < "$work/interp.txt" | tr -d ' ')
kernels=$(wc -l < "$work/probe-native-native/native-names.txt" 2>/dev/null | tr -d ' ')
echo "verify: $lines vector lines, $kernels native kernels" >&2

if diff -u "$work/interp.txt" "$work/native.txt" > "$work/diff.txt"; then
  echo "verify: PASS - interpreter and compiled binary are byte-identical" >&2
  exit 0
fi
echo "verify: FAIL - outputs differ" >&2
head -40 "$work/diff.txt" >&2
exit 1
