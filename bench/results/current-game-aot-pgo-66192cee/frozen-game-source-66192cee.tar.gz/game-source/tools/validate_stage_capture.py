#!/usr/bin/env python3
"""Read-only, stdlib-only integrity gate for terrain_stage_capture.py tensors.

Usage: python3 tools/validate_stage_capture.py DIR
Checks byte counts and SHA256 against DIR/stage-meta.json; stage names are
capture-order labels, NOT verified model identities or diffusion step indices.
"""

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import stat
import struct
import sys

MAX_METADATA_BYTES = 2 * 1024 * 1024
MAX_TENSOR_BYTES = 256 * 1024 * 1024
MAX_STAGES = 512
MAX_CONDITIONS = 32
MAX_NOISE_LABELS = 64
MAX_ERRORS = 16
NAME = re.compile(r"[A-Za-z][A-Za-z0-9_-]{0,63}\Z")
SHA = re.compile(r"[0-9a-f]{64}\Z")


def shape_bytes(shape):
    if not isinstance(shape, list) or not 1 <= len(shape) <= 8:
        raise ValueError("shape must have 1..8 dimensions")
    count = 1
    for dim in shape:
        if type(dim) is not int or dim <= 0:
            raise ValueError("shape dimensions must be positive integers")
        count *= dim
        if count > MAX_TENSOR_BYTES // 4:
            raise ValueError("tensor exceeds 256 MiB bound")
    return count * 4


def check_tensor(directory, filename, shape, digest, errors):
    try:
        expected_bytes = shape_bytes(shape)
    except ValueError as exc:
        errors.append(f"{filename}: {exc}")
        return
    if not isinstance(digest, str) or not SHA.fullmatch(digest):
        errors.append(f"{filename}: invalid sha256 metadata")
        return
    path = directory / filename
    try:
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode):
            errors.append(f"{filename}: missing regular file or symlink refused")
            return
        if info.st_size != expected_bytes:
            errors.append(f"{filename}: bytes {info.st_size} != expected {expected_bytes}")
            return
        hasher = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                hasher.update(chunk)
        if hasher.hexdigest() != digest:
            errors.append(f"{filename}: sha256 mismatch")
    except OSError as exc:
        errors.append(f"{filename}: {exc.strerror or type(exc).__name__}")


def check_noise(directory, name, labels, errors):
    """Legacy writer stores exact float32-derived labels, but no noise digest."""
    filename = f"{name}_noise.f32"
    if (not isinstance(labels, list) or not 1 <= len(labels) <= MAX_NOISE_LABELS
            or any(type(value) not in (int, float) or not math.isfinite(value)
                   for value in labels)):
        errors.append(f"{filename}: noise_labels must contain 1..64 finite numbers")
        return
    path = directory / filename
    try:
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode):
            errors.append(f"{filename}: missing regular file or symlink refused")
            return
        expected = len(labels) * 4
        if info.st_size != expected:
            errors.append(f"{filename}: bytes {info.st_size} != expected {expected}")
            return
        with path.open("rb") as stream:
            data = stream.read(expected)
        values = struct.unpack(f"<{len(labels)}f", data)
        if any(not math.isfinite(value) or value != label
               for value, label in zip(values, labels)):
            errors.append(f"{filename}: float32 values differ from noise_labels")
    except OSError as exc:
        errors.append(f"{filename}: {exc.strerror or type(exc).__name__}")


def validate(directory):
    errors = []
    checked = 0
    meta = directory / "stage-meta.json"
    try:
        info = meta.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_METADATA_BYTES:
            raise ValueError("metadata must be a regular file of at most 2 MiB")
        with meta.open("rb") as stream:
            document = json.load(stream)
    except (OSError, ValueError, UnicodeError) as exc:
        return {"ok": False, "checked": 0, "errors": [f"stage-meta.json: {exc}"]}
    stages = document.get("stages") if isinstance(document, dict) else None
    if not isinstance(stages, dict) or not 1 <= len(stages) <= MAX_STAGES:
        return {"ok": False, "checked": 0, "errors": ["stages must contain 1..512 entries"]}
    for name, entry in stages.items():
        if not isinstance(name, str) or not NAME.fullmatch(name):
            errors.append("invalid stage name (path traversal refused)")
            continue
        if not isinstance(entry, dict):
            errors.append(f"{name}: stage entry must be an object")
            continue
        for role in ("x", "out"):
            check_tensor(directory, f"{name}_{role}.f32", entry.get(f"{role}_shape"),
                         entry.get(f"{role}_sha256"), errors)
            checked += 1
        conds = entry.get("conds", [])
        if not isinstance(conds, list) or len(conds) > MAX_CONDITIONS:
            errors.append(f"{name}: conds must be a list of at most 32")
        else:
            for index, cond in enumerate(conds):
                cond = cond if isinstance(cond, dict) else {}
                check_tensor(directory, f"{name}_cond{index}.f32", cond.get("shape"),
                             cond.get("sha256"), errors)
                checked += 1
        has_noise = any(key in entry for key in
                        ("noise_labels", "noise_shape", "noise_sha256"))
        if has_noise:
            labels = entry.get("noise_labels")
            filename = f"{name}_noise.f32"
            if "noise_shape" in entry or "noise_sha256" in entry:
                shape = entry.get("noise_shape")
                if (not isinstance(labels, list) or not 1 <= len(labels) <= MAX_NOISE_LABELS
                        or any(type(value) not in (int, float) or not math.isfinite(value)
                               for value in labels)):
                    errors.append(f"{filename}: noise_labels must contain 1..64 finite numbers")
                else:
                    try:
                        if shape_bytes(shape) != len(labels) * 4:
                            errors.append(f"{filename}: noise_shape size differs from noise_labels")
                    except ValueError as exc:
                        errors.append(f"{filename}: {exc}")
                # New producer fields bind the bytes even if legacy labels agree;
                # retaining the exact-label check catches disagreement between both.
                check_tensor(directory, filename, shape, entry.get("noise_sha256"), errors)
            if "noise_shape" not in entry and "noise_sha256" not in entry:
                check_noise(directory, name, labels, errors)
            elif isinstance(labels, list) and 1 <= len(labels) <= MAX_NOISE_LABELS:
                check_noise(directory, name, labels, errors)
            checked += 1
    error_count = len(errors)
    return {"ok": not errors, "checked": checked,
            "errors": errors[:MAX_ERRORS], "error_count": error_count,
            "errors_truncated": max(0, error_count - MAX_ERRORS),
            "warning": "stage names are capture-order labels, not model/step identities"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path, help="existing stage capture directory")
    args = parser.parse_args(argv)
    result = validate(args.directory)
    print(json.dumps(result, sort_keys=True))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
