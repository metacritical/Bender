#!/usr/bin/env python3
"""BUILD-TIME ORACLE — per-model forward golden vectors. Never runtime.

Hooks each EDMUnet2D.forward in the REAL pipeline and records the exact
(inputs, output) pair that flowed, so the native ONNX path can be validated one
stage at a time with no geometry assumptions at all.

This deliberately does NOT reconstruct any stage. An earlier oracle reimplemented
the stages, got the window geometry wrong, and produced ocean where upstream has
land. Capturing real forward calls removes that entire class of error.

Also verifies that the published ONNX graphs and the PyTorch checkpoint share
weights, by comparing tensors by name.

Output: native/proof/fixtures/stage/<name>.f32 + stage-meta.json
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import struct
import sys

# NOTE: numpy (and torch) are imported inside main(), so this module -- and the
# pure naming helper below -- can be imported and unit-tested with the standard
# library alone. Torch imports are deliberately confined to main().

ORIGIN, SEED, SIZE = 100000, 12345, 64

#: Canonical stage order. `pipe` exposes exactly these three submodels.
STAGE_ORDER = ("coarse", "base", "decoder")


class StageCaptureError(RuntimeError):
    """A capture precondition failed; nothing is written."""


def stage_call_name(model, models, counters):
    """Name one forward call by the IDENTITY of the model it came from.

    The old hook used a single global counter and assumed calls arrive coarse,
    base, decoder in that order (`order[idx]`). The coarse stage alone runs 20
    forward calls, so the real sequence was mislabelled from the second call on:

        call 0  -> "coarse"    (correct by luck)
        call 1  -> "base"      (really coarse)
        call 2  -> "decoder"   (really coarse)
        call 3+ -> "extra3", "extra4", ...

    Every capture after the first was therefore attributed to the wrong stage, and
    the genuine base and decoder forwards were never captured at all.

    Stages are distinguished by object identity against the live submodels --
    never by call order, never by channel count or tensor shape -- because shape
    alone cannot separate two stages that happen to agree.

    ``counters`` is mutated in place and maps stage -> number of calls already
    seen. Returns a record::

        {"label": "coarse",              # first call of each stage
         "stage": "coarse",
         "stage_index": 0,
         "global_index": 0}

        {"label": "coarse-step-0001",    # subsequent calls
         "stage": "coarse",
         "stage_index": 1,
         "global_index": 1}

    The bare ``coarse``/``base``/``decoder`` labels are preserved so existing
    consumers reading ``<name>_x.f32`` keep working; later calls are suffixed.
    An unrecognised model raises before any caller writes anything.
    """
    stage = None
    for name in STAGE_ORDER:
        if models.get(name) is model:
            stage = name
            break
    if stage is None:
        raise StageCaptureError(
            "forward called on a model that is not one of the pipeline's "
            "submodels; refusing to guess a stage from call order or shape"
        )
    index = counters.get(stage, 0)
    counters[stage] = index + 1
    global_index = sum(counters.values()) - 1
    label = stage if index == 0 else "%s-step-%04d" % (stage, index)
    return {
        "label": label,
        "stage": stage,
        "stage_index": index,
        "global_index": global_index,
    }


def tensor_payload(values):
    """Pack a flat sequence of numbers as little-endian float32 bytes.

    Standard library only -- ``struct`` rounds to float32 exactly as
    ``numpy.asarray(values, "<f4")`` does -- so the byte layout a capture records
    can be produced and tested without importing numpy or torch.
    """
    flat = list(values)
    return struct.pack("<%df" % len(flat), *flat)


def write_payload(path, payload):
    """Write ``payload`` verbatim and return the SHA-256 of those exact bytes.

    The digest describes what is on disk, by construction: there is no separate
    encoding step that could disagree with the hash.
    """
    with open(path, "wb") as handle:
        handle.write(payload)
    return hashlib.sha256(payload).hexdigest()


def write_f32(path, array):
    """Write ``array`` as little-endian float32 and return the file's SHA-256.

    The digest is computed over the EXACT bytes written. ``numpy.tobytes()``
    returns native byte order, so on a big-endian host it would disagree with the
    little-endian file -- the metadata would describe bytes that are not on disk.
    Forcing ``dtype="<f4"`` first makes the hash and the file the same object,
    independent of host endianness.
    """
    import numpy as np

    data = np.asarray(array, dtype="<f4")
    return write_payload(path, data.tobytes(order="C"))


def prepare_output_dir(path):
    """Claim a NEW capture directory, exclusively.

    ``os.mkdir`` is used rather than ``makedirs``: it fails if the path exists at
    all, so the claim is atomic and two concurrent captures cannot both believe
    they own the same directory. An existing directory is refused even when it is
    EMPTY, because ownership cannot be proven after the fact -- and a populated
    one is refused because stale ``*_f32`` files from an earlier capture would
    silently disagree with the new ``stage-meta.json``.

    Callers must run this BEFORE importing torch or loading any model: a refusal
    after a multi-gigabyte init leaves the GPU held for nothing.
    """
    path = os.path.abspath(path)
    try:
        os.mkdir(path)
    except FileExistsError:
        raise StageCaptureError(
            "output path %s already exists; a capture writes to a NEW directory "
            "so it cannot mix with earlier stage files or race another capture"
            % path) from None
    except OSError as exc:
        raise StageCaptureError("cannot create %s: %s" % (path, exc)) from exc
    return path


def write_meta_atomic(path, meta):
    """Write stage-meta.json last, by rename, so a reader never sees a partial."""
    temp = path + ".tmp-%d" % os.getpid()
    with open(temp, "w") as f:
        json.dump(meta, f, indent=1)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, path)
    return path


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--origin", type=int, default=ORIGIN)
    ap.add_argument("--seed", type=int, default=SEED)
    ap.add_argument("--size", type=int, default=SIZE)
    ap.add_argument("--upstream", default="tmp/terrain-runtime/repo")
    ap.add_argument("--out", default="native/proof/fixtures/stage")
    args = ap.parse_args(argv)

    # Claim the output directory and validate every input BEFORE importing torch
    # or touching a model. A refusal here costs nothing; a refusal after the
    # multi-gigabyte init would hold the GPU for no reason.
    upstream = os.path.abspath(args.upstream)
    if not os.path.isdir(upstream):
        raise StageCaptureError("upstream checkout not found: %s" % upstream)
    if args.size <= 0:
        raise StageCaptureError("--size must be positive, got %d" % args.size)
    outdir = prepare_output_dir(args.out)

    import numpy as np  # noqa: F401 - confined to main; the helpers are stdlib-only
    import torch
    torch.set_num_threads(2)

    os.chdir(upstream)
    if upstream not in sys.path:
        sys.path.insert(0, upstream)

    from terrain_diffusion.inference.world_pipeline import WorldPipeline
    from terrain_diffusion.models.edm_unet import EDMUnet2D

    cap_coarse_list, cap_lat_list, cap_dec_list = [], [], []

    pipe = WorldPipeline.from_pretrained(
        "xandergos/terrain-diffusion-30m", seed=args.seed,
        latents_batch_size=1, log_mode="info", caching_strategy="direct")
    pipe.to("cpu")
    pipe.bind()

    # ---- hook every model forward -------------------------------------
    captured = {}
    cap_coarse_list, cap_lat_list, cap_dec_list = [], [], []
    orig_forward = EDMUnet2D.forward

    # Stages are identified by which submodel the call came from, not by call
    # order: the coarse stage alone runs 20 forwards, so a global counter mislabels
    # everything after the first.
    models = {
        "coarse": pipe.coarse_model,
        "base": pipe.base_model,
        "decoder": pipe.decoder_model,
    }
    counters = {}
    calls = []

    def hooked(self, x, noise_labels=None, conditional_inputs=None, **kw):
        out = orig_forward(self, x, noise_labels=noise_labels,
                           conditional_inputs=conditional_inputs, **kw)
        record = stage_call_name(self, models, counters)
        name = record["label"]
        calls.append(record)
        if name not in captured:
            captured[name] = {
                # Identity contract: which stage this is, and where it falls in
                # the global call sequence, so a consumer never infers either
                # from the label string.
                "stage": record["stage"],
                "call_index": record["global_index"],
                "x": x.detach().clone(),
                "noise_labels": None if noise_labels is None else noise_labels.detach().clone(),
                "cond": [c.detach().clone() for c in (conditional_inputs or [])],
                "out": out.detach().clone(),
            }
        return out

    def rec_coarse(self, ctx, *a, **k):
        cap_coarse_list.append(list(ctx))
        return orig_coarse_c(self, ctx, *a, **k)

    def rec_lat(self, ctxs, samples, conds, *a, **k):
        cap_lat_list.extend([list(c) for c in ctxs])
        return orig_lat_c(self, ctxs, samples, conds, *a, **k)

    def rec_dec(self, ctx, latents, *a, **k):
        cap_dec_list.append(list(ctx))
        return orig_dec_c(self, ctx, latents, *a, **k)

    orig_coarse_c = WorldPipeline._coarse_inference
    orig_lat_c = WorldPipeline._latent_inference
    orig_dec_c = WorldPipeline._decoder_inference
    WorldPipeline._coarse_inference = rec_coarse
    WorldPipeline._latent_inference = rec_lat
    WorldPipeline._decoder_inference = rec_dec

    EDMUnet2D.forward = hooked
    try:
        res = pipe.get(args.origin, args.origin,
                       args.origin + args.size, args.origin + args.size,
                       with_climate=False)
    finally:
        EDMUnet2D.forward = orig_forward
        WorldPipeline._coarse_inference = orig_coarse_c
        WorldPipeline._latent_inference = orig_lat_c
        WorldPipeline._decoder_inference = orig_dec_c

    meta = {
        "origin": args.origin, "seed": args.seed, "size": args.size,
        "device": "cpu", "torch_threads": 2,
        "upstream_revision": "e8dcb4b1a834ab2f6b1a6f5256ed7c9f2f3e8230",
        "model_revision": "9ef8030cb805b433b98ec25c5dddefbac07a9e26",
        "note": "real forward captures; no stage reconstructed",
        "stage_order": list(STAGE_ORDER),
        "stage_counts": dict(counters),
        "stages": {},
    }
    # Every forward call, in order, with its stage and per-stage index, so a
    # consumer never has to infer a stage from a filename.
    meta["calls"] = [
        {"label": c["label"], "stage": c["stage"],
         "stage_index": c["stage_index"], "global_index": c["global_index"]}
        for c in calls
    ]

    # Capture ALL contexts, not just the first call. The earlier version recorded
    # only cap["dec"]/cap["lat"][0], which is why the 4-window decoder batch
    # looked like a single window and stage comparison could not be complete.
    meta["all_contexts"] = {
        "coarse": [list(c) for c in cap_coarse_list],
        "latent": [list(c) for c in cap_lat_list],
        "decoder": [list(c) for c in cap_dec_list],
    }

    for name, cap in captured.items():
        x = cap["x"].numpy().astype(np.float32)
        out = cap["out"].numpy().astype(np.float32)
        # The digest returned here describes the bytes actually on disk.
        x_sha = write_f32(os.path.join(outdir, "%s_x.f32" % name), x)
        out_sha = write_f32(os.path.join(outdir, "%s_out.f32" % name), out)
        entry = {
            "stage": cap["stage"],
            "call_index": cap["call_index"],
            "x_shape": list(x.shape), "out_shape": list(out.shape),
            "x_sha256": x_sha,
            "out_sha256": out_sha,
            "x_stats": {"min": float(x.min()), "max": float(x.max()),
                        "mean": float(x.mean())},
            "out_stats": {"min": float(out.min()), "max": float(out.max()),
                          "mean": float(out.mean())},
        }
        if cap["noise_labels"] is not None:
            nl = cap["noise_labels"].numpy().astype(np.float32)
            # `noise_shape`/`noise_sha256` mirror the x/out fields: a consumer
            # verifies the FILE, not a re-derivation of the labels. Legacy
            # captures carry only `noise_labels`, which cannot be verified.
            entry["noise_shape"] = list(nl.shape)
            entry["noise_sha256"] = write_f32(
                os.path.join(outdir, "%s_noise.f32" % name), nl)
            entry["noise_labels"] = [float(v) for v in nl.ravel()]
        if cap["cond"]:
            conds = []
            for i, c in enumerate(cap["cond"]):
                a = c.numpy().astype(np.float32)
                conds.append({
                    "shape": list(a.shape),
                    "sha256": write_f32(
                        os.path.join(outdir, "%s_cond%d.f32" % (name, i)), a),
                })
            entry["conds"] = conds
        meta["stages"][name] = entry

    print(json.dumps({k: v for k, v in meta["stages"].items()}, indent=1))
    # Metadata goes last, atomically: every .f32 must exist before a reader can
    # see a meta file that references it.
    write_meta_atomic(os.path.join(outdir, "stage-meta.json"), meta)
    print("wrote", outdir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
