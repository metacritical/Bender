#!/usr/bin/env python3
"""BUILD-TIME ORACLE ONLY. Never runs at game runtime.

Dumps every stage of the real upstream terrain-diffusion pipeline at one fixed
query, so the native implementation can be compared numerically stage by stage
instead of judged by whether a tile "looks like land".

This file is deliberately outside native/proof: it is a fixture generator, not a
runtime component. Nothing in the shipped game imports it.

Forced to CPU with 2 threads: the parent process needs the GPU for UI work and
this oracle is a one-off measurement, not a performance claim. Provenance:
device=cpu, torch.set_num_threads(2).

Outputs go to native/proof/fixtures/oracle/ and are small (float32 arrays).
Heavy weights are never copied here.

Usage:
    PYTHONPATH=<upstream> python3 tools/terrain_oracle_dump.py [--origin N] [--seed N] [--size N]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys

import numpy as np

ORIGIN_DEFAULT = 100000
SEED_DEFAULT = 12345
SIZE_DEFAULT = 64


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--origin", type=int, default=ORIGIN_DEFAULT)
    ap.add_argument("--seed", type=int, default=SEED_DEFAULT)
    ap.add_argument("--size", type=int, default=SIZE_DEFAULT)
    ap.add_argument("--upstream", default="tmp/terrain-runtime/repo")
    ap.add_argument("--out", default="native/proof/fixtures/oracle")
    args = ap.parse_args(argv)

    import torch

    torch.set_num_threads(2)
    device = "cpu"

    upstream = os.path.abspath(args.upstream)
    outdir = os.path.abspath(args.out)
    os.makedirs(outdir, exist_ok=True)
    os.chdir(upstream)
    if upstream not in sys.path:
        sys.path.insert(0, upstream)

    from terrain_diffusion.inference.synthetic_map import make_synthetic_map_factory
    from terrain_diffusion.inference.world_pipeline import WorldPipeline
    from terrain_diffusion.common.model_utils import resolve_model_path, MODEL_PATHS
    from terrain_diffusion.models.edm_unet import EDMUnet2D

    origin, seed, size = args.origin, args.seed, args.size
    meta = {
        "origin": origin,
        "seed": seed,
        "size": size,
        "device": device,
        "torch_threads": 2,
        "upstream_revision": "e8dcb4b1a834ab2f6b1a6f5256ed7c9f2f3e8230",
        "purpose": "build-time oracle, never runtime",
    }

    # ---- AUTHORITATIVE: call the real pipeline -------------------------
    #
    # An earlier version of this script reimplemented each stage by hand and
    # produced elevation -1432..-728 m here. The real pipeline returns
    # +1081..+1785 m at the same query. The reimplementation was wrong: it
    # derived window indices that do not match what infinite_tensor actually
    # uses. Calling get() is the only trustworthy reference.
    #
    from terrain_diffusion.inference.world_pipeline import WorldPipeline

    pipe = WorldPipeline.from_pretrained(
        "xandergos/terrain-diffusion-30m", seed=seed,
        latents_batch_size=1, log_mode="info", caching_strategy="direct")
    pipe.to(device)
    pipe.bind()

    # Capture the stage tensors that actually flowed, so native can be compared
    # against real internal values rather than a reconstruction.
    cap = {}
    orig_lat = WorldPipeline._latent_inference
    orig_dec = WorldPipeline._decoder_inference
    orig_coarse = WorldPipeline._coarse_inference

    def cap_lat(self, ctxs, samples, conds, *a, **k):
        if "lat" not in cap:
            cap["lat"] = (list(ctxs), [c.detach().clone() for c in conds])
        return orig_lat(self, ctxs, samples, conds, *a, **k)

    def cap_dec(self, ctx, latents, *a, **k):
        if "dec" not in cap:
            cap["dec"] = (ctx, latents.detach().clone())
        return orig_dec(self, ctx, latents, *a, **k)

    def cap_coarse(self, ctx, *a, **k):
        cap.setdefault("coarse", []).append(ctx)
        return orig_coarse(self, ctx, *a, **k)

    WorldPipeline._latent_inference = cap_lat
    WorldPipeline._decoder_inference = cap_dec
    WorldPipeline._coarse_inference = cap_coarse
    try:
        res = pipe.get(origin, origin, origin + size, origin + size, with_climate=False)
    finally:
        WorldPipeline._latent_inference = orig_lat
        WorldPipeline._decoder_inference = orig_dec
        WorldPipeline._coarse_inference = orig_coarse

    elev = res["elev"].detach().numpy().astype(np.float32)
    elev.astype("<f4").tofile(os.path.join(outdir, "elevation_m.f32"))
    meta["elevation_shape"] = list(elev.shape)
    meta["elevation_stats"] = {"min": float(elev.min()), "max": float(elev.max()),
                               "mean": float(elev.mean())}
    meta["window_indices"] = {
        "coarse": [list(c) for c in cap.get("coarse", [])],
        "latent": [list(c) for c in cap.get("lat", ([],))[0]] if "lat" in cap else None,
        "decoder": list(cap["dec"][0]) if "dec" in cap else None,
    }
    if "lat" in cap:
        ci = cap["lat"][1][0].numpy().astype(np.float32)
        ci.astype("<f4").tofile(os.path.join(outdir, "cond_img_7x4x4.f32"))
        meta["cond_img_shape"] = list(ci.shape)
        meta["cond_img_stats"] = [
            {"min": float(ci[0, c].min()), "max": float(ci[0, c].max()),
             "mean": float(ci[0, c].mean())} for c in range(ci.shape[1])]
    if "dec" in cap:
        lat = cap["dec"][1].numpy().astype(np.float32)
        lat.astype("<f4").tofile(os.path.join(outdir, "latents.f32"))
        meta["latents_shape"] = list(lat.shape)

    # ---- hashes + write meta ------------------------------------------
    files = {}
    for name in sorted(os.listdir(outdir)):
        if name == "meta.json":
            continue
        p = os.path.join(outdir, name)
        files[name] = {"bytes": os.path.getsize(p), "sha256": sha256_of(p)}
    meta["files"] = files
    with open(os.path.join(outdir, "meta.json"), "w") as fh:
        json.dump(meta, fh, indent=1)

    print(json.dumps({
        "origin": origin, "seed": seed, "size": size,
        "elevation_range": [meta["elevation_stats"]["min"], meta["elevation_stats"]["max"]],
        "elevation_mean": meta["elevation_stats"]["mean"],
        "window_indices": meta.get("window_indices"),
        "cond_img_shape": meta.get("cond_img_shape"),
        "outdir": outdir,
    }, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
