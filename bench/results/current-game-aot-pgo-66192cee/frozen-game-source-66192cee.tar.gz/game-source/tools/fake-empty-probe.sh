#!/bin/sh
# A provider that exits 0 having written NOTHING. Used to prove the loop treats a
# successful exit with no artifact as a failure rather than an empty world.
exit 0
