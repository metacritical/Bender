"""Persistent progressive-world worker: one pipeline, patches published whole.

OWNERSHIP. This module owns exactly one thing: the process that turns a request
into a SEALED patch directory. It does not own the wire policy (the consumer
does), the contract (``progressive_world`` does), the tile format
(``scenic_terrain.encode_scenic_tile`` does) or the sampler
(``terrain_backend.load_sampler`` does). It is the seam that joins them, and it
adds no second definition of any of them.

WHAT IT WILL NOT DO
-------------------
* No model, GPU or window is touched at import. The pipeline is loaded LAZILY on
  the first request and then REUSED, so two requests cost one load.
* No legacy path is modified: ``terrain_backend``, ``scenic_terrain`` and
  ``terrain_cache`` are imported, never edited.
* Nothing is sampled per-tile or resampled per-patch. The world's mapping and
  address law are fixed at patch 0 and every patch obeys them.

THE HONEST LIMIT ON CANCELLATION
--------------------------------
The sampler is blocking and serial. A ``cancel`` line arriving WHILE a model call
is running CANNOT be observed until that call returns, so this worker never
claims to interrupt inference. Physical cancellation is the parent's job: it
owns the process and reaps it with TERM. A ``cancel`` line only records a token
as cancelled BETWEEN requests, and a stale epoch can never publish -- see
:class:`PatchState` in ``progressive_world``.

THE SEAM WITNESS IS A CONSISTENCY GATE, NOT A PROOF
---------------------------------------------------
Every patch samples its witness window (core 4x4 chunks plus one chunk of halo
per side, 96 px), stores ALL 36 witness tiles as TDS3, and publishes only the 16
core tiles. Where a neighbour is already published, the overlapping witness
tiles must be BYTE-IDENTICAL at the same global coordinates, header included.
That catches a pipeline whose output depends on request context. It does not
prove seams are invisible, and a quantized-height collision is not numerical
equality. The first patch has no neighbour, so it publishes without any adjacent
proof -- and says so.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import zlib

import progressive_world as pw
import scenic_terrain as st
import terrain_backend as tb
import terrain_cache as tc

#: Wire version this worker speaks. A different version is refused outright.
WIRE_VERSION = 1

#: Directory names inside a patch. ``witness`` is sampled evidence, never a
#: publishable tile set; ``tiles`` holds exactly the 16 core tiles.
TILES_DIR = "tiles"
WITNESS_DIR = "witness"
READY_NAME = "READY"
MANIFEST_NAME = "manifest.janet"
MANIFEST_JSON_NAME = "manifest.json"

#: Maximum bytes of one request line. A longer line is a protocol error.
MAX_LINE_BYTES = 512

#: Signed int32 range for patch coordinates.
_INT32_MIN = -(2 ** 31)
_INT32_MAX = 2 ** 31 - 1

#: The exact manifest key set the consumer expects: 14 keys, no more, no less.
MANIFEST_KEYS = (
    "format", "magic", "world-identity", "patch-identity", "anchor", "chunks",
    "tiles", "height-min", "height-max", "tiles-crc32", "sealed",
    "halo-chunks", "witness-tiles", "witness-crc32",
)


class WorkerError(RuntimeError):
    """A request, a patch or a witness violates the worker's contract."""


# ---------------------------------------------------------------------------
# Wire parsing: bounded, strict, no surprises
# ---------------------------------------------------------------------------


def _require_int32(value, name):
    if isinstance(value, bool) or not isinstance(value, int):
        raise WorkerError("%s must be an int" % name)
    if not _INT32_MIN <= value <= _INT32_MAX:
        raise WorkerError("%s is outside signed int32" % name)
    return value


def _require_token(value, name="token"):
    if not isinstance(value, str) or not value:
        raise WorkerError("%s must be a non-empty string" % name)
    if len(value) > 64:
        raise WorkerError("%s exceeds 64 characters" % name)
    allowed = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                  "abcdefghijklmnopqrstuvwxyz0123456789_.-")
    if any(char not in allowed for char in value):
        raise WorkerError("%s contains a disallowed character" % name)
    return value


def parse_line(raw):
    """Parse one request line into a validated record, or raise.

    Bounded before parsing: a line over :data:`MAX_LINE_BYTES` is refused without
    being handed to the JSON parser, so a malformed client cannot spend the
    worker's memory.
    """
    if isinstance(raw, bytes):
        if len(raw) > MAX_LINE_BYTES:
            raise WorkerError("request line exceeds %d bytes" % MAX_LINE_BYTES)
        try:
            raw = raw.decode("utf-8")
        except UnicodeDecodeError:
            raise WorkerError("request line is not UTF-8") from None
    elif isinstance(raw, str):
        if len(raw.encode("utf-8")) > MAX_LINE_BYTES:
            raise WorkerError("request line exceeds %d bytes" % MAX_LINE_BYTES)
    else:
        raise WorkerError("request line must be str or bytes")
    text = raw.strip()
    if not text:
        raise WorkerError("request line is empty")
    try:
        record = json.loads(text)
    except json.JSONDecodeError as exc:
        raise WorkerError("request line is not JSON: %s" % exc) from None
    if not isinstance(record, dict):
        raise WorkerError("request must be a JSON object")
    if record.get("v") != WIRE_VERSION:
        raise WorkerError(
            "wire version %r is not %d" % (record.get("v"), WIRE_VERSION)
        )
    kind = record.get("kind")
    if kind == "cancel":
        return {"kind": "cancel", "token": _require_token(record.get("token"))}
    if kind != "request":
        raise WorkerError("unknown request kind %r" % (kind,))
    world = record.get("world")
    try:
        tc._require_digest(world)
    except (TypeError, ValueError) as exc:
        raise WorkerError("world is not a digest: %s" % exc) from None
    epoch = record.get("epoch")
    if isinstance(epoch, bool) or not isinstance(epoch, int):
        raise WorkerError("epoch must be an int")
    if not 0 <= epoch <= _INT32_MAX:
        raise WorkerError("epoch is outside 0..%d" % _INT32_MAX)
    token = _require_token(record.get("token"))
    patch = record.get("patch")
    if not isinstance(patch, dict):
        raise WorkerError("patch must be an object")
    cx = _require_int32(patch.get("cx"), "patch.cx")
    cz = _require_int32(patch.get("cz"), "patch.cz")
    return {"kind": "request", "world": world, "epoch": epoch, "token": token,
            "cx": cx, "cz": cz}


def result_line(*, token, cx, cz, status, epoch, reason=None, artifact=None):
    """One result line. ``status`` is validated, published or error."""
    if status not in ("validated", "published", "error"):
        raise WorkerError("unknown result status %r" % (status,))
    record = {
        "v": WIRE_VERSION,
        "kind": "result",
        "token": token,
        "patch": {"cx": cx, "cz": cz},
        "status": status,
        "epoch": epoch,
        "reason": reason,
        "artifact": artifact,
    }
    return json.dumps(record, sort_keys=True) + "\n"


# ---------------------------------------------------------------------------
# Patch geometry
# ---------------------------------------------------------------------------


def patch_anchor(cx, cz, query=None):
    """The core patch's chunk-space anchor, by the contract's own floor rule."""
    record = pw.query_record(query or pw.default_query_record())
    return pw.anchor_pair(cx, cz, record["window_chunks"])


def witness_chunk_bounds(ax, az):
    """Inclusive chunk bounds of a patch's witness window (6x6 chunks).

    One chunk of halo on each side, so the witness covers
    ``[ax-1, ax+4] x [az-1, az+4]``.
    """
    return (ax - pw.HALO_CHUNKS, az - pw.HALO_CHUNKS,
            ax + pw.CORE_WINDOW_CHUNKS - 1 + pw.HALO_CHUNKS,
            az + pw.CORE_WINDOW_CHUNKS - 1 + pw.HALO_CHUNKS)


def core_chunk_bounds(ax, az):
    """Inclusive chunk bounds of the 4x4 core, the only publishable part."""
    return (ax, az, ax + pw.CORE_WINDOW_CHUNKS - 1, az + pw.CORE_WINDOW_CHUNKS - 1)


def witness_tile_count():
    """Witness tiles stored per patch: the whole 6x6 window."""
    return pw.WITNESS_WINDOW_CHUNKS * pw.WITNESS_WINDOW_CHUNKS


def core_tile_count():
    return pw.CORE_WINDOW_CHUNKS * pw.CORE_WINDOW_CHUNKS


def neighbour_anchors(ax, az):
    """The eight grid-legal neighbours of a patch anchor, in a fixed order.

    Core patches are anchored on a 4-chunk lattice, so a neighbour is exactly one
    core width away -- no globbing, no directory scan, nothing to guess.
    """
    step = pw.CORE_WINDOW_CHUNKS
    return [
        (ax - step, az), (ax + step, az),
        (ax, az - step), (ax, az + step),
        (ax - step, az - step), (ax - step, az + step),
        (ax + step, az - step), (ax + step, az + step),
    ]


def overlapping_cores(ax, az):
    """Chunks this patch's WITNESS shares with each neighbour's WITNESS.

    The comparison region is witness x witness, not witness x core: two witness
    windows one core apart intersect in ``2 * HALO_CHUNKS`` columns (2) by
    ``WITNESS_WINDOW_CHUNKS`` rows (6), which is the agreed 12 tiles for a
    cardinal neighbour. Both patches stored that whole window, so both sides of
    every comparison exist on disk.
    """
    step = pw.CORE_WINDOW_CHUNKS
    mine = witness_chunk_bounds(ax, az)
    core = {}
    for dx, dz in ((-step, 0), (step, 0), (0, -step), (0, step),
                   (-step, -step), (-step, step), (step, -step), (step, step)):
        nax, naz = ax + dx, az + dz
        theirs = witness_chunk_bounds(nax, naz)
        x0 = max(mine[0], theirs[0])
        x1 = min(mine[2], theirs[2])
        z0 = max(mine[1], theirs[1])
        z1 = min(mine[3], theirs[3])
        if x1 < x0 or z1 < z0:
            continue
        core[(nax, naz)] = [(cx, cz)
                            for cz in range(z0, z1 + 1)
                            for cx in range(x0, x1 + 1)]
    return core


# ---------------------------------------------------------------------------
# Sealed manifests
# ---------------------------------------------------------------------------


def _crc32_of_files(paths):
    """CRC-32 over the concatenation of ``paths`` in the order given."""
    crc = 0
    for path in paths:
        with open(path, "rb") as handle:
            crc = zlib.crc32(handle.read(), crc)
    return crc & 0xFFFFFFFF


def render_manifest(*, world_identity, patch_identity, anchor, chunks, tiles,
                    height_min, height_max, tiles_crc32, halo_chunks,
                    witness_tiles, witness_crc32):
    """The 14-key inert Janet manifest. Key set and order are fixed."""
    record = {
        "format": 4,
        "magic": "TDS4",
        "world-identity": world_identity,
        "patch-identity": patch_identity,
        "anchor": list(anchor),
        "chunks": chunks,
        "tiles": tiles,
        "height-min": height_min,
        "height-max": height_max,
        "tiles-crc32": tiles_crc32,
        "sealed": True,
        "halo-chunks": halo_chunks,
        "witness-tiles": witness_tiles,
        "witness-crc32": witness_crc32,
    }
    if tuple(record) != MANIFEST_KEYS:
        raise WorkerError("manifest key set drifted from the consumer contract")
    return record


def render_manifest_text(record):
    """The manifest as inert Janet data: one table literal, no evaluation."""
    parts = []
    for key in MANIFEST_KEYS:
        value = record[key]
        if isinstance(value, bool):
            parts.append(":%s %s" % (key, "true" if value else "false"))
        elif isinstance(value, int):
            parts.append(":%s %d" % (key, value))
        elif isinstance(value, str):
            parts.append(":%s %s" % (key, tb._janet_string(value)))
        elif isinstance(value, (list, tuple)):
            parts.append(":%s [%s]" % (key, " ".join(str(int(v)) for v in value)))
        else:
            raise WorkerError("manifest value for %r is not inert data" % (key,))
    return "{%s}\n" % " ".join(parts)


# ---------------------------------------------------------------------------
# The worker
# ---------------------------------------------------------------------------


class ProgressiveWorker:
    """One serial owner of one world root, with a lazily loaded pipeline.

    The sampler factory is injectable so the whole publish path can be exercised
    with a fake -- no model, no GPU, no window. In production it is
    ``terrain_backend.load_sampler`` and the load happens ONCE.
    """

    def __init__(self, root, *, world_identity, query=None, mapping=None,
                 climate=None, sampler_factory=None, sampler_identity=None,
                 sampler_layout=None, emit=None):
        self.root = os.fspath(root)
        tc._require_digest(world_identity)
        self.world_identity = world_identity
        if climate is None:
            climate = pw.climate_record(policy_version=None,
                                        container_version=None)
        if climate.get("policy_version") is not None:
            # The container exists, but no policy has been approved to read it in
            # a running world. Refusing is honest; silently ignoring the pin and
            # exporting elevation only would be a world that claims a policy it
            # does not honour.
            raise WorkerError(
                "climate policy %r is not supported yet: this worker exports "
                "elevation only and will not claim a climate carrier"
                % (climate.get("policy_version"),)
            )
        self.query = pw.query_record(query or pw.default_query_record())
        self.mapping = mapping if mapping is not None else tc.HEIGHT_MAPPING
        self.climate = climate
        self.sampler_factory = sampler_factory
        self.sampler_identity = sampler_identity
        self.sampler_layout = sampler_layout
        self.emit = emit
        self._sampler = None
        self.load_count = 0
        self.cancelled = set()
        self.published = []
        self.witnesses = []
        os.makedirs(os.path.join(self.root, "patches"), exist_ok=True)

    # -- sampler ---------------------------------------------------------

    def sampler(self):
        """Load the pipeline once and reuse it for every request."""
        if self._sampler is None:
            if self.sampler_factory is None:
                raise WorkerError(
                    "no sampler factory: this worker does not load a model by "
                    "itself, so a caller must supply one"
                )
            self._sampler = self.sampler_factory(
                self.sampler_identity, self.sampler_layout
            )
            self.load_count += 1
        return self._sampler

    def close(self):
        sampler, self._sampler = self._sampler, None
        closer = getattr(sampler, "close", None)
        if closer is not None:
            try:
                closer()
            except Exception:  # noqa: BLE001 - closing must not mask errors
                pass

    # -- sampling --------------------------------------------------------

    def witness_pixels(self, ax, az):
        """Half-open pixel bounds of the full witness window, halo included."""
        ppv = self.query["pixels_per_voxel"]
        halo = self.query["halo_voxels"]
        x0 = ax * tc.TILE_SIZE * ppv - halo * ppv
        z0 = az * tc.TILE_SIZE * ppv - halo * ppv
        span = self.query["witness_window_pixels"] * ppv
        return (x0, z0, x0 + span, z0 + span)

    def sample_witness(self, ax, az):
        """Sample the whole witness window ONCE; return ``{(cx, cz): metres}``.

        One model call per patch, covering core and halo together, so the halo
        values a neighbour is compared against come from the same query the core
        did rather than a second, differently-shaped call.

        Elevations are returned in METRES, not quantized: the band assessment must
        judge the raw values, because ``HeightMapping.quantize`` clamps and would
        make an all-clipped patch look in-band.
        """
        px0, pz0, px1, pz1 = self.witness_pixels(ax, az)
        sampler = self.sampler()
        matrix = tb._fetch(sampler, px0, pz0, px1, pz1)
        ppv = self.query["pixels_per_voxel"]
        out = {}
        cx0, cz0, cx1, cz1 = witness_chunk_bounds(ax, az)
        for cz in range(cz0, cz1 + 1):
            for cx in range(cx0, cx1 + 1):
                base_row = (cz - cz0) * tc.TILE_SIZE * ppv
                base_col = (cx - cx0) * tc.TILE_SIZE * ppv
                metres = []
                for z in range(tc.TILE_SIZE):
                    row = matrix[base_row + z * ppv]
                    for x in range(tc.TILE_SIZE):
                        metres.append(row[base_col + x * ppv])
                out[(cx, cz)] = metres
        return out

    # -- witnesses -------------------------------------------------------

    def _tile_bytes(self, cx, cz, heights):
        return st.encode_scenic_tile(
            cx, cz, heights,
            height_min=self.mapping.height_min,
            height_max=self.mapping.height_max,
        )

    def check_neighbours(self, ax, az, candidate_tiles):
        """Refuse a candidate whose overlap disagrees with a published neighbour.

        Comparison is by GLOBAL chunk coordinate and over the TILE BYTES, header
        included, so it is a real duplicate-sample check. It is not a seam proof:
        quantized heights can collide, and matching bytes cannot prove a seam is
        invisible.
        """
        compared = 0
        for (nax, naz), shared in overlapping_cores(ax, az).items():
            neighbour = os.path.join(
                self.root, "patches", "%d_%d" % (nax, naz)
            )
            if not os.path.isfile(os.path.join(neighbour, READY_NAME)):
                continue
            for cx, cz in shared:
                published_path = os.path.join(
                    neighbour, WITNESS_DIR, "%d_%d.tdh" % (cx, cz)
                )
                if not os.path.isfile(published_path):
                    # A sealed neighbour must carry its whole witness; a missing
                    # witness file is corruption, not an absent comparison.
                    raise WorkerError(
                        "sealed neighbour %d_%d has no witness tile %d_%d"
                        % (nax, naz, cx, cz)
                    )
                with open(published_path, "rb") as handle:
                    sealed = handle.read()
                if candidate_tiles[(cx, cz)] != sealed:
                    raise WorkerError(
                        "witness mismatch at global chunk (%d,%d) against "
                        "published neighbour (%d,%d): the pipeline's output is "
                        "not invariant across request context, so this candidate "
                        "is not published"
                        % (cx, cz, nax, naz)
                    )
                compared += 1
        return compared

    # -- publication -----------------------------------------------------

    def patch_directory(self, ax, az):
        return os.path.join(self.root, "patches", "%d_%d" % (ax, az))

    def publish(self, ax, az, *, patch_identity, epoch, token):
        """Build, seal and atomically publish one patch.

        Ordering is the point: everything is written into a sibling staging
        directory, ``READY`` is written INSIDE that sealed staging directory, and
        only then is the whole directory renamed into place. A reader therefore
        sees either no patch or a complete sealed patch -- never a half-written
        one.
        """
        tiles = self.sample_witness(ax, az)

        cx0, cz0, cx1, cz1 = core_chunk_bounds(ax, az)
        core = {(cx, cz): tiles[(cx, cz)]
                for cz in range(cz0, cz1 + 1)
                for cx in range(cx0, cx1 + 1)}
        assessment = pw.band_assessment(
            [core[key] for key in sorted(core)], mapping=self.mapping
        )
        if assessment["all_clipped"]:
            # An honest "not land here": the whole core is outside the band. No
            # patch is published and nothing is clamped into a flat seabed.
            raise WorkerError(
                "core is all_clipped at the %s bound; refusing to publish a flat "
                "patch" % assessment["bound"]
            )

        # Quantized height bytes are what the witness compares; build every tile
        # before writing anything, so a header or band failure cannot leave a
        # partially written staging directory behind.
        candidate = {}
        for (cx, cz), metres in tiles.items():
            heights = [self.mapping.quantize(value) for value in metres]
            candidate[(cx, cz)] = self._tile_bytes(cx, cz, heights)

        compared = self.check_neighbours(ax, az, candidate)

        final = self.patch_directory(ax, az)
        if os.path.exists(final):
            # Never overwrite a sealed patch. Re-publishing is a new decision, not
            # a side effect of a retried request.
            raise WorkerError("patch %d_%d is already sealed" % (ax, az))
        staging = final + ".staging-%s" % token
        if os.path.exists(staging):
            shutil.rmtree(staging)
        os.makedirs(os.path.join(staging, TILES_DIR))
        os.makedirs(os.path.join(staging, WITNESS_DIR))

        try:
            witness_coords = sorted(tiles, key=lambda pair: (pair[1], pair[0]))
            witness_paths = []
            for cx, cz in witness_coords:
                path = os.path.join(staging, WITNESS_DIR, "%d_%d.tdh" % (cx, cz))
                with open(path, "wb") as handle:
                    handle.write(candidate[(cx, cz)])
                witness_paths.append(path)
            core_coords = sorted(core, key=lambda pair: (pair[1], pair[0]))
            tile_paths = []
            for cx, cz in core_coords:
                path = os.path.join(staging, TILES_DIR, "%d_%d.tdh" % (cx, cz))
                with open(path, "wb") as handle:
                    handle.write(candidate[(cx, cz)])
                tile_paths.append(path)

            manifest = render_manifest(
                world_identity=self.world_identity,
                patch_identity=patch_identity,
                anchor=(ax, az),
                chunks=pw.CORE_WINDOW_CHUNKS,
                tiles=len(tile_paths),
                height_min=self.mapping.height_min,
                height_max=self.mapping.height_max,
                tiles_crc32=_crc32_of_files(tile_paths),
                halo_chunks=pw.HALO_CHUNKS,
                witness_tiles=len(witness_paths),
                witness_crc32=_crc32_of_files(witness_paths),
            )
            text = render_manifest_text(manifest).encode("utf-8")
            with open(os.path.join(staging, MANIFEST_NAME), "wb") as handle:
                handle.write(text)
            with open(os.path.join(staging, MANIFEST_JSON_NAME), "w") as handle:
                json.dump(manifest, handle, sort_keys=True, indent=2)
            # READY inside the sealed staging directory, last, so the rename
            # below publishes a directory that is already complete.
            with open(os.path.join(staging, READY_NAME), "w") as handle:
                json.dump({"ready": True, "sealed": True,
                           "patch": [ax, az], "epoch": epoch,
                           "compared-witness-tiles": compared}, handle,
                          sort_keys=True)
            os.replace(staging, final)
        except BaseException:
            if os.path.isdir(staging):
                shutil.rmtree(staging, ignore_errors=True)
            raise

        self.published.append((ax, az))
        self.witnesses.append(len(witness_paths))
        return {
            "anchor": [ax, az],
            "tiles": len(tile_paths),
            "witness_tiles": len(witness_paths),
            "compared": compared,
            "directory": final,
        }

    # -- request handling ------------------------------------------------

    def handle(self, request):
        """Handle one parsed request; return the result line.

        A cancel arriving here is only reachable BETWEEN requests. It marks the
        token cancelled and nothing else: this worker cannot interrupt a running
        model call, and it does not pretend to.
        """
        if request["kind"] == "cancel":
            self.cancelled.add(request["token"])
            return None
        token = request["token"]
        cx, cz = request["cx"], request["cz"]
        epoch = request["epoch"]
        ax, az = patch_anchor(cx, cz, self.query)
        try:
            if token in self.cancelled:
                return result_line(token=token, cx=cx, cz=cz, status="error",
                                   epoch=epoch,
                                   reason="cancelled before publication")
            patch_identity = pw.patch_identity(
                world_identity_digest=self.world_identity, cx=ax, cz=az,
                query=self.query, halo_chunks=pw.HALO_CHUNKS,
            )
            state = pw.PatchState(patch_identity, revision=epoch)
            state.claim(revision=epoch)
            state.validate()
            result = self.publish(ax, az, patch_identity=patch_identity,
                                  epoch=epoch, token=token)
            state.publish()
            return result_line(token=token, cx=cx, cz=cz, status="published",
                               epoch=state.revision, artifact=result["directory"])
        except (WorkerError, pw.ProgressiveContractError) as exc:
            return result_line(token=token, cx=cx, cz=cz, status="error",
                               epoch=epoch, reason=str(exc))
