#!/usr/bin/env python3
"""Read-only, bounded inventory of caller-listed native proof files.

Usage: python3 tools/native_artifact_inventory.py ROOT SPEC.json

SPEC.json (<= 1 MiB):
  {"version": 1, "artifacts": [
    {"role": "coarse-model", "path": "models/coarse.onnx",
     "notice": "notices/MODEL-LICENSE", "expected_sha256": "<64 hex>"}
  ]}

All paths are relative to ROOT. `expected_sha256` may be omitted to inventory
observed bytes without making an integrity assertion. Each artifact requires a
regular, confined notice file; this tool does not interpret its license terms,
validate numeric output, load libraries/models, or assert shipping readiness.
"""

import argparse
import hashlib
import json
import os
import re
import stat
import sys
from pathlib import Path

MAX_SPEC_BYTES = 1_048_576
MAX_ARTIFACTS = 128
MAX_FILE_BYTES = 8_000_000_000
MAX_NOTICE_BYTES = 1_048_576
CHUNK_BYTES = 1_048_576
ROLE = re.compile(r"[a-z][a-z0-9-]{0,63}\Z")
DIGEST = re.compile(r"[0-9a-f]{64}\Z")


class InventoryError(ValueError):
    """Malformed spec or missing/tampered artifact; never a readiness verdict."""


def _plain_file(path, limit):
    """Open a regular file with no symlink-following, checking opened identity."""
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    except OSError as exc:
        raise InventoryError(f"cannot open regular file: {path}: {exc.strerror}") from exc
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise InventoryError(f"not a bounded regular file: {path}")
        return fd, info.st_size
    except BaseException:
        os.close(fd)
        raise


def _relative_path(value):
    if not isinstance(value, str) or not value or len(value) > 512 or "\\" in value:
        raise InventoryError("path must be a bounded relative POSIX path")
    if any(part in ("", ".", "..") for part in value.split("/")) or value.startswith("/"):
        raise InventoryError(f"unsafe relative path: {value}")
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise InventoryError("path contains control characters")
    return value


def _confined(root, relative):
    path = root
    parts = _relative_path(relative).split("/")
    for part in parts[:-1]:
        path = path / part
        try:
            info = path.lstat()
        except OSError as exc:
            raise InventoryError(f"missing parent directory: {relative}") from exc
        if not stat.S_ISDIR(info.st_mode):
            raise InventoryError(f"parent is not a real directory: {relative}")
    target = path / parts[-1]
    try:
        info = target.lstat()
    except OSError as exc:
        raise InventoryError(f"missing file: {relative}") from exc
    if not stat.S_ISREG(info.st_mode):
        raise InventoryError(f"not a regular file: {relative}")
    return target


def _digest(path, limit):
    fd, size = _plain_file(path, limit)
    digest = hashlib.sha256()
    count = 0
    try:
        with os.fdopen(fd, "rb", closefd=True) as stream:
            while block := stream.read(CHUNK_BYTES):
                count += len(block)
                if count > limit:
                    raise InventoryError(f"file grew beyond byte limit: {path}")
                digest.update(block)
    except OSError as exc:
        raise InventoryError(f"cannot read file: {path}: {exc.strerror}") from exc
    if count != size:
        raise InventoryError(f"file size changed during inventory: {path}")
    return count, digest.hexdigest()


def inventory(root, spec_path):
    root = Path(root)
    if not root.is_dir() or root.is_symlink():
        raise InventoryError("root must be a real directory")
    root = root.resolve()
    spec_fd, _ = _plain_file(spec_path, MAX_SPEC_BYTES)
    with os.fdopen(spec_fd, "rb", closefd=True) as stream:
        raw = stream.read(MAX_SPEC_BYTES + 1)
    if len(raw) > MAX_SPEC_BYTES:
        raise InventoryError("spec exceeds byte limit")
    try:
        spec = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise InventoryError("spec is not valid JSON") from exc
    if not isinstance(spec, dict) or set(spec) != {"version", "artifacts"} or spec["version"] != 1 or isinstance(spec["version"], bool):
        raise InventoryError("unsupported inventory spec")
    entries = spec["artifacts"]
    if not isinstance(entries, list) or not 1 <= len(entries) <= MAX_ARTIFACTS:
        raise InventoryError("artifacts must contain 1..128 entries")
    seen_paths, seen_roles = set(), set()
    validated = []
    for entry in entries:
        if not isinstance(entry, dict) or not {"role", "path", "notice"} <= set(entry) or not set(entry) <= {"role", "path", "notice", "expected_sha256"}:
            raise InventoryError("artifact has missing or unknown fields")
        role, path, notice = entry["role"], entry["path"], entry["notice"]
        if not isinstance(role, str) or not ROLE.fullmatch(role) or role in seen_roles:
            raise InventoryError("invalid or duplicate artifact role")
        path, notice = _relative_path(path), _relative_path(notice)
        if path == notice or path in seen_paths or notice in seen_paths:
            raise InventoryError("duplicate artifact or notice path")
        seen_paths.add(path)
        seen_roles.add(role)
        expected = entry.get("expected_sha256")
        if expected is not None and (not isinstance(expected, str) or not DIGEST.fullmatch(expected)):
            raise InventoryError("expected_sha256 must be 64 lowercase hexadecimal characters")
        validated.append((role, path, notice, expected))
    for _, _, notice, _ in validated:
        if notice in seen_paths:
            raise InventoryError("notice reused as artifact path")
    results = []
    for role, path, notice, expected in validated:
        artifact_path = _confined(root, path)
        notice_path = _confined(root, notice)
        count, observed = _digest(artifact_path, MAX_FILE_BYTES)
        notice_count, notice_sha = _digest(notice_path, MAX_NOTICE_BYTES)
        if not notice_count:
            raise InventoryError(f"empty required notice: {notice}")
        if expected is not None and observed != expected:
            raise InventoryError(f"SHA-256 mismatch: {path}")
        results.append({"role": role, "path": path, "bytes": count,
                        "sha256": observed, "expected_sha256_matched": expected is not None,
                        "notice": notice, "notice_bytes": notice_count,
                        "notice_sha256": notice_sha})
    return {"version": 1, "validated_numeric": False,
            "shipping_ready": False, "artifacts": results}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", help="artifact root, never modified")
    parser.add_argument("spec", help="explicit bounded JSON inventory spec")
    args = parser.parse_args(argv)
    try:
        print(json.dumps(inventory(args.root, args.spec), sort_keys=True))
    except InventoryError as exc:
        print(f"inventory refused: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
