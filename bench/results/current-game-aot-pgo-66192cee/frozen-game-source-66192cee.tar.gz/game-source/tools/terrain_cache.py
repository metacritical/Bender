"""Deterministic height-tile cache and wire format for the TrineXraft terrain backend.

This module is deliberately dependency-free: only the Python standard library is
imported, so it can be vendored, unit-tested and reused by a future
InfiniteDiffusion adapter without pulling in numpy/torch.  It performs no
inference and no game wiring; it only turns already-sampled terrain heights
into identity-addressed, integrity-checked 16x16 tiles on disk.

Wire layout
-----------
Every tile file is exactly ``HEADER_STRUCT.size + TILE_PAYLOAD_SIZE`` = 48 + 256
= 308 bytes::

    offset  size  type     field
    0       4     char[4]  magic, always b"TDH2" (version 2 of this format)
    4       4     int32    chunk x  (signed, little endian)
    8       4     int32    chunk z  (signed, little endian)
    12      4     uint32   payload length, always 256
    16      4     uint32   CRC-32 (IEEE) of the payload
    20      32    byte[32] SHA-256 of the payload bytes (not of the header)
    52      256   uint8    height payload, x-fastest: index = x + 16 * z

Two integrity fields on purpose: Janet has no stdlib SHA-256 and no unsigned
32-bit arithmetic, so a Janet reader verifies CRC-32 (plus size, magic,
coordinates and the height band) while Python and the backend verify both.  The
CRC detects accidental corruption only; it is not a security boundary and makes
no cryptographic claim.  Magic ``TDH1`` (304-byte, SHA-256 only) is obsolete and
rejected on read.

The payload is one byte per column holding a *voxel height* in the inclusive
range ``HEIGHT_MIN..HEIGHT_MAX`` (4..60).  Row ``z`` occupies bytes
``16*z .. 16*z+15`` with ``x`` increasing inside the row, matching the engine's
``generate-from-heights`` x-fastest contract.  Coordinates in the header are the
signed chunk coordinates the payload was generated for; a decoder asked for a
different tile rejects the file instead of silently relocating data.

On disk a cache root holds one directory per generation identity::

    <cache_root>/<identity_digest>/manifest.json     immutable identity record
    <cache_root>/<identity_digest>/tiles/<cx>_<cz>.tdh

``identity_digest`` is the lowercase hex SHA-256 of the canonical (sorted-key,
separator-normalized) JSON encoding of the generation descriptor.  The manifest
pins that descriptor so a directory can never be reinterpreted as a different
generation; tile paths never contain hashes of local window positions, because
the identity must be independent of which tile is being queried.  The digest is
computed here and recorded in the manifest: Janet consumers must READ the
manifest string rather than reimplement SHA-256.

Quantization
------------
Heights are quantized only from globally defined values, never from any local
window statistic::

    voxel = floor(elevation_meters / meters_per_voxel + sea_level + 0.5)
    voxel = clamp(voxel, HEIGHT_MIN, HEIGHT_MAX)

``sea_level`` is the fixed transfer constant 28 and ``baseline_elevation_m`` is
0, so ``elevation_meters == 0`` lands on sea level 28.  Because the rule depends
only on the world elevation, the same world column quantizes identically no
matter which tile asks for it.

Coordinates
-----------
A tile-local column ``(x, z)`` with ``0 <= x, z < 16`` maps to the global voxel
columns ``wx = cx * 16 + x`` and ``wz = cz * 16 + z``.  Backend sample positions
multiply those by an integer ``pixels_per_voxel``: ``px = wx * pixels_per_voxel``
and ``pz = wz * pixels_per_voxel``.  Negative chunk coordinates are supported and
keep their sign throughout.

Integrity and durability
------------------------
Tile writes go to a temporary file in the destination directory, are fsynced,
and are then published with :func:`os.replace`, so a crash or a rejected encode
leaves any previous tile untouched and no partial file behind.  Manifests are
created exclusively via ``os.link`` and are immutable: a repeated write with
identical content succeeds, a different record raises :class:`ManifestConflict`.
Filesystems that cannot hard-link are refused with
:class:`AtomicPublishUnsupported` rather than approximated by writing the final
path directly, which could expose a truncated manifest to a reader.
"""

from __future__ import annotations

import dataclasses
import errno
import hashlib
import json
import math
import os
import struct
import tempfile
import zlib

TILE_SIZE = 16
TILE_PAYLOAD_SIZE = TILE_SIZE * TILE_SIZE

HEIGHT_MIN = 4
HEIGHT_MAX = 60
SEA_LEVEL = 28
METERS_PER_VOXEL = 50
BASELINE_ELEVATION_M = 0.0

# TDH2: magic, cx, cz, payload length, CRC-32(payload), SHA-256(payload).
# The CRC-32 exists because a Janet reader cannot compute SHA-256 without a
# hand-rolled implementation; it detects accidental corruption only and is
# explicitly not a security boundary. SHA-256 remains for both readers.
MAGIC = b"TDH2"
HEADER_STRUCT = struct.Struct("<4siiII32s")
TILE_BYTES = HEADER_STRUCT.size + TILE_PAYLOAD_SIZE
MANIFEST_NAME = "manifest.json"
TILE_DIR_NAME = "tiles"
TILE_SUFFIX = ".tdh"

FORMAT_VERSION = 2
UNITS = "meters"
# Required identity fields. pixels_per_voxel is REQUIRED rather than optional:
# it is part of what the backend samples, so a backend that forgets to pin it
# must not silently land on another generation's identity.
IDENTITY_KEYS = (
    "model",
    "model_revision",
    "upstream_revision",
    "seed",
    "sampler",
    "mapping",
    "pixels_per_voxel",
    "units",
    "dtype",
    "device",
)

# The sampler/inference geometry that provably changes terrain.  All are
# required inside the ``sampler`` descriptor field; window size or stride
# changes must never share an identity, since they change sampled output.
SAMPLER_GEOMETRY_KEYS = (
    "name",
    "steps",
    "guidance",
    "scheduler",
    "T",
    "coarse_window",
    "coarse_stride",
    "latent_window",
    "latent_stride",
    "decoder_window",
    "decoder_stride",
)

_INT32_MIN = -(2 ** 31)
_INT32_MAX = 2 ** 31 - 1

# Hard links unsupported here, so a manifest publish falls back to "xb" create.
# EACCES is deliberately absent: a permission failure is a real error, not a
# filesystem that lacks hard links.
_NO_HARDLINK_ERRNOS = frozenset(
    getattr(errno, name)
    for name in ("EPERM", "EOPNOTSUPP", "ENOTSUP", "EXDEV", "EMLINK")
    if hasattr(errno, name)
)


class TileCorruptError(ValueError):
    """A tile file failed magic, length, coordinate or digest validation."""


class ManifestConflict(RuntimeError):
    """An identity directory already pins a different generation descriptor."""


class AtomicPublishUnsupported(RuntimeError):
    """The filesystem cannot publish a file atomically and exclusively.

    Raised instead of falling back to a direct write of the final path, which
    could leave a truncated manifest visible to a reader.
    """


def _require_int(value, name, *, minimum=None, maximum=None):
    """Return ``value`` as an int, rejecting bools and non-integral floats."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError("%s must be an int, not %r" % (name, type(value).__name__))
    if minimum is not None and value < minimum:
        raise ValueError("%s must be >= %d, got %d" % (name, minimum, value))
    if maximum is not None and value > maximum:
        raise ValueError("%s must be <= %d, got %d" % (name, maximum, value))
    return value


def _require_chunk_coord(cx, cz):
    """Validate a signed int32 chunk coordinate pair."""
    return (
        _require_int(cx, "cx", minimum=_INT32_MIN, maximum=_INT32_MAX),
        _require_int(cz, "cz", minimum=_INT32_MIN, maximum=_INT32_MAX),
    )


def _require_digest(digest):
    """Validate a 64-character lowercase hex identity digest."""
    if not isinstance(digest, str):
        raise TypeError("identity digest must be a str")
    if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        raise ValueError("identity digest must be 64 lowercase hex characters")
    return digest


def _require_pixels_per_voxel(pixels_per_voxel):
    return _require_int(pixels_per_voxel, "pixels_per_voxel", minimum=1)


def _require_float(value, name):
    """Return ``value`` as a finite float, rejecting bools and NaN/infinities."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError("%s must be a real number" % name)
    try:
        value = float(value)
    except OverflowError:
        raise ValueError("%s is too large to represent as a float" % name)
    if value != value:
        raise ValueError("%s must not be NaN" % name)
    if value in (float("inf"), float("-inf")):
        raise ValueError("%s must be finite" % name)
    return value


@dataclasses.dataclass(frozen=True)
class HeightMapping:
    """The global elevation-to-voxel transfer function.

    Every field is a world-wide constant, never a per-tile statistic, so the
    same world column quantizes identically regardless of which tile asks.
    """

    meters_per_voxel: float = METERS_PER_VOXEL
    sea_level: int = SEA_LEVEL
    baseline_elevation_m: float = BASELINE_ELEVATION_M
    height_min: int = HEIGHT_MIN
    height_max: int = HEIGHT_MAX

    def __post_init__(self):
        meters = _require_float(self.meters_per_voxel, "meters_per_voxel")
        if meters <= 0:
            raise ValueError("meters_per_voxel must be positive")
        low = _require_int(self.height_min, "height_min")
        high = _require_int(self.height_max, "height_max")
        if low > high:
            raise ValueError("height_min must not exceed height_max")
        for name, value in (
            ("meters_per_voxel", meters),
            ("sea_level", _require_int(self.sea_level, "sea_level")),
            (
                "baseline_elevation_m",
                _require_float(self.baseline_elevation_m, "baseline_elevation_m"),
            ),
            ("height_min", low),
            ("height_max", high),
        ):
            object.__setattr__(self, name, value)

    def quantize(self, elevation_meters):
        """``floor((elevation - baseline) / meters + sea_level + 0.5)``, clamped.

        Rejects NaN, infinities, bools, non-numeric values, and any input whose
        transfer overflows: an elevation or ratio outside the exact IEEE-double
        range raises :class:`ValueError` rather than saturating, so callers can
        never mistake an out-of-range sample for a real terrain height.
        """
        elevation = _require_float(elevation_meters, "elevation_meters")
        steps = (elevation - self.baseline_elevation_m) / self.meters_per_voxel
        if steps != steps:
            raise ValueError("elevation transfer produced NaN")
        if steps in (float("inf"), float("-inf")):
            raise ValueError("elevation transfer overflowed the voxel grid")
        try:
            height = math.floor(steps + self.sea_level + 0.5)
        except OverflowError:
            raise ValueError("elevation transfer overflowed the voxel grid") from None
        return max(self.height_min, min(self.height_max, height))


HEIGHT_MAPPING = HeightMapping()


def quantize_height(elevation_meters, mapping=HEIGHT_MAPPING):
    """Quantize a global elevation in metres to an integer voxel height.

    Binds the fixed global transfer (:data:`HEIGHT_MAPPING`: sea level 28,
    50 metres per voxel, baseline 0, band 4..60).  NaN, infinities, bools and
    non-numeric values are rejected rather than coerced.
    """
    return mapping.quantize(elevation_meters)


def world_voxel(cx, cz, x, z):
    """Map a tile-local column to global voxel columns ``(wx, wz)``."""
    cx, cz = _require_chunk_coord(cx, cz)
    x = _require_int(x, "x", minimum=0, maximum=TILE_SIZE - 1)
    z = _require_int(z, "z", minimum=0, maximum=TILE_SIZE - 1)
    return (cx * TILE_SIZE + x, cz * TILE_SIZE + z)


def world_pixel(cx, cz, x, z, pixels_per_voxel):
    """Map a tile-local column to backend pixel coordinates ``(px, pz)``."""
    pixels_per_voxel = _require_pixels_per_voxel(pixels_per_voxel)
    wx, wz = world_voxel(cx, cz, x, z)
    return (wx * pixels_per_voxel, wz * pixels_per_voxel)


def _canonical_json(value):
    """Canonical JSON bytes: sorted keys, compact separators, no NaN."""
    try:
        return json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
            allow_nan=False,
        ).encode("ascii")
    except (TypeError, ValueError) as exc:
        raise ValueError("generation descriptor is not canonical JSON: %s" % exc)


def _format_block():
    """The fixed wire/transfer constants bound into every identity."""
    mapping = HEIGHT_MAPPING
    return {
        "version": FORMAT_VERSION,
        "magic": MAGIC.decode("ascii"),
        "tile_size": TILE_SIZE,
        "height_min": HEIGHT_MIN,
        "height_max": HEIGHT_MAX,
        # Pin the default quantization transfer so two runs cannot share an
        # identity while mapping metres to voxels differently. A descriptor
        # using a custom HeightMapping must say so in its own "mapping" value.
        "sea_level": mapping.sea_level,
        "meters_per_voxel": mapping.meters_per_voxel,
        "baseline_elevation_m": mapping.baseline_elevation_m,
    }


def _require_text(value, name):
    """Require a non-empty string identity field."""
    if not isinstance(value, str) or not value:
        raise TypeError("descriptor %s must be a non-empty str" % name)
    return value


def _require_mapping_or_text(value, name):
    """Require a string, or a dict of plain data, for mapping pins."""
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        if not value:
            raise ValueError("descriptor %s must not be empty" % name)
        return value
    raise TypeError("descriptor %s must be a non-empty str or a dict" % name)


def _require_sampler(value, name):
    """Require the full pinned sampler/inference geometry as a non-empty dict.

    A bare string such as ``"DPM++"`` does not pin window size, stride or
    sampler defaults, so two runs that differ only there would otherwise share
    an identity and read each other's tiles.  The required fields are the ones
    that provably change handed-back terrain; anything else the backend pins is
    hashed as given.
    """
    if not isinstance(value, dict) or not value:
        raise TypeError(
            "descriptor %s must be a non-empty dict pinning the sampler and "
            "window geometry" % name
        )
    for key in SAMPLER_GEOMETRY_KEYS:
        if key not in value:
            raise ValueError("descriptor %s is missing geometry field %r" % (name, key))
    return value


# Per-field validators; a field absent from this map takes plain text.
_FIELD_VALIDATORS = {
    "seed": lambda value, name: _require_int(value, name),
    "pixels_per_voxel": lambda value, name: _require_pixels_per_voxel(value),
    "sampler": _require_sampler,
    "mapping": _require_mapping_or_text,
}


def _validated_caller_fields(descriptor):
    """Type-check a caller descriptor (which must not carry ``format``).

    ``seed`` is a true int, ``pixels_per_voxel`` a positive int, ``sampler`` a
    non-empty dict carrying :data:`SAMPLER_GEOMETRY_KEYS`, ``mapping`` a string
    or dict, and the remaining fields non-empty strings.
    """
    if not isinstance(descriptor, dict):
        raise TypeError("generation descriptor must be a dict")
    if "format" in descriptor:
        raise ValueError("descriptor key 'format' is reserved for the wire format")
    missing = [key for key in IDENTITY_KEYS if key not in descriptor]
    if missing:
        raise ValueError("generation descriptor is missing: %s" % ", ".join(missing))
    for key in IDENTITY_KEYS:
        validate = _FIELD_VALIDATORS.get(key, _require_text)
        validate(descriptor[key], key)
    return dict(descriptor)


def identity_descriptor(descriptor):
    """Return the full descriptor used for identity hashing.

    The caller's fields are preserved verbatim and no local window position is
    added or normalized away; only the fixed wire-format constants are attached
    so two incompatible layouts can never share an identity directory.

    Extra keys beyond :data:`IDENTITY_KEYS` are hashed as given, which is how
    sampling geometry is pinned: pass e.g. ``geometry={"T": 2, "coarse": ...}``
    and it becomes part of the identity.  ``format`` is reserved for this module
    and may not be supplied by the caller.
    """
    record = _validated_caller_fields(descriptor)
    record["format"] = _format_block()
    return record


def normalize_identity(identity):
    """Validate a stored identity record, as found in a manifest.

    Unlike :func:`identity_descriptor` this accepts a record that already
    carries ``format``, but requires that block to equal the current one, so a
    manifest written by a different wire format or transfer cannot pass.
    """
    if not isinstance(identity, dict):
        raise TypeError("identity must be a dict")
    stored_format = identity.get("format")
    if not isinstance(stored_format, dict):
        raise ValueError("identity is missing its format block")
    if stored_format != _format_block():
        raise ValueError("identity format block does not match this module")
    fields = {key: value for key, value in identity.items() if key != "format"}
    return identity_descriptor(fields)


def identity_digest(descriptor):
    """SHA-256 hex digest of the canonical generation descriptor."""
    return hashlib.sha256(_canonical_json(identity_descriptor(descriptor))).hexdigest()


def _payload_bytes(heights):
    """Validate and pack 256 x-fastest integer heights into payload bytes."""
    if isinstance(heights, (bytes, bytearray, memoryview)):
        sequence = list(bytes(heights))
    elif isinstance(heights, (list, tuple)):
        sequence = heights
    else:
        raise TypeError("heights must be a bytes-like object or a list/tuple")
    if len(sequence) != TILE_PAYLOAD_SIZE:
        raise ValueError(
            "heights must contain %d values, got %d"
            % (TILE_PAYLOAD_SIZE, len(sequence))
        )
    payload = bytearray(TILE_PAYLOAD_SIZE)
    for index, height in enumerate(sequence):
        if isinstance(height, bool) or not isinstance(height, int):
            raise TypeError(
                "height[%d] must be an int, not %r" % (index, type(height).__name__)
            )
        if not HEIGHT_MIN <= height <= HEIGHT_MAX:
            raise ValueError(
                "height[%d] must be in %d..%d, got %d"
                % (index, HEIGHT_MIN, HEIGHT_MAX, height)
            )
        payload[index] = height
    return bytes(payload)


def encode_tile(cx, cz, heights):
    """Encode one tile: ``<4siiII32s`` header followed by the 256-byte payload."""
    cx, cz = _require_chunk_coord(cx, cz)
    payload = _payload_bytes(heights)
    crc = zlib.crc32(payload) & 0xFFFFFFFF
    digest = hashlib.sha256(payload).digest()
    header = HEADER_STRUCT.pack(MAGIC, cx, cz, len(payload), crc, digest)
    return header + payload


def decode_tile(data, cx, cz, *, height_min=None, height_max=None):
    """Decode one tile, rejecting corruption and coordinate mismatch.

    Returns ``(cx, cz, payload)`` where ``payload`` is the raw 256-byte
    x-fastest height payload.  Rejected: wrong type, truncation, trailing bytes,
    unknown magic, mismatched expected coordinates, a payload length other than
    256, a CRC-32 or payload digest that does not match the header, and
    out-of-range heights.
    """
    expected_cx, expected_cz = _require_chunk_coord(cx, cz)
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("tile data must be bytes-like")
    data = bytes(data)
    if len(data) < HEADER_STRUCT.size:
        raise TileCorruptError(
            "tile truncated: %d bytes, header needs %d"
            % (len(data), HEADER_STRUCT.size)
        )
    magic, file_cx, file_cz, payload_length, crc, digest = HEADER_STRUCT.unpack_from(
        data
    )
    if magic != MAGIC:
        raise TileCorruptError(
            "bad tile magic %r, expected %r (TDH1 is obsolete)" % (magic, MAGIC)
        )
    if payload_length != TILE_PAYLOAD_SIZE:
        raise TileCorruptError(
            "bad payload length %d, expected %d"
            % (payload_length, TILE_PAYLOAD_SIZE)
        )
    if len(data) != TILE_BYTES:
        raise TileCorruptError(
            "tile length %d, expected %d (truncated or trailing bytes)"
            % (len(data), TILE_BYTES)
        )
    if (file_cx, file_cz) != (expected_cx, expected_cz):
        raise TileCorruptError(
            "tile coordinates (%d,%d) do not match requested (%d,%d)"
            % (file_cx, file_cz, expected_cx, expected_cz)
        )
    payload = data[HEADER_STRUCT.size:]
    if zlib.crc32(payload) & 0xFFFFFFFF != crc:
        raise TileCorruptError("payload CRC-32 does not match header")
    if hashlib.sha256(payload).digest() != digest:
        raise TileCorruptError("payload SHA-256 does not match header")
    low = HEIGHT_MIN if height_min is None else height_min
    high = HEIGHT_MAX if height_max is None else height_max
    for index, height in enumerate(payload):
        if not low <= height <= high:
            raise TileCorruptError(
                "height[%d]=%d outside %d..%d" % (index, height, low, high)
            )
    return file_cx, file_cz, payload


def cache_dir(cache_root, digest):
    """Return ``<cache_root>/<identity_digest>``."""
    _require_digest(digest)
    return os.path.join(os.fspath(cache_root), digest)


def tile_path(cache_root, digest, cx, cz):
    """Return the deterministic path of one tile under an identity directory."""
    cx, cz = _require_chunk_coord(cx, cz)
    return os.path.join(
        cache_dir(cache_root, digest),
        TILE_DIR_NAME,
        "%d_%d%s" % (cx, cz, TILE_SUFFIX),
    )


def _manifest_bytes(descriptor, digest):
    record = {
        "identity": identity_descriptor(descriptor),
        "identity_digest": digest,
        "payload_bytes": TILE_PAYLOAD_SIZE,
        "tile_bytes": TILE_BYTES,
    }
    return _canonical_json(record) + b"\n"


def _publish_exclusive(temp_path, path):
    """Publish ``temp_path`` at ``path`` without ever overwriting it.

    ``os.link`` is the only primitive that creates a directory entry atomically
    and refuses an existing destination.  Filesystems that cannot hard-link are
    therefore REFUSED rather than approximated: the exclusive-create fallback
    wrote the final path directly, so a crash or short write could expose a
    partial manifest at the destination.  Failing closed keeps the guarantee.
    """
    try:
        os.link(temp_path, path)
    except OSError as exc:
        if exc.errno in _NO_HARDLINK_ERRNOS:
            raise AtomicPublishUnsupported(
                "filesystem cannot hard-link %r into place, so an atomic "
                "exclusive publish is impossible here: %s"
                % (path, exc.strerror or exc)
            ) from exc
        raise


def _atomic_publish(path, data, *, replace):
    """Write ``data`` to ``path`` via a same-directory temporary file."""
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)
    fd, temp_path = tempfile.mkstemp(prefix=".tmp-", dir=directory)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        if replace:
            os.replace(temp_path, path)
        else:
            _publish_exclusive(temp_path, path)
    finally:
        # os.replace consumed the temporary file; only an unconsumed one remains.
        if os.path.exists(temp_path):
            os.unlink(temp_path)


def write_manifest(cache_root, descriptor, digest=None):
    """Create the immutable identity manifest, refusing a conflicting one.

    Returns the identity digest.  Writing the same descriptor twice is a no-op;
    writing a different descriptor into an existing identity directory raises
    :class:`ManifestConflict`.

    The existing manifest is always re-validated in full (re-hashed identity,
    pinned counts, no extra fields) before this treats a repeat write as a
    no-op, so a tampered manifest surfaces here instead of being trusted.
    """
    computed = identity_digest(descriptor)
    if digest is not None and digest != computed:
        raise ValueError("supplied digest does not match descriptor")
    path = os.path.join(cache_dir(cache_root, computed), MANIFEST_NAME)
    expected = identity_descriptor(descriptor)

    if os.path.exists(path):
        _require_pinned_identity(cache_root, computed, expected)
        return computed

    data = _manifest_bytes(descriptor, computed)
    try:
        _atomic_publish(path, data, replace=False)
    except FileExistsError:
        # Lost a race with a concurrent writer: accept only an identical pin.
        _require_pinned_identity(cache_root, computed, expected)
    return computed


def _require_pinned_identity(cache_root, digest, expected):
    """Raise :class:`ManifestConflict` unless the manifest pins ``expected``."""
    existing = read_manifest(cache_root, digest)["identity"]
    if existing != expected:
        raise ManifestConflict(
            "identity directory %s already pins a different descriptor" % digest
        )


def read_manifest(cache_root, digest):
    """Read and validate the manifest pinned to an identity directory."""
    digest = _require_digest(digest)
    path = os.path.join(cache_dir(cache_root, digest), MANIFEST_NAME)
    with open(path, "rb") as handle:
        raw = handle.read()
    try:
        record = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ManifestConflict("manifest is not valid JSON: %s" % exc)
    if not isinstance(record, dict):
        raise ManifestConflict("manifest root must be an object")
    if record.get("identity_digest") != digest:
        raise ManifestConflict(
            "manifest digest %r does not match directory %r"
            % (record.get("identity_digest"), digest)
        )
    identity = record.get("identity")
    if not isinstance(identity, dict):
        raise ManifestConflict("manifest identity must be an object")
    try:
        canonical_identity = _canonical_json(normalize_identity(identity))
    except (TypeError, ValueError) as exc:
        raise ManifestConflict("manifest identity is malformed: %s" % exc)
    if _canonical_json(identity) != canonical_identity:
        raise ManifestConflict("manifest identity is not in canonical form")
    if hashlib.sha256(canonical_identity).hexdigest() != digest:
        raise ManifestConflict("manifest identity does not hash to its directory")
    if record.get("tile_bytes") != TILE_BYTES:
        raise ManifestConflict("manifest tile_bytes does not match this module")
    if record.get("payload_bytes") != TILE_PAYLOAD_SIZE:
        raise ManifestConflict("manifest payload_bytes does not match this module")
    extra = set(record) - {"identity", "identity_digest", "payload_bytes", "tile_bytes"}
    if extra:
        raise ManifestConflict("manifest has unexpected fields: %s" % sorted(extra))
    return record


def write_tile(cache_root, digest, cx, cz, heights):
    """Atomically write one tile under an existing identity.

    The identity manifest must already exist: a tile is only meaningful inside
    the generation it was produced for, so this refuses to create an orphan
    directory that :func:`read_tile` would then reject.  A failed encode raises
    before the destination is touched.
    """
    digest = _require_digest(digest)
    cx, cz = _require_chunk_coord(cx, cz)
    read_manifest(cache_root, digest)
    data = encode_tile(cx, cz, heights)
    path = tile_path(cache_root, digest, cx, cz)
    _atomic_publish(path, data, replace=True)
    return path


def read_tile(cache_root, digest, cx, cz):
    """Read and verify one tile, including the identity manifest that pins it."""
    digest = _require_digest(digest)
    cx, cz = _require_chunk_coord(cx, cz)
    read_manifest(cache_root, digest)
    with open(tile_path(cache_root, digest, cx, cz), "rb") as handle:
        data = handle.read()
    return decode_tile(data, cx, cz)


__all__ = [
    "AtomicPublishUnsupported",
    "BASELINE_ELEVATION_M",
    "FORMAT_VERSION",
    "HEADER_STRUCT",
    "HEIGHT_MAPPING",
    "HEIGHT_MAX",
    "HEIGHT_MIN",
    "HeightMapping",
    "IDENTITY_KEYS",
    "MAGIC",
    "MANIFEST_NAME",
    "METERS_PER_VOXEL",
    "ManifestConflict",
    "SAMPLER_GEOMETRY_KEYS",
    "SEA_LEVEL",
    "TILE_BYTES",
    "TILE_PAYLOAD_SIZE",
    "TILE_SIZE",
    "TileCorruptError",
    "cache_dir",
    "decode_tile",
    "encode_tile",
    "identity_descriptor",
    "identity_digest",
    "normalize_identity",
    "quantize_height",
    "read_manifest",
    "read_tile",
    "tile_path",
    "world_pixel",
    "world_voxel",
    "write_manifest",
    "write_tile",
]
