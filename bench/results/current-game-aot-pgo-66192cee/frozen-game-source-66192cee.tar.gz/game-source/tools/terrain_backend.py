"""Terrain Diffusion backend for TrineXraft: sample, quantize, publish tiles.

This module is the ONLY place in the repository that talks to a diffusion model.
It is deliberately inert on import: model dependencies (``torch``, ``numpy``,
``terrain_diffusion``) are imported lazily inside :func:`load_sampler`, so
``--help``, ``descriptor`` and the unit tests run with the Python standard
library alone.  Nothing here generates terrain at import time and nothing here
downloads weights at generation time.

What it does
------------
For a chunk coordinate ``(cx, cz)`` it samples one *point-lattice* column per
voxel and publishes a 308-byte TDH2 tile.  The sampled world pixel of voxel
``(x, z)`` is::

    px = origin_x + (cx * 16 + x) * pixels_per_voxel
    pz = origin_z + (cz * 16 + z) * pixels_per_voxel

so the voxel grid is exactly the region corners at ``pixels_per_voxel`` spacing,
shifted by the world origin, and a column's elevation is a pure function of its
world pixel coordinate.  No averaging, no interpolation, and never a tile-local
statistic: a world column means the same thing no matter which tile asked.

Canonical query windows
-----------------------
Queries are *not* anchored to the request.  A window is chunk-aligned and
anchored to the global grid, ``floor(cx / window_chunks) * window_chunks``, and it
is always fetched whole.  The pixels the model sees therefore depend only on the
window index -- never on which other chunks were requested alongside it.  An
isolated chunk, the same chunk inside a 5x5 batch, and the same chunk in a
differently-ordered batch all send the model the *identical* rectangle.

That is a correctness property, not an optimisation: the previous
request-anchored window fed the model different rectangles for the same chunk
depending on batch composition, which left windowed-cache and edge handling
request-dependent.  ``window_chunks``, ``origin_pixels``, ``max_samples`` and the
strategy revision are all hashed into the identity, so a cache baked under one
window geometry can never be read under another.

Elevations are converted with the fixed, world-wide transfer owned by
:mod:`terrain_cache` alone (sea level 28, 50 m per voxel, baseline 0, band 4..60)
via :func:`terrain_cache.quantize_height`.

Axis convention
---------------
Upstream ``get(i1, j1, i2, j2)`` is half-open ``[i1, i2) x [j1, j2)`` with ``i``
the ROW (z) and ``j`` the COLUMN (x), returning ``(rows, cols)``.  :func:`_fetch`
therefore calls ``get(pz0, px0, pz1, px1)`` and every read is ``matrix[z][x]``,
which is what makes the payload ``x``-fastest (``index = x + 16 * z``) line up
with the game's ``generate-from-heights`` contract.

Files are the only channel
--------------------------
Under ``<cache_root>/<identity_digest>/`` (the layout :mod:`terrain_cache`
already owns)::

    manifest.json           authoritative identity record (terrain_cache)
    manifest.janet          inert bridge twin read by the game
    stats.json              frozen conditioning table (own runtime copy)
    requests/<cx>_<cz>.req  request marker; the FILE NAME is the whole message
    tiles/<cx>_<cz>.tdh     complete tiles, published atomically
    errors/<cx>_<cz>.txt    terminal failure; never retried

The manifest bridge is exactly::

    {:format 2 :magic "TDH2" :identity "<64 lowercase hex>" :seed N
     :payload-bytes 256 :tile-bytes 308}

What is pinned, and what is honestly not
----------------------------------------
The identity descriptor pins the model repo/revision, upstream code revision,
seed, the full sampler/inference geometry, the height mapping, the sampling
scale, dtype and device, plus content digests of the model ``config.json``, the
frozen conditioning table, the upstream source tree, and the installed
``pyfastnoiselite`` binary.

A digest is not a provenance claim.  The locally built ``pyfastnoiselite`` is
NOT the pinned PyPI 0.0.6 wheel, so no run here may claim bit-identical output
with the official pipeline; that limitation is recorded in the identity itself
rather than omitted.  Device and dtype are recorded, not normalized away: two
peers on different hardware are not assumed byte-identical.

Pinned code revision: the checkout under ``tmp/`` is not a git work tree, so the
revision is proven by a content digest of the whole source tree.  When a git
work tree IS available its ``HEAD`` must equal :data:`UPSTREAM_REVISION`
exactly; a mismatch is fatal, because nothing here trusts a typed-in string.

Seed zero is rejected: upstream evaluates ``seed or random.randint(...)`` in the
synthetic-map factory, so a falsy seed silently substitutes a random world while
the recorded identity still looks reproducible.
"""

from __future__ import annotations

import argparse
import dataclasses
import fcntl
import hashlib
import json
import math
import os
import re
import signal
import sys
import threading
import time
import urllib.request

import terrain_cache as tc

# ---------------------------------------------------------------------------
# Pins
# ---------------------------------------------------------------------------

MODEL_REPO = "xandergos/terrain-diffusion-30m"
MODEL_REVISION = "9ef8030cb805b433b98ec25c5dddefbac07a9e26"
UPSTREAM_REPO = "xandergos/terrain-diffusion"
UPSTREAM_REVISION = "e8dcb4b1a834ab2f6b1a6f5256ed7c9f2f3e8230"
#: Alternative proof of the code revision for a tree with no ``.git``: SHA-256
#: over sorted ``<relative path> <file sha256>`` lines.
UPSTREAM_SOURCE_SHA256 = (
    "3b7f78788ca4797f19a98c8c1e246abd0af9f39b72ac7e6bd7ee1efc1ae96504"
)

STATS_REPO = "xandergos/terrain-diffusion-30m-onnx"
STATS_REVISION = "ad2df557eca5645f588766101cf3bc3682455c3e"
STATS_FILENAME = "pipeline_data.json"
STATS_URL = "https://huggingface.co/%s/resolve/%s/%s" % (
    STATS_REPO,
    STATS_REVISION,
    STATS_FILENAME,
)

#: Required keys of the frozen conditioning table.  We keep exactly these in our
#: own runtime file so a missing or partial table fails closed instead of
#: silently recomputing quantiles from rasters that are not shipped.
STATS_KEYS = (
    "n_quantiles",
    "noise_quantile_tables",
    "data_quantile_tables",
    "a_temp_std",
    "b_temp_std",
    "temp_std_p1",
    "temp_std_p99",
)
CONDITIONING_VERSION = "onnx-frozen-%s" % STATS_REVISION[:12]
#: Canonical SHA-256 of the extracted frozen table.  Shape checks prove a table is
#: *well formed*; this proves it is the *official* one.  A locally recomputed
#: table is well formed too -- the docs measure it drifting up to 69.1 m on the
#: elevation channel -- so shape alone would silently accept a different planet.
OFFICIAL_STATS_SHA256 = (
    "528754ea8203928364cccd931686ec87612b1eefba44ef7956293f33a68bdbe3"
)

DEFAULT_SEED = 4
DEFAULT_PIXELS_PER_VOXEL = 1  # one block = 30 m at 30 m native
DEFAULT_DTYPE = "fp32"
DEFAULT_DEVICE = "mps"
DEFAULT_MAX_SAMPLES = 64  # lattice points per axis per pipeline call
MAX_SAMPLES_LIMIT = 512

SAMPLER_NAME = "WorldPipeline"
SAMPLER_STEPS = 20
SAMPLER_GUIDANCE = 1.0
SAMPLER_SCHEDULER = "EDMDPMSolverMultistep"

#: Upstream values this backend pins.  A snapshot ``config.json`` that carries
#: any of these with a different value is a different world and is refused.
#: ``T``, ``decoder_tile_size`` and ``decoder_tile_stride`` are NOT in the pinned
#: config -- they are ``WorldPipeline.__init__`` defaults -- so they are pinned
#: here and passed explicitly at load time rather than read back from the file.
EXPECTED_CONFIG = {
    "native_resolution": 30,
    "latent_compression": 8,
    "cond_snr": [0.5, 0.5, 0.5, 0.5, 0.5],
    "frequency_mult": [1.0, 1.0, 1.0, 1.0, 1.0],
    "drop_water_pct": 0.5,
    "residual_std": 0.7,
}

#: Decoder window/stride pairs that may be chosen.  The first is upstream's
#: default and the default here; the second is the MPS-reliable pair the Java mod
#: uses.  They produce different terrain for the same seed, so the pair is hashed.
DECODER_GEOMETRIES = ((512, 384), (256, 192))

#: Constructor-only pins: absent from ``config.json``, so they can never be
#: verified against it and must be supplied explicitly when loading.
CONSTRUCTOR_PINS = {
    "T": 2,
    "decoder_tile_size": 512,
    "decoder_tile_stride": 384,
}

#: The exact model weights this backend will accept, relative to the snapshot
#: root, with the SHA-256 and byte size published for MODEL_REVISION.  Hashing
#: only ``config.json`` would let byte-different weights share one cache
#: identity, which is the false-provenance failure this module exists to prevent:
#: the identity still *claims* a model revision while serving another world.
MODEL_WEIGHTS = {
    "coarse_model/diffusion_pytorch_model.safetensors": {
        "sha256": "f88cdc26c70a2c73ee4c91088b8cec3f45202fc452682ac759554b099c5c2f33",
        "bytes": 11200936,
    },
    "base_model/diffusion_pytorch_model.safetensors": {
        "sha256": "351d1b1a77cf32e15adc4f72ed5fd26d317340598329d35f5dce2ff6dbcce735",
        "bytes": 1014772076,
    },
    "decoder_model/diffusion_pytorch_model.safetensors": {
        "sha256": "b6c7fa99f836ad75c514236c9529e18a68ea207ed59dd39fd1341fc9a8a03bcc",
        "bytes": 111709108,
    },
}

#: The four model configs, pinned by SHA-256.  The three submodel configs are
#: read by ``diffusers.from_pretrained`` and are numerically ACTIVE while being
#: shape-neutral: ``concat_balance``, ``fourier_scale``, ``disable_out_gain`` and
#: ``logvar_channels`` all change output without changing a tensor shape, so a
#: weights-only check cannot see them.  Hashing them means such an edit mints a
#: new identity instead of silently sharing a cache directory.
MODEL_CONFIGS = {
    "config.json": {
        "sha256": "c60f0b74d89317e64cfc623fbfdd828f1b5b2e50aa75020ac4001103381853bd",
        "bytes": 774,
    },
    "coarse_model/config.json": {
        "sha256": "3256a71d181dc3b10f7e44320920694b6aba1572ee5200872a503f89c8cbb3b4",
        "bytes": 828,
    },
    "base_model/config.json": {
        "sha256": "2400da3c7bed5dbc331a0cfabd3f4a5a3c5c977d4c4b3fb1037f4e285d320598",
        "bytes": 682,
    },
    "decoder_model/config.json": {
        "sha256": "fc69e7c75bcc8b92d687306cb38cca2868a6034cdf73ddf7cfbf7078af6ac55e",
        "bytes": 609,
    },
}

#: The query strategy revision.  Bumped whenever the *shape* of a model query
#: changes, because window shape is part of what the model computes, not merely
#: an access detail.
QUERY_STRATEGY = "canonical-macrotile-v1"

#: Native pixels per axis that one aligned query window covers, before
#: ``pixels_per_voxel`` scaling.  A canonical window is always fetched whole.
DEFAULT_WINDOW_CHUNKS = 4

DEFAULT_ORIGIN_PIXELS = (0, 0)

DEFAULT_HOME = os.path.expanduser("~/.cache/huggingface/hub")
DEFAULT_SNAPSHOT = os.path.join(
    DEFAULT_HOME,
    "models--xandergos--terrain-diffusion-30m",
    "snapshots",
    MODEL_REVISION,
)
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_UPSTREAM = os.path.join(_REPO_ROOT, "tmp", "terrain-runtime", "repo")
DEFAULT_CACHE_ROOT = os.path.join(_REPO_ROOT, "tmp", "terrain-cache")
DEFAULT_STATS_SOURCE = "/tmp/pd.json"

MANIFEST_JANET_NAME = "manifest.janet"
STATS_NAME = "stats.json"
IDENTITY_RECORD = "identity.json"
REQUESTS_DIR_NAME = "requests"
ERRORS_DIR_NAME = "errors"
REQUEST_SUFFIX = ".req"
ERROR_SUFFIX = ".txt"

#: Process-ownership and progress artefacts.  Both live inside the identity
#: directory, so a cache carries its own liveness and stage without a side
#: channel the game would have to locate separately.
LOCK_NAME = ".worker.lock"
STATUS_NAME = "worker-status.janet"

#: A launch receipt is written by the child *before* it validates anything, so it
#: covers the window in which a launch can die before any status exists. A
#: launcher cannot see that window otherwise: Janet's `:return-code` is absent
#: until `os/proc-wait`, which suspends the fiber, so it is not a liveness poll.
RECEIPT_NAME = "worker-launch.janet"

#: The status bridge is a fixed, tiny Janet table -- the game has no JSON
#: parser, and this must stay inert data it can read with `parse`.
STATUS_VERSION = 1
STATUS_MAX_BYTES = 16 * 1024
STATUS_STATES = (
    "starting",
    "loading-model",
    "generating",
    "idle",
    "failed",
    "stopping",
    "waiting-for-device",
)

#: Exit code for "another producer holds the lock".  Distinct from 1 (a failure
#: the caller should report as broken) and from 2 (a usage error), so a launcher
#: can tell "retry later / reuse the live worker" from "this is wrong".
EXIT_LOCKED = 75


class BackendError(RuntimeError):
    """A generation precondition failed; nothing was published."""


class LockBusy(BackendError):
    """Another process owns this identity or device.

    Separate from ``BackendError`` because it is the one failure that is *not*
    the cache's fault: a launcher must reuse the running producer instead of
    reporting a broken cache, and it maps to its own exit code. Catching
    ``BackendError`` broadly would turn a real fault -- a failed status write, a
    drifted pin -- into "someone else is using it", which sends the operator to
    wait on nothing.
    """


# ---------------------------------------------------------------------------
# Small filesystem helpers
# ---------------------------------------------------------------------------


def canonical_json(value):
    """Canonical JSON bytes: sorted keys, compact separators, no NaN."""
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def _sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def _atomic_write(path, data):
    """Write bytes to ``path`` by same-directory rename; never partial."""
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)
    temp = os.path.join(directory, ".tmp-%d-%d" % (os.getpid(), time.time_ns()))
    try:
        with open(temp, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def _read_json(path):
    with open(path, "rb") as handle:
        return json.loads(handle.read().decode("utf-8"))


# ---------------------------------------------------------------------------
# Process ownership: two advisory locks, released by the kernel on death
# ---------------------------------------------------------------------------


def _runtime_dir():
    """Where machine-wide (not per-identity) artefacts live.

    ``TRINECRAFT_RUNTIME_DIR`` overrides it so tests (and a sandboxed launcher)
    can isolate the device lock instead of contending with the real machine.
    """
    override = os.environ.get("TRINECRAFT_RUNTIME_DIR")
    if override:
        return override
    base = os.environ.get("XDG_RUNTIME_DIR") or os.path.join(
        os.path.expanduser("~"), ".cache", "trinecraft"
    )
    return os.path.join(base, "terrain")


def device_lock_path(device):
    """The machine-wide lock for one accelerator.

    An identity lock stops two producers on the *same* cache.  It cannot stop a
    second producer on a *different* identity driving the same GPU, which is the
    condition that produced the MPS watchdog warnings -- so the device needs its
    own lock, held for the lifetime of any process that will load a pipeline.
    """
    return os.path.join(_runtime_dir(), "%s.lock" % str(device))


@dataclasses.dataclass
class ProcessLock:
    """One advisory ``flock`` held for the life of a block.

    ``flock`` is used rather than a pid file because the kernel drops it when the
    process dies, however it dies.  There is deliberately no pid-based staleness
    heuristic: another process's liveness cannot be established safely from here
    without racing the very death we are trying to detect.
    """

    path: str
    device: str
    handle: object = None

    def acquire(self):
        """Take the lock non-blocking, or raise ``BackendError`` with the holder."""
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        handle = open(self.path, "a+")
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            holder = ""
            try:
                handle.seek(0)
                holder = handle.read(200).strip()
            except OSError:
                pass
            handle.close()
            raise LockBusy(
                "%s is already in use%s; another terrain producer owns this "
                "device. Stop it first, or reuse the running one."
                % (self.path, " (pid %s)" % holder if holder else "")
            ) from None
        # Record who holds it, for a human reading the message above. The lock
        # itself, not this text, is what excludes.
        handle.seek(0)
        handle.truncate()
        handle.write("%d\n" % os.getpid())
        handle.flush()
        self.handle = handle
        return self

    def release(self):
        if self.handle is None:
            return
        try:
            fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
        finally:
            self.handle.close()
            self.handle = None

    def __enter__(self):
        return self.acquire()

    def __exit__(self, *_exc):
        self.release()
        return False


def identity_lock_path(layout):
    """The per-identity lock, shared by ``worker`` and ``bake``.

    One lock for both commands is the point: a bake and a worker on the same
    identity would each load a pipeline and publish tiles for the same
    coordinates, which the request/publish protocol is not designed to arbitrate.
    """
    return os.path.join(layout.root, LOCK_NAME)


def acquire_producer_locks(layout, device):
    """Take the identity lock then the device lock, in that order.

    Ordering is fixed so two processes cannot deadlock by taking them in opposite
    orders.  On any failure the already-held lock is released before raising.
    """
    identity_lock = ProcessLock(identity_lock_path(layout), device)
    identity_lock.acquire()
    device_lock = ProcessLock(device_lock_path(device), device)
    try:
        device_lock.acquire()
    except BackendError:
        identity_lock.release()
        raise
    return identity_lock, device_lock


# ---------------------------------------------------------------------------
# Status bridge: one tiny inert Janet table the game can parse
# ---------------------------------------------------------------------------


def _janet_string(value):
    """Escape a value as a Janet string literal."""
    out = []
    for char in str(value):
        if char == "\\":
            out.append("\\\\")
        elif char == '"':
            out.append('\\"')
        elif char in "\n\r\t":
            out.append({"\n": "\\n", "\r": "\\r", "\t": "\\t"}[char])
        elif ord(char) < 0x20:
            out.append("\\x%02X" % ord(char))
        else:
            out.append(char)
    return '"%s"' % "".join(out)


def render_status(status):
    """Serialise a status record as a Janet table, inert data only.

    Deliberately not JSON: the game has no JSON parser, and this file is read on
    the load path where adding one would be a new dependency. ``parse`` handles a
    data literal with no code in it.
    """
    state = status["state"]
    if state not in STATUS_STATES:
        raise BackendError("unknown status state %r" % (state,))
    parts = [
        ":version %d" % STATUS_VERSION,
        ":identity-digest %s" % _janet_string(status["identity_digest"]),
        ":pid %d" % int(status["pid"]),
        ":state :%s" % state,
        ":completed %d" % int(status.get("completed", 0)),
        ":message %s" % _janet_string(status.get("message", "")),
    ]
    if status.get("owner_token"):
        parts.append(":owner-token %s" % _janet_string(status["owner_token"]))
    text = "{" + " ".join(parts) + "}\n"
    data = text.encode("utf-8")
    if len(data) > STATUS_MAX_BYTES:
        raise BackendError(
            "status record is %d bytes, over the %d byte bridge cap"
            % (len(data), STATUS_MAX_BYTES)
        )
    return data


class StatusWriter:
    """Publish worker state as an inert Janet table, atomically.

    Every write replaces the whole file, so a reader never sees a half-updated
    state. A writer that does not own the identity must never be constructed --
    that is what would clobber the live owner's status on a lock-busy exit.
    """

    def __init__(self, layout, identity_digest, owner_token=None):
        self.path = os.path.join(layout.root, STATUS_NAME)
        self.identity_digest = identity_digest
        self.owner_token = owner_token

    def write(self, state, completed=0, message=""):
        payload = render_status(
            {
                "state": state,
                "identity_digest": self.identity_digest,
                "pid": os.getpid(),
                "completed": int(completed),
                "message": message,
                "owner_token": self.owner_token,
            }
        )
        _atomic_write(self.path, payload)
        return payload


def read_status(layout):
    """Best-effort read of a status record for tests and diagnostics."""
    path = os.path.join(layout.root, STATUS_NAME)
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


_TOKEN_RE = re.compile(r"\A[A-Za-z0-9_-]{1,128}\Z")

RECEIPT_STATES = ("launched", "started", "reused", "failed")


def validate_token(token):
    """A launch token becomes a path component, so it is validated as one.

    Deliberately narrow: no dots, no slashes, no whitespace. This is a
    path-safety rule first, because ``worker-launch-<token>.janet`` must stay
    inside the identity directory, and a style rule only incidentally.
    """
    if not isinstance(token, str) or not _TOKEN_RE.match(token):
        raise BackendError(
            "launch token must match [A-Za-z0-9_-]{1,128}; got %r" % (token,)
        )
    return token


def receipt_path(layout, token):
    return os.path.join(layout.root, "worker-launch-%s.janet" % validate_token(token))


def write_launch_receipt(
    layout,
    identity_digest,
    token,
    state,
    *,
    worker_pid=0,
    worker_token=None,
    message="",
):
    """Publish this launch's outcome at a path the launcher already knows.

    Per launch, never shared: two launches racing must not overwrite each other's
    outcome, and a launcher reads only the path it named -- no directory scan, and
    no scanning on the load path.

    ``:worker-pid`` is the pid that actually serves, which on ``:reused`` is the
    *existing owner*, not this process. That is the whole reason a new child's pid
    cannot authorise reuse on its own.
    """
    if state not in RECEIPT_STATES:
        raise BackendError("unknown receipt state %r" % (state,))
    parts = [
        ":version %d" % STATUS_VERSION,
        ":identity-digest %s" % _janet_string(identity_digest),
        ":state :%s" % state,
        ":launcher-pid %d" % os.getpid(),
        ":worker-pid %d" % int(worker_pid or 0),
        ":owner-token %s" % _janet_string(token),
    ]
    if worker_token:
        parts.append(":worker-token %s" % _janet_string(worker_token))
    parts.append(":message %s" % _janet_string(message or ""))
    data = ("{" + " ".join(parts) + "}\n").encode("utf-8")
    if len(data) > STATUS_MAX_BYTES:
        raise BackendError("launch receipt exceeds the bridge cap")
    _atomic_write(receipt_path(layout, token), data)
    return data


def remove_launch_receipt(layout, token):
    """Delete one launch's receipt; the launcher owns this, not the child."""
    try:
        os.unlink(receipt_path(layout, token))
    except FileNotFoundError:
        pass


def read_launch_receipt(layout, token):
    path = receipt_path(layout, token)
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def _status_owner(layout, identity_digest):
    """The live owner as recorded by the status file, or (None, None).

    Used only after the kernel has already refused the identity lock: the refusal
    is the proof that a process held it, and this identifies that process. The
    owner could still die between the refusal and this read -- that race is
    inherent and is reported as what was observed, not papered over.
    """
    text = read_status(layout)
    if not text:
        return None, None
    pid = None
    token = None
    match = re.search(r":pid (-?\d+)", text)
    if match:
        pid = int(match.group(1))
    if identity_digest not in text:
        # A status naming a different identity is not evidence about this one.
        return None, None
    match = re.search(r':owner-token "((?:[^"\\]|\\.)*)"', text)
    if match:
        token = match.group(1)
    return pid, token


def coord_name(cx, cz):
    return "%d_%d" % (cx, cz)


@dataclasses.dataclass(frozen=True)
class Layout:
    """One identity's on-disk layout, exactly as the game reads it.

    ``cache_root`` and ``digest`` are kept separate from ``root`` because
    :mod:`terrain_cache` takes them as arguments and derives ``root`` itself;
    re-deriving them from a path with ``dirname``/``basename`` works for absolute
    paths and silently breaks for relative ones.
    """

    cache_root: str
    digest: str
    root: str

    @classmethod
    def open(cls, cache_root, digest):
        return cls(os.fspath(cache_root), digest, tc.cache_dir(cache_root, digest))

    def tile_path(self, cx, cz):
        return tc.tile_path(self.cache_root, self.digest, cx, cz)

    def request_path(self, cx, cz):
        return os.path.join(
            self.root, REQUESTS_DIR_NAME, coord_name(cx, cz) + REQUEST_SUFFIX
        )

    def error_path(self, cx, cz):
        return os.path.join(
            self.root, ERRORS_DIR_NAME, coord_name(cx, cz) + ERROR_SUFFIX
        )

    def stats_path(self):
        return os.path.join(self.root, STATS_NAME)

    def has_tile(self, cx, cz):
        return os.path.exists(self.tile_path(cx, cz))

    def has_error(self, cx, cz):
        return os.path.exists(self.error_path(cx, cz))


# ---------------------------------------------------------------------------
# Query geometry: the canonical window contract
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True)
class Query:
    """How a chunk is turned into model pixels.

    This is the single object sampling takes, so a caller cannot accidentally mix
    a window from one identity with an origin from another.

    Canonical windows
    -----------------
    A window is chunk-aligned and anchored to the *global* grid::

        anchor = (cx // window_chunks) * window_chunks

    Floor division keeps negative chunks on the same grid as positive ones, so
    chunk ``-1`` and chunk ``0`` share window ``-4`` when ``window_chunks`` is 4.
    The whole window is always fetched, so the pixels the model sees depend only
    on the window index -- never on which other chunks happened to be requested.
    That is what makes an isolated chunk and the same chunk inside a batch send
    the model identical input, which is the property the previous
    request-anchored window could not offer.
    """

    pixels_per_voxel: int = 1
    origin_pixels: tuple = DEFAULT_ORIGIN_PIXELS
    window_chunks: int = DEFAULT_WINDOW_CHUNKS
    max_samples: int = DEFAULT_MAX_SAMPLES

    def __post_init__(self):
        if isinstance(self.pixels_per_voxel, bool) or not isinstance(
            self.pixels_per_voxel, int
        ):
            raise BackendError("pixels_per_voxel must be an int")
        if self.pixels_per_voxel not in (1, 2, 4, 8):
            raise BackendError("pixels_per_voxel must be one of 1, 2, 4, 8")
        origin = tuple(self.origin_pixels)
        if len(origin) != 2:
            raise BackendError("origin_pixels must hold exactly two integers")
        for value in origin:
            if isinstance(value, bool) or not isinstance(value, int):
                raise BackendError(
                    "origin_pixels must be integers, got %r" % (value,)
                )
        object.__setattr__(self, "origin_pixels", origin)
        if isinstance(self.window_chunks, bool) or not isinstance(
            self.window_chunks, int
        ):
            raise BackendError("window_chunks must be an int")
        if self.window_chunks < 1:
            raise BackendError("window_chunks must be at least 1")
        if isinstance(self.max_samples, bool) or not isinstance(self.max_samples, int):
            raise BackendError("max_samples must be an int")
        window_pixels = self.window_pixels
        if window_pixels > self.max_samples:
            raise BackendError(
                "a canonical window needs %d samples per axis "
                "(window_chunks %d x 16 voxels x pixels_per_voxel %d) but "
                "max_samples is %d; raise --max-samples to at least %d or "
                "lower --window-chunks"
                % (
                    window_pixels,
                    self.window_chunks,
                    self.pixels_per_voxel,
                    self.max_samples,
                    window_pixels,
                )
            )

    @property
    def window_pixels(self):
        """Native pixels one canonical window spans, per axis."""
        return self.window_chunks * tc.TILE_SIZE * self.pixels_per_voxel

    def anchor(self, chunk):
        """Global chunk coordinate of the window containing ``chunk``."""
        return (chunk // self.window_chunks) * self.window_chunks

    def pixel(self, global_x, global_z):
        """World pixel of a global voxel column, origin included."""
        return (
            self.origin_pixels[0] + global_x * self.pixels_per_voxel,
            self.origin_pixels[1] + global_z * self.pixels_per_voxel,
        )

    def window_bounds(self, macro_x, macro_z):
        """Half-open world-pixel bounds of the canonical window at an anchor."""
        x0 = self.origin_pixels[0] + macro_x * tc.TILE_SIZE * self.pixels_per_voxel
        z0 = self.origin_pixels[1] + macro_z * tc.TILE_SIZE * self.pixels_per_voxel
        return (x0, z0, x0 + self.window_pixels, z0 + self.window_pixels)

    def identity_record(self):
        """The pin hashed into the identity; a different window is a new trail."""
        return {
            "strategy": QUERY_STRATEGY,
            "origin_pixels": list(self.origin_pixels),
            "window_chunks": self.window_chunks,
            "window_pixels": self.window_pixels,
            "max_samples": self.max_samples,
            "pixels_per_voxel": self.pixels_per_voxel,
        }

    @classmethod
    def from_identity(cls, identity):
        """Rebuild the exact query an identity was baked with."""
        record = identity.get("query")
        if not isinstance(record, dict):
            raise BackendError("identity has no pinned query geometry")
        if record.get("strategy") != QUERY_STRATEGY:
            raise BackendError(
                "identity query strategy %r is not %r"
                % (record.get("strategy"), QUERY_STRATEGY)
            )
        origin = record.get("origin_pixels", DEFAULT_ORIGIN_PIXELS)
        query = cls(
            pixels_per_voxel=int(record.get("pixels_per_voxel", identity[
                "pixels_per_voxel"])),
            origin_pixels=tuple(origin),
            window_chunks=int(record.get("window_chunks", DEFAULT_WINDOW_CHUNKS)),
            max_samples=int(record.get("max_samples", DEFAULT_MAX_SAMPLES)),
        )
        if query.pixels_per_voxel != identity["pixels_per_voxel"]:
            raise BackendError(
                "identity pixels_per_voxel and its pinned query disagree"
            )
        return query


# ---------------------------------------------------------------------------
# Pinned inputs: snapshot config, upstream source, frozen stats
# ---------------------------------------------------------------------------


def read_snapshot_config(snapshot):
    path = os.path.join(snapshot, "config.json")
    try:
        config = _read_json(path)
    except FileNotFoundError:
        raise BackendError(
            "snapshot config.json is missing: %s" % path
        ) from None
    except (OSError, ValueError) as exc:
        raise BackendError(
            "snapshot config.json is not readable: %s (%s)" % (path, exc)
        ) from exc
    if not isinstance(config, dict):
        raise BackendError("snapshot config.json is not an object")
    return config


def check_config(config):
    """Fail closed unless the snapshot config pins the expected geometry."""
    problems = []
    for key, expected in EXPECTED_CONFIG.items():
        if key not in config:
            problems.append("%s is missing from config.json" % key)
            continue
        actual = config[key]
        if isinstance(expected, float) and isinstance(actual, (int, float)):
            if abs(float(actual) - expected) > 1e-9:
                problems.append("%s=%r expected %r" % (key, actual, expected))
        elif actual != expected:
            problems.append("%s=%r expected %r" % (key, actual, expected))
    # A constructor pin that the config DOES carry must still agree with it.
    for key, expected in CONSTRUCTOR_PINS.items():
        if key in config and config[key] != expected:
            problems.append("%s=%r expected %r" % (key, config[key], expected))
    if problems:
        raise BackendError(
            "snapshot config does not match this backend's pins: "
            + "; ".join(problems)
        )
    return config


def source_tree_digest(repo):
    """SHA-256 over sorted ``<relative path> <file sha256>`` lines.

    Deterministic and independent of mtimes, so it can pin a tree that carries no
    git metadata.  Skips bytecode and VCS directories.
    """
    if not os.path.isdir(repo):
        raise BackendError("upstream source not found: %s" % repo)
    lines = []
    for dirpath, dirnames, filenames in os.walk(repo):
        dirnames[:] = sorted(
            name for name in dirnames if name not in (".git", "__pycache__")
        )
        for name in sorted(filenames):
            if name.endswith(".pyc"):
                continue
            full = os.path.join(dirpath, name)
            lines.append(
                "%s %s"
                % (os.path.relpath(full, repo).replace(os.sep, "/"), _sha256_file(full))
            )
    return _sha256_bytes("\n".join(lines).encode("utf-8"))


def _git_head(git_dir):
    try:
        with open(os.path.join(git_dir, "HEAD"), "r", encoding="utf-8") as handle:
            raw = handle.read().strip()
        if raw.startswith("ref: "):
            with open(
                os.path.join(git_dir, raw[5:].strip()), "r", encoding="utf-8"
            ) as handle:
                return handle.read().strip()
        return raw
    except OSError:
        return None


def verify_upstream(repo):
    """Verify the pinned code revision by git HEAD when possible, else content.

    A git work tree whose ``HEAD`` differs from :data:`UPSTREAM_REVISION` is a
    hard failure; this is deliberately not "trust whatever HEAD says".
    """
    source = source_tree_digest(repo)
    git_dir = os.path.join(repo, ".git")
    if os.path.isdir(git_dir) or os.path.isfile(git_dir):
        head = _git_head(git_dir)
        if head is None:
            raise BackendError("git work tree at %s has no readable HEAD" % repo)
        if head != UPSTREAM_REVISION:
            raise BackendError(
                "upstream HEAD %s does not match pinned %s" % (head, UPSTREAM_REVISION)
            )
        record = {"pin_verified_by": "git", "git_head": head}
    else:
        record = {"pin_verified_by": "source-hash", "git_head": None}
    record["source_sha256"] = source
    return record


def noise_library_digest(noise_module_file):
    """Digest the installed ``pyfastnoiselite`` build.

    ``dist_info`` distinguishes the official wheel from the bespoke replacement
    this host has; ``note`` records the consequence verbatim, because the noise
    quantiles are determinism-critical and pretending otherwise would be a lie.
    """
    if not os.path.isfile(noise_module_file):
        raise BackendError("pyfastnoiselite is not installed")
    lib_dir = os.path.dirname(os.path.abspath(noise_module_file))
    site_dir = os.path.dirname(lib_dir)
    versions = (
        [
            name
            for name in os.listdir(site_dir)
            if name.lower().startswith("pyfastnoiselite") and name.endswith(".dist-info")
        ]
        if os.path.isdir(site_dir)
        else []
    )
    note = (
        "official-pyfastnoiselite-wheel"
        if versions
        else "bespoke build; not claimed bit-identical to PyPI 0.0.6"
    )
    return {
        "sha256": _sha256_file(noise_module_file),
        "dist_info": bool(versions),
        "note": note,
    }


def _verify_pinned_files(snapshot, pins, *, kind):
    """Verify files by byte size and SHA-256; return ``{relative: digest}``.

    Size is checked before hashing so a truncated download fails in milliseconds
    instead of after reading a gigabyte, and so a wrong revision is caught before
    any expensive read.  A mismatch raises rather than being recorded: a digest
    that is merely *observed* would let a foreign snapshot be labelled with the
    pinned revision.

    An empty or non-mapping ``pins`` is refused.  Iterating it would verify
    nothing and return ``{}``, which hashes to a constant -- so every snapshot,
    including a foreign one, would produce the same ``configs_sha256``/
    ``weights_sha256`` and identity.  That turns "pin more of the world" into a
    no-op for any caller that passes a table, which is the same
    verify-nothing-but-claim-revision failure this function exists to prevent.
    """
    if not isinstance(pins, dict) or not pins:
        raise BackendError(
            "refusing to verify %s files against an empty pin table" % kind
        )
    files = {}
    for relative, pin in sorted(pins.items()):
        path = os.path.join(snapshot, relative)
        if not os.path.isfile(path):
            raise BackendError("snapshot is missing %s file %s" % (kind, relative))
        actual_bytes = os.path.getsize(path)
        if actual_bytes != pin["bytes"]:
            raise BackendError(
                "%s %s is %d bytes, pinned revision has %d"
                % (kind, relative, actual_bytes, pin["bytes"])
            )
        digest = _sha256_file(path)
        if digest != pin["sha256"]:
            raise BackendError(
                "%s %s hashes to %s, pinned revision is %s"
                % (kind, relative, digest, pin["sha256"])
            )
        files[relative] = digest
    return files


def verify_configs(snapshot, *, expected=None):
    """Verify the four model configs against the pinned digests."""
    pins = MODEL_CONFIGS if expected is None else expected
    files = _verify_pinned_files(snapshot, pins, kind="config")
    return {
        "configs_sha256": _sha256_bytes(canonical_json(files)),
        "files": files,
    }


def verify_weights(snapshot, *, expected=None):
    """Verify the three safetensors against the pinned digests."""
    pins = MODEL_WEIGHTS if expected is None else expected
    files = _verify_pinned_files(snapshot, pins, kind="weight")
    return {
        "weights_sha256": _sha256_bytes(canonical_json(files)),
        "files": files,
    }


def verify_snapshot(snapshot, *, weights=None, configs=None):
    """Verify configs AND weights together, so neither can be checked alone.

    Returning both blocks from one call is deliberate: a caller that verified
    only one of them is exactly how a shape-neutral config edit stayed invisible
    while the weights matched.
    """
    config_block = verify_configs(snapshot, expected=configs)
    weight_block = verify_weights(snapshot, expected=weights)
    return {
        "configs_sha256": config_block["configs_sha256"],
        "weights_sha256": weight_block["weights_sha256"],
    }


def extract_frozen_stats(source):
    """Return only the frozen conditioning keys, validated and pinned.

    ``pipeline_data.json`` carries extra bookkeeping; we keep exactly
    :data:`STATS_KEYS`.  Shapes are checked (5 tables x 64 knots) and every value
    must be finite, so a truncated or partial table fails closed rather than
    half-loading a world.

    The result is then compared against :data:`OFFICIAL_STATS_SHA256`, in the one
    function every caller must pass through: ``init``, ``descriptor``, ``bake``,
    ``worker``, ``doctor``, ``fetch-stats`` and ``_install_frozen_stats``.  A shape
    check alone cannot tell the official table from a well-formed local recompute,
    and a substituted table would otherwise be copied into an identity that still
    advertises the pinned ``conditioning_version``.  There is deliberately no
    opt-out argument: a test that needs a non-official table patches
    :data:`OFFICIAL_STATS_SHA256` to that fixture's digest, so every production
    call site keeps the gate.
    """
    if isinstance(source, dict):
        data, where = source, "in-memory stats"
    else:
        data, where = _read_json(source), str(source)
    if not isinstance(data, dict):
        raise BackendError("frozen stats %s is not a JSON object" % where)
    missing = [key for key in STATS_KEYS if key not in data]
    if missing:
        raise BackendError("frozen stats missing keys: %s" % ", ".join(missing))
    record = {key: data[key] for key in STATS_KEYS}
    # Strictly an int: `int(64.9) == 64` would accept a table whose recorded knot
    # count is not 64, and `True` would pass as 1 only by accident of int().
    quantiles = record["n_quantiles"]
    if isinstance(quantiles, bool) or not isinstance(quantiles, int):
        raise BackendError(
            "frozen stats n_quantiles must be an int, got %r"
            % (type(quantiles).__name__,)
        )
    if quantiles != 64:
        raise BackendError("frozen stats n_quantiles must be 64")
    for key in ("noise_quantile_tables", "data_quantile_tables"):
        tables = record[key]
        if not isinstance(tables, list) or len(tables) != 5:
            raise BackendError("frozen stats %s must hold 5 tables" % key)
        for index, table in enumerate(tables):
            if not isinstance(table, list) or len(table) != 64:
                raise BackendError(
                    "frozen stats %s[%d] must hold 64 knots" % (key, index)
                )
            for value in table:
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    raise BackendError(
                        "frozen stats %s[%d] holds a non-number" % (key, index)
                    )
                if not math.isfinite(float(value)):
                    raise BackendError(
                        "frozen stats %s[%d] holds a non-finite value" % (key, index)
                    )
    for key in ("a_temp_std", "b_temp_std", "temp_std_p1", "temp_std_p99"):
        value = record[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise BackendError("frozen stats %s must be a number" % key)
        if not math.isfinite(float(value)):
            raise BackendError("frozen stats %s must be finite" % key)
    _require_official_stats(record)
    return record


def fetch_frozen_stats(url=STATS_URL, timeout=60):
    """Download the pinned conditioning table; never implicit."""
    request = urllib.request.Request(url, headers={"User-Agent": "trinecraft-backend"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def _require_official_stats(stats):
    """Refuse a frozen table that is not the pinned one.

    Called unconditionally from :func:`extract_frozen_stats`, which is the only
    route from bytes on disk to an identity.  A substituted table therefore has no
    path into a production cache.
    """
    digest = _sha256_bytes(canonical_json(stats))
    if digest != OFFICIAL_STATS_SHA256:
        raise BackendError(
            "frozen conditioning table hashes to %s, but the official table is %s. "
            "A locally recomputed table is a different world; run `fetch-stats`."
            % (digest, OFFICIAL_STATS_SHA256)
        )
    return digest


def stats_source_path(cache_root, stats_source=None):
    """Locate the frozen table: explicit path, our cached copy, then ``/tmp``."""
    candidates = [
        stats_source,
        os.path.join(cache_root, STATS_NAME),
        DEFAULT_STATS_SOURCE,
    ]
    for candidate in candidates:
        if candidate and os.path.isfile(candidate):
            return candidate
    raise BackendError(
        "no frozen conditioning table found (looked at %s); run `fetch-stats` "
        "or pass --stats-json"
        % ", ".join(str(candidate) for candidate in candidates if candidate)
    )


# ---------------------------------------------------------------------------
# Identity
# ---------------------------------------------------------------------------


def sampler_geometry(config=None, decoder_geometry=None):
    """The sampler descriptor the cache identity requires.

    ``terrain_cache.SAMPLER_GEOMETRY_KEYS`` mandates every field below, so a bare
    sampler name can never share an identity with a full geometry pin.

    ``decoder_geometry`` optionally overrides the decoder window/stride pair.
    Upstream's default is 512/384 and stays the default here; the alternate
    256/192 pair is a *different world* (the docs say so), so it is hashed rather
    than normalized away, and choosing it can never silently reuse a cache baked
    at 512/384.
    """
    if config is not None:
        check_config(config)
    window = CONSTRUCTOR_PINS["decoder_tile_size"]
    stride = CONSTRUCTOR_PINS["decoder_tile_stride"]
    if decoder_geometry is not None:
        window, stride = decoder_geometry
        if (window, stride) not in DECODER_GEOMETRIES:
            raise BackendError(
                "decoder geometry %d/%d is not one of the pinned pairs %s"
                % (window, stride, ", ".join("%d/%d" % pair
                                             for pair in DECODER_GEOMETRIES))
            )
    return {
        "name": SAMPLER_NAME,
        "steps": SAMPLER_STEPS,
        "guidance": SAMPLER_GUIDANCE,
        "scheduler": SAMPLER_SCHEDULER,
        "T": CONSTRUCTOR_PINS["T"],
        "coarse_window": 64,
        "coarse_stride": 48,
        "latent_window": 64,
        "latent_stride": 32,
        "decoder_window": window,
        "decoder_stride": stride,
    }


def mapping_pin():
    """The quantization transfer, as an explicit identity object."""
    return {
        "name": "trinecraft-heights-v2",
        "meters_per_voxel": tc.METERS_PER_VOXEL,
        "sea_level": tc.SEA_LEVEL,
        "baseline_elevation_m": tc.BASELINE_ELEVATION_M,
        "height_min": tc.HEIGHT_MIN,
        "height_max": tc.HEIGHT_MAX,
        "sampling": "point-lattice",
    }


def build_identity(
    *,
    seed,
    pixels_per_voxel,
    dtype,
    device,
    snapshot,
    config,
    pin,
    stats,
    origin_pixels=DEFAULT_ORIGIN_PIXELS,
    window_chunks=DEFAULT_WINDOW_CHUNKS,
    max_samples=DEFAULT_MAX_SAMPLES,
    decoder_geometry=None,
    noise_lib=None,
    weights=None,
    configs=None,
):
    """Assemble the full identity descriptor, failing closed on any omission.

    ``noise_lib`` exists so a test can supply a synthetic record without the
    compiled ``pyfastnoiselite`` build; it defaults to digesting the installed
    binary, which is what every production caller uses.  Supplying one is the
    same trust decision as supplying a sampler, and it is recorded verbatim.
    """
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise BackendError("seed must be an int")
    if seed == 0:
        raise BackendError(
            "seed 0 is rejected: the synthetic-map factory treats a falsy seed "
            "as 'draw a random world'"
        )
    if seed < 0 or seed > 0xFFFFFFFFFFFFFFFF:
        raise BackendError("seed must fit in 64 unsigned bits")
    if pixels_per_voxel not in (1, 2, 4, 8):
        raise BackendError("pixels_per_voxel must be one of 1, 2, 4, 8")
    if dtype not in ("fp32", "fp16", "bf16"):
        raise BackendError("dtype must be fp32, fp16 or bf16")
    if device not in ("mps", "cpu", "cuda"):
        raise BackendError("device must be mps, cpu or cuda")
    if not os.path.isdir(snapshot):
        raise BackendError("pinned local snapshot directory is missing: %s" % snapshot)
    check_config(config)
    if pin["pin_verified_by"] == "source-hash":
        if pin["source_sha256"] != UPSTREAM_SOURCE_SHA256:
            raise BackendError(
                "upstream source digest %s does not match the pin %s"
                % (pin["source_sha256"], UPSTREAM_SOURCE_SHA256)
            )
    # Re-validate: a caller may hand back a stats dict that was mutated after it
    # was read, and the digest must describe a table this module has checked. The
    # official-table pin lives inside extract_frozen_stats, so `build_identity`
    # has no opt-out of its own -- there is deliberately no flag here that could
    # admit a substituted table into a production identity.
    stats = extract_frozen_stats(stats)
    stats_bytes = canonical_json(stats)
    noise = noise_lib or noise_library_digest(_noise_module_file())
    # Weights are hashed, never merely observed: a snapshot with the right config
    # but different bytes is a different world and must not share a cache.
    # Configs AND weights, never one without the other: a shape-neutral config
    # edit (concat_balance, fourier_scale) changes numerics while every weight
    # hash still matches.
    snapshot_pins = verify_snapshot(snapshot, weights=weights, configs=configs)
    weights = {"weights_sha256": snapshot_pins["weights_sha256"]}
    # One object owns the geometry, so the pinned record and the sampler can
    # never be constructed from different inputs.
    query = Query(
        pixels_per_voxel=int(pixels_per_voxel),
        origin_pixels=tuple(origin_pixels),
        window_chunks=int(window_chunks),
        max_samples=int(max_samples),
    )
    return {
        "model": MODEL_REPO,
        "model_revision": MODEL_REVISION,
        "upstream_revision": UPSTREAM_REVISION,
        "seed": int(seed),
        "sampler": sampler_geometry(config, decoder_geometry),
        "query": query.identity_record(),
        "mapping": mapping_pin(),
        "pixels_per_voxel": int(pixels_per_voxel),
        "units": tc.UNITS,
        "dtype": dtype,
        "device": device,
        "config_sha256": _sha256_file(os.path.join(snapshot, "config.json")),
        "configs_sha256": snapshot_pins["configs_sha256"],
        "weights_sha256": snapshot_pins["weights_sha256"],
        "stats_sha256": _sha256_bytes(stats_bytes),
        "conditioning_version": CONDITIONING_VERSION,
        "source_sha256": pin["source_sha256"],
        "source_pin_verified_by": pin["pin_verified_by"],
        "noise_lib_sha256": noise["sha256"],
        "noise_lib_note": noise["note"],
    }


def manifest_twin(digest, seed):
    """The exact Janet bridge record; key order and spacing are the contract."""
    return (
        '{:format 2 :magic "TDH2" :identity "%s" :seed %d '
        ":payload-bytes %d :tile-bytes %d}\n"
        % (digest, seed, tc.TILE_PAYLOAD_SIZE, tc.TILE_BYTES)
    )


def write_identity(cache_root, identity, *, stats_source=None):
    """Create the identity directory, manifest pair, stats copy and queues.

    ``cache_root`` is the shared root holding one directory per identity;
    :mod:`terrain_cache` owns both the digest rule and the immutable manifest, so
    this never re-derives either.
    """
    digest = tc.identity_digest(identity)
    layout = Layout.open(cache_root, digest)
    os.makedirs(layout.root, exist_ok=True)
    for name in (tc.TILE_DIR_NAME, REQUESTS_DIR_NAME, ERRORS_DIR_NAME):
        os.makedirs(os.path.join(layout.root, name), exist_ok=True)
    stats = extract_frozen_stats(stats_source_path(cache_root, stats_source))
    stats_bytes = canonical_json(stats)
    if _sha256_bytes(stats_bytes) != identity["stats_sha256"]:
        raise BackendError("frozen stats do not match the identity descriptor")
    _atomic_write(layout.stats_path(), stats_bytes + b"\n")
    tc.write_manifest(cache_root, identity, digest)
    _atomic_write(
        os.path.join(layout.root, MANIFEST_JANET_NAME),
        manifest_twin(digest, identity["seed"]).encode("utf-8"),
    )
    _atomic_write(
        os.path.join(layout.root, IDENTITY_RECORD),
        canonical_json({"identity": identity, "identity_digest": digest}) + b"\n",
    )
    return digest, layout


def existing_identities(cache_root):
    """Identity digests already present under a cache root."""
    if not os.path.isdir(cache_root):
        return []
    return sorted(
        name
        for name in os.listdir(cache_root)
        if os.path.isdir(os.path.join(cache_root, name))
        and os.path.isfile(os.path.join(cache_root, name, tc.MANIFEST_NAME))
    )


def open_or_create_identity(cache_root, identity, *, stats_source=None):
    """Publish an identity, refusing to silently fork an existing cache root.

    Creating the first identity is allowed, because that is the documented
    one-step bootstrap.  Creating a *different* one beside an existing identity is
    refused: a worker started with drifted flags would otherwise appear to
    succeed while writing a cache the game is not reading, and the pending markers
    it consumes belong to the older identity.  ``init`` is the explicit way to add
    a second generation.
    """
    digest = tc.identity_digest(identity)
    present = existing_identities(cache_root)
    if present and digest not in present:
        raise BackendError(
            "%s already holds identity %s; this run resolves to %s. Refusing to "
            "create a second generation implicitly -- rerun with the original "
            "flags, or use `init` to add this one deliberately."
            % (cache_root, ", ".join(present), digest)
        )
    return write_identity(cache_root, identity, stats_source=stats_source)


def open_identity(cache_root, digest):
    """Open an existing identity directory, validating its manifest first."""
    layout = Layout.open(cache_root, digest)
    if not os.path.isdir(layout.root):
        raise BackendError("no identity directory at %s; run `init` first" % layout.root)
    record = _require_manifest(layout)
    return record["identity"], layout


# ---------------------------------------------------------------------------
# Sampling and quantization
# ---------------------------------------------------------------------------


def _as_float(value):
    """Coerce one sampled elevation to a Python ``float``.

    The real pipeline returns ``numpy``/``torch`` scalars, which
    :func:`terrain_cache.quantize_height` deliberately refuses because it only
    accepts real Python numbers.  Coercion happens here, once, and is strict:
    bools are still rejected (``True`` would otherwise quantize as 1 m), and a
    value that cannot become a finite float raises :class:`BackendError` rather
    than becoming terrain.
    """
    if isinstance(value, bool):
        raise BackendError("sampler returned a bool where an elevation belongs")
    try:
        return float(value)
    except (TypeError, ValueError):
        raise BackendError(
            "sampler returned a non-numeric elevation of type %s"
            % type(value).__name__
        ) from None


def _as_matrix(elev, rows, cols):
    """Normalize a sampler result to ``rows`` sequences of ``cols`` values."""
    if elev is None:
        raise BackendError("sampler returned no elevation")
    try:
        height = len(elev)
    except TypeError:
        raise BackendError("sampler elevation is not a 2-D sequence") from None
    if height != rows:
        raise BackendError("sampler returned %d rows, expected %d" % (height, rows))
    normalized = []
    for row in elev:
        try:
            width = len(row)
        except TypeError:
            raise BackendError("sampler elevation row is not a sequence") from None
        if width != cols:
            raise BackendError(
                "sampler returned %d columns per row, expected %d" % (width, cols)
            )
        normalized.append(row)
    return normalized


def _fetch(sampler, px0, pz0, px1, pz1):
    """Fetch a half-open pixel rectangle as ``matrix[z][x]``.

    Upstream ``get(i1, j1, i2, j2)`` indexes rows by ``i`` (z) and columns by
    ``j`` (x).  Passing the pixel bounds in that order is what keeps the payload
    x-fastest; swapping them silently transposes every tile.
    """
    result = sampler.get(pz0, px0, pz1, px1)
    if not isinstance(result, dict) or "elev" not in result:
        raise BackendError("sampler result has no 'elev' entry")
    return _as_matrix(result["elev"], pz1 - pz0, px1 - px0)


def windows_for(cx0, cz0, cx1, cz1, query):
    """Distinct canonical windows covering a half-open chunk rectangle.

    A window is emitted once even when many requested chunks fall inside it, so
    a scattered batch and a dense one share the same query shape.  Ordering is
    row-major and deterministic.
    """
    anchors = set()
    for cz in range(cz0, cz1):
        for cx in range(cx0, cx1):
            anchors.add((query.anchor(cx), query.anchor(cz)))
    return sorted(anchors, key=lambda pair: (pair[1], pair[0]))


def window_payloads(sampler, query, anchors):
    """Fetch each canonical window whole, returning its height grid.

    Returns ``{(anchor_x, anchor_z): {(cx, cz): [256 heights]}}`` for every chunk
    inside the window.  Because the fetch always covers the full window, the
    result for a given chunk is the same object whether it was requested alone or
    as part of a batch -- there is no "partial window" path to diverge from.
    """
    voxels = tc.TILE_SIZE
    ppv = query.pixels_per_voxel
    out = {}
    for macro_x, macro_z in anchors:
        px0, pz0, px1, pz1 = query.window_bounds(macro_x, macro_z)
        matrix = _fetch(sampler, px0, pz0, px1, pz1)
        chunks = {}
        for cz in range(macro_z, macro_z + query.window_chunks):
            base_row = (cz - macro_z) * voxels * ppv
            rows = [base_row + z * ppv for z in range(voxels)]
            for cx in range(macro_x, macro_x + query.window_chunks):
                base_col = (cx - macro_x) * voxels * ppv
                heights = []
                for offset in rows:
                    row = matrix[offset]
                    for x in range(voxels):
                        heights.append(
                            tc.quantize_height(_as_float(row[base_col + x * ppv]))
                        )
                chunks[(cx, cz)] = heights
        out[(macro_x, macro_z)] = chunks
    return out


def sample_chunks(sampler, cx0, cz0, cx1, cz1, query):
    """Sample a half-open chunk rectangle; ``{(cx, cz): [256 heights]}``.

    Sampling is a pure function of ``(query, global voxel)``: every window is
    anchored to the global grid and fetched whole, so a chunk produces identical
    heights whether it is baked alone, inside a rectangle, or as part of a
    differently-ordered batch.  Chunks outside the requested rectangle are
    computed and discarded rather than skipped, precisely because skipping them
    is what would reintroduce a request-dependent window.
    """
    tc._require_chunk_coord(cx0, cz0)
    tc._require_chunk_coord(cx1, cz1)
    if cx1 <= cx0 or cz1 <= cz0:
        raise BackendError("chunk rectangle must be non-empty")
    wanted = {(cx, cz) for cz in range(cz0, cz1) for cx in range(cx0, cx1)}
    out = {}
    for chunks in window_payloads(
        sampler, query, windows_for(cx0, cz0, cx1, cz1, query)
    ).values():
        for coord in wanted & chunks.keys():
            out[coord] = chunks[coord]
    missing = wanted - out.keys()
    if missing:
        raise BackendError(
            "canonical windows did not cover %s" % sorted(missing)[:4]
        )
    return out


def sample_chunk(sampler, cx, cz, query):
    """Sample one chunk by the same canonical-window path the baker uses."""
    return sample_chunks(sampler, cx, cz, cx + 1, cz + 1, query)[(cx, cz)]


def publish_tile(layout, cx, cz, heights):
    """Write one tile, refusing to shadow a tile or override a terminal error."""
    if layout.has_error(cx, cz):
        raise BackendError("%s is terminal (error marker present)" % coord_name(cx, cz))
    if layout.has_tile(cx, cz):
        raise BackendError("tile %s already exists" % coord_name(cx, cz))
    return tc.write_tile(layout.cache_root, layout.digest, cx, cz, heights)


def mark_error(layout, cx, cz, message):
    """Publish a terminal error marker atomically; never retried."""
    if layout.has_error(cx, cz):
        raise BackendError("%s is already terminal" % coord_name(cx, cz))
    _atomic_write(
        layout.error_path(cx, cz), (message or "unknown error").encode("utf-8")
    )
    return layout.error_path(cx, cz)


def _clear_marker(layout, cx, cz):
    marker = layout.request_path(cx, cz)
    if os.path.exists(marker):
        os.unlink(marker)


def parse_coord_name(name, suffix):
    stem = name[: -len(suffix)]
    cx_text, sep, cz_text = stem.partition("_")
    if not sep or not cz_text:
        raise ValueError("marker name %r is not <cx>_<cz>%s" % (name, suffix))
    return int(cx_text), int(cz_text)


def read_requests(layout, *, on_invalid=None):
    """Read request coordinates from marker file names, sorted for stability.

    A name that is not a canonical ``<int32>_<int32>`` marker is reported through
    ``on_invalid(name, reason)`` and skipped.  Skipping is deliberate: one
    malformed marker written by a buggy or hostile client must never be able to
    kill the worker, and must never alias a real coordinate (``007_3`` is not
    ``7_3``).
    """
    directory = os.path.join(layout.root, REQUESTS_DIR_NAME)
    if not os.path.isdir(directory):
        return []
    coords = []
    for name in sorted(os.listdir(directory)):
        if name.startswith(".") or not name.endswith(REQUEST_SUFFIX):
            continue
        stem = name[: -len(REQUEST_SUFFIX)]
        try:
            cx, cz = parse_coord_name(name, REQUEST_SUFFIX)
        except ValueError:
            if on_invalid is not None:
                on_invalid(name, "not <cx>_<cz>")
            continue
        if (str(cx), str(cz)) != tuple(stem.split("_", 1)):
            if on_invalid is not None:
                on_invalid(name, "not canonical decimal")
            continue
        try:
            tc._require_chunk_coord(cx, cz)
        except (TypeError, ValueError):
            if on_invalid is not None:
                on_invalid(name, "coordinate outside int32")
            continue
        coords.append((cx, cz))
    return coords


def write_request(layout, cx, cz):
    """Stamp an empty request marker; the file NAME is the whole message."""
    tc._require_chunk_coord(cx, cz)
    if layout.has_tile(cx, cz):
        return "ready"
    if layout.has_error(cx, cz):
        return "suppressed"
    target = layout.request_path(cx, cz)
    if os.path.exists(target):
        return "queued"
    _atomic_write(target, b"")
    return "requested"


def pending_state(layout, cx, cz):
    if layout.has_tile(cx, cz):
        return "ready"
    if layout.has_error(cx, cz):
        return "error"
    if os.path.exists(layout.request_path(cx, cz)):
        return "queued"
    return "missing"


# ---------------------------------------------------------------------------
# Real sampler: one persistent WorldPipeline per identity
# ---------------------------------------------------------------------------


def _noise_module_file():
    """Locate the ``pyfastnoiselite`` build without importing torch."""
    import importlib.util

    try:
        spec = importlib.util.find_spec("pyfastnoiselite")
    except (ImportError, ValueError):
        spec = None
    if spec is None or not spec.submodule_search_locations:
        raise BackendError("pyfastnoiselite is not installed")
    base = list(spec.submodule_search_locations)[0]
    for name in sorted(os.listdir(base)):
        if name.startswith("pyfastnoiselite") and name.endswith(".so"):
            return os.path.join(base, name)
    return os.path.join(base, "__init__.py")


def _install_frozen_stats(layout):
    """Point ``synthetic_map`` at our frozen table and remove its fallback.

    Both the module constant and the recompute entry point are replaced, so a
    missing or unreadable cache raises instead of silently rebuilding quantiles
    from rasters.  Returns the digest that was installed.
    """
    from terrain_diffusion.inference import synthetic_map as sm

    stats_path = layout.stats_path()
    if not os.path.isfile(stats_path):
        raise BackendError("identity is missing %s; rerun `init`" % STATS_NAME)
    stats = extract_frozen_stats(stats_path)
    sm.STATS_CACHE_PATH = stats_path

    def _refuse(*_args, **_kwargs):
        raise BackendError(
            "refusing to recompute conditioning statistics: the frozen table "
            "is the world definition (docs/TERRAIN_DIFFUSION.md section 6)"
        )

    sm._compute_map_stats = _refuse
    return _sha256_bytes(canonical_json(stats))


class PipelineSampler:
    """Adapter exposing ``get(i1, j1, i2, j2) -> {"elev": 2-D}``.

    ``with_climate`` is FORWARDED, not pinned, and it defaults to ``False`` so
    every existing caller keeps exactly the work it paid for. The chunk cache
    wants elevation only; a caller that wants the five climate channels asks for
    them through this same method instead of reaching behind the adapter into
    ``self.pipeline``. Upstream's ``WorldPipeline.get`` accepted this argument
    all along; pinning it to ``False`` here was the only thing discarding
    climate.
    """

    def __init__(self, pipeline):
        self.pipeline = pipeline

    def get(self, i1, j1, i2, j2, with_climate=False):
        return self.pipeline.get(i1, j1, i2, j2, with_climate=with_climate)

    def close(self):
        try:
            self.pipeline.close()
        except Exception:  # pragma: no cover - close is best effort
            pass


def load_sampler(identity, layout, *, snapshot=None, upstream=None, device=None):
    """Load the pinned pipeline lazily and bind it for direct sampling.

    No network is used: the snapshot must already be a local directory, and the
    Hub client is forced offline before any model import.
    """
    for name in ("HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE", "HF_HUB_DISABLE_TELEMETRY"):
        os.environ[name] = "1"
    snapshot = snapshot or DEFAULT_SNAPSHOT
    upstream = upstream or DEFAULT_UPSTREAM
    device = device or identity["device"]
    if not os.path.isdir(snapshot):
        raise BackendError("snapshot directory is missing: %s" % snapshot)
    check_config(read_snapshot_config(snapshot))
    if device != identity["device"]:
        raise BackendError(
            "device %r differs from the pinned identity device %r"
            % (device, identity["device"])
        )
    pin = verify_upstream(upstream)
    if pin["source_sha256"] != identity["source_sha256"]:
        raise BackendError("upstream source digest does not match the identity")
    # Put the *verified* checkout on sys.path here rather than at import time, so
    # `doctor` still works where terrain_diffusion cannot be imported at all. The
    # digest check above has already passed, so this path is the verified tree.
    upstream_abs = os.path.abspath(upstream)
    if upstream_abs not in sys.path:
        sys.path.insert(0, upstream_abs)
    # Re-verify the weight bytes against the identity: a snapshot path can be
    # replaced between baking runs, and this is the only check that binds the
    # bytes actually loaded to the cache directory being written.
    pins = verify_snapshot(snapshot)
    for key, label in (
        ("weights_sha256", "model weights"),
        ("configs_sha256", "model configs"),
    ):
        if pins[key] != identity.get(key):
            raise BackendError(
                "%s do not match the identity (snapshot %s)" % (label, pins[key])
            )
    installed = _install_frozen_stats(layout)
    if installed != identity["stats_sha256"]:
        raise BackendError("frozen stats do not match the identity digest")

    import torch  # noqa: F401  (must exist before the pipeline import)
    from terrain_diffusion.inference.world_pipeline import WorldPipeline

    if device == "mps" and not torch.backends.mps.is_available():
        raise BackendError("device 'mps' requested but MPS is not available")
    if device == "cuda" and not torch.cuda.is_available():
        raise BackendError("device 'cuda' requested but CUDA is not available")

    pipeline = WorldPipeline.from_pretrained(
        snapshot,
        seed=identity["seed"],
        T=identity["sampler"]["T"],
        caching_strategy="direct",
        cache_limit=100 * 1024 * 1024,
        latents_batch_size=1,
        decoder_tile_size=identity["sampler"]["decoder_window"],
        decoder_tile_stride=identity["sampler"]["decoder_stride"],
        dtype=None if identity["dtype"] == "fp32" else identity["dtype"],
        torch_compile=False,
    )
    pipeline.to(device)
    pipeline.bind(None)
    if int(pipeline.seed) != int(identity["seed"]):
        raise BackendError("pipeline seed does not match the identity")
    return PipelineSampler(pipeline)


# ---------------------------------------------------------------------------
# Bake and worker
# ---------------------------------------------------------------------------


def _require_manifest(layout):
    """Fail with a BackendError when the identity manifest is absent or wrong."""
    try:
        return tc.read_manifest(layout.cache_root, layout.digest)
    except FileNotFoundError:
        raise BackendError(
            "no identity manifest at %s; run `init` first" % layout.root
        ) from None
    except (tc.ManifestConflict, ValueError) as exc:
        raise BackendError("identity manifest is not usable: %s" % exc) from exc


def bake_chunks(
    layout,
    sampler,
    *,
    cx0,
    cz0,
    cx1,
    cz1,
    query,
    progress=None,
):
    """Quantize and publish a whole chunk rectangle; returns published paths.

    Tiles already on disk count as done and are never rewritten.  A terminal
    error marker is a hard refusal: retrying it forever is exactly the behaviour
    this backend exists to avoid.
    """
    tc._require_chunk_coord(cx0, cz0)
    tc._require_chunk_coord(cx1, cz1)
    if cx1 <= cx0 or cz1 <= cz0:
        raise BackendError("chunk rectangle must be non-empty")
    _require_manifest(layout)
    terminal = [
        (cx, cz)
        for cz in range(cz0, cz1)
        for cx in range(cx0, cx1)
        if layout.has_error(cx, cz)
    ]
    if terminal:
        raise BackendError(
            "refusing to bake a rectangle with terminal errors: %s"
            % ", ".join(coord_name(cx, cz) for cx, cz in terminal)
        )
    pending = [
        (cx, cz)
        for cz in range(cz0, cz1)
        for cx in range(cx0, cx1)
        if not layout.has_tile(cx, cz)
    ]
    if not pending:
        return []
    heights = sample_chunks(sampler, cx0, cz0, cx1, cz1, query)
    published = []
    for index, (cx, cz) in enumerate(pending, 1):
        published.append(
            tc.write_tile(layout.cache_root, layout.digest, cx, cz, heights[(cx, cz)])
        )
        _clear_marker(layout, cx, cz)
        if progress is not None:
            progress(cx, cz, index, len(pending))
    return published


def group_windows(coords, query):
    """Group requested chunks by the canonical window that contains them.

    Grouping only decides which window is fetched first; it never changes what a
    window contains, because a window is always fetched whole.
    """
    groups = {}
    for cx, cz in coords:
        groups.setdefault((query.anchor(cx), query.anchor(cz)), []).append((cx, cz))
    return groups


def run_worker(
    layout,
    *,
    stop_after=None,
    idle_sleep=1.0,
    poll_limit=64,
    sampler_factory=None,
    progress=None,
    stop_event=None,
):
    """Persistent serial worker: one pipeline, bounded queue, no threads.

    A request marker is deleted only after its tile or its error file exists.
    Failures are terminal and reported once.  ``stop_after`` bounds the number of
    ticks (for tests) and ``sampler_factory(identity, layout)`` lets a caller
    inject an explicitly fake sampler instead of loading weights.
    """
    sampler = None
    summary = {"ticks": 0, "tiles": 0, "errors": 0, "stopped": "complete"}
    identity = _require_manifest(layout)["identity"]
    query = Query.from_identity(identity)
    factory = sampler_factory or load_sampler
    try:
        while True:
            if stop_event is not None and stop_event.is_set():
                summary["stopped"] = "requested"
                return summary
            summary["ticks"] += 1
            coords = read_requests(
                layout,
                on_invalid=lambda name, why: summary.setdefault(
                    "invalid_markers", []
                ).append("%s (%s)" % (name, why)),
            )[:poll_limit]
            if coords:
                groups = group_windows(coords, query)
                for _, members in sorted(groups.items()):
                    for cx, cz in members:
                        if layout.has_tile(cx, cz) or layout.has_error(cx, cz):
                            _clear_marker(layout, cx, cz)
                    pending = [
                        (cx, cz)
                        for cx, cz in members
                        if not layout.has_tile(cx, cz) and not layout.has_error(cx, cz)
                    ]
                    if not pending:
                        continue
                    if sampler is None:
                        # Loading the pipeline can fail (MPS unavailable, digest
                        # drift, missing snapshot). That failure must be terminal
                        # and reported, not raised out of the loop: an escaping
                        # exception leaves the markers forever pending, so the
                        # game shows "pending" and every restart repeats it.
                        try:
                            sampler = factory(identity, layout)
                        except (KeyboardInterrupt, SystemExit):
                            raise
                        except BaseException as exc:  # noqa: BLE001
                            # The pipeline is process-wide, so a load failure
                            # dooms every queued marker, not just this window's.
                            for cx, cz in read_requests(layout):
                                if not layout.has_error(cx, cz):
                                    mark_error(layout, cx, cz, repr(exc))
                                    summary["errors"] += 1
                                _clear_marker(layout, cx, cz)
                            summary["load_failure"] = repr(exc)
                            summary["stopped"] = "load-failed"
                            return summary
                    x0 = min(coord[0] for coord in pending)
                    x1 = max(coord[0] for coord in pending) + 1
                    z0 = min(coord[1] for coord in pending)
                    z1 = max(coord[1] for coord in pending) + 1
                    try:
                        heights = sample_chunks(
                            sampler, x0, z0, x1, z1, query
                        )
                    except (KeyboardInterrupt, SystemExit):
                        raise
                    except BaseException as exc:  # noqa: BLE001 - fail per tile
                        for cx, cz in pending:
                            if not layout.has_error(cx, cz):
                                mark_error(layout, cx, cz, repr(exc))
                                _clear_marker(layout, cx, cz)
                                summary["errors"] += 1
                        continue
                    for cx, cz in pending:
                        try:
                            tc.write_tile(
                                layout.cache_root,
                                layout.digest,
                                cx,
                                cz,
                                heights[(cx, cz)],
                            )
                        except BaseException as exc:  # noqa: BLE001
                            mark_error(layout, cx, cz, repr(exc))
                            _clear_marker(layout, cx, cz)
                            summary["errors"] += 1
                            continue
                        _clear_marker(layout, cx, cz)
                        summary["tiles"] += 1
                        if progress is not None:
                            progress(cx, cz)
            if stop_after is not None and summary["ticks"] >= stop_after:
                summary["stopped"] = "stop_after"
                return summary
            if stop_event is not None:
                stop_event.wait(idle_sleep)
            else:
                time.sleep(idle_sleep)
    except KeyboardInterrupt:
        summary["stopped"] = "interrupted"
        return summary
    finally:
        if sampler is not None:
            sampler.close()


# ---------------------------------------------------------------------------
# The worker command: ownership, staged status, graceful stop
# ---------------------------------------------------------------------------


def run_worker_command(
    layout,
    identity,
    *,
    owner_token=None,
    stop_after=None,
    idle_sleep=1.0,
    sampler_factory=None,
    stop_event=None,
    status_writer=None,
    locks_held=False,
):
    """Serve one identity under both locks, publishing staged status.

    The status is written at three real transitions only -- before the model
    load, immediately after a *validated* load and before the first query, and on
    each published tile -- so `:completed` is a count of tiles that exist, never a
    synthetic percentage.

    A process that cannot take the locks never constructs a status writer, so a
    failed second launch cannot overwrite the live owner's status.
    """
    device = identity["device"]
    # A caller that must classify contention *before* any status exists takes the
    # locks itself and passes `locks_held`; it then owns releasing them.
    if locks_held:
        identity_lock = device_lock = None
    else:
        identity_lock, device_lock = acquire_producer_locks(layout, device)
    writer = status_writer or StatusWriter(
        layout, tc.identity_digest(identity), owner_token=owner_token
    )
    try:
        writer.write("starting", 0, "waiting for a free device")
        writer.write("loading-model", 0, "loading pipeline")
        factory = sampler_factory or load_sampler
        inner = {"tiles": 0}
        real_factory = factory

        def staged_factory(factory_identity, factory_layout):
            sampler = real_factory(factory_identity, factory_layout)
            # The load has now been validated end to end (pins re-checked).
            writer.write("generating", 0, "sampling")
            return sampler

        def progress(cx, cz):
            inner["tiles"] += 1
            writer.write(
                "generating", inner["tiles"], "published %s" % coord_name(cx, cz)
            )

        summary = run_worker(
            layout,
            stop_after=stop_after,
            idle_sleep=idle_sleep,
            sampler_factory=staged_factory,
            progress=progress,
            stop_event=stop_event,
        )
        state = "failed" if summary.get("stopped") == "load-failed" else "idle"
        writer.write(
            state,
            inner["tiles"],
            summary.get("load_failure") or "stopped: %s" % summary["stopped"],
        )
        return summary
    except BaseException:
        try:
            writer.write("failed", 0, "worker aborted")
        except Exception:  # noqa: BLE001 - reporting must not mask the cause
            pass
        raise
    finally:
        if device_lock is not None:
            device_lock.release()
        if identity_lock is not None:
            identity_lock.release()


def _launch_with_receipt(args, receipt_layout, directory, token):
    """Run one launch and publish its outcome at ``worker-launch-<token>.janet``.

    The states progress in the order a launcher reads them: ``:launched`` before
    anything is validated, ``:failed`` when it will not serve, ``:reused`` when a
    live owner already serves this identity, and ``:started`` once this process
    holds both locks.

    ``:reused`` carries the *existing owner's* pid and token, never this child's:
    a freshly spawned child by definition has a different pid from the owner, so a
    receipt naming only the child could never establish that reuse is safe.
    """
    digest = os.path.basename(directory)

    def publish(state, **kwargs):
        try:
            write_launch_receipt(
                receipt_layout, digest, token, state, **kwargs
            )
        except (BackendError, OSError) as exc:
            # A receipt that cannot be written must not abort the launch: the
            # worker may still be entirely able to serve.
            print(
                "terrain_backend: launch receipt not written: %s" % exc,
                file=sys.stderr,
            )

    publish("launched", message="validating identity")
    try:
        identity, cache_root, layout = identity_from_stored_dir(
            directory,
            snapshot=args.snapshot,
            upstream=args.upstream,
            stats_source=args.stats_json,
        )
    except BackendError as exc:
        # Early validation failure: the outcome must be visible, not vanish.
        publish("failed", message=str(exc))
        print("terrain_backend: %s" % exc, file=sys.stderr)
        return 2

    # Take the locks here rather than inside `run_worker_command`, because the
    # contention outcome has to be classified before any status exists.
    try:
        identity_lock, device_lock = acquire_producer_locks(
            layout, identity["device"]
        )
    except LockBusy as exc:
        owner_pid, owner_token = _status_owner(layout, tc.identity_digest(identity))
        # The exception names the path that was refused; only the identity lock
        # means "this cache is already served". A device refusal is a different
        # condition and must not be reported as reuse.
        same_identity = identity_lock_path(layout) in str(exc)
        if same_identity:
            publish(
                "reused",
                worker_pid=owner_pid or 0,
                worker_token=owner_token,
                message="identity already served by pid %s"
                % (owner_pid or "unknown"),
            )
        else:
            # Another *identity* holds the device: do not imply reuse.
            publish("failed", message="device-busy: %s" % exc)
        print("terrain_backend: %s" % exc, file=sys.stderr)
        return EXIT_LOCKED

    try:
        publish("started", worker_pid=os.getpid(), message="serving")
        summary = _run_worker_locked(args, layout, identity)
    except BackendError as exc:
        publish("failed", message=str(exc))
        print("terrain_backend: %s" % exc, file=sys.stderr)
        return 2
    except OSError as exc:
        publish("failed", message=str(exc))
        print("terrain_backend: %s" % exc, file=sys.stderr)
        return 2
    finally:
        device_lock.release()
        identity_lock.release()
    print(json.dumps(summary, indent=2))
    return 0


def _run_worker_locked(args, layout, identity):
    """The worker loop, with the locks already held by the caller."""
    stop_event = threading.Event()

    def request_stop(_signum, _frame):
        stop_event.set()

    previous = {}
    for signal_name in ("SIGTERM", "SIGINT"):
        number = getattr(signal, signal_name, None)
        if number is None:
            continue
        previous[number] = signal.signal(number, request_stop)
    try:
        return run_worker_command(
            layout,
            identity,
            owner_token=getattr(args, "owner_token", None),
            stop_after=getattr(args, "stop_after", None),
            idle_sleep=getattr(args, "idle_sleep", 1.0),
            stop_event=stop_event,
            locks_held=True,
        )
    finally:
        for number, handler in previous.items():
            signal.signal(number, handler)


def _run_worker_command(args, layout, identity):
    """Wire the CLI worker: locks, signal-driven stop, status, exit codes."""
    stop_event = threading.Event()

    def request_stop(_signum, _frame):
        # Inference is indivisible: this sets the flag the loop already polls, so
        # a stop takes effect between queries, never mid-query.
        stop_event.set()

    previous = {}
    for signal_name in ("SIGTERM", "SIGINT"):
        number = getattr(signal, signal_name, None)
        if number is None:
            continue
        previous[number] = signal.signal(number, request_stop)
    try:
        try:
            summary = run_worker_command(
                layout,
                identity,
                owner_token=getattr(args, "owner_token", None),
                stop_after=getattr(args, "stop_after", None),
                idle_sleep=getattr(args, "idle_sleep", 1.0),
                stop_event=stop_event,
            )
        except LockBusy as exc:
            # Contention is the one retryable outcome: a launcher should reuse
            # the live worker, not report a broken cache.
            print("terrain_backend: %s" % exc, file=sys.stderr)
            return EXIT_LOCKED
        except BackendError as exc:
            # A real fault -- a failed status write, a drifted pin, a missing
            # snapshot. Returning 75 here would tell a launcher to wait on a
            # worker that will never appear.
            print("terrain_backend: %s" % exc, file=sys.stderr)
            return 2
        except OSError as exc:
            # A filesystem fault (the status file, the tile write) is likewise a
            # real failure, and must not reach a launcher as a bare traceback.
            print("terrain_backend: %s" % exc, file=sys.stderr)
            return 2
    finally:
        for number, handler in previous.items():
            signal.signal(number, handler)
    # The receipt is a retained outcome, not a liveness signal: the launcher owns
    # removing its own token file. Liveness stays the status file's job.
    print(json.dumps(summary, indent=2))
    return 0


# ---------------------------------------------------------------------------
# Doctor
# ---------------------------------------------------------------------------


def doctor(
    *,
    cache_root=DEFAULT_CACHE_ROOT,
    snapshot=DEFAULT_SNAPSHOT,
    upstream=DEFAULT_UPSTREAM,
    stats_source=DEFAULT_STATS_SOURCE,
    python=None,
):
    """Report exactly what is and is not proven on this machine.

    Runs without importing torch: it checks files, pins and digests, and states
    plainly which claims are unavailable (the locally built noise library is not
    the official wheel; a tree without git metadata cannot be verified by HEAD).
    """
    report = {
        "python": python or sys.version.split()[0],
        "cache_root": cache_root,
        "snapshot": snapshot,
        "upstream": upstream,
        "problems": [],
        "checks": {},
    }

    def check(name, fn):
        try:
            report["checks"][name] = dict(fn(), ok=True)
        except BaseException as exc:  # noqa: BLE001 - doctor reports, never dies
            report["problems"].append("%s: %s" % (name, exc))
            report["checks"][name] = {"ok": False, "error": str(exc)}

    def check_snapshot():
        config_path = os.path.join(snapshot, "config.json")
        return {
            "config_sha256": _sha256_file(config_path)
            if os.path.isfile(config_path)
            else None,
            "submodels": {
                name: os.path.isdir(os.path.join(snapshot, name))
                for name in ("coarse_model", "base_model", "decoder_model")
            },
        }

    def check_pins():
        """Hash every pinned config and weight, so `doctor` reports them too.

        Both blocks from one call, for the same reason `load_sampler` uses one:
        a snapshot that passes the weights while its submodel configs drifted is
        exactly the gap this check exists to catch, and reporting only one half
        would reproduce it in the diagnostic tool.
        """
        return verify_snapshot(snapshot)

    def check_config_pins():
        return {"native_resolution": read_snapshot_config(snapshot).get(
            "native_resolution")}

    def check_upstream():
        pin = verify_upstream(upstream)
        if pin["pin_verified_by"] == "source-hash":
            if pin["source_sha256"] != UPSTREAM_SOURCE_SHA256:
                raise BackendError(
                    "upstream source digest %s does not match the pin %s"
                    % (pin["source_sha256"], UPSTREAM_SOURCE_SHA256)
                )
        return pin

    def check_stats():
        source = stats_source_path(cache_root, stats_source)
        stats = extract_frozen_stats(source)
        return {"source": source, "stats_sha256": _sha256_bytes(canonical_json(stats))}

    def check_cache():
        identities = []
        if os.path.isdir(cache_root):
            identities = sorted(
                name
                for name in os.listdir(cache_root)
                if os.path.isdir(os.path.join(cache_root, name))
            )
        return {"identities": identities}

    check("snapshot", check_snapshot)
    check("pins", check_pins)
    check("config", check_config_pins)
    check("upstream", check_upstream)
    check("stats", check_stats)
    check("noise_lib", lambda: noise_library_digest(_noise_module_file()))
    check("cache", check_cache)
    report["ok"] = not report["problems"]
    return report


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _parse_chunk_rect(values):
    if len(values) == 1:
        cx0 = cz0 = values[0]
        cx1, cz1 = cx0 + 1, cz0 + 1
    elif len(values) == 2:
        cx0, cz0 = values
        cx1, cz1 = cx0 + 1, cz0 + 1
    elif len(values) == 4:
        cx0, cz0, cx1, cz1 = values
    else:
        raise BackendError("--chunks takes 1, 2 or 4 integers")
    if cx1 <= cx0 or cz1 <= cz0:
        raise BackendError("--chunks rectangle must be non-empty and exclusive")
    return cx0, cz0, cx1, cz1


def _resolve_cache_root(args):
    """Resolve ``--cache-root`` given before or after the subcommand."""
    chosen = (
        getattr(args, "cache_root", None)
        or getattr(args, "cache_root_top", None)
        or DEFAULT_CACHE_ROOT
    )
    return os.path.abspath(chosen)


def identity_from_stored_dir(
    directory, *, snapshot=None, upstream=None, stats_source=None
):
    """Rebuild an identity from a stored directory and prove it belongs there.

    The stored ``identity.json`` is *read but not trusted*: every pinned artefact
    it names is re-verified from disk (snapshot configs and weights, the frozen
    stats table, the upstream checkout), the identity is rebuilt from those
    verified bytes, and the resulting digest must equal the directory name.  A
    JSON file that merely claims a digest therefore cannot select generation
    parameters the cache was not baked with.

    Returns ``(identity, cache_root, layout)``.
    """
    directory = os.path.abspath(directory)
    if not os.path.isdir(directory):
        raise BackendError("identity directory is missing: %s" % directory)
    cache_root, name = os.path.split(directory)
    layout = Layout.open(cache_root, name)
    # The manifest is the immutable witness and is read first, so a missing or
    # conflicting manifest is refused before any pin work. Its ``identity`` block
    # additionally carries the wire ``format`` stamp, which is added at write time
    # and is not part of the identity descriptor -- so the descriptor comparison
    # below uses the stored record instead.
    manifest = _require_manifest(layout)
    if manifest.get("identity_digest") != name:
        raise BackendError(
            "manifest in %s names digest %s, not the directory name"
            % (name, manifest.get("identity_digest"))
        )
    record_path = os.path.join(layout.root, IDENTITY_RECORD)
    if not os.path.isfile(record_path):
        raise BackendError("identity record is missing: %s" % record_path)
    stored = _read_json(record_path)["identity"]
    # An explicit path is honoured, and a path that cannot reproduce the stored
    # pins is a hard error -- falling back to the machine default would verify a
    # *different* artefact set and then blame the directory.
    snapshot = snapshot or DEFAULT_SNAPSHOT
    upstream = upstream or DEFAULT_UPSTREAM
    if not os.path.isdir(snapshot):
        raise BackendError(
            "snapshot directory is missing: %s (the identity cannot be "
            "re-verified without it)" % snapshot
        )
    if not os.path.isdir(upstream):
        raise BackendError(
            "upstream checkout is missing: %s" % upstream
        )
    config = read_snapshot_config(snapshot)
    pin = verify_upstream(upstream)
    stats = extract_frozen_stats(stats_source_path(cache_root, stats_source))
    query = Query.from_identity(stored)
    sampler = stored["sampler"]
    rebuilt = build_identity(
        seed=stored["seed"],
        pixels_per_voxel=stored["pixels_per_voxel"],
        dtype=stored["dtype"],
        device=stored["device"],
        snapshot=snapshot,
        config=config,
        pin=pin,
        stats=stats,
        origin_pixels=tuple(query.origin_pixels),
        window_chunks=query.window_chunks,
        max_samples=query.max_samples,
        decoder_geometry=(sampler["decoder_window"], sampler["decoder_stride"]),
        noise_lib={
            "sha256": stored["noise_lib_sha256"],
            "note": stored["noise_lib_note"],
        },
    )
    digest = tc.identity_digest(rebuilt)
    if digest != name:
        raise BackendError(
            "identity directory %s does not match the pins it stores: rebuilt "
            "digest is %s. The directory was renamed, or its snapshot/stats no "
            "longer hold the bytes this identity claims." % (name, digest)
        )
    if canonical_json(rebuilt) != canonical_json(stored):
        raise BackendError(
            "identity %s rebuilt from disk differs from the stored record" % name
        )
    return rebuilt, cache_root, layout


def _identity_from_args(args):
    cache_root = _resolve_cache_root(args)
    pin = verify_upstream(args.upstream)
    stats = extract_frozen_stats(
        stats_source_path(cache_root, args.stats_json)
    )
    identity = build_identity(
        seed=args.seed,
        pixels_per_voxel=args.pixels_per_voxel,
        dtype=args.dtype,
        device=args.device,
        snapshot=args.snapshot,
        config=read_snapshot_config(args.snapshot),
        pin=pin,
        stats=stats,
        origin_pixels=(args.origin_x, args.origin_z),
        window_chunks=args.window_chunks,
        max_samples=args.max_samples,
        decoder_geometry=(args.decoder_tile, args.decoder_stride),
    )
    return identity, cache_root


def build_parser():
    """Build the CLI.

    ``--cache-root`` is accepted both before and after the subcommand.  argparse
    applies a top-level option to the top-level parser only, and a shared parent
    parser would have its subparser default overwrite the top-level value, so the
    flag is declared under two destinations and resolved once in
    :func:`_resolve_cache_root`.
    """
    parser = argparse.ArgumentParser(
        prog="terrain_backend",
        description="Deterministic Terrain Diffusion tile backend for TrineXraft.",
    )
    parser.add_argument("--cache-root", dest="cache_root_top", default=None)
    sub = parser.add_subparsers(dest="command", required=True)

    p_doctor = sub.add_parser("doctor", help="verify pins, snapshot, stats and cache")
    p_doctor.add_argument("--cache-root", dest="cache_root", default=None)
    p_doctor.add_argument("--snapshot", default=DEFAULT_SNAPSHOT)
    p_doctor.add_argument("--upstream", default=DEFAULT_UPSTREAM)
    p_doctor.add_argument("--stats-json", default=None)
    p_doctor.add_argument("--json", action="store_true")

    for name, help_text in (
        ("descriptor", "print the identity descriptor"),
        ("init", "create the identity directory and bridge manifest"),
        ("bake", "sample a chunk rectangle and publish tiles"),
        ("worker", "run the persistent request worker"),
    ):
        p = sub.add_parser(name, help=help_text)
        p.add_argument("--cache-root", dest="cache_root", default=None)
        p.add_argument("--snapshot", default=DEFAULT_SNAPSHOT)
        p.add_argument("--upstream", default=DEFAULT_UPSTREAM)
        p.add_argument("--stats-json", default=None)
        p.add_argument("--seed", type=int, default=DEFAULT_SEED)
        p.add_argument("--pixels-per-voxel", type=int, default=DEFAULT_PIXELS_PER_VOXEL)
        p.add_argument("--dtype", default=DEFAULT_DTYPE)
        p.add_argument("--device", default=DEFAULT_DEVICE)
        p.add_argument(
            "--origin-x", type=int, default=0,
            help="world pixel origin on the x axis (hashed; shifts the whole world)",
        )
        p.add_argument(
            "--origin-z", type=int, default=0,
            help="world pixel origin on the z axis (hashed; shifts the whole world)",
        )
        p.add_argument(
            "--window-chunks", type=int, default=DEFAULT_WINDOW_CHUNKS,
            help="chunks per axis in one canonical query window (hashed)",
        )
        p.add_argument(
            "--decoder-tile", type=int, default=512,
            help="decoder window: 512 (upstream default) or 256 (MPS-reliable)",
        )
        p.add_argument(
            "--decoder-stride", type=int, default=384,
            help="decoder stride: 384 (upstream default) or 192",
        )
        p.add_argument("--max-samples", type=int, default=DEFAULT_MAX_SAMPLES,
                       help="max pixels per axis in one query (hashed)")
        if name == "bake":
            p.add_argument("--chunks", type=int, nargs="+", required=True)
            p.add_argument(
                "--dry-run",
                action="store_true",
                help="resolve the identity and print the planned rectangle only",
            )
        if name == "worker":
            p.add_argument("--stop-after", type=int, default=None)
            p.add_argument("--idle-sleep", type=float, default=1.0)
            p.add_argument(
                "--from-identity",
                default=None,
                help="full identity directory; every generation parameter is "
                "read from it and re-verified, so launchers cannot drift",
            )
            p.add_argument(
                "--owner-token",
                default=None,
                help="opaque launcher token recorded in the status bridge",
            )

    p_fetch = sub.add_parser(
        "fetch-stats", help="download the pinned frozen conditioning table"
    )
    p_fetch.add_argument("--out", default=DEFAULT_STATS_SOURCE)
    p_fetch.add_argument("--force", action="store_true")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "fetch-stats":
        out = os.path.abspath(args.out)
        if os.path.exists(out) and not args.force:
            raise SystemExit("refusing to overwrite %s without --force" % out)
        record = extract_frozen_stats(json.loads(fetch_frozen_stats().decode("utf-8")))
        _atomic_write(out, canonical_json(record) + b"\n")
        print(json.dumps({"path": out, "sha256": _sha256_file(out)}, indent=2))
        return 0

    # Resolved only after the dispatches that take no cache root, since
    # `fetch-stats` has no --cache-root and would raise AttributeError.
    cache_root = _resolve_cache_root(args)

    if args.command == "doctor":
        report = doctor(
            cache_root=cache_root,
            snapshot=args.snapshot,
            upstream=args.upstream,
            stats_source=args.stats_json,
        )
        if args.json:
            print(json.dumps(report, indent=2, sort_keys=True))
        else:
            for name, payload in sorted(report["checks"].items()):
                print("%-11s %s" % (name, "ok" if payload.get("ok") else "FAIL"))
            for problem in report["problems"]:
                print("problem: %s" % problem)
            print("doctor: %s" % ("ok" if report["ok"] else "FAILED"))
        return 0 if report["ok"] else 1

    # A launcher names the cache it wants served and nothing else. Every
    # generation parameter comes from the stored, re-verified identity, so the
    # flags cannot drift into a *different* cache than the game opened.
    if args.command == "worker" and args.from_identity:
        directory = os.path.abspath(args.from_identity)
        receipt_layout = Layout.open(
            os.path.dirname(directory), os.path.basename(directory)
        )
        token = getattr(args, "owner_token", None)
        if token is None:
            # No nonce: no receipt. A launcher that wants an outcome to read must
            # name one, because a shared default path would let two launches
            # clobber each other's result.
            identity, cache_root, layout = identity_from_stored_dir(
                args.from_identity,
                snapshot=args.snapshot,
                upstream=args.upstream,
                stats_source=args.stats_json,
            )
            return _run_worker_command(args, layout, identity)
        validate_token(token)
        return _launch_with_receipt(
            args, receipt_layout, directory, token
        )

    identity, cache_root = _identity_from_args(args)
    digest = tc.identity_digest(identity)

    if args.command == "descriptor":
        print(
            json.dumps(
                {"identity": tc.identity_descriptor(identity), "identity_digest": digest},
                indent=2,
                sort_keys=True,
            )
        )
        return 0

    if args.command == "init":
        digest, layout = write_identity(
            cache_root, identity, stats_source=args.stats_json
        )
        print(
            json.dumps(
                {
                    "identity_digest": digest,
                    "directory": layout.root,
                    "seed": identity["seed"],
                },
                indent=2,
            )
        )
        return 0

    # `worker` must never create a cache. It is the long-running consumer of a
    # queue that already exists, so an absent identity means it was pointed at the
    # wrong root or started with drifted flags -- in both cases creating a
    # directory would make it report a healthy zero-work summary while the real
    # queue sat untouched somewhere else. `init` is the documented way to create
    # an identity; `bake` may also create one, because it is an explicit,
    # bounded command that names its rectangle.
    if args.command == "worker":
        digest = tc.identity_digest(identity)
        _, layout = open_identity(cache_root, digest)
    else:
        digest, layout = open_or_create_identity(
            cache_root, identity, stats_source=args.stats_json
        )

    if args.command == "bake":
        cx0, cz0, cx1, cz1 = _parse_chunk_rect(args.chunks)
        if args.dry_run:
            print(
                json.dumps(
                    {
                        "identity_digest": digest,
                        "directory": layout.root,
                        "rectangle": [cx0, cz0, cx1, cz1],
                        "pixels_per_voxel": identity["pixels_per_voxel"],
                        "query": identity["query"],
                    },
                    indent=2,
                )
            )
            return 0
        # `bake` takes the same identity lock as `worker`: publishing tiles for
        # coordinates a live worker is also answering would have both processes
        # driving one device and racing the same request markers.
        try:
            identity_lock, device_lock = acquire_producer_locks(
                layout, identity["device"]
            )
        except LockBusy as exc:
            print("terrain_backend: %s" % exc, file=sys.stderr)
            return EXIT_LOCKED
        try:
            sampler = load_sampler(
                identity, layout, snapshot=args.snapshot, upstream=args.upstream
            )
            try:
                published = bake_chunks(
                    layout,
                    sampler,
                    cx0=cx0,
                    cz0=cz0,
                    cx1=cx1,
                    cz1=cz1,
                    query=Query.from_identity(identity),
                    progress=lambda cx, cz, done, total: print(
                        "%d/%d %s" % (done, total, coord_name(cx, cz)), flush=True
                    ),
                )
            finally:
                sampler.close()
        except LockBusy as exc:
            print("terrain_backend: %s" % exc, file=sys.stderr)
            return EXIT_LOCKED
        except BackendError as exc:
            print("terrain_backend: %s" % exc, file=sys.stderr)
            return 2
        finally:
            device_lock.release()
            identity_lock.release()
        print(json.dumps({"published": len(published)}, indent=2))
        return 0

    if args.command == "worker":
        # Flag-derived and stored-directory launches share one path, so ownership
        # and status apply however the worker was started.
        return _run_worker_command(args, layout, identity)

    raise SystemExit("unknown command %r" % args.command)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BackendError as exc:
        print("terrain_backend: %s" % exc, file=sys.stderr)
        sys.exit(2)
