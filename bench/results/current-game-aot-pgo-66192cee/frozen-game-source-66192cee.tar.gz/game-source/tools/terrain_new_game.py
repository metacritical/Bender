"""Temporary Python Terrain Diffusion provider for New Game.

This is the *temporary* generator behind New Game until the native provider is
verified. It runs the real pinned ``WorldPipeline`` -- the same snapshot, the same
weights and the same frozen conditioning table the offline backend already pins --
and exports a scenic format-3 cache that the existing Janet reader already reads.
It deliberately does **not** reimplement inference, and it invents **no** parallel
artifact format: the artifact is produced by :func:`scenic_terrain.import_raw`,
which is the verified exporter.

Contract
--------
**One process, no children.** Nothing here launches a child process, starts a
background worker, or downloads weights. The caller supervises this process; SIGTERM
is honoured by abandoning the in-progress generation and leaving **no ready flag**
and no partial artifact. This is enforced by a test that scans this module for the
child-process and network entry points, so the prose must not name them either.

**Offline readiness.** ``--check`` answers "could this run" without downloading
anything and without touching a model: it verifies the local snapshot, its pinned
config and weight digests, the frozen conditioning table digest, the upstream
source pin, and writes nothing.

**Finite generation.** A run samples one bounded rectangle of native pixels
(``--size``, default 128, capped at 512) and emits one whole map. It never grows
an unbounded world, and it makes no claim to be the infinite generator: that is
the native provider's job.

The defaults are chosen to be honest about being small: ``--size 128`` at
``--meters-per-voxel 25`` covers 128 native pixels = 8 chunks = a 128-block map.
It is a bounded **sample area**, clearly labelled as such, and it deliberately
downsamples instead of fabricating 512-block detail the model never produced.
At the inland origin (100000, 100000) this region is land, and the model's 1785 m
peak maps to about ``1785/25 + 28 = 99``, well inside the 4..252 scenic band and
below the reserved top, so the map is not clamped.

**Truthful milestones only.** Progress is reported as discrete stages
(``resolve``, ``verify``, ``load``, ``sample``, ``export``, ``verify-artifact``,
``ready``) with counts that are actually known. There is no synthetic percentage
and no interpolated ETA. ``ready`` is emitted **only** after the finished artifact
has been re-read from disk and verified.

**Provenance is recorded, never asserted.** The artifact carries the seed, the
model repository and revision, the weight/config/stat digests, the sampler
geometry, the mapping and the sampling rectangle. Anything not measured is absent
rather than guessed.

**Seed.** ``--seed`` is the *world* seed: any integer in ``0..2**31-1``, zero
included. Zero is required to work, because it is a number a player can type.

Upstream evaluates ``seed or random.randint(...)`` in its synthetic-map factory,
so handing it a zero seed would silently draw a random world and the recorded
seed would stop describing the terrain. The provider therefore maps the world
seed to a *model* seed:

    world seed 0            -> model seed 2147483647   (SEED_MAPPING_VERSION)
    world seed 1..2**31-1   -> unchanged

Only zero is touched, so existing worlds and existing caches keep their seeds.
The artifact records all three values -- ``world_seed``, ``model_seed`` and
``seed_mapping`` -- inside provenance, which the scenic identity hashes.

Consequence, stated plainly: world seed 0 and world seed 2147483647 sample the
same terrain. That is a **deliberate, recorded collision**, not aliasing. The two
artifacts remain distinct identities because their provenance differs, and the
mapping version makes a future re-choice of constant mint a new digest rather
than silently reusing an older map.

Artifact
--------
Output is a scenic cache root::

    <out>/<identity>/manifest.json       TDS3 manifest, 12 keys
    <out>/<identity>/manifest.janet      bridge twin for the Janet reader
    <out>/<identity>/provenance.json     CRC-bound map record (not parsed by Janet)
    <out>/<identity>/tiles/<cx>_<cz>.tdh TDS3 tiles
    <out>/<identity>/summary.json        export summary
    <out>/<identity>/READY               written last, only after verification

``<out>`` must be empty or absent; a non-empty directory is refused, because
overwriting a map a running game may be reading is not a recoverable operation.

Cancellation is cooperative and **delayed**: SIGTERM sets a flag that is checked
between stages. A long Python-level call inside the model cannot be interrupted
mid-C, so a supervisor that needs a hard bound should send TERM to the process
group and then KILL after a short grace period. That is safe: ``READY`` is written
last, by atomic rename, only after the artifact has been re-verified, so a killed
run can never leave a marker claiming success. A partially written artifact is
left in place for inspection rather than silently deleted.

Threads: this module starts none and sets none. The sampler inherits whatever the
runtime configures, so the supervisor should bound the job to a couple of CPU
threads to avoid oversubscription.

CLI
---
::

    terrain_new_game.py --check --out DIR
    terrain_new_game.py --out DIR --seed 12345 [--size 128] [--stage]

Exit codes: ``0`` artifact ready, ``2`` refused preconditions, ``3`` generation
failed, ``130`` cancelled by SIGTERM.

Testability
-----------
``main(..., pipeline_factory=..., stages_writer=...)`` accepts a fake pipeline so
the whole prepare → sample → export → verify sequence is exercised with no torch
and no GPU. The fake is a test fixture and proves the plumbing only.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import shutil
import signal
import sys

import scenic_terrain as st
import terrain_backend as tb
import terrain_cache as tc

#: Native pixels sampled per axis. Capped so one run stays bounded.
DEFAULT_SIZE = 128
MIN_SIZE = 16
MAX_SIZE = 512

#: Which sample of the world this run covers, in native pixels.
DEFAULT_ORIGIN = (100000, 100000)

DEFAULT_METERS_PER_VOXEL = 25.0
DEFAULT_SEA_LEVEL = 28
DEFAULT_SEED = 12345
DEFAULT_PROFILE = "alpine"

#: World voxel placement of the map's first tile. Chunk-aligned by construction.
DEFAULT_WORLD_ORIGIN = (-16, -16)

#: How many climate channels upstream's ``_compute_climate`` returns, in order:
#: elevation-adjusted mean temperature (C), temperature seasonality,
#: annual precipitation (mm/yr), precipitation variability, and the
#: elevation/temperature correction coefficient (C/m). The fifth channel is NOT
#: humidity. A pipeline returning any other count is refused, not reinterpreted.
CLIMATE_CHANNELS = 5

READY_NAME = "READY"

#: Stages a run actually reaches, in order. The last one is written only after
#: the artifact has been re-verified.
STAGES = ("resolve", "verify", "load", "sample", "export", "verify-artifact", "ready")

#: Terminal stages that are NOT success. A progress file may legally end on one
#: of these, which is how the supervisor distinguishes "still working" from
#: "stopped without an artifact"; it is never a substitute for the READY marker.
PROGRESS_TERMINAL_FAILURE = "failed"
PROGRESS_TERMINAL_CANCELLED = "cancelled"

#: Every stage a progress file may carry. A whitelist, so the game can switch on
#: the keyword without defending against arbitrary text.
PROGRESS_STAGES = STAGES + (PROGRESS_TERMINAL_FAILURE, PROGRESS_TERMINAL_CANCELLED)

#: The progress record schema version. Bumped if the key set changes.
PROGRESS_VERSION = 1

#: Hard cap, matching the reader's own bound (src/generation-job.janet).
PROGRESS_MAX_BYTES = 4096

PROGRESS_DEFAULT_NAME = "progress.janet"

EXIT_READY = 0
EXIT_REFUSED = 2
EXIT_FAILED = 3
EXIT_CANCELLED = 130

#: The world-seed domain the UI and catalogue use. 0 is a legitimate world seed:
#: it is a number a player can type, and it must produce reproducible terrain.
MAX_SEED = (2 ** 31) - 1

#: Version of the world-seed -> model-seed mapping. Bumping it mints a new
#: provenance digest, so a map baked under an older mapping can never be
#: mistaken for one baked under this one.
SEED_MAPPING_VERSION = "nonzero-v1"

#: The model seed substituted for CONCRETE world seed 0. Upstream evaluates
#: ``seed or random.randint(...)`` in its synthetic-map factory, so a zero model
#: seed silently draws a random world and the recorded seed stops describing the
#: terrain. Substituting a fixed nonzero value keeps seed 0 reproducible while
#: never handing upstream a falsy seed. Chosen as the largest valid 31-bit value
#: so it can never collide with an in-range world seed's own model seed.
ZERO_SEED_MODEL_SEED = MAX_SEED


class ProviderError(RuntimeError):
    """A precondition failed; nothing was generated."""


class Cancelled(RuntimeError):
    """SIGTERM arrived; the run must leave no ready flag behind."""


# ---------------------------------------------------------------------------
# Cancellation
# ---------------------------------------------------------------------------


class _Cancellation:
    """Turns SIGTERM into a flag the sampling loop can observe.

    The handler only sets a flag. It does not raise from the signal context and
    does not touch the filesystem, so an interrupted run cannot observe a
    half-written ready marker.
    """

    def __init__(self):
        self.requested = False
        self._previous = None

    def __enter__(self):
        try:
            self._previous = signal.signal(signal.SIGTERM, self._handle)
        except ValueError:  # not the main thread (tests); flag still usable
            self._previous = None
        return self

    def __exit__(self, *_exc):
        if self._previous is not None:
            try:
                signal.signal(signal.SIGTERM, self._previous)
            except ValueError:
                pass
        return False

    def _handle(self, _signum, _frame):
        self.requested = True

    def check(self, stage):
        if self.requested:
            raise Cancelled("SIGTERM received during %s" % stage)


# ---------------------------------------------------------------------------
# Stages: discrete, measured, no fake percentages
# ---------------------------------------------------------------------------


def render_progress(*, stage, completed=None, total=None, message=None):
    """Render one progress record as an inert Janet table, or raise.

    Janet has no JSON parser (``src/terrain-cache.janet`` says so explicitly), so
    this is Janet *data*: one table literal whose values are a whitelisted
    keyword, two optional non-negative integers, and an escaped string. The reader
    parses it and never evaluates it, exactly like ``manifest.janet``.

    The string escaping reuses the backend's proven escaper rather than growing a
    second one, so a message can never break the literal.
    """
    if stage not in PROGRESS_STAGES:
        raise ProviderError("unknown progress stage %r" % stage)
    for name, value in (("completed", completed), ("total", total)):
        if value is None:
            continue
        if isinstance(value, bool) or not isinstance(value, int):
            raise ProviderError("progress %s must be an int or nil" % name)
        if value < 0:
            raise ProviderError("progress %s must not be negative" % name)
    if message is not None and not isinstance(message, str):
        raise ProviderError("progress message must be a string or nil")

    parts = [":version %d" % PROGRESS_VERSION, ":stage :%s" % stage]
    parts.append(":completed %s" % ("nil" if completed is None else str(completed)))
    parts.append(":total %s" % ("nil" if total is None else str(total)))
    parts.append(":message %s" % (
        "nil" if message is None else tb._janet_string(message)
    ))
    text = "{%s}\n" % " ".join(parts)
    encoded = text.encode("utf-8")
    if len(encoded) > PROGRESS_MAX_BYTES:
        raise ProviderError(
            "progress record is %d bytes, over the %d byte reader cap"
            % (len(encoded), PROGRESS_MAX_BYTES)
        )
    return encoded


def write_progress(path, *, stage, completed=None, total=None, message=None):
    """Write the progress sidecar atomically; a reader never sees a partial file."""
    data = render_progress(
        stage=stage, completed=completed, total=total, message=message
    )
    directory = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(directory, exist_ok=True)
    temp = os.path.join(directory, ".progress-tmp-%d" % os.getpid())
    try:
        with open(temp, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return path


def read_progress(path):
    """Parse a progress sidecar into a dict, for tests and Python-side tooling.

    A small strict reader for exactly the five keys :func:`render_progress`
    writes. The real consumer is Janet's own ``parse``; this exists so the
    round trip can be asserted offline without a Janet runtime.
    """
    with open(path, "rb") as handle:
        raw = handle.read(PROGRESS_MAX_BYTES + 1)
    if len(raw) > PROGRESS_MAX_BYTES:
        raise ProviderError("progress file exceeds %d bytes" % PROGRESS_MAX_BYTES)
    text = raw.decode("utf-8").strip()
    if not (text.startswith("{") and text.endswith("}")):
        raise ProviderError("progress file is not a single table")
    body = text[1:-1].strip()

    record = {}
    index = 0
    length = len(body)
    while index < length:
        if body[index] != ":":
            raise ProviderError("expected a key at offset %d" % index)
        index += 1
        start = index
        while index < length and (body[index].isalnum() or body[index] in "-_"):
            index += 1
        key = body[start:index]
        if index >= length or body[index] != " ":
            raise ProviderError("key %r has no value" % key)
        index += 1
        if body.startswith("nil", index):
            record[key] = None
            index += 3
        elif body[index] == ":":
            index += 1
            start = index
            while index < length and (body[index].isalnum() or body[index] in "-_"):
                index += 1
            record[key] = body[start:index]
        elif body[index] == '"':
            # Round-trip through json for the escape rules, which match.
            decoder = json.JSONDecoder()
            value, consumed = decoder.raw_decode(body[index:])
            record[key] = value
            index += consumed
        else:
            start = index
            while index < length and (body[index].isdigit() or body[index] == "-"):
                index += 1
            record[key] = int(body[start:index])
        while index < length and body[index] == " ":
            index += 1
    return record


class Stages:
    """Emit one JSON line per discrete stage, and optionally a Janet sidecar.

    A stage is only emitted when it is *reached*; there is no progress estimate,
    because a fraction of an unknown cost is a fabricated number. The JSON log on
    stderr is for humans reading a terminal; ``progress_path`` is the machine
    channel the game polls, and it is written only when a path is supplied.
    """

    def __init__(self, stream=None, progress_path=None):
        self.stream = stream if stream is not None else sys.stderr
        self.progress_path = progress_path
        self.reached = []
        self.cancelled = False

    def _write_sidecar(self, stage, detail):
        if self.progress_path is None:
            return
        write_progress(
            self.progress_path,
            stage=stage,
            completed=detail.get("completed"),
            total=detail.get("total"),
            message=detail.get("message"),
        )

    def emit(self, stage, **detail):
        if stage not in STAGES:
            raise ProviderError("unknown stage %r" % stage)
        self.reached.append(stage)
        record = {"stage": stage}
        record.update(detail)
        self.stream.write(json.dumps(record, sort_keys=True) + "\n")
        self.stream.flush()
        self._write_sidecar(stage, detail)

    def fail(self, message):
        """Record a terminal failure. Never a success signal."""
        self.stream.write(
            json.dumps({"stage": PROGRESS_TERMINAL_FAILURE}, sort_keys=True) + "\n"
        )
        self.stream.flush()
        self._write_sidecar(PROGRESS_TERMINAL_FAILURE, {"message": message})

    def cancel(self, stage):
        self.cancelled = True
        self.stream.write(
            json.dumps({"stage": PROGRESS_TERMINAL_CANCELLED, "during": stage},
                       sort_keys=True) + "\n"
        )
        self.stream.flush()
        self._write_sidecar(
            PROGRESS_TERMINAL_CANCELLED, {"message": "cancelled during %s" % stage}
        )


# ---------------------------------------------------------------------------
# Preconditions: everything checkable without a model
# ---------------------------------------------------------------------------


def resolve_seed(world_seed):
    """Map a world seed to the model seed that is actually sampled.

    ``world_seed`` is what the UI, the catalogue and the save file carry: any
    integer in ``0..2**31-1``, zero included. ``model_seed`` is what
    ``WorldPipeline`` is given, and it is **never** zero, because upstream treats
    a falsy seed as "draw a random world".

    Only zero is remapped. Every nonzero world seed keeps ``model_seed ==
    world_seed``, so existing maps and existing caches are untouched.

    Two different world seeds can therefore share terrain (0 and 2**31-1).
    That is a deliberate, recorded collision, not an aliasing bug: the artifact
    records both numbers plus the mapping version, and the version is part of
    the hashed provenance, so the two artifacts remain distinct identities.
    """
    if isinstance(world_seed, bool) or not isinstance(world_seed, int):
        raise ProviderError("world seed must be an int")
    if world_seed < 0 or world_seed > MAX_SEED:
        raise ProviderError("world seed must be in 0..%d" % MAX_SEED)
    if world_seed == 0:
        return {
            "world_seed": 0,
            "model_seed": ZERO_SEED_MODEL_SEED,
            "seed_mapping": SEED_MAPPING_VERSION,
            "remapped": True,
        }
    return {
        "world_seed": world_seed,
        "model_seed": world_seed,
        "seed_mapping": SEED_MAPPING_VERSION,
        "remapped": False,
    }


def validate_settings(*, seed, size, meters_per_voxel, sea_level, profile,
                      origin, world_origin):
    """Reject bad settings before any expensive work."""
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise ProviderError("seed must be an int")
    if seed < 0 or seed > MAX_SEED:
        raise ProviderError("seed must be in 0..%d" % MAX_SEED)
    if isinstance(size, bool) or not isinstance(size, int):
        raise ProviderError("size must be an int")
    if not MIN_SIZE <= size <= MAX_SIZE:
        raise ProviderError(
            "size must be %d..%d native pixels (got %d)" % (MIN_SIZE, MAX_SIZE, size)
        )
    if size % tc.TILE_SIZE:
        raise ProviderError(
            "size must be a multiple of %d so the map is whole tiles" % tc.TILE_SIZE
        )
    if not isinstance(meters_per_voxel, (int, float)) or meters_per_voxel <= 0:
        raise ProviderError("meters_per_voxel must be positive")
    if isinstance(sea_level, bool) or not isinstance(sea_level, int):
        raise ProviderError("sea_level must be an int")
    for name, value in (("origin", origin), ("world_origin", world_origin)):
        if len(tuple(value)) != 2:
            raise ProviderError("%s must hold two integers" % name)
        for part in value:
            if isinstance(part, bool) or not isinstance(part, int):
                raise ProviderError("%s must hold integers" % name)
    if world_origin[0] % tc.TILE_SIZE or world_origin[1] % tc.TILE_SIZE:
        raise ProviderError(
            "world_origin %s must be chunk-aligned (%d blocks)"
            % (world_origin, tc.TILE_SIZE)
        )
    if not isinstance(profile, str) or not profile:
        raise ProviderError("profile must be a non-empty string")
    return True


#: Runtime packages the sampler imports, with the versions verified for this
#: backend. Resolved with ``importlib.util.find_spec`` + distribution metadata, so
#: a readiness probe never pays torch's multi-second import cost and never loads a
#: model. Each entry is ``(distribution, import-name, expected-version)``.
#: A version of ``None`` means "must be present, version not pinned".
REQUIRED_RUNTIME = (
    ("torch", "torch", "2.13.0"),
    ("numpy", "numpy", "2.5.1"),
    ("diffusers", "diffusers", "0.42.1"),
    ("safetensors", "safetensors", "0.8.0"),
    ("infinite-tensor", "infinite_tensor", "0.4.0"),
    ("ema-pytorch", "ema_pytorch", "0.8.3"),
    ("torchvision", "torchvision", "0.28.0"),
)


def check_dependencies(required=REQUIRED_RUNTIME, *, find_spec=None, distribution=None):
    """Report whether the runtime can import what the sampler needs.

    Uses ``find_spec`` and distribution metadata only: no package is imported, so
    torch's load cost is avoided and a readiness probe stays a pure read. ``torch``
    in particular must NOT be imported here -- importing it takes seconds and
    initializes device state.

    ``find_spec`` and ``distribution`` are injectable so a test can prove the
    absent-package path without uninstalling anything.
    """
    if find_spec is None:
        import importlib.util as _util

        find_spec = _util.find_spec
    if distribution is None:
        import importlib.metadata as _metadata

        distribution = _metadata.version

    entries = {}
    missing = []
    mismatched = []
    for dist, module, expected in required:
        try:
            spec = find_spec(module)
        except (ImportError, ValueError, AttributeError):
            spec = None
        try:
            version = distribution(dist)
        except BaseException:  # noqa: BLE001 - PackageNotFoundError and friends
            version = None
        present = spec is not None and version is not None
        entry = {
            "module": module,
            "present": present,
            "version": version,
            "expected": expected,
        }
        if not present:
            missing.append(dist)
        elif expected is not None and version != expected:
            # Recorded, but not a hard failure: a different patch release is a
            # packaging decision, not a reason to refuse a run that may work.
            entry["version_matches_pin"] = False
            mismatched.append("%s %s (pinned %s)" % (dist, version, expected))
        else:
            entry["version_matches_pin"] = True
        entries[dist] = entry
    return {
        "ok": not missing,
        "required": len(required),
        "missing": missing,
        "version_mismatches": mismatched,
        "packages": entries,
    }


def check_readiness(*, snapshot=None, upstream=None, stats_source=None,
                    cache_root=None, python=None):
    """Report whether a run could proceed. Downloads nothing, loads no model.

    Every check is a local file/digest test, so this is safe to call before the
    game commits to generating. It never creates the output directory.
    """
    snapshot = snapshot or tb.DEFAULT_SNAPSHOT
    upstream = upstream or tb.DEFAULT_UPSTREAM
    report = {
        "python": python or sys.version.split()[0],
        # The ABSOLUTE interpreter path matters to the supervisor: `python3` on
        # PATH is often not the venv that has torch, and a wrong one fails only
        # after a long model load. Report what is actually running.
        "python_executable": sys.executable,
        "python_version": sys.version.split()[0],
        "snapshot": snapshot,
        "upstream": upstream,
        "stats_source": stats_source,
        "checks": {},
        "problems": [],
    }

    def record(name, fn):
        try:
            payload = dict(fn())
            # A check that returns its own `ok` keeps it: a dependency probe can
            # legitimately complete while reporting "not ready", and forcing
            # ok=True here would turn that verdict back into a pass.
            payload.setdefault("ok", True)
            report["checks"][name] = payload
            if not payload["ok"]:
                report["problems"].append("%s: %s" % (
                    name, ", ".join(payload.get("missing") or ["failed"])))
        except BaseException as exc:  # noqa: BLE001 - report, never die
            report["problems"].append("%s: %s" % (name, exc))
            report["checks"][name] = {"ok": False, "error": str(exc)}

    def snapshot_check():
        config = tb.read_snapshot_config(snapshot)
        tb.check_config(config)
        return {
            "native_resolution": config.get("native_resolution"),
            "submodels": {
                name: os.path.isdir(os.path.join(snapshot, name))
                for name in ("coarse_model", "base_model", "decoder_model")
            },
        }

    def pins_check():
        return tb.verify_snapshot(snapshot)

    def upstream_check():
        return tb.verify_upstream(upstream)

    def stats_check():
        path = tb.stats_source_path(
            cache_root or os.path.join(tb.DEFAULT_CACHE_ROOT, "_probe"),
            stats_source,
        )
        stats = tb.extract_frozen_stats(path)
        return {"source": path, "stats_sha256": tb._sha256_bytes(
            tb.canonical_json(stats))}

    def dependencies_check():
        return check_dependencies()

    record("dependencies", dependencies_check)
    record("snapshot", snapshot_check)
    record("pins", pins_check)
    record("upstream", upstream_check)
    record("stats", stats_check)
    report["ok"] = not report["problems"]
    return report


#: Names an output root may already contain without counting as "in use".
#: Only the progress sidecar qualifies: it is a run's own bookkeeping, and a
#: supervisor may legitimately place it inside the staging root it is about to
#: fill. Anything else means a real artifact is present.
TOLERATED_ROOT_ENTRIES = (PROGRESS_DEFAULT_NAME,)


def prepare_output(out, *, progress_path=None):
    """Create a fresh output root, refusing real content.

    The progress sidecar is tolerated, because a caller may put it inside the
    staging root and it is written *before* the first stage is emitted -- without
    this the run would refuse its own bookkeeping. Every other entry means a map
    is already there, and overwriting that is not a recoverable operation.
    """
    out = os.path.abspath(out)
    allowed = set(TOLERATED_ROOT_ENTRIES)
    if progress_path is not None:
        progress_abs = os.path.abspath(progress_path)
        if os.path.dirname(progress_abs) == out:
            allowed.add(os.path.basename(progress_abs))
    if os.path.exists(out):
        if not os.path.isdir(out):
            raise ProviderError("output path exists and is not a directory: %s" % out)
        unexpected = sorted(set(os.listdir(out)) - allowed)
        if unexpected:
            raise ProviderError(
                "output directory %s is not empty (found %s); refusing to "
                "overwrite a map a running game may be reading"
                % (out, ", ".join(unexpected[:4]))
            )
    else:
        os.makedirs(out)
    return out


# ---------------------------------------------------------------------------
# Identity: the pinned backend descriptor, reused verbatim
# ---------------------------------------------------------------------------


def build_provider_identity(*, seed, size, origin, device="cpu", dtype="fp32",
                            snapshot=None, upstream=None, stats_source=None,
                            cache_root=None, noise_lib=None):
    """Build the backend identity the sampler will be loaded against.

    The identity is the backend's own descriptor -- same code, same pins -- so a
    provider run and an offline bake of the same settings agree exactly and share
    provenance. ``pixels_per_voxel`` stays 1: this provider samples the model's
    native pixels one-for-one and lets the *mapping* set the scale.
    """
    snapshot = snapshot or tb.DEFAULT_SNAPSHOT
    upstream = upstream or tb.DEFAULT_UPSTREAM
    pin = tb.verify_upstream(upstream)
    stats = tb.extract_frozen_stats(
        tb.stats_source_path(cache_root or os.path.join(tb.DEFAULT_CACHE_ROOT, "_probe"),
                             stats_source)
    )
    identity = tb.build_identity(
        seed=seed,
        pixels_per_voxel=1,
        dtype=dtype,
        device=device,
        snapshot=snapshot,
        config=tb.read_snapshot_config(snapshot),
        pin=pin,
        stats=stats,
        origin_pixels=tuple(origin),
        decoder_geometry=None,
        noise_lib=noise_lib,
    )
    return identity, snapshot, upstream


#: Prefix for the per-run scratch root created when the caller supplies none.
SCRATCH_PREFIX = "terrain-provider-scratch-"


def scratch_root(parent=None):
    """Create a private, unique scratch root for one run's identity directory.

    ``load_sampler`` needs a real identity directory to install the frozen stats
    table, but this run must not touch any cache the game may already be using.
    The backend's shared default cache root holds other worlds' identities, so
    pointing the scratch there made a new seed collide with a legacy generation
    and refuse the run before any inference.

    This creates a directory owned solely by this run, under ``parent`` or the
    system temp directory, and never inside the output artifact.
    """
    import tempfile

    base = parent or os.path.join(tempfile.gettempdir(), "")
    return tempfile.mkdtemp(prefix=SCRATCH_PREFIX, dir=parent if parent else None)


def write_identity_for_sampler(identity, *, stats_source=None, cache_root=None):
    """Materialise the identity directory the sampler installer requires.

    ``load_sampler`` reads the identity's ``stats.json`` and re-verifies it, so it
    needs a real directory. When ``cache_root`` is not supplied this creates a
    private per-run scratch root rather than writing into the backend's shared
    cache, which belongs to other generations.
    """
    if cache_root is None:
        cache_root = scratch_root()
    else:
        os.makedirs(cache_root, exist_ok=True)
    return tb.open_or_create_identity(cache_root, identity, stats_source=stats_source)


# ---------------------------------------------------------------------------
# Sampling
# ---------------------------------------------------------------------------


def _climate_point(value, channel, row, column):
    """Coerce one climate sample to a finite Python ``float``, or refuse.

    Climate is metadata, so a bad sample must not become a plausible biome: a
    bool, a non-number, NaN or an infinity raises instead of being clamped,
    zero-filled or dropped. ``_as_float`` already rejects bools and non-numbers;
    the finiteness check is this function's own contribution because a NaN
    survives ``float()``.
    """
    try:
        number = tb._as_float(value)
    except tb.BackendError as exc:
        raise ProviderError(
            "climate channel %d at (%d,%d) is not a number: %s"
            % (channel, row, column, exc)
        ) from None
    if not math.isfinite(number):
        raise ProviderError(
            "climate channel %d at (%d,%d) is %r; climate values must be finite"
            % (channel, row, column, number)
        )
    return number


def normalize_climate(climate, *, rows, cols):
    """Upstream's ``(5, H, W)`` climate as ``(H, W, 5)``, validated, or ``None``.

    The axis order is not a preference: upstream stacks the five channels on the
    LEADING axis (``world_pipeline.py`` builds
    ``torch.stack([temp, seasonality, precip, variab, beta])``), while
    ``scenic_terrain.export_raw`` compares ``climate.shape[:2]`` against the
    elevation grid, which would refuse that layout outright. The transpose
    happens here, once, and every channel keeps its own index.

    ``None`` stays legal and means "the pipeline produced no climate", which
    exports no climate exactly as before. Nothing is fabricated: a wrong channel
    count, a plane that disagrees with the elevation grid, or a non-finite value
    raises :class:`ProviderError` rather than writing a default.
    """
    if climate is None:
        return None
    if hasattr(climate, "detach"):
        climate = climate.detach().to("cpu").float().numpy()
    if hasattr(climate, "tolist"):
        climate = climate.tolist()
    try:
        channels = len(climate)
    except TypeError:
        raise ProviderError("pipeline climate is not a 3-D array") from None
    if channels != CLIMATE_CHANNELS:
        raise ProviderError(
            "pipeline climate has %d channels, expected %d"
            % (channels, CLIMATE_CHANNELS)
        )
    planes = []
    for channel, plane in enumerate(climate):
        try:
            height = len(plane)
        except TypeError:
            raise ProviderError(
                "pipeline climate channel %d is not a 2-D array" % channel
            ) from None
        if height != rows:
            raise ProviderError(
                "pipeline climate channel %d has %d rows, expected %d"
                % (channel, height, rows)
            )
        plane_rows = []
        for index, row in enumerate(plane):
            try:
                width = len(row)
            except TypeError:
                raise ProviderError(
                    "pipeline climate channel %d row %d is not a sequence"
                    % (channel, index)
                ) from None
            if width != cols:
                raise ProviderError(
                    "pipeline climate channel %d has %d columns, expected %d"
                    % (channel, width, cols)
                )
            plane_rows.append([
                _climate_point(value, channel, index, column)
                for column, value in enumerate(row)
            ])
        planes.append(plane_rows)
    # (5, H, W) -> (H, W, 5): one column is one sample of all five channels.
    return [
        [
            [planes[channel][row][column] for channel in range(CLIMATE_CHANNELS)]
            for column in range(cols)
        ]
        for row in range(rows)
    ]


def _sample(pipeline, *, origin, size, cancellation, with_climate):
    """The one sampling path: returns ``(elevation rows, climate or None)``."""
    x0, z0 = int(origin[0]), int(origin[1])
    x1, z1 = x0 + int(size), z0 + int(size)
    if cancellation is not None:
        cancellation.check("sample")
    # The flag is passed EXPLICITLY, never probed: a pipeline that cannot answer
    # it raises here rather than being quietly handed back a climate-less world.
    result = pipeline.get(z0, x0, z1, x1, with_climate=with_climate)
    if not isinstance(result, dict) or "elev" not in result:
        raise ProviderError("pipeline returned no 'elev' entry")
    elevation = result["elev"]
    rows = z1 - z0
    cols = x1 - x0
    if hasattr(elevation, "detach"):
        elevation = elevation.detach().to("cpu").float().numpy()
    try:
        height = len(elevation)
    except TypeError:
        raise ProviderError("pipeline elevation is not a 2-D array") from None
    if height != rows:
        raise ProviderError("pipeline returned %d rows, expected %d" % (height, rows))
    out = []
    for row in elevation:
        try:
            width = len(row)
        except TypeError:
            raise ProviderError("pipeline elevation row is not a sequence") from None
        if width != cols:
            raise ProviderError(
                "pipeline returned %d columns, expected %d" % (width, cols)
            )
        out.append([tb._as_float(value) for value in row])
    climate = normalize_climate(result.get("climate"), rows=rows, cols=cols)
    return out, climate


def sample_region(pipeline, *, origin, size, stages=None, cancellation=None):
    """Sample one ``size x size`` native-pixel region as ``(rows, cols)`` metres.

    Calls the real ``WorldPipeline.get(i1, j1, i2, j2)`` exactly once for the whole
    rectangle -- bounded work for a bounded map -- and returns plain nested lists
    so the exporter can consume it without a torch import here.

    Elevation only, by request: this is the contract every existing caller and
    every elevation test already relies on. ``sample_map`` is the same single
    call WITH the climate channels.

    Upstream's axis order is ``i`` = row (z) and ``j`` = column (x), half-open.
    """
    elevation, _climate = _sample(
        pipeline, origin=origin, size=size,
        cancellation=cancellation, with_climate=False,
    )
    return elevation


def sample_map(pipeline, *, origin, size, stages=None, cancellation=None):
    """Sample one region and its climate: ``(elevation rows, climate or None)``.

    Climate is requested in the SAME ``get`` as the elevation, so the five
    channels describe exactly the terrain sampled -- not a separately resampled
    field. A pipeline that returns no ``climate`` entry yields ``None``, which
    exports no climate (the pre-climate behaviour); a pipeline whose climate is
    malformed raises instead.
    """
    return _sample(
        pipeline, origin=origin, size=size,
        cancellation=cancellation, with_climate=True,
    )


def provenance_record(*, identity, settings, snapshot, upstream, seed_mapping):
    """Everything this run can honestly assert about how the map was made.

    Nothing is defaulted: each value is read from the identity the sampler was
    actually loaded against.
    """
    return {
        "provider": "python-terrain-diffusion",
        "provider_version": 1,
        "temporary": True,
        "replaces": "native provider once verified",
        "model": identity["model"],
        "model_revision": identity["model_revision"],
        "upstream_revision": identity["upstream_revision"],
        "upstream_repo": tb.UPSTREAM_REPO,
        # `seed` is the MODEL seed actually sampled; the world seed and the
        # mapping version sit beside it so a world seed of 0 is unambiguous and
        # a mapping change can never reuse an older artifact's provenance.
        "seed": identity["seed"],
        "world_seed": seed_mapping["world_seed"],
        "model_seed": seed_mapping["model_seed"],
        "seed_mapping": seed_mapping["seed_mapping"],
        "seed_remapped": seed_mapping["remapped"],
        "weightset_sha256": identity["weights_sha256"],
        "configset_sha256": identity["configs_sha256"],
        "stats_sha256": identity["stats_sha256"],
        "config_sha256": identity["config_sha256"],
        "conditioning_version": identity["conditioning_version"],
        "source_sha256": identity["source_sha256"],
        "sampler": identity["sampler"],
        "mapping": identity["mapping"],
        "query": identity["query"],
        "dtype": identity["dtype"],
        "device": identity["device"],
        "settings": dict(settings),
        "snapshot": os.path.abspath(snapshot),
        "upstream_path": os.path.abspath(upstream),
    }


# ---------------------------------------------------------------------------
# The run
# ---------------------------------------------------------------------------


def generate(*, out, seed=DEFAULT_SEED, size=DEFAULT_SIZE, origin=DEFAULT_ORIGIN,
             meters_per_voxel=DEFAULT_METERS_PER_VOXEL, sea_level=DEFAULT_SEA_LEVEL,
             profile=DEFAULT_PROFILE, world_origin=DEFAULT_WORLD_ORIGIN,
             device="cpu", dtype="fp32", snapshot=None, upstream=None,
             stats_source=None, work_root=None, stages=None,
             pipeline_factory=None, noise_lib=None):
    """Produce one verified scenic artifact. Returns a result dict.

    Sequence: validate → resolve identity → load the real pipeline → sample once →
    export through ``scenic_terrain.import_raw`` → re-read the artifact and verify
    → write ``READY``. Any failure or cancellation leaves **no** ready flag.
    """
    stages = stages if stages is not None else Stages()
    validate_settings(
        seed=seed, size=size, meters_per_voxel=meters_per_voxel,
        sea_level=sea_level, profile=profile, origin=origin,
        world_origin=world_origin,
    )
    seed_mapping = resolve_seed(seed)
    # Claim the output root FIRST. Emitting a stage writes the progress sidecar,
    # and if that sidecar lives inside the root, the later "is it empty?" check
    # would refuse the run's own bookkeeping. Ordering is the fix; the tolerated
    # entry list in `prepare_output` is the belt to that braces.
    out = prepare_output(out, progress_path=stages.progress_path)
    stages.emit("resolve", seed=seed, world_seed=seed_mapping["world_seed"],
                model_seed=seed_mapping["model_seed"],
                seed_mapping=seed_mapping["seed_mapping"],
                size=size, origin=list(origin))
    identity, snapshot, upstream = build_provider_identity(
        seed=seed_mapping["model_seed"], size=size, origin=origin,
        device=device, dtype=dtype,
        snapshot=snapshot, upstream=upstream, stats_source=stats_source,
        cache_root=work_root, noise_lib=noise_lib,
    )
    stages.emit("verify", weightset_sha256=identity["weights_sha256"],
                stats_sha256=identity["stats_sha256"])

    # A scratch root created here belongs to this run alone and is removed when
    # the run ends, so a failed load cannot leave an identity directory behind
    # for the next run to collide with.
    owned_scratch = None
    try:
        with _Cancellation() as cancellation:
            cancellation.check("load")
            if pipeline_factory is None:
                if work_root is None:
                    owned_scratch = scratch_root()
                _, layout = write_identity_for_sampler(
                    identity, stats_source=stats_source,
                    cache_root=owned_scratch or work_root,
                )
                sampler = tb.load_sampler(
                    identity, layout, snapshot=snapshot, upstream=upstream, device=device
                )
                pipeline = sampler
                closer = getattr(sampler, "close", None)
            else:
                pipeline = pipeline_factory(identity)
                closer = getattr(pipeline, "close", None)
            stages.emit("load", device=device, dtype=dtype)
            try:
                cancellation.check("sample")
                elevation, climate = sample_map(
                    pipeline, origin=origin, size=size,
                    stages=stages, cancellation=cancellation,
                )
                stages.emit("sample", rows=len(elevation),
                            cols=len(elevation[0]) if elevation else 0,
                            has_climate=climate is not None)
            finally:
                if closer is not None:
                    try:
                        closer()
                    except Exception:  # noqa: BLE001 - closing must not mask errors
                        pass

            cancellation.check("export")
            raw_path = os.path.join(out, "raw_export.npz")
            st.export_raw(
                raw_path,
                elevation,
                origin_pixels=origin,
                # The artifact's `seed` is the MODEL seed actually sampled, because
                # every reader (and the catalogue's seed check) compares it against
                # the run that produced the terrain. The world seed the player chose
                # travels in provenance, which the scenic identity hashes -- so
                # world seed 0 and world seed 2147483647 share terrain but keep
                # distinct identities.
                seed=seed_mapping["model_seed"],
                pixels_per_voxel=1,
                climate=climate,
                provenance=provenance_record(
                    identity=identity, settings={
                        "size": size, "origin": list(origin),
                        "meters_per_voxel": meters_per_voxel,
                        "sea_level": sea_level, "profile": profile,
                        "world_origin": list(world_origin),
                    },
                    snapshot=snapshot, upstream=upstream,
                    seed_mapping=seed_mapping,
                ),
            )
            # Assess clipping from the raw metres BEFORE quantizing, while the
            # true (unclamped) values are still in hand. `summary.json` counts a
            # value as clipped when it merely REACHES a boundary, which cannot
            # distinguish a destroyed map from a legitimate plateau.
            band = identity["mapping"]
            clipping = clip_assessment(
                elevation,
                meters_per_voxel=meters_per_voxel,
                sea_level=sea_level,
                baseline_elevation_m=band["baseline_elevation_m"],
                height_min=st.SCENIC_HEIGHT_MIN,
                height_max=st.SCENIC_HEIGHT_MAX,
            )
            summary = st.import_raw(
                raw_path,
                out,
                meters_per_voxel=meters_per_voxel,
                sea_level=sea_level,
                profile=profile,
                world_origin_voxels=world_origin,
            )
            stages.emit("export", identity=summary["identity"], tiles=summary["tiles"],
                        clipped_below_min=clipping["clipped_below_min"],
                        clipped_above_max=clipping["clipped_above_max"],
                        all_clipped=clipping["all_clipped"])

            cancellation.check("verify-artifact")
            verified = verify_artifact(out, summary["identity"])
            verified["clipping"] = clipping
            stages.emit("verify-artifact", **verified)

            if clipping["all_clipped"]:
                # The artifact and raw export stay on disk as a diagnostic, but
                # no READY marker is written: a flat clipped map is not a world.
                # The game's gate is the marker, so this cannot be mistaken for
                # a successful generation.
                raise ProviderError(
                    "%s (raw voxel range %d..%d, band %d..%d; %d of %d samples "
                    "clipped). The artifact was kept for inspection but was not "
                    "marked ready."
                    % (
                        clipping["reason"],
                        clipping["raw_voxel_min"], clipping["raw_voxel_max"],
                        clipping["height_min"], clipping["height_max"],
                        clipping["clipped_below_min"] + clipping["clipped_above_max"],
                        clipping["samples"],
                    )
                )

            ready = write_ready(out, summary, verified)
            stages.emit("ready", ready=str(ready))
    finally:
        # Only remove a scratch root this run created; a caller-supplied
        # work_root is theirs to keep.
        if owned_scratch is not None:
            shutil.rmtree(owned_scratch, ignore_errors=True)
    return {
        "out": out,
        "identity": summary["identity"],
        "tiles": summary["tiles"],
        "ready": ready,
        "summary": summary,
        "verified": verified,
        "clipping": clipping,
        "world_seed": seed_mapping["world_seed"],
        "model_seed": seed_mapping["model_seed"],
        "seed_mapping": seed_mapping["seed_mapping"],
    }


def verify_artifact(out, identity):
    """Re-read the artifact from disk and check it, or refuse to call it ready.

    This is what makes ``ready`` meaningful: the manifest is validated by the
    existing scenic reader, every tile is decoded under the manifest's declared
    band, and the tile count matches the manifest's own bounds.
    """
    record = st.read_scenic_manifest(out, identity)
    bounds = record["bounds"]
    chunks_x = bounds[2] - bounds[0] + 1
    chunks_z = bounds[3] - bounds[1] + 1
    expected = chunks_x * chunks_z
    tiles_dir = os.path.join(out, identity, tc.TILE_DIR_NAME)
    present = sorted(
        name for name in os.listdir(tiles_dir) if name.endswith(".tdh")
    )
    if len(present) != expected:
        raise ProviderError(
            "artifact has %d tiles, manifest bounds imply %d"
            % (len(present), expected)
        )
    lowest = None
    highest = None
    for name in present:
        cx_text, _, cz_text = name[: -len(".tdh")].partition("_")
        cx, cz = int(cx_text), int(cz_text)
        heights = st.read_scenic_tile(out, identity, cx, cz)
        if isinstance(heights, tuple):
            heights = heights[-1]
        low = min(heights)
        high = max(heights)
        lowest = low if lowest is None else min(lowest, low)
        highest = high if highest is None else max(highest, high)
    return {
        "identity": identity,
        "tiles": len(present),
        "chunks_x": chunks_x,
        "chunks_z": chunks_z,
        "height_min_observed": lowest,
        "height_max_observed": highest,
    }


def clip_assessment(elevation_m, *, meters_per_voxel, sea_level,
                    baseline_elevation_m, height_min, height_max):
    """Measure whether a map was clipped BEYOND the band, not merely reaching it.

    ``summary.json`` counts a value as clipped when ``value <= height_min``, so a
    legitimate voxel that lands exactly on the boundary is counted too. That is
    fine for a diagnostic and wrong for a gate, so this recomputes from the raw
    metres: a voxel is clipped only when its *unclamped* value falls strictly
    outside the band, which means real relief was destroyed.

    Returns a record with the counts, the raw voxel range, and ``reason`` set when
    the whole map is clipped to a single bound.
    """
    samples = len(elevation_m) * (len(elevation_m[0]) if elevation_m else 0)
    if not samples:
        raise ProviderError("cannot assess clipping of an empty map")
    below = 0
    above = 0
    lowest = None
    highest = None
    for row in elevation_m:
        for metres in row:
            raw = int(math.floor(
                (float(metres) - baseline_elevation_m) / meters_per_voxel
                + sea_level + 0.5
            ))
            if raw < height_min:
                below += 1
            elif raw > height_max:
                above += 1
            lowest = raw if lowest is None else min(lowest, raw)
            highest = raw if highest is None else max(highest, raw)
    record = {
        "samples": samples,
        "clipped_below_min": below,
        "clipped_above_max": above,
        "raw_voxel_min": lowest,
        "raw_voxel_max": highest,
        "height_min": height_min,
        "height_max": height_max,
        "all_clipped": False,
        "bound": None,
        "reason": None,
    }
    if below == samples:
        record["all_clipped"] = True
        record["bound"] = "min"
        record["reason"] = (
            "all sampled heights clipped to minimum; the whole map lies below the "
            "supported band -- choose another seed or a larger supported mapping"
        )
    elif above == samples:
        record["all_clipped"] = True
        record["bound"] = "max"
        record["reason"] = (
            "all sampled heights clipped to maximum; the whole map lies above the "
            "supported band -- choose another seed or a larger supported mapping"
        )
    return record


def write_ready(out, summary, verified):
    """Write the ready flag last, after verification, via atomic rename."""
    payload = {
        "ready": True,
        "identity": summary["identity"],
        "tiles": summary["tiles"],
        "verified": verified,
        "provider": "python-terrain-diffusion",
        "temporary": True,
    }
    path = os.path.join(out, summary["identity"], READY_NAME)
    temp = path + ".tmp-%d" % os.getpid()
    data = json.dumps(payload, indent=2, sort_keys=True).encode("utf-8")
    with open(temp, "wb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp, path)
    return path


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def build_parser():
    parser = argparse.ArgumentParser(
        prog="terrain_new_game",
        description="Temporary Python Terrain Diffusion provider for New Game.",
    )
    parser.add_argument("--out", required=True, help="output cache root")
    parser.add_argument("--check", action="store_true",
                        help="report offline readiness and exit; generates nothing")
    parser.add_argument(
        "--progress", default=None, metavar="PATH",
        help="write an inert Janet progress sidecar here; never written by --check",
    )
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED,
                        help="resolved world seed, 1..%d" % MAX_SEED)
    parser.add_argument("--size", type=int, default=DEFAULT_SIZE,
                        help="native pixels per axis, %d..%d" % (MIN_SIZE, MAX_SIZE))
    parser.add_argument("--origin-x", type=int, default=DEFAULT_ORIGIN[0])
    parser.add_argument("--origin-z", type=int, default=DEFAULT_ORIGIN[1])
    parser.add_argument("--meters-per-voxel", type=float,
                        default=DEFAULT_METERS_PER_VOXEL)
    parser.add_argument("--sea-level", type=int, default=DEFAULT_SEA_LEVEL)
    parser.add_argument("--profile", default=DEFAULT_PROFILE)
    parser.add_argument("--world-origin-x", type=int, default=DEFAULT_WORLD_ORIGIN[0])
    parser.add_argument("--world-origin-z", type=int, default=DEFAULT_WORLD_ORIGIN[1])
    parser.add_argument("--device", default="cpu", choices=("cpu", "mps", "cuda"))
    parser.add_argument("--dtype", default="fp32", choices=("fp32", "fp16", "bf16"))
    parser.add_argument("--snapshot", default=None)
    parser.add_argument("--upstream", default=None)
    parser.add_argument("--stats-json", default=None)
    return parser


def main(argv=None, *, pipeline_factory=None, stages_stream=None, noise_lib=None):
    args = build_parser().parse_args(argv)
    # `--check` must stay a pure read: no model, no output, and specifically no
    # progress file, so a readiness probe can never be mistaken for a run.
    stages = Stages(stages_stream, progress_path=None)

    if args.check:
        report = check_readiness(
            snapshot=args.snapshot, upstream=args.upstream,
            stats_source=args.stats_json,
        )
        if args.json:
            print(json.dumps(report, indent=2, sort_keys=True))
        else:
            print("python     %s" % report["python_executable"])
            print("version    %s" % report["python_version"])
            print("snapshot   %s" % report["snapshot"])
            print("upstream   %s" % report["upstream"])
            stats_source = report["checks"].get("stats", {}).get("source")
            if stats_source:
                print("stats      %s" % stats_source)
            deps = report["checks"].get("dependencies", {})
            for name, payload in sorted(report["checks"].items()):
                print("%-13s %s" % (name, "ok" if payload.get("ok") else "FAIL"))
            for dist, entry in sorted(deps.get("packages", {}).items()):
                if not entry["present"]:
                    print("  MISSING %s" % dist)
                elif not entry.get("version_matches_pin", True):
                    print("  version %s %s (pinned %s)"
                          % (dist, entry["version"], entry["expected"]))
            for problem in report["problems"]:
                print("problem: %s" % problem)
            print("ready-to-generate: %s" % ("yes" if report["ok"] else "no"))
        return EXIT_READY if report["ok"] else EXIT_REFUSED

    stages.progress_path = args.progress
    try:
        result = generate(
            out=args.out, seed=args.seed, size=args.size,
            origin=(args.origin_x, args.origin_z),
            meters_per_voxel=args.meters_per_voxel, sea_level=args.sea_level,
            profile=args.profile,
            world_origin=(args.world_origin_x, args.world_origin_z),
            device=args.device, dtype=args.dtype,
            snapshot=args.snapshot, upstream=args.upstream,
            stats_source=args.stats_json, stages=stages,
            pipeline_factory=pipeline_factory, noise_lib=noise_lib,
        )
    except Cancelled as exc:
        stages.cancel("run")
        print("cancelled: %s" % exc, file=sys.stderr)
        return EXIT_CANCELLED
    except ProviderError as exc:
        stages.fail(str(exc))
        print("refused: %s" % exc, file=sys.stderr)
        return EXIT_REFUSED
    except BaseException as exc:  # noqa: BLE001 - never claim ready on a crash
        stages.fail(str(exc))
        print("generation failed: %s" % exc, file=sys.stderr)
        return EXIT_FAILED

    if args.json:
        print(json.dumps(
            {"identity": result["identity"], "tiles": result["tiles"],
             "out": result["out"], "ready": result["ready"]},
            indent=2, sort_keys=True,
        ))
    else:
        print("identity %s" % result["identity"])
        print("tiles    %d" % result["tiles"])
        print("ready    %s" % result["ready"])
    return EXIT_READY


if __name__ == "__main__":
    sys.exit(main())
