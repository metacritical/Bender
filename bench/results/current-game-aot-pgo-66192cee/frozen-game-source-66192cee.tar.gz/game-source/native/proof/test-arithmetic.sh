#!/usr/bin/env bash
# Fixed, model-free native arithmetic proof suite. No graphs, inference, GPU,
# Python, downloads, or native builds are loaded by the tests below.
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

if (( $# != 0 )); then
  printf 'usage: %s (no arguments)\n' "$0" >&2
  exit 2
fi

if [[ -n "${BENDER:-}" ]]; then
  if [[ ! -x "$BENDER" ]]; then
    printf 'error: BENDER is not executable: %s\n' "$BENDER" >&2
    exit 1
  fi
  bender="$(cd "$(dirname "$BENDER")" && pwd)/$(basename "$BENDER")"
elif [[ -x "$root/../../janet/build/bender" ]]; then
  bender="$root/../../janet/build/bender"
elif command -v bender >/dev/null 2>&1; then
  bender="$(command -v bender)"
else
  printf 'error: bender not found; set BENDER to an executable interpreter\n' >&2
  exit 1
fi

# An explicit allowlist: never glob future tests into this safety boundary.
suites=(
  test-geometry.janet
  test-scheduler.janet
  test-scheduler-tensor.janet
  test-laplacian.janet
  test-resize-aa.janet
)
failed=0
for suite in "${suites[@]}"; do
  printf '=== native arithmetic: %s ===\n' "$suite"
  if (cd "$root" && JANET_NO_PROFILE=1 "$bender" "$root/native/proof/$suite"); then
    :
  else
    printf '!!! native arithmetic FAILED: %s\n' "$suite" >&2
    failed=1
  fi
done
exit "$failed"
