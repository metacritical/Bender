# test-scheduler.janet — golden-vector test for the native scheduler.
#
# Every expected number here was produced by the REAL upstream Python
# implementation (terrain_diffusion/scheduler/dpmsolver.py,
# EDMDPMSolverMultistepScheduler) and pasted in verbatim. This test does not
# re-derive them, so it can actually catch a port that is wrong.
#
# Run:  <bender> native/proof/test-scheduler.janet

(import ./scheduler :as sc)

(def failures @[])

(defn approx? [a b tol]
  (<= (math/abs (- a b)) tol))

(defn check [label got expected &opt tol]
  (default tol 1e-6)
  (if (approx? got expected tol)
    (do (print (string/format "  ok    %-40s %.10g" label got)))
    (do
      (print (string/format "  FAIL  %-40s got %.10g want %.10g" label got expected))
      (array/push failures label))))

(defn check-str [label got expected]
  (if (= got expected)
    (print (string/format "  ok    %s" label))
    (do
      (print (string/format "  FAIL  %s: got %s want %s" label got expected))
      (array/push failures label))))

(print "=== sigma schedule (20 steps, karras) ===")

# Captured from:
#   EDMDPMSolverMultistepScheduler(sigma_min=0.002, sigma_max=80, sigma_data=0.5)
#   .set_timesteps(20)  ->  .sigmas  (21 values, float32)
(def expected-sigmas
  [79.99998474121094 59.657501220703125 43.920257568359375 31.88442039489746
   22.794111251831055 16.02229881286621 11.05366325378418 7.468902587890625
   4.930656909942627 3.1708412170410156 1.979400634765625 1.1943087577819824
   0.6928236484527588 0.3838551640510559 0.20140404999256134
   0.09897341579198837 0.04488256946206093 0.01840081810951233
   0.006621698383241892 0.0019999996293336153 0.0])

(def sigmas (sc/karras-sigmas 20))
(check-str "sigma count" (length sigmas) 21)
(for i 0 21
  (check (string/format "sigma[%d]" i) (sigmas i) (expected-sigmas i) 1e-6))

(print "")
(print "=== timesteps (trigflow atan(sigma/sigma_data)) ===")

# Captured from scheduler.timesteps  ->  [1.0955066680908203, 1.0221549272537231, ...]
(check "timesteps[0] (0.25*log)" (sc/precondition-noise (sigmas 0)) 1.0955066680908203 1e-6)
(check "timesteps[1] (0.25*log)" (sc/precondition-noise (sigmas 1)) 1.0221549272537231 1e-6)
(check "timesteps[2] (0.25*log)" (sc/precondition-noise (sigmas 2)) 0.9455938935279846 1e-6)

(print "")
(print "=== 3-step denoise trace (constant model outputs) ===")

# Captured from a real 3-step run where the model output on step i is the
# constant 0.1*(i+1) for every element, starting from sample = 0.3.
# Trace entries: sigma, scaled sample, cnoise, then prev_sample after step.
(def trace
  [{:sigma 79.99998474121094 :scaled 0.003749927505850792 :cnoise 1.5645464658737183
    :prev 0.057870469987392426}
   {:sigma 2.5152194499969482 :scaled 0.022566553205251694 :cnoise 1.3745646476745605
    :prev 0.15205702185630798}
   {:sigma 0.0019999996293336153 :scaled 0.3041115999221802 :cnoise 0.0039999778382480145
    :prev 0.15265458822250366}])

(def sch (sc/make-scheduler 3))
(var sample 0.3)

(for i 0 3
  (def entry (trace i))
  (def sigma (sc/current-sigma sch))
  (check (string/format "step%d sigma" i) sigma (entry :sigma) 1e-6)
  (check (string/format "step%d c_in-scaled" i)
         (* sample (sc/precondition-inputs sigma)) (entry :scaled) 1e-6)
  (check (string/format "step%d cnoise" i)
         (sc/trigflow-noise sigma) (entry :cnoise) 1e-6)
  # The stand-in model output: constant 0.1*(i+1).
  (set sample (sc/step sch sample (* 0.1 (+ i 1))))
  (check (string/format "step%d prev_sample" i) sample (entry :prev) 1e-4))

(print "")
(print "=== determinism ===")
(def a (sc/karras-sigmas 20))
(def b (sc/karras-sigmas 20))
(check-str "schedule is reproducible" (= (length a) (length b)) true)
(var same true)
(for i 0 (length a) (unless (= (a i) (b i)) (set same false)))
(check-str "schedule values identical" same true)

(print "")
(if (empty? failures)
  (do
    (print (string/format "SCHEDULER PASSED: %d golden checks matched upstream" 21))
    (os/exit 0))
  (do
    (print (string/format "SCHEDULER FAILED: %d mismatches" (length failures)))
    (each f failures (print "   - " f))
    (os/exit 1)))
