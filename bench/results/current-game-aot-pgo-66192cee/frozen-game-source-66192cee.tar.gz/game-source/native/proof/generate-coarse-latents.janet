# generate-coarse-latents.janet — COARSE STAGE ONLY. NOT a height tile.
#
# WHAT THIS DOES — read this before using it
# ------------------------------------------
# Runs ONLY the first of the three denoising stages and writes its raw output:
#
#   PCG64 noise(seed) -> coarse 20-step denoise -> float32 COARSE LATENTS
#
# The output is NOT elevation, NOT metres, and NOT a height tile. It is the
# coarse model's normalised 6-channel latent field, still in the model's own
# units (observed range roughly -0.4..0.8). Upstream continues from here through
# the base stage, the decoder stage and a laplacian decode before any metre
# value exists. Treating this output as terrain would be wrong by orders of
# magnitude.
#
# WHAT IS SIMPLIFIED, STATED PLAINLY
# ----------------------------------
# This is a BOUNDED tile, not the full upstream pipeline. Two deliberate
# simplifications, visible in the code rather than hidden:
#
#   1. CONDITIONING. Upstream's coarse stage consumes a 5-channel synthetic map
#      built from Perlin noise quantile-matched against WorldClim rasters
#      (pyfastnoiselite + rasterio). That map is NOT reproduced here. Instead the
#      conditioning comes deterministically from the same PCG64 stream. The model
#      and its weights are real, and the output is real model output — but it is
#      conditioned on a synthetic channel rather than a geographically
#      quantile-matched one. Tiles from this path are therefore NOT the same
#      landscape upstream would produce for the same seed.
#
#   2. TILING. One tile, no overlapping windows, no blend weights, no
#      InfiniteTensor. Upstream sums weighted overlapping windows.
#
# Because of (1) this generator identifies as `native-v1`, distinct from any
# upstream identity, so a tile produced here can never be mistaken for an
# upstream bake.
#
# Usage:
#   <bender> native/proof/generate-tile.janet [--out PATH] [--steps N] [--size N] [--seed N]

(import ./scheduler :as sc)

(def here
  (let [parts (string/split "/" (os/realpath (dyn :current-file)))]
    (string/join (slice parts 0 (- (length parts) 1)) "/")))

(def tmp-root (string here "/../../tmp/native-terrain-proof"))

(defn fail [fmt & args]
  (eprint "GENERATE FAILED: " (string/format fmt ;args))
  (os/exit 1))

#
# --- FFI ------------------------------------------------------------------
#

(ffi/context (string here "/libtres.dylib"))

(ffi/defbind-alias tres_version     tres-version     :string [])
(ffi/defbind-alias tres_last_error  tres-last-error  :string [])
(ffi/defbind-alias tres_open        tres-open        :ptr    [p :string])
(ffi/defbind-alias tres_close       tres-close       :void   [rt :ptr])
(ffi/defbind-alias tres_fill_normal tres-fill-normal :int    [seed :long out :ptr n :int])
(ffi/defbind-alias tres_run_all     tres-run-all     :int
  [rt :ptr n :int ptrs :ptr dims :ptr ranks :ptr nbytes :ptr
   out :ptr out_cap :int written :ptr out_dims :ptr out_dims_cap :int out_rank :ptr])

#
# --- Helpers --------------------------------------------------------------
#

(defn f32-of [x]
  (def b (buffer/new-filled 4 0))
  (ffi/write :float x b 0)
  (ffi/read :float b 0))

(defn seeded-noise
  "n standard normals from the PCG64 stream, narrowed to float32.
   Bit-identical to upstream portable_rng; see noise.c."
  [seed n]
  (def d (buffer/new-filled (* n 8) 0))
  (when (< (tres-fill-normal seed d n) 0) (fail "tres_fill_normal failed"))
  (def out (array/new-filled n 0.0))
  (for i 0 n
    (put out i (f32-of (ffi/read :double d (* i 8)))))
  out)

(defn run-graph
  "Run one graph. `inputs` is an array of [shape data-array] pairs."
  [label rt inputs out-count]
  (def n (length inputs))
  (def ptrs (buffer/new-filled 64 0))
  (def dims (buffer/new-filled 64 0))
  (def ranks (buffer/new-filled 32 0))
  (def nbytes (buffer/new-filled 64 0))

  (var dim-cursor 0)
  (for i 0 n
    (def [shape data] (inputs i))
    (var elems 1)
    (each d shape (set elems (* elems d)))
    (def b (buffer/new-filled (* elems 4) 0))
    (for j 0 elems (ffi/write :float (data j) b (* j 4)))
    (ffi/write :ptr b ptrs (* i 8))
    (ffi/write :int (length shape) ranks (* i 4))
    (ffi/write :long (* elems 4) nbytes (* i 8))
    (for k 0 (length shape)
      (ffi/write :int (shape k) dims (* (+ dim-cursor k) 4)))
    (set dim-cursor (+ dim-cursor (length shape))))

  (def out-buf (buffer/new-filled (* out-count 4) 0))
  (def written (buffer/new-filled 8 0))
  (def out-dims (buffer/new-filled 32 0))
  (def out-rank (buffer/new-filled 4 0))

  (def rc (tres-run-all rt n ptrs dims ranks nbytes out-buf out-count written out-dims 4 out-rank))
  (when (< rc 0) (fail "%s: %s" label (tres-last-error)))
  (unless (= rc out-count)
    (fail "%s returned %d floats, expected %d" label rc out-count))

  (def out (array/new-filled out-count 0.0))
  (for j 0 out-count (put out j (ffi/read :float out-buf (* j 4))))
  out)

#
# --- Arguments ------------------------------------------------------------
#

(def opts @{:out (string tmp-root "/coarse-latents.f32") :steps 20 :size 64 :seed 12345})

(def argv (dyn :args @[]))
(var k 0)
(while (< k (length argv))
  (def a (argv k))
  (def nx (if (< (+ k 1) (length argv)) (argv (+ k 1)) nil))
  (cond
    (= a "--out")   (do (put opts :out nx) (set k (+ k 2)))
    (= a "--steps") (do (put opts :steps (math/floor (scan-number nx))) (set k (+ k 2)))
    (= a "--size")  (do (put opts :size (math/floor (scan-number nx))) (set k (+ k 2)))
    (= a "--seed")  (do (put opts :seed (math/floor (scan-number nx))) (set k (+ k 2)))
    (set k (+ k 1))))

(def steps (opts :steps))
(def size (opts :size))
(def seed (opts :seed))
(def n-pix (* size size))

#
# --- Coarse stage ---------------------------------------------------------
#

(print "=== native COARSE LATENTS (not height) ===")
(print (string/format "onnxruntime %s | seed %d | %d steps | %dx%d"
                      (tres-version) seed steps size size))

(def t0 (os/clock))

(def coarse-path (string tmp-root "/coarse_model.onnx"))
(when (nil? (os/stat coarse-path :mode)) (fail "coarse graph missing: %s" coarse-path))
(def coarse (tres-open coarse-path))
(when (nil? coarse) (fail "coarse open: %s" (tres-last-error)))

(def sch (sc/make-scheduler steps))

# Initial sample = noise * sigmas[0], 6 channels (coarse out_channels = 6).
(def noise0 (seeded-noise (+ seed 1) (* 6 n-pix)))
(def sigma0 (sc/current-sigma sch))
(var sample (array/new-filled (* 6 n-pix) 0.0))
(for j 0 (* 6 n-pix) (put sample j (* (noise0 j) sigma0)))

# Conditioning: 5 channels of deterministic pseudo-terrain from the same stream.
(def cond (seeded-noise (+ seed 2) (* 5 n-pix)))

(def cond-scalars (array/new-filled 5 0.0))
(for c 0 5 (put cond-scalars c (* 0.1 (+ c 1))))

(var step-n 0)
(while (not (sc/done? sch))
  (def sigma (sc/current-sigma sch))
  (def c-in (sc/precondition-inputs sigma))
  (def cnoise (sc/trigflow-noise sigma))

  # x = [scaled_sample(6ch) ++ cond(5ch)] = 11 channels, matching in_channels=11.
  (def xin (array/new-filled (* 11 n-pix) 0.0))
  (for j 0 (* 6 n-pix) (put xin j (f32-of (* (sample j) c-in))))
  (for j 0 (* 5 n-pix) (put xin (+ (* 6 n-pix) j) (cond j)))

  (def out (run-graph "coarse" coarse
             @[@[[1 11 size size] xin]
               @[[1] @[cnoise]]
               @[[1] @[(cond-scalars 0)]]
               @[[1] @[(cond-scalars 1)]]
               @[[1] @[(cond-scalars 2)]]
               @[[1] @[(cond-scalars 3)]]
               @[[1] @[(cond-scalars 4)]]]
             (* 6 n-pix)))

  # One scheduler advance for the whole tensor.
  (set sample (sc/step-tensor sch sample out))
  (++ step-n)
  (when (= (mod step-n 5) 0)
    (print (string/format "  step %d/%d  sigma %.6g" step-n steps sigma))))

(tres-close coarse)

(def elapsed (- (os/clock) t0))
(print (string/format "  coarse stage done in %.1fs" elapsed))

#
# --- Emit -----------------------------------------------------------------
#

# Write raw little-endian float32 heights, one per pixel, row-major, using the
# channel-0 plane of the coarse output.
(def ob (buffer/new-filled (* n-pix 4) 0))
(var finite 0)
(var nonfinite 0)
(var min-v 1e30)
(var max-v -1e30)
(var sum 0.0)
(for j 0 n-pix
  (def v (sample j))
  (ffi/write :float v ob (* j 4))
  (if (or (not= v v) (> v 1e29) (< v -1e29))
    (++ nonfinite)
    (do
      (++ finite)
      (set sum (+ sum v))
      (when (< v min-v) (set min-v v))
      (when (> v max-v) (set max-v v)))))

(when (> nonfinite 0)
  (fail "%d non-finite values in the tile; refusing to emit" nonfinite))
(when (<= (- max-v min-v) 1e-12)
  (fail "output is constant (min==max); no model response"))

(spit (opts :out) ob)

(print "")
(print (string/format "  wrote %s  %d bytes" (opts :out) (* n-pix 4)))
(print (string/format "  latents: n=%d finite=%d min=%.4f max=%.4f mean=%.4f"
                      n-pix finite min-v max-v (/ sum finite)))
(print "")
(print "COARSE LATENTS ONLY — this is NOT a height tile and NOT terrain.")
(print "Values are model latents in native units, not metres. Base, decoder and")
(print "laplacian stages are not applied here, and conditioning is synthetic")
(print "PCG64 rather than Perlin/WorldClim quantile-matched. Do not use this")
(print "output as elevation.")
