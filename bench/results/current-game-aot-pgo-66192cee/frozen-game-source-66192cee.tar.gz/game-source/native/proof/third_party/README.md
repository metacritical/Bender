# Vendored third-party code

## FastNoiseLite.h

- Upstream: https://github.com/Auburn/FastNoiseLite
- Author: Jordan Peck and contributors
- Licence: **MIT** (the header carries its own licence block verbatim at the top)
- Vendored from: `pyfastnoiselite` 0.0.5 sdist, `ext/FastNoise/Cpp/FastNoiseLite.h`
- SHA-256: `ca72cb947b7cc558ea3a77fc837803f813890884aaf71e2b7ea6435440b9a814`
- Lines: 2586

This is the same noise implementation upstream `pyfastnoiselite` wraps, which is
what makes the native conditioning comparable to the Python path rather than a
different landscape. Do not modify this file; replace it wholesale on upgrade.

Note the header is the **class** API (`FastNoiseLite`, `SetSeed`, `GetNoise`),
not the newer `fnl_state` C interface. `conditioning_cpp.cpp` wraps it for the
plain-C `conditioning.c`.
