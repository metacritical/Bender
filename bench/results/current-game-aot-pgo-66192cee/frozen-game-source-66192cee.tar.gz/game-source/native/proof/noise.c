/*
 * noise.c — deterministic Gaussian noise for the native terrain proof.
 *
 * WHY THIS IS C AND NOT JANET
 * ---------------------------
 * The upstream generator is PCG64 (a 64-bit LCG) followed by the Marsaglia
 * polar method. A pure-Janet implementation is not possible with exact
 * semantics: bender's numbers are IEEE doubles (max exactly-representable
 * integer 2^53), while PCG64 multiplies 64-bit values modulo 2^64, and bender's
 * `band` rejects values outside signed 32-bit. Any "PCG64" written in pure
 * Janet would silently lose the low bits of every step and produce a different
 * stream. So the generator lives here, in C, with real uint64_t arithmetic.
 *
 * ALGORITHM — identical to terrain_diffusion/inference/portable_rng.py
 * --------------------------------------------------------------------
 *   state  = state * 6364136223846793005 + 1442695040888963407   (mod 2^64)
 *   xorshifted = ((state >> 18) ^ state) >> 27
 *   rot        = state >> 59
 *   out32      = rotr32(xorshifted, rot)
 *
 *   v1 = 2 * ((u1 + 1) / 2^32) - 1
 *   v2 = 2 * ((u2 + 1) / 2^32) - 1
 *   s  = v1^2 + v2^2
 *   reject unless 0 < s < 1
 *   f  = sqrt(-2 * ln(s) / s)
 *   emit v1*f, then v2*f
 *
 * This is the SAME algorithm and the same constants as upstream, so the native
 * path is comparable to the Python path rather than being an unrelated noise
 * field. Whether it reproduces upstream BIT-FOR-BIT is measured separately and
 * is NOT assumed here: see the golden-vector test. Note the upstream loop reads
 * `state` forward across the whole call, so the stream is sequential and the
 * output array length participates in the result.
 *
 * LICENSING
 * ---------
 * PCG is by Melissa O'Neill, Apache-2.0 / MIT dual. The Marsaglia polar method
 * is public-domain mathematical technique. This implementation is original.
 */

#include <math.h>
#include <stdint.h>
#include <string.h>

#define PCG64_MULT 6364136223846793005ULL
#define PCG64_INC 1442695040888963407ULL

static inline uint32_t rotr32(uint32_t x, unsigned r) {
  return (x >> r) | (x << ((32u - r) & 31u));
}

static inline uint32_t pcg64_next(uint64_t *state) {
  *state = *state * PCG64_MULT + PCG64_INC;
  uint64_t s = *state;
  uint32_t xorshifted = (uint32_t)(((s >> 18) ^ s) >> 27);
  unsigned rot = (unsigned)(s >> 59) & 31u;
  return rotr32(xorshifted, rot);
}

/*
 * Fill `n` doubles with standard normals from the stream seeded by `seed`
 * (masked to 64 bits, matching upstream's `np.uint64(int(seed) & 0xFFFF...)`).
 *
 * Returns the number of values written, or -1 on a bad argument.
 *
 * Signature note: `n` is a plain `int`, matching bender's 32-bit `:int`. An
 * `int64_t` here shifts the following argument on the FFI call and dereferences
 * a garbage pointer.
 */
int tres_fill_normal(uint64_t seed, double *out, int n) {
  if (out == NULL || n < 0) return -1;
  if (n == 0) return 0;

  uint64_t state = seed;
  const double inv_2p32 = 1.0 / 4294967296.0;
  int i = 0;

  while (i < n) {
    uint32_t u1 = pcg64_next(&state);
    uint32_t u2 = pcg64_next(&state);

    double v1 = 2.0 * ((double)u1 + 1.0) * inv_2p32 - 1.0;
    double v2 = 2.0 * ((double)u2 + 1.0) * inv_2p32 - 1.0;
    double s = v1 * v1 + v2 * v2;

    if (0.0 < s && s < 1.0) {
      double f = sqrt(-2.0 * log(s) / s);
      out[i] = v1 * f;
      i++;
      if (i < n) {
        out[i] = v2 * f;
        i++;
      }
    }
  }
  return n;
}

/*
 * Coordinate-seeded infinite Gaussian field — port of upstream
 * `gaussian_noise_patch` (world_pipeline.py:66-113).
 *
 * Upstream seeds a whole TILE from (base_seed, tile_y, tile_x) via a portable
 * 64-bit mix, fills tile_h*tile_w normals from that per-tile stream, then copies
 * the requested window out. The consequence that matters: the same world column
 * yields the same noise regardless of which request asks for it, which is what
 * makes overlapping queries agree. A plain sequential stream (fill from seed
 * directly) does NOT have that property and produces a different world.
 *
 *   h = (base_seed & 2^64-1) * 0x9E3779B9
 *   h = (h + (tile_y & 2^32-1)) & 2^64-1
 *   h = (h * 0x9E3779B9 + (tile_x & 2^32-1)) & 2^64-1
 */

static uint64_t tile_seed(uint64_t base_seed, int64_t ty, int64_t tx) {
  uint64_t h = base_seed * 0x9E3779B9ULL;
  h = (h + (uint64_t)(ty & 0xFFFFFFFFLL)) & 0xFFFFFFFFFFFFFFFFULL;
  h = (h * 0x9E3779B9ULL + (uint64_t)(tx & 0xFFFFFFFFLL)) & 0xFFFFFFFFFFFFFFFFULL;
  return h;
}

/* Floor division that matches Python's // for negatives. */
static int64_t floor_div(int64_t a, int64_t b) {
  int64_t q = a / b;
  if ((a % b != 0) && ((a < 0) != (b < 0))) q--;
  return q;
}

/*
 * Fill one channel patch of h x w at global pixel (y0, x0).
 * Returns the number of values written, or -1 on bad arguments.
 */
int tres_noise_patch_tiled(uint64_t base_seed, int64_t y0, int64_t x0,
                           int height, int width, int channels,
                           int tile_h, int tile_w,
                           double *out, int out_count);

int tres_noise_patch(uint64_t base_seed, int64_t y0, int64_t x0,
                     int height, int width, int channels,
                     double *out, int out_count) {
  /* Upstream's coarse stage passes tile_h = TILE_SIZE = 64, NOT the 256 default
   * of `gaussian_noise_patch`. The tile size participates in the per-tile seed
   * and in the stream length, so a different tile size is a different noise
   * field entirely -- verified: tile 64 vs 256 disagree from the first value.
   * The caller's `height` IS the tile size for these windows. */
  return tres_noise_patch_tiled(base_seed, y0, x0, height, width, channels,
                                height, width, out, out_count);
}

int tres_noise_patch_tiled(uint64_t base_seed, int64_t y0, int64_t x0,
                           int height, int width, int channels,
                           int tile_h, int tile_w,
                           double *out, int out_count) {
  if (out == NULL || height <= 0 || width <= 0) return -1;
  if (channels < 1 || channels > 6) return -1;
  if (out_count < channels * height * width) return -1;
  if (tile_h < 1 || tile_w < 1 || tile_h > 256 || tile_w > 256) return -1;

  int64_t ty0 = floor_div(y0, tile_h);
  int64_t ty1 = floor_div(y0 + height - 1, tile_h);
  int64_t tx0 = floor_div(x0, tile_w);
  int64_t tx1 = floor_div(x0 + width - 1, tile_w);

  for (int64_t ty = ty0; ty <= ty1; ty++) {
    int64_t tile_y0 = ty * tile_h;
    for (int64_t tx = tx0; tx <= tx1; tx++) {
      int64_t tile_x0 = tx * tile_w;

      int64_t oy0 = y0 > tile_y0 ? y0 : tile_y0;
      int64_t oy1 = (y0 + height) < (tile_y0 + tile_h) ? (y0 + height) : (tile_y0 + tile_h);
      int64_t ox0 = x0 > tile_x0 ? x0 : tile_x0;
      int64_t ox1 = (x0 + width) < (tile_x0 + tile_w) ? (x0 + width) : (tile_x0 + tile_w);

      if (oy1 <= oy0 || ox1 <= ox0) continue;

      uint64_t seed = tile_seed(base_seed, ty, tx);

      /* Upstream fills the WHOLE (channels, tile_h, tile_w) buffer from the one
       * per-tile seed, so channel c starts at offset c*tile_h*tile_w in a single
       * continuous stream. Offsetting the seed per channel instead produces a
       * different field and breaks agreement with the reference. */
      /* Up to 6 channels are requested (the coarse sample uses 6). */
      static double tile_buf[6 * 256 * 256];
      const int total = channels * (int)tile_h * tile_w;
      if (tres_fill_normal(seed, tile_buf, total) < 0) return -1;

      for (int c = 0; c < channels; c++) {
        const int64_t chan_off = (int64_t)c * tile_h * tile_w;
        double *dst = out + (int64_t)c * height * width;
        for (int64_t y = oy0; y < oy1; y++) {
          for (int64_t x = ox0; x < ox1; x++) {
            int64_t tyoff = y - tile_y0;
            int64_t txoff = x - tile_x0;
            dst[(y - y0) * width + (x - x0)] = tile_buf[chan_off + tyoff * tile_w + txoff];
          }
        }
      }
    }
  }
  return channels * height * width;
}
