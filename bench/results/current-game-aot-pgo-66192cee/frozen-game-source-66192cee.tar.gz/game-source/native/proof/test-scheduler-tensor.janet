# test-scheduler-tensor.janet — step-tensor advances state once and is
# element-independent.
#
# WHAT THIS VALIDATES
# -------------------
# `scheduler.janet` exposes two shapes for one update: `step-tensor` (a whole
# array of elements under one schedule step) and the per-element update it calls.
# The hazard is state: `step-tensor` must advance the schedule EXACTLY ONCE no
# matter how many elements it carries, and no element may influence another.
#
# The scalar-vs-vector check alone proves only that the two agree -- a shared bug
# in both paths would cancel. So the later sections pin ABSOLUTE values computed
# from a fixed synthetic model-output sequence, which is reproducible from this
# file alone with no model, no ONNX, no GPU. Those numbers are the durable
# evidence; the agreement checks are the cheap invariant.
#
# WHAT THIS DOES NOT CLAIM
# ------------------------
# Nothing about the full pipeline. A relative difference of one ULP per step in
# this arithmetic says nothing about a nonlinear model's compounding error, and
# it is NOT evidence about any observed pipeline discrepancy. This file also does
# not re-test the 21-point sigma schedule (test-scheduler.janet does that).
#
# No model forward, no graph load, no inference.

(import ./scheduler :as sc)

(var checks 0)
(var failures 0)
(defn check-eq [lbl got want]
  (++ checks)
  (unless (= got want)
    (++ failures)
    (print "  FAIL " lbl " got=" (string got) " want=" (string want))))

(defn check [lbl ok]
  (++ checks)
  (unless ok
    (++ failures)
    (print "  FAIL " lbl)))

#: Fixed synthetic model outputs, cycled. Deterministic and model-free, so the
#: absolute numbers below can be reproduced from this file alone.
(def MOUT @[0.5 -0.25 1.0 -1.5])

(defn run-vector [n-elems seed-vals]
  (def sch (sc/make-scheduler 20))
  (var v seed-vals)
  (for k 0 20
    (def mo (seq [i :range [0 n-elems]]
               (MOUT (% (+ k i) 4))))
    (set v (sc/step-tensor sch v mo)))
  [sch v])

(defn run-scalar [seed]
  (def sch (sc/make-scheduler 20))
  (var v seed)
  (for k 0 20
    (set v ((sc/step-tensor sch @[v] @[(MOUT (% k 4))]) 0)))
  [sch v])

(print "\nscalar vs vector:")

# ---- 1. A vector element must equal the scalar run with the same inputs -----
# Element 0 sees MOUT[0],MOUT[1],... in both paths.
(def [sv vv] (run-vector 2 @[3.0 7.0]))
(def [ss sc0] (run-scalar 3.0))
(check-eq "vector elem0 == scalar run" (vv 0) sc0)
# Element 1 sees a DIFFERENT sequence (offset by one), so it must differ.
(check "vector elem1 differs from elem0" (not= (vv 1) (vv 0)))
(check "elem1 is finite" (= (vv 1) (vv 1)))

# ---- 2. Absolute values from the fixed sequence ---------------------------
# Computed once from this exact file and inputs; no external fixture needed.
(def- EPS 1e-12)
(check "abs elem0 is -0.011739858801274186"
       (< (math/abs (- (vv 0) -0.011739858801274186)) EPS))
(check "abs elem1 is 0.015524492823356141"
       (< (math/abs (- (vv 1) 0.015524492823356141)) EPS))

(print "\nstate advances once:")

# ---- 3. One step-tensor call over many elements advances the index by 1 ----
(def sch3 (sc/make-scheduler 20))
(def _ (sc/step-tensor sch3 @[1.0 2.0 3.0] @[0.1 0.2 0.3]))
(check-eq "index after one call over 3 elements" (sch3 :index) 1)
(check-eq "steps is 20" (sch3 :steps) 20)
# And the full 20-step loop lands exactly on the terminal index, not past it.
(def sch4 (sc/make-scheduler 20))
(var v4 1.0)
(for k 0 20 (set v4 ((sc/step-tensor sch4 @[v4] @[(MOUT (% k 4))]) 0)))
(check-eq "index after 20 steps" (sch4 :index) 20)

(print "\nfirst/last path and terminal are finite:")

# ---- 4. The first-order path (idx 0) and the terminal guard (idx 19) ------
(defn run-trace [seed]
  (def sch (sc/make-scheduler 20))
  (var v seed)
  (def trace @[])
  (for k 0 20
    (set v ((sc/step-tensor sch @[v] @[(MOUT (% k 4))]) 0))
    (array/push trace v))
  trace)

(def tr (run-trace 1.0))
(check-eq "length of trace" (length tr) 20)
# Step 0 goes through first-order-update; step 19 through the terminal guard.
(check "value after step 1 is 0.80929787152001831"
       (< (math/abs (- (tr 0) 0.80929787152001831)) EPS))
(check "value after step 19 is -0.021855707307365614"
       (< (math/abs (- (tr 18) -0.021855707307365614)) EPS))
(check "terminal value is -0.024855333066075042"
       (< (math/abs (- (tr 19) -0.024855333066075042)) EPS))
# The terminal guard exists so the sigma-0 step does not divide by zero.
(check "terminal value is finite" (= (tr 19) (tr 19)))

(print "\n" checks " checks, " failures " failures")
(unless (zero? failures) (os/exit 1))
(print "scheduler tensor tests: all passed")
