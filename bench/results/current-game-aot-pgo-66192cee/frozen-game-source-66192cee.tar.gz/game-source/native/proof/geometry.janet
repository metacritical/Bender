# Exact infinite_tensor window geometry, in pure Janet.
#
# Derived from source, not reconstructed (see docs/NATIVE_GEOMETRY_CONTRACT.md):
#   infinite_tensor/tensor_window.py:152-190   get_bounds
#   infinite_tensor/tensor_window.py:106-148   intersecting_windows
#   infinite_tensor/infinite_tensor.py:565,581 arg_window.get_bounds(window_index)
#   world_pipeline.py:1080-1083,1244,1245,1357,1358  the window specs
#   world_pipeline.py:1375-1395                the elevation query padding
#
# This module is GEOMETRY ONLY. It says nothing about numerics -- the RNG, the EDM
# solver, the weights, or the denoise. Matching every bound here does not mean an
# elevation will match; only comparison against the live oracle's elevation_m.f32
# establishes that.
#
# No FFI, no model calls, no I/O. Everything here is a pure function of integers.

(def tile-size 64)
(def tile-stride 32)
#: The coarse stage overlaps by 16, not 32: `_build_coarse_stage` sets
#: `TILE_STRIDE = TILE_SIZE - 16` (world_pipeline.py:1062).
(def coarse-tile-stride 48)
(def decoder-tile-size 512)
(def decoder-tile-stride 384)
(def latent-compression 8)
(def coarse-pooling 1)

#: Bounds are inclusive-start / exclusive-stop per dimension, exactly as the Python
#: `slice` objects are. Never treat `stop` as inclusive: that is a one-block shift.
(defn- spec [size stride offset]
  @{:size size :stride stride :offset offset :ndim (length size)})

(defn window-spec
  "The pinned TensorWindow for `name`.

  These are the constructions in world_pipeline.py, transcribed one for one. The
  `:latent-cond` offset `(0,-1,-1)` is the one term that is easy to miss: it makes
  cond index `i` cover `i-1 .. i+3`, one cell of context before and three after."
  [name]
  (case name
    # NOTE stride 48, not 32: `_build_coarse_stage` sets
    # `TILE_STRIDE = TILE_SIZE - 16` (world_pipeline.py:1062), so coarse windows
    # overlap by 16 pixels. Using tile-stride here shifted every coarse index.
    :coarse      (spec [7 tile-size tile-size] [7 coarse-tile-stride coarse-tile-stride] [0 0 0])
    :latent      (spec [6 tile-size tile-size] [6 tile-stride tile-stride] [0 0 0])
    :latent-cond (spec [7 4 4] [7 1 1] [0 -1 -1])
    :decoder     (spec [2 decoder-tile-size decoder-tile-size]
                       [2 decoder-tile-stride decoder-tile-stride] [0 0 0])
    :decoder-in  (spec [6 (div decoder-tile-size latent-compression)
                          (div decoder-tile-size latent-compression)]
                       [6 (div decoder-tile-stride latent-compression)
                          (div decoder-tile-stride latent-compression)]
                       [0 0 0])
    (error (string "unknown window spec " name))))

(defn window-bounds
  "Pixel-space `@{:start [s...] :stop [e...]}` covered by window index `idx`.

  `start = idx*stride + offset`, `stop = start + size` -- per output dimension,
  exactly as `TensorWindow.get_bounds`. Dimensions beyond `idx` are treated as 0.
  "
  [sp idx]
  (def nd (sp :ndim))
  (def starts @[])
  (def stops @[])
  (for i 0 nd
    (def c (if (< i (length idx)) (get idx i) 0))
    (def s (+ (* c (get (sp :stride) i)) (get (sp :offset) i)))
    (array/push starts s)
    (array/push stops (+ s (get (sp :size) i))))
  @{:start starts :stop stops})

(defn- ceil-div-int [a b]
  # -((-a) // b) in integer arithmetic, matching the Python exactly.
  (def q (math/floor (/ (- a) b)))
  (- q))

(defn intersecting-windows
  "Every window index whose pixel extent intersects `q`, ordered.

  `q` is `@{:start [s...] :stop [e...]}` in pixel space. Uses the same floor
  division as `infinite_tensor`, which is what makes negative coordinates land on
  the correct window instead of one too far.

  Bounded on purpose: this is called for a 64-pixel QA query, never for a world.
  `opts` accepts `:max-candidates` (default 4096) and `:max-extent` (default 512);
  exceeding either raises rather than looping."
  [sp q &opt opts]
  (default opts @{})
  (def max-c (get opts :max-candidates 4096))
  (def max-e (get opts :max-extent 512))
  (def nd (sp :ndim))
  (def ranges @[])
  # A query may describe fewer dims than the spec. The missing PREFIX dim is the
  # channel axis, whose window count is fixed by the spec's own stride (usually a
  # single window), never by the query -- enumerating it would invent combinations
  # the pipeline never asks for.
  (def qlen (length (q :start)))
  (def skip (- nd qlen))
  (var chan-count 1)
  (for i 0 skip
    (def s (get (sp :stride) i))
    (set chan-count (max 1 (math/floor (/ (get (sp :size) i) s)))))
  (for i 0 nd
    (def lo-px (if (< i qlen) (get (q :start) i) 0))
    (def hi-px (if (< i qlen) (get (q :stop) i) chan-count))
    (def extent (- hi-px lo-px))
    (when (> extent max-e)
      (error (string "query extent " extent " on dim " i
                     " exceeds the bounded maximum " max-e)))
    (def size (get (sp :size) i))
    (def stride (get (sp :stride) i))
    (def offset (get (sp :offset) i))
    # tensor_window.py:124 -- numerator = start - offset - window_size + 1
    (def numer (+ (- lo-px offset size) 1))
    # low = ceil(numer/stride) with floor semantics
    (def low (if (>= numer 0)
               (math/floor (/ (+ numer (- stride 1)) stride))
               (ceil-div-int numer stride)))
    (def high (math/floor (/ (- (- hi-px 1) offset) stride)))
    (if (> low high)
      (break nil)
      (array/push ranges [low high])))
  (unless (= (length ranges) nd) (break @[]))
  # Cartesian product, row-major, deterministic.
  (def out @[])
  (defn walk [dim prefix]
    (if (= dim nd)
      (array/push out (tuple ;prefix))
      (do
        (def [lo hi] (get ranges dim))
        (for v lo (+ hi 1)
          (array/push prefix v)
          (walk (+ dim 1) prefix)
          (array/pop prefix)
          (when (> (length out) max-c)
            (error (string "window enumeration exceeds the bounded maximum " max-c)))))))
  (walk 0 @[])
  out)

(defn decoder-query-bounds
  "The PADDED residual pixel range the decoder stage is actually asked for.

  A 64-pixel elevation query is never the decoder window. `_compute_elev` pads by
  `sigma=5 -> kernel 11 -> pad_lr = 11//2+1 = 6 -> pad_hr = 6*8 = 48`, then aligns
  the low edge down and the high edge up to multiples of `latent_compression`.
  Omitting this is the single most likely cause of a systematic offset: at
  100000 the padded range intersects FOUR decoder windows, not one."
  [q &opt sigma]
  (default sigma 5)
  (def kernel (+ (* (math/floor (/ (* sigma 2) 2)) 2) 1))
  (def pad-lr (+ (math/floor (/ kernel 2)) 1))
  (def pad-hr (* pad-lr latent-compression))
  (def sc latent-compression)
  (defn align-down [v] (* (math/floor (/ v sc)) sc))
  (defn align-up [v] (* (ceil-div-int v sc) sc))
  @{:start [(align-down (- (get (q :start) 0) pad-hr))
            (align-down (- (get (q :start) 1) pad-hr))]
   :stop  [(align-up (+ (get (q :stop) 0) pad-hr))
           (align-up (+ (get (q :stop) 1) pad-hr))]
   :pad-hr pad-hr :sigma sigma})

(defn- ctx [face idx]
  (def sp (window-spec face))
  @{:face face :index (tuple ;idx) :bounds (window-bounds sp idx)})

(defn stage-plan
  "The ordered contexts each stage needs for an elevation `query`.

  `query` is `@{:start [i j] :stop [i2 j2]}` in elevation pixels.

  The dependency chain is NOT a shared index, and getting that wrong is what made
  an earlier planner report 4/4/4/16 where the real pipeline needs 4/25/25/4 at
  origin 100000:

    1. decoder: the PADDED query (pad_hr 48) intersected with 512/384 windows.
    2. latent:  each decoder window consumes latent pixels via `decoder-in`
       (64 wide, stride 48). The UNION of those ranges is intersected with latent
       windows (64, stride 32), expanding 4 decoder windows into 25 latent ones
       spanning 387..391.
    3. cond:    indexed in WINDOW space -- the same index as each latent window
       (infinite_tensor.py:565, arg_window.get_bounds(window_index)) -- so its
       count equals the latent count. Pixels are 4 wide with offset -1.
    4. coarse:  NOT indexed by latent index and NOT rescaled. The cond window's own
       pixels (386..394) are intersected directly against the coarse stage's
       64/48 windows (`_build_coarse_stage`, TILE_STRIDE = TILE_SIZE - 16), giving
       indices 7..8.

  Returns `@{:padded :decode :latent :cond :coarse :counts :ranges}`."
  [query &opt opts]
  (default opts @{})
  (def padded (decoder-query-bounds query (get opts :sigma 5)))
  (def dsp (window-spec :decoder))
  (def dwins
    (intersecting-windows
      dsp
      @{:start [0 (get (padded :start) 0) (get (padded :start) 1)]
        :stop  [1 (get (padded :stop) 0)  (get (padded :stop) 1)]}
      opts))

  # 2. latent windows over the union of latent pixels the decoders consume.
  (def din (window-spec :decoder-in))
  (defn- span-on [ws dim]
    (var lo nil) (var hi nil)
    (each w ws
      (def b (window-bounds din w))
      (def s (get (b :start) dim)) (def e (get (b :stop) dim))
      (set lo (if (nil? lo) s (min lo s)))
      (set hi (if (nil? hi) e (max hi e))))
    (if (nil? lo) nil @[lo hi]))
  (def ispan (span-on dwins 1))
  (def jspan (span-on dwins 2))
  (def lwins
    (if (nil? ispan)
      @[]
      (intersecting-windows (window-spec :latent)
                            @{:start [0 (get ispan 0) (get jspan 0)]
                              :stop  [1 (get ispan 1) (get jspan 1)]}
                            opts)))

  # 3. cond shares the latent window index; 4. coarse from the cond pixel span.
  (def conds (map (fn [w] (ctx :latent-cond w)) lwins))
  (var clo nil) (var chi nil)
  (each c conds
    (def b (c :bounds))
    (def s (get (b :start) 1)) (def e (get (b :stop) 1))
    (set clo (if (nil? clo) s (min clo s)))
    (set chi (if (nil? chi) e (max chi e))))
  (def coarse
    (if (nil? clo)
      @[]
      (map (fn [w] (ctx :coarse w))
           (intersecting-windows (window-spec :coarse)
                                 @{:start [0 clo clo] :stop [1 chi chi]}
                                 opts))))
  (defn- rng [idxs]
    (if (pos? (length idxs)) @[(get (get idxs 0) 1) (get (get idxs (- (length idxs) 1)) 1)] nil))
  @{:padded padded
    :decode (map (fn [w] (ctx :decoder w)) dwins)
    :latent (map (fn [w] (ctx :latent w)) lwins)
    :cond conds
    :coarse coarse
    :counts @{:decoder (length dwins) :latent (length lwins)
              :cond (length conds) :coarse (length coarse)}
    :ranges @{:decoder (rng dwins) :latent (rng lwins)
              :coarse (rng (map (fn [c] (c :index)) coarse))}})

(defn weighted-assemble
  "Combine overlapping windows by weight, never by equal average.

  `entries` is a sequence of `@[values weights]` where both are flat sequences of
  the same length. Returns `@[sum weight-sum]` so the caller divides once, matching
  `residual_init[0] / residual_init[1]`: `_decoder_inference` returns
  `cat([sample*weight, weight])` and the consumer divides. Averaging overlaps
  equally cannot reproduce the seam blend."
  [entries]
  (def n (length entries))
  (when (zero? n) (error "weighted-assemble needs at least one entry"))
  (def width (length (get (get entries 0) 0)))
  (def acc (array/new-filled width 0))
  (def wacc (array/new-filled width 0))
  (each e entries
    (def [vals wts] e)
    (unless (= (length vals) width)
      (error "weighted-assemble entries must share a length"))
    (unless (= (length wts) width)
      (error "weighted-assemble weights must match the value length"))
    (for i 0 width
      (put acc i (+ (get acc i) (* (get vals i) (get wts i))))
      (put wacc i (+ (get wacc i) (get wts i)))))
  @[acc wacc])

(defn bounds-of-face
  "Convenience: the `@{:start :stop}` for window index `idx` of `face`."
  [face idx]
  (window-bounds (window-spec face) idx))
