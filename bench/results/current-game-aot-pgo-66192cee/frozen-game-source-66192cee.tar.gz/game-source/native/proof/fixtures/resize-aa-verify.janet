# GOLDEN FIXTURES (verification round) -- real torchvision, CPU float32.
# No model, no GPU, no weights, no inference. Paired with
# resize-aa-verify.json for external consumers; this .janet form is what the
# proofs import, because bender ships no JSON reader.
#
# Source: torch 2.13.0 / torchvision 0.28.0, BILINEAR,
# antialias=True, align_corners=False.
#
# Values are transcribed at FULL precision. An earlier %g transcription cut
# 0.009398497 to 0.009398 and produced a spurious ~5e-7 error that was then
# blamed on float32; do not reformat.
#
# The edge impulse distinguishes DROP-AND-RENORMALISE from CLAMP. For 8 -> 3
# output 0 the taps are 11/38, 15/38, 9/38, 3/38 on source indices 0..3, so an
# impulse at (0,0) must give (11/38)^2 = 0.083795014 at out[0,0]. Clamping
# instead folds out-of-range taps onto index 0 for a weight of 3/8 per axis and
# a corner of (3/8)^2 = 0.140625, about 68 percent higher.

# sha256 of the paired JSON (resize-aa-verify.json), which carries the same numbers plus
# the torch/torchvision versions. Pinned so a silent divergence between the
# JSON and this transcription is detectable rather than trusted.
(def json-sha256 "448511efc015ad5014147f73cff4f6dd96a6042ae8d2e0685a475a305568f797")

(def torch-version "2.13.0")
(def torchvision-version "0.28.0")
(def interpolation "BILINEAR")
(def antialias true)
(def align-corners false)
(def in-h 8)
(def in-w 8)

(def edge-00
  @{:out-h 3 :out-w 3
    :note "corner impulse; predicted out[0] = (11/38)^2 = 0.083795014"
    :in
     @[1.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0]
    :out
     @[0.083795011 0.0 0.0
     0.0 0.0 0.0
     0.0 0.0 0.0]})

(def offcentre-1-6
  @{:out-h 3 :out-w 3
    :in
     @[0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 1.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
     0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0]
    :out
     @[0.0 0.009398497 0.155817181
     0.0 0.000566893 0.009398496
     0.0 0.0 0.0]})

(def checker-p0
  @{:out-h 3 :out-w 3
    :in
     @[0.0 1.0 0.0 1.0 0.0 1.0 0.0 1.0
     1.0 0.0 1.0 0.0 1.0 0.0 1.0 0.0
     0.0 1.0 0.0 1.0 0.0 1.0 0.0 1.0
     1.0 0.0 1.0 0.0 1.0 0.0 1.0 0.0
     0.0 1.0 0.0 1.0 0.0 1.0 0.0 1.0
     1.0 0.0 1.0 0.0 1.0 0.0 1.0 0.0
     0.0 1.0 0.0 1.0 0.0 1.0 0.0 1.0
     1.0 0.0 1.0 0.0 1.0 0.0 1.0 0.0]
    :out
     @[0.498614967 0.50000006 0.501385093
     0.5 0.50000006 0.5
     0.501385033 0.5 0.498614967]})

# The four tap weights for output 0 of an 8 -> 3 resample, as exact
# rationals, so an implementation can be checked against the filter itself.
(def taps-out0 @[@{:index 0 :weight-num 11 :weight-den 38}
               @{:index 1 :weight-num 15 :weight-den 38}
               @{:index 2 :weight-num 9  :weight-den 38}
               @{:index 3 :weight-num 3  :weight-den 38}])
(def corner-expected-squared (/ (* 11 11) (* 38 38)))
