# GOLDEN FIXTURES -- generated at build time from the real Python
# infinite_tensor.TensorWindow by calling get_bounds / intersecting_windows.
# Do not hand-edit: regenerate with tools/terrain_geometry_golden.py.
# Janet data, not JSON: bender has no json module, and a fixture that
# cannot be loaded proves nothing.
(def window-definitions
  @{
    :coarse @{:size [7 64 64] :stride [7 48 48] :offset [0 0 0]}
    :latent @{:size [6 64 64] :stride [6 32 32] :offset [0 0 0]}
    :latent-cond @{:size [7 4 4] :stride [7 1 1] :offset [0 -1 -1]}
    :decoder @{:size [2 512 512] :stride [2 384 384] :offset [0 0 0]}
    :decoder-in @{:size [6 64 64] :stride [6 48 48] :offset [0 0 0]}
   })

(def bounds-table
  @{
   :coarse @{
     0 @{:start [0 0 0] :stop [7 64 64]}
     7 @{:start [0 336 336] :stop [7 400 400]}
     259 @{:start [0 12432 12432] :stop [7 12496 12496]}
     260 @{:start [0 12480 12480] :stop [7 12544 12544]}
     386 @{:start [0 18528 18528] :stop [7 18592 18592]}
     387 @{:start [0 18576 18576] :stop [7 18640 18640]}
   }
   :latent @{
     0 @{:start [0 0 0] :stop [6 64 64]}
     7 @{:start [0 224 224] :stop [6 288 288]}
     259 @{:start [0 8288 8288] :stop [6 8352 8352]}
     260 @{:start [0 8320 8320] :stop [6 8384 8384]}
     386 @{:start [0 12352 12352] :stop [6 12416 12416]}
     387 @{:start [0 12384 12384] :stop [6 12448 12448]}
   }
   :latent-cond @{
     0 @{:start [0 -1 -1] :stop [7 3 3]}
     7 @{:start [0 6 6] :stop [7 10 10]}
     259 @{:start [0 258 258] :stop [7 262 262]}
     260 @{:start [0 259 259] :stop [7 263 263]}
     386 @{:start [0 385 385] :stop [7 389 389]}
     387 @{:start [0 386 386] :stop [7 390 390]}
   }
   :decoder @{
     0 @{:start [0 0 0] :stop [2 512 512]}
     7 @{:start [0 2688 2688] :stop [2 3200 3200]}
     259 @{:start [0 99456 99456] :stop [2 99968 99968]}
     260 @{:start [0 99840 99840] :stop [2 100352 100352]}
     386 @{:start [0 148224 148224] :stop [2 148736 148736]}
     387 @{:start [0 148608 148608] :stop [2 149120 149120]}
   }
   :decoder-in @{
     0 @{:start [0 0 0] :stop [6 64 64]}
     7 @{:start [0 336 336] :stop [6 400 400]}
     259 @{:start [0 12432 12432] :stop [6 12496 12496]}
     260 @{:start [0 12480 12480] :stop [6 12544 12544]}
     386 @{:start [0 18528 18528] :stop [6 18592 18592]}
     387 @{:start [0 18576 18576] :stop [6 18640 18640]}
   }
   })

(def dependency-pairs
  @[
   @{:output-index 7
     :args @{
       :coarse @{:start [0 336 336] :stop [7 400 400]}
       :latent @{:start [0 224 224] :stop [6 288 288]}
       :latent-cond @{:start [0 6 6] :stop [7 10 10]}
       :decoder-in @{:start [0 336 336] :stop [6 400 400]}
     }}
   @{:output-index 259
     :args @{
       :coarse @{:start [0 12432 12432] :stop [7 12496 12496]}
       :latent @{:start [0 8288 8288] :stop [6 8352 8352]}
       :latent-cond @{:start [0 258 258] :stop [7 262 262]}
       :decoder-in @{:start [0 12432 12432] :stop [6 12496 12496]}
     }}
   @{:output-index 386
     :args @{
       :coarse @{:start [0 18528 18528] :stop [7 18592 18592]}
       :latent @{:start [0 12352 12352] :stop [6 12416 12416]}
       :latent-cond @{:start [0 385 385] :stop [7 389 389]}
       :decoder-in @{:start [0 18528 18528] :stop [6 18592 18592]}
     }}
   ])

(def padded-queries
  @[
   @{:query [100000 100000 100064 100064] :padded [99952 99952 100112 100112] :decoder-windows [[259 259] [259 260] [260 259] [260 260]]}
   @{:query [0 0 64 64] :padded [-48 -48 112 112] :decoder-windows [[-1 -1] [-1 0] [0 -1] [0 0]]}
   @{:query [-1 -1 63 63] :padded [-56 -56 112 112] :decoder-windows [[-1 -1] [-1 0] [0 -1] [0 0]]}
   @{:query [-64 -64 0 0] :padded [-112 -112 48 48] :decoder-windows [[-1 -1] [-1 0] [0 -1] [0 0]]}
   @{:query [100000 100000 100128 100128] :padded [99952 99952 100176 100176] :decoder-windows [[259 259] [259 260] [260 259] [260 260]]}
   ])
