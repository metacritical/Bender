# Original, backend-neutral voxel corner AO arithmetic. Not a renderer or a
# Bliss-derived implementation; no mesh, shader, or model runtime is involved.
(def brightness [1.0 0.8 0.6 0.45])

(defn corner-occlusion [side-a side-b diagonal]
  ``Return 0..3 blocked-neighbour count; touching side walls fully occlude.``
  (each occupied [side-a side-b diagonal]
    (assert (boolean? occupied) "corner occupancy must be boolean"))
  (if (and side-a side-b)
    3
    (+ (if side-a 1 0) (if side-b 1 0) (if diagonal 1 0))))

(defn quad-diagonal [ao4]
  ``Return :flip if the opposite 0/2 BRIGHTNESS sum exceeds 1/3;
  otherwise :keep (including ties). Corner order is 0..3, and AO level
  0 is brightest, 3 darkest. :keep names the 0–2 diagonal and :flip
  names 1–3; this is a convention, not renderer index ordering.``
  (assert (and (or (array? ao4) (tuple? ao4)) (= (length ao4) 4))
          "quad AO needs exactly four ordered corners")
  (each level ao4
    (assert (and (number? level) (= level (math/floor level))
                 (<= 0 level 3))
            "quad AO levels must be integers 0..3"))
  (let [sum02 (+ (get brightness (get ao4 0))
                 (get brightness (get ao4 2)))
        sum13 (+ (get brightness (get ao4 1))
                 (get brightness (get ao4 3)))]
    (if (> sum02 sum13) :flip :keep)))
