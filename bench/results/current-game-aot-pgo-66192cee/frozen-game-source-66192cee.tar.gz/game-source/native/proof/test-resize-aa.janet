# test-resize-aa.janet — antialias bilinear downsample vs real torchvision.
#
# WHAT THIS VALIDATES
# -------------------
# `resize-bilinear-antialias-2d` against real torchvision CPU captures. The
# expected values are NOT derived from the implementation and NOT hand-computed:
# they are what torchvision produced on the same input (see
# native/proof/capture-resize-aa*.py, which record the torch and torchvision
# versions in the fixtures).
#
# Two fixtures feed this file:
#   fixtures/resize-aa.janet          six 8x8 -> {3,4,5} cases
#   fixtures/resize-aa-verify.janet   edge / off-centre / checker, plus the exact
#                                     tap weights for output 0 of an 8 -> 3 pass
#   fixtures/resize-aa-addendum.janet the upsample guard (AA vs noAA)
#
# WHAT THE EDGE CASE PROVES
# -------------------------
# For 8 -> 3, output index 0 has centre 0.8333 and support radius 2.6667, so its
# taps are exactly 11/38, 15/38, 9/38, 3/38 on source indices 0..3. An impulse at
# (0,0) must therefore give (11/38)^2 = 0.083795014 at out[0,0].
#
# A CLAMP implementation instead folds out-of-range taps onto index 0, giving
# weight 3/8 per axis and a corner of (3/8)^2 = 0.140625 — about 68% higher. So
# the edge case discriminates drop-and-renormalise from clamp on a single number,
# which is why it is asserted against both the capture and the analytic value.
#
# WHAT THIS DOES NOT CLAIM
# ------------------------
# Nothing about the full pipeline. This tests the resize filter only. The
# encoder does not yet route through it (that is a separate, unstarted change),
# and native coarse 44x is not addressed here.
#
# No model, no weights, no GPU, no inference, no Python at runtime.

(import ./laplacian :as lap)
(import ./fixtures/resize-aa :as aa)
(import ./fixtures/resize-aa-verify :as vr)
(import ./fixtures/resize-aa-addendum :as ad)

(var checks 0)
(var failures @[])

(defn ok [lbl]
  (++ checks)
  (print "  ok    " lbl))

(defn bad [lbl &opt detail]
  (++ checks)
  (array/push failures lbl)
  (print "  FAIL  " lbl (if detail (string " (" detail ")") "")))

(defn close? [a b tol] (<= (math/abs (- a b)) tol))

# Float32 agreement, measured rather than assumed. With the fixture transcribed at
# full precision the worst observed deviation is 6.0e-08 (checker), which is
# about half a float32 ULP near 0.5. TOL is set at 1e-7: comfortably above the
# observed error, far below the 5e-7 that a 6-significant-digit transcription
# artifact used to produce. The old 2e-6 was hiding that artifact.
(def TOL 1e-7)

(defn check-max-diff [lbl got want tol]
  (var worst 0.0)
  (for i 0 (min (length got) (length want))
    (def d (math/abs (- (got i) (want i))))
    (when (> d worst) (set worst d)))
  (if (<= worst tol)
    (do (++ checks) (print (string/format "  ok    %-24s max diff %.2e" lbl worst)))
    (do (++ checks) (array/push failures lbl)
        (print (string/format "  FAIL  %-24s max diff %.6f" lbl worst)))))

#
# --- 1. Six torchvision captures, 8x8 -> 3x3 / 4x4 / 5x5 -------------------
#
(print "")
(print "=== torchvision captures: 8x8 downsamples ===")

(each c aa/cases
  (def nm (c :case))
  (def oh (c :out-h))
  (def ow (c :out-w))
  (def got (lap/resize-bilinear-antialias-2d (c :in) aa/in-h aa/in-w oh ow))
  (def want (c :out))
  (if (= (length got) (length want))
    (ok (string nm " " oh "x" ow " length"))
    (bad (string nm " length") (string (length got) " want " (length want))))
  (check-max-diff nm got want TOL))

#
# --- 2. The verification round: edge, off-centre, checker ------------------
#
(print "")
(print "=== verification round: edge / off-centre / checker ===")

(each [nm c] [["edge-00" vr/edge-00]
              ["offcentre-1-6" vr/offcentre-1-6]
              ["checker-p0" vr/checker-p0]]
  (def got (lap/resize-bilinear-antialias-2d (c :in) 8 8 3 3))
  (check-max-diff nm got (c :out) TOL))

#
# --- 3. The tap weights themselves, as exact rationals --------------------
#
# Checking against the filter's weights is stronger than checking against one
# output value: it pins WHICH source indices contribute and how much.
#
(print "")
(print "=== 8->3 taps for output 0 are 11/38, 15/38, 9/38, 3/38 ===")

# Reconstruct the weights by differentiating: feed a unit impulse at each source
# index in turn and read out[0]. For a separable filter the 2-D response at
# [0,0] is w_i * w_0, so the ratio of the i-th response to the 0-th gives w_i/w_0
# directly, independent of scale.
(defn response-at-00 [src-idx]
  (def t (array/new-filled 64 0.0))
  (put t src-idx 1.0)
  (get (lap/resize-bilinear-antialias-2d t 8 8 3 3) 0))

(def r0 (response-at-00 0))
(def w0 (/ 11 38))
(if (close? r0 (* w0 w0) 1e-9)
  (ok "impulse at (0,0) gives (11/38)^2 = 0.083795014")
  (bad "corner analytic" (string/format "%.9f vs %.9f" r0 (* w0 w0))))

# A clamp implementation cannot produce this: its corner would be (3/8)^2.
(if (> (math/abs (- r0 (* (/ 3 8) (/ 3 8)))) 0.05)
  (ok "corner is NOT the clamp value (3/8)^2 = 0.140625")
  (bad "corner matches a clamp implementation"))

# Each pinned rational from the fixture, checked as a ratio against w0.
(each t vr/taps-out0
  (def idx (t :index))
  (def want (/ (t :weight-num) (t :weight-den)))
  (def got (/ (response-at-00 idx) r0))
  (if (close? got (/ want w0) 1e-9)
    (ok (string "tap j=" idx " is " (t :weight-num) "/" (t :weight-den)))
    (bad (string "tap j=" idx) (string/format "ratio %.9f want %.9f" got (/ want w0)))))

#
# --- 4. Phases must be distinguished --------------------------------------
#
# Both checker phases flatten to the same 0.5 interior and differ ONLY at the
# corners, with opposite bias. A phase-blind filter returns identical arrays and
# would pass a single-phase test.
#
(print "")
(print "=== checker phases differ at corners, agree in the centre ===")

(def c0 (lap/resize-bilinear-antialias-2d (get (aa/cases 3) :in) 8 8 3 3))
(def c1 (lap/resize-bilinear-antialias-2d (get (aa/cases 4) :in) 8 8 3 3))
(if (and (> (math/abs (- (c0 0) (c1 0))) 1e-4)
         (> (math/abs (- (c0 8) (c1 8))) 1e-4))
  (ok "corner biases differ between phase 0 and phase 1")
  (bad "phases not distinguished at the corners"))
(if (close? (c0 4) (c1 4) 1e-9)
  (ok "centre is identical between phases (0.5)")
  (bad "centre differs between phases"))

#
# --- 5. Antialias is not a no-op passthrough ------------------------------
#
(print "")
(print "=== antialias differs from plain bilinear on a downsample ===")

(def plainc (lap/resize-bilinear-2d (get (aa/cases 3) :in) 8 8 3 3))
(var differs false)
(for i 0 9 (when (> (math/abs (- (plainc i) (c0 i))) 1e-3) (set differs true)))
(if differs
  (ok "antialias result differs from plain bilinear")
  (bad "antialias produced the plain bilinear result"))

#
# --- 6. Upsampling must stay bit-identical -------------------------------
#
# torchvision does NOT antialias when upsampling: the capture recorded
# max |aa - noaa| = 0 for a 1x4 -> 1x8 ramp. So the existing upsample path must
# not move, and the old goldens stay valid.
#
(print "")
(print "=== upsampling is unaffected (AA is a downsample concern) ===")

(def up-now (lap/resize-bilinear-2d ad/ramp-in 1 4 1 8))
(if (= (length up-now) 8)
  (ok "upsample length 8")
  (bad "upsample length"))
(check-max-diff "upsample ramp" up-now @[0.0 0.25 0.75 1.25 1.75 2.25 2.75 3.0] 1e-12)

# And the captured AA-vs-noAA equality, straight from the fixture.
(check-max-diff "aa == noaa on upsample" ad/ramp-up-aa ad/ramp-up-noaa 0.0)

#
# --- 7. MIXED axes are REFUSED, not silently approximated ---------------
#
# The helper is down-sampling only. Earlier it used radius = scale, which gave a
# growing axis radius < 1, driving `1 - |d|/radius` to <= 0 for every neighbour
# and collapsing that axis to a single zero tap. radius is now max(1, scale), but
# a mixed call is still outside what the captures validate, so it raises instead
# of returning plausible numbers nobody has checked against torch.
#
# Callers that must grow an axis use resize-bilinear-2d, whose plain clamp-tap
# path is the recorded upsample behaviour.
#
(print "")
(print "=== mixed axes are refused ===")

(def mixed-cases @[[8 4 3 8] [4 8 8 3] [8 8 4 16] [8 8 16 4]])
(var refused 0)
(each [r c or ow] mixed-cases
  (def t (array/new-filled (* r c) 1.0))
  (try (lap/resize-bilinear-antialias-2d t r c or ow)
       ([e] (++ refused))))
(if (= refused (length mixed-cases))
  (ok (string "all " (length mixed-cases) " growing calls refused"))
  (bad "mixed guard" (string refused " of " (length mixed-cases) " refused")))

# Pure downsampling must still work, including anisotropic (both axes shrink but
# by different factors).
(var down-ok true)
(each [r c or ow] [[8 8 3 3] [8 4 4 2] [16 16 4 4] [8 8 5 3]]
  (def t (array/new-filled (* r c) 1.0))
  (def o (lap/resize-bilinear-antialias-2d t r c or ow))
  (unless (= (length o) (* or ow)) (set down-ok false)))
(if down-ok
  (ok "pure downsampling accepted in all directions")
  (bad "a downsampling call failed"))

# A constant field must survive downsampling exactly -- this is the property the
# collapsed support used to violate.
(var const-ok true)
(each [r c or ow] [[8 8 3 3] [8 4 4 2] [16 16 4 4]]
  (def t (array/new-filled (* r c) 2.0))
  (def o (lap/resize-bilinear-antialias-2d t r c or ow))
  (for i 0 (length o) (unless (close? (o i) 2.0 1e-12) (set const-ok false))))
(if const-ok
  (ok "constant field preserved through downsampling")
  (bad "constant field drifted on downsample"))

# --- 8. The captures are discriminating, not a shift ---------------------
#
# A test can pass merely because expected and actual moved together. These check
# the captured antialias outputs are NOT what a plain (non-AA) filter produces,
# so the fixture genuinely distinguishes the two designs.
#
(print "")
(print "=== captures discriminate AA from plain bilinear ===")

(defn max-abs-diff [a b]
  (var m 0.0)
  (for i 0 (min (length a) (length b))
    (def d (math/abs (- (a i) (b i))))
    (when (> d m) (set m d)))
  m)

(each c aa/cases
  (def nm (c :case))
  (def oh (c :out-h))
  (def ow (c :out-w))
  (def cap (c :out))
  (def plain-out (lap/resize-bilinear-2d (c :in) aa/in-h aa/in-w oh ow))
  (def d (max-abs-diff cap plain-out))
  (if (> d 1e-3)
    (ok (string/format "%-24s captured != plain (diff %.4f)" nm d))
    (bad (string nm " capture not discriminating") (string/format "diff %.6f" d))))

# And the edge corner is specifically not the clamp value, restated here so a
# future "simplification" to clamping fails loudly.
(def eo (get vr/edge-00 :out))
(if (> (math/abs (- (eo 0) (* (/ 3 8) (/ 3 8)))) 0.05)
  (ok "edge capture is not the clamp value (3/8)^2")
  (bad "edge capture matches a clamp implementation"))

#
(print "")
(unless (empty? failures)
  (print (string/format "RESIZE-AA FAILED: %d of %d" (length failures) checks))
  (os/exit 1))
(print (string/format "RESIZE-AA PASSED (%d checks)" checks))
