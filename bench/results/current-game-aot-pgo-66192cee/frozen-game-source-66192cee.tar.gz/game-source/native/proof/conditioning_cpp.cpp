// Thin C++ shim exposing FastNoiseLite (C++ class API) to conditioning.c.
//
// The vendored header is the CLASS interface (FastNoiseLite with SetSeed/
// SetNoiseType/...), not the newer fnl_state C style, so the noise field has to
// be constructed in C++ and conditioning.c stays plain C.

#include <cstdint>
#include "FastNoiseLite.h"

extern "C" double tres_perlin2d(uint32_t ch_seed, double freq, int octaves,
                                double x, double y) {
  FastNoiseLite noise;
  noise.SetSeed((int)ch_seed);
  noise.SetNoiseType(FastNoiseLite::NoiseType_Perlin);
  noise.SetFrequency((float)freq);
  noise.SetFractalType(FastNoiseLite::FractalType_FBm);
  noise.SetFractalOctaves(octaves);
  noise.SetFractalLacunarity(2.0f);
  noise.SetFractalGain(0.5f);
  return (double)noise.GetNoise((float)x, (float)y);
}
