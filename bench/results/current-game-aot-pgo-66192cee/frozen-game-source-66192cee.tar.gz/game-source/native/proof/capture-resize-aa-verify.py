import json, hashlib, torch, torchvision
import torchvision.transforms.functional as TF

def cap(t, oh, ow):
    o = TF.resize(t, [oh, ow], interpolation=TF.InterpolationMode.BILINEAR, antialias=True)
    return [round(float(v), 9) for v in o.flatten().tolist()]

def arr(rows): return [float(v) for r in rows for v in r]

cases = {}

# EDGE impulse at (0,0). Predicted first tap weight 11/38, so out[0]=(11/38)^2.
edge = torch.zeros(1,1,8,8); edge[0,0,0,0] = 1.0
cases["impulse_edge_00_3x3"] = {"in": arr(edge[0,0].tolist()), "out": cap(edge,3,3),
  "note": "corner impulse; predicted out[0] = (11/38)^2 = 0.083795014"}

# OFF-CENTRE impulse at (1,6): exercises non-symmetric taps.
off = torch.zeros(1,1,8,8); off[0,0,1,6] = 1.0
cases["impulse_offcentre_1_6_3x3"] = {"in": arr(off[0,0].tolist()), "out": cap(off,3,3)}

# CHECKER: full array in and out, phase 0.
chk = torch.zeros(1,1,8,8)
for y in range(8):
    for x in range(8): chk[0,0,y,x] = float((x+y) % 2)
cases["checker_phase0_3x3"] = {"in": arr(chk[0,0].tolist()), "out": cap(chk,3,3)}

# Every row/col of the edge impulse, so the tap ORDER is checkable not just out[0].
row0 = cap(edge,3,3)[0:3]
doc = {"_note": "torchvision BILINEAR antialias=True, CPU float32. Verify-against-analytic round. No model/GPU/weights.",
       "torch": torch.__version__, "torchvision": torchvision.__version__,
       "interpolation": "BILINEAR", "antialias": True, "align_corners": False,
       "cases": cases}
p="native/proof/fixtures/resize-aa-verify.json"
open(p,"w").write(json.dumps(doc, indent=1))
print(json.dumps({"sha256": hashlib.sha256(open(p,'rb').read()).hexdigest(),
  "edge_out00": cases["impulse_edge_00_3x3"]["out"][0],
  "analytic": round((11/38)**2, 9)}, indent=1))
