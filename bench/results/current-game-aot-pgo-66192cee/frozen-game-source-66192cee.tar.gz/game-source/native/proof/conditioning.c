/*
 * conditioning.c — the real Perlin/WorldClim quantile conditioning map.
 *
 * WHY THIS IS C
 * -------------
 * The conditioning map is FastNoiseLite Perlin noise quantile-matched against
 * WorldClim climate distributions, then post-processed with a lapse-rate
 * correction. The noise itself is C++ (FastNoiseLite, MIT, vendored in
 * third_party/), so the perlin field has to live here. The quantile match is a
 * piecewise-linear interpolation over 64 knots, which is pure arithmetic.
 *
 * WHAT IT REPRODUCES
 * ------------------
 * Exactly upstream `make_synthetic_map_factory(seed, frequency_mult, drop_water_pct)`
 * at e8dcb4b1:
 *
 *   for channel i in 0..4:
 *     noise = FastNoiseLite(seed = (seed + i + 1) & 0x7FFFFFFF)
 *             Perlin, FBm, octaves/frequency per map_configs
 *     raw   = transform_perlin(noise(x,y), noise_quantiles_i, data_quantiles_i)
 *   then finalize_synthetic_map(raw):
 *     ch0 = sign(x)*sqrt(|x|)
 *     ch1 = temp + lapse_rate*max(0, elev), clipped, sub-20 stretched
 *     ch2 = seasonality from temp_std quantiles
 *     ch3,ch4 = precip and precip CV
 *
 * The quantile tables and scalar constants are NOT hardcoded here: they are
 * read from a flat binary the build step writes out of the pinned stats file.
 * That keeps the numerics data-driven and auditable instead of transcribed.
 *
 * NO RASTERS AT RUNTIME
 * ---------------------
 * The WorldClim GeoTIFFs are only used at BUILD time, by upstream's own Python,
 * to produce the quantile tables. Nothing here opens a TIFF, so the shipped
 * runtime has no GDAL/libtiff dependency and no large raster payload.
 *
 * LICENSING
 * ---------
 * FastNoiseLite: MIT (header carries its own licence, vendored verbatim).
 * Quantile tables: derived quantities computed from WorldClim 2.1 (Fick &
 * Hijmans 2017). They are distribution summaries, not raster copies. WorldClim
 * must be cited for the derived data; see native/proof/README.md.
 */

#include <math.h>
#include <stdint.h>
#include <string.h>

/* FastNoiseLite is C++; this TU stays plain C and calls the shim in
 * conditioning_cpp.cpp, because the ORT header cannot be included from C++. */
extern double tres_perlin2d(uint32_t ch_seed, double freq, int octaves,
                            double x, double y);

#define N_QUANTILES 64
#define N_CHANNELS 5

/* Quantile tables and scalars, loaded once from the flat fixture. */
typedef struct {
  int ready;
  double noise_q[N_CHANNELS][N_QUANTILES];
  double data_q[N_CHANNELS][N_QUANTILES];
  double a_temp_std;
  double b_temp_std;
  double temp_std_p1;
  double temp_std_p99;
} TresCondData;

static TresCondData g_cond;

/* Per-channel noise geometry, from synthetic_map.make_synthetic_map_factory's
 * map_configs at frequency_mult = [1,1,1,1,1]:
 *   ch0: freq 0.05, octaves 4
 *   ch1: freq 0.05, octaves 2
 *   ch2: freq 0.05, octaves 4
 *   ch3: freq 0.05, octaves 4
 *   ch4: freq 0.05, octaves 4
 * lacunarity 2.0, gain 0.5 for all.
 */
static const double kFrequency[N_CHANNELS] = {0.05, 0.05, 0.05, 0.05, 0.05};
static const int kOctaves[N_CHANNELS] = {4, 2, 4, 4, 4};

/*
 * Load the flat fixture produced by the build step.
 *
 * Layout (native endian, doubles unless noted):
 *   [0]            a_temp_std
 *   [1]            b_temp_std
 *   [2]            temp_std_p1
 *   [3]            temp_std_p99
 *   [4 .. 4+320)   noise_q[5][64]
 *   [324 .. 644)   data_q[5][64]
 *
 * Returns 1 on success, 0 if the buffer is too small.
 */
int tres_cond_load(const double *buf, int64_t count) {
  const int64_t need = 4 + (int64_t)N_CHANNELS * N_QUANTILES * 2;
  if (buf == NULL || count < need) return 0;

  g_cond.a_temp_std = buf[0];
  g_cond.b_temp_std = buf[1];
  g_cond.temp_std_p1 = buf[2];
  g_cond.temp_std_p99 = buf[3];

  int64_t k = 4;
  for (int c = 0; c < N_CHANNELS; c++) {
    for (int i = 0; i < N_QUANTILES; i++) g_cond.noise_q[c][i] = buf[k++];
  }
  for (int c = 0; c < N_CHANNELS; c++) {
    for (int i = 0; i < N_QUANTILES; i++) g_cond.data_q[c][i] = buf[k++];
  }
  g_cond.ready = 1;
  return 1;
}

int tres_cond_ready(void) { return g_cond.ready; }

/* np.interp with edge clamping, matching transform_perlin's left/right. */
static double interp_clamped(double x, const double *xs, const double *ys, int n) {
  if (x <= xs[0]) return ys[0];
  if (x >= xs[n - 1]) return ys[n - 1];
  /* linear scan is fine: 64 knots, called 5*W*H times is still cheap, and it
   * avoids a subtle binary-search off-by-one against numpy's exact behaviour. */
  for (int i = 1; i < n; i++) {
    if (x <= xs[i]) {
      double t = (x - xs[i - 1]) / (xs[i] - xs[i - 1]);
      return ys[i - 1] + t * (ys[i] - ys[i - 1]);
    }
  }
  return ys[n - 1];
}

static double sign_sqrt(double x) {
  double s = (x < 0.0) ? -1.0 : 1.0;
  return s * sqrt(fabs(x));
}

static double max0(double v) { return v > 0.0 ? v : 0.0; }

static double clampd(double v, double lo, double hi) {
  return v < lo ? lo : (v > hi ? hi : v);
}

/*
 * Generate the 5-channel conditioning map for a WxH query at global origin
 * (i1, j1). Output is channel-major: out[c*W*H + y*W + x].
 *
 * `seed` is the world seed; upstream derives per-channel seeds as
 * (seed + i + 1) & 0x7FFFFFFF.
 *
 * Returns 1 on success, 0 if the quantile data was not loaded.
 */
int tres_cond_map(int64_t seed, int64_t origin_y, int64_t origin_x,
                  int width, int height, double *out, int64_t out_count) {
  if (!g_cond.ready || out == NULL) return 0;
  const int64_t need = (int64_t)N_CHANNELS * width * height;
  if (out_count < need) return 0;

  /* Raw channels, channel-major. */
  for (int c = 0; c < N_CHANNELS; c++) {
    uint32_t ch_seed = (uint32_t)((seed + (int64_t)c + 1) & 0x7FFFFFFF);

    double *dst = out + (int64_t)c * width * height;
    for (int y = 0; y < height; y++) {
      for (int x = 0; x < width; x++) {
        /* Upstream samples at integer pixel coordinates (0,0),(1,0),... */
        /* Global coordinates: the conditioning must agree for the same world
         * column regardless of which query asks for it. */
        double n = tres_perlin2d(ch_seed, kFrequency[c], kOctaves[c],
                                 (double)(origin_x + x), (double)(origin_y + y));
        dst[(int64_t)y * width + x] =
            interp_clamped(n, g_cond.noise_q[c], g_cond.data_q[c], N_QUANTILES);
      }
    }
  }

  /* finalize_synthetic_map */
  double *elev = out;
  double *temp = out + (int64_t)1 * width * height;
  double *tstd = out + (int64_t)2 * width * height;
  double *prec = out + (int64_t)3 * width * height;
  double *pcv = out + (int64_t)4 * width * height;

  int64_t n = (int64_t)width * height;
  for (int64_t i = 0; i < n; i++) {
    /* lapse_rate = clip((-6.5 + 0.0015*precip)/1000, -9.8, -4.0)/1000 ; note the
     * upstream expression divides by 1000 once after the clip. */
    double lapse = clampd((-6.5 + 0.0015 * prec[i]), -9.8, -4.0) / 1000.0;
    temp[i] = temp[i] + lapse * max0(elev[i]);
    temp[i] = clampd(temp[i], -10.0, 40.0);

    /* sub-20 stretch: affine 1.25x around the 20 pivot */
    if (temp[i] <= 20.0) temp[i] = (temp[i] - 20.0) * 1.25 + 20.0;

    /* seasonality remap against the global baseline */
    double t = (tstd[i] - g_cond.temp_std_p1) / (g_cond.temp_std_p99 - g_cond.temp_std_p1);
    double baseline = -1.0 * (g_cond.a_temp_std * temp[i] + g_cond.b_temp_std);
    double p1 = g_cond.temp_std_p1;
    if (baseline < p1) baseline = p1;
    tstd[i] = t * (g_cond.temp_std_p99 - baseline) + baseline;
    tstd[i] = tstd[i] + (g_cond.a_temp_std * temp[i] + g_cond.b_temp_std);
    if (tstd[i] < 20.0) tstd[i] = 20.0;

    /* precip CV damping */
    pcv[i] = pcv[i] * max0((185.0 - 0.04111 * prec[i]) / 185.0);

    /* elevation is sqrt-compressed LAST */
    elev[i] = sign_sqrt(elev[i]);
  }

  return 1;
}
