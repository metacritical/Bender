# scheduler.janet — DPM-Solver++ multistep scheduler in pure Janet.
#
# WHAT THIS IS
# ------------
# A faithful port of terrain_diffusion/scheduler/dpmsolver.py at the exact
# settings the upstream pipeline uses for the coarse stage:
#
#   sigma_schedule      = "karras"
#   sigma_min           = 0.002
#   sigma_max           = 80.0
#   sigma_data          = 0.5
#   rho                 = 7.0
#   solver_order        = 2
#   prediction_type     = "epsilon"
#   algorithm_type      = "dpmsolver++"
#   final_sigmas_type   = "zero"
#   lower_order_final   = true
#
# All of this is pure arithmetic, so it belongs in Janet rather than in C: no
# 64-bit integer tricks are needed anywhere, and keeping it here means the world
# definition stays readable and testable in the language the game is written in.
#
# VERIFIED AGAINST UPSTREAM, NOT RE-DERIVED
# -----------------------------------------
# The numbers below were captured from the real Python scheduler
# (EDMDPMSolverMultistepScheduler) at float32 precision and are compared exactly
# in test-scheduler.janet. This file does not "claim" correctness; it is checked.
#
# NOTE ON PRECISION: upstream computes sigmas in float32 (`sigmas.to(float32)`).
# The values below are float32-rounded, so the native schedule matches what the
# model was actually conditioned on, not a float64 idealisation of it.

(defn f32
  "Round a double to float32 the way torch's `.to(torch.float32)` does.

   Janet has no float32 type. `ffi/write :float` / `ffi/read :float` round-trip
   through a 4-byte buffer, which is exactly the IEEE binary32 rounding the
   model sees, so this is used to keep the schedule comparable."
  [x]
  (def b (buffer/new-filled 4 0))
  (ffi/write :float x b 0)
  (ffi/read :float b 0))

(def sigma-min 0.002)
(def sigma-max 80.0)
(def sigma-data 0.5)
(def rho 7.0)

#
# --- Sigma schedule -------------------------------------------------------
#

(defn karras-sigmas
  "Karras et al. (2022) noise schedule: 21 values for 20 steps.

   rho-interpolates from sigma_max down to sigma_min in inverse-rho space, then
   appends the final sigma (0.0 for final_sigmas_type='zero')."
  [steps &opt min-s max-s rho-v]
  (default min-s sigma-min)
  (default max-s sigma-max)
  (default rho-v rho)
  (def ramp-len steps)
  (def min-inv (math/pow min-s (/ 1 rho-v)))
  (def max-inv (math/pow max-s (/ 1 rho-v)))
  (def out @[])
  (for i 0 ramp-len
    # Upstream computes this on a float32 tensor: ramp is float32 from
    # torch.linspace, the base is rounded to float32, and the `** rho` result is
    # float32. Rounding only at the end gives values that differ in the 5th
    # significant digit and drift the whole schedule, so each stage is rounded.
    # Every intermediate is rounded to float32, not just the result: upstream
    # runs this on a float32 tensor, so the ramp, the subtraction, the product,
    # the addition and the power all round at binary32. Rounding only the final
    # value leaves errors in the 5th digit that accumulate across the schedule.
    (def ramp (f32 (if (= ramp-len 1) 0.0 (/ i (- ramp-len 1)))))
    (def delta (f32 (- (f32 min-inv) (f32 max-inv))))
    (def base (f32 (+ (f32 max-inv) (f32 (* ramp delta)))))
    (array/push out (f32 (math/pow base (f32 rho-v)))))
  (array/push out 0.0)
  out)

#
# --- Preconditioning ------------------------------------------------------
#

(defn precondition-inputs
  "c_in = 1 / sqrt(sigma^2 + sigma_data^2); scaled = sample * c_in"
  [sigma]
  (/ 1.0 (math/sqrt (+ (* sigma sigma) (* sigma-data sigma-data)))))

(defn precondition-noise
  "precondition_noise: c_noise = 0.25 * log(sigma).
   This is what the scheduler exposes as `.timesteps`, and it is NOT the same as
   the trigflow label fed to the model inside the coarse loop."
  [sigma]
  (* 0.25 (math/log sigma)))

(defn trigflow-noise
  "trigflow_precondition_noise: atan(sigma / sigma_data) -> the model's t label."
  [sigma]
  (math/atan (/ sigma sigma-data)))

(defn precondition-outputs
  "EDM epsilon-prediction output preconditioning.
   c_skip = sd^2 / (s^2 + sd^2), c_out = s*sd / sqrt(s^2 + sd^2)
   denoised = c_skip * sample + c_out * model_output"
  [sample model-output sigma]
  (def s2 (+ (* sigma sigma) (* sigma-data sigma-data)))
  (def c-skip (/ (* sigma-data sigma-data) s2))
  (def c-out (/ (* sigma sigma-data) (math/sqrt s2)))
  (+ (* c-skip sample) (* c-out model-output)))

(defn convert-model-output
  "dpmsolver++ with epsilon prediction: the model predicts noise, so the data
   prediction is precondition_outputs(sample, model_output, sigma)."
  [model-output sample sigma]
  (precondition-outputs sample model-output sigma))

#
# --- Sigma -> alpha/sigma ------------------------------------------------
#

(defn sigma-to-alpha-sigma-t
  "Upstream `_sigma_to_alpha_sigma_t` OVERRIDES the diffusers default:
       alpha_t = 1        (inputs are pre-scaled before entering the UNet)
       sigma_t = sigma
   It is NOT the VP form 1/sqrt(sigma^2+sd^2). Using the VP form here shifts
   every lambda and produces a completely different denoise trajectory."
  [sigma]
  [1.0 sigma])

#
# --- Updates --------------------------------------------------------------
#

(defn first-order-update
  "dpm_solver_first_order_update (equivalent to DDIM), dpmsolver++ branch."
  [sigmas idx sample model-output]
  (def sigma-s (sigmas idx))
  (def sigma-t (sigmas (+ idx 1)))
  (def [alpha-s sigma-s-t] (sigma-to-alpha-sigma-t sigma-s))
  (def [alpha-t sigma-t-t] (sigma-to-alpha-sigma-t sigma-t))
  (def lambda-t (- (math/log alpha-t) (math/log sigma-t-t)))
  (def lambda-s (- (math/log alpha-s) (math/log sigma-s-t)))
  (def h (- lambda-t lambda-s))
  # dpmsolver++ branch:
  #   x_t = (sigma_t / sigma_s) * sample - (alpha_t * (exp(-h) - 1)) * model_output
  (def x-t (* (/ sigma-t-t sigma-s-t) sample))
  (def coeff (- 0 (* alpha-t (- (math/exp (- 0 h)) 1.0))))
  (+ x-t (* coeff model-output)))

(defn second-order-update
  "multistep_dpm_solver_second_order_update, dpmsolver++, solver_type=midpoint."
  [sigmas idx sample model-outputs]
  # Upstream: m0, m1 = model_output_list[-1], model_output_list[-2]
  # i.e. m0 is the MOST RECENT output, m1 the one before it. The list is ordered
  # oldest-first here, so indexing forward silently inverts the derivative term.
  (def m0 (model-outputs (- (length model-outputs) 1)))
  (def m1 (model-outputs (- (length model-outputs) 2)))
  (def sigma-n (sigmas idx))
  (def sigma-n1 (sigmas (- idx 1)))
  (def sigma-n2 (sigmas (+ idx 1)))
  (def [alpha-n sigma-n-t] (sigma-to-alpha-sigma-t sigma-n))
  (def [alpha-n1 _] (sigma-to-alpha-sigma-t sigma-n1))
  (def [alpha-n2 sigma-n2-t] (sigma-to-alpha-sigma-t sigma-n2))
  (def lambda-n (- (math/log alpha-n) (math/log sigma-n-t)))
  (def lambda-n1 (- (math/log alpha-n1) (math/log sigma-n1)))
  (def lambda-n2 (- (math/log alpha-n2) (math/log sigma-n2-t)))
  (def h (- lambda-n2 lambda-n))
  (def h0 (- lambda-n lambda-n1))
  (def r0 (/ h0 h))
  (def x-t (* (/ sigma-n2-t sigma-n) sample))
  (def d0 m0)
  (def d1 (/ (- m0 m1) r0))
  # x_t = (sigma_t/sigma_s0)*sample
  #       - (alpha_t*(exp(-h)-1))*D0
  #       - 0.5*(alpha_t*(exp(-h)-1))*D1
  (def coeff0 (- 0 (* alpha-n2 (- (math/exp (- 0 h)) 1.0))))
  (def coeff1 0.5)
  (+ x-t (* coeff0 d0) (* (* coeff1 coeff0) d1)))

#
# --- Scheduler state ------------------------------------------------------
#

(defn make-scheduler
  "Build scheduler state for `steps` inference steps."
  [steps]
  @{:steps steps
    :sigmas (karras-sigmas steps)
    :model-outputs @[]   # ring of the last two model outputs
    :lower-order-nums 0
    :index 0})

(defn current-sigma [sch] ((sch :sigmas) (sch :index)))

(defn done? [sch] (>= (sch :index) (sch :steps)))

(defn step
  "Advance one scheduler step. `model-output` is the raw model prediction.

   Mirrors upstream's branch selection: order 1 while fewer than two model
   outputs are available, or on the final step when lower_order_final is set
   and the schedule has fewer than 15 steps."
  [sch sample model-output]
  (def idx (sch :index))
  (def steps (sch :steps))
  (def sigmas (sch :sigmas))
  (def sigma (sigmas idx))

  # dpmsolver++ (non-SDE): no noise injection.
  (def converted (convert-model-output model-output sample sigma))

  (array/push (sch :model-outputs) converted)
  (while (> (length (sch :model-outputs)) 2)
    (array/remove (sch :model-outputs) 0))

  # The schedule ends at sigma 0 (final_sigmas_type="zero"). A second-order
  # update divides by the next sigma, so it must never run on the final step --
  # upstream reaches the same conclusion through `lower_order_final`, but that
  # flag alone only fires for schedules shorter than 15 steps. Guard on the
  # actual sigma value so a full 20-step run cannot divide by zero.
  (def next-sigma (sigmas (+ idx 1)))
  (def terminal-zero (<= next-sigma 1e-12))
  (def lower-order-final (or terminal-zero (and (= idx (- steps 1)) (< steps 15))))

  (def prev
    (if (or (= steps 1) (< (sch :lower-order-nums) 1) lower-order-final)
      (first-order-update sigmas idx sample converted)
      (second-order-update sigmas idx sample (sch :model-outputs))))

  (when (< (sch :lower-order-nums) 2)
    (put sch :lower-order-nums (+ (sch :lower-order-nums) 1)))
  (put sch :index (+ idx 1))
  prev)

#
# --- Tensor-aware stepping ------------------------------------------------
#
# `step` operates on one scalar and advances the scheduler. A denoiser produces
# thousands of values per step but the SCHEDULE advances once, so calling `step`
# per element would run the whole schedule thousands of times. `step-tensor`
# computes the per-element update under the current step index and advances the
# state exactly once.
#

(defn step-tensor
  "Step the scheduler once over a whole tensor.

   `sample` and `model-output` are flat arrays of equal length. Returns a new
   array; the scheduler state advances exactly once."
  [sch sample model-output]
  (def n (length sample))
  (def idx (sch :index))
  (def steps (sch :steps))
  (def sigmas (sch :sigmas))
  (def sigma (sigmas idx))

  # Convert the model output to data-prediction, elementwise.
  (def converted (array/new-filled n 0.0))
  (for i 0 n
    (put converted i (convert-model-output (model-output i) (sample i) sigma)))

  (array/push (sch :model-outputs) converted)
  (while (> (length (sch :model-outputs)) 2)
    (array/remove (sch :model-outputs) 0))

  # The schedule ends at sigma 0 (final_sigmas_type="zero"). A second-order
  # update divides by the next sigma, so it must never run on the final step --
  # upstream reaches the same conclusion through `lower_order_final`, but that
  # flag alone only fires for schedules shorter than 15 steps. Guard on the
  # actual sigma value so a full 20-step run cannot divide by zero.
  (def next-sigma (sigmas (+ idx 1)))
  (def terminal-zero (<= next-sigma 1e-12))
  (def lower-order-final (or terminal-zero (and (= idx (- steps 1)) (< steps 15))))
  (def use-first (or (= steps 1) (< (sch :lower-order-nums) 1) lower-order-final))

  (def out (array/new-filled n 0.0))
  (if use-first
    (do
      (for i 0 n (put out i (first-order-update sigmas idx (sample i) (converted i)))))
    (do
      (def mo (sch :model-outputs))
      (for i 0 n
        (put out i (second-order-update sigmas idx (sample i) [((mo 0) i) ((mo 1) i)])))))

  (when (< (sch :lower-order-nums) 2)
    (put sch :lower-order-nums (+ (sch :lower-order-nums) 1)))
  (put sch :index (+ idx 1))
  out)
