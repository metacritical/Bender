# laplacian.janet — laplacian decode/denoise for the native height pipeline.
#
# Port of terrain_diffusion/data/laplacian_encoder.py, restricted to the path the
# height computation actually uses. Three operations matter:
#
#   laplacian_decode(residual, lowres)  -> residual + upsample(lowres)
#   laplacian_denoise(residual, lowres) -> residual, new_lowres  (re-encode)
#   final elevation                     -> sign(x) * x^2
#
# The pipeline's elevation step is:
#
#   residual_p = (residual[0] / residual[1]) * RESIDUAL_STD + RESIDUAL_MEAN
#   lowfreq_p  = latents_norm[4] * LOWFREQ_STD + LOWFREQ_MEAN
#   residual_p, lowfreq_p = laplacian_denoise(residual_p, lowfreq_p, sigma=5)
#   elev_sqrt  = laplacian_decode(residual_p, lowfreq_p)
#   elev       = sign(elev_sqrt) * elev_sqrt^2
#
# BILINEAR UPSAMPLING
# -------------------
# torchvision's `TF.resize(..., interpolation=BILINEAR)` uses
# align_corners=False by default, which is the half-pixel-centre convention:
#
#   src = (dst + 0.5) * (src_size / dst_size) - 0.5
#
# with edge clamping. This file implements exactly that. Getting the convention
# wrong shifts every low-frequency feature by half a pixel, which is visible as
# a systematic offset in the final heights.
#
# IMPORTANT SCOPE NOTE
# --------------------
# `laplacian_denoise` re-encodes the decoded signal with a Gaussian blur at
# sigma=5. The blur is the one piece that is NOT bit-portable from torchvision
# by inspection: torchvision's gaussian_blur uses a reflect-padded separable
# kernel whose truncation differs subtly between versions. This implementation
# uses the same kernel construction (radius = int(sigma*2)//2*2+1, reflect pad)
# and is checked against upstream on a fixed input in test-laplacian.janet.
# Where it cannot match exactly, that is reported rather than hidden.

#
# --- Bilinear resize (align_corners = false) ------------------------------
#

(defn- lerp [a b t] (+ a (* t (- b a))))

(defn- clamp-idx [i n]
  (cond (< i 0) 0 (> i (- n 1)) (- n 1) i))

(defn resize-bilinear-2d
  "Bilinear resize of a rows x cols flat array (row-major) to out-rows x out-cols.
   Matches torchvision bilinear with align_corners=False and edge clamping."
  [src rows cols out-rows out-cols]
  (def out (array/new-filled (* out-rows out-cols) 0.0))
  (def sy (/ rows out-rows))
  (def sx (/ cols out-cols))
  (for oy 0 out-rows
    (def fy (- (* (+ oy 0.5) sy) 0.5))
    (def y0 (math/floor fy))
    (def wy (- fy y0))
    (def iy0 (clamp-idx y0 rows))
    (def iy1 (clamp-idx (+ y0 1) rows))
    (for ox 0 out-cols
      (def fx (- (* (+ ox 0.5) sx) 0.5))
      (def x0 (math/floor fx))
      (def wx (- fx x0))
      (def ix0 (clamp-idx x0 cols))
      (def ix1 (clamp-idx (+ x0 1) cols))
      (def v00 (src (+ (* iy0 cols) ix0)))
      (def v01 (src (+ (* iy0 cols) ix1)))
      (def v10 (src (+ (* iy1 cols) ix0)))
      (def v11 (src (+ (* iy1 cols) ix1)))
      (put out (+ (* oy out-cols) ox)
           (lerp (lerp v00 v01 wx) (lerp v10 v11 wx) wy))))
  out)

#
# --- Antialias bilinear downsample ----------------------------------------
#

(defn- aa-taps
  "One output sample's [index weight] taps for an antialias triangle filter.

   torchvision's antialias path scales the filter's SUPPORT by the sampling
   ratio, but ONLY when DOWNSAMPLING: ATen uses `radius = max(1, scale)`. A
   source index j contributes `max(0, 1 - |j - centre| / radius)` where the
   centre is `(i + 0.5) * scale - 0.5`. Out-of-range taps are DROPPED, not
   clamped, and the remaining weights are renormalised -- that is why a corner
   impulse reads 0.083795 rather than 1/9.

   The `max(1, ...)` matters for a MIXED resize, where one axis shrinks and the
   other grows (rows 8 -> 3, cols 4 -> 8). With radius = scale the growing axis
   would get radius 0.5, so `1 - |d|/0.5 <= 0` for every neighbour and the axis
   collapses to a single zero tap -- a perfectly good bilinear upsample wiped
   out. max(1, scale) keeps the plain triangle there.

   Returns [taps, weight-sum]; the caller divides, so a sample whose taps all
   fall outside the source yields 0 rather than a division by zero."
  [n out-n i]
  (def scale (/ n out-n))
  # ATen: support scales only when shrinking; growing axes keep radius 1.
  (def radius (max 1.0 scale))
  (def centre (- (* (+ i 0.5) scale) 0.5))
  (def lo (math/floor (- centre radius)))
  (def hi (math/ceil (+ centre radius)))
  (def taps @[])
  (var total 0.0)
  (var j lo)
  (while (<= j hi)
    (when (and (>= j 0) (< j n))
      (def w (max 0.0 (- 1.0 (/ (math/abs (- j centre)) radius))))
      (when (> w 0.0)
        (array/push taps @[j w])
        (set total (+ total w))))
    (++ j))
  [taps total])

(defn resize-bilinear-antialias-2d
  "torchvision `resize(..., BILINEAR, antialias=True)`, separable.

   Used for DOWNSAMPLING only: the support scaling is what suppresses aliasing,
   and it is a no-op in spirit when out >= in but the filter still differs from
   the plain bilinear above. Callers that need the bit-identical upsample path
   must keep using `resize-bilinear-2d`, which is unchanged.

   Verified against six real torchvision captures (fixtures/resize-aa.janet):
   off-centre impulses, a corner impulse that exercises edge renormalisation,
   and two phased checkerboards whose OPPOSITE corner biases a phase-blind filter
   cannot reproduce."
  [src rows cols out-rows out-cols]
  # DOWN-SAMPLING ONLY. The support scaling is what suppresses aliasing, and the
  # filter is only validated against torchvision on shrinking axes. Callers that
  # need to grow an axis must use resize-bilinear-2d, whose plain clamp-tap path
  # is the recorded behaviour for upsample. Failing loudly here is deliberate:
  # a mixed call would silently produce plausible-but-unvalidated numbers, and
  # for an up-axis with radius = scale the interior collapses entirely.
  (when (or (> out-rows rows) (> out-cols cols))
    (error (string "resize-bilinear-antialias-2d is for downsampling only: "
                   rows "x" cols " -> " out-rows "x" out-cols
                   "; use resize-bilinear-2d to grow an axis")))
  # Rows first: one horizontal pass produces an out-cols-wide intermediate with
  # the original row count, then a vertical pass reduces that to out-rows.
  (def mid (array/new-filled (* rows out-cols) 0.0))
  (for y 0 rows
    (for ox 0 out-cols
      (def [taps total] (aa-taps cols out-cols ox))
      (var acc 0.0)
      (each t taps
        (set acc (+ acc (* (src (+ (* y cols) (t 0))) (t 1)))))
      (put mid (+ (* y out-cols) ox) (if (> total 0.0) (/ acc total) 0.0))))
  (def out (array/new-filled (* out-rows out-cols) 0.0))
  (for oy 0 out-rows
    (def [taps total] (aa-taps rows out-rows oy))
    (for ox 0 out-cols
      (var acc 0.0)
      (each t taps
        (set acc (+ acc (* (mid (+ (* (t 0) out-cols) ox)) (t 1)))))
      (put out (+ (* oy out-cols) ox) (if (> total 0.0) (/ acc total) 0.0))))
  out)

#
# --- Linear-extrapolation padding and extrapolated resize -----------------
#

(defn pad-linear-extrapolation
  "`pad_linear_extrapolation` (laplacian_encoder.py:6-37): one sample ring whose
   value CONTINUES the edge gradient, so a resample sees a straight line rather
   than a clamp.

       top  = 2*first - second        bottom = 2*last - second_last
       left = 2*first - second        right  = 2*last - second_last   (per row)

   A dimension of size 1 cannot form a gradient, so it is duplicated instead
   (`:19-21`, `:34-36`). Returns [padded, padded-rows, padded-cols]."
  [src rows cols]
  (defn edge2 [a b] (- (* 2 a) b))
  (def pr (+ rows 2))
  (def pc (+ cols 2))
  (def out (array/new-filled (* pr pc) 0.0))
  # 1. Every source sample lands at (+1,+1) in the padded grid.
  (for y 0 rows
    (for x 0 cols
      (put out (+ (* (+ y 1) pc) (+ x 1)) (src (+ (* y cols) x)))))
  # 2. Row ring, using the source columns, then fixing the two corner columns
  #    from the values already written (so a 1-wide source behaves too).
  (for x 0 cols
    (def col (+ x 1))
    (put out col
         (if (> rows 1)
           (edge2 (src x) (src (+ cols x)))
           (src x)))
    (def bot (+ (* (- pr 1) pc) col))
    (put out bot
         (if (> rows 1)
           (edge2 (src (+ (* (- rows 1) cols) x))
                  (src (+ (* (- rows 2) cols) x)))
           (src (+ (* (- rows 1) cols) x)))))
  # 3. Column ring over EVERY padded row, including the two just added.
  (for y 0 pr
    (def base (* y pc))
    (put out base
         (if (> cols 1)
           (edge2 (get out (+ base 1)) (get out (+ base 2)))
           (get out (+ base 1))))
    (def lastc (+ base (- pc 1)))
    (put out lastc
         (if (> cols 1)
           (edge2 (get out (+ base (- pc 2))) (get out (+ base (- pc 3))))
           (get out (+ base (- pc 2))))))
  [out pr pc])

(defn round-even
  "Python 3's `round()` for a non-negative float: round half to EVEN.

   `resize_extrapolated` (laplacian_encoder.py:53-59) uses bare `round()`, which
   is ties-to-even, NOT ties-up. `math/floor(x + 0.5)` differs exactly when the
   fraction is .5 and the integer part is even-of-odd:

       round(2.5) = 2   floor(2.5+0.5) = 3    <- differs
       round(0.5) = 0   floor(0.5+0.5) = 1    <- differs
       round(1.5) = 2   floor(1.5+0.5) = 2    <- same

   Production resampling is 64 -> 512 (ratio 8, an exact integer) so this never
   fires there; it matters for the public helper at any ratio whose
   `target + 2*scale` lands on a .5. Reproducing the quirk is the point: a
   smoother-looking result would not be upstream's.

   Negative inputs are not part of this code path and are rejected rather than
   silently given C-style behaviour."
  [x]
  (when (< x 0)
    (error (string "round-even expects a non-negative value, got " x)))
  (def fl (math/floor x))
  (def frac (- x fl))
  (if (< frac 0.5)
    fl
    (if (> frac 0.5)
      (+ fl 1)
      # exact tie: choose the even neighbour
      (if (zero? (% fl 2)) fl (+ fl 1)))))

(defn resize-extrapolated-2d
  "`resize_extrapolated` (laplacian_encoder.py:41-61).

   Pads one linear-extrapolation ring, resizes to
   `round(target + 2*scale)` where `scale = target/source`, then crops back by
   `round(scale)`. The result CONTINUES the boundary gradient instead of clamping
   to the edge sample -- at source 4 -> target 8 a ramp 0,1,2,3 becomes
   -0.25, 0.25, ... , 3.25 rather than 0.0, ... , 3.0.

   `int(round(target + 2*scale))` and `int(round(scale))` use Python 3's
   ties-to-EVEN rule, reproduced by `round-even` rather than `floor(x+0.5)`. The
   two differ at an exact .5 with an even integer part (round(2.5)=2 vs 3), which
   changes both the padded size and the crop offset. Production 64 -> 512 has
   ratio 8 and never hits the tie; the public helper can, and the test pins it."
  [src rows cols out-rows out-cols]
  (def [padded pr pc] (pad-linear-extrapolation src rows cols))
  (def scale-h (/ out-rows rows))
  (def scale-w (/ out-cols cols))
  (def new-h (round-even (+ out-rows (* 2 scale-h))))
  (def new-w (round-even (+ out-cols (* 2 scale-w))))
  (def pad-h (round-even scale-h))
  (def pad-w (round-even scale-w))
  (def up (resize-bilinear-2d padded pr pc new-h new-w))
  (def out (array/new-filled (* out-rows out-cols) 0.0))
  (for y 0 out-rows
    (def sy (+ y pad-h))
    (for x 0 out-cols
      (put out (+ (* y out-cols) x) (up (+ (* sy new-w) (+ x pad-w))))))
  out)

#
# --- Separable Gaussian blur (reflect padding) ----------------------------
#

(defn- gaussian-kernel
  "Torchvision's gaussian_blur kernel for `sigma`, normalised and SYMMETRIC.

   Upstream calls TF.gaussian_blur with `kernel_size=int(sigma*2)//2*2 + 1`; torch
   builds a kernel of exactly that SIZE, centred on the middle index. For positive
   sigma that is r = floor(sigma) and ksize = 2r+1:

       sigma 1 -> ksize 3,  r 1, indices [-1, 0, 1]
       sigma 5 -> ksize 11, r 5, indices [-5 .. 5]

   Returns [weights, r] where weights[i] applies at offset i-r."
  [sigma]
  (when (<= sigma 0)
    (error "gaussian-kernel needs a positive sigma; upstream's sigma map is"))
  # int(sigma*2)//2*2 + 1, Python's left-to-right precedence: halve, double, add 1.
  (def ksize (+ (* (math/floor (/ (math/floor (* sigma 2)) 2)) 2) 1))
  (def r (math/floor (/ ksize 2)))
  (def ks (array/new-filled ksize 0))
  (var total 0.0)
  (for i 0 ksize
    (def idx (- i r))
    (def v (math/exp (- 0 (/ (* idx idx) (* 2 sigma sigma)))))
    (put ks i v)
    (set total (+ total v)))
  (for i 0 ksize (put ks i (/ (ks i) total)))
  [ks r])

(defn- reflect-idx [i n]
  "torchvision uses padding_mode='reflect' for gaussian_blur.

   Reflection folds about the EDGE sample, so the sequence is periodic with period
   2*(n-1): -1 -> 1 and n -> n-2, and the edge value is never repeated. n = 1 has
   no neighbour to fold onto, so every index maps to 0.

   This is computed in closed form rather than by iterating: the earlier version
   looped, and its negative branch (`(- (* -2 n) v 2)`) grew MORE negative, so it
   never terminated. Every sigma >= 1 reaching index 0 hung -- including the
   sigma 5 the generator passes."
  (when (<= n 0)
    (error (string "reflect-idx needs a positive length, got " n)))
  (if (= n 1)
    0
    (do
      (def period (* 2 (- n 1)))
      # Janet's % takes the sign of the dividend, so normalise into [0, period).
      (def m (mod (+ (mod i period) period) period))
      (if (< m n) m (- period m)))))

(defn gaussian-blur-2d
  "Separable Gaussian blur of a rows x cols flat array with reflect padding."
  [src rows cols sigma]
  (def [ks r] (gaussian-kernel sigma))
  (def ksize (length ks))
  (def tmp (array/new-filled (* rows cols) 0.0))

  # horizontal pass
  (for y 0 rows
    (for x 0 cols
      (var acc 0.0)
      (for k 0 ksize
        (def sx (reflect-idx (+ (- x r) k) cols))
        (set acc (+ acc (* (ks k) (src (+ (* y cols) sx))))))
      (put tmp (+ (* y cols) x) acc)))

  (def out (array/new-filled (* rows cols) 0.0))
  # vertical pass
  (for y 0 rows
    (for x 0 cols
      (var acc 0.0)
      (for k 0 ksize
        (def sy (reflect-idx (+ (- y r) k) rows))
        (set acc (+ acc (* (ks k) (tmp (+ (* sy cols) x))))))
      (put out (+ (* y cols) x) acc)))
  out)

#
# --- Laplacian codec ------------------------------------------------------
#

(defn laplacian-decode
  "residual + upsample(lowres) to the residual's shape.

   `extrapolate?` selects `resize_extrapolated` over a plain clamp resize, matching
   `laplacian_decode(..., extrapolate=)` (laplacian_encoder.py:93-126). It defaults
   to FALSE so the existing 6-arity call -- and every golden that used it -- keeps
   the plain decode unchanged."
  [residual rows cols lowres lr lc &opt extrapolate?]
  (default extrapolate? false)
  (def up (if extrapolate?
            (resize-extrapolated-2d lowres lr lc rows cols)
            (resize-bilinear-2d lowres lr lc rows cols)))
  (def out (array/new-filled (* rows cols) 0.0))
  (for i 0 (* rows cols)
    (put out i (+ (residual i) (up i))))
  out)

(defn laplacian-encode
  "Returns [residual, lowres]: lowres is the downsampled+blurred signal,
   residual is what decode would have needed.

   ORDER MATTERS and upstream fixes it: `laplacian_encode`
   (terrain_diffusion/data/laplacian_encoder.py:74-75) resizes DOWN to the target
   grid FIRST and blurs at that resolution:

       lowres = TF.resize(x, downsample_size)
       lowres = TF.gaussian_blur(lowres, ksize, sigma)

   Blurring at full resolution and then downsampling is a DIFFERENT operator: a
   downsample of a blur computed on the full grid is not the same filter as a
   blur whose sigma applies to the target grid. The low-frequency band -- and
   therefore everything `laplacian_denoise` re-encodes -- depends on this order."
  [signal rows cols target low-sigma]
  # Upstream calls TF.resize, whose antialias defaults to True. That is what the
  # AA captures show: at 8 -> 4 sigma 1 the real lowres starts 1.904740, while a
  # plain tap gives 1.795809. Route the DOWNsample through the AA filter; the
  # upsample back to the source grid is unaffected either way, because
  # torchvision does not antialias when growing (captured max |aa - noaa| = 0).
  (def shrinking (or (> rows target) (> cols target)))
  (def down (if shrinking
              (resize-bilinear-antialias-2d signal rows cols target target)
              (resize-bilinear-2d signal rows cols target target)))
  (def lowres (gaussian-blur-2d down target target low-sigma))
  (def up (resize-bilinear-2d lowres target target rows cols))
  (def residual (array/new-filled (* rows cols) 0.0))
  (for i 0 (* rows cols)
    (put residual i (- (signal i) (up i))))
  [residual lowres])

(defn laplacian-denoise
  "laplacian_denoise: decode, then re-encode to snap the low-frequency band.

   Upstream `laplacian_denoise` (laplacian_encoder.py:134-136) calls
   `laplacian_decode(residual, lowres, interp_mode, extrapolate=True)` -- the
   extrapolated decode is HARD-WIRED there, while the public `laplacian_decode`
   defaults to False. That asymmetry is real and is reproduced here: denoise
   always extrapolates, plain decode does not unless asked."
  [residual rows cols lowres lr lc sigma]
  (def decoded (laplacian-decode residual rows cols lowres lr lc true))
  (def [_ new-lowres] (laplacian-encode decoded rows cols lc sigma))
  [residual new-lowres])

#
# --- Elevation ------------------------------------------------------------
#

(defn elevation-from-laplacian
  "Final elevation: sign(x) * x^2, where x is the decoded laplacian signal.
   Upstream computes this after denoise + decode."
  [residual rows cols lowres lr lc sigma &opt lowfreq-mean lowfreq-std residual-mean residual-std]
  (default lowfreq-mean -31.4)
  (default lowfreq-std 38.6)
  (default residual-mean 0.0)
  (default residual-std 1.1678)
  (def decoded (laplacian-decode residual rows cols lowres lr lc))
  (def out (array/new-filled (* rows cols) 0.0))
  (for i 0 (* rows cols)
    (def v (decoded i))
    (put out i (* (if (< v 0) -1.0 1.0) v v)))
  out)
