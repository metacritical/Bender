# generate-query.janet — run the assembler and compare against real upstream.
#
# This is the bounded end-to-end proof: assemble one 64x64 elevation query
# through every window the geometry planner requires, then measure the result
# against the real `WorldPipeline.get` output for the same query.
#
# Nothing here reads oracle data as INPUT. The oracle is only compared against,
# never consumed, so a match is evidence and a mismatch is a real mismatch.
#
# Usage:
#   <bender> native/proof/generate-query.janet [--origin N] [--seed N] [--steps N]

(import ./assembler :as asm)
(import ./laplacian :as lap)
(import ./pipeline :as pl)

(def here
  (let [parts (string/split "/" (os/realpath (dyn :current-file)))]
    (string/join (slice parts 0 (- (length parts) 1)) "/")))

(def tmp-root (string here "/../../tmp/native-terrain-proof"))

(defn fail [fmt & args]
  (eprint "QUERY FAILED: " (string/format fmt ;args))
  (os/exit 1))

(def opts @{:origin 100000 :seed 12345 :steps 20})
(def argv (dyn :args @[]))
(var k 0)
(while (< k (length argv))
  (def a (argv k))
  (def nx (if (< (+ k 1) (length argv)) (argv (+ k 1)) nil))
  (cond
    (= a "--origin") (do (put opts :origin (math/floor (scan-number nx))) (set k (+ k 2)))
    (= a "--seed")   (do (put opts :seed (math/floor (scan-number nx))) (set k (+ k 2)))
    (= a "--steps")  (do (put opts :steps (math/floor (scan-number nx))) (set k (+ k 2)))
    (set k (+ k 1))))

(def origin (opts :origin))
(def seed (opts :seed))
(def steps (opts :steps))
(def size 64)

(print "=== native query assembly ===")
(print (string/format "origin %d seed %d %d steps %dx%d" origin seed steps size size))
(def t0 (os/clock))

(def result (asm/assemble @{:origin origin :seed seed :steps steps :size size}))
(def resu (result :residual))

(print (string/format "  assembled residual in %.1fs" (- (os/clock) t0)))

# --- laplacian decode to metres ------------------------------------------
#
(def lowf (result :lowfreq))
(def low-n (result :low-size))
(print (string/format "  low-frequency field: %dx%d" low-n low-n))
(do (var mn 1e30) (var mx -1e30) (var sum 0.0)
    (each v lowf (set sum (+ sum v)) (when (< v mn) (set mn v)) (when (> v mx) (set mx v)))
    (print (string/format "  lowfreq raw: min %.4f max %.4f mean %.4f (want ~-0.1..0.1)"
                          mn mx (/ sum (length lowf)))))

# residual_p = residual * RESIDUAL_STD + RESIDUAL_MEAN
# lowfreq_p  = latents_norm[4] * LOWFREQ_STD + LOWFREQ_MEAN
# Upstream: residual_p = (residual_init[0]/residual_init[1]) * RESIDUAL_STD + MEAN
# The assembler already divided by the accumulated weight, which IS
# residual_init[1], so resu is the normalised residual.
(def residual-p (pl/emap1 |(+ (* $ pl/RESIDUAL-STD) pl/RESIDUAL-MEAN) resu))
(def lowfreq-p (pl/emap1 |(+ (* $ pl/LOWFREQ-STD) pl/LOWFREQ-MEAN) lowf))

# Upstream (world_pipeline.py:1399-1404):
#   residual_p, lowfreq_p = laplacian_denoise(residual_p, lowfreq_p, sigma=5)
#   elev_p = laplacian_decode(residual_p, lowfreq_p)
#   elev   = sign(elev_p) * elev_p^2
# The denoise step is load-bearing: without it the residual contributes nothing
# and the elevation is determined purely by the low-frequency band.
(def den (lap/laplacian-denoise residual-p size size lowfreq-p low-n low-n 5))
(def residual-d (get den 0))
(def lowfreq-d (get den 1))
(print (string/format "  denoise: residual unchanged, lowfreq %dx%d" (length lowfreq-d) (length lowfreq-d)))

(def elev (lap/elevation-from-laplacian residual-d size size lowfreq-d low-n low-n 5
                                         pl/LOWFREQ-MEAN pl/LOWFREQ-STD
                                         pl/RESIDUAL-MEAN pl/RESIDUAL-STD))

(var finite 0) (var nonfinite 0)
(var mn 1e30) (var mx -1e30) (var sum 0.0)
(each v elev
  (if (or (not= v v) (> v 1e29) (< v -1e29))
    (++ nonfinite)
    (do (++ finite) (set sum (+ sum v))
        (when (< v mn) (set mn v))
        (when (> v mx) (set mx v)))))

(print (string/format "  elevation: n=%d finite=%d min=%.2f max=%.2f mean=%.2f"
                      (length elev) finite mn mx (/ sum (max finite 1))))

(when (> nonfinite 0) (fail "%d non-finite elevations" nonfinite))

# --- compare against the real upstream output ----------------------------
(def oracle (string here "/fixtures/oracle/elevation_m.f32"))
(if (nil? (os/stat oracle :mode))
  (print "  (no oracle file; skipping comparison)")
  (do
    (def want (file/read (file/open oracle :rb) :all))
    (def nwant (math/floor (/ (length want) 4)))
    (def got-n (length elev))
    (print (string/format "  oracle: %d values, native: %d" nwant got-n))
    (when (= nwant got-n)
      (var max-abs 0.0) (var ss 0.0) (var sum-abs 0.0)
      (var wmin 1e30) (var wmax -1e30) (var wsum 0.0)
      (for i 0 got-n
        (def w (ffi/read :float want (* i 4)))
        (set wsum (+ wsum w))
        (when (< w wmin) (set wmin w))
        (when (> w wmax) (set wmax w))
        (def d (- (elev i) w))
        (set sum-abs (+ sum-abs (math/abs d)))
        (set ss (+ ss (* d d)))
        (when (> (math/abs d) max-abs) (set max-abs (math/abs d))))
      (def rmse (math/sqrt (/ ss got-n)))
      (def wmean (/ wsum got-n))
      (def relief (- wmax wmin))
      (print "")
      (print "=== comparison vs real WorldPipeline.get ===")
      (print (string/format "  upstream     min %.2f max %.2f mean %.2f  relief %.2f m"
                            wmin wmax wmean relief))
      (print (string/format "  native       min %.2f max %.2f mean %.2f"
                            mn mx (/ sum (max finite 1))))
      (print (string/format "  RMSE         %.2f m" rmse))
      (print (string/format "  max |diff|   %.2f m" max-abs))
      (print (string/format "  mean |diff|  %.2f m" (/ sum-abs got-n)))
      (print (string/format "  relative     %.4f  (RMSE / upstream relief)"
                            (/ rmse (max relief 1e-9)))))))

(print (string/format "  total %.1fs" (- (os/clock) t0)))
