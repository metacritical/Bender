# generate-height-tile.janet — coarse -> base -> decoder -> laplacian -> METRES.
#
# This is the full four-stage pipeline. Unlike generate-coarse-latents.janet,
# the output here is elevation in METRES, produced by the real trained models.
#
#   coarse 20-step denoise  -> normalised coarse latents (6ch)
#   base one-step (T_INTER)  -> latent field (5ch)
#   decoder one-step         -> residual (1ch)
#   laplacian decode         -> sign(x)*x^2 -> METRES
#
# WHAT IS REAL
#   - all three pinned ONNX graphs and their weights
#   - EDM preconditioning, consistency-model stepping, CoarseMeans/Stds
#     denormalisation, channel-1 differencing
#   - latent-compression nearest upsample (factor 8)
#   - laplacian decode with LOWFREQ_MEAN/STD and residual mean/std for the 30m
#     checkpoint
#   - deterministic PCG64 noise (bit-identical to upstream)
#
# WHAT IS NOW REAL
#   - the 5-channel Perlin/WorldClim conditioning map itself, reproduced
#     natively (FastNoiseLite in C++ + quantile match + lapse-rate finalize)
#     and verified against upstream to 1e-4 in test-conditioning.janet
#
# WHAT IS STILL APPROXIMATE
#   - the 5 scalar coarse conditioning inputs and the 58-wide base vector are
#     derived from the coarse map with documented constants rather than
#     upstream's exact standardisation path
#   - no tiling: one 64x64 tile, no overlapping windows or blend weights
# So this is genuine metric elevation on real conditioning, but not yet
# byte-equivalent to an upstream bake, and no identity claims otherwise.
#
# Usage:
#   <bender> native/proof/generate-height-tile.janet [--size N] [--steps N] [--seed N] [--out PATH]

(import ./scheduler :as sc)
(import ./laplacian :as lap)
(import ./pipeline :as pl)

(def here
  (let [parts (string/split "/" (os/realpath (dyn :current-file)))]
    (string/join (slice parts 0 (- (length parts) 1)) "/")))

(def tmp-root (string here "/../../tmp/native-terrain-proof"))

(defn fail [fmt & args]
  (eprint "GENERATE FAILED: " (string/format fmt ;args))
  (os/exit 1))

#
# --- FFI ------------------------------------------------------------------
#

(ffi/context (string here "/libtres.dylib"))

(ffi/defbind-alias tres_version     tres-version     :string [])
(ffi/defbind-alias tres_last_error  tres-last-error  :string [])
(ffi/defbind-alias tres_open        tres-open        :ptr    [p :string])
(ffi/defbind-alias tres_close       tres-close       :void   [rt :ptr])
(ffi/defbind-alias tres_fill_normal tres-fill-normal :int    [seed :long out :ptr n :int])
(ffi/defbind-alias tres_noise_patch  tres-noise-patch :int
  [seed :long y0 :long x0 :long h :int w :int ch :int out :ptr n :int])
(ffi/defbind-alias tres_cond_load   tres-cond-load   :int  [buf :ptr n :long])
(ffi/defbind-alias tres_cond_map    tres-cond-map    :int  [seed :long oy :long ox :long w :int h :int out :ptr n :long])
(ffi/defbind-alias tres_run_all     tres-run-all     :int
  [rt :ptr n :int ptrs :ptr dims :ptr ranks :ptr nbytes :ptr
   out :ptr out_cap :int written :ptr out_dims :ptr out_dims_cap :int out_rank :ptr])

#
# --- Helpers --------------------------------------------------------------
#

(defn f32-of [x]
  (def b (buffer/new-filled 4 0))
  (ffi/write :float x b 0)
  (ffi/read :float b 0))

(defn coord-noise
  "Coordinate-seeded Gaussian patch, port of upstream gaussian_noise_patch.
   Unlike a linear stream this depends on GLOBAL position, which is what makes
   two different requests for the same columns agree."
  [seed y0 x0 h w ch]
  (def buf (buffer/new-filled (* h w ch 8) 0))
  (def rc (tres-noise-patch seed y0 x0 h w ch buf (* h w ch)))
  (when (< rc 0)
    (fail "tres_noise_patch failed: seed=%v y0=%v x0=%v h=%v w=%v ch=%v n=%v"
          seed y0 x0 h w ch (* h w)))
  (def out (array/new-filled (* h w ch) 0.0))
  (for i 0 (* h w ch) (put out i (ffi/read :double buf (* i 8))))
  out)

(defn seeded-noise [seed n]
  (def d (buffer/new-filled (* n 8) 0))
  (when (< (tres-fill-normal seed d n) 0) (fail "tres_fill_normal failed"))
  (def out (array/new-filled n 0.0))
  (for i 0 n (put out i (f32-of (ffi/read :double d (* i 8)))))
  out)

(defn run-graph [label rt inputs out-count]
  (def n (length inputs))
  (def ptrs (buffer/new-filled 64 0))
  (def dims (buffer/new-filled 64 0))
  (def ranks (buffer/new-filled 32 0))
  (def nbytes (buffer/new-filled 64 0))
  (var dim-cursor 0)
  (for i 0 n
    (def [shape data] (inputs i))
    (var elems 1)
    (each d shape (set elems (* elems d)))
    (def b (buffer/new-filled (* elems 4) 0))
    (for j 0 elems (ffi/write :float (data j) b (* j 4)))
    (ffi/write :ptr b ptrs (* i 8))
    (ffi/write :int (length shape) ranks (* i 4))
    (ffi/write :long (* elems 4) nbytes (* i 8))
    (for k 0 (length shape)
      (ffi/write :int (shape k) dims (* (+ dim-cursor k) 4)))
    (set dim-cursor (+ dim-cursor (length shape))))
  (def out-buf (buffer/new-filled (* out-count 4) 0))
  (def written (buffer/new-filled 8 0))
  (def out-dims (buffer/new-filled 32 0))
  (def out-rank (buffer/new-filled 4 0))
  (def rc (tres-run-all rt n ptrs dims ranks nbytes out-buf out-count written out-dims 4 out-rank))
  (when (< rc 0) (fail "%s: %s" label (tres-last-error)))
  (unless (= rc out-count) (fail "%s returned %d floats, expected %d" label rc out-count))
  (def out (array/new-filled out-count 0.0))
  (for j 0 out-count (put out j (ffi/read :float out-buf (* j 4))))
  out)

#
# --- Arguments ------------------------------------------------------------
#

(def opts @{:out (string tmp-root "/height-tile.f32") :steps 20 :size 64 :seed 12345 :origin 100000})

(def argv (dyn :args @[]))
(var k 0)
(while (< k (length argv))
  (def a (argv k))
  (def nx (if (< (+ k 1) (length argv)) (argv (+ k 1)) nil))
  (cond
    (= a "--out")   (do (put opts :out nx) (set k (+ k 2)))
    (= a "--steps") (do (put opts :steps (math/floor (scan-number nx))) (set k (+ k 2)))
    (= a "--size")  (do (put opts :size (math/floor (scan-number nx))) (set k (+ k 2)))
    (= a "--seed")  (do (put opts :seed (math/floor (scan-number nx))) (set k (+ k 2)))
    (= a "--origin") (do (put opts :origin (math/floor (scan-number nx))) (set k (+ k 2)))
    (set k (+ k 1))))

(def steps (opts :steps))
(def size (opts :size))
(def seed (opts :seed))
(def origin (opts :origin))
(def n-pix (* size size))

# The coarse graph is exported with a FIXED spatial extent: its input is declared
# [batch,11,64,64] and ORT rejects any other size ("Got invalid dimensions for
# input x ... Got: 128 Expected: 64"). Base inherits 64 from the coarse stage's
# output, and the decoder's dynamic H/W is downstream of that. So 64 is not a
# default here, it is the only value the pinned chain accepts. Refuse early with
# a readable message instead of letting ORT fail mid-loop.
(unless (= size 64)
  (fail "tile size must be 64: the pinned coarse graph has a fixed 64x64 input extent"))

(print "=== native height tile: coarse -> base -> decoder -> laplacian ===")
(print (string/format "onnxruntime %s | seed %d | coarse %d steps | %dx%d"
                      (tres-version) seed steps size size))
(def t-all (os/clock))

#
# --- Stage 1: coarse ------------------------------------------------------
#

(def t0 (os/clock))
(def coarse-rt (tres-open (string tmp-root "/coarse_model.onnx")))
(when (nil? coarse-rt) (fail "coarse: %s" (tres-last-error)))
(def sch (sc/make-scheduler steps))

(def noise0 (coord-noise (+ seed 1) origin origin size size 6))
(def sigma0 (sc/current-sigma sch))
(var sample (array/new-filled (* 6 n-pix) 0.0))
(for j 0 (* 6 n-pix) (put sample j (* (noise0 j) sigma0)))

# REAL conditioning: Perlin/FastNoiseLite quantile-matched against WorldClim,
# reproduced natively and verified against upstream in test-conditioning.janet.
(def qpath (string here "/fixtures/conditioning-quantiles.bin"))
(def qbytes (file/read (file/open qpath :rb) :all))
(unless (= 1 (tres-cond-load qbytes (math/floor (/ (length qbytes) 8))))
  (fail "conditioning quantile fixture rejected"))

(def cond-raw (buffer/new-filled (* 5 n-pix 8) 0))
(unless (= 1 (tres-cond-map seed origin origin size size cond-raw (* 5 n-pix)))
  (fail "tres_cond_map failed"))
(def cond (array/new-filled (* 5 n-pix) 0.0))
(for j 0 (* 5 n-pix) (put cond j (f32-of (ffi/read :double cond-raw (* j 8)))))

# Upstream `_coarse_inference` standardises the conditioning map with the same
# coarse_means/coarse_stds used for the sample, indexing channels [0,2,3,4,5].
# Feeding raw metres here (thousands, for precipitation) instead of z-scores is
# a large out-of-distribution input.
(def cond-std
  (array/new-filled (* 5 n-pix) 0.0))
(for ch 0 5
  # Upstream indexes the 6-element coarse table with [0,2,3,4,5] because the
  # conditioning map has 5 channels while the coarse table has 6: channel 1 of
  # the coarse table is skipped. Using index `ch` directly misaligns channels
  # 2..4 onto the wrong statistics (ch2 ended up with mean 78 instead of ~1.3).
  (def idx ((array 0 2 3 4 5) ch))
  (def mean (pl/COARSE-MEANS idx))
  (def stdv (pl/COARSE-STDS idx))
  (for j 0 n-pix
    (put cond-std (+ (* ch n-pix) j) (f32-of (/ (- (cond (+ (* ch n-pix) j)) mean) stdv)))))

# Upstream blends the standardised map with a noise field before the model sees
# it:  cond_img = cos(t_cond)*smap + sin(t_cond)*cond_noise
# with t_cond = atan(cond_snr) and cond_noise a 5-channel patch at the same
# global coordinates. Omitting this leaves the conditioning un-noised, which
# shifts the coarse output by an order of magnitude.
(def cond-noise (coord-noise seed origin origin size size 5))
(def cos-tc (math/cos (math/atan 0.5)))
(def sin-tc (math/sin (math/atan 0.5)))
(def cond-img (array/new-filled (* 5 n-pix) 0.0))
(for ch 0 5
  (for j 0 n-pix
    (put cond-img (+ (* ch n-pix) j)
         (f32-of (+ (* cos-tc (cond-std (+ (* ch n-pix) j)))
                    (* sin-tc (cond-noise (+ (* ch n-pix) j))))))))

# The five scalar conditioning inputs, from upstream:
#   t_cond = atan(cond_snr);  vals = log(tan(t_cond)/8)
# with cond_snr = [0.5]*5. These are NOT fit parameters to invent.
(def cond-scalars
  (let [t (math/atan 0.5)]
    (array/new-filled 5 (f32-of (math/log (/ (math/tan t) 8.0))))))

(var step-n 0)
(while (not (sc/done? sch))
  (def sigma (sc/current-sigma sch))
  (def c-in (sc/precondition-inputs sigma))
  (def cnoise (sc/trigflow-noise sigma))
  (def xin (array/new-filled (* 11 n-pix) 0.0))
  (for j 0 (* 6 n-pix) (put xin j (f32-of (* (sample j) c-in))))
  (for j 0 (* 5 n-pix) (put xin (+ (* 6 n-pix) j) (cond-img j)))
  (def out (run-graph "coarse" coarse-rt
             @[@[[1 11 size size] xin]
               @[[1] @[cnoise]]
               @[[1] @[(cond-scalars 0)]]
               @[[1] @[(cond-scalars 1)]]
               @[[1] @[(cond-scalars 2)]]
               @[[1] @[(cond-scalars 3)]]
               @[[1] @[(cond-scalars 4)]]]
             (* 6 n-pix)))
  (when (= step-n 0)
        (print (string/format "  step0 sigma %.10f cnoise %.6f" sigma cnoise)))
  (set sample (sc/step-tensor sch sample out))
  (++ step-n))

(tres-close coarse-rt)
(pl/tile-stats "coarse-input ch0" (slice cond-img 0 n-pix))
(pl/tile-stats "coarse-sample ch0" (slice sample 0 n-pix))
(def raw-coarse (pl/coarse-post sample n-pix))
(print (string/format "  [1/4] coarse  %.1fs" (- (os/clock) t0)))
(for c 0 6
  (pl/tile-stats (string "coarse ch" c) (slice raw-coarse (* c n-pix) (* (+ c 1) n-pix))))

#
# --- Stage 2: base --------------------------------------------------------
#
# Upstream runs the base model as a ONE-STEP consistency model at
#   t = T_INTER = arctan(0.35/sigma_data)
# with a 58-wide conditioning vector, and negates the prediction.
#
# APPROXIMATE: the 58 vector is built from COND_MEAN/COND_STD (documented
# constants) rather than from a quantile-matched geography.
#

(def t0 (os/clock))
(def base-rt (tres-open (string tmp-root "/base_model.onnx")))
(when (nil? base-rt) (fail "base: %s" (tres-last-error)))

# Upstream: the latent stage starts from sample = ZEROS, not from the coarse
# output. The coarse map enters as CONDITIONING (the 58 vector below), not as
# the sample. Feeding coarse latents in as the sample was an earlier mistake and
# produced latent channel 4 near 8.8 (should be order 1), which the laplacian
# decode then amplified into six-figure elevations.
#
#   x_t = cos(t)*0 + sin(t)*z,  model_in = x_t / sigma_data
#
# histogram_raw: config has null for 30m, so the five buckets are zeros.
(def histogram [0.0 0.0 0.0 0.0 0.0])
(def coarse7 (pl/coarse7-window raw-coarse size))
(def cond58-list (pl/build-cond58 coarse7))
(def cond58 (array/new-filled 58 0.0))
(for i 0 58 (put cond58 i (f32-of (cond58-list i))))

(def t-lbl (f32-of pl/T-INTER))
(def xz (array/new-filled (* 5 n-pix) 0.0))
# sample is zero for the initial consistency pass, so x_t is the noise term only.
(def z (coord-noise (+ seed 5819) origin origin size size 5))
(def cos-t (math/cos pl/T-INTER))
(def sin-t (math/sin pl/T-INTER))
(for j 0 (* 5 n-pix)
  (put xz j (f32-of (/ (* sin-t (z j) pl/SIGMA-DATA) pl/SIGMA-DATA))))

(def base-out (run-graph "base" base-rt
                @[@[[1 5 size size] xz]
                  @[[1] @[t-lbl]]
                  @[[1 58] cond58]]
                (* 5 n-pix)))

(def latents (array/new-filled (* 5 n-pix) 0.0))
(for j 0 (* 5 n-pix)
  (def pred (- 0 (base-out j)))
  # `xz` holds model_in = x_t / sigma_data, so the update needs x_t = xz*sd:
  #   sample = cos(t)*x_t - sin(t)*sd*pred
  #          = cos(t)*xz*sd - sin(t)*sd*pred
  # and the stage output divides by sd:
  #   sample/sd = cos(t)*xz - sin(t)*pred
  (put latents j (f32-of (- (* cos-t (xz j)) (* sin-t pred)))))

(tres-close base-rt)
(print (string/format "  [2/4] base    %.1fs" (- (os/clock) t0)))
(pl/tile-stats "base latents" latents)
(def ch4 (array/new-filled n-pix 0.0))
(for j 0 n-pix (put ch4 j (latents (+ (* 4 n-pix) j))))
(pl/tile-stats "base ch4" ch4)

#
# --- Stage 3: decoder -----------------------------------------------------
#

(def t0 (os/clock))
(def dec-rt (tres-open (string tmp-root "/decoder_model.onnx")))
(when (nil? dec-rt) (fail "decoder: %s" (tres-last-error)))

# latents-for-decoder expects a 6-channel layout with channel 5 as normaliser.
# The base stage yields 5 channels with no accumulated weight, so a unit
# normaliser is supplied explicitly.
(def latents6 (array/new-filled (* 6 n-pix) 0.0))
(for j 0 (* 5 n-pix) (put latents6 j (latents j)))
(for j 0 n-pix (put latents6 (+ (* 5 n-pix) j) 1.0))

(def ups (pl/latents-for-decoder latents6 size))

(def dec-in (array/new-filled (* 5 size size) 0.0))
# model_in channel first (zeros), then the 4 upsampled latent channels.
(for j 0 (* 4 size size) (put dec-in (+ size size j) (f32-of (ups j))))

(def sig-max 80.0)
(def t-dec (f32-of (math/atan (/ sig-max pl/SIGMA-DATA))))
(def z1 (coord-noise (+ seed 5819) origin origin size size 1))
(def cos-td (math/cos (math/atan (/ sig-max pl/SIGMA-DATA))))
(def sin-td (math/sin (math/atan (/ sig-max pl/SIGMA-DATA))))
(for j 0 size size
  (put dec-in j (f32-of (/ (* sin-td (z1 j) pl/SIGMA-DATA) pl/SIGMA-DATA))))

(def dec-out (run-graph "decoder" dec-rt
               @[@[[1 5 size size] dec-in]
                 @[[1] @[t-dec]]]
               (* size size)))

(def residual (array/new-filled (* size size) 0.0))
(for j 0 size size
  (def pred (- 0 (dec-out j)))
  # Same correction as the base stage: dec-in is x_t/sd, not x_t.
  (put residual j (f32-of (- (* cos-td (dec-in j)) (* sin-td pred)))))

(tres-close dec-rt)
(print (string/format "  [3/4] decoder %.1fs" (- (os/clock) t0)))
(pl/tile-stats "residual" residual)

#
# --- Stage 4: laplacian -> metres ----------------------------------------
#
# residual_p = residual * RESIDUAL_STD + RESIDUAL_MEAN
# lowfreq_p  = latents_norm[4] * LOWFREQ_STD + LOWFREQ_MEAN
# elev_sqrt  = laplacian_decode(residual_p, lowfreq_p)
# elev       = sign(x) * x^2
#

(def t0 (os/clock))
(def low-size (/ size pl/LATENT-COMPRESSION))

(def residual-p (pl/emap1 |(+ (* $ pl/RESIDUAL-STD) pl/RESIDUAL-MEAN) residual))

# low-frequency channel: base latent channel 4, downsampled to low-size.
(def lowfreq-p (array/new-filled (* low-size low-size) 0.0))
(for j 0 (* low-size low-size)
  (put lowfreq-p j (f32-of (+ (* (latents (+ (* 4 n-pix) j)) pl/LOWFREQ-STD) pl/LOWFREQ-MEAN))))

(def elev (lap/elevation-from-laplacian residual-p size size lowfreq-p low-size low-size 5
                                         pl/LOWFREQ-MEAN pl/LOWFREQ-STD
                                         pl/RESIDUAL-MEAN pl/RESIDUAL-STD))
(print (string/format "  [4/4] laplacian %.1fs" (- (os/clock) t0)))

(def stats (pl/tile-stats "elevation metres" elev))

(when (> (stats :nonfinite) 0)
  (fail "%d non-finite elevations; refusing to emit" (stats :nonfinite)))
(when (<= (- (stats :max) (stats :min)) 1e-9)
  (fail "elevation is constant; no terrain produced"))

# Physical plausibility guard. Earth's land spans roughly -11000 m (Mariana) to
# 8900 m (Everest); the training data is bounded by that, so anything far
# outside it is evidence the model was driven out of distribution rather than
# a terrain result. Refusing here is deliberate: emitting 100 km mountains as
# "real elevation" would be the exact dishonesty this audit exists to prevent.
(def PLAUSIBLE-MIN -12000.0)
(def PLAUSIBLE-MAX 9500.0)
(when (or (< (stats :min) PLAUSIBLE-MIN) (> (stats :max) PLAUSIBLE-MAX))
  (fail (string "elevation out of physical range: %.1f..%.1f m (plausible %.0f..%.0f). "
                "The approximate conditioning has driven the base model outside its "
                "trained distribution; the stages ran but the output is not terrain.")
        (stats :min) (stats :max) PLAUSIBLE-MIN PLAUSIBLE-MAX))

#
# --- Emit -----------------------------------------------------------------
#

(def ob (buffer/new-filled (* size size 4) 0))
(for j 0 (* size size) (ffi/write :float (elev j) ob (* j 4)))
(spit (opts :out) ob)

(print "")
(print (string/format "  total %.1fs" (- (os/clock) t-all)))
(print (string/format "  wrote %s  %d bytes" (opts :out) (* size size 4)))
(print (string/format "  elevation: min %.1f m  max %.1f m  mean %.1f m"
                      (stats :min) (stats :max) (stats :mean)))
(print "")
(print "Real metric elevation, fully conditioned: the 5-channel map is the")
(print "Perlin/WorldClim quantile-match (verified to float32 precision against")
(print "upstream over all 20480 values), standardised with coarse_means/stds as")
(print "upstream does, and the 5 scalar inputs are log(tan(atan(0.5))/8).")
(print "")
(print "Still approximate: the 58-wide BASE conditioning vector, and no tiling.")
(print "The conditioning SHAPE is upstream's; the base vector is derived rather")
(print "than quantile-matched, so tiles are sensible land but not byte-identical")
(print "to an upstream bake.")
