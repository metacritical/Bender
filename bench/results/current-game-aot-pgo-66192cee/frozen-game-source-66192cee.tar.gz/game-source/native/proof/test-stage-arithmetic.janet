# test-stage-arithmetic.janet — per-stage ONNX vs PyTorch forward, real inputs.
#
# WHAT THIS VALIDATES
# -------------------
# For each of the three graphs, feed the EXACT input tensor that the real
# upstream pipeline produced (captured by hooking EDMUnet2D.forward during a real
# get()) and compare the ONNX output against the EXACT PyTorch output for that
# same call.
#
# This tests model arithmetic only. It deliberately involves NO geometry, NO
# window indices and NO conditioning construction — every one of those was a
# source of wrong answers earlier, and none of them can influence this test
# because the inputs are given as already-computed arrays.
#
# If a stage mismatches here, the graph or the runtime binding is wrong.
# If a stage matches here, the arithmetic is right and any remaining error lives
# in the orchestration around it.
#
# Fixtures are build-time captures (gitignored raw, hashes pinned in
# stage-meta.json). Nothing here is precomputed terrain: each file is the
# input/output of one forward pass, not a world.

(def here
  (let [parts (string/split "/" (os/realpath (dyn :current-file)))]
    (string/join (slice parts 0 (- (length parts) 1)) "/")))

(def fx (string here "/fixtures/stage2"))

(defn get-in-noise
  "Base noise label captured in stage-meta (1.5645464658737183 for the 30m base)."
  [] 1.5645464658737183)

(defn fail [fmt & args]
  (eprint "STAGE TEST FAILED: " (string/format fmt ;args))
  (os/exit 1))

(ffi/context (string here "/libtres.dylib"))
(ffi/defbind-alias tres_open      tres-open      :ptr [p :string])
(ffi/defbind-alias tres_close     tres-close     :void [rt :ptr])
(ffi/defbind-alias tres_last_error tres-last-error :string [])
(ffi/defbind-alias tres_run_all   tres-run-all   :int
  [rt :ptr n :int ptrs :ptr dims :ptr ranks :ptr nbytes :ptr
   out :ptr out_cap :int written :ptr out_dims :ptr out_dims_cap :int out_rank :ptr])

#
# --- helpers --------------------------------------------------------------
#

(defn read-f32
  "Load a raw little-endian float32 file into a Janet array."
  [p n]
  (def b (file/read (file/open p :rb) :all))
  (def got (math/floor (/ (length b) 4)))
  (unless (= got n)
    (fail "%s: expected %d floats, file has %d" p n got))
  (def out (array/new-filled n 0.0))
  (for i 0 n (put out i (ffi/read :float b (* i 4))))
  out)

(defn run-graph
  "Run one graph with explicit per-input shapes and data."
  [label model inputs out-count]
  (def rt (tres-open model))
  (when (nil? rt) (fail "%s open: %s" label (tres-last-error)))
  (def n (length inputs))
  (def ptrs (buffer/new-filled 64 0))
  (def dims (buffer/new-filled 64 0))
  (def ranks (buffer/new-filled 32 0))
  (def nbytes (buffer/new-filled 64 0))
  (var dim-cursor 0)
  (for i 0 n
    (def [shape data] (inputs i))
    (var elems 1)
    (each d shape (set elems (* elems d)))
    (unless (= elems (length data))
      (fail "%s input %d: shape %p needs %d values, got %d"
            label i shape elems (length data)))
    (def b (buffer/new-filled (* elems 4) 0))
    (for j 0 elems (ffi/write :float (data j) b (* j 4)))
    (ffi/write :ptr b ptrs (* i 8))
    (ffi/write :int (length shape) ranks (* i 4))
    (ffi/write :long (* elems 4) nbytes (* i 8))
    (for k 0 (length shape)
      (ffi/write :int (shape k) dims (* (+ dim-cursor k) 4)))
    (set dim-cursor (+ dim-cursor (length shape))))
  (def out-buf (buffer/new-filled (* out-count 4) 0))
  (def written (buffer/new-filled 8 0))
  (def odims (buffer/new-filled 32 0))
  (def orank (buffer/new-filled 4 0))
  (def rc (tres-run-all rt n ptrs dims ranks nbytes out-buf out-count written odims 4 orank))
  (when (< rc 0) (fail "%s run: %s" label (tres-last-error)))
  (tres-close rt)
  (unless (= rc out-count) (fail "%s returned %d, expected %d" label rc out-count))
  (def out (array/new-filled out-count 0.0))
  (for j 0 out-count (put out j (ffi/read :float out-buf (* j 4))))
  out)

(defn compare
  "Compare two float arrays. Reports max abs diff and relative-to-scale."
  [label got want]
  (def n (length got))
  (var max-abs 0.0)
  (var max-rel 0.0)
  (var at -1)
  (var amax 0.0)
  (for i 0 n
    (def d (math/abs (- (got i) (want i))))
    (when (> d max-abs) (set max-abs d) (set at i))
    (when (> (math/abs (want i)) amax) (set amax (math/abs (want i))))
    (def scale (math/abs (want i)))
    (when (> scale 1e-9)
      (def r (/ d scale))
      (when (> r max-rel) (set max-rel r))))
  (print (string/format "  %-9s n=%d  max|d|=%.3e  max|d|/|v|=%.3e  at %d"
                        label n max-abs max-rel at))
  {:max-abs max-abs :max-rel max-rel :mag amax})

#
# --- per-stage ------------------------------------------------------------
#

(def total-failures @[])

(print "=== stage arithmetic vs captured PyTorch forwards ===")
(print "onnxruntime: " (tres-last-error))

# COARSE: x[1,11,64,64] + noise[1] + cond0..4[1] -> out[1,6,64,64]
(print "")
(print "coarse  x[1,11,64,64] -> out[1,6,64,64]")
(def cx (read-f32 (string fx "/coarse_x.f32") (* 11 64 64)))
(def cl (read-f32 (string fx "/coarse_noise.f32") 1))
(def c0 (read-f32 (string fx "/coarse_cond0.f32") 1))
(def cout-want (read-f32 (string fx "/coarse_out.f32") (* 6 64 64)))
(def cout (run-graph "coarse" (string here "/../../tmp/native-terrain-proof/coarse_model.onnx")
           @[@[[1 11 64 64] cx] @[[1] cl]
             @[[1] c0] @[[1] c0] @[[1] c0] @[[1] c0] @[[1] c0]]
           (* 6 64 64)))
(def rc (compare "coarse" cout cout-want))
(when (> (rc :max-abs) 1e-4)
  (print (string/format "  FAIL  coarse exceeds 1e-4 (%.3e)" (rc :max-abs)))
  (array/push total-failures "coarse"))

# BASE: x[1,5,64,64] + noise[1] + cond[1,58] -> out[1,5,64,64]
(print "")
(print "base    x[1,5,64,64] -> out[1,5,64,64]")
(def bx (read-f32 (string fx "/base_x.f32") (* 5 64 64)))
(def bl (read-f32 (string fx "/base_noise.f32") 1))
(def bc (read-f32 (string fx "/base_cond0.f32") 58))
(def bout-want (read-f32 (string fx "/base_out.f32") (* 5 64 64)))
(def bout (run-graph "base" (string here "/../../tmp/native-terrain-proof/base_model.onnx")
             @[@[[1 5 64 64] bx] @[[1] bl] @[[1 58] bc]]
             (* 5 64 64)))
(def rb (compare "base" bout bout-want))
(when (> (rb :max-abs) 1e-4)
  (print (string/format "  FAIL  base exceeds 1e-4 (%.3e)" (rb :max-abs)))
  (array/push total-failures "base"))

# DECODER: x[1,5,512,512] + noise[1] -> out[1,1,512,512]
(print "")
(print "decoder x[1,5,512,512] -> out[1,1,512,512]")
(def dx (read-f32 (string fx "/decoder_x.f32") (* 5 512 512)))
(def dl (read-f32 (string fx "/decoder_noise.f32") 1))
(def dout-want (read-f32 (string fx "/decoder_out.f32") (* 512 512)))
(def dout (run-graph "decoder" (string here "/../../tmp/native-terrain-proof/decoder_model.onnx")
            @[@[[1 5 512 512] dx] @[[1] dl]]
            (* 512 512)))
(def rd (compare "decoder" dout dout-want))
(when (> (rd :max-abs) 1e-4)
  (print (string/format "  FAIL  decoder exceeds 1e-4 (%.3e)" (rd :max-abs)))
  (array/push total-failures "decoder"))

#
# --- verdict --------------------------------------------------------------
#

(print "")
(if (empty? total-failures)
  (do
    (print "STAGE ARITHMETIC PASSED: all three graphs reproduce PyTorch within 1e-4")
    (print "on the exact tensors the upstream pipeline produced at origin 100000.")
    (os/exit 0))
  (do
    (print (string/format "STAGE ARITHMETIC FAILED: %d stage(s)" (length total-failures)))
    (each f total-failures (print "   - " f))
    (os/exit 1)))
