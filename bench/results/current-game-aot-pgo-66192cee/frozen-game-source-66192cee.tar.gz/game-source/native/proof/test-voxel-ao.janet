# Pure arithmetic proof; no GPU, renderer, native model, or chunk allocation.
(import ./voxel-ao :as ao)

(def truth-table [[false false false 0]
                  [false false true 1]
                  [false true false 1]
                  [false true true 2]
                  [true false false 1]
                  [true false true 2]
                  [true true false 3]
                  [true true true 3]])
(each row truth-table
  (let [[a b d expected] row]
    (assert (= expected (ao/corner-occlusion a b d))
            "corner occupancy truth table")
    (assert (= (ao/corner-occlusion a b d)
               (ao/corner-occlusion b a d))
            "side-swap symmetry")))
(print "all eight AO occupancies and symmetry: ok")

(assert (= 4 (length ao/brightness)))
(for i 0 4
  (assert (<= 0 (get ao/brightness i) 1) "brightness outside 0..1")
  (when (> i 0)
    (assert (> (get ao/brightness (- i 1)) (get ao/brightness i))
            "greater occlusion must be darker")))
(assert (= 1.0 (get ao/brightness 0)))
(assert (= 0.45 (get ao/brightness 3)))
(print "brightness LUT bounded and strictly decreasing: ok")

# Preserve the original :flip/:keep API; compare the actual shader LUT.
(assert (= :keep (ao/quad-diagonal [3 0 3 0])))
(assert (= :flip (ao/quad-diagonal [0 3 0 3])))
(assert (= :keep (ao/quad-diagonal [2 1 0 1])))
(assert (= :keep (ao/quad-diagonal [0 0 0 0])))
(assert (= :keep (ao/quad-diagonal [0 0 3 3]))
        "equal brightness sums keep the 0–2 diagonal")
(assert (= :keep (ao/quad-diagonal [3 1 2 0])))
(assert (= :flip (ao/quad-diagonal (tuple 0 2 1 3))))
# Nonlinear LUT makes level sums alone insufficient: 0+3 and 1+2 both
# have level sum 3, but brightness 1+.45 > .8+.6.
(assert (= :flip (ao/quad-diagonal [0 1 3 2])))
(assert (= :keep (ao/quad-diagonal [1 0 2 3])))
(print "opposite brightness sums and deterministic tie: ok")

(defn rejected? [thunk]
  (let [[ok _] (protect (thunk))] (not ok)))
(each bad [[0 false false] [:yes false false] [nil false false]
           [false 1 false] [false false "true"]]
  (assert (rejected? (fn [] (apply ao/corner-occlusion bad)))
          "non-boolean AO occupancy accepted"))
(each bad [nil [] [0 1 2] [0 1 2 3 0] [0 1 2 -1]
           [0 1 2 4] [0 1 2 2.5] [0 1 2 :three] "0123"]
  (assert (rejected? (fn [] (ao/quad-diagonal bad)))
          "malformed AO quad accepted"))
(print "strict occupancy and quad validation: ok")
(print "voxel AO arithmetic tests: all passed")
