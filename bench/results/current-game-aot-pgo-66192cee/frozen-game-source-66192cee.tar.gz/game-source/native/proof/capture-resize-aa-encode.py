import json, hashlib, torch, torchvision
import torchvision.transforms.functional as TF

results = {}

# 1. Ramp 4 -> 8 UPSAMPLE guard. Old goldens must not move.
ramp = torch.tensor([[0.,1.,2.,3.]], dtype=torch.float32).reshape(1,1,1,4)
up = TF.resize(ramp, [1,8], interpolation=TF.InterpolationMode.BILINEAR, antialias=True)
results["ramp_1x4_to_1x8_aa"] = {
  "in": [round(float(v),9) for v in ramp.flatten().tolist()],
  "out": [round(float(v),9) for v in up.flatten().tolist()],
  "note": "upsample with antialias=True; torch keeps this identical to antialias=False",
}
up_no = TF.resize(ramp, [1,8], interpolation=TF.InterpolationMode.BILINEAR, antialias=False)
results["ramp_1x4_to_1x8_noaa"] = {
  "in": [round(float(v),9) for v in ramp.flatten().tolist()],
  "out": [round(float(v),9) for v in up_no.flatten().tolist()],
}

# 2. FULL upstream laplacian_encode, 8 -> 4, sigma=1, on a ramp.
#    This is the case that catches AA-vs-nonAA preblur semantics end to end.
import sys
sys.path.insert(0, "tmp/terrain-runtime/repo")
from terrain_diffusion.data.laplacian_encoder import laplacian_encode

for sigma in (1.0,):
    x = torch.arange(64, dtype=torch.float32).reshape(1,1,8,8) / 8.0
    for extrap in (False, True):
        res, low = laplacian_encode(x, 4, sigma, extrapolate=extrap)
        results[f"encode_8to4_sigma{sigma}_extrap{int(extrap)}"] = {
          "in": [round(float(v),9) for v in x.flatten().tolist()],
          "residual": [round(float(v),9) for v in res.flatten().tolist()],
          "lowres": [round(float(v),9) for v in low.flatten().tolist()],
          "sigma": sigma, "target": 4, "extrapolate": extrap,
        }

out = {
 "_note": "torchvision/torch upstream CPU captures for AA resize and full laplacian_encode. No model, no GPU, no weights.",
 "torch": torch.__version__, "torchvision": torchvision.__version__,
 "cases": results,
}
path = "native/proof/fixtures/resize-aa-addendum.json"
open(path,"w").write(json.dumps(out, indent=1))
print(json.dumps({"sha256": hashlib.sha256(open(path,'rb').read()).hexdigest(), "keys": list(results)}, indent=1))
