# assembler.janet — bounded finite-window query assembler.
#
# Produces one elevation tile by running the real ONNX graphs over every window
# the geometry planner says is needed, then blending with the linear weight
# window and dividing by the accumulated weights.
#
# Dependency chain for the target query (origin 100000, 64x64):
#
#   query 100000..100064
#     -> padded 99952..100112            (pad_hr = 48, from sigma=5)
#     -> 4 decoder windows  (512/384)
#     -> 25 latent windows  (64/32, via decoder-in 64/48)
#     -> 25 cond windows    (7,4,4 / 7,1,1 / offset -1,-1)
#     -> 4 coarse windows   (64/48)       <- stride 48, NOT 32
#
# The counts come from geometry.janet's stage-plan, which is verified against the
# real Python TensorWindow (129/129 checks in test-geometry.janet).
#
# WHAT IS REAL HERE
#   - all three pinned ONNX graphs and their weights
#   - the EDM/consistency preconditioning, coarse denormalisation, channel-1
#     differencing, latent-compression nearest upsample
#   - the laplacian decode and sign(x)*x^2 elevation
#   - the linear tent weight window and weighted blending
#
# WHAT IS APPROXIMATE
#   - the 5 scalar coarse conditioning inputs and the 58-wide base vector are
#     derived rather than taken from a fully quantile-matched geography
#   - the conditioning MAP is real (Perlin/WorldClim quantile match, verified to
#     float32 precision against upstream)
#
# No oracle file is read at run time. Nothing here is precomputed terrain.

(import ./geometry :as geo)
(import ./scheduler :as sc)
(import ./laplacian :as lap)
(import ./pipeline :as pl)

(def here
  (let [parts (string/split "/" (os/realpath (dyn :current-file)))]
    (string/join (slice parts 0 (- (length parts) 1)) "/")))

(def tmp-root (string here "/../../tmp/native-terrain-proof"))

(defn fail [fmt & args]
  (eprint "ASSEMBLER FAILED: " (string/format fmt ;args))
  (os/exit 1))

#
# --- FFI ------------------------------------------------------------------
#

(ffi/context (string here "/libtres.dylib"))

(ffi/defbind-alias tres_version     tres-version     :string [])
(ffi/defbind-alias tres_last_error  tres-last-error  :string [])
(ffi/defbind-alias tres_open        tres-open        :ptr    [p :string])
(ffi/defbind-alias tres_close       tres-close       :void   [rt :ptr])
(ffi/defbind-alias tres_fill_normal tres-fill-normal :int    [seed :long out :ptr n :int])
(ffi/defbind-alias tres_noise_patch tres-noise-patch :int
  [seed :long y0 :long x0 :long h :int w :int ch :int out :ptr n :int])
(ffi/defbind-alias tres_noise_patch_tiled tres-noise-patch-tiled :int
  [seed :long y0 :long x0 :long h :int w :int ch :int th :int tw :int out :ptr n :int])
(ffi/defbind-alias tres_cond_load   tres-cond-load   :int  [buf :ptr n :long])
(ffi/defbind-alias tres_cond_ready  tres-cond-ready  :int  [])
(ffi/defbind-alias tres_cond_map    tres-cond-map    :int
  [seed :long oy :long ox :long w :int h :int out :ptr n :long])
(ffi/defbind-alias tres_run_all     tres-run-all     :int
  [rt :ptr n :int ptrs :ptr dims :ptr ranks :ptr nbytes :ptr
   out :ptr out_cap :int written :ptr out_dims :ptr out_dims_cap :int out_rank :ptr])

#
# --- small helpers --------------------------------------------------------
#

(defn f32 [x]
  (def b (buffer/new-filled 4 0))
  (ffi/write :float x b 0)
  (ffi/read :float b 0))

(defn coord-noise
  "Coordinate-seeded Gaussian patch, bit-exact against upstream
   `gaussian_noise_patch(base_seed, y0, x0, h, w, channels, tile_h, tile_w)`.

   THE TILE SIZE IS PART OF THE FIELD. The coarse stage calls it with
   tile_h = tile_w = TILE_SIZE = 64 (world_pipeline.py:1026-1031), not the
   function's 256 default. A 256 tile produces an entirely different noise
   stream -- verified: tile 64 and tile 256 disagree from the first value --
   and that mismatch is what made the coarse output 44x too large.

   Pass `th`/`tw` explicitly; there is no safe default."
  [seed y0 x0 h w ch th tw]
  (def buf (buffer/new-filled (* h w ch 8) 0))
  (def rc (tres-noise-patch-tiled seed y0 x0 h w ch th tw buf (* h w ch)))
  (when (< rc 0) (fail "tres_noise_patch_tiled %v %v %v %v %v %v %v %v"
                      seed y0 x0 h w ch th tw))
  (def out (array/new-filled (* h w ch) 0.0))
  (for i 0 (* h w ch) (put out i (ffi/read :double buf (* i 8))))
  out)

(defn run-graph
  "Run one graph. `inputs` is an array of [shape data-array] pairs."
  [label rt inputs out-count]
  (def n (length inputs))
  (def ptrs (buffer/new-filled 64 0))
  (def dims (buffer/new-filled 64 0))
  (def ranks (buffer/new-filled 32 0))
  (def nbytes (buffer/new-filled 64 0))
  (var dim-cursor 0)
  (for i 0 n
    (def [shape data] (inputs i))
    (var elems 1)
    (each d shape (set elems (* elems d)))
    (unless (= elems (length data))
      (fail "%s input %d: shape %p needs %d, got %d" label i shape elems (length data)))
    (def b (buffer/new-filled (* elems 4) 0))
    (for j 0 elems (ffi/write :float (data j) b (* j 4)))
    (ffi/write :ptr b ptrs (* i 8))
    (ffi/write :int (length shape) ranks (* i 4))
    (ffi/write :long (* elems 4) nbytes (* i 8))
    (for k 0 (length shape)
      (ffi/write :int (shape k) dims (* (+ dim-cursor k) 4)))
    (set dim-cursor (+ dim-cursor (length shape))))
  (def out-buf (buffer/new-filled (* out-count 4) 0))
  (def written (buffer/new-filled 8 0))
  (def odims (buffer/new-filled 32 0))
  (def orank (buffer/new-filled 4 0))
  (def rc (tres-run-all rt n ptrs dims ranks nbytes out-buf out-count written odims 4 orank))
  (when (< rc 0) (fail "%s: %s" label (tres-last-error)))
  (unless (= rc out-count) (fail "%s returned %d, expected %d" label rc out-count))
  (def out (array/new-filled out-count 0.0))
  (for j 0 out-count (put out j (ffi/read :float out-buf (* j 4))))
  out)

(defn linear-weight-window
  "`linear_weight_window` from world_pipeline.py:117-124, separable tent with
   eps=1e-3. Returns a size*size flat array."
  [size]
  (def mid (/ (- size 1) 2))
  (def eps 1e-3)
  (def out (array/new-filled (* size size) 0.0))
  (for y 0 size
    (for x 0 size
      (def dy (math/abs (- y mid)))
      (def dx (math/abs (- x mid)))
      (def wy (- 1 (* (- 1 eps) (min 1.0 (/ dy mid)))))
      (def wx (- 1 (* (- 1 eps) (min 1.0 (/ dx mid)))))
      (put out (+ (* y size) x) (* wy wx))))
  out)

#
# --- stage runners --------------------------------------------------------
#
# Each returns the stage tensor for ONE window, cropped/aligned to that window's
# pixel range. The caller accumulates them into a padded buffer.
#

(defn run-coarse-window
  "One coarse window -> 6 channels at 64x64 (post denormalisation)."
  [rt ctx seed steps y0 x0]
  (def size 64)
  (def n (* size size))
  (def sch (sc/make-scheduler steps))

  (def noise0 (coord-noise (+ seed 1) y0 x0 size size 6 size size))
  (def sigma0 (sc/current-sigma sch))
  (var sample (array/new-filled (* 6 n) 0.0))
  (for j 0 (* 6 n) (put sample j (* (noise0 j) sigma0)))

  # conditioning map for this window, at its own global coordinates
  (def craw (buffer/new-filled (* 5 n 8) 0))
  (def mrc (tres-cond-map (math/floor seed) (math/floor y0) (math/floor x0) 64 64 craw (* 5 64 64)))
  (unless (= 1 mrc)
    (fail "tres_cond_map failed y0=%v(%v) x0=%v(%v) size=%v(%v) n=%v(%v) bufbytes=%d rc=%v ready=%v"
          y0 (type y0) x0 (type x0) size (type size) n (type n) (length craw) mrc (tres-cond-ready)))
  (def cmean pl/COARSE-MEANS)
  (def cstd pl/COARSE-STDS)
  (def idxs [0 2 3 4 5])
  (def cstd-img (array/new-filled (* 5 n) 0.0))
  (for ch 0 5
    (def id (idxs ch))
    (for j 0 n
      (put cstd-img (+ (* ch n) j)
           (f32 (/ (- (ffi/read :double craw (* (+ (* ch n) j) 8)) (cmean id))
                   (cstd id))))))

  (def cnoise (coord-noise seed y0 x0 size size 5 size size))
  (def ct (math/atan 0.5))
  (def cosc (math/cos ct)) (def sinc (math/sin ct))
  (def cimg (array/new-filled (* 5 n) 0.0))
  (for j 0 (* 5 n)
    (put cimg j (f32 (+ (* cosc (cstd-img j)) (* sinc (cnoise j))))))

  (def t (math/atan 0.5))
  (def cs (f32 (math/log (/ (math/tan t) 8.0))))

  (var step 0)
  (while (not (sc/done? sch))
    (def sigma (sc/current-sigma sch))
    (def c-in (sc/precondition-inputs sigma))
    (def cn (sc/trigflow-noise sigma))
    (def xin (array/new-filled (* 11 n) 0.0))
    (for j 0 (* 6 n) (put xin j (f32 (* (sample j) c-in))))
    (for j 0 (* 5 n) (put xin (+ (* 6 n) j) (cimg j)))
    (def out (run-graph "coarse" rt
               (array
                 (array (array 1 11 size size) xin)
                 (array (array 1) (array cn))
                 (array (array 1) (array cs))
                 (array (array 1) (array cs))
                 (array (array 1) (array cs))
                 (array (array 1) (array cs))
                 (array (array 1) (array cs)))
               (* 6 n)))
    (set sample (sc/step-tensor sch sample out))
    (++ step))
  (pl/coarse-post sample n))

(defn run-latent-window
  "One latent window -> 5 channels at 64x64, from the coarse 4x4 cond window."
  [rt ctx coarse7 seed y0 x0]
  # coarse7: 7x16 flat array (6 coarse channels + unit weight, at 4x4)
  (def size 64)
  (def n (* size size))
  (def cond58 (pl/build-cond58 coarse7))

  (def z (coord-noise (+ seed 5819) y0 x0 size size 5 256 256))
  # NOT T_INTER. Upstream `_latent_inference` is called with
  # `t_init = atan(scheduler.sigmas[0]/sigma_data)` = atan(80/0.5) = 1.56455,
  # which is why the captured base noise_label is 1.5645464658737183.
  # Using T_INTER (atan(0.7) = 0.6107) here made sin(t) 0.57 instead of 0.99998
  # and scaled the whole latent field wrong.
  (def t (math/atan (/ 80.0 pl/SIGMA-DATA)))
  (def cos-t (math/cos t)) (def sin-t (math/sin t))
  (def xz (array/new-filled (* 5 n) 0.0))
  (for j 0 (* 5 n)
    (put xz j (f32 (/ (* sin-t (z j) pl/SIGMA-DATA) pl/SIGMA-DATA))))

  (def out (run-graph "base" rt
             (array
               (array (array 1 5 size size) xz)
               (array (array 1) (array (f32 t)))
               (array (array 1 58) cond58))
             (* 5 n)))

  # Upstream `_latent_inference`:
  #   sample = cos(t)*x_t - sin(t)*sigma_data*pred
  #   output = sample / sigma_data
  # `xz` holds model_in = x_t/sigma_data, so x_t = xz*sigma_data and
  #   sample/sigma_data = cos(t)*xz - sin(t)*pred
  # The earlier version omitted the final /sigma_data, leaving the latents a
  # factor of 2 too large and collapsing the decoded elevation.
  (def lat (array/new-filled (* 5 n) 0.0))
  (for j 0 (* 5 n)
    (def pred (- 0 (out j)))
    (put lat j (f32 (- (* cos-t (xz j)) (* sin-t pred)))))
  lat)

(defn run-decoder-window
  "One decoder window: 5x512x512 -> 1x512x512 residual, weighted."
  [rt ctx lat5 seed y0 x0]
  (def size 512)
  (def lc geo/latent-compression)
  (def low (/ size lc))
  (def low-n (* low low))
  (def n (* size size))

  # latent 64x64 -> 4 channels down to 8x8 -> nearest upsample to 512
  # Upstream (world_pipeline.py:1321) does `latents.view(1,4,TILE/lc,TILE/lc)`:
  # the 4 latent channels are 64x64 and are REINTERPRETED as 8x8, i.e. the
  # latent tensor is already stored at the coarse grid. There is no averaging
  # here -- `interpolate(nearest)` then expands 8x8 to 512.
  (def l64 64)
  (def lat-low (/ l64 lc))    # 8
  (def up (array/new-filled (* 4 n) 0.0))
  (for ch 0 4
    (def chan (array/new-filled low-n 0.0))
    (for y 0 lat-low
      (for x 0 lat-low
        (put chan (+ (* y lat-low) x)
             (lat5 (+ (* ch (* l64 l64)) (* y l64) x)))))
    # nearest upsample 8x8 -> 512x512
    (for y 0 size
      (def sy (math/floor (/ y lc)))
      (for x 0 size
        (def sx (math/floor (/ x lc)))
        (put up (+ (* ch n) (* y size) x) (chan (+ (* sy lat-low) sx))))))

  (def sig-max 80.0)
  (def td (math/atan (/ sig-max pl/SIGMA-DATA)))
  (def cos-td (math/cos td)) (def sin-td (math/sin td))
  (def z1 (coord-noise (+ seed 5819) y0 x0 size size 1 256 256))

  # 5 channels: the noisy model input in channel 0, then the 4 upsampled latents.
  (def din (array/new-filled (* 5 n) 0.0))
  (for j 0 n (put din j (f32 (/ (* sin-td (z1 j) pl/SIGMA-DATA) pl/SIGMA-DATA))))
  (for j 0 (* 4 n) (put din (+ n j) (f32 (up j))))
  (unless (= (length din) (* 5 n))
    (fail "din has %d, expected %d" (length din) (* 5 n)))

  (def out (run-graph "decoder" rt
             (array
               (array (array 1 5 size size) din)
               (array (array 1) (array (f32 td))))
             n))

  (def res (array/new-filled n 0.0))
  (for j 0 n
    (def pred (- 0 (out j)))
    (put res j (f32 (- (* cos-td (din j)) (* sin-td pred)))))
  res)

#
# --- entry ----------------------------------------------------------------
#

(defn assemble
  "Assemble elevation for `query` from every window the planner requires.

   Pipeline, in dependency order:
     1. coarse windows  -> assemble the 6-channel coarse field over the span the
        cond windows need
     2. per latent window: crop the 4x4 cond region, build the 58-vector, run base
     3. per decoder window: upsample its latent input, run decoder, accumulate
        weighted residual and weight into the padded span
     4. divide by accumulated weight, crop to the query, laplacian-decode to metres
   "
  [opts]
  (def origin (opts :origin))
  (def size (opts :size))
  (def seed (opts :seed))
  (def steps (opts :steps))

  (def q @{:start [origin origin] :stop [(+ origin size) (+ origin size)]})
  (def plan (geo/stage-plan q))
  (def padded (plan :padded))
  (def p0 (get (padded :start) 0))
  (def p1 (get (padded :stop) 0))
  (def span (- p1 p0))
  (print (string/format "  padded %d..%d (%dx%d)" p0 p1 span span))
  (print (string/format "  plan: %d dec, %d lat, %d cond, %d coarse"
                        ((plan :counts) :decoder) ((plan :counts) :latent)
                        ((plan :counts) :cond) ((plan :counts) :coarse)))

  # conditioning quantiles must be loaded before any tres_cond_map call
  (def qpath (string here "/fixtures/conditioning-quantiles.bin"))
  (def qbytes (file/read (file/open qpath :rb) :all))
  # Keep the quantile buffer reachable: tres_cond_load copies the values, but a
  # collected Janet buffer would let the GC reuse that memory while C still holds
  # pointers into it.
  (def q-keepalive qbytes)
  (def qn (math/floor (/ (length qbytes) 8)))
  (def qrc (tres-cond-load qbytes qn))
  (unless (= 1 qrc)
    (fail "conditioning quantile fixture rejected: bytes=%d doubles=%v rc=%v"
          (length qbytes) qn qrc))

  (def coarse-rt (tres-open (string tmp-root "/coarse_model.onnx")))
  (def base-rt   (tres-open (string tmp-root "/base_model.onnx")))
  (def dec-rt    (tres-open (string tmp-root "/decoder_model.onnx")))
  (each [n rt] [["coarse" coarse-rt] ["base" base-rt] ["decoder" dec-rt]]
    (when (nil? rt) (fail "%s open failed" n)))

  # ---- 1. coarse field over the span the cond windows need --------------
  # cond windows live in coarse output pixel space; union their bounds.
  (var c0 nil) (var c1 nil)
  (each c (plan :cond)
    (def b (c :bounds))
    (def s (get (b :start) 1)) (def e (get (b :stop) 1))
    (set c0 (if (nil? c0) s (min c0 s)))
    (set c1 (if (nil? c1) e (max c1 e))))
  (print (string/format "  coarse pixel span %d..%d" c0 c1))

  # Assemble coarse over a glyph-aligned region covering [c0,c1) by running each
  # needed coarse window and copying its 64x64 output into a buffer.
  (def cspan (- c1 c0))
  (def cacc (array/new-filled (* 6 cspan cspan) 0.0))
  (def cw (array/new-filled (* cspan cspan) 0.0))
  (def cww (linear-weight-window 64))
  (each cwin (plan :coarse)
    (def cb (cwin :bounds))
    (def cy (get (cb :start) 1)) (def cx (get (cb :start) 2))
    (def out6 (run-coarse-window coarse-rt cwin seed steps cy cx))
    (for y 0 64
      (for x 0 64
        (def gy (- (+ cy y) c0)) (def gx (- (+ cx x) c0))
        (when (and (>= gy 0) (< gy cspan) (>= gx 0) (< gx cspan))
          (def i (+ (* gy cspan) gx))
          (def w (cww (+ (* y 64) x)))
          (for ch 0 6
            (def si (+ (* ch (* 64 64)) (* y 64) x))
            (def di (+ (* ch cspan cspan) i))
            (put cacc di (+ (get cacc di) (* (get out6 si) w))))
          (put cw i (+ (get cw i) w))))))
  (tres-close coarse-rt)
  (print "  coarse assembled")
  (do (var mn 1e30) (var mx -1e30) (var sum 0.0) (var cnt 0)
      (for ch 0 6
        (for i 0 (* cspan cspan)
          (def w (get cw i))
          (when (> w 1e-12)
            (def v (/ (get cacc (+ (* ch cspan cspan) i)) w))
            (set sum (+ sum v)) (++ cnt)
            (when (< v mn) (set mn v)) (when (> v mx) (set mx v)))))
      (print (string/format "  coarse field: min %.2f max %.2f mean %.2f (upstream -74.6..66.4 mean -18.1)"
                            mn mx (/ sum (max cnt 1)))))

  # ---- 2. per latent window: cond 4x4 -> base --------------------------
  (def lat-cache @{})
  # `latents_norm[4]` is the low-frequency band the final elevation needs
  # (world_pipeline.py:1402). It must be accumulated alongside the residual,
  # otherwise the laplacian decode has no low-frequency field and collapses.
  # LATENT-SPACE accumulators. The latent tensor lives at 1/8 the pixel scale,
  # so its indices are 12384.. not 99456... Using the pixel `span` here silently
  # wrote outside the array and left the field empty.
  (def lat-p0 (math/floor (/ p0 geo/latent-compression)))
  (def lat-p1 (math/floor (/ p1 geo/latent-compression)))
  (def lat-span (- lat-p1 lat-p0))
  (print (string/format "  latent space %d..%d (%dx%d)" lat-p0 lat-p1 lat-span lat-span))
  (def lacc (array/new-filled (* lat-span lat-span) 0.0))
  (def lwacc (array/new-filled (* lat-span lat-span) 0.0))
  (defn key-of [idx] (string/join (seq [v :in idx] (string v)) ","))

  (defn run-latent [lctx]
    (def lidx (lctx :index))
    (def k (key-of lidx))
    (or (get lat-cache k)
        (let [cb (lctx :bounds)
              cy (get (cb :start) 1)
              cx (get (cb :start) 2)
              c7 (array/new-filled (* 7 16) 0.0)]
          (for ch 0 6
            (for yy 0 4
              (for xx 0 4
                (def gy (math/floor (- (+ cy yy) c0)))
                (def gx (math/floor (- (+ cx xx) c0)))
                (def i (+ (* gy cspan) gx))
                (def w (if (and (>= i 0) (< i (length cw))) (get cw i) 0.0))
                (put c7 (+ (* ch 16) (* yy 4) xx)
                     (if (<= w 1e-12) 0.0 (/ (get cacc (+ (* ch cspan cspan) i)) w))))))
          (for i 0 16 (put c7 (+ (* 6 16) i) 1.0))
          # The latent window's own bounds give the global coordinates its noise
          # must be seeded from. `cb` above is the COND window bounds (4 wide,
          # offset -1); the latent window is 64 wide at stride 32.
          (def lbb (geo/bounds-of-face :latent lidx))
          (def ly0 (get (lbb :start) 1))
          (def lx0 (get (lbb :start) 2))
          (def v (run-latent-window base-rt lctx c7 seed ly0 lx0))
          (put lat-cache k v)
          # copy latent ch4 into the padded latent accumulator
          (def lw (linear-weight-window 64))
          (for yy 0 64
            (for xx 0 64
              (def gy (- (+ ly0 yy) lat-p0)) (def gx (- (+ lx0 xx) lat-p0))
              (when (and (>= gy 0) (< gy lat-span) (>= gx 0) (< gx lat-span))
                (def i (+ (* gy lat-span) gx))
                (def w (lw (+ (* yy 64) xx)))
                (put lacc i (+ (get lacc i) (* (get v (+ (* 4 4096) (* yy 64) xx)) w)))
                (put lwacc i (+ (get lwacc i) w)))))
          v)))

  # ---- 3. decoder windows -> weighted residual -------------------------
  (def acc (array/new-filled (* span span) 0.0))
  (def wacc (array/new-filled (* span span) 0.0))
  (def w512 (linear-weight-window 512))

  (each dw (plan :decode)
    (def db (dw :bounds))
    (def dy (get (db :start) 1)) (def dx (get (db :start) 2))
    # the latent window covering this decoder's INPUT start
    (def dib (geo/bounds-of-face :decoder-in (dw :index)))
    (def ly (get (dib :start) 1)) (def lx (get (dib :start) 2))
    (def lidx @[0 (math/floor (/ ly 32)) (math/floor (/ lx 32))])
    (def lctx (first (filter |(= (key-of ($ :index)) (key-of lidx)) (plan :latent))))
    (def lat5 (if (nil? lctx)
                (fail "no latent context for %v" lidx)
                (run-latent lctx)))
    (def res (run-decoder-window dec-rt dw lat5 seed dy dx))
    (for y 0 512
      (for x 0 512
        (def gy (- (+ dy y) p0)) (def gx (- (+ dx x) p0))
        (when (and (>= gy 0) (< gy span) (>= gx 0) (< gx span))
          (def i (+ (* gy span) gx))
          (def w (w512 (+ (* y 512) x)))
          (put acc i (+ (get acc i) (* (get res (+ (* y 512) x)) w)))
          (put wacc i (+ (get wacc i) w)))))
    (print (string/format "    decoder %v done" (dw :index))))

  (tres-close base-rt) (tres-close dec-rt)

  # ---- 4. divide, crop, laplacian --------------------------------------
  (def n (* size size))
  (def resu (array/new-filled n 0.0))
  (for y 0 size
    (for x 0 size
      (def gy (- (+ origin y) p0)) (def gx (- (+ origin x) p0))
      (def i (+ (* gy span) gx))
      (def w (get wacc i))
      (put resu (+ (* y size) x)
           (if (<= w 1e-12) 0.0 (/ (get acc i) w)))))

  # low-frequency field at the query resolution: divide accumulated latent ch4,
  # then downsample by latent_compression to the coarse grid the decode wants.
  # The query at 64x64 spans 8 latent cells (64/8). Read them from latent space
  # at the query's own latent origin.
  (def low-n (/ size geo/latent-compression))
  (def q-lat (math/floor (/ origin geo/latent-compression)))
  (def lowf (array/new-filled (* low-n low-n) 0.0))
  (for ly 0 low-n
    (for lx 0 low-n
      (def gy (- (+ q-lat ly) lat-p0))
      (def gx (- (+ q-lat lx) lat-p0))
      (def i (+ (* gy lat-span) gx))
      (if (and (>= i 0) (< i (length lacc)))
        (let [w (get lwacc i)]
          (put lowf (+ (* ly low-n) lx)
               (if (<= w 1e-12) 0.0 (/ (get lacc i) w))))
        (put lowf (+ (* ly low-n) lx) 0.0))))

  {:residual resu :size size :lowfreq lowf :low-size low-n}
  )
