# terrain-runtime-proof.janet — Janet drives a real ONNX graph through FFI.
#
# WHAT THIS PROVES
# ----------------
# Janet, with no Python and no subprocess, can:
#   1. dlopen a shared library and resolve symbols          (ffi/context)
#   2. read ONNX Runtime's version through OrtGetApiBase    (proves the dylib loads)
#   3. load a real 22.5 MB ONNX graph (741 nodes, opset 17)
#   4. pass float buffers to C as pointers and read results back
#   5. run one forward pass of the real coarse model on the CPU
#   6. validate the output shape, finiteness and variation
#
# WHAT THIS DOES NOT PROVE
# -----------------------
# This is ONE forward pass of ONE of three models. There is no scheduler, no
# latent stage, no decoder, no laplacian decode, no noise field and no tile
# assembly. "Native generation works" is NOT a claim this file supports, and no
# summary of it may say so.
#
# Usage:
#   BENDER=/path/to/bender <bender> native/proof/terrain-runtime-proof.janet
#
# The `ffi/*` functions are built into bender's boot and need no import. Only the
# 8 functions in libtres.dylib are bound; ONNX Runtime is never bound directly
# (see terrain-runtime-proof.c for why).

# bender has no dirname helper: derive it from the split path, dropping the
# file component. os/dir only accepts a directory, not a file path.
(def here
  (let [parts (string/split "/" (os/realpath (dyn :current-file)))]
    (string/join (slice parts 0 (- (length parts) 1)) "/")))

(defn fail [fmt & args]
  (eprint "PROOF FAILED: " (string/format fmt ;args))
  (os/exit 1))

(defn exists? [p] (= :file (os/stat p :mode)))

#
# --- Locate artifacts -----------------------------------------------------
#
# Everything is under the gitignored tmp/ proof directory. A missing artifact is
# a hard failure with the exact path printed. A proof that quietly skips is
# worse than no proof.
#

(def proof-root (string here "/../.."))
(def tmp-root (string proof-root "/tmp/native-terrain-proof"))
(def ort-root (string tmp-root "/onnxruntime-osx-arm64-1.31.1"))

(def lib-path (string ort-root "/lib/libonnxruntime.1.31.1.dylib"))
(def shim-path (string here "/libtres.dylib"))
(def model-path (string tmp-root "/coarse_model.onnx"))

(each [label p] [["ONNX Runtime dylib" lib-path]
                 ["proof shim" shim-path]
                 ["coarse ONNX graph" model-path]]
  (unless (exists? p)
    (fail "%s missing at %s -- see native/proof/README.md" label p)))

#
# --- Bind the shim --------------------------------------------------------
#
# ffi/defbind-alias takes (C symbol, Janet name, return type, [arg-name arg-type ...]).
#

(ffi/context shim-path)

(ffi/defbind-alias tres_version        tres-version        :string [])
(ffi/defbind-alias tres_last_error     tres-last-error     :string [])
(ffi/defbind-alias tres_open           tres-open           :ptr    [model-path :string])
(ffi/defbind-alias tres_input_count    tres-input-count    :int    [rt :ptr])
(ffi/defbind-alias tres_output_count   tres-output-count   :int    [rt :ptr])
(ffi/defbind-alias tres_input_name     tres-input-name     :int    [rt :ptr i :int buf :ptr n :int])
(ffi/defbind-alias tres_close          tres-close          :void   [rt :ptr])
(ffi/defbind-alias tres_run_all        tres-run-all        :int
  [rt :ptr n :int ptrs :ptr dims :ptr ranks :ptr nbytes :ptr
   out :ptr out_cap :int written :ptr out_dims :ptr out_dims_cap :int out_rank :ptr])

#
# --- Probe 1: does the runtime load at all -------------------------------
#

(print "=== native terrain proof ===")
(def version (tres-version))
(print "onnxruntime version via OrtGetApiBase: " version)
(unless (string? version) (fail "tres_version did not return a string"))

#
# --- Probe 2: load the real graph ----------------------------------------
#

(def rt (tres-open model-path))
(when (nil? rt)
  (fail "tres_open failed: %s" (tres-last-error)))

(def n-in (tres-input-count rt))
(def n-out (tres-output-count rt))
(print (string/format "graph loaded: %d inputs, %d outputs" n-in n-out))
(unless (= n-in 7) (fail "expected 7 inputs, got %d" n-in))
(unless (= n-out 1) (fail "expected 1 output, got %d" n-out))

#
# --- Probe 3: enumerate input names from the graph -----------------------
#
# Names come from the pinned graph, not from this script, so a drift between the
# model and the harness fails here instead of at Run time.
#

(def name-buf (buffer/new-filled 128 0))
(def input-names @[])
(for i 0 n-in
  (def n (tres-input-name rt i name-buf 128))
  (when (< n 0) (fail "tres_input_name(%d) failed: %s" i (tres-last-error)))
  # string/slice on a buffer returns a string; build it from the bytes so a
  # trailing NUL or stale tail can never leak into the comparison.
  (def nm (string (string/slice name-buf 0 n)))
  (array/push input-names nm)
  (print (string/format "  input[%d] = %s" i nm)))

# `=` compares arrays by identity in Janet, not structurally, so the names are
# compared element by element.
(def expected @["x" "noise_labels" "cond_0" "cond_1" "cond_2" "cond_3" "cond_4"])
(var names-match? (= (length input-names) (length expected)))
(when names-match?
  (for i 0 (length expected)
    (unless (= (input-names i) (expected i))
      (set names-match? false))))
(unless names-match?
  (fail "input names %p != pinned expectation %p" input-names expected))

#
# --- Probe 4: one real forward pass --------------------------------------
#
# Shapes read from the exported graph's protobuf, not guessed:
#   x            float32 [2, '', '', '']   -> [1, 11, 64, 64] here (in_channels=11)
#   noise_labels float32 [2]               -> [1]
#   cond_i       float32 [2]               -> [1]  (five "float" conditioning inputs)
#   output       float32 [2, '', '', '']   -> [1, 6, 64, 64]  (out_channels=6)
#
# A deterministic input keeps a second run comparable; random input would make
# the proof unfalsifiable.
#

(def side 64)
(def in-ch 11)
(def out-ch 6)

(def x-count (* in-ch side side))
(def out-count (* out-ch side side))

(def x-buf (buffer/new-filled (* x-count 4) 0))
(for i 0 x-count
  (ffi/write :float (/ (mod (* i 37) 1000) 1000.0) x-buf (* i 4)))

(def label-buf (buffer/new-filled 4 0))
(ffi/write :float 0.5 label-buf 0)

(def cond-bufs @[])
(for i 0 5
  (def b (buffer/new-filled 4 0))
  (ffi/write :float (+ 0.1 (* i 0.05)) b 0)
  (array/push cond-bufs b))

(print (string/format "running one forward pass: x=[1,%d,%d,%d]" in-ch side side))

(def out-buf (buffer/new-filled (* out-count 4) 0))

#
# A single flat libtres entry point keeps the FFI surface to one variadic-free
# call: 8 buffers in, 1 buffer out. Each buffer is passed as :ptr, which bender
# marshals from a Janet buffer directly (verified separately with a scratch
# library before this file was written).
#

(ffi/defbind-alias tres_run tres-run :int
  [rt :ptr
   x :ptr x_len :int
   nl :ptr
   c0 :ptr c1 :ptr c2 :ptr c3 :ptr c4 :ptr
   out :ptr out_cap :int
   written :ptr])

(def written-buf (buffer/new-filled 8 0))

(def rc (tres-run rt
                  x-buf x-count
                  label-buf
                  (cond-bufs 0) (cond-bufs 1) (cond-bufs 2) (cond-bufs 3) (cond-bufs 4)
                  out-buf out-count
                  written-buf))

(when (< rc 0) (fail "tres_run failed: %s" (tres-last-error)))
(print (string/format "forward pass returned %d floats (expected %d)" rc out-count))
(unless (= rc out-count) (fail "output count %d != expected %d" rc out-count))

#
# --- Probe 5: validate the output ----------------------------------------
#
# A graph that runs but emits NaN/Inf has not been proven. A constant output is
# the signature of a graph disconnected from its weights. Both are checked.
#

(var finite 0)
(var nonfinite 0)
(var min-v 1e30)
(var max-v -1e30)
(var sum 0.0)

(for i 0 out-count
  (def v (ffi/read :float out-buf (* i 4)))
  (if (or (not= v v) (> v 1e29) (< v -1e29))
    (++ nonfinite)
    (do
      (++ finite)
      (set sum (+ sum v))
      (when (< v min-v) (set min-v v))
      (when (> v max-v) (set max-v v)))))

(print (string/format "finite=%d nonfinite=%d min=%.6f max=%.6f mean=%.6f"
                      finite nonfinite min-v max-v (/ sum (max finite 1))))

(when (> nonfinite 0)
  (fail "%d non-finite values; the graph did not compute" nonfinite))
(when (<= (- max-v min-v) 1e-12)
  (fail "output is constant (min==max); graph produced no variation"))

(tres-close rt)


#
# ==========================================================================
# Base and decoder graphs — the real operator risk
# ==========================================================================
#
# Both are driven through tres_run_all, which reads input names from the
# session and bounds-checks every count before reading a byte. No Python.
#
# Base carries the attention path. The exported graph does NOT lower it away:
# it contains 3 Einsum nodes, 38 Transpose, 38 MatMul and 1 Softmax.
# Notably `Einsum 'nhcq,nhck->nhqk'` and `'nhqk,nhck->nhcq'` SURVIVE as Einsum
# rather than becoming MatMul, so the runtime must implement Einsum. That
# contradicts an earlier expectation that matplotlib-style lowering would
# remove them; the graph is the authority and it says otherwise.
#
# The third Einsum is `'i,j->ij'`, an outer product (MPFourier).
#

(defn make-floats [n seed]
  (def b (buffer/new-filled (* n 4) 0))
  (for i 0 n
    (ffi/write :float (/ (mod (* (+ i seed) 37) 1000) 1000.0) b (* i 4)))
  b)

(defn read-float [b i] (ffi/read :float b (* i 4)))

(defn validate-output [label out-buf n]
  (var finite 0)
  (var nonfinite 0)
  (var min-v 1e30)
  (var max-v -1e30)
  (var sum 0.0)
  (for i 0 n
    (def v (read-float out-buf i))
    (if (or (not= v v) (> v 1e29) (< v -1e29))
      (++ nonfinite)
      (do
        (++ finite)
        (set sum (+ sum v))
        (when (< v min-v) (set min-v v))
        (when (> v max-v) (set max-v v)))))
  (print (string/format "  %s: n=%d finite=%d nonfinite=%d min=%.6f max=%.6f mean=%.6f"
                        label n finite nonfinite min-v max-v (/ sum (max finite 1))))
  (when (> nonfinite 0)
    (fail "%s produced %d non-finite values; the graph did not compute" label nonfinite))
  (when (<= (- max-v min-v) 1e-12)
    (fail "%s output is constant (min==max); graph produced no variation" label))
  [min-v max-v])

(defn run-graph [label model n-in shapes out-count]
  # shapes: array of arrays, one per input, each a full shape including batch=1.
  (def rt (tres-open model))
  (when (nil? rt) (fail "%s: tres_open failed: %s" label (tres-last-error)))

  # Flatten pointers, dims, ranks and byte sizes into plain buffers; tres_run_all
  # reads these positionally and validates every count itself.
  (def ptrs-buf (buffer/new-filled (* 8 8) 0))
  (def dims-buf (buffer/new-filled (* 8 4) 0))
  (def ranks-buf (buffer/new-filled (* 8 4) 0))
  (def nbytes-buf (buffer/new-filled (* 8 8) 0))

  (var total-floats 0)
  # dims are PACKED in input order (rank_0 dims, then rank_1 dims, ...), matching
  # how tres_run_all advances its own cursor. A fixed per-input stride would
  # desynchronise the two and silently feed a later input another's shape.
  (var dim-cursor 0)
  (for i 0 n-in
    (def shape (shapes i))
    (var elems 1)
    (each d shape (set elems (* elems d)))
    (def b (make-floats elems (+ 1 i)))
    (ffi/write :ptr b ptrs-buf (* i 8))
    (ffi/write :int (length shape) ranks-buf (* i 4))
    (ffi/write :long (* elems 4) nbytes-buf (* i 8))
    (for k 0 (length shape)
      (ffi/write :int (shape k) dims-buf (* (+ dim-cursor k) 4)))
    (set dim-cursor (+ dim-cursor (length shape)))
    (set total-floats (+ total-floats elems)))

  (def out-buf (buffer/new-filled (* out-count 4) 0))
  (def written-buf (buffer/new-filled 8 0))
  (def out-dims-buf (buffer/new-filled (* 4 8) 0))
  (def out-rank-buf (buffer/new-filled 4 0))

  (def rc (tres-run-all rt n-in ptrs-buf dims-buf ranks-buf nbytes-buf
                        out-buf out-count written-buf
                        out-dims-buf 4 out-rank-buf))

  (when (< rc 0) (fail "%s: tres_run_all failed: %s" label (tres-last-error)))
  (def rank (ffi/read :int out-rank-buf 0))
  (def dims-out (map |(string (ffi/read :s64 out-dims-buf (* $ 8))) (range rank)))
  (print (string/format "  %s: %d floats, out shape [%s]" label rc (string/join dims-out " ")))
  (unless (= rc out-count)
    (fail "%s: returned %d floats, expected %d" label rc out-count))

  (def stats (validate-output label out-buf out-count))
  (tres-close rt)
  stats)

(print "")
(print "=== base_model.onnx (attention: 3 Einsum, 38 MatMul, 1 Softmax) ===")
# x [1,5,64,64] (in_channels=5), noise_labels [1], cond_0 [1,58] (tensor cond)
(run-graph "base" (string tmp-root "/base_model.onnx") 3
           [@[1 5 64 64] @[1] @[1 58]]
           (* 5 64 64))

(print "")
(print "=== decoder_model.onnx (no attention) ===")
# x [1,5,64,64] (1 residual + 4 latents), noise_labels [1]
(run-graph "decoder" (string tmp-root "/decoder_model.onnx") 2
           [@[1 5 64 64] @[1]]
           (* 1 64 64))

(print "")
(print "PROOF PASSED (partial): Janet called ONNX Runtime through FFI and ran")
(print "one real forward pass of each of the three pinned graphs with real")
(print "weights on CPU: coarse, base (including the Einsum attention path),")
(print "and decoder.")
(print "")
(print "NOT yet implemented, and required before any height tile exists:")
(print "  - DPM-Solver++ scheduler and its 20-step loop")
(print "  - deterministic PCG64 noise field (bit-identity unproven)")
(print "  - Perlin/FastNoiseLite conditioning map")
(print "  - laplacian decode/denoise")
(print "  - infinite-tensor windowing, blending and tile assembly")
(print "No generation UI may claim learned terrain until those land.")
