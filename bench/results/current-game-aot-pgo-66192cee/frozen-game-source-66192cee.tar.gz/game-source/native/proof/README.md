# Native terrain proof — Janet drives ONNX Runtime through FFI

**Status: PASSED (partial).** Janet loaded all three pinned ONNX graphs and ran
one forward pass of each with real weights, on CPU, with no Python anywhere in
the call path — including `base`, which carries the Einsum attention path.

This directory proves the **calling seam and the three graphs**. It is not the
pipeline. Read §4 before quoting any of it.

---

## 1. Result

```
=== native terrain proof ===
onnxruntime version via OrtGetApiBase: 1.31.1
graph loaded: 7 inputs, 1 outputs
  input[0] = x
  input[1] = noise_labels
  input[2] = cond_0
  input[3] = cond_1
  input[4] = cond_2
  input[5] = cond_3
  input[6] = cond_4
running one forward pass: x=[1,11,64,64]
forward pass returned 24576 floats (expected 24576)
finite=24576 nonfinite=0 min=-0.644126 max=1.304985 mean=0.286760

=== base_model.onnx (attention: 3 Einsum, 38 MatMul, 1 Softmax) ===
  base: 20480 floats, out shape [1 5 64 64]
  base: n=20480 finite=20480 nonfinite=0 min=-4.503684 max=8.141014 mean=0.339547

=== decoder_model.onnx (no attention) ===
  decoder: 4096 floats, out shape [1 1 64 64]
  decoder: n=4096 finite=4096 nonfinite=0 min=-0.752527 max=0.838786 mean=0.007739
```

Two runs produce identical numbers (same min/max/mean), so the path is
deterministic for a fixed input.

## 2. What was actually downloaded

Both artifacts are pinned and were verified by size before use.

| Artifact | Size | Source |
|---|---|---|
| `coarse_model.onnx` | 22,497,125 B | `huggingface.co/xandergos/terrain-diffusion-30m-onnx` @ `ad2df557eca5645f588766101cf3bc3682455c3e` |
| `base_model.onnx` | 2,029,994,361 B | same revision, sha256 `543de788f73d0a4012685c908259f615601102aace4751aeccec64154ba145c0` |
| `decoder_model.onnx` | 223,854,143 B | same revision, sha256 `6473ae47ca6ec4d743d30fe4f5d381fe4158899714eff09b762005bdbdef68c1` |
| `pipeline_data.json` | 12,226 B | same revision |
| `world_pipeline_config.json` | 774 B | same revision |
| `onnxruntime-osx-arm64-1.31.1.tgz` | 36,936,435 B | `github.com/microsoft/onnxruntime/releases/download/v1.31.1/…` |

SHA-256 of the downloaded graph: `d6ca15b21b2e35d5e594a9ac7a4249a2376590c0ad2b5b49a1e6e2d033450008`.

All of it lives under `tmp/native-terrain-proof/`, which is gitignored. Nothing
was installed into a global environment and no Python package was added.

### Graph facts, read from the protobuf

Not inferred from documentation — parsed out of the file:

| Graph | Nodes | Initializers | Inputs | Output |
|---|---|---|---|---|
| coarse | 741 | 83 | `x[batch,11,64,64]`, `noise_labels[batch]`, `cond_0..4[batch]` | `[batch,6,64,64]` |
| base | 3328 | 304 | `x[batch,5,64,64]`, `noise_labels[batch]`, `cond_0[batch,58]` | `[batch,5,64,64]` |
| decoder | 3213 | 298 | `x[batch,5,H,W]`, `noise_labels[batch]` | `[batch,1,H,W]` |

All F32, IR 8, opset 17.

### Einsum survives export — corrected finding

The earlier audit predicted the attention `einsum` would lower to
MatMul/Transpose/Softmax with no `Einsum` op remaining. **The exported graph says
otherwise**, and the graph is the authority:

- `base_model.onnx` contains **3 `Einsum` nodes**, 38 `Transpose`, 38 `MatMul`, 1 `Softmax`
- equations: `i,j->ij` (an outer product, from `MPFourier`), and the attention pair
  `nhcq,nhck->nhqk` and `nhqk,nhck->nhcq`
- `decoder_model.onnx` contains 1 `Einsum` (`i,j->ij`)

So any runtime must implement `Einsum`, not merely conv/matmul. ONNX Runtime does,
and the base pass above exercises it. This is exactly the kind of claim that had to
be checked against the artifact rather than reasoned about.

## 3. Why a C shim exists

ONNX Runtime's C API exports exactly one symbol, `OrtGetApiBase`, which returns a
pointer to a `struct OrtApi` holding **417 function pointers**. The slot indices
are produced by `ORT_API2_STATUS(...)` and `ORT_CLASS_RELEASE(...)` macros, so
they are not even plain text in the header.

Addressing that struct from a dynamic FFI means computing `api + slot*8` by hand
and calling through an untyped pointer. It is *possible*, and the slots were in
fact extracted during this work (`CreateEnv`=3, `CreateSession`=7, `Run`=9,
`CreateTensorWithDataAsOrtValue`=49, …), but it is unverifiable: one wrong index
calls an arbitrary function with the wrong signature and aborts with no
diagnostic.

`terrain-runtime-proof.c` therefore resolves those offsets at **compile time**
against the real header and exposes 8 ordinary functions that Janet binds
directly. The proof exercises the hand-computed slot values only
indirectly — through the header, which is the correct way to depend on them.

## 3a. The full pipeline, measured

```
[1/4] coarse   3.6s   latents   -70.1 .. 1540.5   mean 220.8
[2/4] base     5.6s   latents   -2.15 .. 2.13     mean -0.08
[3/4] decoder  0.5s   residual -12.62 .. 2.75     mean -0.02
[4/4] laplacian 0.0s  elevation -3553.6 .. -1825.2 m  mean -2408.8 m
```

4096 finite floats, 3368 distinct values, bit-identical across runs
(`sha256 71301733`), 9.7 s total on CPU with 2 threads.

Stage wiring, pinned from `world_pipeline.py` and the exported graphs:

- **coarse** — `x[1,11,64,64]` = `[scaled_sample(6ch) ++ cond_img(5ch)]`,
  `noise_labels` = `atan(sigma/0.5)`, `cond_0..4` scalars; 20 DPM-Solver++ steps;
  then `/sigma_data`, denormalise with `coarse_means/coarse_stds`, and
  `ch1 = ch0 - ch1`.
- **base** — starts from **`sample = zeros`**, NOT from the coarse output. The
  coarse map enters as the 58-wide **conditioning**. Runs once at
  `T_INTER = atan(0.35/0.5)`; `pred = -base_model(...)`.
- **decoder** — `[model_in(1ch) ++ nearest_upsample(latents[0:4]/norm)(4ch)]`,
  one step at `atan(80/0.5)`.
- **laplacian** — `residual*residual_std + residual_mean`,
  `ch4*38.6 - 31.4`, decode, then `sign(x)*x^2` → metres.

Four bugs this measurement caught, none visible from reading the code:

1. the 58-wide conditioning was a constant, so base output was byte-identical
   for 4 and 20 coarse steps — the coarse work was being discarded
2. conditioning must be standardised with `COND_INPUT_MEAN/STD` **before** the
   crops; raw metre-scale values drove base ch4 to 8.8, and since elevation is
   `sign(x)*x^2` that became **107 km**
3. base starts from zero, with coarse as conditioning (see above)
4. `model_in` is `x_t/sigma_data`, so the update is
   `cos(t)*model_in - sin(t)*pred`, without an extra `/sigma_data`

A physical plausibility guard (−12000…9500 m) now refuses to emit rather than
writing a six-figure "elevation" file. It caught bug 2 before it was understood.

## 4. What this does NOT prove

This is **one forward pass of one of three models**. Explicitly not implemented:

- **the 5 scalar coarse inputs and the 58-wide base vector** — still derived from
  the coarse map with documented constants rather than upstream's exact
  standardisation path. The 5-channel conditioning MAP itself is now real and
  matches upstream to 1e-4.
- **spatial noise.** `gaussian_noise_patch` is a *tile-seeded* field keyed by
  global pixel coordinates, so neighbouring tiles agree. The native noise is
  proven bit-identical to upstream for a fixed seed and length, but the
  coordinate-seeded patch variant has not been compared.
- **tiling.** One tile, no overlapping windows, no blend weights, no
  InfiniteTensor. Upstream sums weighted overlapping windows.
- **climate channels.** Only elevation is produced; temp/precip are untouched.

So: one real metric height tile exists. A seamless infinite world does not.

## 5. Reproduce

```sh
# 1. artifacts (one time)
mkdir -p tmp/native-terrain-proof && cd tmp/native-terrain-proof
REV=ad2df557eca5645f588766101cf3bc3682455c3e
curl -fsSL -o coarse_model.onnx \
  "https://huggingface.co/xandergos/terrain-diffusion-30m-onnx/resolve/$REV/coarse_model.onnx"
curl -fsSL -O \
  "https://github.com/microsoft/onnxruntime/releases/download/v1.31.1/onnxruntime-osx-arm64-1.31.1.tgz"
tar xzf onnxruntime-osx-arm64-1.31.1.tgz

# 2. build the shim (absolute rpath: a relative one fails to resolve at dlopen)
cd ../../native/proof
O=$(cd ../../tmp/native-terrain-proof/onnxruntime-osx-arm64-1.31.1 && pwd)
clang -O2 -Wall -shared -o libtres.dylib terrain-runtime-proof.c \
  -I"$O/include" -L"$O/lib" -lonnxruntime -Wl,-rpath,"$O/lib"

# 3. run
BENDER=/path/to/bender <bender> native/proof/terrain-runtime-proof.janet
```

## 6. Gotchas found the hard way

These all cost real debugging time and are worth not rediscovering:

1. **`ffi/defbind-alias` argument order is `(C-symbol, janet-name, ret, args)`**,
   not `(janet-name, C-symbol, …)`. Reversing it yields
   `unknown symbol <janet-name>`.
2. **args are name/type pairs**: `[p :ptr n :int]`, never bare types.
3. **`ffi/read` / `ffi/write` are `(type, buffer, byte-offset)`** — the type
   comes first.
4. **A Janet buffer marshals directly as `:ptr`.** Verified independently with a
   scratch C library before this file was written.
5. **Bender's `:int` is 32-bit.** Declaring `int64_t` in C produced a length of
   `42949718016` (the low half correct, the high half reading the neighbouring
   pointer). Use `int` in the C signature for FFI-friendly lengths.
6. **`=` compares arrays by identity**, not structurally. Compare element by
   element.
7. **`(slice parts 0 -1)` did not drop the last element** in this bender build;
   use `(slice parts 0 (- (length parts) 1))`.
8. **A relative `-rpath` fails at dlopen** once the loader resolves against the
   caller's cwd. Always pass an absolute rpath.
9. **`cbrt` rounding** reported 63.9999 → 63 and rejected a valid 64-side
   tensor. Use exact integer root arithmetic for shape guards.

## 7. Next gates

Nothing here should be extended into a generator until these pass, in order:

1. ~~Base graph~~ — **done**, including the Einsum attention path.
2. ~~Decoder graph~~ — **done**.
3. **Scheduler port.** 20 steps of arithmetic; must reproduce the Python path on
   a fixed seed before any tile is trusted.
4. **Noise field.** PCG64 + Marsaglia polar must reproduce
   `gaussian_noise_patch` bit-for-bit, or nothing downstream matches.
5. **Tile assembly.** Blend weights and window overlap, matching the existing
   `InfiniteTensor` semantics (overlapping windows **sum**; the weight channel
   must survive).

Only after 1–5 does "native learned generation" become a true statement. Any
generation UI must stay unavailable until then.

## 8. Licensing

- ONNX Runtime 1.31.1 — MIT (`LICENSE` in the distribution).
- `terrain-diffusion-30m-onnx` — MIT (model card `license: mit`).
- `terrain-runtime-proof.c` and `terrain-runtime-proof.janet` — original, MIT,
  matching the project.
