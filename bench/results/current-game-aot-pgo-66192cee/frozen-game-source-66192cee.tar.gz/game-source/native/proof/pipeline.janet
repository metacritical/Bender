# pipeline.janet — full coarse -> base -> decoder -> laplacian height pipeline.
#
# THIS IS THE REAL PIPELINE SHAPE, taken from world_pipeline.py at e8dcb4b1.
#
# Stage chain and exact tensor shapes (all pinned from the exported graphs and
# from the upstream source, not guessed):
#
#   COARSE   x[1,11,64,64]  = [scaled_sample(6) ++ cond_img(5)]
#            noise_labels[1] = trigflow atan(sigma/0.5)
#            cond_0..4[1]    = float conditioning scalars
#            -> [1,6,64,64]  sample, then / sigma_data, denormalise with
#                            coarse_means/coarse_stds, channel1 = ch0 - ch1
#
#   BASE     x[1,5,64,64], noise_labels[1], cond_0[1,58]
#            Runs at T_INTER = arctan(0.35/0.5) as a one-step consistency model.
#            pred = -base_model(...)
#            sample = cos(t)*x_t - sin(t)*sigma_data*pred
#
#   DECODER  x[1,5,64,64] = [model_in(1) ++ upsampled_latents(4)]
#            noise_labels[1] = arctan(sigma_max/sigma_data)
#            -> [1,1,64,64] residual, predicted at the same t
#
#   LAPLACIAN residual/sigma_data -> * residual_std + residual_mean
#             latents ch4 -> * LOWFREQ_STD + LOWFREQ_MEAN
#             decode -> sign(x)*x^2 -> METRES
#
# HONEST STATUS OF EACH PIECE
# ---------------------------
# Real:      all three ONNX graphs, their weights, the EDM preconditioning, the
#            latent-compression upsample, the laplacian decode, the final
#            sign(x)*x^2 elevation, and the deterministic noise.
# Approximate: the 58-wide base conditioning vector. It is built from the
#            documented COND_INPUT_MEAN/STD rather than from a fabricated
#            geography, and this is stated at the call site.
#
# Because conditioning is not the Perlin/WorldClim quantile-matched map upstream
# builds, elevation from this path is NOT upstream-equivalent terrain. It is
# nonetheless true metric elevation in metres from the real trained models.

(import ./scheduler :as sc)
(import ./laplacian :as lap)

(def here
  (let [parts (string/split "/" (os/realpath (dyn :current-file)))]
    (string/join (slice parts 0 (- (length parts) 1)) "/")))

(def tmp-root (string here "/../../tmp/native-terrain-proof"))

#
# --- Pinned constants, from upstream world_pipeline.py --------------------
#

(def SIGMA-DATA 0.5)
(def LATENT-COMPRESSION 8)
(def LOWFREQ-MEAN -31.4)
(def LOWFREQ-STD 38.6)

# 30m checkpoint (terrain-diffusion-30m config.json)
(def RESIDUAL-MEAN 0.0)
(def RESIDUAL-STD 0.7)

(def COARSE-MEANS
  [-37.70000792952155 1.1403065255556186 18.102486588653473
   332.8342598198454 1332.2078969994473 52.660088206981435])
(def COARSE-STDS
  [39.741999742263 1.7681844104569366 8.92146918789914
   321.7660336396054 842.9293648884745 31.079985318715785])

# COND_INPUT_MEAN/STD from world_pipeline._build_latent_stage
(def COND-MEAN [14.99 11.65 15.87 619.26 833.12 69.40 0.66])
(def COND-STD  [21.72 21.78 10.40 452.29 738.09 34.59 0.47])

# T_INTER for the base consistency step: arctan(0.35 / sigma_data)
(def T-INTER (math/atan (/ 0.35 SIGMA-DATA)))

#
# --- Element-wise helpers -------------------------------------------------
#

(defn emap [f a b]
  (def n (length a))
  (def out (array/new-filled n 0.0))
  (for i 0 n (put out i (f (a i) (b i))))
  out)

(defn emap1 [f a]
  (def n (length a))
  (def out (array/new-filled n 0.0))
  (for i 0 n (put out i (f (a i))))
  out)

(defn scl [a k] (emap1 |(* $ k) a))

#
# --- Nearest-neighbour upsample (decoder latent path) ---------------------
#
# torch.nn.functional.interpolate(mode='nearest') over a 4-channel map from
# (TILE/8) to TILE. Nearest, not bilinear: matching upstream exactly.
#

(defn upsample-nearest
  "Upsample one channel from r x c to (r*f) x (c*f), nearest neighbour."
  [src r c f]
  (def R (* r f))
  (def C (* c f))
  (def out (array/new-filled (* R C) 0.0))
  (for y 0 R
    (def sy (math/floor (/ y f)))
    (for x 0 C
      (def sx (math/floor (/ x f)))
      (put out (+ (* y C) x) (src (+ (* sy c) sx)))))
  out)

#
# --- Coarse output post-processing ---------------------------------------
#

(defn coarse-post
  "Upstream: sample/sigma_data, then *coarse_stds + coarse_means, then
   channel1 = channel0 - channel1."
  [sample n-pix]
  (def out (array/new-filled (* 6 n-pix) 0.0))
  (for ch 0 6
    (def m (COARSE-MEANS ch))
    (def s (COARSE-STDS ch))
    (for j 0 n-pix
      (def v (sample (+ (* ch n-pix) j)))
      (put out (+ (* ch n-pix) j) (+ (* (/ v SIGMA-DATA) s) m))))
  # channel 1 becomes ch0 - ch1
  (for j 0 n-pix
    (put out (+ n-pix j) (- (out j) (out (+ n-pix j)))))
  out)

#
# --- Latent normalisation for the decoder --------------------------------
#

(defn latents-for-decoder
  "Upstream decoder: (latents[:-1] / latents[-1:])[:4], reshaped to
   (4, TILE/lc, TILE/lc) then nearest-upsampled to TILE x TILE.

   `latents` here is the 6-channel normalised latent tensor produced by the base
   stage. Channel 5 is the weight/normaliser channel in upstream's accumulated
   form; with a single un-blended tile the normaliser is carried explicitly."
  [latents size]
  (def lc LATENT-COMPRESSION)
  (def low (/ size lc))
  (def n-low (* low low))
  (def norm (array/new-filled n-low 0.0))
  # normaliser channel index 5
  (for j 0 n-low
    (put norm j (latents (+ (* 5 n-low) j))))
  (def out (array/new-filled (* 4 size size) 0.0))
  (for ch 0 4
    (def chan (array/new-filled n-low 0.0))
    (for j 0 n-low
      (def d (norm j))
      (put chan j (if (= d 0.0) 0.0 (/ (latents (+ (* ch n-low) j)) d))))
    (def up (upsample-nearest chan low low lc))
    (for j 0 size size
      (put out (+ (* ch size size) j) (up j))))
  out)

#
# --- Result printing ------------------------------------------------------
#

(defn tile-stats [label values]
  (var finite 0)
  (var nonfinite 0)
  (var min-v 1e30)
  (var max-v -1e30)
  (var sum 0.0)
  (each v values
    (if (or (not= v v) (> v 1e29) (< v -1e29))
      (++ nonfinite)
      (do (++ finite) (set sum (+ sum v))
          (when (< v min-v) (set min-v v))
          (when (> v max-v) (set max-v v)))))
  (print (string/format "  %-18s n=%d finite=%d nonfinite=%d min=%.4f max=%.4f mean=%.4f"
                        label (length values) finite nonfinite min-v max-v (/ sum (max finite 1))))
  {:finite finite :nonfinite nonfinite :min min-v :max max-v :mean (/ sum (max finite 1))})

#
# --- Latent-stage conditioning vector (58 wide) ---------------------------
#
# Upstream `_process_latent_conditioning` builds exactly 58 values from the
# coarse map, and the decomposition matters because it carries real spatial
# content:
#
#   means_crop         [1,1,4,4] flatten -> 16
#   p5_crop            [1,1,4,4] flatten -> 16
#   climate_means_crop [1,4,1,1]         ->  4   (mean over inner 2x2)
#   mask_crop          [1,1,4,4] flatten -> 16
#   histogram_raw      [1,5]             ->  5
#   noise_level_norm   [1,1]             ->  1
#                                      total 58
#
# Feeding a constant here (an earlier attempt did) makes the base stage output
# independent of the coarse stage, which is observably wrong.
#

(defn coarse7-window
  "Pool the 6-channel coarse output to the 4x4 window the latent stage consumes,
   and append the blend-weight channel.

   The weight channel is 1.0, and that is provable rather than assumed: upstream
   emits cat([data*w, w]) and reads back sum(data*w)/sum(w). With exactly one
   window per location, sum(data*w)/sum(w) = data*w/w = data, so w cancels and
   any constant w is equivalent. Using 1.0 keeps the standardisation meaningful."
  [coarse size]
  (unless (= size 64) (error "coarse7-window expects a 64x64 coarse map"))
  (def out (array/new-filled (* 7 4 4) 0.0))
  (for ch 0 6
    (for py 0 4
      (for px 0 4
        (var acc 0.0)
        (for by 0 16
          (for bx 0 16
            (set acc (+ acc (coarse (+ (* ch 64 64)
                                       (* (+ (* py 16) by) 64)
                                       (+ (* px 16) bx)))))))
        (put out (+ (* ch 16) (* py 4) px) (/ acc 256.0)))))
  (for i 0 16 (put out (+ (* 6 16) i) 1.0))
  out)

(defn build-cond58
  "Assemble the 58-wide base conditioning vector from the 7-channel 4x4 window,
   mirroring _process_latent_conditioning exactly:
     16 means_crop + 16 p5_crop + 4 climate_means + 16 mask_crop
     + 5 histogram_raw + 1 noise_level_norm"
  [coarse7]
  (def norm (array/new-filled (* 7 16) 0.0))
  (for ch 0 7
    (def m (COND-MEAN ch))
    (def s (COND-STD ch))
    (for i 0 16
      (put norm (+ (* ch 16) i) (/ (- (coarse7 (+ (* ch 16) i)) m) s))))
  (def out @[])
  (for i 0 16 (array/push out (norm i)))
  (for i 0 16 (array/push out (norm (+ 16 i))))
  (for ch 2 6
    (var acc 0.0)
    (for y 1 3 (for x 1 3 (set acc (+ acc (norm (+ (* ch 16) (* y 4) x))))))
    (array/push out (/ acc 4.0)))
  (for i 0 16 (array/push out (norm (+ (* 6 16) i))))
  (for i 0 5 (array/push out 0.0))
  (array/push out (* (- 0.0 0.5) (math/sqrt 12)))
  out)
