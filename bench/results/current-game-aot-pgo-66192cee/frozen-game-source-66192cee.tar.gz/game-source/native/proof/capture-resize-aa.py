#!/usr/bin/env python3
"""BUILD-TIME ORACLE ONLY. CPU torchvision, no model, no GPU, no weights.

Captures torchvision.transforms.functional.resize(antialias=True) for small
BILINEAR DOWNSAMPLE cases, so the native implementation can be checked against
the real library instead of a reimplementation of its filter.

Deterministic inputs, 8x8 float32:
  - impulse: a single 1.0 at an OFF-CENTRE pixel, zero elsewhere. Its response is
    the filter footprint, so any weighting error shows up directly.
  - checker: a PHASED checkerboard (alternating 0/1) which aliases badly without
    antialiasing, so it discriminates antialias=on from antialias=off.

Written to fixtures/resize-aa.json. Nothing here is a model or an inference:
torchvision resize on an in-memory tensor.
"""
import hashlib
import json
import os
import sys

import torch
import torchvision.transforms.functional as TF

H = W = 8
OUTS = [(3, 3), (5, 5), (4, 4)]


def impulse(oy, ox):
    t = torch.zeros(1, 1, H, W, dtype=torch.float32)
    t[0, 0, oy, ox] = 1.0
    return t


def checker(phase):
    t = torch.zeros(1, 1, H, W, dtype=torch.float32)
    for y in range(H):
        for x in range(W):
            t[0, 0, y, x] = float((x + y + phase) % 2)
    return t


def run(name, tensor, oh, ow):
    out = TF.resize(tensor, [oh, ow], interpolation=TF.InterpolationMode.BILINEAR,
                    antialias=True)
    return {
        "case": name, "in_h": H, "in_w": W, "out_h": oh, "out_w": ow,
        "in": [round(float(v), 9) for v in tensor.flatten().tolist()],
        "out": [round(float(v), 9) for v in out.flatten().tolist()],
    }


def main():
    cases = []
    cases.append(run("impulse_offcentre_3x3", impulse(1, 6), 3, 3))
    cases.append(run("impulse_corner_3x3", impulse(0, 0), 3, 3))
    cases.append(run("impulse_offcentre_5x5", impulse(2, 5), 5, 5))
    cases.append(run("checker_phase0_3x3", checker(0), 3, 3))
    cases.append(run("checker_phase1_3x3", checker(1), 3, 3))
    cases.append(run("impulse_offcentre_4x4", impulse(3, 6), 4, 4))
    doc = {
        "_note": "torchvision resize BILINEAR antialias=True, CPU float32. "
                 "Build-time oracle: no model, no GPU, no weights.",
        "torch": torch.__version__,
        "torchvision": __import__("torchvision").__version__,
        "in_h": H, "in_w": W,
        "cases": cases,
    }
    path = "native/proof/fixtures/resize-aa.json"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as fh:
        json.dump(doc, fh, indent=1)
    with open(path, "rb") as fh:
        sha = hashlib.sha256(fh.read()).hexdigest()
    print(json.dumps({"cases": len(cases), "sha256": sha, "path": path}, indent=1))


if __name__ == "__main__":
    sys.exit(main())
