# PLAN.md addition — Phase 17f, the temporary Python provider (IN PROGRESS)

Read-only documentation work in `/Users/pankajdoharey/Development/Projects/ML/trinecraft`.
Touch **only** `docs/PLAN.md`. No source, tool, or test edits; no subprocess; no
model; no GPU.

## Constraint

PLAN.md documents 22 phases plus 10, 11a, 11c, 11d and 17a–e. Every one must be
preserved verbatim. The addition is one new subsection under `### 17a` and one
amended sentence in the cross-phase shipping gate. Nothing is renumbered,
shortened, or marked done that is not done.

## Content to add

### 17f — Temporary Python provider — IN PROGRESS, not done

- **What it is.** A real implementation today: the pinned upstream
  `WorldPipeline` runs in a Python child process and exports a scenic format-3
  cache the existing Janet reader already consumes. It reimplements no inference
  and invents no second artifact format.
- **Why temporary.** The user has authorized a Python dependency for New Game
  during this milestone. It is removed once native generation is verified. It is
  an explicit, named dependency — **not** part of the shipping gate and **not**
  evidence of completion.
- **Readiness/contract facts**, each checkable in the repository:
  - `--check` reports offline readiness and writes nothing.
  - Stages are discrete and `READY` is written only after the artifact is
    re-read and every tile decodes: no synthetic percentage, no ETA.
  - An inert Janet progress sidecar (`a5139c2`), because the provider's JSON on
    stderr cannot be polled without blocking on a pipe.
  - One directly owned child, cancellable, SOLE writer, with a bounded
    progress-file reader (`src/generation-job.janet`).
- **Known limitations, stated rather than smoothed over:**
  - **Finite, not infinite.** `--size` defaults to 128 and caps at 512; one
    bounded rectangle, one `get`, one export.
  - The default origin `(100000, 100000)` is a location known to be land.
  - **Seed mapping is a recorded collision.** World seed 0 maps to model seed
    2147483647 under `SEED_MAPPING_VERSION = "nonzero-v1"`, because upstream
    substitutes a random world for a falsy seed. World seeds 0 and 2147483647
    therefore sample identical terrain — deliberate and versioned, not aliasing.
- **NOT yet true, and not claimed:** no real generation has been run through the
  New Game path end to end. The safety module, the catalogue wiring and the
  `main.janet` integration are **in progress** by separate owners
  (`src/generation-job.janet`, catalogue `d9`, `main.janet` WIP).

### Native provider — unchanged, and paused

The learned native provider stays **`available false`**. Exact coarse and solver
stage mismatches remain, and native inference is **paused after the user closed
three rogue processes**. No new native generation happens until one owned,
cancellable job with strict reaping and bounded concurrency exists.

### Shipping gate — amend one paragraph

State that the gate's requirement is **final Python-free** generation, and that
the temporary provider is a named dependency that does not satisfy it. The gate
is not met by the temporary provider.

## Verification before commit

- `git diff --stat` shows `docs/PLAN.md` and nothing else.
- All 22 phase headings plus 10, 11a, 11c, 11d, 17a–e still present.
- No sentence claims the temporary provider works end to end, that native
  generation works, or that the shipping gate is met.
- One atomic docs commit; no further iterations on this file.
