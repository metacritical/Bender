# The core janet library
# Copyright 2026 © Calvin Rose

###
###
### Macros and Basic Functions
###
###

(setdyn :optimize 1)

(def defn :macro :flycheck
  ```
  (defn name & more)

  Define a function. Equivalent to `(def name (fn name [args] ...))`.

  Optional Clojure-style type hints are accepted for ahead-of-time
  compilation: a `^type` symbol before the argvector hints the return
  type, and `^type` before a parameter symbol hints that parameter
  (positional; unmarked parameters read as `:number`). Hinted values
  (`:long`, `:double`) may be unboxed by an AOT compiler; without
  hints everything stays boxed. Hints are collected into a
  `{:hint ...}` metadata entry on the binding.

  (defn f ^long [x ^double y] ...)   # returns :long, y is :double
  ```
  (fn defn [name & more]
    (def len (length more))
    (def modifiers @[])
    (var docstr "")
    (var ret-hint nil)
    (def fstart
      (fn recur [i]
        (def {i ith} more)
        (def t (type ith))
        (if (= t :tuple)
          i
          (do
            (if (= t :symbol)
              (if (= 94 (get (string ith) 0))
                # ^type or ^:type before the argvector hints the return type
                (do (var nm (string/slice (string ith) 1))
                  (if (= 58 (get nm 0)) (set nm (string/slice nm 1)))
                  # :float is an alias for :double (janet numbers are doubles)
                  (def k (keyword nm))
                  (set ret-hint (if (= k :float) :double k)))
                nil)
              nil)
            (if (= t :string)
              (set docstr ith)
              (if (= t :symbol)
                nil
                (array/push modifiers ith)))
            (if (< i len) (recur (+ i 1)))))))
    (def start (fstart 0))
    # Strip ^type hint symbols out of the arglist: [x ^long y] binds
    # two parameters, x (unhinted) and y (:long). Every parameter gets
    # a positional hint entry, `:number` when unmarked.
    (def raw-args (in more start))
    (def pargs @[])
    (def param-hints @[])
    (var ai 0)
    (while (< ai (length raw-args))
      (def a (in raw-args ai))
      (if (= :symbol (type a))
        (if (= 94 (get (string a) 0))
          (do
            # hinted param: the hint entry IS the param's slot entry
            (var nm (string/slice (string a) 1))
            (if (= 58 (get nm 0)) (set nm (string/slice nm 1)))
            (def k (keyword nm))
            (array/push param-hints (if (= k :float) :double k))
            (set ai (+ ai 1))
            (array/push pargs (in raw-args ai))
            (set ai (+ ai 1)))
          (do
            (array/push pargs a)
            (array/push param-hints :number)
            (set ai (+ ai 1))))
        (do
          (array/push pargs a)
          (array/push param-hints :number)
          (set ai (+ ai 1)))))
    (var hinted false)
    (var hi 0)
    (while (< hi (length param-hints))
      (if (not= (in param-hints hi) :number) (set hinted true))
      (set hi (+ hi 1)))
    (if (if hinted true ret-hint)
      (do
        (def hm @{})
        (if hinted (put hm :params (tuple ;param-hints)) nil)
        (if ret-hint (put hm :returns ret-hint) nil)
        # def metadata accepts structs (a table here is rejected by the
        # compiler's attribute handling)
        (array/push modifiers (struct :hint hm)))
      nil)
    # Add function signature to docstring
    (var index 0)
    (def arglen (length pargs))
    (def buf (buffer "(" name))
    (while (< index arglen)
      (buffer/push-string buf " ")
      (buffer/format buf "%j" (in pargs index))
      (set index (+ index 1)))
    (array/push modifiers (string buf ")\n\n" docstr))
    (if (dyn :debug) (array/push modifiers {:source-form (dyn :macro-form)}))
    # Build return value
    ~(def ,name ,;modifiers (fn ,name ,(tuple ;pargs) ,;(tuple/slice more (+ start 1))))))

(defn defmacro :macro :flycheck
  "Define a macro."
  [name & more]
  (apply defn name :macro more))

(defmacro as-macro
  ``
  Use a function or macro literal `f` as a macro. This allows any
  function to be used as a macro. Inside a quasiquote, the idiom
  `(as-macro ,my-custom-macro arg1 arg2...)` can be used to avoid
  unwanted variable capture of `my-custom-macro`.
  ``
  [f & args]
  (f ;args))

(defmacro defmacro- :flycheck
  "Define a private macro that will not be exported."
  [name & more]
  (apply defn name :macro :private more))

(defmacro defn- :flycheck
  "Define a private function that will not be exported."
  [name & more]
  (apply defn name :private more))

(defmacro def-
  "Define a private value that will not be exported."
  [name & more]
  ~(def ,name :private ,;more))

(defmacro var-
  "Define a private var that will not be exported."
  [name & more]
  ~(var ,name :private ,;more))

(defmacro toggle
  "Set a value to its boolean inverse. Same as `(set value (not value))`."
  [value]
  ~(set ,value (,not ,value)))

(defn defglobal
  "Dynamically create a global def."
  [name value]
  (def name* (symbol name))
  (setdyn name* @{:value value})
  nil)

(defn varglobal
  "Dynamically create a global var."
  [name init]
  (def name* (symbol name))
  (setdyn name* @{:ref @[init]})
  nil)

# Basic predicates
(defn nan? "Check if x is NaN." [x] (not= x x))
(defn number? "Check if x is a number." [x] (= (type x) :number))
(defn fiber? "Check if x is a fiber." [x] (= (type x) :fiber))
(defn string? "Check if x is a string." [x] (= (type x) :string))
(defn symbol? "Check if x is a symbol." [x] (= (type x) :symbol))
(defn keyword? "Check if x is a keyword." [x] (= (type x) :keyword))
(defn buffer? "Check if x is a buffer." [x] (= (type x) :buffer))
(defn function? "Check if x is a function (not a cfunction)." [x] (= (type x) :function))
(defn cfunction? "Check if x is a cfunction." [x] (= (type x) :cfunction))
(defn table? "Check if x is a table." [x] (= (type x) :table))
(defn struct? "Check if x is a struct." [x] (= (type x) :struct))
(defn array? "Check if x is an array." [x] (= (type x) :array))
(defn tuple? "Check if x is a tuple." [x] (= (type x) :tuple))
(defn boolean? "Check if x is a boolean." [x] (= (type x) :boolean))
(defn truthy? "Check if x is truthy." [x] (if x true false))
(defn true? "Check if x is true." [x] (= x true))
(defn false? "Check if x is false." [x] (= x false))
(defn nil? "Check if x is nil." [x] (= x nil))
(defn empty? "Check if an iterable, `iter`, is empty." [iter] (= nil (next iter nil)))

# For macros, we define an incomplete odd? function that will be overridden.
(defn odd? [x] (= 1 (mod x 2)))

(def- non-atomic-types
  {:array true
   :tuple true
   :table true
   :buffer true
   :symbol true
   :struct true})

(defn idempotent?
  "Check if x is a value that evaluates to itself when compiled."
  [x]
  (not (in non-atomic-types (type x))))

# C style macros and functions for imperative sugar. No bitwise though.
(defn inc "Returns x + 1." [x] (+ x 1))
(defn dec "Returns x - 1." [x] (- x 1))
(defmacro ++ "Increments the var x by 1." [x] ~(set ,x (,+ ,x ,1)))
(defmacro -- "Decrements the var x by 1." [x] ~(set ,x (,- ,x ,1)))
(defmacro += "Shorthand for (set x (+ x ;ns))." [x & ns] ~(set ,x (,+ ,x ,;ns)))
(defmacro -= "Shorthand for (set x (- x ;ns))." [x & ns] ~(set ,x (,- ,x ,;ns)))
(defmacro *= "Shorthand for (set x (* x ;ns))." [x & ns] ~(set ,x (,* ,x ,;ns)))
(defmacro /= "Shorthand for (set x (/ x ;ns))." [x & ns] ~(set ,x (,/ ,x ,;ns)))
(defmacro %= "Shorthand for (set x (% x ;ns))." [x & ns] ~(set ,x (,% ,x ,;ns)))

(defmacro assert :flycheck # should top level assert flycheck?
  "Throw an error if x is not truthy. Will not evaluate `err` if x is truthy."
  [x &opt err]
  (def v (gensym))
  ~(do
     (def ,v ,x)
     (if ,v
       ,v
       (,error ,(if err err (string/format "assert failure in %j" x))))))

(defmacro defdyn :flycheck
  ``Define an alias for a keyword that is used as a dynamic binding. The
  alias is a normal, lexically scoped binding that can be used instead of
  a keyword to prevent typos. `defdyn` does not set dynamic bindings or otherwise
  replace `dyn` and `setdyn`. The alias *must* start and end with the `*` character, usually
  called "earmuffs".``
  [alias & more]
  (assert (symbol? alias) "alias must be a symbol")
  (assert (> (length alias) 2) "name must have leading and trailing '*' characters")
  (assert (= 42 (get alias 0) (get alias (- (length alias) 1))) "name must have leading and trailing '*' characters")
  (def prefix (dyn :defdyn-prefix))
  (def kw (keyword prefix (slice alias 1 -2)))
  ~(def ,alias :dyn ,;more ,kw))

(defdyn *macro-form*
  "Inside a macro, is bound to the source form that invoked the macro")

(defdyn *flychecking*
  "Check if the current form is being evaluated inside `flycheck`. Will be `true` while flychecking.")

(defdyn *lint-error*
  "The current lint error level. The error level is the lint level at which compilation will exit with an error and not continue.")

(defdyn *lint-warn*
  "The current lint warning level. The warning level is the lint level at which an error will be printed but compilation will continue as normal.")

(defdyn *lint-levels*
  "A table of keyword alias to numbers denoting a lint level. Can be used to provided custom aliases for numeric lint levels.")

(defdyn *macro-lints*
  ``Bound to an array of lint messages that will be reported by the compiler inside a macro.
  To indicate an error or warning, a macro author should use `maclintf`.``)

(defn maclintf
  ``When inside a macro, call this function to add a linter warning. Takes
  a `fmt` argument like `string/format`, which is used to format the message.``
  [level fmt & args]
  (def lints (dyn *macro-lints*))
  (if lints
    (do
      (def form (dyn *macro-form*))
      (def [l c] (if (tuple? form) (tuple/sourcemap form) [nil nil]))
      (def l (if (not= -1 l) l))
      (def c (if (not= -1 c) c))
      (def msg (string/format fmt ;args))
      (array/push lints [level l c msg])))
  nil)

(defn errorf
  "A combination of `error` and `string/format`. Equivalent to `(error (string/format fmt ;args))`."
  [fmt & args]
  (error (string/format fmt ;args)))

(defmacro assertf
  "Convenience macro that combines `assert` and `string/format`."
  [x fmt & args]
  (def v (gensym))
  ~(do
     (def ,v ,x)
     (if ,v
       ,v
       (,errorf ,fmt ,;args))))

(defmacro default
  ``Define a default value for an optional argument.
  Expands to `(def sym :shadow (if (= nil sym) val sym))`.``
  [sym val]
  ~(def ,sym :shadow (if (,= nil ,sym) ,val ,sym)))

(defmacro comment
  "Ignores the body of the comment."
  [&])

(defmacro if-not
  "Shorthand for `(if (not condition) else then)`."
  [condition then &opt else]
  ~(if ,condition ,else ,then))

(defmacro when
  "Evaluates the body when the condition is true. Otherwise returns nil."
  [condition & body]
  ~(if ,condition (do ,;body)))

(defmacro unless
  "Shorthand for `(when (not condition) ;body)`. "
  [condition & body]
  ~(if ,condition nil (do ,;body)))

(defmacro cond
  ``
  Evaluates conditions sequentially until the first true condition is
  found, and then executes the corresponding body. If there are an odd
  number of forms, and no forms are matched, the last expression is
  executed. If there are no matches, returns nil.
  ``
  [& clauses]
  (defn aux [i]
    (def restlen (- (length clauses) i))
    (if (= restlen 0) nil
      (if (= restlen 1) (in clauses i)
        (tuple 'if (in clauses i)
               (in clauses (+ i 1))
               (aux (+ i 2))))))
  (aux 0))

(defmacro case
  ``
  Select the body that equals the `dispatch` value. When `clauses` has
  an odd number of elements, the last is the default expression. If no
  match is found, returns nil.
  ``
  [dispatch & clauses]
  (def atm (idempotent? dispatch))
  (def sym (if atm dispatch (gensym)))
  (defn aux [i]
    (def restlen (- (length clauses) i))
    (if (= restlen 0) nil
      (if (= restlen 1) (in clauses i)
        (tuple 'if (tuple = sym (in clauses i))
               (in clauses (+ i 1))
               (aux (+ i 2))))))
  (if atm
    (aux 0)
    (tuple 'do
           (tuple 'def sym dispatch)
           (aux 0))))

(defmacro let
  ``Create a scope and bind values to symbols. Each pair in `bindings` is
  assigned as if with `def`, and the body of the `let` form returns the last
  value.``
  [bindings & body]
  (if (odd? (length bindings)) (error "expected even number of bindings to let"))
  (def len (length bindings))
  (var i 0)
  (var accum @['do])
  (while (< i len)
    (def {i k (+ i 1) v} bindings)
    (array/push accum (tuple 'def k v))
    (+= i 2))
  (array/concat accum body)
  (tuple/slice accum 0))

(defmacro protect
  `Evaluate expressions, while capturing any errors. Evaluates to a tuple
  of two elements. The first element is true if successful, false if an
  error, and the second is the return value or error.`
  [& body]
  (let [f (gensym) r (gensym)]
    ~(let [,f (,fiber/new (fn :protect [] ,;body) :ie)
           ,r (,resume ,f)]
       [(,not= :error (,fiber/status ,f)) ,r])))

(defmacro and
  `Evaluates to the last argument if all preceding elements are truthy, otherwise
  evaluates to the first falsey argument.`
  [& forms]
  (var ret true)
  (def len (length forms))
  (var i len)
  (while (> i 0)
    (-- i)
    (def v (in forms i))
    (set ret (if (= i (- len 1))
               v
               (if (idempotent? v)
                 ['if v ret v]
                 (do (def s (gensym))
                   ['if ['def s v] ret s])))))
  ret)

(defmacro or
  `Evaluates to the last argument if all preceding elements are falsey, otherwise
  evaluates to the first truthy element.`
  [& forms]
  (def len (length forms))
  (var i (- len 1))
  (var ret (get forms i))
  (while (> i 0)
    (-- i)
    (def fi (in forms i))
    (set ret (if (idempotent? fi)
               (tuple 'if fi fi ret)
               (do
                 (def $fi (gensym))
                 (tuple 'do (tuple 'def $fi fi)
                        (tuple 'if $fi $fi ret))))))
  ret)

(defmacro try
  ``Try something and catch errors. `body` is any expression,
  and `catch` should be a form, the first element of which is a tuple. This tuple
  should contain a binding for errors and an optional binding for
  the fiber wrapping the body. Returns the result of `body` if no error,
  or the result of `catch` if an error.``
  [body catch]
  (assert (and (not (empty? catch)) (indexed? (catch 0))) "the first element of `catch` must be a tuple or array")
  (let [[err fib] (catch 0)
        r (gensym)
        f (gensym)]
    ~(let [,f (,fiber/new (fn :try [] ,body) :ie)
           ,r (,resume ,f)]
       (if (,= (,fiber/status ,f) :error)
         (do
           ,(if err ~(def ,err ,r))
           ,(if fib ~(def ,fib ,f))
           ,;(tuple/slice catch 1))
         ,r))))

(defmacro with-syms
  "Evaluates `body` with each symbol in `syms` bound to a generated, unique symbol."
  [syms & body]
  (var i 0)
  (def len (length syms))
  (def accum @[])
  (while (< i len)
    (array/push accum (in syms i) [gensym])
    (++ i))
  ~(let (,;accum) ,;body))

(defn- defer-impl
  "Defer but allow custom name for stack traces"
  [name form body]
  (with-syms [f r]
    ~(do
       (def ,f (,fiber/new (fn ,name [] ,;body) :ti))
       (def ,r (,resume ,f))
       ,form
       (if (= (,fiber/status ,f) :dead)
         ,r
         (,propagate ,r ,f)))))

(defmacro defer
  ``Run `form` unconditionally after `body`, even if the body throws an error.
  Will also run `form` if a user signal 0-4 is received.``
  [form & body]
  (defer-impl :defer form body))

(defmacro edefer
  ``Run `form` after `body` in the case that body terminates abnormally (an error or user signal 0-4).
  Otherwise, return last form in `body`.``
  [form & body]
  (with-syms [f r]
    ~(do
       (def ,f (,fiber/new (fn :edefer [] ,;body) :ti))
       (def ,r (,resume ,f))
       (if (= (,fiber/status ,f) :dead)
         ,r
         (do ,form (,propagate ,r ,f))))))

(defmacro prompt
  ``Set up a checkpoint that can be returned to. `tag` should be a value
  that is used in a `return` statement, like a keyword.``
  [tag & body]
  (with-syms [res target payload fib]
    ~(do
       (def ,fib (,fiber/new (fn :prompt [] [,tag (do ,;body)]) :i0))
       (def ,res (,resume ,fib))
       (def [,target ,payload] ,res)
       (if (,= ,tag ,target)
         ,payload
         (,propagate ,res ,fib)))))

(defmacro chr
  `Convert a string of length 1 to its byte (ascii) value at compile time.`
  [c]
  (unless (and (string? c) (= (length c) 1))
    (error (string/format "expected string of length 1, got %v" c)))
  (c 0))

(defmacro label
  ``Set a label point that is lexically scoped. `name` should be a symbol
  that will be bound to the label.``
  [name & body]
  ~(do
     (def ,name @"")
     ,(apply prompt name body)))

(defn return
  "Return to a prompt point."
  [to &opt value]
  (signal 0 [to value]))

(defmacro with
  ``Evaluate `body` with some resource, which will be automatically cleaned up
  if there is an error in `body`. `binding` is bound to the expression `ctor`, and
  `dtor` is a function or callable that is passed the binding. If no destructor
  (`dtor`) is given, will call :close on the resource.``
  [[binding ctor dtor] & body]
  ~(do
     (def ,binding ,ctor)
     ,(defer-impl :with [(or dtor :close) binding] body)))

# declare ahead of time
(var- macexvar nil)

(defmacro if-let
  ``Make multiple bindings, and if all are truthy,
  evaluate the `tru` form. If any are false or nil, evaluate
  the `fal` form. Bindings have the same syntax as the `let` macro.``
  [bindings tru &opt fal]
  (def len (length bindings))
  (if (= 0 len) (error "expected at least 1 binding"))
  (if (odd? len) (error "expected an even number of bindings"))
  (def fal2 (if macexvar (macexvar fal) fal))
  (defn aux [i]
    (if (>= i len)
      tru
      (do
        (def bl (in bindings i))
        (def br (in bindings (+ 1 i)))
        (if (symbol? bl)
          ~(if (def ,bl ,br) ,(aux (+ 2 i)) ,fal2)
          ~(if (def ,(def sym (gensym)) ,br)
             (do (def ,bl ,sym) ,(aux (+ 2 i)))
             ,fal2)))))
  (aux 0))

(defmacro when-with
  ``Similar to with, but if binding is false or nil, returns
  nil without evaluating the body. Otherwise, the same as `with`.``
  [[binding ctor dtor] & body]
  ~(as-macro ,if-let [,binding ,ctor]
             ,(defer-impl :when-with [(or dtor :close) binding] body)))

(defmacro if-with
  ``Similar to `with`, but if binding is false or nil, evaluates
  the falsey path. Otherwise, evaluates the truthy path. In both cases,
  `ctor` is bound to binding.``
  [[binding ctor dtor] truthy &opt falsey]
  ~(as-macro ,if-let [,binding ,ctor]
             ,(defer-impl :if-with [(or dtor :close) binding] [truthy])
             ,falsey))

(defn- for-var-template
  [i start stop step comparison delta body]
  (with-syms [s]
    (def st (if (idempotent? step) step (gensym)))
    (def loop-body
      ~(while (,comparison ,i ,s)
         ,;body
         (set ,i (,delta ,i ,st))))
    ~(do
       (var ,i ,start)
       (def ,s ,stop)
       ,;(if (= st step) [] [~(def ,st ,step)])
       ,(if (and (number? st) (> st 0))
          loop-body
          ~(if (,> ,st 0) ,loop-body)))))

(defn- for-template
  [binding start stop step comparison delta body]
  (def i (gensym))
  (for-var-template i start stop step comparison delta
                    [~(def ,binding ,i) ;body]))

(defn- check-indexed [x]
  (if (indexed? x)
    x
    (error (string "expected tuple for range, got " x))))

(defn- range-template
  [binding object kind rest op comparison]
  (check-indexed object)
  (def [a b c] object)
  (def [start stop step]
    (case (length object)
      1 (case kind :range [0 a 1] :down [a 0 1])
      2 [a b 1]
      [a b c]))
  (for-template binding start stop step comparison op [rest]))

(defn- each-template
  [binding inx kind body]
  (with-syms [k]
    (def ds (if (idempotent? inx) inx (gensym)))
    ~(do
       ,(unless (= ds inx) ~(def ,ds ,inx))
       (var ,k (,next ,ds nil))
       (while (,not= nil ,k)
         (def ,binding
           ,(case kind
              :each ~(,in ,ds ,k)
              :keys k
              :pairs ~[,k (,in ,ds ,k)]))
         ,;body
         (set ,k (,next ,ds ,k))))))

(defn- iterate-template
  [binding expr body]
  (with-syms [i]
    ~(do
       (var ,i nil)
       (while (set ,i ,expr)
         (def ,binding ,i)
         ,body))))

(defn- loop1
  [body head i]

  # Terminate recursion
  (when (<= (length head) i)
    (break ~(do ,;body)))

  (def {i binding
        (+ i 1) verb} head)

  # 2 term expression
  (when (keyword? binding)
    (break
      (let [rest (loop1 body head (+ i 2))]
        (case binding
          :until ~(do (if ,verb (break) nil) ,rest)
          :while ~(do (if ,verb nil (break)) ,rest)
          :let ~(as-macro ,let ,verb (do ,rest))
          :after ~(do ,rest ,verb nil)
          :before ~(do ,verb ,rest nil)
          :repeat (with-syms [iter]
                    ~(do (var ,iter ,verb) (while (,> ,iter 0) ,rest (as-macro ,-- ,iter))))
          :when ~(as-macro ,when ,verb ,rest)
          :unless ~(as-macro ,unless ,verb ,rest)
          (error (string "unexpected loop modifier " binding))))))

  # 3 term expression
  (def {(+ i 2) object} head)
  (let [rest (loop1 body head (+ i 3))]
    (case verb
      :range (range-template binding object :range rest + <)
      :range-to (range-template binding object :range rest + <=)
      :down (range-template binding object :down rest - >)
      :down-to (range-template binding object :down rest - >=)
      :keys (each-template binding object :keys [rest])
      :pairs (each-template binding object :pairs [rest])
      :in (each-template binding object :each [rest])
      :iterate (iterate-template binding object rest)
      (error (string "unexpected loop verb " verb)))))

(defmacro forv
  ``Do a C-style for-loop for side effects. The iteration variable `i`
  can be mutated in the loop, unlike normal `for`. Returns nil.``
  [i start stop & body]
  (for-var-template i start stop 1 < + body))

(defmacro for
  "Do a C-style for-loop for side effects. Returns nil."
  [i start stop & body]
  (for-template i start stop 1 < + body))

(defmacro eachk
  ``
  Loop over each key in `x` with each key bound to `binding` with
  destructuring support. Returns `nil`.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with a suitable `next` method.
  ``
  [binding x & body]
  (each-template binding x :keys body))

(defmacro eachp
  ``
  Loop over each (key, value) pair in `x` with each pair bound to
  `binding` with destructuring support. Returns `nil`.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [binding x & body]
  (each-template binding x :pairs body))

(defmacro each
  ``
  Loop over each value in `x` with each value of `x` bound to
  `binding` with destructuring support. Returns `nil`.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [binding x & body]
  (each-template binding x :each body))

(defmacro repeat
  "Evaluate body n times. If n is negative, body will be evaluated 0 times. Evaluates to nil."
  [n & body]
  (with-syms [iter]
    ~(do (var ,iter ,n) (while (,> ,iter 0) ,;body (as-macro ,-- ,iter)))))

(defmacro forever
  "Evaluate body forever in a loop, or until a break statement."
  [& body]
  ~(while true ,;body))

(defn- check-empty-body
  [body]
  (if (= (length body) 0)
    (maclintf :normal "empty loop body")))

(defmacro loop
  ``
  A general purpose loop macro. This macro is similar to the Common
  Lisp `loop` macro, although intentionally much smaller in scope.

  The first argument, `head`, should be a tuple that contains a
  sequence of either bindings or conditionals. A binding is a sequence
  of three values that define something to loop over. Bindings are
  written in the format:

      binding :verb object/expression

  where `binding` is a binding as passed to `def`, `:verb` is one of a
  set of keywords, and `object` is any expression. Each subsequent
  binding creates a nested loop within the loop created by the
  previous binding.

  The available verbs are:

  * `:iterate` -- repeatedly evaluate and bind to the expression while
    it is truthy.

  * `:range` -- loop over a range. The object should be a two-element
    tuple with a start and end value, and an optional positive
    step. The range is half open, [start, end).

  * `:range-to` -- same as `:range`, but the range is inclusive
    [start, end].

  * `:down` -- loop over a range, stepping downwards. The object
    should be a two-element tuple with a start and end value, and an
    optional positive step size.  The range is half open, [start,
    end).

  * `:down-to` -- same as `:down`, but the range is inclusive [start,
    end].

  * `:keys` -- iterate over the keys in a bytes, indexed, dictionary,
    fiber, or abstract type with a suitable `next` method.

  * `:pairs` -- iterate over the key-value pairs as tuples in a bytes,
    indexed, dictionary, fiber, or abstract type with suitable `get`
    and `next` methods.

  * `:in` -- iterate over the values in a bytes, indexed, dictionary,
    fiber, or abstract type with suitable `get` and `next` methods.

  `loop` also accepts conditionals to refine the looping
  further. Conditionals are of the form:

      :modifier argument

  where `:modifier` is one of a set of keywords, and `argument` is
  keyword-dependent. `:modifier` can be one of:

  * `:while expression` -- breaks from the current loop if
    `expression` is falsey.

  * `:until expression` -- breaks from the current loop if
    `expression` is truthy.

  * `:let bindings` -- defines bindings inside the current loop as
    passed to the `let` macro.

  * `:before form` -- evaluates a form for a side effect before the
    next inner loop.

  * `:after form` -- same as `:before`, but the side effect happens
    after the next inner loop.

  * `:repeat n` -- repeats the next inner loop `n` times.

  * `:when condition` -- only evaluates the current loop body when
    `condition` is truthy.

  * `:unless condition` -- only evaluates the current loop body when
    `condition` is falsey.

  The `loop` macro always evaluates to `nil`.
  ``
  [head & body]
  (loop1 body head 0))

(defmacro seq
  ``Similar to `loop`, but accumulates the loop body into an array and returns that.
  See `loop` for details.``
  [head & body]
  (def $accum (gensym))
  (check-empty-body body)
  ~(do (def ,$accum @[]) (as-macro ,loop ,head (,array/push ,$accum (do ,;body))) ,$accum))

(defmacro catseq
  ``Similar to `loop`, but concatenates each element from the loop body into an array and returns that.
  See `loop` for details.``
  [head & body]
  (def $accum (gensym))
  (check-empty-body body)
  ~(do (def ,$accum @[]) (as-macro ,loop ,head (,array/concat ,$accum (do ,;body))) ,$accum))

(defmacro tabseq
  ``Similar to `loop`, but accumulates key value pairs into a table.
  See `loop` for details.``
  [head key-body & value-body]
  (def $accum (gensym))
  ~(do (def ,$accum @{}) (as-macro ,loop ,head (,put ,$accum ,key-body (do ,;value-body))) ,$accum))

(defmacro generate
  ``Create a generator expression using the `loop` syntax. Returns a fiber
  that yields all values inside the loop in order. See `loop` for details.``
  [head & body]
  (check-empty-body body)
  ~(,fiber/new (fn :generate [] (as-macro ,loop ,head (,yield (do ,;body)))) :yi))

(defmacro coro
  "A wrapper for making fibers that may yield multiple values (coroutine). Same as `(fiber/new (fn [] ;body) :yi)`."
  [& body]
  (tuple fiber/new (tuple 'fn :coro '[] ;body) :yi))

(defmacro fiber-fn
  "A wrapper for making fibers. Same as `(fiber/new (fn [] ;body) flags)`."
  [flags & body]
  (tuple fiber/new (tuple 'fn :fiber-fn '[] ;body) flags))

(defn sum
  ``
  Returns the sum of the values of `x`. If `x` is empty, returns 0.

 `x` can be a bytes, indexed, dictionary, fiber, or abstract type with
  suitable `get` and `next` methods.
  ``
  [x]
  (var accum 0)
  (each v x (+= accum v))
  accum)

(defn mean
  ``
  Returns the mean of the values of `x`. If empty, returns `math/nan`.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [x]
  (if (lengthable? x)
    (/ (sum x) (length x))
    (do
      (var [accum total] [0 0])
      (each v x (+= accum v) (++ total))
      (/ accum total))))

(defn geomean
  ``
  Returns the geometric mean of the values of `x`. If empty, returns
  `math/nan`.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [x]
  (if (lengthable? x)
    (do
      (var accum 0)
      (each v x (+= accum (math/log v)))
      (math/exp (/ accum (length x))))
    (do
      (var [accum total] [0 0])
      (each v x (+= accum (math/log v)) (++ total))
      (math/exp (/ accum total)))))

(defn product
  ``
  Returns the product of the values of `x`. If `x` is empty, returns
  1.

 `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [x]
  (var accum 1)
  (each v x (*= accum v))
  accum)

(defmacro when-let
  "Same as `(if-let bindings (do ;body))`."
  [bindings & body]
  ~(as-macro ,if-let ,bindings (do ,;body)))

(defn comp
  `Takes multiple functions and returns a function that is the composition
  of those functions.`
  [& functions]
  (case (length functions)
    0 nil
    1 (in functions 0)
    2 (let [[f g] functions] (fn :comp [& x] (f (g ;x))))
    3 (let [[f g h] functions] (fn :comp [& x] (f (g (h ;x)))))
    4 (let [[f g h i] functions] (fn :comp [& x] (f (g (h (i ;x))))))
    (let [[f g h i] functions]
      (comp (fn :comp [x] (f (g (h (i x)))))
            ;(tuple/slice functions 4 -1)))))

(defn identity
  "A function that returns its argument."
  [x]
  x)

(defn complement
  "Returns a function that is the complement to the argument."
  [f]
  (fn :complement [x] (not (f x))))

(defmacro- do-extreme
  [order args]
  ~(do
     (def ds ,args)
     (var k (next ds nil))
     (var ret (get ds k))
     (while (,not= nil (set k (next ds k)))
       (def x (in ds k))
       (if (,order x ret) (set ret x)))
     ret))

(defn extreme
  ``Returns the most extreme value in `args` based on the function `order`.
  `order` should take two values and return true or false (a comparison).
  Returns nil if `args` is empty.``
  [order args] (do-extreme order args))

(defn max
  "Returns the numeric maximum of the arguments."
  [& args] (do-extreme > args))

(defn min
  "Returns the numeric minimum of the arguments."
  [& args] (do-extreme < args))

(defn max-of
  "Returns the numeric maximum of the argument sequence."
  [args] (do-extreme > args))

(defn min-of
  "Returns the numeric minimum of the argument sequence."
  [args] (do-extreme < args))

(defn first
  ``
  Get the first value in `x`.

  If `x` is a non-empty bytes or indexed type value, return the first
  element.

  If `x` is a fiber, return the fiber's last value or `nil` if there
  isn't one yet.

  If `x` is an abstract type value with a `get` method, call the method
  with a key of `0`.

  In all other cases, return `nil`.
  ``
  [x]
  (get x 0))

(defn last
  ``
  Get the final element from `x`.

  `x` can be a bytes, indexed, or abstract type value with suitable
  `get` and `length` methods.
  ``
  [x]
  (get x (- (length x) 1)))

## Polymorphic comparisons

(defmacro- do-compare
  [x y]
  (def f (gensym))
  (def f-res (gensym))
  (def g (gensym))
  (def g-res (gensym))
  ~(do
     (def ,f (,get ,x :compare))
     (def ,f-res (if ,f (,f ,x ,y)))
     (if ,f-res
       ,f-res
       (do
         (def ,g (,get ,y :compare))
         (def ,g-res (if ,g (,- (,g ,y ,x))))
         (if ,g-res
           ,g-res
           (,cmp ,x ,y))))))

(defn compare
  ``Polymorphic compare. Returns -1, 0, 1 for x < y, x = y, x > y respectively.
  Differs from the primitive comparators in that it first checks to
  see whether either x or y implement a `compare` method which can
  compare x and y. If so, it uses that method. If not, it
  delegates to the primitive comparators.``
  [x y]
  (do-compare x y))

(defmacro- compare-reduce [op xs]
  ~(do
     (var res true)
     (var x (get ,xs 0))
     (forv i 1 (length ,xs)
       (let [y (in ,xs i)]
         (if (,op (do-compare x y) 0)
           (set x y)
           (do (set res false) (break)))))
     res))

(defn compare=
  ``Equivalent of `=` but using polymorphic `compare` instead of primitive comparator.``
  [& xs]
  (compare-reduce = xs))

(defn compare<
  ``Equivalent of `<` but using polymorphic `compare` instead of primitive comparator.``
  [& xs]
  (compare-reduce < xs))

(defn compare<=
  ``Equivalent of `<=` but using polymorphic `compare` instead of primitive comparator.``
  [& xs]
  (compare-reduce <= xs))

(defn compare>
  ``Equivalent of `>` but using polymorphic `compare` instead of primitive comparator.``
  [& xs]
  (compare-reduce > xs))

(defn compare>=
  ``Equivalent of `>=` but using polymorphic `compare` instead of primitive comparator.``
  [& xs]
  (compare-reduce >= xs))

(defn zero? "Check if x is zero." [x] (= (compare x 0) 0))
(defn pos? "Check if x is greater than 0." [x] (= (compare x 0) 1))
(defn neg? "Check if x is less than 0." [x] (= (compare x 0) -1))
(defn one? "Check if x is equal to 1." [x] (= (compare x 1) 0))
(defn even? "Check if x is even." [x] (= 0 (compare 0 (mod x 2))))
(defn odd? "Check if x is odd." [x] (= 0 (compare 1 (mod x 2))))

###
###
### Indexed Combinators
###
###

(defmacro- median-of-three
  [x y z]
  ~(if (<= ,x ,y)
     (if (<= ,y ,z) ,y (if (<= ,z ,x) ,x ,z))
     (if (<= ,z ,y) ,y (if (<= ,x ,z) ,x ,z))))

(defmacro- sort-partition-template
  [ind before? left right pivot]
  ~(do
     (while (,before? (in ,ind ,left) ,pivot) (++ ,left))
     (while (,before? ,pivot (in ,ind ,right)) (-- ,right))))

(defn- sort-help [a lo hi before?]
  (when (< lo hi)
    (def [x y z] [(in a lo)
                  (in a (div (+ lo hi) 2))
                  (in a hi)])
    (def pivot (median-of-three x y z))
    (var left lo)
    (var right hi)
    (while true
      (case before?
        < (sort-partition-template a < left right pivot)
        > (sort-partition-template a > left right pivot)
        (sort-partition-template a before? left right pivot))
      (when (<= left right)
        (def tmp (in a left))
        (set (a left) (in a right))
        (set (a right) tmp)
        (++ left)
        (-- right))
      (if (>= left right) (break)))
    (if (< lo right)
      (sort-help a lo right before?))
    (if (< left hi)
      (sort-help a left hi before?)))
  a)

(defn sort
  ``
  Sorts `x` in-place, and returns it. Uses quick-sort and is not a
  stable sort. If a `before?` comparator function is provided, sorts
  elements using that, otherwise uses `<`.

  `x` can be a buffer, array, or abstract type with suitable `get`,
  `put`, and `length` methods.
  ``
  [x &opt before?]
  (default before? <)
  (sort-help x 0 (- (length x) 1) before?))

(defn sort-by
  ``
  Sorts `x` in-place by calling a function `f` on each element and
  comparing the results with `<`.

  `x` can be a buffer, array, or abstract type with suitable `get`,
  `put`, and `length` methods.
  ``
  [f x]
  (sort x (fn :sort-by-comp [i j] (< (f i) (f j)))))

(defn sorted
  ``
  Returns a new sorted array based on an indexed type `ind`. If a
  `before?` comparator function is provided, sorts elements using
  that, otherwise uses `<`.
  ``
  [ind &opt before?]
  (sort (array/slice ind) before?))

(defn sorted-by
  ``
  Returns a new sorted array based on an indexed type `ind`.
  Comparison is done by invoking a function `f` on each element and
  comparing the results with `<`.
  ``
  [f ind]
  (sorted ind (fn :sorted-by-comp [x y] (< (f x) (f y)))))

(defn reduce
  ``
  Also know as fold-left in many languages, this function transforms
  `x` by successively applying a function `f` to values from `x` and
  an updating "accumulator" value. `f` is a function of 2 arguments,
  `(f acc v)`, where `acc` starts as `init` and `v` is the next value
  in `x`. `f` returns a value that will be used as `acc` in the next
  call to `f`. The ultimate return value is that of the final call to
  `f`.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [f init x]
  (var acc init)
  (each v x (set acc (f acc v)))
  acc)

(defn reduce2
  ``
  The 2-argument version of `reduce`. Instead of taking an explicit
  initial value, the first value of `x` is used instead. If `x` is
  empty, returns `nil`.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [f x]
  (var k (next x))
  (if (= nil k) (break nil))
  (var res (in x k))
  (set k (next x k))
  (while (not= nil k)
    (set res (f res (in x k)))
    (set k (next x k)))
  res)

(defn accumulate
  ``
  Similar to `reduce`, but accumulates successive results of applying
  `f` into a new array. The last element in the array is what would be
  the return value from `reduce`. The `init` value is not added
  directly as the first value of the new array, i.e. the returned
  array will have the same number of elements as `x`.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [f init x]
  (var res init)
  (def ret @[])
  (each v x (array/push ret (set res (f res v))))
  ret)

(defn accumulate2
  ``
  The 2-argument version of `accumulate`. Instead of taking an
  explicit initial value, the first value of `x` is used instead. If
  `x` is empty, returns an empty array.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [f x]
  (var k (next x))
  (def ret @[])
  (if (= nil k) (break ret))
  (var res (in x k))
  (array/push ret res)
  (set k (next x k))
  (while (not= nil k)
    (set res (f res (in x k)))
    (array/push ret res)
    (set k (next x k)))
  ret)

(defmacro- map-aggregator
  `Aggregation logic for various map functions.`
  [maptype res val]
  (case maptype
    :map ~(array/push ,res ,val)
    :mapcat ~(array/concat ,res ,val)
    :keep ~(if (def y ,val) (array/push ,res y))
    :count ~(if ,val (++ ,res))
    :some ~(if (def y ,val) (do (set ,res y) (break)))
    :all ~(if (def y ,val) nil (do (set ,res y) (break)))))

(defmacro- map-n
  `Generates efficient map logic for a specific number of
  indexed beyond the first.`
  [n maptype res f ind inds]
  ~(do
     (def ,(seq [k :range [0 n]] (symbol 'ind k)) ,inds)
     ,;(seq [k :range [0 n]] ~(var ,(symbol 'key k) nil))
     (each x ,ind
       ,;(seq [k :range [0 n]]
           ~(if (= nil (set ,(symbol 'key k) (next ,(symbol 'ind k) ,(symbol 'key k)))) (break)))
       (map-aggregator ,maptype ,res (,f x ,;(seq [k :range [0 n]] ~(in ,(symbol 'ind k) ,(symbol 'key k))))))))

(defmacro- map-template
  [maptype res f ind inds]
  ~(do
     (def ninds (length ,inds))
     (case ninds
       0 (each x ,ind (map-aggregator ,maptype ,res (,f x)))
       1 (map-n 1 ,maptype ,res ,f ,ind ,inds)
       2 (map-n 2 ,maptype ,res ,f ,ind ,inds)
       3 (map-n 3 ,maptype ,res ,f ,ind ,inds)
       (do
         (def iter-keys (array/new-filled ninds))
         (def call-buffer (array/new-filled ninds))
         (var done false)
         (each x ,ind
           (forv i 0 ninds
             (let [old-key (in iter-keys i)
                   ii (in ,inds i)
                   new-key (next ii old-key)]
               (if (= nil new-key)
                 (do (set done true) (break))
                 (do (set (iter-keys i) new-key) (set (call-buffer i) (in ii new-key))))))
           (if done (break))
           (map-aggregator ,maptype ,res (,f x ;call-buffer)))))))

(defn map
  ``
  Map a function `f` over every value in `x` and return an array of
  results.

  Also functions variadically, i.e. takes additional arguments, with
  suitable changes to the arity of `f`. `f` is called with both values
  from `x` and additional arguments, and only as many times as the
  length of the shortest of `x` and each element of `xs`. If `x` or
  any element of `xs` is empty, returns an empty array.

  `x` and elements of `xs` can be values of type bytes, indexed,
  dictionary, fiber, or abstract with suitable `get` and `next`
  methods.
  ``
  [f x & xs]
  (def res @[])
  (map-template :map res f x xs)
  res)

(defn mapcat
  ``
  Map a function `f` over every value in `x` and use `array/concat` to
  concatenate the results.

  Also functions variadically, i.e. takes additional arguments, with
  suitable changes to the arity of `f`. `f` is called with both values
  from `x` and additional arguments, and only as many times as the
  length of the shortest of `x` and each element of `xs`. If `x` or
  any element of `xs` is empty, returns an empty array.

  `x` and elements of `xs` can be values of type bytes, indexed,
  dictionary, fiber, or abstract with suitable `get` and `next`
  methods.
  ``
  [f x & xs]
  (def res @[])
  (map-template :mapcat res f x xs)
  res)

(defn filter
  ``
  Given a predicate, take only elements from `x` for which `(pred
  element)` is truthy. Returns a new array.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [pred x]
  (def res @[])
  (each v x
    (if (pred v) (array/push res v)))
  res)

(defn count
  ``
  Count the number of values in `x` for which applying `pred` yields a
  truthy value.

  Also functions variadically, i.e. takes additional arguments, with
  suitable changes to the arity of `pred`. `pred` is called with both
  values from `x` and additional arguments, and only as many times as
  the length of the shortest of `x` and each element of `xs`. If `x`
  or any element of `xs` is empty, returns 0.

  `x` and elements of `xs` can be values of type bytes, indexed,
  dictionary, fiber, or abstract with suitable `get` and `next`
  methods.
  ``
  [pred x & xs]
  (var res 0)
  (map-template :count res pred x xs)
  res)

(defn keep
  ``
  Given a predicate `pred`, return a new array containing the truthy
  results of applying `pred` to each value in `x`.

  Also functions variadically, i.e. takes additional arguments, with
  suitable changes to the arity of `pred`. `pred` is called with both
  values from `x` and additional arguments, and only as many times as
  the length of the shortest of `x` and each element of `xs`. If `x`
  or any element of `xs` is empty, returns an empty array.

  `x` and elements of `xs` can be values of type bytes, indexed,
  dictionary, fiber, or abstract with suitable `get` and `next`
  methods.
  ``
  [pred x & xs]
  (def res @[])
  (map-template :keep res pred x xs)
  res)

(defn find-index
  ``
  Find the index of `x` for which `pred` is true. If not found, return
  `dflt` if provided, or `nil` otherwise.

  `x` can be a bytes, indexed, dictionary, or abstract type with
  suitable `get` and `next` methods.
  ``
  [pred x &opt dflt]
  (var k (next x nil))
  (var ret dflt)
  (while (not= nil k)
    (when (pred (in x k)) (set ret k) (break))
    (set k (next x k)))
  ret)

(defn find
  ``
  Find the first value in `x` that satisfies `pred`. If not found,
  return `dflt` if given, or `nil` otherwise.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [pred x &opt dflt]
  (var k (next x nil))
  (var ret dflt)
  (while (not= nil k)
    (def item (in x k))
    (when (pred item) (set ret item) (break))
    (set k (next x k)))
  ret)

(defn index-of
  ``
  Find the first key associated with a value `val` in `x`, acting like
  a reverse lookup. Will not look at dictionary prototypes. If not
  found, return `dflt` if given, or `nil` otherwise.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [val x &opt dflt]
  (var k (next x nil))
  (var ret dflt)
  (while (not= nil k)
    (when (= (in x k) val) (set ret k) (break))
    (set k (next x k)))
  ret)

(defn- take-n-slice
  [f n ind]
  (def len (length ind))
  (def m (+ len n))
  (def start (if (< n 0 m) m 0))
  (def end (if (<= 0 n len) n len))
  (f ind start end))

(defn take
  ``Take the first n elements of a fiber, indexed or bytes type. Returns a new array, tuple or string,
  respectively. If `n` is negative, takes the last `n` elements instead.``
  [n ind]
  (cond
    (indexed? ind) (take-n-slice tuple/slice n ind)
    (bytes? ind) (take-n-slice string/slice n ind)
    (dictionary? ind) (do
                        (var left n)
                        (tabseq [[i x] :pairs ind :until (< (-- left) 0)] i x))
    (do
      (def res @[])
      (var key nil)
      (repeat n
        (if (= nil (set key (next ind key))) (break))
        (array/push res (in ind key)))
      res)))

(defn- take-until-slice
  [f pred ind]
  (def len (length ind))
  (def i (find-index pred ind))
  (def end (if (nil? i) len i))
  (f ind 0 end))

(defn take-until
  "Same as `(take-while (complement pred) ind)`."
  [pred ind]
  (cond
    (indexed? ind) (take-until-slice tuple/slice pred ind)
    (bytes? ind) (take-until-slice string/slice pred ind)
    (dictionary? ind) (tabseq [[i x] :pairs ind :until (pred x)] i x)
    (seq [x :in ind :until (pred x)] x)))

(defn take-while
  `Given a predicate, take only elements from a fiber, indexed, or bytes type that satisfy
  the predicate, and abort on first failure. Returns a new array, tuple, or string, respectively.`
  [pred ind]
  (take-until (complement pred) ind))

(defn- drop-n-slice
  [f n ind]
  (def len (length ind))
  (cond
    (<= 0 n len) (f ind n)
    (< (- len) n 0) (f ind 0 (+ len n))
    (f ind len)))

(defn- drop-n-dict
  [f n ind]
  (def res (f ind))
  (var left n)
  (loop [[i x] :pairs ind :until (< (-- left) 0)] (set (res i) nil))
  res)

(defn drop
  ``Drop the first `n` elements in an indexed or bytes type. Returns a new tuple or string
  instance, respectively. If `n` is negative, drops the last `n` elements instead.``
  [n ind]
  (cond
    (indexed? ind) (drop-n-slice tuple/slice n ind)
    (bytes? ind) (drop-n-slice string/slice n ind)
    (struct? ind) (drop-n-dict struct/to-table n ind)
    (table? ind) (drop-n-dict table/clone n ind)
    (do
      (var key nil)
      (repeat n
        (if (= nil (set key (next ind key))) (break)))
      ind)))

(defn- drop-until-slice
  [f pred ind]
  (def len (length ind))
  (def i (find-index pred ind))
  (def start (if (nil? i) len i))
  (f ind start))

(defn- drop-until-dict
  [f pred ind]
  (def res (f ind))
  (loop [[i x] :pairs ind :until (pred x)] (set (res i) nil))
  res)

(defn drop-until
  "Same as `(drop-while (complement pred) ind)`."
  [pred ind]
  (cond
    (indexed? ind) (drop-until-slice tuple/slice pred ind)
    (bytes? ind) (drop-until-slice string/slice pred ind)
    (struct? ind) (drop-until-dict struct/to-table pred ind)
    (table? ind) (drop-until-dict table/clone pred ind)
    (do (find pred ind) ind)))

(defn drop-while
  `Given a predicate, remove elements from an indexed or bytes type that satisfy
  the predicate, and abort on first failure. Returns a new tuple or string, respectively.`
  [pred ind]
  (drop-until (complement pred) ind))

###
###
### Lazy sequences
###
###

# A lazy sequence is a memoizing pull cell: a function of no arguments that
# returns either `nil` (the end) or a tuple of `[value rest-cell]`, computing
# its body at most once.
#
# Why a cell and not the obvious alternatives, all measured:
#
#   * A fiber is pull-based, but it is ONE-SHOT. A second traversal of the same
#     fiber yields nothing, and it does not memoize. A lazy seq must be
#     re-traversable, so a fiber is a cursor, not a sequence.
#   * Janet's `map` is eager over every source, so `(map f (lazy-range))` would
#     realize the whole sequence -- and hang outright on an infinite one.
#   * An abstract type would make a seq a first-class iterable, but abstract
#     types are defined in C only; that is a bigger, less reversible change.
#
# The cell costs one closure per element and cannot cross a process boundary
# (closures do not marshal); pass an array across a process, not a sequence.
# Use `lazy-to-array` or `lazy-to-fiber` at the boundary.
#
# Traversal is iterative -- `lazy-to-array` and friends walk with `while` --
# so consuming a long sequence does not grow the stack. Building one is also
# stack-safe: the GC marks closure environments with an explicit worklist
# (see janet_drain_env_queue in gc.c), which is what makes a chain of any
# depth survivable.

(defn delay1
  ``Memoize a thunk: call `f` at most once, then return its value. The
  primitive every lazy cell is built from.``
  [f]
  (var value nil)
  (var done false)
  (fn []
    (if done
      value
      (do
        (set done true)
        (set value (f))
        value))))

(defn lazy-cell
  "A lazy sequence from a thunk returning nil or `[value rest-cell]`."
  [f]
  (delay1 f))

(defn lazy-nil
  "The empty lazy sequence."
  [] (lazy-cell (fn [] nil)))

(defn lazy-cons
  "Prepend `x` to lazy sequence `s` without realizing `s`."
  [x s]
  (lazy-cell (fn [] (tuple x s))))

(defn lazy-from-array
  "A lazy sequence over the elements of `ind`, index by index."
  [ind &opt start]
  (def i (if (nil? start) 0 start))
  (lazy-cell (fn []
               (if (>= i (length ind))
                 nil
                 (tuple (in ind i) (lazy-from-array ind (+ i 1)))))))

(defn lazy-to-array
  "Realize all of `s` into an array. Traversal is iterative, so a long
  sequence does not grow the stack. An infinite sequence would hang here --
  bound it with `lazy-take` first."
  [s]
  (def out @[])
  (var cell s)
  (var cont true)
  (while cont
    (def c (cell))
    (if c
      (do (array/push out (get c 0)) (set cell (get c 1)))
      (set cont false)))
  out)

(defn realize
  "Realize all of lazy sequence `s` into an array. See `lazy-to-array`."
  [s]
  (lazy-to-array s))

(defn lazy-each
  "Call `f` on each element of `s` for its side effects, iteratively. Returns nil."
  [f s]
  (var cell s)
  (var cont true)
  (while cont
    (def c (cell))
    (if c
      (do (f (get c 0)) (set cell (get c 1)))
      (set cont false)))
  nil)

(defn lazy-reduce
  "Reduce `s` with `f` from `init`, iteratively."
  [f init s]
  (var acc init)
  (lazy-each (fn [x] (set acc (f acc x))) s)
  acc)

(defn lazy-to-fiber
  ``A fiber view over `s` so ordinary `each` works: `(each v (lazy-to-fiber s) ...)`.

  The fiber is ONE-SHOT -- a second traversal yields nothing. The sequence it
  came from stays re-traversable, so build a new fiber for each pass.``
  [s]
  (fiber/new (fn []
               (var cell s)
               (var cont true)
               (while cont
                 (def c (cell))
                 (if c
                   (do (yield (get c 0)) (set cell (get c 1)))
                   (set cont false))))))

(defn lazy-peek
  "Realize the head of `s` once, returning its `[value rest]` tuple or nil."
  [s]
  (s))

(defn lazy-empty?
  "Whether `s` is exhausted. Realizes the head."
  [s]
  (nil? (s)))

(defn lazy-first
  "The first value of `s`, or nil when empty. Realizes the head."
  [s]
  (def c (s))
  (if c (get c 0)))

(defn lazy-rest
  "Everything after the first value of `s`. Realizes the head."
  [s]
  (def c (s))
  (if c (get c 1) (lazy-nil)))

(defn lazy-range
  ``Integers in `[start, end)`. With one argument, `[0, start)`.
  Elements are realized on demand, so the sequence may be enormous.``
  [start &opt end step]
  (def lo (if (nil? end) 0 start))
  (def hi (if (nil? end) start end))
  (def by (if (nil? step) 1 step))
  (if (<= by 0)
    (error "lazy-range expects a positive step")
    (lazy-cell (fn []
                 (if (>= lo hi)
                   nil
                   (tuple lo (lazy-range (+ lo by) hi by)))))))

(defn lazy-repeat
  "An infinite sequence of `x`, or `x` repeated `n` times when `n` is given."
  [x &opt n]
  (if n
    (lazy-cell (fn [] (if (<= n 0) nil (tuple x (lazy-repeat x (- n 1))))))
    (lazy-cell (fn [] (tuple x (lazy-repeat x))))))

(defn lazy-iterate
  "An infinite sequence of `x`, `(f x)`, `(f (f x))`, ..."
  [f x]
  (lazy-cell (fn [] (tuple x (lazy-iterate f (f x))))))

(defn lazy-map
  ``Lazily map `f` over `s`. Nothing is computed until an element is asked
  for, and each element is computed at most once.``
  [f s]
  (lazy-cell (fn []
               (def c (s))
               (if (not c)
                 nil
                 (tuple (f (get c 0)) (lazy-map f (get c 1)))))))

(defn lazy-filter
  ``Lazily keep the elements of `s` satisfying `pred`. Elements are tested on
  demand, so this terminates on an infinite source while matches keep occurring.``
  [pred s]
  (lazy-cell (fn []
               (var c (s))
               (while (and c (not (pred (get c 0))))
                 (def next-cell (get c 1))
                 (set c (next-cell)))
               (if (not c)
                 nil
                 (tuple (get c 0) (lazy-filter pred (get c 1)))))))

(defn lazy-take
  ``At most the first `n` elements of `s`.

  The remaining count is tested BEFORE the cell is realized, so `n` elements
  cost exactly `n` realizations -- taking 5 from an infinite sequence never
  computes a 6th.``
  [n s]
  (lazy-cell (fn []
               (if (<= n 0)
                 nil
                 (do
                   (def c (s))
                   (if (not c)
                     nil
                     (tuple (get c 0) (lazy-take (- n 1) (get c 1)))))))))

(defn lazy-drop
  "Skip the first `n` elements of `s`, realizing and discarding them."
  [n s]
  (if (<= n 0)
    s
    (lazy-cell (fn []
                 (var c (s))
                 (var left n)
                 (while (and c (> left 0))
                   (def next-cell (get c 1))
                   (set c (next-cell))
                   (-- left))
                 c))))

(defn lazy-take-while
  "The prefix of `s` whose elements satisfy `pred`."
  [pred s]
  (lazy-cell (fn []
               (def c (s))
               (if (not c)
                 nil
                 (do
                   (def v (get c 0))
                   (if (pred v)
                     (tuple v (lazy-take-while pred (get c 1)))
                     nil))))))

(defn lazy-drop-while
  "`s` without its leading elements that satisfy `pred`."
  [pred s]
  (lazy-cell (fn []
               (var c (s))
               (while (and c (pred (get c 0)))
                 (def next-cell (get c 1))
                 (set c (next-cell)))
               (if (not c) nil (tuple (get c 0) (get c 1))))))

(var- lazy-cat-more nil)

(defn- lazy-cat-start
  "Internal: the lazy sequence beginning at index `i` of `seqs`."
  [seqs i]
  (lazy-cell (fn []
               (var out nil)
               (if (< i (length seqs))
                 (do
                   (def d ((in seqs i)))
                   (if d
                     (set out (tuple (get d 0) (lazy-cat-more seqs i (get d 1)))))))
               out)))

(set lazy-cat-more (fn lazy-cat-more
  [seqs i rest]
  (lazy-cell (fn []
               (var out nil)
               (def c (rest))
               (if c
                 (set out (tuple (get c 0) (lazy-cat-more seqs i (get c 1))))
                 (set out ((lazy-cat-start seqs (+ i 1)))))
               out))))
(defn lazy-cat
  "Concatenate lazy sequences left to right, without realizing the tail."
  [& seqs]
  (lazy-cat-start seqs 0))

(defn lazy-mapcat
  "Lazily map `f` over `s` and concatenate the resulting sequences."
  [f s]
  (lazy-cell (fn []
               (var c (s))
               (var head nil)
               (var tail nil)
               (while (and c (nil? head))
                 (def inner (f (get c 0)))
                 (if (lazy-empty? inner)
                   (def next-cell (get c 1))
                   (do
                     (set head (lazy-first inner))
                     (set tail (lazy-cat (lazy-rest inner)
                                         (lazy-mapcat f (get c 1)))))))
               (if (nil? head) nil (tuple head tail)))))

(defn juxt*
  ``Returns the juxtaposition of functions. In other words,
  `((juxt* a b c) x)` evaluates to `[(a x) (b x) (c x)]`.``
  [& funs]
  (fn :juxt* [& args]
    (def ret @[])
    (each f funs
      (array/push ret (f ;args)))
    (tuple/slice ret 0)))

(defmacro juxt
  "Macro form of `juxt*`. Same behavior but more efficient."
  [& funs]
  (def parts @['tuple])
  (def $args (gensym))
  (each f funs
    (array/push parts (tuple apply f $args)))
  (tuple 'fn :juxt (tuple '& $args) (tuple/slice parts 0)))

(defn has-key?
  ``
  Check if `x` maps `key` to a non-nil value.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with a suitable `get` method.
  ``
  [x key]
  (not= nil (get x key)))

(defn has-value?
  ``
  Checks if `x` contains `value`.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type with
  suitable `get` and `next` methods.
  ``
  [x value]
  (not= nil (index-of value x)))

(defdyn *defdyn-prefix* ``Optional namespace prefix to add to keywords declared with `defdyn`.
  Use this to prevent keyword collisions between dynamic bindings.``)
(defdyn *out* "Where normal print functions print output to.")
(defdyn *err* "Where error printing prints output to.")
(defdyn *redef* "When set, allow dynamically rebinding top level defs. Will slow generated code and is intended to be used for development.")
(defdyn *debug* "Enables a built in debugger on errors and other useful features for debugging in a repl.")
(defdyn *exit* "When set, will cause the current context to complete. Can be set to exit from repl (or file), for example.")
(defdyn *exit-value* "Set the return value from `run-context` upon an exit.")
(defdyn *task-id* "When spawning a thread or fiber, the task-id can be assigned for concurrency control.")
(defdyn *optimize* "Set optimization level for the the `compile` function. Default is 1 (matching the core library's own compilation), and higher integer levels will enable more optimization.")

(defdyn *current-file*
  "Bound to the name of the currently compiling file.")

(defmacro tracev
  `Print to stderr a value and a description of the form that produced that value.
  Evaluates to x.`
  [x]
  (def [l c] (tuple/sourcemap (dyn *macro-form* ())))
  (def cf (dyn *current-file*))
  (def fmt-1 (if cf (string/format "trace [%s]" cf) "trace"))
  (def fmt-2 (if (or (neg? l) (neg? c)) ":" (string/format " on line %d, column %d:" l c)))
  (def fmt (string fmt-1 fmt-2 " %j is "))
  (def s (gensym))
  ~(upscope
     (def ,s ,x)
     (,eprinf ,fmt ',x)
     (,eprintf (,dyn :pretty-format "%q") ,s)
     ,s))

(defn keep-syntax
  ``Creates a tuple with the tuple type and sourcemap of `before` but the
  elements of `after`. If either one of its arguments is not a tuple, returns
  `after` unmodified. Useful to preserve syntactic information when transforming
  an ast in macros.``
  [before after]
  (if (and (= :tuple (type before))
           (= :tuple (type after)))
    (do
      (def res (if (= :parens (tuple/type before))
                 (tuple/slice after)
                 (tuple/brackets ;after)))
      (tuple/setmap res ;(tuple/sourcemap before)))
    after))

(defn keep-syntax!
  ``Like `keep-syntax`, but if `after` is an array, it is coerced into a tuple.
  Useful to preserve syntactic information when transforming an ast in macros.``
  [before after]
  (keep-syntax before (if (= :array (type after))
                        (tuple/slice after)
                        after)))

(defmacro ->
  ``Threading macro. Inserts x as the second value in the first form
  in `forms`, and inserts the modified first form into the second form
  in the same manner, and so on. Useful for expressing pipelines of data.``
  [x & forms]
  (defn fop [last n]
    (def [h t] (if (= :tuple (type n))
                 (tuple (in n 0) (array/slice n 1))
                 (tuple n @[])))
    (def parts (array/concat @[h last] t))
    (keep-syntax! n parts))
  (reduce fop x forms))

(defmacro ->>
  ``Threading macro. Inserts x as the last value in the first form
  in `forms`, and inserts the modified first form into the second form
  in the same manner, and so on. Useful for expressing pipelines of data.``
  [x & forms]
  (defn fop [last n]
    (def [h t] (if (= :tuple (type n))
                 (tuple (in n 0) (array/slice n 1))
                 (tuple n @[])))
    (def parts (array/concat @[h] t @[last]))
    (keep-syntax! n parts))
  (reduce fop x forms))

(defmacro -?>
  ``Short circuit threading macro. Inserts x as the second value in the first form
  in `forms`, and inserts the modified first form into the second form
  in the same manner, and so on. The pipeline will return nil
  if an intermediate value is nil.
  Useful for expressing pipelines of data.``
  [x & forms]
  (defn fop [last n]
    (def [h t] (if (= :tuple (type n))
                 (tuple (in n 0) (array/slice n 1))
                 (tuple n @[])))
    (def sym (gensym))
    (def parts (array/concat @[h sym] t))
    ~(as-macro ,let [,sym ,last] (if ,sym ,(keep-syntax! n parts))))
  (reduce fop x forms))

(defmacro -?>>
  ``Short circuit threading macro. Inserts x as the last value in the first form
  in `forms`, and inserts the modified first form into the second form
  in the same manner, and so on. The pipeline will return nil
  if an intermediate value is nil.
  Useful for expressing pipelines of data.``
  [x & forms]
  (defn fop [last n]
    (def [h t] (if (= :tuple (type n))
                 (tuple (in n 0) (array/slice n 1))
                 (tuple n @[])))
    (def sym (gensym))
    (def parts (array/concat @[h] t @[sym]))
    ~(as-macro ,let [,sym ,last] (if ,sym ,(keep-syntax! n parts))))
  (reduce fop x forms))

(defn- walk-ind [f form]
  (def ret @[])
  (each x form (array/push ret (f x)))
  ret)

(defn- walk-dict [f form]
  (def ret @{})
  (loop [k :keys form]
    (put ret (f k) (f (in form k))))
  ret)

(defn- walk-dict-values [f form]
  (def ret @{})
  (loop [k :keys form]
    (put ret k (f (in form k))))
  ret)

(defn walk
  ``Iterate over the values in ast and apply `f`
  to them. Collect the results in a data structure. If ast is not a
  table, struct, array, or tuple,
  returns form.``
  [f form]
  (case (type form)
    :table (walk-dict f form)
    :struct (table/to-struct (walk-dict f form))
    :array (walk-ind f form)
    :tuple (keep-syntax! form (walk-ind f form))
    form))

(defn postwalk
  ``Do a post-order traversal of a data structure and call `(f x)`
  on every visitation.``
  [f form]
  (f (walk (fn [x] (postwalk f x)) form)))

(defn prewalk
  "Similar to `postwalk`, but do pre-order traversal."
  [f form]
  (walk (fn [x] (prewalk f x)) (f form)))

(defmacro as->
  ``Thread forms together, replacing `as` in `forms` with the value
  of the previous form. The first form is the value x. Returns the
  last value.``
  [x as & forms]
  (var prev x)
  (each form forms
    (def sym (gensym))
    (def next-prev (postwalk (fn [y] (if (= y as) sym y)) form))
    (set prev ~(let [,sym ,prev] ,next-prev)))
  prev)

(defmacro as?->
  ``Thread forms together, replacing `as` in `forms` with the value
  of the previous form. The first form is the value x. If any
  intermediate values are falsey, return nil; otherwise, returns the
  last value.``
  [x as & forms]
  (var prev x)
  (each form forms
    (def sym (gensym))
    (def next-prev (postwalk (fn [y] (if (= y as) sym y)) form))
    (set prev ~(if-let [,sym ,prev] ,next-prev)))
  prev)

(defmacro with-dyns
  `Run a block of code in a new fiber that has some
  dynamic bindings set. The fiber will not mask errors
  or signals, but the dynamic bindings will be properly
  unset, as dynamic bindings are fiber-local.`
  [bindings & body]
  (def dyn-forms
    (seq [i :range [0 (length bindings) 2]]
      ~(setdyn ,(bindings i) ,(bindings (+ i 1)))))
  ~(,resume (,fiber/new (fn :with-dyns [] ,;dyn-forms ,;body) :p)))

(defmacro with-env
  `Run a block of code with a given environment table`
  [env & body]
  ~(,resume (,fiber/new (fn :with-env [] ,;body) : ,env)))

(defmacro with-vars
  ``Evaluates `body` with each var in `vars` temporarily bound. Similar signature to
  `let`, but each binding must be a var.``
  [vars & body]
  (def len (length vars))
  (unless (even? len) (error "expected even number of argument to vars"))
  (def temp (seq [i :range [0 len 2]] (gensym)))
  (def saveold (seq [i :range [0 len 2]] ['def (temp (/ i 2)) (vars i)]))
  (def setnew (seq [i :range [0 len 2]] ['set (vars i) (vars (+ i 1))]))
  (def restoreold (seq [i :range [0 len 2]] ['set (vars i) (temp (/ i 2))]))
  (with-syms [ret f s]
    ~(do
       ,;saveold
       (def ,f (,fiber/new (fn :with-vars [] ,;setnew ,;body) :ti))
       (def ,ret (,resume ,f))
       ,;restoreold
       (if (= (,fiber/status ,f) :dead) ,ret (,propagate ,ret ,f)))))

(defn partial
  "Partial function application."
  [f & more]
  (if (zero? (length more)) f
    (fn :partial [& r] (f ;more ;r))))

(defn every?
  ``
  Evaluates to the last element of `x` if all preceding elements are
  truthy, true if `x` is empty, or otherwise to the first falsey
  element.

  `x` can be a bytes, indexed. dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [x]
  (var res true)
  (loop [v :in x :while res]
    (set res v))
  res)

(defn any?
  ``
  Evaluates to the last element of `x` if all preceding elements are
  falsey, `nil` if `x` is empty, or otherwise to the first truthy
  element.

  `x` can be a bytes, indexed. dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [x]
  (var res nil)
  (loop [v :in x :until res]
    (set res v))
  res)

(defn reverse!
  ``
  Reverses the order of the values in `x` and returns it mutated.

  `x` can be a buffer, array, or abstract type with suitable
  `get`, `length`, and `put` methods.
  ``
  [x]
  (var i 0)
  (var j (length x))
  (while (< i (-- j))
    (def v (in x i))
    (put x i (in x j))
    (put x j v)
    (++ i))
  x)

(defn reverse
  ``
  Reverses the order of the values in `x`. If `x` is a bytes type,
  returns a buffer, otherwise returns an array.

  `x` can be a bytes, indexed, fiber, or abstract type with suitable
  `get` and `next` methods.
  ``
  [x]
  (if (lengthable? x)
    (do
      (var n (length x))
      (def ret (if (bytes? x)
                 (buffer/new-filled n)
                 (array/new-filled n)))
      (each v x
        (put ret (-- n) v))
      ret)
    (reverse! (seq [v :in x] v))))

(defn invert
  ``
  Returns a table where the keys of `x` are the values, and the values
  are the keys. If multiple keys in `x` are mapped to the same value,
  only one of those values will become a key in the returned table.

  `x` can be a bytes, indexed, dictionary, or abstract type with a
  suitable `next` method.
  ``
  [x]
  (def ret @{})
  (loop [k :keys x]
    (put ret (in x k) k))
  ret)

(defn zipcoll
  ``
  Creates a table from `ks` and `vs` by pairing values at the same
  index from each. If `ks` or `vs` has more values than the other, the
  extra values are ignored. Returns a new table.

  `ks` and `vs` can by bytes, indexed, fibers, or abstract types with
  suitable `get` and `next` methods.
  ``
  [ks vs]
  (def res @{})
  (var kk nil)
  (var vk nil)
  (while true
    (set kk (next ks kk))
    (if (= nil kk) (break))
    (set vk (next vs vk))
    (if (= nil vk) (break))
    (put res (in ks kk) (in vs vk)))
  res)

(defn get-in
  ``
  Use the keys `ks` to look up a nested value in `x`. If a value is
  not found, will return `dflt` if provided, or `nil` otherwise.

  `x` can be a suitable indexed, dictionary, or abstract type with a
  `get` method.

  `ks` can be an indexed or abstract type with `get` and `next`
  methods.
  ``
  [x ks &opt dflt]
  (var d x)
  (loop [k :in ks :while (not (nil? d))] (set d (get d k)))
  (if (= nil d) dflt d))

(defn update-in
  ``
  Update a value in `x`. Looks into a nested spot in `x` identified by
  the keys `ks` and replaces the value found there with `f` applied to
  that value and any values passed and available in `args`. Missing
  spots will be replaced with tables and `f` is passed `nil` instead
  of a found value. Returns `x` modified.

  `x` can be a suitable array, table or abstract type with `get` and
  `put` methods.

  `ks` can be an indexed or abstract type with suitable `get` and
  `length` methods.
  ``
  [x ks f & args]
  (var d x)
  (def len-1 (- (length ks) 1))
  (if (< len-1 0) (error "expected at least 1 key in ks"))
  (forv i 0 len-1
    (def k (get ks i))
    (def v (get d k))
    (if (= nil v)
      (let [newv (table)]
        (put d k newv)
        (set d newv))
      (set d v)))
  (def last-key (get ks len-1))
  (def last-val (get d last-key))
  (put d last-key (f last-val ;args))
  x)

(defn put-in
  ``
  Use the keys `ks` to put a value `val` into a nested spot in
  `x`. Missing spots will be replaced with tables. Returns `x`
  modified.

  `x` can be a suitable array, table or abstract type with `get` and
  `put` methods.

  `ks` can be an indexed or abstract type with suitable `get` and
  `length` methods.
  ``
  [x ks val]
  (var d x)
  (def len-1 (- (length ks) 1))
  (if (< len-1 0) (error "expected at least 1 key in ks"))
  (forv i 0 len-1
    (def k (get ks i))
    (def v (get d k))
    (if (= nil v)
      (let [newv (table)]
        (put d k newv)
        (set d newv))
      (set d v)))
  (def last-key (get ks len-1))
  (def last-val (get d last-key))
  (put d last-key val)
  x)

(defn update
  ``
  For a given key in `x`, replace its associated value with the result
  of applying `f` to that value. If `args` are provided, they will be
  passed along to `f` as well. Returns updated `x`.

  `x` can be a buffer, array, table, or suitable abstract type with
  `get` and `put` methods.
  ``
  [x key f & args]
  (def old (get x key))
  (put x key (f old ;args)))

(defn merge-into
  ``
  Merges multiple dictionaries into table `tab`. If a key appears in
  more than one dictionary in `dicts`, then later values replace any
  previous ones. Returns `tab`.
  ``
  [tab & dicts]
  (loop [d :in dicts
         key :keys d]
    (put tab key (in d key)))
  tab)

(defn merge
  ``
  Merges multiple dictionaries into one new table. If a key appears in
  more than one dictionary in `dicts` then later values replace any
  previous ones. Returns the new table.
  ``
  [& dicts]
  (def container @{})
  (loop [d :in dicts
         key :keys d]
    (put container key (in d key)))
  container)

(defn keys
  ``
  Get the keys of `x` as an array.

  `x` can be a bytes, indexed, dictionary, or abstract type with a
  suitable `next` method.
  ``
  [x]
  (if (lengthable? x)
    (do
      (def arr (array/new-filled (length x)))
      (var i 0)
      (eachk k x
        (put arr i k)
        (++ i))
      arr)
    (seq [k :keys x] k)))

(defn values
  ``
  Get the values of `x` as an array.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [x]
  (if (lengthable? x)
    (do
      (def arr (array/new-filled (length x)))
      (var i 0)
      (each v x
        (put arr i v)
        (++ i))
      arr)
    (seq [v :in x] v)))

(defn pairs
  ``
  Return an array of tuples of the key-value pairs of `x`. For bytes
  and indexed types, the integer indices are considered the keys.

  `x` can be a bytes, indexed, dictionary, or abstract type with
  suitable `get` and `in` methods.
  ``
  [x]
  (if (lengthable? x)
    (do
      (def arr (array/new-filled (length x)))
      (var i 0)
      (eachp p x
        (put arr i p)
        (++ i))
      arr)
    (seq [p :pairs x] p)))

(defn frequencies
  ``
  Returns a table of occurrences of each value in `x`.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with `get` and `next` methods.
  ``
  [x]
  (def freqs @{})
  (each v x
    (put freqs v (inc (in freqs v 0))))
  freqs)

(defn group-by
  ``
  Group values of `x` by a function `f` and put the results into a new
  table. The keys of the table are the distinct return values from
  calling `f` on the values of `x`. The values of the table are arrays
  of all values of `x` for which `f` called on the value equals that
  corresponding key.

  `x` can be a bytes, indexed, dictionary, fiber, or abstract type
  with suitable `get` and `next` methods.
  ``
  [f x]
  (def ret @{})
  (each v x
    (def y (f v))
    (if-let [arr (get ret y)]
      (array/push arr v)
      (put ret y @[v])))
  ret)

(defn partition-by
  ``
  Partition values of `x` by a function `f`. Partitions split when `f`
  applied to a value changes result when iterating to the next value
  of `x`. Returns a new array of arrays.

  `x` can be a bytes, indexed, fiber, or abstract type with suitable
  `get` and `next` methods.
  ``
  [f x]
  (def ret @[])
  (var span nil)
  (var categ nil)
  (var new? true)
  (each v x
    (def y (f v))
    (cond
      new? (do (set new? false) (set categ y) (set span @[v]) (array/push ret span))
      (= categ y) (array/push span v)
      (do (set categ y) (set span @[v]) (array/push ret span))))
  ret)

(defn interleave
  ``
  Returns an array of the values of each element of `xs`, interleaved.
  If the elements of `xs` do not all have the same number of values,
  the shortest element of `xs` determines the number of values from
  each element of `xs` that are contained in the returned array.

  Each element of `xs` can be a bytes, indexed, fiber, or abstract
  type with suitable `get` and `next` methods.
  ``
  [& xs]
  (mapcat tuple ;xs))

(defn distinct
  "Returns an array of the deduplicated values in `xs`."
  [xs]
  (def ret @[])
  (def seen @{})
  (each x xs (if (in seen x) nil (do (put seen x true) (array/push ret x))))
  ret)

(defn flatten-into
  ``
  Appends the depth-first traversal of an indexed type `ind` into a
  given array `into`. Returns `into`.
  ``
  [into ind]
  (each elt ind
    (if (indexed? elt)
      (flatten-into into elt)
      (array/push into elt)))
  into)

(defn flatten
  ``
  Returns a depth-first traversal of an indexed type `ind` as a new
  array.
  ``
  [ind]
  (flatten-into @[] ind))

(defn kvs
  ``Takes a table or struct and returns a new array of key value pairs
  like `@[k v k v ...]`.``
  [dict]
  (def ret @[])
  (loop [k :keys dict] (array/push ret k (in dict k)))
  ret)

(defn from-pairs
  ``Takes a sequence of pairs and creates a table from each pair. It is the inverse of
  `pairs` on a table. Returns a new table.``
  [ps]
  (def ret @{})
  (each [k v] ps
    (put ret k v))
  ret)

(defn interpose
  ``
  Returns an array of the values of `x` separated by `val`.

  `x` can be a bytes, indexed, fiber or abstract type with suitable
  `get` and `next` methods.
  ``
  [val x]
  (var k (next x nil))
  (if (not= nil k)
    (if (lengthable? x)
      (do
        (def ret (array/new-filled (- (* 2 (length x)) 1) val))
        (var i 0)
        (while (not= nil k)
          (put ret i (in x k))
          (set k (next x k))
          (+= i 2))
        ret)
      (do
        (def ret @[(in x k)])
        (while (not= nil (set k (next x k)))
          (array/push ret val (in x k)))
        ret))
    @[]))

(defn- partition-slice
  [f n ind]
  (var [start end] [0 n])
  (def len (length ind))
  (def parts (div len n))
  (def ret (array/new-filled parts))
  (forv k 0 parts
    (put ret k (f ind start end))
    (set start end)
    (+= end n))
  (if (< start len)
    (array/push ret (f ind start)))
  ret)

(defn partition
  ``
  Partition the values of `x` into tuples of size `n`. Returns a new
  array.

  `n` should be a non-negative integer.

  `x` can be a bytes, indexed, fiber, or abstract type with suitable
  `get` and `next` methods.
  ``
  [n x]
  (cond
    (indexed? x) (partition-slice tuple/slice n x)
    (bytes? x) (partition-slice string/slice n x)
    (partition-slice tuple/slice n (values x))))

###
###
### IO Helpers
###
###

(defn slurp
  ``Read all data from a file with name `path` and then close the file.``
  [path]
  (def f (file/open path :rb))
  (if-not f (error (string "could not open file " path)))
  (def contents (file/read f :all))
  (file/close f)
  contents)

(defn spit
  ``Write `bytes` to a file at `path`. Can optionally append to the file.``
  [path bytes &opt mode]
  (default mode :wb)
  (def f (file/open path mode))
  (if-not f (error (string "could not open file " path " with mode " mode)))
  (file/write f bytes)
  (file/close f)
  nil)

(defdyn *pretty-format*
  "Format specifier for the `pp` function")

(defdyn *repl-prompt*
  "Allow setting a custom prompt at the default REPL. Not all REPLs will respect this binding.")

(defn pp
  ``Pretty-print to stdout or `(dyn *out*)`. The format string used is `(dyn *pretty-format* "%q")`.``
  [x]
  (printf (dyn *pretty-format* "%q") x)
  (flush))

(defn puts
  ``Ruby-like `puts`: print each argument on its own line to stdout (or
  `(dyn *out*)`). Arrays and tuples print element-wise (recursively, so
  nested structures flatten one element per line); `nil` prints a blank
  line; anything else prints as `print` would. Returns `nil`.``
  [& xs]
  (each x xs
    (cond
      (nil? x) (print)
      (indexed? x) (each y x (puts y))
      (print x)))
  nil)

(defn file/lines
  "Return an iterator over the lines of a file."
  [file]
  (coro
    (while (def line (file/read file :line))
      (yield line))))

###
###
### Multimethods
###
###

(var *multimethods*
  "Registry of multimethod functions to method tables (internal;
  prefer `methods`, `get-method`, `defmethod` over touching it directly)."
  @{})

# AOT images clone constants, including this mutable core table and helpers.
# Look up the runtime core var's ref instead of capturing its table at compile
# time; the registry must be the same one for macro expansions and core APIs.
(defn- multi-registry []
  (get (get (dyn '*multimethods*) :ref) 0))

(defn- multi-register [f t]
  (put (multi-registry) f t)
  f)

(defn- multi-install [m name v method]
  (def t (in (multi-registry) m))
  (if (nil? t) (error (string "not a multimethod: " name)))
  (put (get t :methods) v method))

(defn- multi-invoke [t args]
  (def dv (apply (get t :dispatch) args))
  (def method (if (nil? dv)
                (in (get t :methods) (get t :default))
                (or (in (get t :methods) dv)
                    (in (get t :methods) (get t :default)))))
  (if (nil? method)
    (error (string "no method for dispatch value " (describe dv))))
  (apply method args))

(defn methods
  ``Return the live method table of multimethod `m` (dispatch value
  to function). Add and remove entries with `defmethod` and
  `remove-method`.``
  [m]
  (def t (in (multi-registry) m))
  (if (nil? t) (error (string "not a multimethod: " (describe m))))
  (get t :methods))

(defn get-method
  ``The method `m` would invoke for dispatch value `v` (with
  `:default` fallback), or nil.``
  [m v]
  (def t (in (multi-registry) m))
  (if (nil? t) (error (string "not a multimethod: " (describe m))))
  (if (nil? v)
    (in (get t :methods) (get t :default))
    (or (in (get t :methods) v)
        (in (get t :methods) (get t :default)))))

(defn remove-method
  ``Remove the method for dispatch value `v` from multimethod `m`.
  Returns `m`.``
  [m v]
  (put (methods m) v nil)
  m)

(defmacro defmulti
  ``Define a multimethod `name` dispatching by `dispatch-fn` (called
  with the same args; its return selects the method). Single-arity
  methods only in v1; no hierarchies (exact dispatch values plus a
  `:default` fallback, default `:default`). Dispatch values must be
  hashable. Same-VM typical (the registry is core-local). Emits a
  single top-level `def` (a `do`-wrapped `def` would scope it
  invisibly — `do` opens a scope).``
  [name dispatch-fn &opt opts]
  (let [inv multi-invoke register multi-register]
    ~(def ,name
       ((fn [t] (,register (fn [& args] (,inv t args)) t))
        {:dispatch ,dispatch-fn
         :methods @{}
         :default ,(if opts (get opts :default) :default)}))))

(defmacro defmethod
  ``Install a method for `name` (defined by `defmulti`) at dispatch
  value `dispatch-val`. A single call form (no top-level `def`, same
  scoping reason as `defmulti`). Errors loudly on an unknown
  multimethod.``
  [name dispatch-val & fntail]
  (let [install multi-install]
    ~(,install ,name ',name ,dispatch-val
               (fn ,(first fntail) ,;(tuple/slice fntail 1)))))

###
###
### Atoms (same-VM synchronous state)
###
### Single-threaded boxes: `atom`, `deref`, `swap!`, `reset!`,
### `compare-and-set!`, with optional `:validator`. No locking is
### involved — sharing one across OS threads is a user error; move
### state across threads through channels (or results through
### futures/promises, which settle exactly once). Validators run on
### every proposed value and reject by returning nil/false (error).

(defn atom
  ``Create an atom holding `x`. `opts` (`:validator f`) installs a
  predicate every proposed value must satisfy.``
  [x &opt opts]
  @{:kind :atom
    :state x
    :validator (if opts (get opts :validator))})

(defn atom?
  "True for atoms."
  [x]
  (and (table? x) (= :atom (get x :kind))))

(defn deref
  "Read an atom's current value."
  [a]
  (if (atom? a)
    (get a :state)
    (error (string "deref expects an atom, got " (describe a)))))

(defn- atom-check [a v]
  (def valid (get a :validator))
  (when (and valid (not (valid v)))
    (error "atom validator rejected the proposed value"))
  v)

(defn reset!
  "Set atom `a` to `v` (validated), returning `v`."
  [a v]
  (put a :state (atom-check a v))
  v)

(defn swap!
  "Set atom `a` to `(f state args...)` (validated), returning the new
  value. Single-threaded: no retry loop (nothing can interleave)."
  [a f & args]
  (def nv (apply f (get a :state) args))
  (put a :state (atom-check a nv))
  nv)

(defn compare-and-set!
  "Set atom `a` to `new` iff its current value `=`s `old`
  (validated). Returns true on success, false otherwise."
  [a old new]
  (if (= old (get a :state))
    (do (put a :state (atom-check a new))
      true)
    false))

###
###
### Pattern Matching
###
###

(defmacro match
  ```
  Pattern matching. Match an expression `x` against any number of cases.
  Each case is a pattern to match against, followed by an expression to
  evaluate to if that case is matched.  Legal patterns are:

  * symbol -- a pattern that is a symbol will match anything, binding `x`'s
    value to that symbol.

  * array or bracket tuple -- an array or bracket tuple will match only if
    all of its elements match the corresponding elements in `x`.
    Use `& rest` at the end of an array or bracketed tuple to bind all remaining values to `rest`.

  * table or struct -- a table or struct will match if all values match with
    the corresponding values in `x`.

  * tuple -- a tuple pattern will match if its first element matches, and the
    following elements are treated as predicates and are true.

  * `_` symbol -- the last special case is the `_` symbol, which is a wildcard
    that will match any value without creating a binding.

  While a symbol pattern will ordinarily match any value, the pattern `(@ <sym>)`,
  where `<sym>` is any symbol, will attempt to match `x` against a value
  already bound to `<sym>`, rather than matching and rebinding it.

  Any other value pattern will only match if it is equal to `x`.
  Quoting a pattern with `'` will also treat the value as a literal value to match against.

  ```
  [x & cases]

  # Partition body into sections.
  (def oddlen (odd? (length cases)))
  (def else (if oddlen (last cases)))
  (def patterns (partition 2 (if oddlen (slice cases 0 -2) cases)))

  # Keep an array for accumulating the compilation output
  (def x-sym (if (idempotent? x) x (gensym)))
  (def accum @[])
  (if (not= x x-sym) (array/push accum ['def x-sym x]))

  # Table of gensyms
  (def symbols @{[nil nil] x-sym})
  (def length-symbols @{})

  (defn emit [x] (array/push accum x))
  (defn emit-branch [condition result] (array/push accum :branch condition result))

  (defn get-sym
    [parent-sym key]
    (def symbol-key [parent-sym key])
    (or (get symbols symbol-key)
        (let [s (gensym)]
          (put symbols symbol-key s)
          (emit ['def s [get parent-sym key]])
          s)))

  (defn get-length-sym
    [parent-sym]
    (or (get length-symbols parent-sym)
        (let [s (gensym)]
          (put length-symbols parent-sym s)
          (emit ['def s ['if [indexed? parent-sym] [length parent-sym]]])
          s)))

  (defn visit-pattern-1
    [b2g parent-sym key pattern]
    (if (= pattern '_) (break))
    (def s (get-sym parent-sym key))
    (def t (type pattern))
    (def isarr (or (= t :array) (and (= t :tuple) (= (tuple/type pattern) :brackets))))
    (cond

      # match local binding
      (= t :symbol)
      (if-let [x (in b2g pattern)]
        (array/push x s)
        (put b2g pattern @[s]))

      # match quoted literal
      (and (= t :tuple) (= 2 (length pattern)) (= 'quote (pattern 0)))
      (break)

      # match data structure template
      (or (= t :struct) (= t :table))
      (eachp [i sub-pattern] pattern
        (visit-pattern-1 b2g s i sub-pattern))

      isarr
      (do
        (get-length-sym s)
        (eachp [i sub-pattern] pattern
          (when (= sub-pattern '&)
            (when (<= (length pattern) (inc i))
              (errorf "expected symbol following & in pattern"))

            (when (< (+ i 2) (length pattern))
              (errorf "expected a single symbol follow '& in pattern, found %q" (slice pattern (inc i))))

            (when (not= (type (pattern (inc i))) :symbol)
              (errorf "expected symbol following & in pattern, found %q" (pattern (inc i))))

            (put b2g (pattern (inc i)) @[[slice s i]])
            (break))
          (when (= sub-pattern '$)
            (when (not= (length pattern) (inc i))
              (error "expected $ to be last symbol in pattern"))
            (break))

          (visit-pattern-1 b2g s i sub-pattern)))

      # match global unification
      (and (= t :tuple) (= 2 (length pattern)) (= '@ (pattern 0)))
      (break)

      # match predicated binding
      (and (= t :tuple) (>= (length pattern) 2))
      (do
        (visit-pattern-1 b2g parent-sym key (pattern 0)))))

  (defn visit-pattern-2
    [anda gun preds parent-sym key pattern]
    (if (= pattern '_) (break))
    (def s (get-sym parent-sym key))
    (def t (type pattern))
    (def isarr (or (= t :array) (and (= t :tuple) (= (tuple/type pattern) :brackets))))
    (when isarr
      (array/push anda (get-length-sym s))
      (def amp-index (find-index (fn [x] (= x '&)) pattern))
      (def dollar-index (find-index (fn [x] (= x '$)) pattern))
      (def pattern-len (or dollar-index amp-index (length pattern)))
      (array/push anda [(if dollar-index = <=) pattern-len (get-length-sym s)]))
    (cond

      # match data structure template
      (or (= t :struct) (= t :table))
      (eachp [i sub-pattern] pattern
        (array/push anda [not= nil (get-sym s i)])
        (visit-pattern-2 anda gun preds s i sub-pattern))

      isarr
      (eachp [i sub-pattern] pattern
        # stop recursing to sub-patterns if the rest sigil is found
        (when (or (= sub-pattern '$) (= sub-pattern '&))
          (break))
        (visit-pattern-2 anda gun preds s i sub-pattern))

      # match local binding
      (= t :symbol) (break)

      # match quoted literal
      (and (= t :tuple) (= 2 (length pattern)) (= 'quote (pattern 0)))
      (array/push anda ['= s pattern])

      # match global unification
      (and (= t :tuple) (= 2 (length pattern)) (= '@ (pattern 0)))
      (if-let [x (in gun (pattern 1))]
        (array/push x s)
        (put gun (pattern 1) @[s]))

      # match predicated binding
      (and (= t :tuple) (>= (length pattern) 2))
      (do
        (array/push preds ;(slice pattern 1))
        (visit-pattern-2 anda gun preds parent-sym key (pattern 0)))

      # match literal
      (array/push anda ['= s pattern])))

  # Compile the patterns
  (each [pattern expression] patterns
    (def b2g @{})
    (def gun @{})
    (def preds @[])
    (visit-pattern-1 b2g nil nil pattern)
    (def anda @['and])
    (visit-pattern-2 anda gun preds nil nil pattern)
    # Local unification
    (def unify @[])
    (each syms b2g
      (when (< 1 (length syms))
        (array/push unify [= ;syms])))
    # Global unification
    (eachp [binding syms] gun
      (array/push unify [= binding ;syms]))
    (sort unify)
    (array/concat anda unify)
    # Final binding
    (def defs (seq [[k v] :in (sort (pairs b2g))] ['def k (first v)]))
    (def unused-defs (seq [[k v] :in (sort (pairs b2g))] ['def k :unused (first v)]))
    # Predicates
    (unless (empty? preds)
      (def pred-join ~(do ,;unused-defs (and ,;preds)))
      (array/push anda pred-join))
    # Use `unused-defs` instead of `defs` when we have predicates to avoid unused binding lint
    # e.g. (match x (n (even? n)) :yes :no) should not warn on unused binding `n`.
    # This is unfortunately not perfect since one programmer written binding is expanded for use in multiple places.
    (emit-branch (tuple/slice anda) ['do ;(if (next preds) unused-defs defs) expression]))

  # Expand branches
  (def stack @[else])
  (each el (reverse accum)
    (if (= :branch el)
      (let [condition (array/pop stack)
            truthy (array/pop stack)
            if-form ~(if ,condition ,truthy
                       ,(case (length stack)
                          0 nil
                          1 (stack 0)
                          ~(do ,;(reverse stack))))]
        (array/remove stack 0 (length stack))
        (array/push stack if-form))
      (array/push stack el)))

  ~(do ,;(reverse stack)))

###
###
### Macro Expansion
###
###

(defn macex1
  ``Expand macros in a form, but do not recursively expand macros.
  See `macex` docs for info on `on-binding`.``
  [x &opt on-binding]

  (when on-binding
    (when (symbol? x)
      (break (on-binding x))))

  (defn recur [y] (macex1 y on-binding))

  (defn dotable [t on-value]
    (def newt @{})
    (var key (next t nil))
    (while (not= nil key)
      (put newt (recur key) (on-value (in t key)))
      (set key (next t key)))
    newt)

  (defn expand-bindings [x]
    (case (type x)
      :array (map expand-bindings x)
      :tuple (keep-syntax! x (map expand-bindings x))
      :table (dotable x expand-bindings)
      :struct (table/to-struct (dotable x expand-bindings))
      (recur x)))

  (defn expanddef [t]
    (def last (in t (- (length t) 1)))
    (def bound (in t 1))
    (keep-syntax! t
                  (array/concat
                    @[(in t 0) (expand-bindings bound)]
                    (tuple/slice t 2 -2)
                    @[(recur last)])))

  (defn expandall [t]
    (def args (map recur (tuple/slice t 1)))
    (tuple (in t 0) ;args))

  (defn expandfn [t]
    (def t1 (in t 1))
    (if (symbol? t1)
      (do
        (def args (map recur (tuple/slice t 3)))
        (keep-syntax t (tuple 'fn t1 (in t 2) ;args)))
      (do
        (def args (map recur (tuple/slice t 2)))
        (keep-syntax t (tuple 'fn t1 ;args)))))

  (defn expandqq [t]
    (defn qq [x]
      (case (type x)
        :tuple (if (= :brackets (tuple/type x))
                 ~[,;(map qq x)]
                 (do
                   (def x0 (get x 0))
                   (if (= 'unquote x0)
                     (tuple x0 (recur (get x 1)))
                     (tuple/slice (map qq x)))))
        :array (map qq x)
        :table (table ;(map qq (kvs x)))
        :struct (struct ;(map qq (kvs x)))
        x))
    (tuple (in t 0) (qq (in t 1))))

  (def specs
    {'set expanddef
     'def expanddef
     'do expandall
     'fn expandfn
     'if expandall
     'quote identity
     'quasiquote expandqq
     'var expanddef
     'while expandall
     'break expandall
     'upscope expandall})

  (defn dotup [t]
    (if (= nil (next t)) (break ()))
    (def h (in t 0))
    (def s (in specs h))
    (def entry (or (dyn h) {}))
    (def m (do (def r (get entry :ref)) (if r (in r 0) (get entry :value))))
    (def m? (in entry :macro))
    (cond
      s (keep-syntax t (s t))
      m? (do (setdyn *macro-form* t) (m ;(tuple/slice t 1)))
      (keep-syntax! t (map recur t))))

  (def ret
    (case (type x)
      :tuple (if (= (tuple/type x) :brackets)
               (tuple/brackets ;(map recur x))
               (dotup x))
      :array (map recur x)
      :struct (table/to-struct (dotable x recur))
      :table (dotable x recur)
      x))
  ret)

(defn all
  ``
  Apply `pred` to values of `x`. Return true if all results are truthy;
  if any result is falsey, stop applying `pred` and return the result.

  Also functions variadically, i.e. takes additional arguments, with
  suitable changes to the arity of `pred`. `pred` is called with both
  values from `x` and additional arguments, and only as many times as
  the length of the shortest of `x` and each element of `xs`. If `x`
  or any element of `xs` is empty, returns true.

  `x` and elements of `xs` can be values of type bytes, indexed,
  dictionary, fiber, or abstract with suitable `get` and `next`
  methods.
  ``
  [pred x & xs]
  (var res true)
  (map-template :all res pred x xs)
  res)

(defn some
  ``
  Returns `nil` if applying `pred` to every value in `x` results in
  only falsey values, otherwise returns the first truthy result
  encountered.

  Also functions variadically, i.e. takes additional arguments, with
  suitable changes to the arity of `f`. `f` is called with both values
  from `x` and additional arguments, and only as many times as the
  length of the shortest of `x` and each element of `xs`. If `x` or
  any element of `xs` is empty, returns `nil`.

  `x` and elements of `xs` can be values of type bytes, indexed,
  dictionary, fiber, or abstract with suitable `get` and `next`
  methods.
  ``
  [pred x & xs]
  (var res nil)
  (map-template :some res pred x xs)
  res)

(defn freeze
  `Freeze an object (make it immutable) and do a deep copy, making
  child values also immutable. Closures, fibers, and abstract types
  will not be recursively frozen, but all other types will.`
  [x]
  (def tx (type x))
  (cond
    (or (= tx :array) (= tx :tuple))
    (tuple/slice (map freeze x))

    (or (= tx :table) (= tx :struct))
    (let [temp-tab @{}]
      # Handle multiple unique keys that freeze. Result should
      # be independent of iteration order.
      (eachp [k v] x
        (def kk (freeze k))
        (def vv (freeze v))
        (def old (get temp-tab kk))
        (def new (if (= nil old) vv (max vv old)))
        (put temp-tab kk new))
      (table/to-struct temp-tab (freeze (getproto x))))

    (= tx :buffer)
    (string x)

    x))

(defn thaw
  ```
  Thaw an object (make it mutable) and do a deep copy, making
  child values also mutable. Closures, fibers, and abstract
  types will not be recursively thawed, but all other types will.
  ```
  [ds]
  (case (type ds)
    :array (walk-ind thaw ds)
    :tuple (walk-ind thaw ds)
    :table (walk-dict thaw (table/proto-flatten ds))
    :struct (walk-dict thaw (struct/proto-flatten ds))
    :string (buffer ds)
    ds))

(defn thaw-keep-keys
  ```
  Similar to `thaw`, but do not modify table or struct keys.
  ```
  [ds]
  (case (type ds)
    :array (walk-ind thaw-keep-keys ds)
    :tuple (walk-ind thaw-keep-keys ds)
    :table (walk-dict-values thaw-keep-keys (table/proto-flatten ds))
    :struct (walk-dict-values thaw-keep-keys (struct/proto-flatten ds))
    :string (buffer ds)
    ds))

(defn deep-not=
  ``Like `not=`, but mutable types (arrays, tables, buffers) are considered
  equal if they have identical structure. Much slower than `not=`.``
  [x y]
  (def tx (type x))
  (or
    (not= tx (type y))
    (cond
      (or (= tx :tuple) (= tx :array))
      (or (not= (length x) (length y))
          (do
            (var ret false)
            (forv i 0 (length x)
              (def xx (in x i))
              (def yy (in y i))
              (if (deep-not= xx yy)
                (break (set ret true))))
            ret))
      (or (= tx :struct) (= tx :table))
      (or (not= (length x) (length y))
          (do
            (def rawget (if (= tx :struct) struct/rawget table/rawget))
            (var ret false)
            (eachp [k v] x
              (if (deep-not= (rawget y k) v) (break (set ret true))))
            ret))
      (= tx :buffer) (not= 0 (- (length x) (length y)) (memcmp x y))
      (not= x y))))

(defn deep=
  ``Like `=`, but mutable types (arrays, tables, buffers) are considered
  equal if they have identical structure. Much slower than `=`.``
  [x y]
  (not (deep-not= x y)))

(defn macex
  ``Expand macros completely.
  `on-binding` is an optional callback for whenever a normal symbolic binding
  is encountered. This allows macros to easily see all bindings used by their
  arguments by calling `macex` on their contents. The binding itself is also
  replaced by the value returned by `on-binding` within the expanded macro.``
  [x &opt on-binding]
  (var previous x)
  (var current (macex1 x on-binding))
  (var counter 0)
  (while (deep-not= current previous)
    (if (> (++ counter) 200)
      (error "macro expansion too nested"))
    (set previous current)
    (set current (macex1 current on-binding)))
  current)

(set macexvar macex)

(defmacro varfn :flycheck
  ``Create a function that can be rebound. `varfn` has the same signature
  as `defn`, but defines functions in the environment as vars. If a var `name`
  already exists in the environment, it is rebound to the new function. Returns
  a function.``
  [name & body]
  (def expansion (apply defn name body))
  (def fbody (last expansion))
  (def modifiers (tuple/slice expansion 2 -2))
  (def metadata @{})
  (each m modifiers
    (cond
      (keyword? m) (put metadata m true)
      (string? m) (put metadata :doc m)
      (dictionary? m) (merge-into metadata m)
      (error (string "invalid metadata " m))))
  (with-syms [entry old-entry f]
    ~(as-macro ,let [,old-entry (,dyn ',name)]
               (def ,entry (as-macro ,or ,old-entry @{:ref @[nil]}))
               (,setdyn ',name ,entry)
               (def ,f ,fbody)
               (,put-in ,entry [:ref 0] ,f)
               (,merge-into ,entry ',metadata)
               ,f)))

###
###
### Function shorthand
###
###

(def- max-shortfn-params 9999) # Less than 0xFFFF so we have enough registers for internal use
(defmacro short-fn
  ```
  Shorthand for `fn`. Arguments are given as `$n`, where `n` is the
  0-indexed argument of the function. `$` is also an alias for the
  first (index 0) argument. The `$&` symbol will make the anonymous
  function variadic if it appears in the body of the function, and
  can be combined with positional arguments.
  ```
  [arg &opt name]
  (var max-param-seen -1)
  (var vararg false)
  (defn saw-special-arg
    [num]
    (set max-param-seen (max max-param-seen num)))
  (def prefix (gensym))
  (defn on-binding
    [x]
    (if (string/has-prefix? '$ x)
      (cond
        (= '$ x)
        (do
          (saw-special-arg 0)
          (symbol prefix '$0))
        (= '$& x)
        (do
          (set vararg true)
          (symbol prefix x))
        :else
        (do
          (def num (scan-number (string/slice x 1)))
          (if num
            (do
              (assertf (nat? num) "expected indexed parameter, got %s" x)
              (assertf (<= num max-shortfn-params) "too many short-fn parameters (%s)" x)
              (saw-special-arg num)
              (symbol prefix x))
            x)))
      x))
  (def expanded (macex arg on-binding))
  (def name-splice (if name [name] [:short-fn]))
  (def fn-args (seq [i :range [0 (+ 1 max-param-seen)]] (symbol prefix '$ i)))
  ~(fn ,;name-splice [,;fn-args ,;(if vararg ['& (symbol prefix '$&)] [])] ,expanded))

###
###
### Default PEG patterns
###
###

(defdyn *peg-grammar*
  ``The implicit base grammar used when compiling PEGs. Any undefined keywords
  found when compiling a peg will use lookup in this table (if defined).``)

(def default-peg-grammar
  `The default grammar used for pegs. This grammar defines several common patterns
  that should make it easier to write more complex patterns.`
  ~@{:a (range "az" "AZ")
     :d (range "09")
     :h (range "09" "af" "AF")
     :s (set " \t\r\n\0\f\v")
     :w (range "az" "AZ" "09")
     :A (if-not :a 1)
     :D (if-not :d 1)
     :H (if-not :h 1)
     :S (if-not :s 1)
     :W (if-not :w 1)
     :a+ (some :a)
     :d+ (some :d)
     :h+ (some :h)
     :s+ (some :s)
     :w+ (some :w)
     :A+ (some :A)
     :D+ (some :D)
     :H+ (some :H)
     :S+ (some :S)
     :W+ (some :W)
     :a* (any :a)
     :d* (any :d)
     :h* (any :h)
     :s* (any :s)
     :w* (any :w)
     :A* (any :A)
     :D* (any :D)
     :H* (any :H)
     :S* (any :S)
     :W* (any :W)})

(setdyn *peg-grammar* default-peg-grammar)

###
###
### Evaluation and Compilation
###
###

(defdyn *syspath*
  "Path of directory to load system modules from.")

# Initialize syspath
(each [k v] (partition 2 (tuple/slice boot/args 2))
  (case k
    "JANET_PATH" (setdyn *syspath* v)))

(defn make-env
  `Create a new environment table. The new environment
  will inherit bindings from the parent environment, but new
  bindings will not pollute the parent environment.`
  [&opt parent]
  (def parent (if parent parent root-env))
  (def newenv (table/setproto @{} parent))
  newenv)

(defdyn *err-color*
  "Whether or not to turn on error coloring in stacktraces and other error messages.")

(defn bad-parse
  "Default handler for a parse error."
  [p where]
  (def ec (dyn *err-color*))
  (def [line col] (:where p))
  (eprint
    (if ec "\e[31m" "")
    where
    ":"
    line
    ":"
    col
    ": parse error: "
    (:error p)
    (if ec "\e[0m"))
  (eflush))

(defn warn-compile
  "Default handler for a compile warning."
  [msg level where &opt line col]
  (def ec (dyn *err-color*))
  (eprin
    (if ec "\e[33m" "")
    where
    ":"
    line
    ":"
    col
    ": compile warning (" level "): ")
  (eprint msg (if ec "\e[0m"))
  (eflush))

(defn bad-compile
  "Default handler for a compile error."
  [msg macrof where &opt line col]
  (def ec (dyn *err-color*))
  (eprin
    (if ec "\e[31m" "")
    where
    ":"
    line
    ":"
    col
    ": compile error: ")
  (if macrof
    (debug/stacktrace macrof msg "")
    (eprint msg (if ec "\e[0m")))
  (eflush))

(defn curenv
  ``Get the current environment table. Same as `(fiber/getenv (fiber/current))`. If `n`
  is provided, gets the nth prototype of the environment table.``
  [&opt n]
  (var e (fiber/getenv (fiber/current)))
  (if n (repeat n (if (= nil e) (break)) (set e (table/getproto e))))
  e)

(def- lint-levels
  {:none 0
   :relaxed 1
   :normal 2
   :strict 3
   :all math/inf})

(defn run-context
  ``
  Run a context. This evaluates expressions in an environment, and
  encapsulates parsing, compilation, and evaluation. Takes a
  dictionary `opts` with the following options:

  * `:env` -- environment to compile against; default is the current
    environment.

  * `:chunks` -- callback to read into a buffer; default is `getline`.

  * `:on-status` -- callback when a value is evaluated; default is
    `debug/stacktrace`.

  * `:on-compile-error` -- callback when compilation fails; default
    is `bad-compile`.

  * `:on-compile-warning` -- callback for any linting error; default
    is `warn-compile`.

  * `:on-parse-error` -- callback when parsing fails; default is
    `bad-parse`.

  * `:fiber-flags` -- flags to wrap the compilation fiber with;
    default is `:ia`.

  * `:evaluator` -- callback that executes thunks; signature is
    `(evaluator thunk source env where)`.

  * `:source` -- source path for better errors (use keywords for
    non-paths); default is `:<anonymous>`.

  * `:parser` -- custom parser that implements the same interface as
    Janet's built-in parser.

  * `:read` -- function to get the next form; signature is `(read env
    source)`; overrides all parsing.

  * `:expander` -- function that is called on each top-level form
    before being compiled.

  Returns `(in env :exit-value env)` when complete.
  ``
  [opts]

  (def {:env env
        :chunks chunks
        :on-status onstatus
        :on-compile-error on-compile-error
        :on-compile-warning on-compile-warning
        :on-parse-error on-parse-error
        :fiber-flags guard
        :evaluator evaluator
        :source default-where
        :parser parser
        :read read
        :expander expand} opts)
  (default env (or (fiber/getenv (fiber/current)) @{}))
  (default chunks (fn chunks [buf p] (getline "" buf env)))
  (default onstatus debug/stacktrace)
  (default on-compile-error bad-compile)
  (default on-compile-warning warn-compile)
  (default on-parse-error bad-parse)
  (default evaluator (fn evaluate [x &] (x)))
  (default default-where :<anonymous>)
  (default guard :ydt)

  (var where default-where)

  (if (string? where)
    (put env *current-file* where))

  # Evaluate 1 source form in a protected manner
  (def lints @[])
  (defn eval1 [source &opt l c]
    (def source (if expand (expand source) source))
    (var good true)
    (var resumeval nil)
    (def f
      (fiber/new
        (fn :compile-and-lint []
          (array/clear lints)
          (def res (compile source env where lints))
          (when (next lints)
            # Convert lint levels to numbers.
            (def levels (get env *lint-levels* lint-levels))
            (def lint-error (get env *lint-error*))
            (def lint-warning (get env *lint-warn*))
            (def lint-error (or (get levels lint-error lint-error) 0))
            (def lint-warning (or (get levels lint-warning lint-warning) 2))
            (each [level line col msg] (distinct lints) # some macros might cause code to be duplicated. Avoid repeated messages.
              (def lvl (get lint-levels level 0))
              (cond
                (<= lvl lint-error) (do
                                      (set good false)
                                      (on-compile-error msg nil where (or line l) (or col c)))
                (<= lvl lint-warning) (on-compile-warning msg level where (or line l) (or col c)))))
          (when good
            (if (= (type res) :function)
              (evaluator res source env where)
              (do
                (set good false)
                (def {:error err :line line :column column :fiber errf} res)
                (on-compile-error err errf where (or line l) (or column c))))))
        guard
        env))
    (while (fiber/can-resume? f)
      (def res (resume f resumeval))
      (when good (set resumeval (onstatus f res)))))

  # Reader version
  (when read
    (forever
      (if (in env :exit) (break))
      (eval1 (read env where)))
    (break (in env :exit-value env)))

  # The parser object
  (def p (or parser (parser/new)))
  (def p-consume (p :consume))
  (def p-produce (p :produce))
  (def p-status (p :status))
  (def p-has-more (p :has-more))

  (defn parse-err
    "Handle parser error in the correct environment"
    [p where]
    (def f (coro (on-parse-error p where)))
    (fiber/setenv f env)
    (resume f))

  (defn produce []
    (def tup (p-produce p true))
    [(in tup 0) ;(tuple/sourcemap tup)])

  # Loop
  (def buf @"")
  (var parser-not-done true)
  (while parser-not-done
    (if (env :exit) (break))
    (buffer/clear buf)
    (match (chunks buf p)
      :cancel
      (do
        # A :cancel chunk represents a cancelled form in the REPL, so reset.
        (:flush p)
        (buffer/clear buf))

      [:source new-where]
      (do
        (set where new-where)
        (if (string? new-where)
          (put env *current-file* new-where)))

      (do
        (var pindex 0)
        (def len (length buf))
        (when (= len 0)
          (:eof p)
          (set parser-not-done false))
        (while (> len pindex)
          (+= pindex (p-consume p buf pindex))
          (while (p-has-more p)
            (eval1 ;(produce))
            (if (env :exit) (break)))
          (when (= (p-status p) :error)
            (parse-err p where)
            (if (env :exit) (break)))))))

  # Check final parser state
  (unless (env :exit)
    (while (p-has-more p)
      (eval1 ;(produce))
      (if (env :exit) (break)))
    (when (= (p-status p) :error)
      (parse-err p where)))

  (put env :exit nil)
  (in env :exit-value env))

(defn quit
  ``Tries to exit from the current repl or run-context. Does not always exit the application.
  Works by setting the :exit dynamic binding to true. Passing a non-nil `value` here will cause the outer
  run-context to return that value.``
  [&opt value]
  (setdyn :exit true)
  (setdyn :exit-value value)
  nil)

(defn eval
  ``Evaluates a form in the current environment. If more control over the
  environment is needed, use `run-context`. Optionally pass in an `env` table with available bindings.``
  [form &opt env]
  (def res (compile form env :eval))
  (if (= (type res) :function)
    (res)
    (error (get res :error))))

(defn parse
  `Parse a string and return the first value. For complex parsing, such as for a repl with error handling,
  use the parser api.`
  [str]
  (let [p (parser/new)]
    (parser/consume p str)
    (if (= :error (parser/status p))
      (error (parser/error p)))
    (parser/eof p)
    (if (parser/has-more p)
      (parser/produce p)
      (if (= :error (parser/status p))
        (error (parser/error p))
        (error "no value")))))

(defn parse-all
  `Parse a string and return all parsed values. For complex parsing, such as for a repl with error handling,
  use the parser api.`
  [str]
  (let [p (parser/new)
        ret @[]]
    (parser/consume p str)
    (if (= :error (parser/status p))
      (error (parser/error p)))
    (parser/eof p)
    (while (parser/has-more p)
      (array/push ret (parser/produce p)))
    (if (= :error (parser/status p))
      (error (parser/error p))
      ret)))

(defn eval-string
  ``Evaluates a string in the current environment. If more control over the
  environment is needed, use `run-context`. Optionally pass in an `env` table with available bindings.``
  [str &opt env]
  (var ret nil)
  (each x (parse-all str) (set ret (eval x env)))
  ret)

###
###
### P-lanes: VM-per-core proc parallelism
###

(defn proc/spawn
  "Spawn a zero-argument process with mailbox capacity (default 16).
  Returns a local proc or a routed [:pid lane serial ctl] handle. Mutable
  captures keep their existing local placement. Routed backpressure waits
  for the control-channel write before returning the saved PID."
  [entry &opt capacity]
  (def prepared (if (nil? capacity)
                  (proc/spawn-prepare entry)
                  (proc/spawn-prepare entry capacity)))
  (if (and (tuple? prepared) (= :proc-spawn-write (get prepared 0)))
    (do (def pid (get prepared 1))
        (ev/give (get prepared 2) (get prepared 3))
        pid)
    prepared))

(defn proc/lane-worker
  "Resident dispatcher for one proc lane. Takes one launch tuple
  [ctl lane-id aff]: `ctl` is the lane's threaded control channel;
  `lane-id` is 0 for the main VM, 1..N for workers; `aff` requests
  best-effort core pinning. Messages:
  [:spawn serial cap entry] -> VM-local spawn, registered under serial
  [:deliver serial payload] -> proc/send into the local proc's mailbox
  [:stop]                   -> exit the lane"
  [launch]
  (def [ctl lane-id aff] launch)
  (when aff (proc/lane-pin lane-id))
  (def serials @{})
  (var overflow nil)
  (defn handle-spawn [msg]
    # [:spawn serial cap entry] -- runs on THIS lane wherever the
    # task came from (ctl or the :steal overflow queue).
    (def [op serial x y] msg)
    (def entry y)
    (def cap (if (number? x) x 64))
    # node = lane-id + 1 (0 is reserved for the main VM;
    # handles and the cached cross-pid must agree).
    (def p (proc/spawn (fn []
                         (setdyn :proc-cross-pid
                                 [:pid (inc lane-id) serial ctl])
                         (entry))
                       cap))
    (put serials serial p))
  (while true
    # Milestone 2c idle pull: before parking on the control channel,
    # drain up to K tasks from the :steal overflow queue. This
    # converts spare capacity into throughput without proc migration.
    (when overflow
      (var k 0)
      (var going true)
      (while (and going (< k 4))
        (def task (proc/lane-pull overflow))
        (if task
          (do (handle-spawn task) (++ k))
          (set going false))))
    (def [op serial x y] (ev/take ctl))
    (case op
      # [:overflow queue] -- milestone 2c: the global steal queue,
      # delivered here before any spawn traffic.
      :overflow (set overflow y)
      # [:pull] -- wakeup nudge from an overflowing spawner: drain the
      # overflow queue fully (the dispatcher was parked; nothing else
      # would see the tasks).
      :pull (when overflow
              (var going true)
              (while going
                (def task (proc/lane-pull overflow))
                (if task (handle-spawn task) (set going false))))
      :spawn (handle-spawn [op serial x y])
      :deliver (if-let [p (or (get serials serial) (proc/lane-lookup serial))]
                 (proc/send p x))
      # [:proc-fwd serial msg] -- resolve to the LOCAL proc first
      # (dual-key lane registry); the serials tuple would re-forward.
      :proc-fwd (if-let [p (or (proc/lane-lookup serial) (get serials serial))]
                  (proc/send p x))  # [:proc-fwd serial msg] -- 3-tuple
      # [:proc-monitor serial tag watcher] -- P2.3 remote monitor
      # registration (procx/monitor-chan). Host the reaper on the
      # watched proc's home lane: take the local sup, derive the
      # P2.3 reason (:normal on ok, else fiber/last-value), record
      # the exit reason, deliver [:down tag reason] to the watcher
      # channel (a threaded push marshals across VMs). Unknown
      # serial: :noproc.
      :proc-monitor (do (if-let [p (proc/lane-lookup serial)]
                      (do
                        (def sup (proc/sup-of p))
                        (def ch y)
                        (def tag x)
                        (ev/go
                          (fn []
                            (def [sig fib _] (ev/take sup))
                            (def reason (if (= sig :ok) :normal (fiber/last-value fib)))
                            (proc/record-exit p reason)
                            # watcher: channel (give) or pid tuple (send
                            # -- routes through the watcher's home lane)
                            (if (= :core/channel (type ch))
                              (ev/give ch [:down tag reason])
                              (proc/send ch [:down tag reason])))))
                      (ev/give y [:down x :noproc])))
      # [:kill serial reason] -- resolve to the LOCAL proc (serials
      # stores pid tuples; repushing would echo the op forever) and
      # apply the kill on the home lane.
      :kill (if-let [p (proc/lane-lookup serial)]
              (proc/kill p x))
      :stop (do
              # Milestone 2a: wake locally-parked procs so the worker's
              # event loop can drain and the lane thread can be joined.
              # Best effort: try-send never blocks the dispatcher, and
              # procs in long loops keep the lane alive (the join's
              # grace detaches it instead).
              (each p (values serials)
                (proc/try-send p :lane-stop))
              (break))
      nil)))

(setdyn :proc-lane-worker proc/lane-worker)

(def load-image-dict
  ``A table used in combination with `unmarshal` to unmarshal byte sequences created
  by `make-image`, such that `(load-image bytes)` is the same as `(unmarshal bytes load-image-dict)`.``
  @{})

(def make-image-dict
  ``A table used in combination with `marshal` to marshal code (images), such that
  `(make-image x)` is the same as `(marshal x make-image-dict)`.``
  @{})

(defmacro comptime
  "Evals x at compile time and returns the result. Similar to a top level unquote."
  [x]
  (def y (eval x))
  y)

(defmacro compif
  "Check the condition `cnd` at compile time -- if truthy, compile `tru`, else compile `fals`."
  [cnd tru &opt fals]
  (if (eval cnd)
    tru
    fals))

(defmacro compwhen
  "Check the condition `cnd` at compile time -- if truthy, compile `(upscope ;body)`, else compile nil."
  [cnd & body]
  (if (eval cnd)
    ~(upscope ,;body)))

(defn make-image
  ``Create an image from an environment returned by `require`.
  Returns the image source as a string.``
  [env]
  (marshal env make-image-dict))

(defn load-image
  "The inverse operation to `make-image`. Returns an environment."
  [image]
  (unmarshal image load-image-dict))

(defn- check-dyn-relative [x] (if (string/has-prefix? "@" x) x))
(defn- check-relative [x] (if (string/has-prefix? "." x) x))
# Don't try to preload absolute or relative paths
(defn- check-preloadable [x] (if-not (or (string/has-prefix? "/" x) (string/find "." x) (string/find "@" x)) x))
(defn- check-is-dep [x] (unless (or (string/has-prefix? "/" x) (string/has-prefix? "@" x) (string/has-prefix? "." x)) x))
(defn- check-project-relative [x] (if (string/has-prefix? "/" x) x))

(defdyn *module-cache* "Dynamic binding for overriding `module/cache`")
(defdyn *module-paths* "Dynamic binding for overriding `module/paths`")
(defdyn *module-loading* "Dynamic binding for overriding `module/loading`")
(defdyn *module-loaders* "Dynamic binding for overriding `module/loaders`")
(defdyn *module-make-env* "Dynamic binding for creating new environments for `import`, `require`, and `dofile`. Overrides `make-env`.")

(def module/cache
  "A table, mapping loaded module identifiers to their environments."
  @{})

(def module/paths
  ```
  The list of paths to look for modules, templated for `module/expand-path`.
  Each element is a two-element tuple, containing the path
  template and a keyword :source, :native, or :image indicating how
  `require` should load files found at these paths.

  A tuple can also
  contain a third element, specifying a filter that prevents `module/find`
  from searching that path template if the filter doesn't match the input
  path. The filter can be a string or a predicate function, and
  is often a file extension, including the period.
  ```
  @[])

(defn module/add-paths
  ```
  Add paths to `module/paths` for a given loader such that
  the generated paths behave like other module types, including
  relative imports and syspath imports. `ext` is the file extension
  to associate with this module type, including the dot. `loader` is the
  keyword name of a loader in `module/loaders`. Returns the modified `module/paths`.
  ```
  [ext loader]
  (def mp (dyn *module-paths* module/paths))
  (defn- find-prefix
    [pre]
    (or (find-index |(and (string? ($ 0)) (string/has-prefix? pre ($ 0))) mp) 0))
  (def dyn-index (find-prefix ":@all:"))
  (array/insert mp dyn-index [(string ":@all:" ext) loader check-dyn-relative])
  (def all-index (find-prefix ".:all:"))
  (array/insert mp all-index [(string ".:all:" ext) loader check-project-relative])
  (def sys-index (find-prefix ":sys:"))
  (array/insert mp sys-index [(string ":sys:/:all:" ext) loader check-is-dep])
  (def curall-index (find-prefix ":cur:/:all:"))
  (array/insert mp curall-index [(string ":cur:/:all:" ext) loader check-relative])
  mp)

(defn module/add-file-extension
  ```
  Add paths to `module/paths` for a given file extension such that
  the programmer can import a module by relative or absolute path from
  the current working directory.
  Returns the modified `module/paths`.
  ```
  [ext loader]
  (assert (string/has-prefix? "." ext) "file extension must have . prefix")
  (def mp (dyn *module-paths* module/paths))
  (array/insert mp 0 [":all:" loader (fn :check-ext [x] (string/has-suffix? ext x))])
  mp)

(defn module/add-syspath
  ```
  Add a custom syspath to `module/paths` by duplicating all entries that being with `:sys:` and
  adding duplicates with a specific path prefix instead.
  ```
  [path]
  (def copies @[])
  (var last-index 0)
  (def mp (dyn *module-paths* module/paths))
  (eachp [index entry] mp
    (def pattern (first entry))
    (when (and (string? pattern) (string/has-prefix? ":sys:/" pattern))
      (set last-index index)
      (array/push copies [(string/replace ":sys:" path pattern) ;(drop 1 entry)])))
  (array/insert mp (+ 1 last-index) ;copies)
  mp)

(module/add-paths ":native:" :native)
(module/add-paths "/init.janet" :source)
(module/add-paths ".janet" :source)
(module/add-paths ".jimage" :image)
(module/add-file-extension ".janet" :source)
(module/add-file-extension ".jimage" :source)
# These obviously won't work on all platforms, but if a user explicitly
# tries to import them, we may as well try.
(module/add-file-extension ".so" :native)
(module/add-file-extension ".dll" :native)
(array/insert module/paths 0
              [(fn is-cached [path] (if (in (dyn *module-cache* module/cache) path) path))
               :preload
               check-preloadable])

# Version of fexists that works even with a reduced OS
(defn- fexists
  [path]
  (compif (dyn 'os/stat)
    (= :file (os/stat path :mode))
    (when-let [f (file/open path :rb)]
      (def res
        (try (do (file/read f 1) true)
          ([err] nil)))
      (file/close f)
      res)))

(defn- mod-filter
  [x path]
  (case (type x)
    :nil path
    :string (string/has-suffix? x path)
    (x path)))

(defn module/find
  ``
  Try to match a module or path name from the patterns in
  `module/paths`.  Returns a tuple `[fullpath kind]` where the kind is
  one of `:source`, `:native`, or `:image` if the module is found,
  otherwise a tuple with nil followed by an error message.
  ``
  [path &opt find-all]
  (var ret nil)
  (def mp (dyn *module-paths* module/paths))
  (def all-matches (if find-all @[]))
  (each [p mod-kind checker] mp
    (when (mod-filter checker path)
      (if (function? p)
        (when-let [res (p path)]
          (set ret [res mod-kind])
          (if find-all (array/push all-matches ret) (break)))
        (do
          (def fullpath (string (module/expand-path path p)))
          (when (fexists fullpath)
            (set ret [fullpath mod-kind])
            (if find-all (array/push all-matches ret) (break)))))))
  (if find-all (break all-matches))
  (if ret ret
    (let [expander (fn :expander [[t _ chk]]
                     (when (string? t)
                       (when (mod-filter chk path)
                         (module/expand-path path t))))
          paths (filter identity (map expander mp))
          str-parts (interpose "\n    " paths)]
      [nil (string "could not find module " path ":\n    " ;str-parts)])))

(def module/loading
  `A table, mapping currently loading modules to true. Used to prevent
  circular dependencies.`
  @{})

(defn module/value
  ``Given a module table, get the value bound to a symbol `sym`. If `private` is
  truthy, will also resolve private module symbols. If no binding is found, will return
  nil.``
  [module sym &opt private]
  (def entry (get module sym))
  (if entry
    (let [v (in entry :value)
          r (in entry :ref)
          p (in entry :private)]
      (if p (if private nil (break)))
      (if (and r (array? r))
        (get r 0)
        v))))

(def debugger-env
  "An environment that contains dot prefixed functions for debugging."
  @{})

(var- debugger-on-status-var nil)

(defn debugger
  ``
  Run a repl-based debugger on a fiber `fib`. Optionally pass in a level to
  differentiate nested debuggers.
  ``
  [fib &opt level]
  (default level 1)
  (def nextenv (make-env (fiber/getenv fib)))
  (put nextenv :fiber fib)
  (put nextenv :debug-level level)
  (put nextenv :signal (fiber/last-value fib))

  (merge-into nextenv debugger-env)
  (defn debugger-chunks [buf p]
    (def status (:state p :delimiters))
    (def c ((:where p) 0))
    (def prpt (string "debug[" level "]:" c ":" status "> "))
    (getline prpt buf nextenv))
  (eprint "entering debug[" level "] - (quit) to exit")
  (flush)
  (run-context
    {:chunks debugger-chunks
     :on-status (debugger-on-status-var nextenv (+ 1 level) true)
     :env nextenv})
  (eprint "exiting debug[" level "]")
  (flush)
  (nextenv :resume-value))

(defn debugger-on-status
  "Create a function that can be passed to `run-context`'s `:on-status`
  argument that will drop into a debugger on errors. The debugger will
  only start on abnormal signals if the env table has the `:debug` dyn
  set to a truthy value."
  [env &opt level is-repl]
  (default level 1)
  (fn :debugger [f x]
    (def fs (fiber/status f))
    (if (= :dead fs)
      (when is-repl
        (put env '_ @{:value x})
        (def pf (get env *pretty-format* "%q"))
        (try
          (printf pf x)
          ([e]
            (eprintf "bad pretty format %v: %v" pf e)
            (eflush)))
        (flush))
      (do
        (debug/stacktrace f x "")
        (eflush)
        (if (get env :debug) (debugger f level))))))

(set debugger-on-status-var debugger-on-status)

(defn dofile
  ``Evaluate a file, file path, or stream and return the resulting environment. :env, :expander,
  :source, :evaluator, :read, and :parser are passed through to the underlying
  `run-context` call. If `exit` is true, any top level errors will trigger a
  call to `(os/exit 1)` after printing the error.``
  [path &named exit env source expander evaluator read parser]
  (def f (case (type path)
           :core/file path
           :core/stream path
           (file/open path :rb)))
  (def path-is-file (= f path))
  (default env ((dyn *module-make-env* make-env)))
  (def spath (string path))
  (put env :source (or source (if-not path-is-file spath path)))
  (var exit-error nil)
  (var exit-fiber nil)
  (defn chunks [buf _] (:read f 4096 buf))
  (defn bp [&opt x y]
    (when exit
      (bad-parse x y)
      (os/exit 1))
    (put env :exit true)
    (def buf @"")
    (with-dyns [*err* buf]
      (bad-parse x y))
    (set exit-error (string/slice buf 0 -2)))
  (defn bc [&opt x y z a b]
    (when exit
      (bad-compile x y z a b)
      (os/exit 1))
    (put env :exit true)
    (def buf @"")
    (with-dyns [*err* buf]
      (bad-compile x nil z a b))
    (set exit-error (string/slice buf 0 -2))
    (set exit-fiber y))
  (unless f
    (error (string "could not find file " path)))
  (def nenv
    (run-context {:env env
                  :chunks chunks
                  :on-parse-error bp
                  :on-compile-error bc
                  :on-status (fn [f x]
                               (when (not= (fiber/status f) :dead)
                                 (when exit
                                   (debug/stacktrace f x "")
                                   (eflush)
                                   (os/exit 1))
                                 (if (get env :debug)
                                   ((debugger-on-status env) f x)
                                   (do
                                     (put env :exit true)
                                     (set exit-error x)
                                     (set exit-fiber f)))))
                  :evaluator evaluator
                  :expander expander
                  :read read
                  :parser parser
                  :source (or source (if path-is-file :<anonymous> spath))}))
  (if-not path-is-file (:close f))
  (when exit-error
    (if exit-fiber
      (propagate exit-error exit-fiber)
      (error exit-error)))
  nenv)

(def module/loaders
  ``A table of loading method names to loading functions.
  This table lets `require` and `import` load many different kinds
  of files as modules.``
  @{:native (fn native-loader [path &] (native path ((dyn *module-make-env* make-env))))
    :source (fn source-loader [path args]
              (def ml (dyn *module-loading* module/loading))
              (put ml path true)
              (defer (put ml path nil)
                (dofile path ;args)))
    :preload (fn preload-loader [path & args]
               (def mc (dyn *module-cache* module/cache))
               (when-let [m (in mc path)]
                 (if (function? m)
                   (set (mc path) (m path ;args))
                   m)))
    :image (fn image-loader [path &] (load-image (slurp path)))})

(defn- require-1
  [path args kargs]
  (def [fullpath mod-kind]
    (if-let [loader (get kargs :loader)]
      [path loader]
      (module/find path)))
  (unless fullpath (error mod-kind))
  (def mc (dyn *module-cache* module/cache))
  (def ml (dyn *module-loading* module/loading))
  (def mls (dyn *module-loaders* module/loaders))
  (if-let [check (if-not (get kargs :fresh) (in mc fullpath))]
    check
    (if (get ml fullpath)
      (error (string "circular dependency " fullpath " detected"))
      (do
        (def loader (if (keyword? mod-kind) (get mls mod-kind) mod-kind))
        (unless loader (error (string "module type " mod-kind " unknown")))
        (def env (loader fullpath args))
        (put mc fullpath env)
        env))))

(defn require
  ``Require a module with the given name. Will search all of the paths in
  `module/paths`. Returns the new environment
  returned from compiling and running the file.``
  [path & args]
  (require-1 path args (struct ;args)))

(defn merge-module
  ``Merge a module source into the `target` environment with a `prefix`, as with the `import` macro.
  This lets users emulate the behavior of `import` with a custom module table.
  If `export` is truthy, then merged functions are not marked as private. Returns
  the modified target environment. If a tuple or array `only` is passed, only merge keys in `only`.``
  [target source &opt prefix export only]
  (def only-set (if only (invert only)))
  (loop [[k v] :pairs source :when (symbol? k) :when (not (v :private)) :when (or (not only) (in only-set k))]
    (def newv (table/setproto @{:private (not export)} v))
    (put target (symbol prefix k) newv))
  target)

(defn import*
  ``Function form of `import`. Same parameters, but the path
  and other symbol parameters should be strings instead.``
  [path & args]
  (def env (curenv))
  (def kargs (table ;args))
  (def {:as as
        :prefix prefix
        :export ep
        :only only} kargs)
  (def newenv (require-1 path args kargs))
  (def prefix (or
                (and as (string as "/"))
                prefix
                (string (first (string/split "." (last (string/split "/" path)))) "/")))
  (merge-module env newenv prefix ep only))

(defmacro import
  ``Import a module. First requires the module, and then merges its
  symbols into the current environment, prepending a given prefix as needed.
  (use the :as or :prefix option to set a prefix). If no prefix is provided,
  use the name of the module as a prefix. One can also use "`:export true`"
  to re-export the imported symbols. If "`:exit true`" is given as an argument,
  any errors encountered at the top level in the module will cause `(os/exit 1)`
  to be called. Dynamic bindings will NOT be imported. Use :fresh with a truthy
  value to bypass the module cache. Use `:only [foo bar baz]` to only import
  select bindings into the current environment.``
  [path & args]
  (assertf (even? (length args)) "args should have even length: %n" args)
  (def ps (partition 2 args))
  (def argm
    (mapcat (fn [[k v]]
              (assertf (keyword? k) "expected keyword, got %s: %n" (type k) k)
              [k (case k :as (string v) :only ~(quote ,v) v)])
            ps))
  (tuple import* (string path) ;argm))

(defmacro use
  ``Similar to `import`, but imported bindings are not prefixed with a module
  identifier. Can also import multiple modules in one shot.``
  [& modules]
  ~(do ,;(map |~(,import* ,(string $) :prefix "") modules)))

###
###
### Documentation
###
###

(defn- env-walk
  [pred &opt env local]
  (default env (fiber/getenv (fiber/current)))
  (def envs @[])
  (do (var e env) (while e (array/push envs e) (set e (table/getproto e)) (if local (break))))
  (def ret-set @{})
  (loop [envi :in envs
         k :keys envi
         :when (pred k)]
    (put ret-set k true))
  (sort (keys ret-set)))

(defn all-bindings
  ``Get all symbols available in an environment. Defaults to the current
  fiber's environment. If `local` is truthy, will not show inherited bindings
  (from prototype tables).``
  [&opt env local]
  (env-walk symbol? env local))

(defn all-dynamics
  ``Get all dynamic bindings in an environment. Defaults to the current
  fiber's environment. If `local` is truthy, will not show inherited bindings
  (from prototype tables).``
  [&opt env local]
  (env-walk keyword? env local))

(defdyn *doc-width*
  "Width in columns to print documentation printed with `doc-format`.")

(defdyn *doc-color*
  "Whether or not to colorize documentation printed with `doc-format`.")

(defn doc-format
  `Reformat a docstring to wrap a certain width. Docstrings can either be plaintext
  or a subset of markdown. This allows a long single line of prose or formatted text to be
  a well-formed docstring. Returns a buffer containing the formatted text.`
  [str &opt width indent colorize]

  (default indent 4)
  (def max-width (- (or width (dyn *doc-width* 80)) 8))
  (def has-color (if (not= nil colorize)
                   colorize
                   (dyn *doc-color*)))

  # Terminal codes for emission/tokenization
  (def delimiters
    (if has-color
      {:code ["\e[97m" "\e[39m"]
       :italics ["\e[3m" "\e[23m"]
       :bold ["\e[1m" "\e[22m"]}
      {:code ["`" "`"]
       :italics ["*" "*"]
       :bold ["**" "**"]}))
  (def modes @{})
  (defn toggle-mode [mode]
    (def active (get modes mode))
    (def delims (get delimiters mode))
    (put modes mode (not active))
    (delims (if active 1 0)))

  # Parse state
  (var cursor 0) # indexes into string for parsing
  (var stack @[]) # return value for this block.

  # Traversal helpers
  (defn c [] (get str cursor))
  (defn cn [n] (get str (+ n cursor)))
  (defn c++ [] (let [ret (get str cursor)] (++ cursor) ret))
  (defn c+=n [n] (let [ret (get str cursor)] (+= cursor n) ret))
  # skip* functions return number of characters matched and advance the cursor.
  (defn skipwhite []
    (def x cursor)
    (while (= (c) (chr " ")) (++ cursor))
    (- cursor x))
  (defn skipline []
    (def x cursor)
    (while (let [y (c)] (and y (not= y (chr "\n")))) (++ cursor))
    (c++)
    (- cursor x))

  # Detection helpers - return number of characters matched
  (defn ul? []
    (let [x (c) x1 (cn 1)]
      (and
        (= x1 (chr " "))
        (or (= x (chr "*")) (= x (chr "-")))
        2)))
  (defn ol? []
    (def old cursor)
    (while (and (>= (c) (chr "0")) (<= (c) (chr "9"))) (c++))
    (let [c1 (c) c2 (cn 1) c* cursor]
      (set cursor old)
      (if (and (= c1 (chr ".")) (= c2 (chr " ")))
        (- c* cursor -2))))
  (defn fcb? [] (if (= (chr "`") (c) (cn 1) (cn 2)) 3))
  (defn nl? [] (= (chr "\n") (c)))

  # Parse helper
  # parse-* functions push nodes to `stack`, and return
  # the indentation they leave the cursor on.

  (var parse-blocks nil) # mutual recursion
  (defn getslice [from to]
    (def to (min to (length str)))
    (string/slice str from to))
  (defn push [x] (array/push stack x))

  (defn parse-list [bullet-check initial indent]
    (def temp-stack @[initial])
    (def old-stack stack)
    (set stack temp-stack)
    (var current-indent indent)
    (while (and (c) (>= current-indent indent))
      (def item-indent
        (when-let [x (bullet-check)]
          (c+=n x)
          (+ indent (skipwhite) x)))
      (unless item-indent
        (set current-indent (skipwhite))
        (break))
      (def item-stack @[])
      (set stack item-stack)
      (set current-indent (parse-blocks item-indent))
      (set stack temp-stack)
      (push item-stack))
    (set stack old-stack)
    (push temp-stack)
    current-indent)

  (defn add-codeblock [indent start end]
    (def replace-chunk (string "\n" (string/repeat " " indent)))
    (push @[:cb (string/replace-all replace-chunk "\n" (getslice start end))])
    (skipline)
    (skipwhite))

  (defn parse-fcb [indent]
    (c+=n 3)
    (skipline)
    (c+=n indent)
    (def start cursor)
    (var end cursor)
    (while (c)
      (if (fcb?) (break))
      (skipline)
      (set end cursor)
      (skipwhite))
    (add-codeblock indent start end))

  (defn parse-icb [indent]
    (var current-indent indent)
    (def start cursor)
    (var end cursor)
    (while (c)
      (skipline)
      (set end cursor)
      (set current-indent (skipwhite))
      (if (< current-indent indent) (break)))
    (add-codeblock indent start end))

  (defn tokenize-line [line]
    (def tokens @[])
    (def token @"")
    (var token-length 0)
    (defn delim [mode]
      (def d (toggle-mode mode))
      (if-not has-color (+= token-length (length d)))
      (buffer/push token d))
    (defn endtoken []
      (if (first token) (array/push tokens [(string token) token-length]))
      (buffer/clear token)
      (set token-length 0))
    (forv i 0 (length line)
      (def b (get line i))
      (cond
        (or (= b (chr "\n")) (= b (chr " "))) (endtoken)
        (= b (chr "`")) (delim :code)
        (not (modes :code))
        (cond
          (= b (chr `\`)) (do
                            (++ token-length)
                            (buffer/push token (get line (++ i))))
          (= b (chr "*"))
          (if (= (chr "*") (get line (+ i 1)))
            (do (++ i)
              (delim :bold))
            (delim :italics))
          (do (++ token-length) (buffer/push token b)))
        (do (++ token-length) (buffer/push token b))))
    (endtoken)
    (tuple/slice tokens))

  (set
    parse-blocks
    (fn parse-blocks [indent]
      (var new-indent indent)
      (var p-start nil)
      (var p-end nil)
      (defn p-line []
        (unless p-start
          (set p-start cursor))
        (skipline)
        (set p-end cursor)
        (set new-indent (skipwhite)))
      (defn finish-p []
        (when (and p-start (> p-end p-start))
          (push (tokenize-line (getslice p-start p-end)))
          (set p-start nil)))
      (while (and (c) (>= new-indent indent))
        (cond
          (nl?) (do (finish-p) (c++) (set new-indent (skipwhite)))
          (ul?) (do (finish-p) (set new-indent (parse-list ul? :ul new-indent)))
          (ol?) (do (finish-p) (set new-indent (parse-list ol? :ol new-indent)))
          (fcb?) (do (finish-p) (set new-indent (parse-fcb new-indent)))
          (>= new-indent (+ 4 indent)) (do (finish-p) (set new-indent (parse-icb new-indent)))
          (p-line)))
      (finish-p)
      new-indent))

  # Handle first line specially for defn, defmacro, etc.
  (when (= (chr "(") (in str 0))
    (skipline)
    (def first-line (string/slice str 0 (- cursor 1)))
    (def fl-open (if has-color "\e[97m" ""))
    (def fl-close (if has-color "\e[39m" ""))
    (push [[(string fl-open first-line fl-close) (length first-line)]]))

  (parse-blocks 0)

  # Emission state
  (def buf @"")
  (var current-column 0)

  # Emission
  (defn emit-indent [indent]
    (def delta (- indent current-column))
    (when (< 0 delta)
      (buffer/push buf (string/repeat " " delta))
      (set current-column indent)))

  (defn emit-nl [&opt indent]
    (buffer/push buf "\n")
    (set current-column 0))

  (defn emit-word [word indent &opt len]
    (def last-byte (last buf))
    (when (and
            last-byte
            (not= last-byte (chr "\n"))
            (not= last-byte (chr " ")))
      (buffer/push buf " ")
      (++ current-column))
    (default len (length word))
    (when (and indent (> (+ 1 current-column len) max-width))
      (emit-nl)
      (emit-indent indent))
    (buffer/push buf word)
    (+= current-column len))

  (defn emit-code
    [code indent]
    (def replacement (string "\n" (string/repeat " " (+ 4 indent))))
    (emit-indent (+ 4 indent))
    (buffer/push buf (string/replace-all "\n" replacement code))
    (if (= (chr "\n") (last code))
      (set current-column 0)
      (emit-nl)))

  (defn emit-node
    [el indent]
    (emit-indent indent)
    (if (tuple? el)
      (let [rep (string "\n" (string/repeat " " indent))]
        (each [word len] el
          (emit-word
            (string/replace-all "\n" rep word)
            indent
            len))
        (emit-nl))
      (case (first el)
        :ul (for i 1 (length el)
              (if (> i 1) (emit-indent indent))
              (emit-word "* " nil)
              (each subel (get el i) (emit-node subel (+ 2 indent))))
        :ol (for i 1 (length el)
              (if (> i 1) (emit-indent indent))
              (def lab (string/format "%d. " i))
              (emit-word lab nil)
              (each subel (get el i) (emit-node subel (+ (length lab) indent))))
        :cb (emit-code (get el 1) indent))))

  (each el stack
    (emit-nl)
    (emit-node el indent))

  buf)

(defn- print-index
  "Print bindings in the current environment given a filter function."
  [fltr]
  (def bindings (filter fltr (all-bindings)))
  (def dynamics (map describe (filter fltr (all-dynamics))))
  (print)
  (print (doc-format (string "Bindings:\n\n" (string/join bindings " ")) nil nil false))
  (print)
  (print (doc-format (string "Dynamics:\n\n" (string/join dynamics " ")) nil nil false))
  (print "\n    Use (doc sym) for more information on a binding.\n"))

(defn- print-module-entry
  [x]
  (def bind-type
    (string "    "
            (cond
              (x :redef) (type (in (x :ref) 0))
              (x :ref) (string :var " (" (type (in (x :ref) 0)) ")")
              (x :macro) :macro
              (x :module) (string :module " (" (x :kind) ")")
              (type (x :value)))
            "\n"))
  (def sm (x :source-map))
  (def d (x :doc))
  (print "\n\n"
         bind-type
         (when-let [[path line col] sm]
           (string "    " path (when (and line col) (string " on line " line ", column " col))))
         (when sm "\n")
         (if d (doc-format d) "\n    no documentation found.\n")
         "\n"))

(defn- print-special-form-entry
  [x]
  (print "\n\n"
         "    special form\n\n"
         "    (" x " ...)\n\n"
         "    See https://janet-lang.org/docs/specials.html\n\n"))

(defn doc*
  "Get the documentation for a symbol in a given environment. Function form of `doc`."
  [&opt sym]

  (cond
    (string? sym)
    (print-index (fn [x] (string/find sym x)))

    sym
    (do
      (def x (dyn sym))
      (if (not x)
        (if (index-of sym '[break def do fn if quasiquote quote
                            set splice unquote upscope var while])
          (print-special-form-entry sym)
          (do
            (def [fullpath mod-kind] (module/find (string sym)))
            (if-let [mod-env (in module/cache fullpath)]
              (print-module-entry {:module true
                                   :kind mod-kind
                                   :source-map [fullpath nil nil]
                                   :doc (in mod-env :doc)})
              (print "symbol " sym " not found."))))
        (print-module-entry x)))

    # else
    (print-index identity)))

(defmacro doc
  ``
  Shows documentation for `what` or lists binding names. If `what` is
  a symbol, shows documentation for that symbol. If `what` is a
  string, shows all lexical and dynamic binding names in the current
  environment containing the string. If `what` is not provided, shows
  all binding names.
  ``
  [&opt what]
  ~(,doc* ',what))

(defn doc-of
  `Searches all loaded modules in module/cache for a given binding and prints out its documentation.
  This does a search by value instead of by name. Returns nil.`
  [x]
  (var found false)
  (loop [module-set :in [[root-env] module/cache]
         module :in module-set
         value :in module]
    (let [check (or (get value :ref) (get value :value))]
      (when (= check x)
        (print-module-entry value)
        (set found true)
        (break))))
  (if-not found
    (print "documentation for value " x " not found.")))

###
###
### Debugger
###
###

(defn .fiber
  "Get the current fiber being debugged."
  []
  (dyn :fiber))

(defn .signal
  "Get the current signal being debugged."
  []
  (dyn :signal))

(defn .stack
  "Print the current fiber stack."
  []
  (print)
  (with-dyns [*err-color* false] (debug/stacktrace (.fiber) (.signal) ""))
  (print))

(defn .frame
  "Show a stack frame"
  [&opt n]
  (def stack (debug/stack (.fiber)))
  (in stack (or n 0)))

(defn .locals
  "Show local bindings"
  [&opt n]
  (get (.frame n) :locals))

(defn .fn
  "Get the current function."
  [&opt n]
  (in (.frame n) :function))

(defn .slots
  "Get an array of slots in a stack frame."
  [&opt n]
  (in (.frame n) :slots))

(defn .slot
  "Get the value of the nth slot."
  [&opt nth frame-idx]
  (in (.slots frame-idx) (or nth 0)))

# Conditional compilation for disasm
(compwhen (dyn 'disasm)

  (defn .disasm
    "Gets the assembly for the current function."
    [&opt n]
    (def frame (.frame n))
    (def func (frame :function))
    (disasm func))

  (defn .bytecode
    "Get the bytecode for the current function."
    [&opt n]
    ((.disasm n) :bytecode))

  (defn .ppasm
    "Pretty prints the assembly for the current function."
    [&opt n]
    (def frame (.frame n))
    (def func (frame :function))
    (def dasm (disasm func))
    (def bytecode (in dasm :bytecode))
    (def pc (frame :pc))
    (def sourcemap (in dasm :sourcemap))
    (var last-loc [-2 -2])
    (eprint "\n  signal:     " (.signal))
    (eprint "  status:     " (fiber/status (.fiber)))
    (eprint "  function:   " (get dasm :name "<anonymous>") " [" (in dasm :source "") "]")
    (when-let [constants (dasm :constants)]
      (eprintf "  constants:  %.4q" constants))
    (eprintf "  slots:      %.4q\n" (frame :slots))
    (when-let [src-path (in dasm :source)]
      (when (and (fexists src-path)
                 sourcemap)
        (defn dump
          [src cur]
          (def offset 5)
          (def beg (max 1 (- cur offset)))
          (def lines (array/concat @[""] (string/split "\n" src)))
          (def end (min (+ cur offset) (length lines)))
          (def digits (inc (math/floor (math/log10 end))))
          (def fmt-str (string "%" digits "d: %s"))
          (for i beg end
            (eprin " ")
            (eprin (if (= i cur) "> " "  "))
            (eprintf fmt-str i (get lines i))))
        (let [[sl _] (sourcemap pc)]
          (dump (slurp src-path) sl)
          (eprint))))
    (def padding (string/repeat " " 20))
    (loop [i :range [0 (length bytecode)]
           :let [instr (bytecode i)]]
      (eprin (if (= (tuple/type instr) :brackets) "*" " "))
      (eprin (if (= i pc) "> " "  "))
      (eprinf "%.20s" (string (string/join (map string instr) " ") padding))
      (when sourcemap
        (let [[sl sc] (sourcemap i)
              loc [sl sc]]
          (when (not= loc last-loc)
            (set last-loc loc)
            (eprin " # line " sl ", column " sc))))
      (eprint))
    (eprint))

  (defn .breakall
    "Set breakpoints on all instructions in the current function."
    [&opt n]
    (def fun (.fn n))
    (def bytecode (.bytecode n))
    (forv i 0 (length bytecode)
      (debug/fbreak fun i))
    (eprint "set " (length bytecode) " breakpoints in " fun))

  (defn .clearall
    "Clear all breakpoints on the current function."
    [&opt n]
    (def fun (.fn n))
    (def bytecode (.bytecode n))
    (forv i 0 (length bytecode)
      (debug/unfbreak fun i))
    (eprint "cleared " (length bytecode) " breakpoints in " fun)))

(defn .source
  "Show the source code for the function being debugged."
  [&opt n]
  (def frame (.frame n))
  (def s (frame :source))
  (def all-source (slurp s))
  (eprint "\n" all-source "\n"))

(defn .break
  "Set breakpoint at the current pc."
  []
  (def frame (.frame))
  (def fun (frame :function))
  (def pc (frame :pc))
  (debug/fbreak fun pc)
  (eprint "set breakpoint in " fun " at pc=" pc))

(defn .clear
  "Clear the current breakpoint."
  []
  (def frame (.frame))
  (def fun (frame :function))
  (def pc (frame :pc))
  (debug/unfbreak fun pc)
  (eprint "cleared breakpoint in " fun " at pc=" pc))

(defn .next
  "Go to the next breakpoint."
  [&opt n]
  (var res nil)
  (forv i 0 (or n 1)
    (set res (resume (.fiber))))
  res)

(defn .nextc
  "Go to the next breakpoint, clearing the current breakpoint."
  [&opt n]
  (.clear)
  (.next n))

(defn .step
  "Execute the next n instructions."
  [&opt n]
  (var res nil)
  (forv i 0 (or n 1)
    (set res (debug/step (.fiber))))
  res)

(def- debugger-keys (filter (partial string/has-prefix? ".") (keys root-env)))
(each k debugger-keys (put debugger-env k (root-env k)) (put root-env k nil))

###
###
### REPL
###
###

(defn repl
  ``Run a repl. The first parameter is an optional function to call to
  get a chunk of source code that should return nil for end of file.
  The second parameter is a function that is called when a signal is
  caught. One can provide an optional environment table to run
  the repl in, as well as an optional parser or read function to pass
  to `run-context`.``
  [&opt chunks onsignal env parser read]
  (default env (make-env))
  (default chunks
    (fn :chunks [buf p]
      (def custom-prompt (get env *repl-prompt*))
      (def repl-prompt
        (if custom-prompt
          (custom-prompt p)
          (string
            "repl:"
            ((:where p) 0)
            ":"
            (:state p :delimiters) "> ")))
      (getline repl-prompt buf env)))
  (run-context {:env env
                :chunks chunks
                :on-status (or onsignal (debugger-on-status env 1 true))
                :parser parser
                :read read
                :source :repl}))

###
###
### Extras
###
###

(compwhen (dyn 'ev/go)

  (defn net/close "Alias for `ev/close`." [stream] (ev/close stream))

  (defn ev/call
    ```
    Call a function asynchronously.
    Returns a task fiber that is scheduled to run the function.
    ```
    [f & args]
    (ev/go (fn :call [&] (f ;args))))

  (defmacro ev/spawn
    ``
    Run some code in a new task fiber. This is shorthand for
    `(ev/go (fn [] ;body))`.
    ``
    [& body]
    ~(,ev/go (fn :spawn [&] ,;body)))

  (defmacro ev/do-thread
    ``Run some code in a new thread. Suspends the current fiber until the thread is complete, and
    evaluates to nil.``
    [& body]
    ~(,ev/thread (fn :do-thread [&] ,;body)))

  (defn- acquire-release
    [acq rel lock body]
    (def l (gensym))
    ~(do
       (def ,l ,lock)
       (,acq ,l)
       (defer (,rel ,l)
         ,;body)))

  (defmacro ev/with-lock
    ``Run a body of code after acquiring a lock. Will automatically release the lock when done.``
    [lock & body]
    (acquire-release ev/acquire-lock ev/release-lock lock body))

  (defmacro ev/with-rlock
    ``Run a body of code after acquiring read access to an rwlock. Will automatically release the lock when done.``
    [lock & body]
    (acquire-release ev/acquire-rlock ev/release-rlock lock body))

  (defmacro ev/with-wlock
    ``Run a body of code after acquiring write access to an rwlock. Will automatically release the lock when done.``
    [lock & body]
    (acquire-release ev/acquire-wlock ev/release-wlock lock body))

  (defmacro ev/spawn-thread
    ``Run some code in a new thread. Like `ev/do-thread`, but returns nil immediately.``
    [& body]
    ~(,ev/thread (fn :spawn-thread [&] ,;body) nil :n))

  (defmacro ev/with-deadline
    ``
    Create a fiber to execute `body`, schedule the event loop to cancel
    the task (root fiber) associated with `body`'s fiber, and start
    `body`'s fiber by resuming it.

    The event loop will try to cancel the root fiber if `body`'s fiber
    has not completed after at least `sec` seconds.

    `sec` is a number that can have a fractional part.
    ``
    [sec & body]
    (with-syms [f]
      ~(as-macro ,let [,f (as-macro ,coro ,;body)]
                 (,ev/deadline ,sec nil ,f)
                 (,resume ,f))))

  (defn- cancel-all [chan fibers reason]
    (each f fibers (ev/cancel f reason))
    (let [n (length fibers)]
      (table/clear fibers)
      (repeat n (ev/take chan))))

  (defn- wait-for-fibers
    [chan fibers]
    (defer (cancel-all chan fibers "parent canceled")
      (repeat (length fibers)
        (def [sig fiber] (ev/take chan))
        (if (= sig :ok)
          (put fibers fiber nil)
          (do
            (cancel-all chan fibers "sibling canceled")
            (propagate (fiber/last-value fiber) fiber))))))

  (defn ev/go-gather
    ```
    Run a dyanmic number of fibers in parallel and resume the current fiber after they complete. Takes
    an array of functions or fibers, `thunks`, that will be run via `ev/go` in another task.
    Returns the gathered results in an array.
    ```
    [thunks]
    (def fset @{})
    (def chan (ev/chan))
    (def results @[])
    (each thunk thunks
      (def ftemp (ev/go thunk nil chan))
      (array/push results ftemp)
      (put fset ftemp ftemp))
    (wait-for-fibers chan fset)
    (for i 0 (length results) # avoid extra copy from map
      (set (results i) (fiber/last-value (in results i))))
    results)

  (defmacro ev/gather
    ``
    Create and run a number of fibers in parallel (created from `bodies`) and resume the
    current fiber after they complete. Shorthand for `ev/go-gather`. Returns the gathered results in an
    array.
    ``
    [& bodies]
    ~(,ev/go-gather ,(seq [body :in bodies] ~(fn :ev/gather [] ,body)))))

  (defn pool/call
    ``Run `(apply func args)` on a worker of the C pool `p` (see `pool/spawn`)
    and wait for the result. Task errors re-raise in the caller; the worker
    survives. With `timeout` (seconds), raise a timeout error instead of
    waiting; the late result is dropped. Blocks while the queue is full.``
    [p func args &opt timeout]
    (pool/acquire p)
    (pool/dispatch p func args :call timeout))

  (defn pool/submit
    ``Enqueue `(apply func args)` on the C pool `p` and return a 1-slot
    reply channel. `(ev/take ch)` gives the result; task errors arrive as
    `[:pool-error err]`. Blocks while the queue is full.``
    [p func args]
    (pool/acquire p)
    (pool/dispatch p func args :submit))

  (defn pool/collect
    ``Take one result from a `pool/submit` reply channel, re-raising
    `[:pool-error err]` as an error. With `timeout` (seconds), raise a
    timeout error instead of waiting.``
    [rch &opt timeout]
    (def raw
      (if (nil? timeout)
        (ev/take rch)
        (let [tch (ev/chan 1)]
          (ev/go (fn [] (ev/sleep timeout) (ev/give tch :pool-timed-out)))
          (def sel (ev/select rch tch))
          (if (= tch (sel 1))
            (error "pool call timed out")
            (sel 2)))))
    (if (and (tuple? raw) (= 2 (length raw)) (= :pool-error (raw 0)))
      (error (raw 1))
      raw))

  (defn pool/map
    ``Fan `func` over `arglist` (each element is the argument array for one
    call) on the C pool `p` and collect results in order. Task errors
    re-raise; `timeout` applies per result.``
    [p func arglist &opt timeout]
    (def chans (map (fn [args] (pool/submit p func args)) arglist))
    (map (fn [ch] (pool/collect ch timeout)) chans))

(compwhen (dyn 'net/listen)
  (defn net/server
    ``
    Starts a server with `net/listen`. Runs `net/accept-loop`
    asynchronously if `handler` is set and `cntype` is `:stream` (the
    default). It is invalid to set `handler` if `cntype` is
    `:datagram`. Returns the new server stream.
    ``
    [host port &opt handler cntype no-reuse]
    (assert (not (and (= cntype :datagram) handler))
            "handler not supported for :datagram servers")
    (def s (net/listen host port cntype no-reuse))
    (when handler
      (ev/go (fn :net/server-handler [] (net/accept-loop s handler)))
      # Ensure accept-loop has started before returning. Not completely needed, but avoids
      # the possibility of closing `s` before `net/accept-loop` runs
      # and getting an annoying error print from `:net/server-handler`
      (ev/sleep 0))
    s))

###
###
### FFI Extra
###
###

(defmacro delay
  "Lazily evaluate a series of expressions. Returns a function that
  returns the result of the last expression. Will only evaluate the
  body once, and then memoizes the result."
  [& forms]
  (def state (gensym))
  (def loaded (gensym))
  ~((fn :delay []
      (var ,state nil)
      (var ,loaded nil)
      (fn []
        (if ,loaded
          ,state
          (do
            (set ,loaded true)
            (set ,state (do ,;forms))))))))

(compwhen (dyn 'ffi/native)

  (defdyn *ffi-context* "Current native library for `ffi/defbind` and other settings")

  (defn- default-mangle
    [name &]
    (string/replace-all "-" "_" name))

  (defn ffi/context
    "Set the path of the dynamic library to implicitly bind, as well
     as other global state for ease of creating native bindings."
    [&opt native-path &named map-symbols lazy]
    (default map-symbols default-mangle)
    (def lib (if lazy nil (ffi/native native-path)))
    (def lazy-lib (if lazy (delay (ffi/native native-path))))
    (setdyn *ffi-context*
            @{:native-path native-path
              :native lib
              :native-lazy lazy-lib
              :lazy lazy
              :map-symbols map-symbols}))

  (defmacro ffi/defbind-alias :flycheck
    "Generate bindings for native functions in a convenient manner.
     Similar to `ffi/defbind` but allows for the janet function name
     to be different than the FFI function."
    [name alias ret-type & body]
    (def real-ret-type (eval ret-type))
    (def meta (slice body 0 -2))
    (def arg-pairs (partition 2 (last body)))
    (def formal-args (map 0 arg-pairs))
    (def type-args (map 1 arg-pairs))
    (def computed-type-args (eval ~[,;type-args]))
    (if (dyn *flychecking*)
      (break ~(defn ,alias ,;meta [,;formal-args] nil)))
    (def {:native lib
          :lazy lazy
          :native-lazy llib
          :map-symbols ms} (assert (dyn *ffi-context*) "no ffi context found"))
    (def raw-symbol (ms name))
    (defn make-sig []
      (ffi/signature :default real-ret-type ;computed-type-args))
    (defn make-ptr []
      (assertf (ffi/lookup (if lazy (llib) lib) raw-symbol) "failed to find ffi symbol %v" raw-symbol))
    (if lazy
      ~(as-macro ,defn ,alias ,;meta {:ffi-alias true} [,;formal-args]
                 (,ffi/call (,(delay (make-ptr))) (,(delay (make-sig))) ,;formal-args))
      ~(as-macro ,defn ,alias ,;meta {:ffi-alias true} [,;formal-args]
                 (,ffi/call ,(make-ptr) ,(make-sig) ,;formal-args))))

  (defmacro ffi/defbind :flycheck
    "Generate bindings for native functions in a convenient manner."
    [name ret-type & body]
    ~(as-macro ,ffi/defbind-alias ,name ,name ,ret-type ,;body)))

  (defn- ffi/struct-field-hint
    "Boxed Janet type of an ffi primitive field (what ffi/read returns)."
    [ft]
    (cond (= ft :long) :long
          (or (= ft :double) (= ft :float) (= ft :int)) :double))

  (defn- ffi/struct-kernel-ty
    "Storage width for kernel-mapped fields, or nil for boxed-only
     (:long reads back s64, pointers stay opaque -- no exact kernel
     contract exists, so kernels using them refuse fail-closed)."
    [ft]
    (cond (= ft :double) :double
          (= ft :float) :float
          (= ft :int) :i32))

  (defmacro ffi/defstruct
    "Declare a C-compatible struct with positional fields and generate
     the whole companion kit: descriptor (ffi/defbind-compatible), size,
     offsets, tuple constructor, native allocator, and field accessors.
     Accessors work boxed everywhere; fields of type :double, :float,
     or :int additionally carry :kernel metadata, so AOT kernels read
     and write them as direct native-memory access (see
     docs/internals/native-memory.md). Other field types stay
     boxed-only. Example: (ffi/defstruct Point x :double y :double)."
    [name & fields]
    (def pairs (partition 2 fields))
    (when (or (empty? pairs) (some (fn [pr] (not= 2 (length pr))) pairs))
      (error (string "ffi/defstruct needs field/type pairs: " name)))
    (def fnames (map 0 pairs))
    (def ftypes (map 1 pairs))
    # layout: align-up walk with ffi size/align (same rules defbind uses)
    (def offs @[])
    (var cur 0)
    (var maxalign 1)
    (each ft ftypes
      (def al (ffi/align ft))
      (def sz (ffi/size ft))
      (when (> al maxalign) (set maxalign al))
      (set cur (+ cur (% (- al (% cur al)) al)))
      (array/push offs cur)
      (+= cur sz))
    (def size (+ cur (% (- maxalign (% cur maxalign)) maxalign)))
    (def descriptor (tuple ;(map (fn [ft] ft) ftypes)))
    (defn acc-name [kind fnm] (symbol name kind fnm))
    (def forms @[(tuple 'def (symbol name "/descriptor") (tuple 'quote descriptor))
                 (tuple 'def (symbol name "/size") size)
                 (tuple 'def (symbol name "/offsets")
                        (struct ;(interleave (map keyword fnames) offs)))])
    # tuple constructor (compat path)
    (array/push forms
      (tuple 'defn (symbol name "/new") (tuple ;(map (fn [fnm] fnm) fnames))
             (tuple 'tuple ;(map (fn [fnm] fnm) fnames))))
    # native allocator + free
    (array/push forms
      (tuple 'defn (symbol name "/malloc") (tuple ;(map (fn [fnm] fnm) fnames))
             (tuple 'do
                    (tuple 'def 'p (tuple 'unsafe/calloc 1 size))
                    ;(map (fn [pr off]
                           (tuple 'unsafe/poke (pr 1) 'p (pr 0) off))
                         pairs offs)
                    'p)))
    (array/push forms
      (tuple 'defn (symbol name "/free") (tuple 'p) (tuple 'unsafe/free 'p)))
    # accessors: boxed bodies (ffi/read / unsafe/poke), kernel metadata
    # where the field type has an exact kernel contract
    (eachp [i pr] pairs
      (def fnm (pr 0))
      (def ft (pr 1))
      (def off (offs i))
      (def ht (ffi/struct-field-hint ft))
      (def kt (ffi/struct-kernel-ty ft))
      (def gmeta (if kt
                   {:hint {:params [:pointer] :returns ht}
                    :kernel {:pread [kt off]}}
                   {:hint {:params [:pointer] :returns ht}}))
      (array/push forms
        (tuple 'defn (acc-name "/" fnm) gmeta (tuple 'p)
               (tuple 'ffi/read ft 'p off)))
      (def smeta (if kt
                   {:hint {:params [:pointer ht] :returns ht}
                    :kernel {:pwrite [kt off]}}
                   {:hint {:params [:pointer ht] :returns ht}}))
      (array/push forms
        (tuple 'defn (acc-name "/set-" fnm) smeta (tuple 'p 'v)
               (tuple 'do (tuple 'unsafe/poke ft 'p 'v off) 'v))))
    # Install NOW into the compilation env: a returned (do ...) would
    # keep the defs scope-local (invisible to later forms), so evaluate
    # each form here like normal loading does. The returned do-block
    # re-establishes the same bindings for pure-syntax tools (flycheck,
    # janet -k) that expand without evaluating.
    (unless (dyn *flychecking*)
      (def menv (curenv))
      (each f forms (eval f menv)))
    (tuple 'do ;forms))

###
###
### Flychecking
###
###

(def- flycheck-specials @{})

(defn- flycheck-evaluator
  ``
  An evaluator function that is passed to `run-context` that lints
  (flychecks) code for `flycheck`.  This means code will be parsed,
  compiled, and have macros expanded, but the code will not be
  evaluated.
  ``
  [thunk source env where]
  (when (and (tuple? source) (= (tuple/type source) :parens))
    (def head (source 0))
    (def entry (get env head {}))
    (def fc (get flycheck-specials head (get entry :flycheck)))
    (cond
      # Sometimes safe form
      (function? fc)
      (fc thunk source env where)
      # Always safe form
      fc
      (thunk))))

(defn flycheck
  ```
  Check a file for errors without running the file. Found errors
  will be printed to stderr in the usual format. Top level functions
  and macros that have the metadata `:flycheck` will also be evaluated
  during flychecking. For full control, the `:flycheck` metadata can
  also be a function that takes 4 arguments - `thunk`, `source`, `env`,
  and `where`, the same as the `:evaluator` argument to `run-context`.
  Other arguments to `flycheck` are the same as `dofile`. Returns nil.
  ```
  [path &keys kwargs]
  (def new-env (make-env (get kwargs :env)))
  (put new-env *flychecking* true)
  (put new-env *module-cache* @{})
  (put new-env *module-loading* @{})
  (put new-env *module-make-env* (fn :make-flycheck-env [&] (make-env new-env)))
  (try
    (dofile path :evaluator flycheck-evaluator ;(kvs kwargs) :env new-env)
    ([e f]
      (debug/stacktrace f e "")))
  nil)

(defn- no-side-effects
  `Check if form may have side effects. If returns true, then the src
  must not have side effects, such as calling a C function.`
  [src]
  (cond
    (tuple? src)
    (if (= (tuple/type src) :brackets)
      (all no-side-effects src))
    (array? src)
    (all no-side-effects src)
    (dictionary? src)
    (and (all no-side-effects (keys src))
         (all no-side-effects (values src)))
    true))

(defn- is-safe-def [thunk source env where]
  (if-let [ve (get env (source 1))
           fc (get ve :flycheck)]
    (cond
      # Sometimes safe form
      (function? fc)
      (fc thunk source env where)
      # Always safe form
      fc
      (thunk))
    (if (no-side-effects (last source))
      (thunk))))

(defn- flycheck-importer
  [thunk source env where]
  (let [[l c] (tuple/sourcemap source)
        newtup (tuple/setmap (tuple ;source :evaluator flycheck-evaluator) l c)]
    ((compile newtup env where))))

(defn- flycheck-use
  [thunk source env where]
  (each a (drop 1 source) (import* (string a) :prefix "" :evaluator flycheck-evaluator)))

# Add metadata to defs and import macros for flychecking
(each sym ['def 'var]
  (put flycheck-specials sym is-safe-def))
(each sym ['def- 'var- 'defglobal 'varglobal]
  (put (dyn sym) :flycheck is-safe-def))
(each sym ['import 'import* 'dofile 'require]
  (put (dyn sym) :flycheck flycheck-importer))
(each sym ['use]
  (put (dyn sym) :flycheck flycheck-use))

###
###
### Bundle tools
###
###

(compwhen (dyn 'os/stat)

  (def- seps {:windows "\\" :mingw "\\" :cygwin "\\"})
  (defn- sep [] (get seps (os/which) "/"))

  (defn- bundle-dir
    [&opt bundle-name]
    (def s (sep))
    (string (os/realpath (dyn *syspath*)) s "bundle" (if bundle-name s) bundle-name))

  (defn- bundle-file
    [bundle-name filename]
    (def s (sep))
    (string (os/realpath (dyn *syspath*)) s "bundle" s bundle-name s filename))

  (defn- get-manifest-filename
    [bundle-name]
    (bundle-file bundle-name "manifest.jdn"))

  (defn- prime-bundle-paths
    []
    (def s (sep))
    (def path (bundle-dir))
    (os/mkdir path)
    (assert (os/stat path :mode)))

  (defn- get-files [manifest]
    (def files (get manifest :files @[]))
    (put manifest :files files)
    files)

  (defn- rmrf
    "rm -rf in janet"
    [x]
    (case (os/lstat x :mode)
      nil nil
      :directory (do
                   (def s (sep))
                   (each y (os/dir x)
                     (rmrf (string x s y)))
                   (os/rmdir x))
      (os/rm x))
    nil)

  (defn- copyfile
    [from to]
    (if-with [ffrom (file/open from :rb)]
      (if-with [fto (file/open to :wb)]
        (do
          (def perm (os/stat from :permissions))
          (def b (buffer/new 0x10000))
          (forever
            (file/read ffrom 0x10000 b)
            (when (empty? b) (buffer/trim b) (os/chmod to perm) (break))
            (file/write fto b)
            (buffer/clear b)))
        (errorf "destination file %s cannot be opened for writing" to))
      (errorf "source file %s cannot be opened for reading" from)))

  (defn- copyrf
    [from to]
    (case (os/stat from :mode)
      :file (copyfile from to)
      :directory (do
                   (def s (sep))
                   (os/mkdir to)
                   (each y (os/dir from)
                     (copyrf (string from s y) (string to s y)))))
    nil)

  (defn- sync-manifest
    [manifest]
    (def bn (get manifest :name))
    (def manifest-name (get-manifest-filename bn))
    (def b @"")
    (buffer/format b "%j" manifest) # make sure it is valid jdn
    (buffer/clear b)
    (buffer/format b "%.99m\n" manifest)
    (spit manifest-name b))

  (defn bundle/manifest
    "Get the manifest for a given installed bundle."
    [bundle-name]
    (def name (get-manifest-filename bundle-name))
    (assertf (fexists name) "no bundle %v found" bundle-name)
    (parse (slurp name)))

  (defn- get-bundle-module
    [bundle-name]
    (def manifest (bundle/manifest bundle-name))
    (def dir (os/cwd))
    (def workdir (get manifest :local-source "."))
    (def fixed-syspath (os/realpath (dyn *syspath*)))
    (try
      (os/cd workdir)
      ([_] (print "cannot enter source directory " workdir " for bundle " bundle-name)))
    (defer (os/cd dir)
      (def new-env (make-env))
      (put new-env *module-cache* @{})
      (put new-env *module-loading* @{})
      (put new-env *module-make-env* (fn make-bundle-env [&] (make-env new-env)))
      (put new-env :workdir workdir)
      (put new-env :name bundle-name)
      (put new-env *syspath* fixed-syspath)
      (with-env new-env
        (put new-env :bundle-dir (bundle-dir bundle-name)) # get the syspath right
        (try
          (require (string "@syspath/bundle/" bundle-name))
          ([e f]
            (def pfx "could not find module @syspath/bundle/")
            (def msg (if (and (string? e)
                              (string/has-prefix? pfx e))
                       "bundle must contain bundle.janet or bundle/init.janet"
                       e))
            (propagate msg f))))))

  (defn- do-hook
    [module bundle-name hook & args]
    (def hookf (module/value module (symbol hook)))
    (unless hookf (break))
    (def dir (os/cwd))
    (os/cd (get module :workdir "."))
    (defer (os/cd dir)
      (print "running hook " hook " for bundle " bundle-name)
      (hookf ;args)))

  (defn bundle/list
    "Get a list of all installed bundles in lexical order."
    []
    (def d (bundle-dir))
    (if (os/stat d :mode)
      (sort (os/dir d))
      @[]))

  (defn- bundle-uninstall-unchecked
    [bundle-name]
    (def man (bundle/manifest bundle-name))
    (def all-hooks (get man :hooks @[]))
    (when (index-of :uninstall all-hooks)
      (def module (get-bundle-module bundle-name))
      (do-hook module bundle-name :uninstall man))
    (def files (get man :files []))
    (each file (reverse files)
      (print "remove " file)
      (case (os/stat file :mode)
        :file (os/rm file)
        :directory (os/rmdir file)))
    (rmrf (bundle-dir bundle-name))
    nil)

  (defn bundle/uninstall
    ``Remove a bundle from the current syspath. There is 1 hook called during
    uninstallation (uninstall). A user can register a hook by defining a
    function with the same name in the bundle script.``
    [bundle-name]
    (def breakage @{})
    (each b (bundle/list)
      (unless (= b bundle-name)
        (def m (bundle/manifest b))
        (def deps (get m :dependencies []))
        (each d deps
          (if (= d bundle-name) (put breakage b true)))))
    (when (next breakage)
      (def breakage-list (sorted (keys breakage)))
      (errorf "cannot uninstall %s, breaks dependent bundles %n" bundle-name breakage-list))
    (bundle-uninstall-unchecked bundle-name))

  (defn bundle/topolist
    "Get topological order of all bundles, such that each bundle is listed after its dependencies."
    []
    (def visited @{})
    (def cycle-detect @{})
    (def order @[])
    (def stack @[])
    (defn visit
      [b]
      (array/push stack b)
      (if (get visited b) (break))
      (if (get cycle-detect b) (errorf "cycle detected in bundle dependencies: %s" (string/join stack " -> ")))
      (put cycle-detect b true)
      (each d (get (bundle/manifest b) :dependencies []) (visit d))
      (put cycle-detect b nil)
      (put visited b true)
      (array/pop stack)
      (array/push order b))
    (each b (bundle/list) (visit b))
    order)

  (defn bundle/prune
    ``Remove all orphaned bundles from the current syspath. An orphaned bundle is a
    bundle that is marked for :auto-remove and is not depended on by any other bundle.``
    []
    (def topo (bundle/topolist))
    (def rtopo (reverse topo))
    # Check which auto-remove packages can be dropped
    # Iterate in (reverse) topological order, and if we see an auto-remove package and have not already seen
    # something that depends on it, then it is a root package and can be pruned.
    (def exempt @{})
    (def to-drop @[])
    (each b rtopo
      (def m (bundle/manifest b))
      (if (or (get exempt b) (not (get m :auto-remove)))
        (do
          (put exempt b true)
          (each d (get m :dependencies []) (put exempt d true)))
        (array/push to-drop b)))
    (print "pruning " (length to-drop) " bundles")
    (each b to-drop
      (print "uninstall " b))
    (each b to-drop
      (print "uninstalling " b)
      (bundle-uninstall-unchecked b)))

  (defn bundle/installed?
    "Check if a bundle is installed."
    [bundle-name]
    (not (not (os/stat (bundle-dir bundle-name) :mode))))

  (defn bundle/install
    ``Install a bundle from the local filesystem. The name of the bundle is
    the value mapped to :name in either `config` or the info file. There are
    5 hooks called during installation (postdeps, clean, build, install and
    check). A user can register a hook by defining a function with the same name
    in the bundle script.``
    [path &keys config]
    (def path (os/realpath path))
    (def s (sep))
    # Detect bundle name
    (def infofile-src1 (string path s "bundle" s "info.jdn"))
    (def infofile-src2 (string path s "info.jdn"))
    (def infofile-src (cond
                        (fexists infofile-src1) infofile-src1
                        (fexists infofile-src2) infofile-src2))
    (def info (-?> infofile-src slurp parse))
    (def bundle-name (get config :name (get info :name)))
    (assertf bundle-name
             "unable to infer bundle name for %v, use :name argument or add :name to info file" path)
    (assertf (not (string/check-set "\\/" bundle-name))
             "bundle name %v cannot contain path separators" bundle-name)
    (assert (next bundle-name) "cannot use empty bundle-name")
    (assertf (not (fexists (get-manifest-filename bundle-name)))
             "bundle %v is already installed" bundle-name)
    # Check bscript
    (def bscript-src1 (string path s "bundle" s "init.janet"))
    (def bscript-src2 (string path s "bundle.janet"))
    (def bscript-src (cond
                       (fexists bscript-src1) bscript-src1
                       (fexists bscript-src2) bscript-src2))
    # Setup installed paths
    (prime-bundle-paths)
    (os/mkdir (bundle-dir bundle-name))
    # Copy aliased infofile
    (when (fexists infofile-src2)
      (copyfile infofile-src2 (bundle-file bundle-name "info.jdn")))
    # Copy aliased bscript
    (when (fexists bscript-src2)
      (copyfile bscript-src2 (bundle-file bundle-name "init.janet")))
    # Copy some files into the new location unconditionally
    (def implicit-sources (string path s "bundle"))
    (when (= :directory (os/stat implicit-sources :mode))
      (copyrf implicit-sources (bundle-dir bundle-name)))
    (def man @{:name bundle-name :local-source path :files @[]})
    (merge-into man config)
    (sync-manifest man)
    (edefer (do (print "installation error, uninstalling") (bundle/uninstall bundle-name))
      (when info
        (def deps (seq [d :in (get info :dependencies @[])]
                    (string (if (dictionary? d) (get d :name) d))))
        (def missing (filter (complement bundle/installed?) deps))
        (when (next missing)
          (error (string "missing dependencies " (string/join missing ", "))))
        (put man :dependencies deps)
        (put man :info info))
      (def module (get-bundle-module bundle-name))
      (def clean (get config :clean))
      (def check (get config :check))
      (def all-hooks (seq [[k v] :pairs module :when (symbol? k) :unless (get v :private)] (keyword k)))
      (put man :hooks all-hooks)
      (do-hook module bundle-name :dependencies man) # deprecated, use :postdeps
      (do-hook module bundle-name :postdeps man)
      (when clean
        (do-hook module bundle-name :clean man))
      (do-hook module bundle-name :build man)
      (do-hook module bundle-name :install man)
      (if (empty? (get man :files)) (print "no files installed, is this a valid bundle?"))
      (sync-manifest man)
      (when check
        (do-hook module bundle-name :check man)))
    (print "installed " bundle-name)
    (when (or (get man :has-exe)
              # remove eventually
              (get man :has-bin-script))
      (def binpath (string (dyn *syspath*) s "bin"))
      (eprintf "executable files have been installed to %s" binpath))
    (when (get man :has-man)
      (def manpath (string (dyn *syspath*) s "man"))
      (eprintf "man pages have been installed to %s" manpath))
    bundle-name)

  (defn- bundle/pack
    ``Take an installed bundle and create a bundle source directory that can be
    used to reinstall the bundle on a compatible system. This is used to create
    backups for installed bundles without rebuilding, or make a prebuilt bundle
    for other systems.``
    [bundle-name dest-dir &opt is-backup]
    (var i 0)
    (def man (bundle/manifest bundle-name))
    (def files (get man :files @[]))
    (assertf (os/mkdir dest-dir) "could not create directory %v (or it already exists)" dest-dir)
    (def s (sep))
    (os/mkdir (string dest-dir s "bundle"))
    (def install-hook (string dest-dir s "bundle" s "init.janet"))
    (edefer (rmrf dest-dir) # don't leave garbage on failure
      (def install-source @[])
      (def syspath (os/realpath (dyn *syspath*)))
      (when is-backup (copyrf (bundle-dir bundle-name) (string dest-dir s "old-bundle")))
      (each file files
        (def {:mode mode :permissions perm} (os/stat file))
        (def relpath (string/triml (slice file (length syspath) -1) s))
        (case mode
          :directory (array/push install-source ~(bundle/add-directory manifest ,relpath ,perm))
          :file (do
                  (def filename (string/format "file_%06d" (++ i)))
                  (copyfile file (string dest-dir s filename))
                  (array/push install-source ~(bundle/add-file manifest ,filename ,relpath ,perm)))
          (errorf "unexpected file %v" file)))
      (def b @"(defn install [manifest]")
      (each form install-source (buffer/format b "\n  %j" form))
      (buffer/push b ")\n")
      (spit install-hook b))
    dest-dir)

  (defn bundle/replace
    ``Reinstall an existing bundle from a new directory. Similar to
    bundle/reinstall, but installs the replacement bundle from any directory.
    This is necessary to replace a package without breaking any dependencies.``
    [bundle-name path &keys new-config]
    (def manifest (bundle/manifest bundle-name))
    (def config (get manifest :config @{}))
    (def s (sep))
    (assertf (= :directory (os/stat path :mode)) "local source %v not available" path)
    (def backup-dir (string (dyn *syspath*) s bundle-name ".backup"))
    (rmrf backup-dir)
    (def backup-bundle-source (bundle/pack bundle-name backup-dir true))
    (edefer (do
              (bundle/install backup-bundle-source :name bundle-name)
              (copyrf (string backup-bundle-source s "old-bundle") (bundle-dir bundle-name))
              (rmrf backup-bundle-source))
      (bundle-uninstall-unchecked bundle-name)
      (bundle/install path :name bundle-name ;(kvs config) ;(kvs new-config)))
    (rmrf backup-bundle-source)
    bundle-name)

  (defn bundle/reinstall
    "Reinstall an existing bundle from the local source code."
    [bundle-name &keys new-config]
    (def manifest (bundle/manifest bundle-name))
    (def path (get manifest :local-source))
    (bundle/replace bundle-name path ;(kvs new-config))
    bundle-name)

  (defn bundle/add-directory
    "Add a directory during an install relative to `(dyn *syspath*)`."
    [manifest dest &opt chmod-mode]
    (def files (get-files manifest))
    (def s (sep))
    (def absdest (string (dyn *syspath*) s dest))
    (unless (os/mkdir absdest)
      (errorf "collision at %s, directory already exists" absdest))
    (def absdest (os/realpath absdest))
    (array/push files absdest)
    (when chmod-mode
      (os/chmod absdest chmod-mode))
    (print "add " absdest)
    absdest)

  (defn bundle/whois
    "Given a file path, figure out which bundle installed it."
    [path]
    (var ret nil)
    (def rpath (os/realpath path))
    (each bundle-name (bundle/list)
      (def files (get (bundle/manifest bundle-name) :files []))
      (def has-file (index-of rpath files))
      (when has-file
        (set ret bundle-name)
        (break)))
    ret)

  (defn bundle/add-file
    "Add a file during an install relative to `(dyn *syspath*)`."
    [manifest src &opt dest chmod-mode]
    (default dest src)
    (def files (get-files manifest))
    (def s (sep))
    (def absdest (string (dyn *syspath*) s dest))
    (when (os/stat absdest :mode)
      (errorf "collision at %s, file already exists" absdest))
    (copyfile src absdest)
    (def absdest (os/realpath absdest))
    (array/push files absdest)
    (when chmod-mode
      (os/chmod absdest chmod-mode))
    (print "add " absdest)
    absdest)

  (defn bundle/add
    ``Add a file or directory during an install relative to `(dyn *syspath*)`.
    Added files and directories will be recorded in the bundle manifest such
    that they are properly tracked and removed during an upgrade or uninstall.``
    [manifest src &opt dest chmod-mode]
    (default dest src)
    (def s (sep))
    (def mode (os/stat src :mode))
    (if-not mode (errorf "file %s does not exist" src))
    (case mode
      :directory
      (let [absdest (bundle/add-directory manifest dest chmod-mode)]
        (each d (os/dir src) (bundle/add manifest (string src s d) (string dest s d) chmod-mode))
        absdest)
      :file (bundle/add-file manifest src dest chmod-mode)
      (errorf "bad path %s - file is a %s" src mode)))

  (defn bundle/add-bin
    ``Add a file to the "bin" subdirectory of the current syspath. By default,
    files will be set to be executable.``
    [manifest src &opt filename chmod-mode]
    (def s (sep))
    (default filename (last (string/split s src)))
    (default chmod-mode 8r755)
    (os/mkdir (string (dyn *syspath*) s "bin"))
    (put manifest :has-exe true)
    (put manifest :has-bin-script true) # remove eventually
    (bundle/add-file manifest src (string "bin" s filename) chmod-mode))

  (defn bundle/add-manpage
    ``Add a file to the man subdirectory of the current syspath. Files are
    copied inside a directory `mansec`. By default, `mansec` is "man1".``
    [manifest src &opt mansec]
    (def s (sep))
    (default mansec "man1")
    (def filename (last (string/split s src)))
    (os/mkdir (string (dyn *syspath*) s "man"))
    (os/mkdir (string (dyn *syspath*) s "man" s mansec))
    (put manifest :has-man true)
    (bundle/add-file manifest src (string "man" s mansec s filename)))

  (defn bundle/update-all
    "Reinstall all bundles."
    [&keys configs]
    (each bundle (bundle/topolist)
      (bundle/reinstall bundle ;(kvs configs)))))

###
###
### CLI Tool Main
###
###

# conditional compilation for reduced os
(def- getenv-raw (if-let [entry (in root-env 'os/getenv)] (entry :value) (fn [&])))
(defn- getenv-alias [env-var &opt dflt]
  (def x (getenv-raw env-var dflt))
  (if (= x "") nil x)) # empty string is coerced to nil

(defn- run-main
  [env subargs]
  (when-let [main (module/value env 'main true)]
    (def guard (if (get env :debug) :ydt :y))
    (defn wrap-main [&]
      (main ;subargs))
    (def f (fiber/new wrap-main guard env))
    (var res nil)
    (while (fiber/can-resume? f)
      (set res (resume f res))
      (when (not= :dead (fiber/status f))
        ((debugger-on-status env) f res)))
    (break true))
  false)

(defdyn *args*
  "Dynamic bindings that will contain command line arguments at program start.")

(defdyn *executable*
  ``Name of the interpreter executable used to execute this program. Corresponds to `argv[0]` in the call to
    `int main(int argc, char **argv);`.``)

(defdyn *profilepath*
  "Path to profile file loaded when starting up the repl.")

(compwhen (not (dyn 'os/isatty))
  (defmacro os/isatty [&] true))

(def- long-to-short
  "map long options to short options"
  {"-help" "h"
   "-version" "v"
   "-stdin" "s"
   "-eval" "e"
   "-expression" "E"
   "-debug" "d"
   "-repl" "r"
   "-noprofile" "R"
   "-persistent" "p"
   "-quiet" "q"
   "-flycheck" "k"
   "-syspath" "m"
   "-compile" "c"
   "-image" "i"
   "-nocolor" "n"
   "-color" "N"
   "-library" "l"
   "-tool" "t"
   "-install" "b"
   "-reinstall" "B"
   "-uninstall" "u"
   "-update-all" "U"
   "-list" "L"
   "-prune" "P"
   "-lint-warn" "w"
   "-lint-error" "x"})

(defn- apply-color
  [colorize]
  (setdyn *pretty-format* (if colorize "%.20Q" "%.20q"))
  (setdyn *err-color* (if colorize true))
  (setdyn *doc-color* (if colorize true)))

(defn- getstdin [prompt buf _]
  (file/write stdout prompt)
  (file/flush stdout)
  (file/read stdin :line buf))

###
###
### AOT driver (bender --aot): the compiler driver lives in the binary.
### tools/janet-aot.sh is a thin shim over this. Mirrors the shell
### grammar 1:1: app.janet [-o app] [-c] [-S] [-E args...] [--native]
### [-Oz] [--release] [--upx] [--no-auto-pgo] [--externs F]
### [--include F]... [-x F] [--ldflags S] [--pgo S] [--pgo-stdin F]
### [--pgo-auto].
### Tools (callgraph/mkimage) run in-process via dofile;
### only cc and profile/parity workloads spawn subprocesses, like any
### cc-style driver.
###

(defn- aot-die [msg &opt code]
  (eprint "bender --aot: " msg)
  (os/exit (or code 2))
  nil)

(defn- aot-words [s]
  (filter (fn [w] (not (empty? w))) (string/split " " (or s ""))))

(defn- aot-exe-root
  `Best-effort repo/install root from the running executable path,
  always absolute (so -I flags and tool paths survive cwd changes).`
  []
  (def exe0 (dyn *executable* ""))
  (def exe (if (or (string/has-prefix? "/" exe0) (nil? (string/find "/" exe0)))
             exe0 # absolute, or bare name (no relative info)
             (string (os/cwd) "/" exe0)))
  (def parts (string/split "/" exe))
  (if (< (length parts) 2)
    nil # bare name from PATH: no relative info
    (do (def dir (string/join (tuple/slice parts 0 (- (length parts) 1)) "/"))
      (def base (last (string/split "/" dir)))
      (if (or (= base "build") (= base "bin"))
        (let [pparts (string/split "/" dir)
              parent (string/join (tuple/slice pparts 0 (- (length pparts) 1)) "/")]
          (if (empty? parent) "." parent))
        (if (empty? dir) "." dir)))))

(defn- aot-tools-dir
  `Locate callgraph.janet + mkimage.janet.`
  []
  (def cands @[])
  (when-let [e (os/getenv "JANET_TOOLS")] (array/push cands e))
  (when-let [r (aot-exe-root)] (array/push cands (string r "/tools")))
  (array/push cands "/usr/local/lib/janet/tools")
  (array/push cands "/usr/lib/janet/tools")
  (var found nil)
  (each d cands
    (when (and (nil? found)
               (= :file (os/stat (string d "/callgraph.janet") :mode))
               (= :file (os/stat (string d "/mkimage.janet") :mode)))
      (set found d)))
  found)

(defn- aot-run-tool [tooldir name toolargs]
  (def toolpath (string tooldir "/" name))
  (def env (make-env))
  (put env *args* (tuple toolpath ;toolargs))
  (dofile toolpath :exit true :env env))

# Auto-PGO cache: standard location shared with AOT binaries (which
# compute the same key/dir in C, see mkimage.janet). Profiles land
# here on binary first-runs and explicit --pgo builds; plain
# --native builds pick them up automatically (see aot-compile).
(defn- aot-cache-dir []
  (def xdg (os/getenv "XDG_CACHE_HOME"))
  (if (and xdg (not (empty? xdg)))
    (string xdg "/janet/pgo")
    (do (def home (os/getenv "HOME"))
      (if (and home (not (empty? home)))
        (string home "/.cache/janet/pgo")
        nil))))

# Interpreter collection is diagnostic unless a build later records an
# explicit replayable workload. Keep it in a separate namespace from the
# gateable AOT cache (which is keyed by output basename).
(defn- development-profile-dir []
  (when-let [cache (aot-cache-dir)]
    (string cache "/interpreter")))

(defn- development-mkdir-p [dir]
  (try (do (var cur "")
           (def abs (string/has-prefix? "/" dir))
           (each part (string/split "/" dir)
             (when (not (empty? part))
               (set cur (if (empty? cur)
                          (if abs (string "/" part) part)
                          (string cur "/" part)))
               (unless (os/stat cur) (os/mkdir cur)))))
    ([_] nil)))

(defn- development-profile-path [source]
  (try
    (do (def canonical (os/realpath source))
      (def token (string (hash canonical)))
      (def dir (string (development-profile-dir) "/source-" token))
      (development-mkdir-p dir)
      (var attempt 0)
      (var path nil)
      (while (and (< attempt 64) (nil? path))
        (def candidate (string dir "/run-" (os/getpid) "-" attempt ".jdn"))
        (unless (or (os/stat candidate) (os/stat (string candidate ".pending"))
                    (os/stat (string candidate ".meta")))
          (set path candidate))
        (++ attempt))
      path)
    ([_] nil)))

(defn- development-profile-accumulate [source completed]
  # Recompute from immutable completed runs under one directory. Replaying
  # after a crash cannot double-count: no run is deleted on publication.
  # Identity is exact source path plus bytes; unknown/foreign runs are ignored.
  (try
    (do (def parts (string/split "/" completed))
      (def dir (string/slice completed 0 (- (length completed) (length (last parts)) 1)))
      (def identity (try @[[ (os/realpath source) (string (slurp source)) ]] ([_] nil)))
      (unless identity (break nil))
      (def lock (string dir "/aggregate.lock"))
      (unless (os/mkdir lock) (break nil))
      (try
        (do (def paths @[])
          (each name (sort (os/dir dir))
            (when (and (string/has-prefix? "run-" name)
                       (string/has-suffix? ".jdn" name))
              (def path (string dir "/" name))
              (when (and (> (or (os/stat path :size) 0) 0)
                         (deep= (try (parse (slurp (string path ".meta"))) ([_] nil)) identity))
                (array/push paths path))))
          (when (not (empty? paths))
            (def candidate (string dir "/cumulative-" (os/getpid) ".pending"))
            (def output (string dir "/cumulative.jdn"))
            (def exe (dyn *executable* "bender"))
            (def tooldir (aot-tools-dir))
            (def argv [exe (string tooldir "/profile-merge.janet")
                       "--accumulate" "--out" candidate
                       ;(map (fn [path] (string "run=" path)) paths)])
            (def env (merge @{} (os/environ) {"JANET_NO_PROFILE" "1"}))
            (when (and tooldir
                       (= 0 (os/execute argv (if (string/find "/" exe) :e :ep) env))
                       (> (or (os/stat candidate :size) 0) 0))
              # Metadata is written first: a crash never makes a new-source
              # aggregate appear to have a valid old-source identity.
              (spit (string output ".meta") (string/format "%j" identity))
              (os/rename candidate output))))
        ([_] nil))
      (try (os/rmdir lock) ([_] nil)))
    ([_] nil)))

(defn- aot-cache-key [out]
  # basename sanitized exactly like the binary's janet_aot_key:
  # [A-Za-z0-9._-] kept, rest '_', 63 chars max, never empty.
  (def parts (string/split "/" out))
  (def base (last parts))
  (def clean
    (string/join
      (map (fn [b] (if (or (and (>= b 65) (<= b 90))
                              (and (>= b 97) (<= b 122))
                              (and (>= b 48) (<= b 57))
                              (= b 95) (= b 45) (= b 46))
                       (string/from-bytes b) "_"))
           (string/bytes base)) ""))
  (def cut (if (> (length clean) 63) (string/slice clean 0 63) clean))
  (if (empty? cut) "janet-app" cut))

# Bind gateable evidence to the exact source bytes, not filesystem mtime:
# two edits in one timestamp tick must never reuse old observations.
(defn- aot-source-identity [paths]
  (try (do (def evidence (map (fn [path] [(os/realpath path) (string (slurp path))]) paths))
           # `map` is eager; a missing or unreadable source rejects reuse.
           evidence)
    ([_] nil)))

(defn- aot-cache-fresh? [prof paths]
  # profile newer than every source (and existing at all)
  (def pst (os/stat prof))
  (when (nil? pst) (break false))
  (def pt (get pst :modified 0))
  (var ok true)
  (each p paths
    (def s (os/stat p))
    # missing sources are someone else's error; ignore here
    (when (and s (> (get s :modified 0) pt)) (set ok false)))
  ok)

(defn- aot-mkdir-p [dir]
  # best-effort recursive mkdir; never fails the build
  (try
    (do (var cur "")
      (def abs (string/has-prefix? "/" dir))
      (each part (string/split "/" dir)
        (when (not (empty? part))
          (set cur (if (empty? cur)
                     (if abs (string "/" part) part)
                     (string cur "/" part)))
          (unless (os/stat cur) (os/mkdir cur)))))
    ([_] nil)))

(defn- aot-cache-sidecars [cdir key]
  (if (os/stat cdir)
    (sort (filter (fn [name]
                    (and (string/has-prefix? (string key ".jdn.run-") name)
                         (string/has-suffix? ".jdn" name)
                         (> (or (os/stat (string cdir "/" name) :size) 0) 0)))
                  (os/dir cdir)))
    @[]))

# --pgo-auto: every auto-PGO profile carries a companion <profile>.workload
# record written by the running binary (see src/core/vm.c). Validate one.
(defn- aot-auto-workload [profile]
  (def rec (try (parse (slurp (string profile ".workload"))) ([_] nil)))
  (unless (and (dictionary? rec)
               (= 1 (get rec :version))
               (string? (get rec :args))
               (indexed? (get rec :argv))
               (boolean? (get rec :has-stdin))
               (boolean? (get rec :replayable))
               (if (get rec :has-stdin)
                 (string? (get rec :stdin-bytes))
                 (nil? (get rec :stdin-bytes))))
    (break nil))
  rec)

# Group the base auto profile and its sidecars by workload identity, so each
# workload is gated on its own evidence instead of one widened union. Returns
# [groups rejected]; nothing is promoted silently and nothing is dropped
# silently (every refusal carries a reason the caller prints).
(defn- aot-auto-groups [cdir key sources]
  (def groups @[])
  (def rejected @[])
  (def candidates [(string cdir "/" key ".jdn")
                   ;(map (fn [name] (string cdir "/" name))
                         (aot-cache-sidecars cdir key))])
  (each path candidates
    (cond
      (not= :file (os/stat path :mode)) nil # base profile may not exist yet
      (nil? (os/stat (string path ".workload")))
      (array/push rejected [path "no workload record (binary predates provenance)"])
      (not (aot-cache-fresh? path sources))
      (array/push rejected [path "stale: sources are newer than this profile"])
      (do
        (def rec (aot-auto-workload path))
        (cond
          (nil? rec)
          (array/push rejected [path "malformed workload record"])
          (not (get rec :replayable))
          (array/push rejected [path (string "not replayable: "
                                             (or (get rec :reason) :unknown))])
          (do
            (def argv (map string (get rec :argv)))
            (def hit (find (fn [g] (and (deep= (get g :argv) argv)
                                        (= (get g :has-stdin) (get rec :has-stdin))
                                        (= (get g :stdin-bytes) (get rec :stdin-bytes))))
                           groups))
            (if hit
              (array/push (get hit :profiles) path)
              (array/push groups @{:args (get rec :args) :argv argv
                                   :has-stdin (get rec :has-stdin)
                                   :stdin-bytes (get rec :stdin-bytes)
                                   :profiles @[path]})))))))
  [groups rejected])

# Evidence that failed its own parity replay is moved aside, never reused and
# never deleted (the failing observation stays available for inspection).
(defn- aot-auto-quarantine [paths]
  (each path paths
    (def dest (string path ".quarantine-" (os/getpid)))
    (try (os/rename path dest) ([_] nil))
    (when (os/stat (string path ".workload"))
      (try (os/rename (string path ".workload") (string dest ".workload")) ([_] nil)))
    (eprint "bender --aot: quarantined " path " -> " dest)))

# An exclusive directory serializes cache profile/workload reads and writes
# across build processes. Contention fails closed rather than reading a
# partially published profile/metadata pair.
(defn- aot-cache-transaction [cdir key action]
  (def lock (string cdir "/" key ".lock"))
  (unless (os/mkdir lock)
    (error (string "PGO cache busy: " lock)))
  (def result (try (action)
                ([e] (try (os/rmdir lock) ([_] nil)) (error e))))
  (os/rmdir lock)
  result)

(defn- aot-merge-profiles [paths dest]
  (def exe (dyn *executable* "bender"))
  (unless (= 0 (os/execute [exe (string (aot-tools-dir) "/profile-merge.janet")
                             "--accumulate" "--out" dest
                             ;(map (fn [path] (string "home=" path)) paths)]
                            (if (string/find "/" exe) :e :ep)))
    (error "profile accumulation failed")))

(defn- aot-report-divergence [paths]
  (when (> (length paths) 1)
    (def exe (dyn *executable* "bender"))
    (unless (= 0 (os/execute [exe (string (aot-tools-dir) "/profile-divergence.janet") ;paths]
                           (if (string/find "/" exe) :e :ep)))
      (error "profile divergence report failed"))))

# v3 stores a manifest and independently replayable raw observations. v2 is
# read as a single workload, with its oracle regenerated at replay time.
#
# allow-legacy admits a v3 record without an oracle. That shape is produced
# when a v2 record is promoted: the gate regenerates the oracle but older
# manifests persisted the record before the oracle was attached. Rejecting
# the whole manifest would strand every cache written by that version. The
# collection path therefore accepts it and repairs it on the next store;
# the automatic path stays strict, because it replays oracles and must not
# treat an unverifiable observation as evidence.
(defn- aot-cache-load [cdir key sources &opt allow-legacy]
  (def base (string cdir "/" key))
  (def meta (try (parse (slurp (string base ".meta"))) ([_] nil)))
  (def identity (aot-source-identity sources))
  (unless (and identity (dictionary? meta) (deep= (get meta :sources) identity))
    (break nil))
  (def records
    (if (= 3 (get meta :version))
      (get meta :workloads)
      (if (and (= 2 (get meta :version))
               (os/stat (string base ".workload"))
               (os/stat (string base ".stdin"))
               (= (get meta :args) (string (slurp (string base ".workload"))))
               (= (get meta :has-stdin) (not (empty? (string (slurp (string base ".stdin"))))))
               (deep= (get meta :stdin-bytes)
                      (if (os/stat (string base ".input"))
                        (string (slurp (string base ".input"))) nil)))
        [{:args (get meta :args) :stdin-bytes (get meta :stdin-bytes)
          :has-stdin (get meta :has-stdin) :profile (string base ".jdn")
          :oracle nil}]
        nil)))
  (unless (and (indexed? records) (not (empty? records))) (break nil))
  (when (and (= 3 (get meta :version))
             (not (and (string? (get meta :aggregate))
                       (= :file (os/stat (get meta :aggregate) :mode)))))
    (break nil))
  (var valid true)
  (each rec records
    (unless (and (dictionary? rec) (string? (get rec :args))
                 (boolean? (get rec :has-stdin))
                 (if (get rec :has-stdin) (string? (get rec :stdin-bytes))
                     (nil? (get rec :stdin-bytes)))
                 (string? (get rec :profile))
                 (= :file (os/stat (get rec :profile) :mode))
                 (if (= 3 (get meta :version))
                   (or (and allow-legacy (nil? (get rec :oracle)))
                        (and (string? (get rec :oracle))
                        (= :file (os/stat (get rec :oracle) :mode))))
                   (nil? (get rec :oracle))))
      (set valid false)))
  (unless valid (break nil))
  records)

(defn- aot-cache-store [out ndir workload stdin sources captured-input prior-oracles previous-meta]
  # Publish immutable generation files before atomically switching the
  # manifest. Never modify a file referenced by the previous manifest.
  (try
    (do (def cdir (aot-cache-dir))
      (when cdir
        (aot-mkdir-p cdir)
        (def key (aot-cache-key out))
        (aot-cache-transaction cdir key (fn []
        (def meta (string cdir "/" key ".meta"))
        (unless (= previous-meta (if (os/stat meta) (string (slurp meta)) nil))
          (error "PGO cache changed during collection; retry training"))
        (def identity (aot-source-identity sources))
        (unless identity (error "missing PGO source identity"))
        (def prior (or (aot-cache-load cdir key sources true) @[]))
        (def records @[])
        (each r prior (array/push records r))
        (def pos (find-index (fn [r] (and (= workload (get r :args))
                                          (= (not (empty? stdin)) (get r :has-stdin))
                                          (= captured-input (get r :stdin-bytes)))) records))
        # An exclusive directory reserves a unique generation even if a
        # previous writer crashed and left unpublished files behind.
        (var serial 0)
        (var generation nil)
        (while (and (nil? generation) (< serial 1024))
          (def trial (string cdir "/" key ".rev-" (os/getpid) "-" serial))
          (if (os/mkdir trial) (set generation trial) (++ serial)))
        (unless generation (error "could not reserve PGO cache generation"))
        # A v2 record promoted into v3 has no stored oracle. The gate just
        # regenerated one; attach it to the promoted record so the manifest
        # stays replay-verifiable (a v3 record without an oracle is refused
        # by the strict load used when applying the cache).
        (for i 0 (length prior)
          (def r (records i))
          (when (nil? (get r :oracle))
            (def regenerated (get prior-oracles i))
            (unless (and regenerated (= :file (os/stat regenerated :mode)))
              (error "legacy PGO record has no regenerated oracle"))
            (def dest (string generation "/legacy-oracle-" i ".out"))
            (spit dest (slurp regenerated))
            # Manifest records parse as structs; rebuild as a table to
            # attach the oracle without mutating the parsed value.
            (def promoted @{})
            (eachp [k v] r (put promoted k v))
            (put promoted :oracle dest)
            (put records i promoted)))
        (def raw (string generation "/profile.jdn"))
        (def oracle (string generation "/oracle.out"))
        (if pos
          (aot-merge-profiles [(get (records pos) :profile) (string ndir "/profile.raw.jdn")] raw)
          (spit raw (slurp (string ndir "/profile.raw.jdn"))))
        (spit oracle (slurp (string ndir "/expected.out")))
        (def rec {:args workload :has-stdin (not (empty? stdin))
                  :stdin-bytes captured-input :profile raw :oracle oracle})
        (if pos (put records pos rec) (array/push records rec))
        (def aggregate (string generation "/aggregate.jdn"))
        (aot-merge-profiles (map (fn [r] (get r :profile)) records) aggregate)
        (def metatmp (string meta ".tmp-" (os/getpid)))
        (spit metatmp (string/format "%j" {:version 3 :sources identity
                                           :aggregate aggregate :workloads records}))
        (when (os/getenv "JANET_PGO_FAIL_BEFORE_MANIFEST")
          (error "injected pre-manifest PGO cache failure"))
        (os/rename metatmp meta)
        (eprint "bender --aot: cached PGO profiles for " (length records) " workloads")
        true))))
    ([e] (eprint "bender --aot: PGO cache publication failed: " e) false)))

(defn- aot-abs-exe []
  (def exe (dyn *executable* "bender"))
  (if (or (string/has-prefix? "/" exe) (nil? (string/find "/" exe)))
    exe # absolute, or bare name (PATH search via :p at spawn)
    (string (os/cwd) "/" exe)))

(defn- aot-run-cc [parts]
  # :p so a bare "cc"/"$CC" resolves via PATH (absolute paths pass through).
  (def code (os/execute parts :p))
  (when (not= code 0)
    (eprint "bender --aot: cc failed with exit " code)
    (os/exit 1))
  code)

(defn- aot-clean [files dirs]
  (each f files (try (os/rm f) ([_] nil)))
  (each d dirs (try (os/rmdir d) ([_] nil))))

(defn- aot-next [aotargs i what]
  (def v (in aotargs (+ i 1)))
  (when (nil? v) (aot-die (string what " needs a value")))
  v)

(defn- aot-compile [aotargs]
  (var src "")
  (var out "")
  (var includes @[])
  (var externs nil)
  (var extrac @[])
  (var ldflags "")
  (var native false)
  (var size-opt false)
  (var release false)
  (var pack-upx false)
  (var only-c false)
  (var print-c false)
  (var run-mode false)
  (var pgo false)
  (var pgo-args "")
  (var pgo-stdin "")
  (var pgo-auto false)
  (var no-auto-pgo false)
  # B7.2 Part B, Piece 1c: opt-in whole-program dead-code elimination.
  # Off by default so no existing build invocation changes behavior
  # (design-note Piece 1, point 4: "never silently on"). Only meaningful
  # with --native, since the dce-reachable gate runs inside the
  # callgraph.janet invocation that only the native path makes.
  (var dce false)
  (var appargs @[])
  (var i 0)
  (def n (length aotargs))
  (while (< i n)
    (def a (in aotargs i))
    (cond
      (= a "-o") (do (set out (aot-next aotargs i "-o")) (+= i 2))
      (= a "-c") (do (set only-c true) (++ i))
      (= a "-S") (do (set print-c true) (++ i))
      (= a "-E") (do (set run-mode true) (++ i)
                     (while (< i n) (array/push appargs (in aotargs i)) (++ i)))
      (= a "--native") (do (set native true) (++ i))
      (= a "-Oz") (do (set size-opt true) (++ i))
      (= a "--release") (do (set release true) (++ i))
      (= a "--upx") (do (set pack-upx true) (++ i))
      (= a "--externs") (do (set externs (aot-next aotargs i "--externs")) (+= i 2))
      (= a "--include") (do (array/push includes (aot-next aotargs i "--include")) (+= i 2))
      (= a "--pgo") (do (set pgo true) (set pgo-args (aot-next aotargs i "--pgo")) (+= i 2))
      (= a "--pgo-stdin") (do (set pgo-stdin (aot-next aotargs i "--pgo-stdin")) (+= i 2))
      (= a "--pgo-auto") (do (set pgo-auto true) (++ i))
      (= a "--no-auto-pgo") (do (set no-auto-pgo true) (++ i))
      (= a "--dce") (do (set dce true) (++ i))
      (= a "-x") (do (array/push extrac (aot-next aotargs i "-x")) (+= i 2))
      (= a "--ldflags") (do (set ldflags (aot-next aotargs i "--ldflags")) (+= i 2))
      (string/has-prefix? "-" a) (aot-die (string "unknown flag " a))
      (do (when (not (empty? src)) (aot-die "one input only"))
          (set src a) (++ i))))
  (when (empty? src)
    (aot-die "usage: bender --aot app.janet [-o app] [-c] [-S] [-E args...] [--native] [-Oz] [--release] [--upx] [--dce] [--externs FILE] [--include FILE] [-x FILE] [--ldflags STR] [--pgo ARGS] [--pgo-stdin FILE] [--pgo-auto] [--no-auto-pgo]"))
  # --dce only has an effect on the native path: the dce-reachable gate
  # lives in callgraph.janet, which the plain-image path never invokes.
  # Refuse loudly rather than silently ignoring the flag.
  (when (and dce (not native))
    (aot-die "--dce requires --native (the dce-reachable gate runs in the native callgraph pass)"))
  (when (and size-opt (or only-c print-c run-mode))
    (aot-die "-Oz needs a real binary build (no -c/-S/-E)"))
  (when pack-upx
    (when (or only-c print-c run-mode)
      (aot-die "--upx requires a real binary build (no -c/-S/-E)"))
    # UPX supports selected ELF targets, not Mach-O or arbitrary formats.
    (unless (and (= (os/which) :linux) (index-of (os/arch) [:x86_64 :x86 :aarch64]))
      (aot-die "--upx requires a supported Linux ELF target"))
    (when (not= 0 (try (os/execute ["upx" "--version"] :p) ([_] -1)))
      (aot-die "--upx requested but UPX is unavailable")))
  (when (and pack-upx (not native))
    (aot-die "--upx requires --native and a replayable PGO workload"))
  (when release
    (unless native (aot-die "--release requires --native"))
    (when (or pgo pgo-auto no-auto-pgo only-c print-c run-mode)
      (aot-die "--release requires existing verified PGO evidence; incompatible with --pgo/--pgo-auto/--no-auto-pgo/-c/-S/-E")))
  (when pgo-auto
    (unless native (aot-die "--pgo-auto needs --native (profiling seeds kernel shaping)"))
    (when (or only-c print-c run-mode)
      (aot-die "--pgo-auto needs a real binary build (no -c/-S/-E)"))
    (when (or pgo no-auto-pgo release)
      (aot-die "--pgo-auto merges cached auto-PGO runs; incompatible with --pgo/--no-auto-pgo/--release")))
  (when pgo
    (unless native (aot-die "--pgo needs --native (profiling seeds kernel shaping)"))
    (when (or only-c print-c run-mode)
      (aot-die "--pgo needs a real binary build (no -c/-S/-E)"))
    (when (and (not (empty? pgo-stdin)) (nil? (os/stat pgo-stdin)))
      (aot-die (string "--pgo-stdin file not found: " pgo-stdin))))
  (when (empty? out)
    (def parts (string/split "/" src))
    (def base (last parts))
    (def stem (if (string/has-suffix? ".janet" base)
                (string/slice base 0 (- (length base) 6))
                base))
    (def dirparts (tuple/slice parts 0 (- (length parts) 1)))
    (set out (if (empty? dirparts) stem
               (string (string/join dirparts "/") "/" stem))))
  # -E builds into a staging dir that is removed after the run.
  (var stage nil)
  (when run-mode
    (set stage (string out ".aotrun-" (os/getpid)))
    (os/mkdir stage)
    (set out (string stage "/app")))
  (def tooldir (or (aot-tools-dir)
                   (aot-die "AOT tools not found (set JANET_TOOLS to the tools/ dir)")))
  (def root (string/slice tooldir 0 (- (length tooldir) 6))) # strip "/tools"
  (def cc (os/getenv "CC" "cc"))
  (def inc-args includes) # callgraph takes extra files bare (no flag)
  (def cfile (string out ".c"))
  (def optflag (if size-opt "-Oz" "-O3"))
  (defn package-upx [candidate workload stdin-path]
    (when pack-upx
      (unless workload
        (aot-die "--upx requires --pgo or a replayable cached workload for packed parity" 1))
      # The unpacked candidate remains intact until the packed copy has
      # passed UPX's integrity check and the identical replay workload.
      (def packed (string candidate ".upx-tmp"))
      (try (os/rm packed) ([_] nil))
      (when (not= 0 (os/execute ["upx" "--best" "-o" packed candidate] :p))
        (aot-die "UPX compression failed; keeping unpacked candidate" 1))
      (when (or (not= :file (os/stat packed :mode))
                (<= (or (os/stat packed :size) 0) 0)
                (not= 0 (os/execute ["upx" "-t" packed] :p)))
        (aot-die "UPX output failed integrity validation" 1))
      (def rawout (string candidate ".unpacked.stdout"))
      (def packedout (string candidate ".packed.stdout"))
      (defn run-one [exe dest]
        (def fout (file/open dest :w))
        (def renv (merge @{} (os/environ)))
        (put renv "JANET_NO_PROFILE" "1")
        (put renv :out fout)
        (var fin nil)
        (when (and stdin-path (not (empty? stdin-path)))
          (unless (os/stat stdin-path) (aot-die "UPX parity stdin is missing" 1))
          (set fin (file/open stdin-path :r))
          (put renv :in fin))
        (def code (os/execute [exe ;(aot-words workload)] :e renv))
        (file/close fout)
        (when fin (file/close fin))
        code)
      (unless (and (= 0 (run-one candidate rawout))
                   (= 0 (run-one packed packedout))
                   (= (string (slurp rawout)) (string (slurp packedout))))
        (aot-die "UPX packed binary parity failed; keeping unpacked candidate" 1))
      (os/rename packed candidate)
      (eprint "bender --aot: UPX verified " candidate " " (os/stat candidate :size) " bytes")))
  (defn size-finish [path]
    (when size-opt
      # Strip the staged binary before installing it. A failure leaves
      # the existing output intact rather than shipping an unstripped file.
      (unless (= 0 (os/execute ["strip" (if (= (os/which) :macos) "-x" "--strip-debug") path] :p))
        (aot-die (string "could not strip size build " path) 1))
      (eprint "bender --aot: -Oz binary " path " " (os/stat path :size) " bytes")))
  (def release-flags (if release ["-DJANET_NO_PGO" "-DJANET_NATIVE_TELEMETRY=0"] []))
  (def sizelink (if size-opt (case (os/which)
                                    :macos ["-Wl,-dead_strip"]
                                    :linux ["-Wl,--gc-sections"]
                                    (aot-die "-Oz unsupported on this target")) []))
  (when size-opt
    (unless (= 0 (os/execute [cc optflag "-ffunction-sections" "-fdata-sections"
                                     "-x" "c" "-c" "-o" "/dev/null" "/dev/null"] :p))
      (aot-die "C compiler does not support -Oz section flags")))
  (if (not native)
    # plain image build (also serves -E below)
    (do (aot-run-tool tooldir "mkimage.janet" [src cfile])
      (when print-c (file/write stdout (slurp cfile)) (os/rm cfile))
      (unless print-c
        (when only-c (print "wrote " cfile))
        (unless only-c
          # -O3: kernels are numeric loops, optimizer pays off.
          # -fwrapv: :wrap int policy needs defined two's-complement
          # wrap (C signed overflow is otherwise UB).
          # -fno-math-errno/-fno-trapping-math: safe fast-math subset,
          # lets LLVM hoist/simplify double code without reassociation
          # (oracle-identical, unlike -ffast-math).
          (def target (if size-opt (string out ".size-tmp") out))
          (aot-run-cc [cc optflag ;(if size-opt ["-ffunction-sections" "-fdata-sections"] []) "-fwrapv"
                       "-fno-math-errno" "-fno-trapping-math"
                       "-I" (string root "/build")
                       "-I" (string root "/src/include")
                       cfile (string root "/build/libjanet.a")
                       ;sizelink "-lm" "-lpthread" "-o" target])
          (size-finish target)
          (when size-opt (os/rename target out))
          (unless run-mode (print "built " out)))))
    # native (hybrid) build
    (do (def ndir (string out "-native"))
      (var profile-args @[])
      (var expected nil)
      # gate inputs: explicit --pgo fills them by collecting now;
      # the auto path fills them from the cache (see below).
      (var gate false)
      (var gate-workload "")
      (var gate-stdin "")
      (var gate-records @[])
      (var prior-cache-meta nil)
      (var prior-oracles @[])
      (var captured-stdin nil)
      (when pgo
        # phase 0 (collect): interpreter under the type collector;
        # stdout doubles as the parity oracle. Runs in the caller's
        # cwd, like a manual run.
        (unless (os/stat ndir) (os/mkdir ndir))
        (def prof (string ndir "/profile.jdn"))
        (set expected (string ndir "/expected.out"))
        (eprint "bender --aot: pgo collect: " src " " pgo-args)
        (def exe (aot-abs-exe))
        (def penv (merge @{} (os/environ)
                         {"JANET_PROFILE" "1" "JANET_PROFILE_OUT" prof}))
        (def pargs (aot-words pgo-args))
        (var infile nil)
        (when (not (empty? pgo-stdin))
          (set captured-stdin (string (slurp pgo-stdin)))
          (def capture-path (string ndir "/stdin.capture"))
          (spit capture-path captured-stdin)
          (set infile (file/open capture-path :r))
          (put penv :in infile))
        (def pout (file/open expected :w))
        (put penv :out pout)
        (def expargs [exe src ;pargs])
        (def pcode (os/execute expargs (if (string/find "/" exe) :e :ep) penv))
        (file/close pout)
        (when infile (file/close infile))
        (when (not= pcode 0)
          (aot-die (string "profile run failed with exit " pcode) 1))
        (when (nil? (os/stat prof))
          (aot-die "collector produced no profile (is JANET_PROFILE wired?)" 1))
        (spit (string ndir "/profile.raw.jdn") (slurp prof))
        # Shape with compatible prior runs, and verify each old oracle as
        # well as the new one before either publishing or installing.
        (def cdir (aot-cache-dir))
        (when (and cdir (os/stat cdir))
          (def key (aot-cache-key out))
          (def meta-path (string cdir "/" key ".meta"))
          # Snapshot metadata under the same lock as cache publication.
          # A busy cache is not evidence that can authorize a new build.
          (var prior nil)
          (try
            (aot-cache-transaction cdir key (fn []
              (when (os/stat meta-path)
                (set prior-cache-meta (string (slurp meta-path))))
              (set prior (aot-cache-load cdir key [src ;includes ;extrac] true))))
            ([e] (aot-die (string "PGO cache busy or unreadable: " e) 1)))
          (def recorded (try (parse prior-cache-meta) ([_] nil)))
          (when (and (= 3 (get recorded :version))
                     (deep= (get recorded :sources)
                            (aot-source-identity [src ;includes ;extrac]))
                     (nil? prior))
            (aot-die "corrupt compatible v3 PGO cache; refusing collection" 1))
          (when prior
            (each r prior
              (def ordinal (length gate-records))
              (def input-path (string ndir "/prior-stdin-" ordinal))
              (def replay-stdin (if (get r :has-stdin) input-path ""))
              (when (get r :has-stdin) (spit input-path (get r :stdin-bytes)))
              (var oracle (get r :oracle))
              # v2 stored no oracle; regenerate it from its exact recorded
              # argv/stdin under the already-verified source identity.
              (when (nil? oracle)
                (set oracle (string ndir "/legacy-oracle-" ordinal ".out"))
                (def oenv (merge @{} (os/environ) {"JANET_NO_PROFILE" "1"}))
                (def oout (file/open oracle :w))
                (var oin nil)
                (when (get r :has-stdin)
                  (set oin (file/open replay-stdin :r))
                  (put oenv :in oin))
                (put oenv :out oout)
                (def oexe (aot-abs-exe))
                (def ocode (os/execute [oexe src ;(aot-words (get r :args))]
                                       (if (string/find "/" oexe) :e :ep) oenv))
                (file/close oout)
                (when oin (file/close oin))
                (unless (= 0 ocode)
                  (aot-die "legacy PGO oracle regeneration failed" 1)))
              (array/push prior-oracles oracle)
              (array/push gate-records {:args (get r :args) :stdin replay-stdin
                                        :oracle oracle}))
            (aot-report-divergence [;(map (fn [r] (get r :profile)) prior)
                                    (string ndir "/profile.raw.jdn")])
            (aot-merge-profiles [;(map (fn [r] (get r :profile)) prior)
                                 (string ndir "/profile.raw.jdn")]
                                (string ndir "/profile.joined.jdn"))
            (os/rename (string ndir "/profile.joined.jdn") prof)))
        (eprint "bender --aot: pgo collected profile")
        (set profile-args ["--profile" prof])
        (set gate true)
        (set gate-workload pgo-args)
        (set gate-stdin (if captured-stdin (string ndir "/stdin.capture") ""))
        (array/push gate-records {:args pgo-args :stdin gate-stdin
                                  :oracle expected}))
      # --pgo-auto: merge the runtime evidence this output key already
      # collected. Every candidate must carry a replayable workload record,
      # be newer than the sources, and then reproduce the interpreter's
      # output through the same parity gate --pgo uses. Evidence is kept per
      # workload (identity = argv + stdin), never flattened into one
      # anonymous union.
      (var auto-groups @[])
      (when pgo-auto
        (def cdir (aot-cache-dir))
        (unless (and cdir (os/stat cdir))
          (aot-die "--pgo-auto found no PGO cache; run the training binary first" 1))
        (def key (aot-cache-key out))
        (def sources [src ;includes ;extrac])
        (var groups nil)
        (var rejected nil)
        (var prior nil)
        (try
          (aot-cache-transaction cdir key (fn []
            (def pair (aot-auto-groups cdir key sources))
            (set groups (pair 0))
            (set rejected (pair 1))
            (set prior (aot-cache-load cdir key sources true))))
          ([e] (aot-die (string "PGO cache busy or unreadable: " e) 1)))
        (each entry rejected
          (eprint "bender --aot: --pgo-auto skipping " (entry 0) ": " (entry 1)))
        (when (empty? groups)
          (aot-die "--pgo-auto found no replayable auto-PGO evidence for this key" 1))
        # A legacy v2 record in the cache would need its oracle regenerated
        # before republication; that promotion belongs to --pgo.
        (when (and prior (find (fn [r] (nil? (get r :oracle))) prior))
          (aot-die "--pgo-auto cannot promote a legacy cache record; run --pgo once first" 1))
        (unless (os/stat ndir) (os/mkdir ndir))
        (var profile-count 0)
        (each g groups (+= profile-count (length (get g :profiles))))
        (eprint "bender --aot: --pgo-auto merging " profile-count " auto profiles over "
                (length groups) " workloads")
        (def exe (aot-abs-exe))
        (for gi 0 (length groups)
          (def g (groups gi))
          # per-workload merge, with the same accumulator --pgo uses
          (def merged (string ndir "/auto-profile-" gi ".jdn"))
          (try (aot-merge-profiles (get g :profiles) merged)
            ([e] (aot-die (string "--pgo-auto profile merge failed: " e) 1)))
          # The oracle is regenerated from the CURRENT sources: a recorded
          # output hash is provenance, not an authority.
          (def oracle (string ndir "/auto-oracle-" gi ".out"))
          (def input-path (string ndir "/auto-stdin-" gi))
          (when (get g :has-stdin) (spit input-path (get g :stdin-bytes)))
          (def oenv (merge @{} (os/environ) {"JANET_NO_PROFILE" "1"}))
          (def oout (file/open oracle :w))
          (var oin nil)
          (when (get g :has-stdin)
            (set oin (file/open input-path :r))
            (put oenv :in oin))
          (put oenv :out oout)
          (def ocode (os/execute [exe src ;(get g :argv)]
                                 (if (string/find "/" exe) :e :ep) oenv))
          (file/close oout)
          (when oin (file/close oin))
          (unless (= 0 ocode)
            (aot-auto-quarantine (get g :profiles))
            (aot-die (string "--pgo-auto oracle run failed with exit " ocode
                             " for workload \"" (get g :args) "\"") 1))
          (eprint "bender --aot: --pgo-auto workload " gi " runs=" (length (get g :profiles))
                  " argv=\"" (get g :args) "\"")
          (array/push auto-groups g)
          (array/push gate-records {:args (get g :args) :argv (get g :argv)
                                    :stdin (if (get g :has-stdin) input-path "")
                                    :oracle oracle :profile merged}))
        (def joined (string ndir "/profile.jdn"))
        (aot-report-divergence (map (fn [r] (get r :profile)) gate-records))
        (aot-merge-profiles (map (fn [r] (get r :profile)) gate-records) joined)
        (set profile-args ["--profile" joined])
        (set gate true)
        (set gate-workload (get (gate-records 0) :args))
        (set gate-stdin (get (gate-records 0) :stdin)))
      # auto-PGO: no flags needed. A fresh cached profile (collected by
      # first binary runs or earlier --pgo builds, newer than sources,
      # with a recorded workload) applies automatically through the
      # same parity gate. Anything missing prints what to do instead;
      # --no-auto-pgo skips this entirely. Never breaks the build.
      (var auto false)
      # A v3 cache is a set of verified, independently replayable runs.
      # Immutable generations permit replay after a locked manifest snapshot;
      # contention itself still means the cache is unavailable for this build.
      (var cache-busy false)
      (when (and native (not pgo) (not pgo-auto) (not no-auto-pgo)
                 (not only-c) (not print-c) (not run-mode))
        (def cdir (aot-cache-dir))
        (when (and cdir (os/stat cdir))
          (def key (aot-cache-key out))
          (var meta nil)
          (var records nil)
          (try
            (aot-cache-transaction cdir key (fn []
              (set meta (try (parse (slurp (string cdir "/" key ".meta"))) ([_] nil)))
              (when (= 3 (get meta :version))
                (set records (aot-cache-load cdir key [src ;includes ;extrac])))))
            ([e] (set cache-busy true)
                 (eprint "bender --aot: PGO cache busy or unreadable; building unoptimized")))
          (when (= 3 (get meta :version))
            (when records
              (unless (os/stat ndir) (os/mkdir ndir))
              (aot-report-divergence (map (fn [r] (get r :profile)) records))
              # Rebuild the aggregate from the verified raw records: never
              # allow a stale aggregate to erase one workload's evidence.
              (aot-merge-profiles (map (fn [r] (get r :profile)) records)
                                  (string ndir "/profile.jdn"))
              (set profile-args ["--profile" (string ndir "/profile.jdn")])
              (each r records
                (def input-path (string ndir "/replay-stdin-" (length gate-records)))
                (when (get r :has-stdin) (spit input-path (get r :stdin-bytes)))
                (array/push gate-records {:args (get r :args)
                                          :stdin (if (get r :has-stdin) input-path "")
                                          :oracle (get r :oracle)}))
              (set gate true)
              (set auto true)
              (eprint "bender --aot: verifying " (length gate-records) " cached workloads")))))
      (when (and native (not pgo) (not pgo-auto) (not no-auto-pgo)
                 (not cache-busy) (not gate) (not only-c) (not print-c) (not run-mode))
        (def cdir (aot-cache-dir))
        (when cdir
          (def key (aot-cache-key out))
          (def cprof (string cdir "/" key ".jdn"))
          (def cwork (string cdir "/" key ".workload"))
          (def cstdin (string cdir "/" key ".stdin"))
           (def cmeta (string cdir "/" key ".meta"))
           (def cinput (string cdir "/" key ".input"))
           (var workload-ok false)
           # Only explicit PGO establishes a replayable workload; binary
           # sidecars remain diagnostic and never enter a gateable cache.
           (var merge-failed false)
           (when (os/stat cdir)
             (try
               (aot-cache-transaction cdir key (fn []
                 (set workload-ok
                   (and (os/stat cmeta) (os/stat cwork) (os/stat cstdin)
                     (= :file (os/stat cprof :mode))
                     (def recorded (try (parse (slurp cmeta)) ([_] nil)))
                     (def current-sources (aot-source-identity [src ;includes ;extrac]))
                     current-sources
                     (deep= recorded
                       {:version 2 :args (string (slurp cwork))
                        :has-stdin (not (empty? (string (slurp cstdin))))
                        :stdin-bytes (if (os/stat cinput) (string (slurp cinput)) nil)
                        :sources current-sources})
                     (if (get recorded :has-stdin)
                       (os/stat cinput)
                       (nil? (os/stat cinput)))))
                 workload-ok))
               ([_] (set merge-failed true)
                    (eprint "bender --aot: PGO cache busy or merge failed; building unoptimized"))))
          (cond merge-failed
                 (eprint "bender --aot: profile merge failed; building unoptimized")
                 (not workload-ok)
                 (eprint "bender --aot: cached profile has no replayable workload; pass --pgo once")
                 (nil? (os/stat cprof))
                (eprint "bender --aot: no cached PGO profile yet; the binary profiles its first run automatically")
                (nil? (os/stat cwork))
                (eprint "bender --aot: cached profile has no workload; pass --pgo \"args\" once to make it gateable")
                (not (aot-cache-fresh? cprof [src ;includes ;extrac]))
                (eprint "bender --aot: cached profile is stale (sources are newer); it refreshes on the next run, or pass --pgo \"args\" now")
                (do (unless (os/stat ndir) (os/mkdir ndir))
                  (def aprof (string ndir "/profile.jdn"))
                  (spit aprof (slurp cprof))
                  (set expected (string ndir "/expected.out"))
                  # fresh oracle for current sources (cached output
                  # would be stale by the same argument as profiles)
                  (eprint "bender --aot: applying cached PGO profile; verifying with recorded workload")
                  (def exe (aot-abs-exe))
                  (def wargs (string (slurp cwork)))
                  (def wpargs (aot-words wargs))
                  (var winfile nil)
                  (var wstdin "")
                  (when (get (parse (slurp cmeta)) :has-stdin)
                    (set wstdin cinput)
                    (set winfile (file/open cinput :r)))
                  (def wout (file/open expected :w))
                  (def wenv (merge @{} (os/environ)))
                  (when release (put wenv "JANET_NO_PROFILE" "1"))
                  (when winfile (put wenv :in winfile))
                  (put wenv :out wout)
                  (def wcode (os/execute [exe src ;wpargs]
                                         (if (string/find "/" exe) :e :ep) wenv))
                  (file/close wout)
                  (when winfile (file/close winfile))
                  (when (not= wcode 0)
                    (when release (aot-die (string "--release oracle run failed with exit " wcode) 1))
                    (eprint "bender --aot: oracle run failed; building unoptimized")
                    (set expected nil))
                  (when expected
                    (set profile-args ["--profile" aprof])
                    (set gate true)
                    (set auto true)
                    (set gate-workload wargs)
                    (set gate-stdin wstdin)
                    (array/push gate-records {:args wargs :stdin wstdin
                                              :oracle expected}))))))
      (when (and release (not gate))
        (aot-die "--release needs compatible cached PGO evidence and a replayable workload; run --pgo first" 1))
      (when (and pack-upx (not gate))
        (aot-die "--upx needs --pgo or compatible cached evidence with a replayable workload" 1))
      (when (and pack-upx (> (length gate-records) 1))
        (aot-die "--upx multi-workload packed parity is not implemented" 1))
      # B7.2 Part B, Piece 1c. The exclusion file is the ONLY channel
      # carrying the dce-reachable verdict to mkimage.janet (same
      # write-a-file/read-a-file convention as native-names.txt). A
      # stale file from an earlier --dce build in the same ndir would
      # silently re-strip on a later non---dce build, so it is removed
      # unconditionally first: "no file" is the canonical encoding of
      # both "flag absent" and ":unsafe verdict".
      (def dce-excluded-file (string ndir "/dce-excluded.txt"))
      (unless (os/stat ndir) (os/mkdir ndir))
      (when (os/stat dce-excluded-file) (try (os/rm dce-excluded-file) ([_] nil)))
      (aot-run-tool tooldir "callgraph.janet"
                    [src ;inc-args ;profile-args "--emit-native-lib" ndir
                     ;(if dce ["--dce"] [])
                     ;(if externs ["--externs" externs] [])])
      (aot-run-tool tooldir "mkimage.janet"
                    [src "--native" (string ndir "/native-names.txt")
                     ;(if (and dce (os/stat dce-excluded-file))
                        ["--dce-excluded" dce-excluded-file] [])
                     cfile])
      (when print-c
        (file/write stdout (slurp cfile))
        (file/write stdout (slurp (string ndir "/native.c"))))
      (unless print-c
        (when only-c (print "wrote " cfile " + " ndir "/native.c"))
        (unless only-c
          (def native-c (string ndir "/native.c"))
          (def libjanet (string root "/build/libjanet.a"))
          (def ccbase [cc optflag ;(if size-opt ["-ffunction-sections" "-fdata-sections"] []) "-fwrapv"
                       "-fno-math-errno" "-fno-trapping-math"
                       "-w" "-DJANET_AOT_NATIVE_INIT" ;release-flags
                       "-I" (string root "/build")
                       "-I" (string root "/src/include")
                       cfile native-c ;extrac libjanet
                       ;(aot-words ldflags) ;sizelink "-lm" "-lpthread" "-o"])
          (var gate-fallback false)
          (when gate
            # phase 1+2 (seeded build, parity gate): binary goes to a
            # temp name first; stdout must match the interpreter
            # byte-for-byte or nothing installs. Explicit --pgo dies on
            # mismatch; the auto path falls back to unoptimized (never
            # break the build for a stale cache).
            (do (def candidate (string out ".pgo-tmp"))
              (aot-run-cc [;ccbase candidate])
              (def actual (string ndir "/actual.out"))
              (for idx 0 (length gate-records)
                (def rec (gate-records idx))
                (def aout (file/open actual :w))
                (def aenv (merge @{} (os/environ) {"JANET_NO_PROFILE" "1"}))
                (var ainfile nil)
                (def input (get rec :stdin))
                (when (not (empty? input))
                  (unless (os/stat input)
                    (aot-die (string "gate stdin file is gone for workload " idx) 1))
                  (set ainfile (file/open input :r))
                  (put aenv :in ainfile))
                (put aenv :out aout)
                (def acode (os/execute [candidate ;(or (get rec :argv)
                                                       (aot-words (get rec :args)))]
                                       :e aenv))
                (file/close aout)
                (when ainfile (file/close ainfile))
                (when (or (not= acode 0)
                          (not= (string (slurp (get rec :oracle))) (string (slurp actual))))
                  (eprint "bender --aot: PGO PARITY FAILED workload " idx
                          " argv=" (get rec :args) " (artifacts in " ndir ")")
                  # --pgo-auto evidence that cannot reproduce the interpreter
                  # is moved aside so no later build can reuse it.
                  (when pgo-auto
                    (aot-auto-quarantine (get (auto-groups idx) :profiles)))
                  (if (and auto (not release))
                    (set gate-fallback true)
                    (aot-die "PGO workload parity failed; no binary installed" 1))))
              (unless gate-fallback
                (do (size-finish candidate)
                      (package-upx candidate gate-workload gate-stdin)
                      # explicit --pgo refreshes the cache (profile +
                      # workload) before installing. Failure preserves the
                      # previous binary and previous published cache state.
                      (when pgo
                        (unless (aot-cache-store out ndir gate-workload pgo-stdin
                                                 [src ;includes ;extrac] captured-stdin
                                                 prior-oracles prior-cache-meta)
                          (aot-die "PGO cache publication failed; no binary installed" 1)))
                      # --pgo-auto publishes one gateable v3 record per
                      # verified workload, reusing the --pgo publication
                      # path, so a later --release finds real evidence.
                      (when pgo-auto
                        (def cdir (aot-cache-dir))
                        (def ckey (aot-cache-key out))
                        (def cmeta (string cdir "/" ckey ".meta"))
                        (for gi 0 (length auto-groups)
                          (def g (auto-groups gi))
                          (def rec (gate-records gi))
                          (spit (string ndir "/profile.raw.jdn") (slurp (get rec :profile)))
                          (spit (string ndir "/expected.out") (slurp (get rec :oracle)))
                          (def snapshot (if (os/stat cmeta) (string (slurp cmeta)) nil))
                          (unless (aot-cache-store out ndir (get g :args)
                                                   (get rec :stdin)
                                                   [src ;includes ;extrac]
                                                   (if (get g :has-stdin)
                                                     (get g :stdin-bytes) nil)
                                                   @[] snapshot)
                            (aot-die "PGO cache publication failed; no binary installed" 1)))
                        (eprint "bender --aot: --pgo-auto published " (length auto-groups)
                                " gateable workloads"))
                      (os/rename candidate out)
                      (eprint "bender --aot: pgo parity ok, installed " out)))))
          (when (and release gate-fallback)
            (aot-die "--release parity failed; no unoptimized release fallback" 1))
          (when (and pack-upx gate-fallback)
            (aot-die "--upx cannot package an unverified fallback" 1))
          (unless (and gate (not gate-fallback))
            (do (def target (if size-opt (string out ".size-tmp") out))
              (aot-run-cc [;ccbase target])
              (size-finish target)
              (when size-opt (os/rename target out))
              (unless run-mode (print "built " out))))))))
  (when run-mode
    # -E: run the staged app with the remaining args, clean up, and
    # propagate its exit code (like exec in the shell driver).
    (def code (os/execute [out ;appargs]))
    (if native
      (do (def ndir (string out "-native"))
        (aot-clean [out cfile (string ndir "/native.c")
                     (string ndir "/native-names.txt")
                     (string ndir "/dce-excluded.txt")]
                   [ndir stage]))
      (aot-clean [out cfile] [stage]))
    (os/exit code))
  math/inf)

(defn cli-main
  `Entrance for the Janet CLI tool. Call this function with the command line
  arguments as an array or tuple of strings to invoke the CLI interface.`
  [args]

  (setdyn *args* args)

  (var should-repl nil)
  (var no-file true)
  (var quiet false)
  (var raw-stdin false)
  (var handleopts true)
  (var exit-on-error true)
  (var compile-only false)
  (var expect-image false)

  (when-let [jp (getenv-alias "JANET_PATH")]
    (def path-sep (if (index-of (os/which) [:windows :mingw]) ";" ":"))
    (def paths (string/split path-sep jp))
    (loop [i :down-to [(- (length paths) 1) 1]]
      (module/add-syspath (get paths i)))
    (setdyn *syspath* (first paths)))
  (if-let [jprofile (getenv-alias "JANET_PROFILE")] (setdyn *profilepath* jprofile))
  (apply-color
    (and
      (not (getenv-alias "NO_COLOR"))
      (os/isatty stdout)
      (os/isatty stderr)))

  (defn- get-lint-level
    [i]
    (def x (in args (+ i 1)))
    (or (scan-number x) (keyword x)))

  # Flag handlers
  (def handlers
    {"h" (fn [&]
           (print "usage: " (dyn *executable* "janet") " [options] script args...")
           (print
             ```
             Options are:
               --help (-h)             : Show this help
               --version (-v)          : Print the version string
               --stdin (-s)            : Use raw stdin instead of getline like functionality
               --eval (-e) code        : Evaluate some code for side effects
               --expression (-E) code arguments... : Evaluate an expression as a short-fn with arguments
               --debug (-d)            : Set the debug flag in the REPL
               --repl (-r)             : Enter the REPL after running all scripts
               --noprofile (-R)        : Disables loading profile.janet when JANET_PROFILE is present
               --persistent (-p)       : Keep on executing if there is a top-level error (persistent)
               --quiet (-q)            : Hide logo (quiet)
               --flycheck (-k)         : Compile scripts but do not execute (flycheck)
               --syspath (-m) syspath  : Set system path for loading global modules
               --compile (-c) source output : Compile janet source code into an image
               --image (-i)            : Load the script argument as an image file instead of source code
               --nocolor (-n)          : Disable ANSI color output in the REPL
               --color (-N)            : Enable ANSI color output in the REPL
               --library (-l) lib      : Use a module before processing more arguments
               --tool (-t) lib args... : Use a module before processing more arguments, and then call it's `main` function
               --lint-warn (-w) level  : Set the lint warning level - default is "normal"
               --lint-error (-x) level : Set the lint error level - default is "none"
               --install (-b) dirpath  : Install a bundle from a directory
               --reinstall (-B) name   : Reinstall a bundle by bundle name
               --uninstall (-u) name   : Uninstall a bundle by bundle name
                --update-all (-U)       : Reinstall all installed bundles
                --prune (-P)            : Uninstall all bundles that are orphaned
                --list (-L)             : List all installed bundles
                --aot args...           : Build an AOT executable (plain VM image or --native hybrid)
                                          --aot app.janet [-o app] [-c] [-S] [-E args...]
                                          [--native] [--externs F] [--include F] [-x F]
                                          [--ldflags S] [--pgo ARGS] [--pgo-stdin F]
                                          [--pgo-auto] [--no-auto-pgo] [--release] [-Oz] [--upx]
                                          --pgo requires --native; collect/replay ARGS for parity
                                          --pgo-auto requires --native; merges and gates the auto-PGO
                                            runs this output key already collected (JANET_AUTO_PGO=1),
                                            quarantining evidence that fails parity
                                          --no-auto-pgo skips cached evidence during this build
                                          --release requires --native and verified cached evidence;
                                            final binary omits automatic profiling and native telemetry
                                          -Oz optimizes/strips a staged binary for size
                                          --upx requires supported Linux ELF, UPX and parity workload
                Environment (PGO):     ordinary script runs collect diagnostics by default;
                                          JANET_NO_PROFILE=1 disables implicit collection
                                          JANET_PROFILE=1 enables explicit interpreter collection;
                                          JANET_PROFILE_OUT=path writes the profile dump
                                          JANET_AUTO_PGO=1 forces AOT-binary diagnostic sidecars
                                          JANET_AUTO_PGO_MIN_CALLS=N sets auto dump threshold (10000)
                                          XDG_CACHE_HOME selects the PGO cache root
                --                      : Stop handling options
             ```)
           (os/exit 0)
           1)
     "v" (fn [&] (print janet/version "-" janet/build) (os/exit 0) 1)
     "s" (fn [&] (set raw-stdin true) (set should-repl true) 1)
     "r" (fn [&] (set should-repl true) 1)
     "p" (fn [&] (set exit-on-error false) 1)
     "q" (fn [&] (set quiet true) 1)
     "i" (fn [&] (set expect-image true) 1)
     "k" (fn [&] (set compile-only true) (set exit-on-error false) 1)
     "n" (fn [&] (apply-color false) 1)
     "N" (fn [&] (apply-color true) 1)
     "m" (fn [i &] (setdyn *syspath* (in args (+ i 1))) 2)
     "c" (fn :c-switch [i &]
           (def path (in args (+ i 1)))
           (def e (dofile path))
           (def output-path
             (if (< (+ i 2) (length args))
               (in args (+ i 2))
               (string
                 (if (string/has-suffix? ".janet" path) (string/slice path 0 -7) path)
                 ".jimage")))
           (spit output-path (make-image e))
           (set no-file false)
           3)
     "-" (fn [&] (set handleopts false) 1)
     "l" (fn :l-switch [i &]
           (import* (in args (+ i 1))
                    :prefix "" :exit exit-on-error)
           2)
     "t" (fn :t-switch [i &]
           (set should-repl false)
           (set no-file false)
           (def lib (in args (+ i 1)))
           (def tool-env (require lib :exit exit-on-error))
           (def subargs (tuple/slice args (+ i 2)))
           (put tool-env *args* subargs)
           (assertf (run-main tool-env subargs) "no main found for module %s" lib)
           math/inf)
     "e" (fn :e-switch [i &]
           (set no-file false)
           (eval-string (in args (+ i 1)))
           2)
     "E" (fn :E-switch [i &]
           (set no-file false)
           (def subargs (array/slice args (+ i 2)))
           (def src ~(short-fn ,(parse (in args (+ i 1))) E-expression))
           (def thunk (compile src))
           (if (function? thunk)
             ((thunk) ;subargs)
             (error (get thunk :error)))
           math/inf)
     "b"
     (compif (dyn 'bundle/install)
       (fn [i &] (bundle/install (in args (+ i 1))) (set no-file false) (if (= nil should-repl) (set should-repl false)) 2)
       (fn [i &] (eprint "--install not supported with reduced os") 2))
     "B"
     (compif (dyn 'bundle/reinstall)
       (fn [i &] (bundle/reinstall (in args (+ i 1))) (set no-file false) (if (= nil should-repl) (set should-repl false)) 2)
       (fn [i &] (eprint "--reinstall not supported with reduced os") 2))
     "u"
     (compif (dyn 'bundle/uninstall)
       (fn [i &] (bundle/uninstall (in args (+ i 1))) (set no-file false) (if (= nil should-repl) (set should-repl false)) 2)
       (fn [i &] (eprint "--uninstall not supported with reduced os") 2))
     "P"
     (compif (dyn 'bundle/prune)
       (fn [i &] (bundle/prune) (set no-file false) (if (= nil should-repl) (set should-repl false)) 1)
       (fn [i &] (eprint "--prune not supported with reduced os") 1))
     "U"
     (compif (dyn 'bundle/update-all)
       (fn [i &] (bundle/update-all) (set no-file false) (if (= nil should-repl) (set should-repl false)) 1)
       (fn [i &] (eprint "--update-all not supported with reduced os") 1))
     "L"
     (compif (dyn 'bundle/list)
       (fn [i &] (each l (bundle/list) (print l)) (set no-file false) (if (= nil should-repl) (set should-repl false)) 1)
       (fn [i &] (eprint "--list not supported with reduced os") 1))
      "d" (fn [&] (setdyn *debug* true) (setdyn *redef* true) 1)
      "-aot" (fn [i &]
               (set no-file false)
               (set should-repl false)
               (aot-compile (array/slice args (+ i 1)))
               math/inf)
     "w" (fn [i &] (setdyn *lint-warn* (get-lint-level i)) 2)
     "x" (fn [i &] (setdyn *lint-error* (get-lint-level i)) 2)
     "R" (fn [&] (setdyn *profilepath* nil) 1)})

  (defn- dohandler [n i &]
    (def h (in handlers (get long-to-short n n)))
    (if h (h i handlers) (do (print "unknown flag -" n) ((in handlers "h")))))

  # Process arguments
  (var i 0)
  (def lenargs (length args))
  (while (< i lenargs)
    (def arg (in args i))
    (if (and handleopts (= "-" (string/slice arg 0 1)))
      (+= i (dohandler (string/slice arg 1) i))
      (do
        (def subargs (array/slice args i))
        (set no-file false)
        (if expect-image
          (do
            (def env (load-image (slurp arg)))
            (put env *args* subargs)
            (run-main env subargs))
          (do
            (def env (make-env))
            (put env *args* subargs)
            (if compile-only
              (flycheck arg :exit exit-on-error :env env)
              (do
                # Implicit interpreter runs are diagnostic, never gateable.
                # Explicit JANET_PROFILE_OUT keeps its legacy dump point.
                (def explicit-profile (getenv-alias "JANET_PROFILE"))
                (def explicit-output (getenv-alias "JANET_PROFILE_OUT"))
                (var implicit-output nil)
                (var initial-source nil)
                (when (and (not (getenv-alias "JANET_NO_PROFILE"))
                           (not explicit-profile) (not explicit-output))
                  (set implicit-output (development-profile-path arg))
                  (when implicit-output
                    (set initial-source (aot-source-identity [arg]))
                    (unless initial-source (set implicit-output nil)))
                  (when implicit-output (development-mkdir-p (development-profile-dir)))
                  (when (and implicit-output (os/stat implicit-output))
                    (set implicit-output nil)))
                (when (or explicit-profile implicit-output)
                  (debug/profile-start))
                (dofile arg :exit exit-on-error :env env)
                (when explicit-output (debug/profile-dump explicit-output))
                (run-main env subargs)
                (when implicit-output
                  (try (do (def pending (string implicit-output ".pending"))
                           (debug/profile-dump pending)
                           (when (and (> (or (os/stat pending :size) 0) 0)
                                      (deep= initial-source (aot-source-identity [arg])))
                             (spit (string implicit-output ".meta")
                                   (string/format "%j" initial-source))
                             (os/rename pending implicit-output)
                             (development-profile-accumulate arg implicit-output)))
                    ([_] nil)))))))
        (set i lenargs))))

  (if (or should-repl no-file)
    (if
      compile-only (flycheck stdin :source :stdin :exit exit-on-error)
      (do
        (if-not quiet
          (print "Bender " janet/version "-" janet/build " " (os/which) "/" (os/arch) "/" (os/compiler) " - '(doc)' for help"))
        (flush)
        (def env (make-env))
        (defn getprompt [p]
          (when-let [custom-prompt (get env *repl-prompt*)] (break (custom-prompt p)))
          (def [line] (parser/where p))
          (string "repl:" line ":" (parser/state p :delimiters) "> "))
        (def getter (if raw-stdin getstdin getline))
        (defn getchunk [buf p]
          (getter (getprompt p) buf env))
        (when-let [profile.janet (dyn *profilepath*)]
          (dofile profile.janet :exit true :env env)
          (put env *current-file* nil))
        (repl getchunk nil env)))))

###
###
### Bootstrap
###
###

(setdyn :optimize nil)

(do

  # Modify root-env to remove private symbols and
  # flatten nested tables.
  (loop [[k v] :in (pairs root-env)
         :when (symbol? k)]
    (def flat (table/proto-flatten v))
    (when (boot/config :no-docstrings)
      (put flat :doc nil))
    (when (boot/config :no-sourcemaps)
      (put flat :source-map nil))
    (unless (boot/config :no-docstrings)
      (unless (v :private)
        (unless (v :doc)
          (errorf "no docs: %v %p" k v)))) # make sure we have docs
    # Fix directory separators on windows to make image identical between windows and non-windows
    (when-let [sm (get flat :source-map)]
      (put flat :source-map [(string/replace-all "\\" "/" (sm 0)) (sm 1) (sm 2)]))
    (if (v :private)
      (put root-env k nil)
      (put root-env k flat)))
  (put root-env 'boot/config nil)
  (put root-env 'boot/args nil)

  # Build dictionary for loading images
  (def load-dict (env-lookup root-env))
  (each [k v] (pairs load-dict)
    # Drop simple types, otherwise we get odd issues when loading foreign data from a different Janet version.
    # It also doesn't usually save any space to encode these anyway.
    (if (or (string? v) (keyword? v) (number? v)) (put load-dict k nil)))
  (merge-into load-image-dict load-dict)

  (def image
    (let [env-pairs (pairs (env-lookup root-env))
          essential-pairs (filter (fn [[k v]] (or (cfunction? v) (abstract? v))) env-pairs)
          lookup (table ;(mapcat identity essential-pairs))
          reverse-lookup (invert lookup)]
      # Check no duplicate values
      (def temp @{})
      (eachp [k v] lookup
        (if (in temp v) (errorf "duplicate value: %v" v))
        (put temp v k))
      (marshal root-env reverse-lookup)))

  # Create amalgamation

  (def feature-header "src/core/features.h")

  (def local-headers
    ["src/core/state.h"
     "src/core/util.h"
     "src/core/gc.h"
     "src/core/vector.h"
     "src/core/fiber.h"
     "src/core/ev.h"
     "src/core/proc.h"
     "src/core/regalloc.h"
     "src/core/compile.h"
     "src/core/emit.h"
     "src/core/symcache.h"])

  (def core-sources
    ["src/core/abstract.c"
     "src/core/array.c"
     "src/core/asm.c"
     "src/core/buffer.c"
     "src/core/bytecode.c"
     "src/core/capi.c"
     "src/core/cfuns.c"
     "src/core/compile.c"
     "src/core/corelib.c"
     "src/core/debug.c"
     "src/core/emit.c"
     "src/core/ev.c"
     "src/core/ffi.c"
     "src/core/fiber.c"
     "src/core/filewatch.c"
     "src/core/gc.c"
     "src/core/inttypes.c"
     "src/core/io.c"
     "src/core/marsh.c"
     "src/core/math.c"
     "src/core/net.c"
     "src/core/os.c"
     "src/core/parse.c"
     "src/core/peg.c"
     "src/core/pp.c"
     "src/core/proc.c"
     "src/core/regalloc.c"
     "src/core/run.c"
     "src/core/specials.c"
     "src/core/state.c"
     "src/core/string.c"
     "src/core/strtod.c"
     "src/core/struct.c"
     "src/core/symcache.c"
     "src/core/table.c"
     "src/core/tuple.c"
     "src/core/util.c"
     "src/core/value.c"
     "src/core/vector.c"
     "src/core/vm.c"
     "src/core/wrap.c"])

  # Print janet.c to stdout
  (def image-only (has-value? boot/args "image-only"))
  (print "/* " (if image-only "Image-only" "Amalgamated") " build - DO NOT EDIT */")
  (print "/* Generated from janet version " janet/version "-" janet/build " */")
  (print "#define JANET_BUILD \"" janet/build "\"")
  (print ```#define JANET_AMALG```)

  (defn do-one-file
    [fname]
    (unless image-only
      (print "\n/* " fname " */")
      (print "#line 0 \"" fname "\"\n")
      (def source (slurp fname))
      (print (string/replace-all "\r" "" source))))

  (do-one-file feature-header)

  (print ```#include "janet.h"```)

  (each h local-headers
    (do-one-file h))

  # windows.h should not be included in any of the external or internal headers - only in .c files.
  (print)
  (print "/* Windows work around - winsock2 must be included before windows.h, especially in amalgamated build */")
  (print "#if defined(JANET_WINDOWS) && defined(JANET_NET)")
  (print "#include <winsock2.h>")
  (print "#endif")
  (print)

  (each s core-sources
    (do-one-file s))

  # Create C source file that contains the boot image in a uint8_t buffer. This
  # can be compiled and linked statically into the main janet library and client
  (print "static const unsigned char janet_core_image_bytes[] = {")
  (loop [line :in (partition 16 image)]
    (prin "  ")
    (each b line
      (prinf "0x%.2X, " b))
    (print))
  (print "  0\n};\n")
  (print "const unsigned char *janet_core_image = janet_core_image_bytes;")
  (print "size_t janet_core_image_size = sizeof(janet_core_image_bytes);"))
