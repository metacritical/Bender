/*
* Copyright (c) 2026 Calvin Rose
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
*/

#ifndef JANET_AMALG
#include "features.h"
#include <janet.h>
#include "compile.h"
#include "util.h"
#include "vector.h"
#include "emit.h"
#endif

static int bad_16bit_jump(int32_t lab1, int32_t lab2) {
    if (lab2 - lab1 > INT16_MAX) return 1;
    if (lab2 - lab1 < INT16_MIN) return 1;
    return 0;
}

static void check_16bit_jump(JanetCompiler *c, int32_t lab1, int32_t lab2) {
    if (bad_16bit_jump(lab1, lab2)) {
        janetc_cerror(c, "bad 16-bit jump, too large");
    }
}

static int bad_24bit_jump(int32_t lab1, int32_t lab2) {
    if (lab2 - lab1 > 0xFFFFFF) return 1;
    if (lab2 - lab1 < -0x1000000) return 1;
    return 0;
}

static void check_24bit_jump(JanetCompiler *c, int32_t lab1, int32_t lab2) {
    if (bad_24bit_jump(lab1, lab2)) {
        janetc_cerror(c, "bad 24-bit jump, too large");
    }
}

static JanetSlot janetc_quote(JanetFopts opts, int32_t argn, const Janet *argv) {
    if (argn != 1) {
        janetc_cerror(opts.compiler, "expected 1 argument to quote");
        return janetc_cslot(janet_wrap_nil());
    }
    return janetc_cslot(argv[0]);
}

static JanetSlot janetc_splice(JanetFopts opts, int32_t argn, const Janet *argv) {
    JanetSlot ret;
    if (!(opts.flags & JANET_FOPTS_ACCEPT_SPLICE)) {
        janetc_cerror(opts.compiler, "splice can only be used in function parameters and data constructors, it has no effect here");
        return janetc_cslot(janet_wrap_nil());
    }
    if (argn != 1) {
        janetc_cerror(opts.compiler, "expected 1 argument to splice");
        return janetc_cslot(janet_wrap_nil());
    }
    ret = janetc_value(opts, argv[0]);
    ret.flags |= JANET_SLOT_SPLICED;
    return ret;
}

static JanetSlot qq_slots(JanetFopts opts, JanetSlot *slots, int makeop) {
    JanetSlot target = janetc_gettarget(opts);
    janetc_pushslots(opts.compiler, slots);
    janetc_freeslots(opts.compiler, slots);
    janetc_emit_s(opts.compiler, makeop, target, 1);
    return target;
}

static JanetSlot quasiquote(JanetFopts opts, Janet x, int depth, int level) {
    if (depth == 0) {
        janetc_cerror(opts.compiler, "quasiquote too deeply nested");
        return janetc_cslot(janet_wrap_nil());
    }
    JanetSlot *slots = NULL;
    JanetFopts subopts = opts;
    subopts.flags &= ~JANET_FOPTS_HINT;
    switch (janet_type(x)) {
        default:
            return janetc_cslot(x);
        case JANET_TUPLE: {
            int32_t i, len;
            const Janet *tup = janet_unwrap_tuple(x);
            len = janet_tuple_length(tup);
            if (len > 1 && janet_checktype(tup[0], JANET_SYMBOL)) {
                const uint8_t *head = janet_unwrap_symbol(tup[0]);
                if (!janet_cstrcmp(head, "unquote")) {
                    if (level == 0) {
                        JanetFopts subopts = janetc_fopts_default(opts.compiler);
                        subopts.flags |= JANET_FOPTS_ACCEPT_SPLICE;
                        return janetc_value(subopts, tup[1]);
                    } else {
                        level--;
                    }
                } else if (!janet_cstrcmp(head, "quasiquote")) {
                    level++;
                }
            }
            for (i = 0; i < len; i++)
                janet_v_push(slots, quasiquote(subopts, tup[i], depth - 1, level));
            return qq_slots(opts, slots, (janet_tuple_flag(tup) & JANET_TUPLE_FLAG_BRACKETCTOR)
                            ? JOP_MAKE_BRACKET_TUPLE
                            : JOP_MAKE_TUPLE);
        }
        case JANET_ARRAY: {
            int32_t i;
            JanetArray *array = janet_unwrap_array(x);
            for (i = 0; i < array->count; i++)
                janet_v_push(slots, quasiquote(subopts, array->data[i], depth - 1, level));
            return qq_slots(opts, slots, JOP_MAKE_ARRAY);
        }
        case JANET_TABLE:
        case JANET_STRUCT: {
            const JanetKV *kv = NULL, *kvs = NULL;
            int32_t len, cap = 0;
            janet_dictionary_view(x, &kvs, &len, &cap);
            while ((kv = janet_dictionary_next(kvs, cap, kv))) {
                JanetSlot key = quasiquote(subopts, kv->key, depth - 1, level);
                JanetSlot value =  quasiquote(subopts, kv->value, depth - 1, level);
                key.flags &= ~JANET_SLOT_SPLICED;
                value.flags &= ~JANET_SLOT_SPLICED;
                janet_v_push(slots, key);
                janet_v_push(slots, value);
            }
            return qq_slots(opts, slots,
                            janet_checktype(x, JANET_TABLE) ? JOP_MAKE_TABLE : JOP_MAKE_STRUCT);
        }
    }
}

static JanetSlot janetc_quasiquote(JanetFopts opts, int32_t argn, const Janet *argv) {
    if (argn != 1) {
        janetc_cerror(opts.compiler, "expected 1 argument to quasiquote");
        return janetc_cslot(janet_wrap_nil());
    }
    return quasiquote(opts, argv[0], opts.compiler->recursion_guard, 0);
}

static JanetSlot janetc_unquote(JanetFopts opts, int32_t argn, const Janet *argv) {
    (void) argn;
    (void) argv;
    janetc_cerror(opts.compiler, "cannot use unquote here");
    return janetc_cslot(janet_wrap_nil());
}

/* Perform destructuring. Be careful to
 * keep the order registers are freed.
 * Returns if the slot 'right' can be freed. */
/* Byte-compare two string-like keys (symbol/keyword/string), so `:or`
 * defaults keyed by symbol `a` match keyword lookups for `:a`. */
static int destructure_key_bytes_equal(Janet a, Janet b) {
    const uint8_t *ab = NULL, *bb = NULL;
    int32_t alen = 0, blen = 0;
    switch (janet_type(a)) {
        case JANET_SYMBOL:
            ab = janet_unwrap_symbol(a);
            break;
        case JANET_KEYWORD:
            ab = janet_unwrap_keyword(a);
            break;
        case JANET_STRING:
            ab = janet_unwrap_string(a);
            break;
        default:
            return 0;
    }
    switch (janet_type(b)) {
        case JANET_SYMBOL:
            bb = janet_unwrap_symbol(b);
            break;
        case JANET_KEYWORD:
            bb = janet_unwrap_keyword(b);
            break;
        case JANET_STRING:
            bb = janet_unwrap_string(b);
            break;
        default:
            return 0;
    }
    alen = janet_string_length(ab);
    blen = janet_string_length(bb);
    if (alen != blen) return 0;
    return !memcmp(ab, bb, (size_t) alen);
}
static int destructure(JanetCompiler *c,
                       Janet left,
                       JanetSlot right,
                       int (*leaf)(JanetCompiler *c,
                                   const uint8_t *sym,
                                   JanetSlot s,
                                   JanetTable *attr),
                       JanetTable *attr) {
    if (c->recursion_guard <= 0) {
        janetc_error(c, janet_cstring("C stack recursed too deeply"));
        return 1;
    }
    switch (janet_type(left)) {
        default:
            janetc_error(c, janet_formatc("unexpected type in destructuring, got %v", left));
            return 1;
        case JANET_SYMBOL:
            /* Leaf, assign right to left */
            return leaf(c, janet_unwrap_symbol(left), right, attr);
        case JANET_TUPLE:
        case JANET_ARRAY: {
            int32_t len = 0;
            const Janet *values = NULL;
            janet_indexed_view(left, &values, &len);
            for (int32_t i = 0; i < len; i++) {
                JanetSlot nextright = janetc_farslot(c);
                Janet subval = values[i];

                if (janet_checktype(subval, JANET_SYMBOL) && !janet_cstrcmp(janet_unwrap_symbol(subval), "&")) {
                    if (i + 1 >= len) {
                        janetc_cerror(c, "expected symbol following '& in destructuring pattern");
                        return 1;
                    }

                    if (i + 2 < len) {
                        int32_t num_extra = len - i - 1;
                        Janet *extra = janet_tuple_begin(num_extra);
                        janet_tuple_flag(extra) |= JANET_TUPLE_FLAG_BRACKETCTOR;

                        for (int32_t j = 0; j < num_extra; ++j) {
                            extra[j] = values[j + i + 1];
                        }

                        janetc_error(c, janet_formatc("expected a single symbol follow '& in destructuring pattern, found %q", janet_wrap_tuple(janet_tuple_end(extra))));
                        return 1;
                    }

                    if (!janet_checktype(values[i + 1], JANET_SYMBOL)) {
                        janetc_error(c, janet_formatc("expected symbol following '& in destructuring pattern, found %q", values[i + 1]));
                        return 1;
                    }

                    JanetSlot argi = janetc_farslot(c);
                    JanetSlot arg  = janetc_farslot(c);
                    JanetSlot len  = janetc_farslot(c);

                    janetc_emit_si(c, JOP_LOAD_INTEGER, argi, i, 0);
                    janetc_emit_ss(c, JOP_LENGTH, len, right, 0);

                    /* loop condition - reuse arg slot for the condition result */
                    int32_t label_loop_start = janetc_emit_sss(c, JOP_LESS_THAN, arg, argi, len, 0);
                    int32_t label_loop_cond_jump = janetc_emit_si(c, JOP_JUMP_IF_NOT, arg, 0, 0);

                    /* loop body */
                    janetc_emit_sss(c, JOP_GET, arg, right, argi, 0);
                    janetc_emit_s(c, JOP_PUSH, arg, 0);
                    janetc_emit_ssi(c, JOP_ADD_IMMEDIATE, argi, argi, 1, 0);

                    /* loop - jump back to the start of the loop */
                    int32_t label_loop_loop = janet_v_count(c->buffer);
                    janetc_emit(c, JOP_JUMP);
                    int32_t label_loop_exit = janet_v_count(c->buffer);

                    /* avoid shifting negative numbers */
                    check_16bit_jump(c, label_loop_cond_jump, label_loop_exit);
                    check_24bit_jump(c, label_loop_start, label_loop_loop);
                    c->buffer[label_loop_cond_jump] |= (uint32_t)(label_loop_exit - label_loop_cond_jump) << 16;
                    c->buffer[label_loop_loop] |= (uint32_t)(label_loop_start - label_loop_loop) << 8;

                    janetc_freeslot(c, argi);
                    janetc_freeslot(c, arg);
                    janetc_freeslot(c, len);

                    janetc_emit_s(c, JOP_MAKE_TUPLE, nextright, 1);

                    leaf(c, janet_unwrap_symbol(values[i + 1]), nextright, attr);
                    janetc_freeslot(c, nextright);
                    break;
                }

                if (i < 0x100) {
                    janetc_emit_ssu(c, JOP_GET_INDEX, nextright, right, (uint8_t) i, 1);
                } else {
                    JanetSlot k = janetc_cslot(janet_wrap_integer(i));
                    janetc_emit_sss(c, JOP_IN, nextright, right, k, 1);
                }
                c->recursion_guard--;
                if (destructure(c, subval, nextright, leaf, attr))
                    janetc_freeslot(c, nextright);
                c->recursion_guard++;
            }
        }
        return 1;
        case JANET_TABLE:
        case JANET_STRUCT: {
            const JanetKV *kvs = NULL;
            int32_t cap = 0, len = 0;
            janet_dictionary_view(left, &kvs, &len, &cap);
            /* Clojure-style `:or {key default}`: first pass collects
             * the defaults dict (literal values only — patterns are
             * data, so defaults cannot be computed). A non-dict `:or`
             * value falls through to a normal key binding. */
            const JanetKV *orkvs = NULL;
            int32_t orlen = 0, orcap = 0;
            {
                int32_t oi;
                for (oi = 0; oi < cap; oi++) {
                    if (janet_checktype(kvs[oi].key, JANET_KEYWORD)) {
                    }
                    if (janet_checktype(kvs[oi].key, JANET_KEYWORD) &&
                            !janet_cstrcmp(janet_unwrap_keyword(kvs[oi].key), "or") &&
                            (janet_checktype(kvs[oi].value, JANET_TABLE) ||
                             janet_checktype(kvs[oi].value, JANET_STRUCT))) {
                        {
                            Janet vv = kvs[oi].value;
                        }
                        janet_dictionary_view(kvs[oi].value, &orkvs, &orlen, &orcap);
                        break;
                    }
                }
            }
            for (int32_t i = 0; i < cap; i++) {
                if (janet_checktype(kvs[i].key, JANET_NIL)) continue;
                /* The `:or` defaults entry was consumed in the first
                 * pass; never bind it as a key. */
                if (NULL != orkvs &&
                        janet_checktype(kvs[i].key, JANET_KEYWORD) &&
                        !janet_cstrcmp(janet_unwrap_keyword(kvs[i].key), "or"))
                    continue;
                /* `:keys [a b]` shorthand: symbol S binds S from keyword
                 * :S; keyword :K binds its symbol form from :K. A
                 * non-sequential `:keys` value is a normal binding. */
                if (janet_checktype(kvs[i].key, JANET_KEYWORD) &&
                        !janet_cstrcmp(janet_unwrap_keyword(kvs[i].key), "keys") &&
                        (janet_checktype(kvs[i].value, JANET_TUPLE) ||
                         janet_checktype(kvs[i].value, JANET_ARRAY))) {
                    const Janet *names = NULL;
                    int32_t nlen = 0;
                    int32_t ni;
                    janet_indexed_view(kvs[i].value, &names, &nlen);
                    for (ni = 0; ni < nlen; ni++) {
                        const uint8_t *nb = NULL;
                        const uint8_t *kb = NULL;
                        Janet key;
                        if (janet_checktype(names[ni], JANET_SYMBOL)) {
                            nb = janet_unwrap_symbol(names[ni]);
                            kb = nb;
                        } else if (janet_checktype(names[ni], JANET_KEYWORD)) {
                            kb = janet_unwrap_keyword(names[ni]);
                            nb = kb;
                        } else {
                            janetc_error(c, janet_formatc("expected symbol or keyword in :keys vector, got %v", names[ni]));
                            return 1;
                        }
                        key = janet_keywordv(kb, janet_string_length(kb));
                        {
                            Janet bindpat = janet_wrap_symbol(janet_symbol(nb, janet_string_length(nb)));
                            JanetSlot nextright = janetc_farslot(c);
                            JanetSlot k = janetc_value(janetc_fopts_default(c), key);
                            Janet dflt = janet_wrap_nil();
                            int has_dflt = 0;
                            int32_t oj;
                            for (oj = 0; oj < orcap; oj++) {
                                if (janet_checktype(orkvs[oj].key, JANET_NIL)) continue;
                                if (destructure_key_bytes_equal(orkvs[oj].key, key)) {
                                    dflt = orkvs[oj].value;
                                    has_dflt = 1;
                                    break;
                                }
                            }
                            janetc_emit_sss(c, JOP_IN, nextright, right, k, 1);
                            if (has_dflt) {
                                int32_t lab = janetc_emit_si(c, JOP_JUMP_IF_NOT_NIL, nextright, 0, 0);
                                JanetSlot d = janetc_value(janetc_fopts_default(c), dflt);
                                janetc_copy(c, nextright, d);
                                {
                                    int32_t cur = janet_v_count(c->buffer);
                                    check_16bit_jump(c, lab, cur);
                                    c->buffer[lab] |= (uint32_t)(cur - lab) << 16;
                                }
                            }
                            c->recursion_guard--;
                            if (destructure(c, bindpat, nextright, leaf, attr))
                                janetc_freeslot(c, nextright);
                            c->recursion_guard++;
                        }
                    }
                    continue;
                }
                /* NOTE: no `:as` whole-binding: `{:as sym}` keeps its
                 * legacy meaning (bind `(get m :as)`), which the
                 * `import*` calling convention depends on
                 * (`(def {:as as :prefix prefix ...} kargs)`). A
                 * Clojure-style whole-binding would silently redefine
                 * every such use — caught by suite-array via broken
                 * imports. */
                {
                    JanetSlot nextright = janetc_farslot(c);
                    JanetSlot k = janetc_value(janetc_fopts_default(c), kvs[i].key);
                    Janet dflt = janet_wrap_nil();
                    int has_dflt = 0;
                    int32_t oj;
                    for (oj = 0; oj < orcap; oj++) {
                        if (janet_checktype(orkvs[oj].key, JANET_NIL)) continue;
                        if (destructure_key_bytes_equal(orkvs[oj].key, kvs[i].key)) {
                            dflt = orkvs[oj].value;
                            has_dflt = 1;
                            break;
                        }
                    }
                    janetc_emit_sss(c, JOP_IN, nextright, right, k, 1);
                    if (has_dflt) {
                        int32_t lab = janetc_emit_si(c, JOP_JUMP_IF_NOT_NIL, nextright, 0, 0);
                        JanetSlot d = janetc_value(janetc_fopts_default(c), dflt);
                        janetc_copy(c, nextright, d);
                        {
                            int32_t cur = janet_v_count(c->buffer);
                            check_16bit_jump(c, lab, cur);
                            c->buffer[lab] |= (uint32_t)(cur - lab) << 16;
                        }
                    }
                    c->recursion_guard--;
                    if (destructure(c, kvs[i].value, nextright, leaf, attr))
                        janetc_freeslot(c, nextright);
                    c->recursion_guard++;
                }
            }
        }
        return 1;
    }
}

/* Create a source map for definitions. */
static const Janet *janetc_make_sourcemap(JanetCompiler *c) {
    Janet *tup = janet_tuple_begin(3);
    tup[0] = c->source ? janet_wrap_string(c->source) : janet_wrap_nil();
    tup[1] = janet_wrap_integer(c->current_mapping.line);
    tup[2] = janet_wrap_integer(c->current_mapping.column);
    return janet_tuple_end(tup);
}

static JanetSlot janetc_varset(JanetFopts opts, int32_t argn, const Janet *argv) {
    if (argn != 2) {
        janetc_cerror(opts.compiler, "expected 2 arguments to set");
        return janetc_cslot(janet_wrap_nil());
    }
    JanetFopts subopts = janetc_fopts_default(opts.compiler);
    if (janet_checktype(argv[0], JANET_SYMBOL)) {
        /* Normal var - (set a 1) */
        const uint8_t *sym = janet_unwrap_symbol(argv[0]);
        JanetSlot dest = janetc_resolve(opts.compiler, sym);
        if (!(dest.flags & JANET_SLOT_MUTABLE)) {
            janetc_cerror(opts.compiler, "cannot set constant");
            return janetc_cslot(janet_wrap_nil());
        }
        subopts.flags = JANET_FOPTS_HINT;
        subopts.hint = dest;
        JanetSlot ret = janetc_value(subopts, argv[1]);
        janetc_copy(opts.compiler, dest, ret);
        return ret;
    } else if (janet_checktype(argv[0], JANET_TUPLE)) {
        /* Set a field (setf behavior) - (set (tab :key) 2) */
        const Janet *tup = janet_unwrap_tuple(argv[0]);
        /* Tuple must have 2 elements */
        if (janet_tuple_length(tup) != 2) {
            janetc_cerror(opts.compiler, "expected 2 element tuple for l-value to set");
            return janetc_cslot(janet_wrap_nil());
        }
        JanetSlot ds = janetc_value(subopts, tup[0]);
        JanetSlot key = janetc_value(subopts, tup[1]);
        /* Can't be tail position because we will emit a PUT instruction afterwards */
        /* Also can't drop either */
        opts.flags &= ~(JANET_FOPTS_TAIL | JANET_FOPTS_DROP);
        JanetSlot rvalue = janetc_value(opts, argv[1]);
        /* Emit the PUT instruction */
        janetc_emit_sss(opts.compiler, JOP_PUT, ds, key, rvalue, 0);
        return rvalue;
    } else {
        /* Error */
        janetc_cerror(opts.compiler, "expected symbol or tuple for l-value to set");
        return janetc_cslot(janet_wrap_nil());
    }
}

/* Add attributes to a global def or var table */
static JanetTable *handleattr(JanetCompiler *c, const char *kind, int32_t argn, const Janet *argv) {
    int32_t i;
    if (argn < 2) {
        janetc_error(c, janet_formatc("expected at least 2 arguments to %s", kind));
        return NULL;
    }
    JanetTable *tab = janet_table(2);
    /* Phase 2a root discipline: this table is held only in C locals across
     * dohead_destructure below, which compiles the bound value (arbitrary
     * code, allocations, collections, and -- since Phase 1.1 -- even
     * suspensions). Pin it for the rest of the compilation. */
    janetc_pin(c, janet_wrap_table(tab));
    const char *binding_name = janet_type(argv[0]) == JANET_SYMBOL
                               ? ((const char *)janet_unwrap_symbol(argv[0]))
                               : "<multiple bindings>";
    for (i = 1; i < argn - 1; i++) {
        Janet attr = argv[i];
        switch (janet_type(attr)) {
            case JANET_TUPLE:
                if (argn > 10) {
                    for (int32_t q = 0; q < argn; q++) {
                        JanetString dstr = janet_description(argv[q]);
                        janet_eprintf("  argv[%d] type=%d len=%d: ",
                                      (int) q, (int) janet_type(argv[q]),
                                      (int) janet_string_length(dstr));
                        for (int32_t w = 0; w < janet_string_length(dstr) && w < 70; w++) {
                            janet_eprintf("%c", (char) dstr[w]);
                        }
                        janet_eprintf("\n");
                    }
                }
                janetc_cerror(c, "unexpected form - did you intend to use defn?");
                break;
            default:
                janetc_error(c, janet_formatc("cannot add metadata %v to binding %s", attr, binding_name));
                break;
            case JANET_KEYWORD:
                janet_table_put(tab, attr, janet_wrap_true());
                break;
            case JANET_STRING:
                janet_table_put(tab, janet_ckeywordv("doc"), attr);
                break;
            case JANET_STRUCT:
                janet_table_merge_struct(tab, janet_unwrap_struct(attr));
                break;
        }
    }
    return tab;
}

typedef struct SlotHeadPair {
    Janet lhs;
    JanetSlot rhs;
} SlotHeadPair;

SlotHeadPair *dohead_destructure(JanetCompiler *c, SlotHeadPair *into, JanetFopts opts, Janet lhs, Janet rhs) {
    if (c->recursion_guard <= 0) {
        janetc_error(c, janet_cstring("C stack recursed too deeply"));
        return NULL;
    }
    /* Detect if we can do an optimization to avoid some allocations */
    int can_destructure_lhs = janet_checktype(lhs, JANET_TUPLE)
                              || janet_checktype(lhs, JANET_ARRAY);
    int rhs_is_indexed = janet_checktype(rhs, JANET_ARRAY)
                         || (janet_checktype(rhs, JANET_TUPLE) && (janet_tuple_flag(janet_unwrap_tuple(rhs)) & JANET_TUPLE_FLAG_BRACKETCTOR));
    uint32_t has_drop = opts.flags & JANET_FOPTS_DROP;

    JanetFopts subopts = janetc_fopts_default(c);
    subopts.flags = opts.flags & ~(JANET_FOPTS_TAIL | JANET_FOPTS_DROP);

    if (has_drop && can_destructure_lhs && rhs_is_indexed) {
        /* Code is of the form (def [a b] [1 2]), avoid the allocation of two tuples */
        JanetView view_lhs = {0};
        JanetView view_rhs = {0};
        janet_indexed_view(lhs, &view_lhs.items, &view_lhs.len);
        janet_indexed_view(rhs, &view_rhs.items, &view_rhs.len);
        int found_amp = 0;
        int found_splice = 0;
        /* Check for (def [x y z] [(splice [1 2 3]) 4 5 6]), bail out of optimization */
        for (int32_t i = 0; i < view_rhs.len; i++) {
            if (!janet_checktype(view_rhs.items[i], JANET_TUPLE)) {
                continue;
            }
            JanetTuple tup = janet_unwrap_tuple(view_rhs.items[i]);
            if (janet_tuple_length(tup) == 0) {
                continue;
            }
            if (janet_symeq(tup[0], "splice")) {
                found_splice = 1;
                /* Good error will be generated later. */
                break;
            }
        }
        /* Check for (def [x & more] [1 2 3]), bail out of optimization */
        for (int32_t i = 0; i < view_lhs.len; i++) {
            if (janet_symeq(view_lhs.items[i], "&")) {
                found_amp = 1;
                /* Good error will be generated later. */
                break;
            }
        }
        if (!found_amp && !found_splice) {
            for (int32_t i = 0; i < view_lhs.len; i++) {
                Janet sub_rhs = view_rhs.len <= i ? janet_wrap_nil() : view_rhs.items[i];
                c->recursion_guard--;
                into = dohead_destructure(c, into, subopts, view_lhs.items[i], sub_rhs);
                c->recursion_guard++;
            }
            return into;
        }
    }

    /* No optimization, do the simple way */
    subopts.hint = opts.hint;
    JanetSlot ret = janetc_value(subopts, rhs);
    SlotHeadPair shp = {lhs, ret};
    janet_v_push(into, shp);
    return into;
}

/* Def or var a symbol in a local scope */
static int namelocal(JanetCompiler *c, const uint8_t *head, int32_t flags, JanetSlot ret, uint32_t def_flags) {
    int isUnnamedRegister = !(ret.flags & JANET_SLOT_NAMED) &&
                            ret.index > 0 &&
                            ret.envindex >= 0;
    /* optimization for `(def x my-def)` - don't emit a movn/movf instruction, we can just alias my-def */
    /* TODO - implement optimization for `(def x my-var)` correctly as well w/ de-aliasing */
    int canAlias = !(flags & JANET_SLOT_MUTABLE) &&
                   !(ret.flags & JANET_SLOT_MUTABLE) &&
                   (ret.flags & JANET_SLOT_NAMED) &&
                   (ret.index >= 0) &&
                   (ret.envindex == -1);
    if (canAlias) {
        ret.flags &= ~JANET_SLOT_MUTABLE;
        isUnnamedRegister = 1; /* don't free slot after use - is an alias for another slot */
    } else if (!isUnnamedRegister) {
        /* Slot is not able to be named */
        JanetSlot localslot = janetc_farslot(c);
        janetc_copy(c, localslot, ret);
        ret = localslot;
    }
    ret.flags |= flags;
    if (c->scope->flags & JANET_SCOPE_TOP) {
        def_flags |= JANET_DEFFLAG_NO_UNUSED;
    }
    janetc_nameslot(c, head, ret, def_flags);
    return !isUnnamedRegister;
}

static int varleaf(
    JanetCompiler *c,
    const uint8_t *sym,
    JanetSlot s,
    JanetTable *reftab) {
    if (c->scope->flags & JANET_SCOPE_TOP) {
        /* Global var, generate var */
        JanetSlot refslot;
        JanetTable *entry = janet_table_clone(reftab);

        int is_redef = c->is_redef;

        JanetArray *ref;
        JanetBinding old_binding;
        if (is_redef && (old_binding = janet_resolve_ext(c->env, sym),
                         old_binding.type == JANET_BINDING_VAR)) {
            ref = janet_unwrap_array(old_binding.value);
        } else {
            ref = janet_array(1);
            janet_array_push(ref, janet_wrap_nil());
        }

        janet_table_put(entry, janet_ckeywordv("ref"), janet_wrap_array(ref));
        janet_table_put(entry, janet_ckeywordv("source-map"),
                        janet_wrap_tuple(janetc_make_sourcemap(c)));
        janet_table_put(c->env, janet_wrap_symbol(sym), janet_wrap_table(entry));
        refslot = janetc_cslot(janet_wrap_array(ref));
        janetc_emit_ssu(c, JOP_PUT_INDEX, refslot, s, 0, 0);
        return 1;
    } else {
        int no_unused = reftab && reftab->count && janet_truthy(janet_table_get_keyword(reftab, "unused"));
        int no_shadow = reftab && reftab->count && janet_truthy(janet_table_get_keyword(reftab, "shadow"));
        uint32_t def_flags = 0;
        if (no_unused) def_flags |= JANET_DEFFLAG_NO_UNUSED;
        if (no_shadow) def_flags |= JANET_DEFFLAG_NO_SHADOWCHECK;
        return namelocal(c, sym, JANET_SLOT_MUTABLE, s, def_flags);
    }
}

static void check_metadata_lint(JanetCompiler *c, JanetTable *attr_table) {
    if (!(c->scope->flags & JANET_SCOPE_TOP) && attr_table && attr_table->count) {
        /* A macro is a normal lint, other metadata is a strict lint */
        if (janet_truthy(janet_table_get_keyword(attr_table, "macro"))) {
            janetc_lintf(c, JANET_C_LINT_NORMAL, "macro tag is ignored in inner scopes");
        }
    }
}

static JanetSlot janetc_var(JanetFopts opts, int32_t argn, const Janet *argv) {
    JanetCompiler *c = opts.compiler;
    JanetTable *attr_table = handleattr(c, "var", argn, argv);
    if (c->result.status == JANET_COMPILE_ERROR) {
        return janetc_cslot(janet_wrap_nil());
    }
    check_metadata_lint(c, attr_table);
    SlotHeadPair *into = NULL;
    into = dohead_destructure(c, into, opts, argv[0], argv[argn - 1]);
    if (c->result.status == JANET_COMPILE_ERROR) {
        janet_v_free(into);
        return janetc_cslot(janet_wrap_nil());
    }
    JanetSlot ret = janetc_cslot(janet_wrap_nil());
    for (int32_t i = 0; i < janet_v_count(into); i++) {
        destructure(c, into[i].lhs, into[i].rhs, varleaf, attr_table);
        ret = into[i].rhs;
    }
    janet_v_free(into);
    return ret;
}

static int defleaf(
    JanetCompiler *c,
    const uint8_t *sym,
    JanetSlot s,
    JanetTable *tab) {
    JanetTable *entry = NULL;
    int is_redef = 0;
    if (c->scope->flags & JANET_SCOPE_TOP) {
        entry = janet_table_clone(tab);
        janet_table_put(entry, janet_ckeywordv("source-map"),
                        janet_wrap_tuple(janetc_make_sourcemap(c)));

        is_redef = c->is_redef;
        if (is_redef) janet_table_put(entry, janet_ckeywordv("redef"), janet_wrap_true());

        if (is_redef) {
            JanetBinding binding = janet_resolve_ext(c->env, sym);
            JanetArray *ref;
            if (binding.type == JANET_BINDING_DYNAMIC_DEF || binding.type == JANET_BINDING_DYNAMIC_MACRO) {
                ref = janet_unwrap_array(binding.value);
            } else {
                ref = janet_array(1);
                janet_array_push(ref, janet_wrap_nil());
            }
            janet_table_put(entry, janet_ckeywordv("ref"), janet_wrap_array(ref));
            JanetSlot refslot = janetc_cslot(janet_wrap_array(ref));
            janetc_emit_ssu(c, JOP_PUT_INDEX, refslot, s, 0, 0);
        } else {
            JanetSlot valsym = janetc_cslot(janet_ckeywordv("value"));
            JanetSlot tabslot = janetc_cslot(janet_wrap_table(entry));
            janetc_emit_sss(c, JOP_PUT, tabslot, valsym, s, 0);
        }
    }
    int no_unused = tab && tab->count && janet_truthy(janet_table_get_keyword(tab, "unused"));
    int no_shadow = is_redef || (tab && tab->count && janet_truthy(janet_table_get_keyword(tab, "shadow")));
    uint32_t def_flags = 0;
    if (no_unused) def_flags |= JANET_DEFFLAG_NO_UNUSED;
    if (no_shadow) def_flags |= JANET_DEFFLAG_NO_SHADOWCHECK;
    int result = namelocal(c, sym, 0, s, def_flags);
    if (entry) {
        /* Add env entry to env AFTER namelocal to avoid the shadowcheck false positive */
        janet_table_put(c->env, janet_wrap_symbol(sym), janet_wrap_table(entry));
    }
    return result;
}

static JanetSlot janetc_def(JanetFopts opts, int32_t argn, const Janet *argv) {
    JanetCompiler *c = opts.compiler;
    JanetTable *attr_table = handleattr(c, "def", argn, argv);
    if (c->result.status == JANET_COMPILE_ERROR) {
        return janetc_cslot(janet_wrap_nil());
    }
    check_metadata_lint(c, attr_table);
    /* The expanded binding metadata is authoritative. Only a direct named
     * function literal has a provable one-to-one child identity. */
    Janet hint = janet_table_get_keyword(attr_table, "hint");
    int hinted = janet_checktype(hint, JANET_TABLE) || janet_checktype(hint, JANET_STRUCT);
    Janet selections = janet_table_get_keyword(c->env, "analysis-retain-profiled-defs");
    Janet selected_line = janet_wrap_nil();
    if (c->retain_hinted_exports_for_analysis && janet_checktype(argv[0], JANET_SYMBOL) &&
        janet_checktype(selections, JANET_TABLE))
        selected_line = janet_table_get(janet_unwrap_table(selections), argv[0]);
    int profiled = janet_checkint(selected_line);
    /* Private hints are checked contracts too; profile selection remains
     * export-only, since private names are not stable module bindings. */
    int retain = c->retain_hinted_exports_for_analysis &&
                 (hinted || (profiled && !janet_truthy(janet_table_get_keyword(attr_table, "private"))));
    JanetScope *fn_scope = c->scope;
    while (fn_scope && !(fn_scope->flags & JANET_SCOPE_FUNCTION)) fn_scope = fn_scope->parent;
    int32_t defs_before = fn_scope ? janet_v_count(fn_scope->defs) : 0;
    int32_t code_before = janet_v_count(c->buffer);
    opts.flags &= ~JANET_FOPTS_HINT;
    SlotHeadPair *into = NULL;
    into = dohead_destructure(c, into, opts, argv[0], argv[argn - 1]);
    if (c->result.status == JANET_COMPILE_ERROR) {
        janet_v_free(into);
        return janetc_cslot(janet_wrap_nil());
    }
    /* ffi/defbind-alias adds {:ffi-alias true} metadata. Mark the direct
     * named function literal's FuncDef so calls compiled later can
     * recognize it without depending on any runtime registration. */
    if (janet_truthy(janet_table_get_keyword(attr_table, "ffi-alias")) &&
            fn_scope && janet_checktype(argv[0], JANET_SYMBOL) &&
            janet_v_count(into) == 1 &&
            janet_v_count(fn_scope->defs) == defs_before + 1) {
        Janet rhs = argv[argn - 1];
        if (janet_checktype(rhs, JANET_TUPLE)) {
            JanetTuple form = janet_unwrap_tuple(rhs);
            if (janet_tuple_length(form) >= 3 && janet_symeq(form[0], "fn") &&
                    janet_checktype(form[1], JANET_SYMBOL) &&
                    janet_equals(form[1], argv[0])) {
                fn_scope->defs[defs_before]->flags |= JANET_FUNCDEF_FLAG_FFI_ALIAS_DECL;
            }
        }
    }
    if (retain) {
        int matched = 0;
        JanetFuncDef *child = NULL;
        Janet rhs = argv[argn - 1];
        if (janet_checktype(argv[0], JANET_SYMBOL) && janet_checktype(rhs, JANET_TUPLE)) {
            JanetTuple form = janet_unwrap_tuple(rhs);
            if (janet_tuple_length(form) >= 3 && janet_symeq(form[0], "fn") &&
                janet_checktype(form[1], JANET_SYMBOL) &&
                janet_equals(form[1], argv[0]) &&
                janet_v_count(into) == 1 && fn_scope &&
                janet_v_count(fn_scope->defs) == defs_before + 1) {
                child = fn_scope->defs[defs_before];
                if (!child->name || !janet_equals(janet_wrap_string(child->name),
                                                   janet_wrap_string(janet_unwrap_symbol(argv[0]))))
                    child = NULL;
                for (int32_t pc = code_before; pc < janet_v_count(c->buffer); pc++) {
                    uint32_t op = c->buffer[pc];
                    if ((op & 0x7F) == JOP_CLOSURE && (op >> 16) == (uint32_t) defs_before &&
                        ((op >> 8) & 0xFF) == (uint32_t) into[0].rhs.index)
                        matched++;
                }
            }
        }
        if (matched == 1 && child && profiled &&
            (!child->sourcemap || child->bytecode_length == 0 ||
             child->sourcemap[0].line != janet_unwrap_integer(selected_line))) {
            profiled = 0;
            if (!hinted)
                janet_eprintf("analysis retention refused for profiled def %v: source line does not match child identity\n", argv[0]);
        }
        if (matched == 1 && child && (hinted || profiled)) {
            JanetRetainedDef entry = {fn_scope, NULL, child, hinted ? hint : janet_wrap_nil(), profiled};
            janet_v_push(c->retained_defs, entry);
        } else if (matched != 1 || !child) {
            janet_eprintf("analysis retention refused for %s def %v: cannot prove direct closure identity\n",
                          hinted ? "hinted" : "profiled", argv[0]);
        }
    }
    JanetSlot ret = janetc_cslot(janet_wrap_nil());
    for (int32_t i = 0; i < janet_v_count(into); i++) {
        destructure(c, into[i].lhs, into[i].rhs, defleaf, attr_table);
        ret = into[i].rhs;
    }
    janet_v_free(into);
    return ret;
}

/* Check if a form matches the pattern (= nil _) or (not= nil _) */
static int janetc_check_nil_form(Janet x, Janet *capture, uint32_t fun_tag) {
    if (!janet_checktype(x, JANET_TUPLE)) return 0;
    JanetTuple tup = janet_unwrap_tuple(x);
    if (3 != janet_tuple_length(tup)) return 0;
    Janet op1 = tup[0];
    if (!janet_checktype(op1, JANET_FUNCTION)) return 0;
    JanetFunction *fun = janet_unwrap_function(op1);
    uint32_t tag = fun->def->flags & JANET_FUNCDEF_FLAG_TAG;
    if (tag != fun_tag) return 0;
    if (janet_checktype(tup[1], JANET_NIL)) {
        *capture = tup[2];
        return 1;
    } else if (janet_checktype(tup[2], JANET_NIL)) {
        *capture = tup[1];
        return 1;
    }
    return 0;
}

/*
 * :condition
 * ...
 * jump-if-not condition :right
 * :left
 * ...
 * jump done (only if not tail)
 * :right
 * ...
 * :done
 */
static JanetSlot janetc_if(JanetFopts opts, int32_t argn, const Janet *argv) {
    JanetCompiler *c = opts.compiler;
    int32_t labelr, labeljr, labeld, labeljd;
    JanetFopts condopts, bodyopts;
    JanetSlot cond, left, right, target;
    Janet truebody, falsebody;
    JanetScope condscope, tempscope;
    const int tail = opts.flags & JANET_FOPTS_TAIL;
    const int drop = opts.flags & JANET_FOPTS_DROP;
    uint8_t ifnjmp = JOP_JUMP_IF_NOT;

    if (argn < 2 || argn > 3) {
        janetc_cerror(c, "expected 2 or 3 arguments to if");
        return janetc_cslot(janet_wrap_nil());
    }

    /* Get the bodies of the if expression */
    truebody = argv[1];
    falsebody = argn > 2 ? argv[2] : janet_wrap_nil();

    /* Get options */
    condopts = janetc_fopts_default(c);
    bodyopts = opts;
    bodyopts.flags &= ~JANET_FOPTS_ACCEPT_SPLICE;

    /* Set target for compilation */
    target = (drop || tail)
             ? janetc_cslot(janet_wrap_nil())
             : janetc_gettarget(opts);

    /* Compile condition */
    janetc_scope(&condscope, c, 0, "if");

    Janet condform = argv[0];
    if (janetc_check_nil_form(condform, &condform, JANET_FUN_EQ)) {
        ifnjmp = JOP_JUMP_IF_NOT_NIL;
    } else if (janetc_check_nil_form(condform, &condform, JANET_FUN_NEQ)) {
        ifnjmp = JOP_JUMP_IF_NIL;
    }

    cond = janetc_value(condopts, condform);

    /* Check constant condition. */
    /* TODO: Use type info for more short circuits */
    if (cond.flags & JANET_SLOT_CONSTANT) {
        int swap_condition = 0;
        if (ifnjmp == JOP_JUMP_IF_NOT && !janet_truthy(cond.constant)) swap_condition = 1;
        if (ifnjmp == JOP_JUMP_IF_NIL && janet_checktype(cond.constant, JANET_NIL)) swap_condition = 1;
        if (ifnjmp == JOP_JUMP_IF_NOT_NIL && !janet_checktype(cond.constant, JANET_NIL)) swap_condition = 1;
        if (swap_condition) {
            /* Swap the true and false bodies */
            Janet temp = falsebody;
            falsebody = truebody;
            truebody = temp;
        }
        janetc_scope(&tempscope, c, 0, "if-true");
        right = janetc_value(bodyopts, truebody);
        if (!drop && !tail) janetc_copy(c, target, right);
        janetc_popscope(c);
        if (!janet_checktype(falsebody, JANET_NIL)) {
            janetc_throwaway(bodyopts, falsebody);
        }
        janetc_popscope(c);
        return target;
    }

    /* Compile jump to right */
    labeljr = janetc_emit_si(c, ifnjmp, cond, 0, 0);

    /* Condition left body */
    janetc_scope(&tempscope, c, 0, "if-true");
    left = janetc_value(bodyopts, truebody);
    if (!drop && !tail) janetc_copy(c, target, left);
    janetc_popscope(c);

    /* Compile jump to done */
    labeljd = janet_v_count(c->buffer);
    if (!tail && !(drop && janet_checktype(falsebody, JANET_NIL))) janetc_emit(c, JOP_JUMP);

    /* Compile right body */
    labelr = janet_v_count(c->buffer);
    janetc_scope(&tempscope, c, 0, "if-false");
    right = janetc_value(bodyopts, falsebody);
    if (!drop && !tail) janetc_copy(c, target, right);
    janetc_popscope(c);

    /* Pop main scope */
    janetc_popscope(c);

    /* Write jumps - only add jump lengths if jump actually emitted */
    labeld = janet_v_count(c->buffer);
    if (labeljr < labeld) {
        check_16bit_jump(c, labeljr, labelr);
        c->buffer[labeljr] |= (uint32_t)(labelr - labeljr) << 16;
        if (!tail && labeljd < labeld) {
            check_24bit_jump(c, labeljd, labeld);
            c->buffer[labeljd] |= (uint32_t)(labeld - labeljd) << 8;
        }
    }

    if (tail) target.flags |= JANET_SLOT_RETURNED;
    return target;
}

/* Compile a do form. Do forms execute their body sequentially and
 * evaluate to the last expression in the body. */
static JanetSlot janetc_do(JanetFopts opts, int32_t argn, const Janet *argv) {
    int32_t i;
    JanetSlot ret = janetc_cslot(janet_wrap_nil());
    JanetCompiler *c = opts.compiler;
    JanetFopts subopts = janetc_fopts_default(c);
    JanetScope tempscope;
    janetc_scope(&tempscope, c, 0, "do");
    for (i = 0; i < argn; i++) {
        if (i != argn - 1) {
            subopts.flags = JANET_FOPTS_DROP;
        } else {
            subopts = opts;
            subopts.flags &= ~JANET_FOPTS_ACCEPT_SPLICE;
        }
        ret = janetc_value(subopts, argv[i]);
        if (i != argn - 1) {
            janetc_freeslot(c, ret);
        }
    }
    janetc_popscope_keepslot(c, ret);
    return ret;
}

/* Compile an upscope form. Upscope forms execute their body sequentially and
 * evaluate to the last expression in the body, but without lexical scope. */
static JanetSlot janetc_upscope(JanetFopts opts, int32_t argn, const Janet *argv) {
    int32_t i;
    JanetSlot ret = janetc_cslot(janet_wrap_nil());
    JanetCompiler *c = opts.compiler;
    JanetFopts subopts = janetc_fopts_default(c);
    for (i = 0; i < argn; i++) {
        if (i != argn - 1) {
            subopts.flags = JANET_FOPTS_DROP;
        } else {
            subopts = opts;
            subopts.flags &= ~JANET_FOPTS_ACCEPT_SPLICE;
        }
        ret = janetc_value(subopts, argv[i]);
        if (i != argn - 1) {
            janetc_freeslot(c, ret);
        }
    }
    return ret;
}

/* Add a funcdef to the top most function scope */
static int32_t janetc_addfuncdef(JanetCompiler *c, JanetFuncDef *def) {
    JanetScope *scope = c->scope;
    while (scope) {
        if (scope->flags & JANET_SCOPE_FUNCTION)
            break;
        scope = scope->parent;
    }
    janet_assert(scope, "could not add funcdef");
    janet_v_push(scope->defs, def);
    return janet_v_count(scope->defs) - 1;
}

/*
 * break
 *
 * jump :end or retn if in function
 */
static JanetSlot janetc_break(JanetFopts opts, int32_t argn, const Janet *argv) {
    JanetCompiler *c = opts.compiler;
    JanetScope *scope = c->scope;
    if (argn > 1) {
        janetc_cerror(c, "expected at most 1 argument");
        return janetc_cslot(janet_wrap_nil());
    }

    /* Find scope to break from */
    while (scope) {
        if (scope->flags & (JANET_SCOPE_FUNCTION | JANET_SCOPE_WHILE))
            break;
        scope = scope->parent;
    }
    if (NULL == scope) {
        janetc_cerror(c, "break must occur in while loop or closure");
        return janetc_cslot(janet_wrap_nil());
    }

    /* Emit code to break from that scope */
    JanetFopts subopts = janetc_fopts_default(c);
    if (scope->flags & JANET_SCOPE_FUNCTION) {
        if (!(scope->flags & JANET_SCOPE_WHILE) && argn) {
            /* Closure body with return argument */
            subopts.flags |= JANET_FOPTS_TAIL;
            janetc_value(subopts, argv[0]);
            return janetc_cslot(janet_wrap_nil());
        } else {
            /* while loop IIFE or no argument */
            if (argn) {
                subopts.flags |= JANET_FOPTS_DROP;
                janetc_value(subopts, argv[0]);
            }
            janetc_emit(c, JOP_RETURN_NIL);
            return janetc_cslot(janet_wrap_nil());
        }
    } else {
        if (argn) {
            subopts.flags |= JANET_FOPTS_DROP;
            janetc_value(subopts, argv[0]);
        }
        /* Tag the instruction so the while special can turn it into a proper jump */
        janetc_emit(c, 0x80 | JOP_JUMP);
        return janetc_cslot(janet_wrap_nil());
    }
}

/*
 * :whiletop
 * ...
 * :condition
 * jump-if-not cond :done
 * ...
 * jump :whiletop
 * :done
 */
static JanetSlot janetc_while(JanetFopts opts, int32_t argn, const Janet *argv) {
    JanetCompiler *c = opts.compiler;
    JanetSlot cond;
    JanetFopts subopts = janetc_fopts_default(c);
    JanetScope tempscope;
    int32_t labelwt, labeld, labeljt, labelc, i;
    int infinite = 0;
    int is_nil_form = 0;
    int is_notnil_form = 0;
    uint8_t ifjmp = JOP_JUMP_IF;
    uint8_t ifnjmp = JOP_JUMP_IF_NOT;

    if (argn < 1) {
        janetc_cerror(c, "expected at least 1 argument to while");
        return janetc_cslot(janet_wrap_nil());
    }

    labelwt = janet_v_count(c->buffer);

    janetc_scope(&tempscope, c, JANET_SCOPE_WHILE, "while");

    /* Check for `(= nil _)` or `(not= nil _)` in condition, and if so, use the
     * jmpnl or jmpnn instructions. This let's us implement `(each ...)`
     * more efficiently. */
    Janet condform = argv[0];
    if (janetc_check_nil_form(condform, &condform, JANET_FUN_EQ)) {
        is_nil_form = 1;
        ifjmp = JOP_JUMP_IF_NIL;
        ifnjmp = JOP_JUMP_IF_NOT_NIL;
    }
    if (janetc_check_nil_form(condform, &condform, JANET_FUN_NEQ)) {
        is_notnil_form = 1;
        ifjmp = JOP_JUMP_IF_NOT_NIL;
        ifnjmp = JOP_JUMP_IF_NIL;
    }

    /* Compile condition */
    cond = janetc_value(subopts, condform);

    /* Check for constant condition */
    if (cond.flags & JANET_SLOT_CONSTANT) {
        /* Loop never executes */
        int never_executes = is_nil_form
                             ? !janet_checktype(cond.constant, JANET_NIL)
                             : is_notnil_form
                             ? janet_checktype(cond.constant, JANET_NIL)
                             : !janet_truthy(cond.constant);
        if (never_executes) {
            janetc_popscope(c);
            return janetc_cslot(janet_wrap_nil());
        }
        /* Infinite loop */
        infinite = 1;
    }

    /* Infinite loop does not need to check condition */
    labelc = infinite
             ? 0
             : janetc_emit_si(c, ifnjmp, cond, 0, 0);

    /* Compile body */
    for (i = 1; i < argn; i++) {
        subopts.flags = JANET_FOPTS_DROP;
        janetc_freeslot(c, janetc_value(subopts, argv[i]));
    }

    /* Check if closure created in while scope. If so,
     * recompile in a function scope. */
    if (tempscope.flags & JANET_SCOPE_CLOSURE) {
        subopts = janetc_fopts_default(c);
        tempscope.flags |= JANET_SCOPE_UNUSED;
        janetc_popscope(c);
        if (c->buffer) janet_v__cnt(c->buffer) = labelwt;
        if (c->mapbuffer) janet_v__cnt(c->mapbuffer) = labelwt;

        janetc_scope(&tempscope, c, JANET_SCOPE_FUNCTION, "while-iife");

        /* Recompile in the function scope */
        cond = janetc_value(subopts, condform);
        if (!(cond.flags & JANET_SLOT_CONSTANT)) {
            /* If not an infinite loop, return nil when condition false */
            janetc_emit_si(c, ifjmp, cond, 2, 0);
            janetc_emit(c, JOP_RETURN_NIL);
        }
        for (i = 1; i < argn; i++) {
            subopts.flags = JANET_FOPTS_DROP;
            janetc_freeslot(c, janetc_value(subopts, argv[i]));
        }
        /* But now add tail recursion */
        int32_t tempself = janetc_regalloc_temp(&tempscope.ra, JANETC_REGTEMP_0);
        janetc_emit(c, JOP_LOAD_SELF | ((uint32_t) tempself << 8));
        janetc_emit(c, JOP_TAILCALL | ((uint32_t) tempself << 8));
        janetc_regalloc_freetemp(&c->scope->ra, tempself, JANETC_REGTEMP_0);
        /* Compile function */
        JanetFuncDef *def = janetc_pop_funcdef(c, janet_cstring("while"));
        janet_def_addflags(def);
        int32_t defindex = janetc_addfuncdef(c, def);
        /* Do basic optimization */
        if (!(c->scope->flags & JANET_SCOPE_UNUSED)) {
            janetc_optimize_funcdef(c, def);
        }
        /* And then load the closure and call it. */
        int32_t cloreg = janetc_regalloc_temp(&c->scope->ra, JANETC_REGTEMP_0);
        janetc_emit(c, JOP_CLOSURE | ((uint32_t) cloreg << 8) | ((uint32_t) defindex << 16));
        janetc_emit(c, JOP_CALL | ((uint32_t) cloreg << 8) | ((uint32_t) cloreg << 16));
        janetc_regalloc_freetemp(&c->scope->ra, cloreg, JANETC_REGTEMP_0);
        c->scope->flags |= JANET_SCOPE_CLOSURE;
        return janetc_cslot(janet_wrap_nil());
    }

    /* Compile jump to :whiletop */
    labeljt = janet_v_count(c->buffer);
    janetc_emit(c, JOP_JUMP);

    /* Calculate jumps */
    labeld = janet_v_count(c->buffer);
    if (!infinite) {
        check_16bit_jump(c, labelc, labeld);
        c->buffer[labelc] |= (uint32_t)(labeld - labelc) << 16;
    }

    check_24bit_jump(c, labeljt, labelwt);
    c->buffer[labeljt] |= (uint32_t)(labelwt - labeljt) << 8;

    /* Calculate breaks */
    for (int32_t i = labelwt; i < labeld; i++) {
        if (c->buffer[i] == (0x80 | JOP_JUMP)) {
            check_24bit_jump(c, i, labeld);
            c->buffer[i] = JOP_JUMP | ((uint32_t)(labeld - i) << 8);
        }
    }

    /* Pop scope and return nil slot */
    janetc_popscope(c);

    return janetc_cslot(janet_wrap_nil());
}

static JanetSlot janetc_fn(JanetFopts opts, int32_t argn, const Janet *argv) {
    JanetCompiler *c = opts.compiler;
    JanetFuncDef *def;
    JanetSlot ret;
    Janet head;
    JanetScope fnscope;
    int32_t paramcount, argi, parami, arity, min_arity = 0, max_arity, defindex, i;
    JanetFopts subopts = janetc_fopts_default(c);
    const Janet *params;
    const char *errmsg = NULL;

    /* Function flags */
    int vararg = 0;
    int structarg = 0;
    int allow_extra = 0;
    int selfref = 0;
    int hasname = 0;
    int seenamp = 0;
    int seenopt = 0;
    int namedargs = 0;

    /* Begin function */
    c->scope->flags |= JANET_SCOPE_CLOSURE;
    janetc_scope(&fnscope, c, JANET_SCOPE_FUNCTION, "function");

    if (argn == 0) {
        errmsg = "expected at least 1 argument to function literal";
        goto error;
    }

    /* Read function parameters */
    parami = 0;
    head = argv[0];
    if (janet_checktype(head, JANET_SYMBOL)) {
        selfref = 1;
        hasname = 1;
        parami = 1;
    } else if (janet_checktype(head, JANET_KEYWORD)) {
        hasname = 1;
        parami = 1;
    }
    if (parami >= argn || !janet_checktype(argv[parami], JANET_TUPLE)) {
        errmsg = "expected function parameters";
        goto error;
    }

    /* Keep track of destructured parameters */
    JanetSlot *destructed_params = NULL;
    JanetSlot *named_params = NULL;
    JanetTable *named_table = NULL;
    JanetSlot named_slot;

    /* Compile function parameters */
    params = janet_unwrap_tuple(argv[parami]);
    paramcount = janet_tuple_length(params);
    arity = paramcount;
    for (i = 0; i < paramcount; i++) {
        Janet param = params[i];
        if (namedargs) {
            arity--;
            if (!janet_checktype(param, JANET_SYMBOL)) {
                errmsg = "only named arguments can follow &named";
                goto error;
            }
            Janet key = janet_wrap_keyword(janet_unwrap_symbol(param));
            janet_table_put(named_table, key, param);
            janet_v_push(named_params, janetc_farslot(c));
        } else if (janet_checktype(param, JANET_SYMBOL)) {
            /* Check for varargs and unfixed arity */
            const uint8_t *sym = janet_unwrap_symbol(param);
            if (sym[0] == '^') {
                /* Type hints belong on defn (^type before a parameter),
                 * which strips them before the fn special ever sees the
                 * arglist. A raw fn with ^ params would otherwise bind
                 * the hint as a parameter and silently change arity. */
                errmsg = "parameter names cannot start with ^ (type hints belong on defn)";
                goto error;
            }
            if (sym[0] == '&') {
                if (!janet_cstrcmp(sym, "&")) {
                    if (seenamp) {
                        errmsg = "& in unexpected location";
                        goto error;
                    } else if (i == paramcount - 1) {
                        allow_extra = 1;
                        arity--;
                    } else if (i == paramcount - 2) {
                        vararg = 1;
                        arity -= 2;
                    } else {
                        errmsg = "& in unexpected location";
                        goto error;
                    }
                    seenamp = 1;
                } else if (!janet_cstrcmp(sym, "&opt")) {
                    if (seenopt) {
                        errmsg = "only one &opt allowed";
                        goto error;
                    } else if (i == paramcount - 1) {
                        errmsg = "&opt cannot be last item in parameter list";
                        goto error;
                    }
                    min_arity = i;
                    arity--;
                    seenopt = 1;
                } else if (!janet_cstrcmp(sym, "&keys")) {
                    if (seenamp) {
                        errmsg = "&keys in unexpected location";
                        goto error;
                    } else if (i == paramcount - 2) {
                        vararg = 1;
                        structarg = 1;
                        arity -= 2;
                    } else {
                        errmsg = "&keys in unexpected location";
                        goto error;
                    }
                    seenamp = 1;
                } else if (!janet_cstrcmp(sym, "&named")) {
                    if (seenamp) {
                        errmsg = "&named in unexpected location";
                        goto error;
                    }
                    vararg = 1;
                    structarg = 1;
                    arity--;
                    seenamp = 1;
                    namedargs = 1;
                    named_table = janet_table(10);
                    named_slot = janetc_farslot(c);
                } else {
                    janetc_nameslot(c, sym, janetc_farslot(c), 0);
                }
            } else {
                janetc_nameslot(c, sym, janetc_farslot(c), 0);
            }
        } else {
            janet_v_push(destructed_params, janetc_farslot(c));
        }
    }

    /* Compile named arguments */
    if (namedargs) {
        Janet param = janet_wrap_table(named_table);
        destructure(c, param, named_slot, defleaf, NULL);
        janetc_freeslot(c, named_slot);
        janet_v_free(named_params);
    }

    /* Compile destructed params */
    int32_t j = 0;
    for (i = 0; i < paramcount; i++) {
        Janet param = params[i];
        if (!janet_checktype(param, JANET_SYMBOL)) {
            janet_assert(janet_v_count(destructed_params) > j, "out of bounds");
            JanetSlot reg = destructed_params[j++];
            destructure(c, param, reg, defleaf, NULL);
            janetc_freeslot(c, reg);
        }
    }
    janet_v_free(destructed_params);

    max_arity = (vararg || allow_extra) ? INT32_MAX : arity;
    if (!seenopt) min_arity = arity;

    /* Check for self ref (also avoid if arguments shadow own name) */
    if (selfref) {
        /* Check if the parameters shadow the function name. If so, don't
         * emit JOP_LOAD_SELF and add a binding since that most users
         * seem to expect that function parameters take precedence over the
         * function name */
        const uint8_t *sym = janet_unwrap_symbol(head);
        int32_t len = janet_v_count(c->scope->syms);
        int found = 0;
        for (int32_t i = 0; i < len; i++) {
            if (c->scope->syms[i].sym == sym) {
                found = 1;
            }
        }
        if (!found) {
            JanetSlot slot = janetc_farslot(c);
            slot.flags = JANET_SLOT_NAMED | JANET_FUNCTION;
            janetc_emit_s(c, JOP_LOAD_SELF, slot, 1);
            /* We should figure out a better way to avoid `(def x 1) (def x :shadow (fn x [...] ...))` triggering a
             * shadow lint for the last x */
            janetc_nameslot(c, sym, slot, JANET_DEFFLAG_NO_UNUSED | JANET_DEFFLAG_NO_SHADOWCHECK);
        }
    }

    /* Compile function body */
    if (parami + 1 == argn) {
        janetc_emit(c, JOP_RETURN_NIL);
    } else {
        for (argi = parami + 1; argi < argn; argi++) {
            subopts.flags = (argi == (argn - 1)) ? JANET_FOPTS_TAIL : JANET_FOPTS_DROP;
            janetc_value(subopts, argv[argi]);
            if (c->result.status == JANET_COMPILE_ERROR)
                goto error2;
        }
    }

    /* Build function */
    JanetString name = hasname ? janet_unwrap_symbol(head) : NULL;
    def = janetc_pop_funcdef(c, name);
    def->arity = arity;
    def->min_arity = min_arity;
    def->max_arity = max_arity;
    if (named_table != NULL) {
        def->named_args_count = named_table->count;
    }
    if (vararg) def->flags |= JANET_FUNCDEF_FLAG_VARARG;
    if (structarg) def->flags |= JANET_FUNCDEF_FLAG_STRUCTARG;
    if (namedargs) def->flags |= JANET_FUNCDEF_FLAG_NAMEDARGS;

    janet_def_addflags(def);
    defindex = janetc_addfuncdef(c, def);

    /* Ensure enough slots for vararg function. */
    if (arity + vararg > def->slotcount) def->slotcount = arity + vararg;

    /* Do basic optimization */
    if (!(fnscope.flags & JANET_SCOPE_UNUSED)) {
        janetc_optimize_funcdef(c, def);
    }

    /* Instantiate closure */
    ret = janetc_gettarget(opts);
    janetc_emit_su(c, JOP_CLOSURE, ret, defindex, 1);
    return ret;

error:
    janetc_cerror(c, errmsg);
error2:
    janetc_popscope(c);
    return janetc_cslot(janet_wrap_nil());
}

/* Keep in lexicographic order */
static const JanetSpecial janetc_specials[] = {
    {"break", janetc_break},
    {"def", janetc_def},
    {"do", janetc_do},
    {"fn", janetc_fn},
    {"if", janetc_if},
    {"quasiquote", janetc_quasiquote},
    {"quote", janetc_quote},
    {"set", janetc_varset},
    {"splice", janetc_splice},
    {"unquote", janetc_unquote},
    {"upscope", janetc_upscope},
    {"var", janetc_var},
    {"while", janetc_while}
};

/* Find a special */
const JanetSpecial *janetc_special(const uint8_t *name) {
    return janet_strbinsearch(
               &janetc_specials,
               sizeof(janetc_specials) / sizeof(JanetSpecial),
               sizeof(JanetSpecial),
               name);
}
