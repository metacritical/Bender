/*
* Copyright (c) 2026 Calvin Rose
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to
* deal in the Software without restriction, including without limitation the
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
* sell copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
*/

#ifndef JANET_AMALG
#include "features.h"
#include <janet.h>
#include "fiber.h"
#include "state.h"
#include "gc.h"
#include "util.h"
#endif

#ifndef JANET_WINDOWS
#include <sys/mman.h>
#include <signal.h>
#include <pthread.h>
#include <unistd.h>
#endif

/* AddressSanitizer detection: GCC defines __SANITIZE_ADDRESS__, clang
 * does not — clang only offers __has_feature(address_sanitizer). The
 * grow-on-fault machinery (SIGSEGV handler + malloc'd sigaltstack)
 * conflicts with ASAN's own signal and allocator machinery, so it is
 * compiled out under either sanitizer flavor. */
#if defined(__SANITIZE_ADDRESS__)
#  define JANET_ASAN 1
#elif defined(__has_feature)
#  if __has_feature(address_sanitizer)
#    define JANET_ASAN 1
#  endif
#endif

/* Stack size for a fiber's native C stack. The fibers here back VM frames
 * (as of Phase 1 the VM values live in fiber->data, so this serves the C
 * calls made while running a fiber -- cfuns, janet_call children, ev), so
 * it can be substantially larger than the 256 KB a generated-code fiber uses
 * code with tight -O2 frames. */
#ifndef JANET_FIBER_STACK_BYTES
#define JANET_FIBER_STACK_BYTES (2 * 1024 * 1024)
#endif
/* Guard size, fully locked behind the usable region. */
#ifndef JANET_FIBER_GUARD_BYTES
#define JANET_FIBER_GUARD_BYTES (64 * 1024)
#endif
/* Phase D (segmented growth): reserve the full window up front but commit
 * only this much initially, extending downward in CHUNK steps on guard
 * faults. Both must stay multiples of any supported page size (4K/16K). */
#ifndef JANET_FIBER_STACK_INIT_BYTES
#define JANET_FIBER_STACK_INIT_BYTES (64 * 1024)
#endif
#ifndef JANET_FIBER_STACK_GROW_BYTES
#define JANET_FIBER_STACK_GROW_BYTES (64 * 1024)
#endif

#ifdef JANET_WINDOWS
/* Flat malloc there, so init is a no-op (growth needs reserved address
 * space + fault interception; a VEH follow-up could add it). */
void janet_fiber_growstack_init(void) {}
#endif

/* Phase D: grow-on-fault for fiber native stacks (POSIX only; Windows
 * keeps the flat malloc, ucontext keeps its fixed makecontext region —
 * growth is transparent to both switchers since stacks extend downward
 * and the saved sp never moves).
 *
 * Layout: [mapping base][red zone: guard, PROT_NONE, forever][usable:
 * reserved PROT_NONE, committed top-down from INIT in CHUNK steps].
 * A fault anywhere in the uncommitted usable window commits down to
 * (and including) the faulting chunk and resumes; the faulting
 * instruction retries transparently. Single-step growth would miss
 * large single-frame jumps (deep GC/mark chains can move sp a long
 * way at once), so the commit target derives from the fault address
 * itself, rounded down to a chunk. A fault in the red zone is overflow
 * (slice 1: identified abort; catchable errors are the D3 follow-up).
 * Anything else chains to the previously installed action (ASan, user
 * os/sigaction handlers). macOS delivers below-mapping faults as
 * SIGBUS, so both signals are handled with the same logic; Linux
 * delivers both as SIGSEGV (the SIGBUS registration is harmless).
 *
 * Only async-safe operations run in the handler (plain reads, mprotect,
 * write); no locks, no allocation. The faulting thread's running fiber
 * (janet_vm.fiber) identifies the mapping — no global registry needed.
 * A stale fiber pointer on host code can only over-commit (harmless) or
 * mislabel a genuine crash (still dies). Installing our own SIGSEGV
 * handler via os/sigaction later replaces growth (documented). */

#ifndef JANET_WINDOWS
#ifndef JANET_NO_GROWSTACK

static struct sigaction janet_growstack_oldact;
static volatile JanetAtomicInt janet_growstack_installed = 0;
static JANET_THREAD_LOCAL int janet_growstack_alt_ok = 0;

/* fork() keeps the handler disposition but (on some systems, notably
 * macOS) resets the signal stack to SS_DISABLE in the child, and all
 * threads but the forking one vanish. Reinstall a working alt stack
 * right here so forked children keep grow-on-fault transparently (the
 * parent's alt-stack mapping is inherited but no longer registered;
 * leaking its registration is virtual-only). Runs in normal context,
 * so malloc is fine. */
static void janet_growstack_atfork_child(void) {
#ifndef JANET_ASAN
    size_t alt_size = 256 * 1024;
    void *alt_stack = malloc(alt_size);
    if (NULL != alt_stack) {
        stack_t ss;
        ss.ss_sp = alt_stack;
        ss.ss_size = alt_size;
        ss.ss_flags = 0;
        if (0 == sigaltstack(&ss, NULL)) {
            janet_growstack_alt_ok = 1;
        } else {
            free(alt_stack);
        }
    }
#else
    (void) 0;
#endif
}

static void janet_growstack_segv(int sig, siginfo_t *info, void *uctx) {
    (void) uctx;
    JanetFiber *fiber = janet_vm.fiber;
    void *fault = (NULL != info) ? info->si_addr : NULL;
    /* P3.6: resolve the faulting windows from the private mapping or,
     * for shared-stack fibers, the lane mapping (attributed to the
     * running fiber — only one runs per thread). Committed write-back
     * goes to the matching owner below. */
    char *base = NULL;
    char *usable = NULL;
    char *committed = NULL;
    int is_shared = 0;
    if (NULL != fiber && NULL != fault) {
        if (fiber->shared_stack && NULL != janet_vm.shared_stack_base &&
                NULL != janet_vm.shared_stack_committed) {
            base = (char *) janet_vm.shared_stack_base;
            usable = (char *) janet_vm.shared_stack;
            committed = (char *) janet_vm.shared_stack_committed;
            is_shared = 1;
        } else if (NULL != fiber->native_stack_base &&
                NULL != fiber->native_stack_committed) {
            base = (char *) fiber->native_stack_base;
            usable = (char *) fiber->native_stack;
            committed = (char *) fiber->native_stack_committed;
        }
    }
    if (NULL != base) {
        char *f = (char *) fault;
        size_t chunk = (size_t) JANET_FIBER_STACK_GROW_BYTES;
        if (f >= usable && f < committed) {
            /* Growth fault anywhere in the uncommitted window: commit
             * down to the faulting chunk (jump-proof) and resume. */
            uintptr_t off = (uintptr_t) (f - usable);
            char *target = usable + (off / chunk) * chunk;
            size_t len = (size_t) (committed - target);
            if (0 == mprotect(target, len, PROT_READ | PROT_WRITE)) {
                if (is_shared) janet_vm.shared_stack_committed = target;
                else fiber->native_stack_committed = target;
                return;
            }
            /* Commit failed: fall through and die below. */
        } else if (f >= base && f < usable) {
            /* Red-zone entry (Phase D3): commit down to the faulting
             * chunk the same way (bounded by the mapping base) and arm
             * the overflow flag; a call-path poll converts it to a
             * catchable error and clears it. Repeated entries consume
             * the red zone progressively, so straight-line descents
             * without polls still terminate at the base instead of
             * livelocking. Shared fibers get the identical treatment
             * (flag is per-fiber). */
            uintptr_t off = (uintptr_t) (f - base);
            char *target = base + (off / chunk) * chunk;
            size_t len = (size_t) (committed - target);
            fiber->stack_overflowed = 1;
            if (len > 0 && 0 == mprotect(target, len, PROT_READ | PROT_WRITE)) {
                if (is_shared) janet_vm.shared_stack_committed = target;
                else fiber->native_stack_committed = target;
                return;
            }
            /* Nothing left (or commit failed): fall through and die. */
        } else if (NULL != fiber && f < base &&
                committed == base) {
            /* Below a fully consumed mapping: our overflow, out of red
             * space. Name it, then die via the old action. */
            static const char msg[] = "janet: fiber native stack overflow\n";
            (void) write(STDERR_FILENO, msg, sizeof(msg) - 1);
        } else {
            goto chain;
        }
    } else {
        goto chain;
    }
chain:
    if (janet_growstack_oldact.sa_flags & SA_SIGINFO) {
        if (NULL != janet_growstack_oldact.sa_sigaction) {
            janet_growstack_oldact.sa_sigaction(sig, info, uctx);
            return;
        }
    } else if (janet_growstack_oldact.sa_handler == SIG_DFL) {
        signal(sig, SIG_DFL);
        raise(sig);
        return;
    } else if (janet_growstack_oldact.sa_handler == SIG_IGN) {
        return;
    } else if (NULL != janet_growstack_oldact.sa_handler) {
        janet_growstack_oldact.sa_handler(sig);
        return;
    }
    signal(sig, SIG_DFL);
    raise(sig);
}

/* Process-once handler install + per-thread alternate stack. Called
 * from janet_init (every VM thread). The alt stack is one-time-per-
 * thread virtual (untouched pages cost no RSS); threads without a VM
 * simply chain. */
void janet_fiber_growstack_init(void) {
    if (1 == janet_atomic_inc(&janet_growstack_installed)) {
        struct sigaction act;
        memset(&act, 0, sizeof(act));
        act.sa_sigaction = janet_growstack_segv;
        sigemptyset(&act.sa_mask);
        act.sa_flags = SA_SIGINFO | SA_ONSTACK;
        sigaction(SIGSEGV, &act, &janet_growstack_oldact);
        /* macOS delivers below-mapping faults as SIGBUS: same handler.
         * Harmless on Linux (never fires there for our mappings). */
        sigaction(SIGBUS, &act, NULL);
        pthread_atfork(NULL, NULL, janet_growstack_atfork_child);
    }
    if (!janet_growstack_alt_ok) {
        /* Roomy: chained handlers (ASan) also run here. Skipped under
         * AddressSanitizer: its allocator CHECK-fails deallocating
         * around these mappings (suite-ev), and ASan prints its own
         * fault reports anyway. Growth still works without one (the
         * faulting sp stays in committed space); only the identified-
         * overflow message may be lost when sp is wild. */
#ifndef JANET_ASAN
        size_t alt_size = 256 * 1024;
        void *alt_stack = malloc(alt_size);
        if (NULL != alt_stack) {
            stack_t ss;
            ss.ss_sp = alt_stack;
            ss.ss_size = alt_size;
            ss.ss_flags = 0;
            if (0 == sigaltstack(&ss, NULL)) {
                janet_growstack_alt_ok = 1;
            } else {
                free(alt_stack);
            }
        }
#endif
    }
}

#endif /* JANET_NO_GROWSTACK */
#endif /* !JANET_WINDOWS */

/* Reserve the full guard+usable window PROT_NONE; commit the top
 * window (all of it under JANET_NO_GROWSTACK, INIT bytes otherwise —
 * the rest arrives on guard faults). Reports the mapping size, the
 * page-aligned guard, and the lowest committed address. */
static void *fiber_native_stack_alloc(size_t *out_total, size_t *out_guard, void **out_committed) {
#ifdef JANET_WINDOWS
    size_t total = JANET_FIBER_STACK_BYTES;
    void *p = malloc(total);
    if (NULL == p) JANET_OUT_OF_MEMORY;
    *out_total = total;
    *out_guard = 0;
    *out_committed = p;
    return p;
#else
    long page = sysconf(_SC_PAGESIZE);
    if (page <= 0) page = 4096;
    size_t guard = ((size_t)JANET_FIBER_GUARD_BYTES + (size_t)page - 1) /
                   (size_t)page * (size_t)page;
    size_t total = guard + JANET_FIBER_STACK_BYTES;
    void *p = mmap(NULL, total, PROT_NONE, MAP_PRIVATE | MAP_ANON, -1, 0);
    if (MAP_FAILED == p) JANET_OUT_OF_MEMORY;
#ifdef JANET_NO_GROWSTACK
    size_t commit = JANET_FIBER_STACK_BYTES;
#else
    size_t commit = JANET_FIBER_STACK_INIT_BYTES;
    if (commit > JANET_FIBER_STACK_BYTES) commit = JANET_FIBER_STACK_BYTES;
#endif
    if (mprotect((char *)p + total - commit, commit,
                 PROT_READ | PROT_WRITE)) {
        munmap(p, total);
        JANET_OUT_OF_MEMORY;
    }
    *out_total = total;
    *out_guard = guard;
    *out_committed = (char *)p + total - commit;
    return p;
#endif
}

void janet_fiber_native_stack_free(JanetFiber *fiber) {
    if (fiber->native_stack_base) {
        /* Never unmap the stack we are currently executing on. This happens
         * at interpreter shutdown: janet_deinit -> janet_clear_memory frees
         * every fiber, but deinit itself runs inside a fiber (e.g. via
         * (os/exit) from a script). Leaking that one mapping is safe --
         * the process is exiting (and for embedders that re-init, it is
         * one stack mapping per deinit). */
        if (fiber == janet_vm.fiber) {
            fiber->native_stack_base = NULL;
            fiber->native_stack = NULL;
            fiber->native_stack_size = 0;
            fiber->native_stack_committed = NULL;
            return;
        }
#ifdef JANET_WINDOWS
        free(fiber->native_stack_base);
#else
        /* native_stack_size is the total mapping size (guard + usable). */
        munmap(fiber->native_stack_base, fiber->native_stack_size);
#endif
        fiber->native_stack_base = NULL;
        fiber->native_stack = NULL;
        fiber->native_stack_size = 0;
        fiber->native_stack_committed = NULL;
    }
}

/* Portable coroutine context switch for native-stack fibers.
 *
 * On x86_64/aarch64 we use a tiny cooperative register switch written as
 * file-scope inline asm; it lands in .text (W^X-safe), saves only the
 * callee-saved registers + stack pointer, and makes no syscalls. The whole
 * "machine context" is the saved stack pointer: every other piece of state
 * lives on the coroutine's own stack. Other architectures fall back to
 * <ucontext.h> swapcontext. */
#if defined(__x86_64__) || defined(__aarch64__)
#if defined(__APPLE__)
  #define JANET_CTX_SYM "_janet_fiber_ctx_swap"
#else
  #define JANET_CTX_SYM "janet_fiber_ctx_swap"
#endif
/* P3.6 lazy mapping: re-prime helper, declared early for reset. */
static void janet_fiber_reprime(JanetFiber *fiber);
#if defined(__x86_64__)
__asm__(
  ".text\n"
  ".globl " JANET_CTX_SYM "\n"
  JANET_CTX_SYM ":\n"
  "  pushq %rbp\n  pushq %rbx\n  pushq %r12\n  pushq %r13\n  pushq %r14\n  pushq %r15\n"
  "  movq %rsp, (%rdi)\n"
  "  movq (%rsi), %rsp\n"
  "  popq %r15\n  popq %r14\n  popq %r13\n  popq %r12\n  popq %rbx\n  popq %rbp\n"
  "  ret\n"
);
#else
__asm__(
  ".text\n"
  ".globl " JANET_CTX_SYM "\n"
  JANET_CTX_SYM ":\n"
  "  stp x19, x20, [sp, #-160]!\n"
  "  stp x21, x22, [sp, #16]\n"
  "  stp x23, x24, [sp, #32]\n"
  "  stp x25, x26, [sp, #48]\n"
  "  stp x27, x28, [sp, #64]\n"
  "  stp x29, x30, [sp, #80]\n"
  "  stp d8,  d9,  [sp, #96]\n"
  "  stp d10, d11, [sp, #112]\n"
  "  stp d12, d13, [sp, #128]\n"
  "  stp d14, d15, [sp, #144]\n"
  "  mov x2, sp\n"
  "  str x2, [x0]\n"
  "  ldr x2, [x1]\n"
  "  mov sp, x2\n"
  "  ldp d14, d15, [sp, #144]\n"
  "  ldp d12, d13, [sp, #128]\n"
  "  ldp d10, d11, [sp, #112]\n"
  "  ldp d8,  d9,  [sp, #96]\n"
  "  ldp x29, x30, [sp, #80]\n"
  "  ldp x27, x28, [sp, #64]\n"
  "  ldp x25, x26, [sp, #48]\n"
  "  ldp x23, x24, [sp, #32]\n"
  "  ldp x21, x22, [sp, #16]\n"
  "  ldp x19, x20, [sp], #160\n"
  "  ret\n"
);
#endif

void janet_fiber_ctx_prime(JanetFiberCtx *ctx, void *base, size_t size,
                           void (*entry)(void)) {
  uintptr_t top = ((uintptr_t)base + size) & ~(uintptr_t)15;
#if defined(__x86_64__)
  /* entry's first instruction needs rsp%16 == 8 (as if reached by `call`).
   * sp_fiber ctx_swap pops 6 callee-saved regs then `ret`s: [entry][rbp]
   * [rbx][r12][r13][r14][r15<-sp]. */
  void **s = (void **)(top - 8);
  *--s = (void *)entry;
  for (int i = 0; i < 6; i++) *--s = 0;
  ctx->sp = s;
#else
  void **s = (void **)(top - 160);
  for (int i = 0; i < 20; i++) s[i] = 0;
  s[11] = (void *)entry;
  ctx->sp = s;
#endif
}
#else
void janet_fiber_ctx_swap(JanetFiberCtx *from, JanetFiberCtx *to) {
  swapcontext(&from->uc, &to->uc);
}

void janet_fiber_ctx_prime(JanetFiberCtx *ctx, void *base, size_t size,
                           void (*entry)(void)) {
  getcontext(&ctx->uc);
  ctx->uc.uc_stack.ss_sp = base;
  ctx->uc.uc_stack.ss_size = size;
  ctx->uc.uc_link = NULL;
  makecontext(&ctx->uc, entry, 0);
}
#endif

static void fiber_reset(JanetFiber *fiber) {
    fiber->maxstack = JANET_STACK_MAX;
    fiber->frame = 0;
    fiber->stackstart = JANET_FRAME_SIZE;
    fiber->stacktop = JANET_FRAME_SIZE;
    fiber->child = NULL;
    fiber->flags = JANET_FIBER_MASK_YIELD | JANET_FIBER_RESUME_NO_USEVAL | JANET_FIBER_RESUME_NO_SKIP;
    fiber->env = NULL;
    fiber->last_value = janet_wrap_nil();
    fiber->in_value = janet_wrap_nil();
    fiber->out_payload = janet_wrap_nil();
    fiber->out_signal = JANET_SIGNAL_OK;
    fiber->resume_ctx = NULL;
    /* Phase 1.1: fresh fibers re-enter run_vm from the trampoline with
     * clean parked registers (loaded by janet_continue_no_check). */
    fiber->suspend_mode = 0;
    fiber->resume_fiber = NULL;
    fiber->saved_signal_buf = NULL;
    fiber->saved_return_reg = NULL;
    fiber->saved_coerce_error = 0;
    fiber->saved_stackn = 0;
    fiber->saved_gc_suspend = 0;
    /* Phase D3: a reset restarts execution from the top (re-primed
     * below). Clear any stale flag, and reclaim red-zone space when
     * unwound fibers consumed it (DEAD/ERROR have no live C frames; a
     * suspended fiber's parked position may still point into it).
     * Gated on position, not the flag: raises clear the flag, so a
     * flag gate would skip exactly the fibers that need reclaim. */
    if (janet_fiber_status(fiber) == JANET_STATUS_DEAD ||
            janet_fiber_status(fiber) == JANET_STATUS_ERROR) {
        fiber->stack_overflowed = 0;
#ifndef JANET_WINDOWS
        if (NULL != fiber->native_stack_committed &&
                NULL != fiber->native_stack &&
                fiber->native_stack_committed < fiber->native_stack) {
            /* Uncommit the red zone only; grown usable space persists. */
            char *usable = (char *) fiber->native_stack;
            char *rebased = (char *) fiber->native_stack_base +
                fiber->native_stack_size - JANET_FIBER_STACK_INIT_BYTES;
            if (rebased < usable) rebased = usable;
            mprotect(fiber->native_stack_base,
                     (size_t) (usable - (char *) fiber->native_stack_base),
                     PROT_NONE);
            fiber->native_stack_committed = rebased;
        }
#endif
    }
    /* Reset restarts from the top: re-prime mapped fibers, leave
     * unmapped ones for the resume path (P3.6 lazy mapping). */
    janet_fiber_reprime(fiber);
#ifdef JANET_EV
    fiber->sched_id = 0;
    fiber->ev_callback = NULL;
    fiber->ev_state = NULL;
    fiber->ev_stream = NULL;
    fiber->supervisor_channel = NULL;
    fiber->interrupt_requested = 0;
    fiber->interrupt_value = janet_wrap_nil();
#endif
    janet_fiber_set_status(fiber, JANET_STATUS_NEW);
}

static JanetFiber *fiber_alloc(int32_t capacity) {
    Janet *data;
    JanetFiber *fiber = janet_gcalloc(JANET_MEMORY_FIBER, sizeof(JanetFiber));
    if (capacity < 32) {
        capacity = 32;
    }
    fiber->capacity = capacity;
    janet_fiber_init_owner(fiber);
    /* P3.3: strict heaps are opt-in per fiber (spawn-isolated sets it
     * after alloc; unmarshal leaves it clear). */
    fiber->heap_strict = 0;
    /* P3.5: no owning proc (proc spawn sets it). */
    fiber->proc = NULL;
    /* P3.6: private stacks by default (ev/go + proc spawn opt in). */
    fiber->shared_stack = 0;
    /* P3.5b: heap lists start empty (births file here). */
    {
        int hli;
        for (hli = 0; hli < 3; hli++)
            fiber->heap_lists[hli] = NULL;
    }
    /* Channel-pending registrations start empty (gcalloc does not
     * zero fresh bump slots — same rule as heap_lists above). */
    fiber->chan_pends = NULL;
    /* Census slot sentinel BEFORE census_add (which assigns the real
     * index): gcalloc hands back unzeroed bump slots, so without this
     * any fiber reaching census_remove without having been added would
     * carry a garbage index that could spuriously pass the fast-path
     * validation. Sentinel first, real index second. */
    fiber->census_idx = JANET_CENSUS_UNTRACKED;
    janet_census_add(fiber);
    {
        /* Step 1.2: nursery starts empty (pages claimed on first bump). */
        int nci;
        for (nci = 0; nci < JANET_SLAB_NCLASSES; nci++)
            fiber->nursery_cur[nci] = NULL;
        fiber->gc_nursery_bytes = 0;
    }
    data = array_allocate(sizeof(Janet), capacity);
    if (NULL == data) {
        JANET_OUT_OF_MEMORY;
    }
    janet_vm.next_collection += sizeof(Janet) * capacity;
    fiber->data = data;
    /* This fiber's native mapping is created lazily on first resume
     * (see janet_continue_no_check) so fibers that never run map
     * nothing — and shared-stack fibers never map privately at all. */
    fiber->native_stack_base = NULL;
    fiber->native_stack = NULL;
    fiber->native_stack_size = 0;
    fiber->native_stack_committed = NULL;
    fiber->stack_overflowed = 0;
    return fiber;
}

/* Step 1 (process heaps): assign a fresh owner id from the VM counter
 * (0 reserved for shared). Used at every fiber birth site (alloc,
 * unmarshal); resets keep the id (same logical fiber). */
void janet_fiber_init_owner(JanetFiber *fiber) {
    uint32_t id = ++janet_vm.gc_owner_next;
    if (0 == id) id = ++janet_vm.gc_owner_next;
    fiber->gc_owner = id;
}

/* Allocate the fiber's native stack on first use and (re)prime its switch
 * context to enter the VM trampoline. See fiber.h for when re-priming
 * is valid. */
void janet_fiber_ensure_native_stack(JanetFiber *fiber) {
    /* P3.6: shared-stack fibers hold no private mapping (each resume
     * re-primes on the lane mapping instead). */
    if (fiber->shared_stack) return;
    if (!fiber->native_stack_base) {
        size_t guard = 0;
        void *committed = NULL;
        fiber->native_stack_base = fiber_native_stack_alloc(&fiber->native_stack_size,
                                                            &guard, &committed);
#ifndef JANET_WINDOWS
        /* Usable start is fixed (base + guard); the committed window
         * starts at the top and grows down on faults. Priming spans the
         * full usable window: sp starts at the top (always committed),
         * and downward growth never moves it, so no re-prime is needed. */
        fiber->native_stack = (char *)fiber->native_stack_base + guard;
        fiber->native_stack_committed = committed;
#else
        fiber->native_stack = fiber->native_stack_base;
        fiber->native_stack_committed = NULL;
#endif
    }
        janet_fiber_reprime(fiber);
}

/* Re-prime a mapped fiber's switch context (trampoline entry).
 * Mapping must exist (no-op otherwise — resume paths map first). */
static void janet_fiber_reprime(JanetFiber *fiber) {
    if (fiber->native_stack) {
        size_t usable = fiber->native_stack_size -
            (size_t)((char *)fiber->native_stack -
                     (char *)fiber->native_stack_base);
        janet_fiber_ctx_prime(&fiber->ctx, fiber->native_stack, usable,
                              janet_fiber_trampoline);
    }
}

/* P3.6 lane-shared mapping: same reserve/commit/guard shape as private
 * stacks (fiber_native_stack_alloc), but VM-scoped and created lazily
 * so VMs without shared fibers map nothing. Growth/red-zone/overflow
 * handling is shared with the private path (see the fault handler —
 * shared faults attribute to the running fiber). */
void janet_fiber_shared_prime(JanetFiber *fiber) {
    if (NULL == janet_vm.shared_stack_base) {
        size_t guard = 0;
        void *committed = NULL;
        void *base = fiber_native_stack_alloc(&janet_vm.shared_stack_size,
                                              &guard, &committed);
        janet_vm.shared_stack_base = base;
        janet_vm.shared_stack = (char *)base + guard;
        janet_vm.shared_stack_committed = committed;
    }
    {
        size_t usable = janet_vm.shared_stack_size -
            (size_t)((char *)janet_vm.shared_stack -
                     (char *)janet_vm.shared_stack_base);
                janet_fiber_ctx_prime(&fiber->ctx, janet_vm.shared_stack, usable,
                              janet_fiber_trampoline);
    }
}
JanetFiber *janet_fiber_reset(JanetFiber *fiber, JanetFunction *callee, int32_t argc, const Janet *argv) {
    int32_t newstacktop;
    /* Phase 2a invariant: never start a fiber on a half-built function.
     * Caught real use-after-sweep construction bugs under GC stress (the
     * def must be fully populated before any fiber references it). */
    if (NULL == callee || NULL == callee->def || NULL == callee->def->bytecode) {
        JanetFiber *cur = janet_vm.fiber;
        fprintf(stderr, "janet_fiber_reset: fiber started on half-built function (callee=%p def=%p bytecode=%p)\n",
                (void *) callee,
                (void *) (callee ? (void *) callee->def : NULL),
                (void *) (callee && callee->def ? (void *) callee->def->bytecode : NULL));
        if (cur) {
            janet_stacktrace(cur, janet_wrap_nil());
        }
        abort();
    }
    fiber_reset(fiber);
    if (argc) {
        newstacktop = fiber->stacktop + argc;
        if (newstacktop >= fiber->capacity) {
            janet_fiber_setcapacity(fiber, 2 * newstacktop);
        }
        if (argv) {
            memcpy(fiber->data + fiber->stacktop, argv, argc * sizeof(Janet));
        } else {
            /* If argv not given, fill with nil */
            for (int32_t i = 0; i < argc; i++) {
                fiber->data[fiber->stacktop + i] = janet_wrap_nil();
            }
        }
        fiber->stacktop = newstacktop;
    }
    /* Don't panic on failure since we use this to implement janet_pcall */
    if (janet_fiber_funcframe(fiber, callee)) return NULL;
    janet_fiber_frame(fiber)->flags |= JANET_STACKFRAME_ENTRANCE;
#ifdef JANET_EV
    fiber->supervisor_channel = NULL;
    fiber->interrupt_requested = 0;
    fiber->interrupt_value = janet_wrap_nil();
#endif
    return fiber;
}

/* Create a new fiber with argn values on the stack. */
JanetFiber *janet_fiber(JanetFunction *callee, int32_t capacity, int32_t argc, const Janet *argv) {
    return janet_fiber_reset(fiber_alloc(capacity), callee, argc, argv);
}

#ifdef JANET_DEBUG
/* Test for memory issues by reallocating fiber every time we push a stack frame */
static void janet_fiber_refresh_memory(JanetFiber *fiber) {
    int32_t n = fiber->capacity;
    if (n) {
        Janet *newData = array_allocate(sizeof(Janet), n);
        if (NULL == newData) {
            JANET_OUT_OF_MEMORY;
        }
        memcpy(newData, fiber->data, n * sizeof(Janet));
        janet_free(fiber->data);
        fiber->data = newData;
    }
}
#endif

/* Ensure that the fiber has enough extra capacity */
void janet_fiber_setcapacity(JanetFiber *fiber, int32_t n) {
    int32_t old_size = fiber->capacity;
    int32_t diff = n - old_size;
    Janet *newData = janet_realloc(fiber->data, sizeof(Janet) * n);
    if (NULL == newData) {
        JANET_OUT_OF_MEMORY;
    }
    fiber->data = newData;
    fiber->capacity = n;
    janet_vm.next_collection += sizeof(Janet) * diff;
}

/* Grow fiber if needed */
static void janet_fiber_grow(JanetFiber *fiber, int32_t needed) {
    int32_t cap = needed > (INT32_MAX / 2) ? INT32_MAX : 2 * needed;
    janet_fiber_setcapacity(fiber, cap);
}

/* Push a value on the next stack frame */
void janet_fiber_push(JanetFiber *fiber, Janet x) {
    if (fiber->stacktop == INT32_MAX) janet_panic("stack overflow");
    if (fiber->stacktop >= fiber->capacity) {
        janet_fiber_grow(fiber, fiber->stacktop);
    }
    fiber->data[fiber->stacktop++] = x;
}

/* Push 2 values on the next stack frame */
void janet_fiber_push2(JanetFiber *fiber, Janet x, Janet y) {
    if (fiber->stacktop >= INT32_MAX - 1) janet_panic("stack overflow");
    int32_t newtop = fiber->stacktop + 2;
    if (newtop > fiber->capacity) {
        janet_fiber_grow(fiber, newtop);
    }
    fiber->data[fiber->stacktop] = x;
    fiber->data[fiber->stacktop + 1] = y;
    fiber->stacktop = newtop;
}

/* Push 3 values on the next stack frame */
void janet_fiber_push3(JanetFiber *fiber, Janet x, Janet y, Janet z) {
    if (fiber->stacktop >= INT32_MAX - 2) janet_panic("stack overflow");
    int32_t newtop = fiber->stacktop + 3;
    if (newtop > fiber->capacity) {
        janet_fiber_grow(fiber, newtop);
    }
    fiber->data[fiber->stacktop] = x;
    fiber->data[fiber->stacktop + 1] = y;
    fiber->data[fiber->stacktop + 2] = z;
    fiber->stacktop = newtop;
}

/* Push an array on the next stack frame */
void janet_fiber_pushn(JanetFiber *fiber, const Janet *arr, int32_t n) {
    if (fiber->stacktop > INT32_MAX - n) janet_panic("stack overflow");
    int32_t newtop = fiber->stacktop + n;
    if (newtop > fiber->capacity) {
        janet_fiber_grow(fiber, newtop);
    }
    safe_memcpy(fiber->data + fiber->stacktop, arr, n * sizeof(Janet));
    fiber->stacktop = newtop;
}

/* Create a struct with n values. If n is odd, the last value is ignored. */
static Janet make_struct_n(const Janet *args, int32_t n) {
    int32_t i = 0;
    if (n & 1) n--;
    JanetKV *st = janet_struct_begin(n);
    for (; i < n; i += 2) {
        janet_struct_put(st, args[i], args[i + 1]);
    }
    return janet_wrap_struct(janet_struct_end(st));
}

/* Push a stack frame to a fiber */
int janet_fiber_funcframe(JanetFiber *fiber, JanetFunction *func) {
    JanetStackFrame *newframe;

    int32_t i;
    int32_t oldtop = fiber->stacktop;
    int32_t oldframe = fiber->frame;
    int32_t nextframe = fiber->stackstart;
    int32_t nextstacktop = nextframe + func->def->slotcount + JANET_FRAME_SIZE;
    int32_t next_arity = fiber->stacktop - fiber->stackstart;

    /* Check strict arity before messing with state */
    if (next_arity < func->def->min_arity) return 1;
    if (next_arity > func->def->max_arity) return 1;

    if (fiber->capacity < nextstacktop) {
        janet_fiber_setcapacity(fiber, 2 * nextstacktop);
#ifdef JANET_DEBUG
    } else {
        janet_fiber_refresh_memory(fiber);
#endif
    }

    /* Nil unset stack arguments (Needed for gc correctness) */
    for (i = fiber->stacktop; i < nextstacktop; ++i) {
        fiber->data[i] = janet_wrap_nil();
    }

    /* Set up the next frame */
    fiber->frame = nextframe;
    fiber->stacktop = fiber->stackstart = nextstacktop;
    newframe = janet_fiber_frame(fiber);
    newframe->prevframe = oldframe;
    newframe->pc = func->def->bytecode;
    newframe->func = func;
    newframe->env = NULL;
    newframe->flags = 0;

    /* Check varargs */
    if (func->def->flags & JANET_FUNCDEF_FLAG_VARARG) {
        int32_t tuplehead = fiber->frame + func->def->arity;
        janet_assert(tuplehead > 0, "fiber stack overflow");
        int st = func->def->flags & JANET_FUNCDEF_FLAG_STRUCTARG;
        if (tuplehead >= oldtop) {
            fiber->data[tuplehead] = st
                                     ? make_struct_n(NULL, 0)
                                     : janet_wrap_tuple(janet_tuple_n(NULL, 0));
        } else {
            fiber->data[tuplehead] = st
                                     ? make_struct_n(
                                         fiber->data + tuplehead,
                                         oldtop - tuplehead)
                                     : janet_wrap_tuple(janet_tuple_n(
                                             fiber->data + tuplehead,
                                             oldtop - tuplehead));
        }
    }

    /* Good return */
    return 0;
}

/* If a frame has a closure environment, detach it from
 * the stack and have it keep its own values */
static void janet_env_detach(JanetFuncEnv *env) {
    /* Check for closure environment */
    if (env) {
        janet_env_valid(env);
        int32_t len = env->length; /* Maximum is 256 */
        size_t s = sizeof(Janet) * (size_t) len;
        Janet *vmem = janet_malloc(s);
        janet_vm.next_collection += (uint32_t) s;
        if (NULL == vmem) {
            JANET_OUT_OF_MEMORY;
        }
        Janet *values = env->as.fiber->data + env->offset;
        safe_memcpy(vmem, values, s);
        uint32_t *bitset = janet_stack_frame(values)->func->def->closure_bitset;
        if (bitset) {
            /* Clear unneeded references in closure environment */
            for (int32_t i = 0; i < len; i += 32) {
                uint32_t mask = ~(bitset[i >> 5]);
                int32_t maxj = i + 32 > len ? len : i + 32;
                for (int32_t j = i; j < maxj; j++) {
                    if (mask & 1) vmem[j] = janet_wrap_nil();
                    mask >>= 1;
                }
            }
        }
        env->offset = 0;
        env->as.values = vmem;
    }
}

/* Validate potentially untrusted func env (unmarshalled envs are difficult to verify) */
int janet_env_valid(JanetFuncEnv *env) {
    if (env->offset < 0) {
        int32_t real_offset = -(env->offset);
        JanetFiber *fiber = env->as.fiber;
        int32_t i = fiber->frame;
        while (i > 0) {
            JanetStackFrame *frame = (JanetStackFrame *)(fiber->data + i - JANET_FRAME_SIZE);
            if (real_offset == i &&
                    frame->env == env &&
                    frame->func &&
                    frame->func->def->slotcount == env->length) {
                env->offset = real_offset;
                return 1;
            }
            i = frame->prevframe;
        }
        /* Invalid, set to empty off-stack variant. */
        env->offset = 0;
        env->length = 0;
        env->as.values = NULL;
        return 0;
    } else {
        return 1;
    }
}

/* Detach a fiber from the env if the target fiber has stopped mutating */
void janet_env_maybe_detach(JanetFuncEnv *env) {
    /* Check for detachable closure envs */
    janet_env_valid(env);
    if (env->offset > 0) {
        JanetFiberStatus s = janet_fiber_status(env->as.fiber);
        int isFinished = s == JANET_STATUS_DEAD ||
                         s == JANET_STATUS_ERROR ||
                         s == JANET_STATUS_USER0 ||
                         s == JANET_STATUS_USER1 ||
                         s == JANET_STATUS_USER2 ||
                         s == JANET_STATUS_USER3 ||
                         s == JANET_STATUS_USER4;
        if (isFinished) {
            janet_env_detach(env);
        }
    }
}

/* Create a tail frame for a function */
int janet_fiber_funcframe_tail(JanetFiber *fiber, JanetFunction *func) {
    int32_t i;
    int32_t nextframetop = fiber->frame + func->def->slotcount;
    int32_t nextstacktop = nextframetop + JANET_FRAME_SIZE;
    int32_t next_arity = fiber->stacktop - fiber->stackstart;
    int32_t stacksize;

    /* Check strict arity before messing with state */
    if (next_arity < func->def->min_arity) return 1;
    if (next_arity > func->def->max_arity) return 1;

    if (fiber->capacity < nextstacktop) {
        janet_fiber_setcapacity(fiber, 2 * nextstacktop);
#ifdef JANET_DEBUG
    } else {
        janet_fiber_refresh_memory(fiber);
#endif
    }

    /* Detach old function */
    if (NULL != janet_fiber_frame(fiber)->func)
        janet_env_detach(janet_fiber_frame(fiber)->env);
    janet_fiber_frame(fiber)->env = NULL;

    /* Check varargs */
    if (func->def->flags & JANET_FUNCDEF_FLAG_VARARG) {
        int32_t tuplehead = fiber->stackstart + func->def->arity;
        int st = func->def->flags & JANET_FUNCDEF_FLAG_STRUCTARG;
        if (tuplehead >= fiber->stacktop) {
            if (tuplehead >= fiber->capacity) janet_fiber_setcapacity(fiber, 2 * (tuplehead + 1));
            for (i = fiber->stacktop; i < tuplehead; ++i) fiber->data[i] = janet_wrap_nil();
            fiber->data[tuplehead] = st
                                     ? make_struct_n(NULL, 0)
                                     : janet_wrap_tuple(janet_tuple_n(NULL, 0));
        } else {
            fiber->data[tuplehead] = st
                                     ? make_struct_n(
                                         fiber->data + tuplehead,
                                         fiber->stacktop - tuplehead)
                                     : janet_wrap_tuple(janet_tuple_n(
                                             fiber->data + tuplehead,
                                             fiber->stacktop - tuplehead));
        }
        stacksize = tuplehead - fiber->stackstart + 1;
    } else {
        stacksize = fiber->stacktop - fiber->stackstart;
    }

    if (stacksize) memmove(fiber->data + fiber->frame, fiber->data + fiber->stackstart, stacksize * sizeof(Janet));

    /* Nil unset locals (Needed for functional correctness) */
    for (i = fiber->frame + stacksize; i < nextframetop; ++i)
        fiber->data[i] = janet_wrap_nil();

    /* Set stack stuff */
    fiber->stacktop = fiber->stackstart = nextstacktop;

    /* Set frame stuff */
    janet_fiber_frame(fiber)->func = func;
    janet_fiber_frame(fiber)->pc = func->def->bytecode;
    janet_fiber_frame(fiber)->flags |= JANET_STACKFRAME_TAILCALL;

    /* Good return */
    return 0;
}

/* Push a stack frame to a fiber for a c function */
void janet_fiber_cframe(JanetFiber *fiber, JanetCFunction cfun) {
    JanetStackFrame *newframe;

    int32_t oldframe = fiber->frame;
    int32_t nextframe = fiber->stackstart;
    int32_t nextstacktop = fiber->stacktop + JANET_FRAME_SIZE;

    if (fiber->capacity < nextstacktop) {
        janet_fiber_setcapacity(fiber, 2 * nextstacktop);
#ifdef JANET_DEBUG
    } else {
        janet_fiber_refresh_memory(fiber);
#endif
    }

    /* Set the next frame */
    fiber->frame = nextframe;
    fiber->stacktop = fiber->stackstart = nextstacktop;
    newframe = janet_fiber_frame(fiber);

    /* Set up the new frame */
    newframe->prevframe = oldframe;
    newframe->pc = (uint32_t *) cfun;
    newframe->func = NULL;
    newframe->env = NULL;
    newframe->flags = 0;
}

/* Pop a stack frame from the fiber. */
void janet_fiber_popframe(JanetFiber *fiber) {
    JanetStackFrame *frame = janet_fiber_frame(fiber);
    if (fiber->frame == 0) return;

    /* Clean up the frame (detach environments) */
    if (NULL != frame->func)
        janet_env_detach(frame->env);

    /* Shrink stack */
    fiber->stacktop = fiber->stackstart = fiber->frame;
    fiber->frame = frame->prevframe;
}

JanetFiberStatus janet_fiber_status(JanetFiber *f) {
    return ((f)->flags & JANET_FIBER_STATUS_MASK) >> JANET_FIBER_STATUS_OFFSET;
}

JanetFiber *janet_current_fiber(void) {
    return janet_vm.fiber;
}

JanetFiber *janet_root_fiber(void) {
    return janet_vm.root_fiber;
}

/* CFuns */

JANET_CORE_FN(cfun_fiber_getenv,
              "(fiber/getenv fib)",
              "Gets the environment for a fiber `fib`. Returns nil if no "
              "such table is set yet.") {
    janet_fixarity(argc, 1);
    JanetFiber *fiber = janet_getfiber(argv, 0);
    return fiber->env ?
           janet_wrap_table(fiber->env) :
           janet_wrap_nil();
}

JANET_CORE_FN(cfun_fiber_setenv,
              "(fiber/setenv fib tab)",
              "Sets the environment table for a fiber `fib` to `tab`. Set "
              "to nil to remove the current environment.") {
    janet_fixarity(argc, 2);
    JanetFiber *fiber = janet_getfiber(argv, 0);
    if (janet_checktype(argv[1], JANET_NIL)) {
        fiber->env = NULL;
    } else {
        fiber->env = janet_gettable(argv, 1);
    }
    return argv[0];
}

JANET_CORE_FN(cfun_fiber_new,
              "(fiber/new func &opt sigmask env)",
              "Create a new fiber with function body func. Can optionally "
              "take a set of signals `sigmask` to capture from child fibers, "
              "and an environment table `env`. The mask is specified as a keyword where each character "
              "is used to indicate a signal to block. If the ev module is enabled, and "
              "this fiber is used as an argument to `ev/go`, these \"blocked\" signals "
              "will result in messages being sent to the supervisor channel. "
              "The default sigmask is :y. "
              "For example,\n\n"
              "    (fiber/new myfun :e123)\n\n"
              "blocks error signals and user signals 1, 2 and 3. The signals are "
              "as follows:\n\n"
              "* :a - block all signals\n"
              "* :d - block debug signals\n"
              "* :e - block error signals\n"
              "* :t - block termination signals: error + user[0-4]\n"
              "* :u - block user signals\n"
              "* :y - block yield signals\n"
              "* :w - block await signals (user9)\n"
              "* :r - block interrupt signals (user8)\n"
              "* :0-9 - block a specific user signal\n\n"
              "The sigmask argument also can take environment flags. If any mutually "
              "exclusive flags are present, the last flag takes precedence.\n\n"
              "* :i - inherit the environment from the current fiber\n"
              "* :p - the environment table's prototype is the current environment table") {
    janet_arity(argc, 1, 3);
    JanetFunction *func = janet_getfunction(argv, 0);
    JanetFiber *fiber;
    if (func->def->min_arity > 1) {
        janet_panicf("fiber function must accept 0 or 1 arguments");
    }
    fiber = janet_fiber(func, 64, func->def->min_arity, NULL);
    janet_assert(fiber != NULL, "bad fiber arity check");
    if (argc == 3 && !janet_checktype(argv[2], JANET_NIL)) {
        fiber->env = janet_gettable(argv, 2);
    }
    if (argc >= 2) {
        int32_t i;
        JanetByteView view = janet_getbytes(argv, 1);
        fiber->flags = JANET_FIBER_RESUME_NO_USEVAL | JANET_FIBER_RESUME_NO_SKIP;
        janet_fiber_set_status(fiber, JANET_STATUS_NEW);
        for (i = 0; i < view.len; i++) {
            if (view.bytes[i] >= '0' && view.bytes[i] <= '9') {
                fiber->flags |= JANET_FIBER_MASK_USERN(view.bytes[i] - '0');
            } else {
                switch (view.bytes[i]) {
                    default:
                        janet_panicf("invalid flag %c, expected a, t, d, e, u, y, w, r, i, or p", view.bytes[i]);
                        break;
                    case 'a':
                        fiber->flags |=
                            JANET_FIBER_MASK_DEBUG |
                            JANET_FIBER_MASK_ERROR |
                            JANET_FIBER_MASK_USER |
                            JANET_FIBER_MASK_YIELD;
                        break;
                    case 't':
                        fiber->flags |=
                            JANET_FIBER_MASK_ERROR |
                            JANET_FIBER_MASK_USER0 |
                            JANET_FIBER_MASK_USER1 |
                            JANET_FIBER_MASK_USER2 |
                            JANET_FIBER_MASK_USER3 |
                            JANET_FIBER_MASK_USER4;
                        break;
                    case 'd':
                        fiber->flags |= JANET_FIBER_MASK_DEBUG;
                        break;
                    case 'e':
                        fiber->flags |= JANET_FIBER_MASK_ERROR;
                        break;
                    case 'u':
                        fiber->flags |= JANET_FIBER_MASK_USER;
                        break;
                    case 'y':
                        fiber->flags |= JANET_FIBER_MASK_YIELD;
                        break;
                    case 'w':
                        fiber->flags |= JANET_FIBER_MASK_USER9;
                        break;
                    case 'r':
                        fiber->flags |= JANET_FIBER_MASK_USER8;
                        break;
                    case 'i':
                        if (!janet_vm.fiber->env) {
                            janet_vm.fiber->env = janet_table(0);
                        }
                        fiber->env = janet_vm.fiber->env;
                        break;
                    case 'p':
                        if (!janet_vm.fiber->env) {
                            janet_vm.fiber->env = janet_table(0);
                        }
                        fiber->env = janet_table(0);
                        fiber->env->proto = janet_vm.fiber->env;
                        break;
                }
            }
        }
    }
    return janet_wrap_fiber(fiber);
}

JANET_CORE_FN(cfun_fiber_status,
              "(fiber/status fib)",
              "Get the status of a fiber. The status will be one of:\n\n"
              "* :dead - the fiber has finished\n"
              "* :error - the fiber has errored out\n"
              "* :debug - the fiber is suspended in debug mode\n"
              "* :pending - the fiber has been yielded\n"
              "* :user(0-7) - the fiber is suspended by a user signal\n"
              "* :interrupted - the fiber was interrupted\n"
              "* :suspended - the fiber is waiting to be resumed by the scheduler\n"
              "* :new - the fiber has just been created and not yet run\n"
              "* :alive - the fiber is currently running and cannot be resumed") {
    janet_fixarity(argc, 1);
    JanetFiber *fiber = janet_getfiber(argv, 0);
    uint32_t s = janet_fiber_status(fiber);
    return janet_ckeywordv(janet_status_names[s]);
}

JANET_CORE_FN(cfun_fiber_current,
              "(fiber/current)",
              "Returns the currently running fiber.") {
    (void) argv;
    janet_fixarity(argc, 0);
    return janet_wrap_fiber(janet_vm.fiber);
}

JANET_CORE_FN(cfun_fiber_root,
              "(fiber/root)",
              "Returns the current root fiber. The root fiber is the oldest "
              "ancestor that does not have a parent. Note that a root fiber "
              "is also a task fiber.") {
    (void) argv;
    janet_fixarity(argc, 0);
    return janet_wrap_fiber(janet_vm.root_fiber);
}

JANET_CORE_FN(cfun_fiber_maxstack,
              "(fiber/maxstack fib)",
              "Gets the maximum stack size in janet values allowed for a fiber. While memory for "
              "the fiber's stack is not allocated up front, the fiber will not allocated more "
              "than this amount and will throw a stack-overflow error if more memory is needed. ") {
    janet_fixarity(argc, 1);
    JanetFiber *fiber = janet_getfiber(argv, 0);
    return janet_wrap_integer(fiber->maxstack);
}

JANET_CORE_FN(cfun_fiber_setmaxstack,
              "(fiber/setmaxstack fib maxstack)",
              "Sets the maximum stack size in janet values for a fiber. By default, the "
              "maximum stack size is usually 8192.") {
    janet_fixarity(argc, 2);
    JanetFiber *fiber = janet_getfiber(argv, 0);
    int32_t maxs = janet_getinteger(argv, 1);
    if (maxs < 0) {
        janet_panic("expected positive integer");
    }
    fiber->maxstack = maxs;
    return argv[0];
}

int janet_fiber_can_resume(JanetFiber *fiber) {
    JanetFiberStatus s = janet_fiber_status(fiber);
    int isFinished = s == JANET_STATUS_DEAD ||
                     s == JANET_STATUS_ERROR ||
                     s == JANET_STATUS_USER0 ||
                     s == JANET_STATUS_USER1 ||
                     s == JANET_STATUS_USER2 ||
                     s == JANET_STATUS_USER3 ||
                     s == JANET_STATUS_USER4;
    return !isFinished;
}

JANET_CORE_FN(cfun_fiber_can_resume,
              "(fiber/can-resume? fib)",
              "Check if a fiber `fib` is finished and cannot be resumed.") {
    janet_fixarity(argc, 1);
    JanetFiber *fiber = janet_getfiber(argv, 0);
    return janet_wrap_boolean(janet_fiber_can_resume(fiber));
}

JANET_CORE_FN(cfun_fiber_last_value,
              "(fiber/last-value fib)",
              "Get the last value returned or signaled from a fiber `fib`.") {
    janet_fixarity(argc, 1);
    JanetFiber *fiber = janet_getfiber(argv, 0);
    return fiber->last_value;
}

/* Module entry point */
void janet_lib_fiber(JanetTable *env) {
    JanetRegExt fiber_cfuns[] = {
        JANET_CORE_REG("fiber/new", cfun_fiber_new),
        JANET_CORE_REG("fiber/status", cfun_fiber_status),
        JANET_CORE_REG("fiber/root", cfun_fiber_root),
        JANET_CORE_REG("fiber/current", cfun_fiber_current),
        JANET_CORE_REG("fiber/maxstack", cfun_fiber_maxstack),
        JANET_CORE_REG("fiber/setmaxstack", cfun_fiber_setmaxstack),
        JANET_CORE_REG("fiber/getenv", cfun_fiber_getenv),
        JANET_CORE_REG("fiber/setenv", cfun_fiber_setenv),
        JANET_CORE_REG("fiber/can-resume?", cfun_fiber_can_resume),
        JANET_CORE_REG("fiber/last-value", cfun_fiber_last_value),
        JANET_REG_END
    };
    janet_core_cfuns_ext(env, NULL, fiber_cfuns);
}
