# Hybrid concurrency: procs for cores, fibers for units.
#
# Run with lanes enabled so the procs actually spread across cores:
#
#   JANET_LANES=11 ./build/janet examples/concurrency-hybrid.janet <units> <per-proc>
#
# Shape (see docs/internals/concurrency-visual-guide.md):
#
#   PROC A [fiber fiber fiber ...] --#   PROC B [fiber fiber fiber ...] ---> results (thread-chan) --> sum
#   PROC C [fiber fiber fiber ...] --/
#
# Each proc owns a local `inbox` (ev/chan) that its own fibers push into -- an
# ev/chan cannot cross lanes, and this one never has to. Only finished values
# cross, through a thread-chan.
(def units (scan-number (get (dyn :args) 1)))
(def per-proc (scan-number (get (dyn :args) 2)))
(def results (ev/thread-chan 65536))

(defn do-work [id]
  (var acc 0)
  (var i 0)
  (while (< i 1000) (set acc (+ acc (+ id i))) (set i (+ i 1)))
  acc)

(defn host [base count]
  (def ch (ev/chan 4096))
  (var i 0)
  (while (< i count)
    (def id (+ base i))
    (ev/go (fn [] (ev/give ch (do-work id))))
    (set i (+ i 1)))
  (var got 0)
  (while (< got count) (ev/give results (ev/take ch)) (set got (+ got 1))))

(def nprocs (max 1 (- (os/cpu-count 4) 1)))
(var started 0)
(var p 0)
(def t0 (os/clock))
(while (< started units)
  (def take (min per-proc (- units started)))
  (proc/spawn (fn [] (host started take)) 8)
  (set started (+ started take))
  (set p (+ p 1)))
(var sum 0)
(var k 0)
(while (< k units) (set sum (+ sum (ev/take results))) (set k (+ k 1)))
(eprintf "units=%d procs=%d fibers_each<=%d lanes=%d wall=%.0fms checksum=%d"
         units p per-proc (proc/lanes) (* 1000.0 (- (os/clock) t0)) sum)
(when (> (proc/lanes) 0) (proc/lanes-stop))
