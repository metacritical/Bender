(def abc 123)
