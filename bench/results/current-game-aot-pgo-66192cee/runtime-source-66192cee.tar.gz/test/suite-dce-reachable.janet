# B7.2 Part B, Piece 1b: the dce-reachable whole-program DCE safety
# gate (tools/callgraph.janet, appended block). See
# docs/internals/b7.2-part-b-design-note.md, "Piece 1". The gate
# classifies the WHOLE program :safe (a stripping candidate set MAY
# exist) or :unsafe (strip nothing) when it finds ANY instance of:
#   pattern 1 -- a function value stored into a container (put/puti
#     value, pending into a mkarr/mktup/mkbtp/mkbuf/mkstr/mkstu/mktab
#     constructor, or pending across any non-consuming non-call op);
#   pattern 2 -- a function value pending as a call ARGUMENT;
#   pattern 3 -- any def reaching a dynsite (existing taint fixpoint);
#   pattern 4 -- any bytecode op outside the recognized-op whitelist.
# Any violation prints "dce unsafe pattern N def I (name) pc P: ..." --
# the diagnostics below are asserted by exact substring, not just exit
# status, because a verdict without a citable location is not a gate.
#
# A safe verdict prints "dce safe reachable <ids> excluded <names>" --
# the reachable set is computed by the pre-existing reachable-from
# machinery, which is trustworthy ONLY after the whole program cleared
# the gate (never as a safety argument on its own).
(import ./helper :prefix "" :exit true)
(start-suite)

(def root "/tmp/janet-dce-reachable-suite")
(os/execute ["/bin/sh" "-c" (string "rm -rf " root)] :p)
(os/mkdir root)

(defn run-callgraph [fixture-name fixture-source]
  (def src (string root "/" fixture-name ".janet"))
  (spit src fixture-source)
  (def out (string root "/" fixture-name ".out"))
  (os/execute ["/bin/sh" "-c"
               (string "./build/bender tools/callgraph.janet " src
                       " > " out " 2>&1")]
              :p)
  (string (slurp out)))

# --- Case 1 (safe): zero disqualifying patterns, one genuinely unused
# top-level function. The verdict must be :safe and the unused function
# must not appear anywhere in the analysis output -- this compiler
# drops unreferenced top-level defns BEFORE analysis (documented in
# test/suite-callgraph.janet as "dropped pre-analysis"), so an unused
# fn manifests as absent from defs and from the reachable set, and the
# textual strip is proven behavior-preserving by the cross-check
# harness below.
(def safe-out
  (run-callgraph "safe-fixture" `
(defn used-fn [x] (* x 2))
(defn helper [x] (+ x 1))
(defn unused-fn [x] (* x 99))
(print (used-fn 21))
(print (helper 5))
`))
(assert (not (nil? (string/find "dce safe reachable" safe-out)))
        "safe fixture reports dce safe with a reachable set")
(assert (not (nil? (string/find "reachable 0 1 2" safe-out)))
        "safe fixture reachable set is exactly the entry thunk + both used defs")
(assert (nil? (string/find "unused-fn" safe-out))
        "unused function is excluded: absent from defs and reachable set")
(assert (nil? (string/find "dce unsafe" safe-out))
        "safe fixture produces no unsafe verdict")

# --- Case 1b: the same fixture's unused function, validated by the
# cross-check harness (Piece 1a) -- proving the reachable set is
# trustworthy against real build+run output, not just self-consistent:
# stripping the fn the analysis excluded must not change behavior.
(def xcheck-exit
  (os/execute ["/bin/sh" "-c"
               (string "./build/bender tools/dce-crosscheck.janet "
                       root "/safe-fixture.janet " root "/xcheck unused-fn")]
              :p))
(assert (= 0 xcheck-exit) "cross-check harness PASSes on fixture 1's excluded name")

# --- Case 2 (pattern 1): a function value stored into a table. Note
# the EXISTING taint fixpoint does not even see this (no `dynamic`
# edge is emitted for a mktab store) -- exactly why the gate's own
# bytecode scan is a mandatory addition, not a re-derivation of
# `tainted`.
(def table-out
  (run-callgraph "table-fixture" `
(defn target-fn [x] (* x 10))
(def dispatch @{:doubler target-fn})
(print ((get dispatch :doubler) 5))
`))
(assert (not (nil? (string/find "dce unsafe pattern 1" table-out)))
        "fn stored in table reports dce unsafe pattern 1")
(assert (not (nil? (string/find "stored in container" table-out)))
        "pattern 1 diagnostic cites the container store")
(assert (not (nil? (string/find "def 0 (thunk)" table-out)))
        "pattern 1 diagnostic cites the offending def")

# --- Case 3 (pattern 2): a function value passed as a call argument.
# Maximally conservative by design: ANY function-typed value flowing
# into a call as an argument disqualifies.
(def arg-out
  (run-callgraph "arg-fixture" `
(defn apply-twice [f x] (f (f x)))
(defn triple [x] (* x 3))
(print (apply-twice triple 2))
`))
(assert (not (nil? (string/find "dce unsafe pattern 2" arg-out)))
        "fn passed as call argument reports dce unsafe pattern 2")
(assert (not (nil? (string/find "pending as call argument" arg-out)))
        "pattern 2 diagnostic cites the call argument")

# --- Case 4 (pattern 3): a dynamic call site (eval) -- caught by the
# existing taint fixpoint here, reported as the gate's own verdict.
(def dyn-out
  (run-callgraph "dyn-fixture" `
(defn used [x] (* x 2))
(defn sneaky [] (eval "(+ 1 2)"))
(print (used 5))
(print (sneaky))
`))
(assert (not (nil? (string/find "dce unsafe pattern 3" dyn-out)))
        "dynsite program reports dce unsafe pattern 3")
(assert (not (nil? (string/find "dynamic call site" dyn-out)))
        "pattern 3 diagnostic cites the dynsite taint")

(end-suite)
