# Regression: PGO seed dedup. A profile row's per-slot type mask may
# carry the same observed type more than once (union of per-origin
# evidence), but duplicates are ONE observation, not a conflict: they
# must seed. Two or more DISTINCT types in a slot are a genuine flip
# and must NOT be forced into the whole-program lattice -- the
# dispatch/joint tiers consume the complete observed signatures
# instead (see suite-native-joint-dispatch.janet).
#
# Also locks the lattice vocabulary normalization: PGO masks and
# `(type const)` spell the boolean leaf :boolean, while comparison
# writes and the emitter spell it :bool. They must join, not widen.
(import ./helper :prefix "" :exit true)
(import ../tools/infer :as infer)
(start-suite)

(defn ident [x] x)
(def defs @[@{:d (disasm ident) :name "ident"}])
(defn row [types] @{:params types :mins @[0] :maxs @[1] :calls 10})

# 1. Duplicate identical entries: dedup to one type and seed.
(def r1 (infer/analyze defs @{} @{"ident" @[(row @[@[:number :number]])]} nil))
(assert (= :number ((get (r1 :pts) 0) 0))
        "duplicate identical observation seeds one distinct type")
(assert (= :number (get (r1 :rts) 0))
        "seeded param flows into the return join")

# 2. Three-way duplicates behave the same.
(def r2 (infer/analyze defs @{}
                       @{"ident" @[(row @[@[:table :table :table]])]} nil))
(assert (= :table ((get (r2 :pts) 0) 0))
        "a triple duplicate is still one observation")

# 3. Genuine flip inside one row: no seed, conflict provenance.
(def r3 (infer/analyze defs @{} @{"ident" @[(row @[@[:array :tuple]])]} nil))
(assert (= :unknown ((get (r3 :pts) 0) 0))
        "distinct observed types never seed one lattice type")
(def p3 (get (get (r3 :pprov) 0) 0))
(assert (dictionary? (get p3 :conflict))
        "distinct observed types recorded as a conflict")
(assert (= [:array :tuple] (tuple/slice (sort (keys (get p3 :conflict)))))
        "conflict provenance names both observed types")

# 4. Different rows disagreeing is still a genuine conflict, even when
#    each individual row is internally duplicated.
(def r4 (infer/analyze defs @{}
                       @{"ident" @[(row @[@[:number :number]])
                                   (row @[@[:string :string]])]} nil))
(assert (= :unknown ((get (r4 :pts) 0) 0))
        "cross-row disagreement does not seed")

# 5. Boolean vocabulary: PGO's :boolean normalizes to the lattice's :bool.
(def r5 (infer/analyze defs @{} @{"ident" @[(row @[@[:boolean :boolean]])]} nil))
(assert (= :bool ((get (r5 :pts) 0) 0))
        "PGO :boolean seeds the :bool leaf")
(assert (= :bool (infer/narrow :bool :bool))
        "bool leaf joins itself")
(assert (= :bool (infer/narrow :unknown :bool))
        "bool leaf is reachable from unknown")

# 6. A true/false compile-time constant is the same leaf.
(assert (= :bool (infer/const-num-type @{:constants @[true]} 0))
        "constant true types as :bool")
(assert (= :bool (infer/const-num-type @{:constants @[false]} 0))
        "constant false types as :bool")

# 7. Malformed slots stay silent (historical fail-closed behavior).
(def r7 (infer/analyze defs @{} @{"ident" @[(row @[@[:number 3]])]} nil))
(assert (= :unknown ((get (r7 :pts) 0) 0))
        "non-keyword evidence never seeds")

# 8. Diagnostic selector: "1"/"all" enables every profiled function;
#    any other value is a comma-separated name list (spaces trimmed).
#    The selector is read only by the eprint path, never by seeding.
(os/setenv "JANET_SEED_DEBUG" "1")
(assert (infer/seed-debug? "anything") "'1' selects every function")
(os/setenv "JANET_SEED_DEBUG" "all")
(assert (infer/seed-debug? "anything") "'all' selects every function")
(os/setenv "JANET_SEED_DEBUG" "ctx-anim, scene-empty?")
(assert (infer/seed-debug? "ctx-anim") "name list matches a member")
(assert (infer/seed-debug? "scene-empty?") "name list trims spaces")
(assert (not (infer/seed-debug? "ctx-step-animation")) "name list rejects others")
(os/setenv "JANET_SEED_DEBUG" nil)
(assert (not (infer/seed-debug? "ctx-anim")) "diagnostic is off by default")

(end-suite)
