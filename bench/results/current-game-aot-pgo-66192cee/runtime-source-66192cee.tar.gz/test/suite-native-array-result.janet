# Native pointer-result composition: a :double caller may store an exact
# :array callee result without confusing the C pointer with a double.
(import ./helper :prefix "" :exit true)
(start-suite)
(def root (string (or (os/getenv "JANET_AOT_TEST_ROOT")
                      (os/getenv "XDG_CACHE_HOME") "/tmp")
                  "/janet-native-array-result-suite-" (os/getpid)))
(assert (nil? (os/stat root)) "test root must be unused")
(os/mkdir root)
(def source (string root "/app.janet"))
(def binary (string root "/app"))
(spit source `
(defn mut-return {:hint {:params [:array :double] :returns :array}} [a x]
  (put a 0 (+ (get a 0) x))
  a)
(defn fresh-return {:hint {:params [:array :array :double] :returns :array}} [a b x]
  (put a 0 x)
  b)
(defn composed {:hint {:params [:array :double] :returns :double}} [a x]
  (def b (mut-return a x))
  (+ (get b 0) x))
(defn distinct {:hint {:params [:array :array :double] :returns :double}} [a b x]
  (def result (fresh-return a b x))
  (+ (get result 0) (get a 0)))
(defn exact-tail {:hint {:params [:array :double] :returns :array}} [a x]
  (mut-return a x))
(defn mut-nil {:hint {:params [:array :double] :returns :nil}} [a x]
  (put a 0 x)
  nil)
(defn incompatible {:hint {:params [:double] :returns :nil}} [x]
  (mut-nil x 1.0))
(defn mixed-slot {:hint {:params [:array :double] :returns :double}} [a x]
  (var v 2)
  (if (> x 0) (set v (mut-return a x)))
  (if (> x 0) (get v 0) v))
# Generic numerical fold of eight array elements through floor/division.
# Exercises the :array -> :double tail shape without app-specific names.
(defn fold-limbs {:hint {:params [:array] :returns :double}} [d]
  (def hi (+ (get d 4) (* (get d 5) 256) (* (get d 6) 65536) (* (get d 7) 16777216)))
  (def lo (+ (get d 0) (* (get d 1) 256) (* (get d 2) 65536) (* (get d 3) 16777216)))
  (/ (+ (* hi 2097152) (math/floor (/ lo 2048))) 9007199254740992.0))
(def a @[3])
(assert (= 13 (composed a 5)) "array result read by double caller")
(assert (= 8 (a 0)) "input mutated")
(def b @[7])
(def other @[13 29])
(assert (= 22 (distinct b other 9)) "distinct array returned")
(assert (= 9 (b 0)) "input distinct from returned array")
(assert (= 13 (other 0)) "other input is the returned array")
(def c @[1])
(assert (= c (exact-tail c 2)) "tail return preserves identity")
(assert (= 3 (c 0)) "tail mutation visible")
(assert (= 2 (mixed-slot @[2] -1)) "negative branch")
(assert (= 5 (mixed-slot @[2] 3)) "positive branch")
(assert (= 0 (fold-limbs @[0 0 0 0 0 0 0 0])) "zero limbs")
(assert (= (fold-limbs @[255 255 255 255 255 255 255 255])
           (/ 9007199254740991 9007199254740992.0)) "max limbs exact")
(assert (< 0 (fold-limbs @[7 42 99 202 6 17 81 10])) "mixed limbs")
(assert (= :rejected (try (mut-return 7 2) ([_] :rejected))) "wrong array type guarded")
(assert (= :rejected (try (apply mut-return [@[1]]) ([_] :rejected))) "wrong arity guarded")
(assert (= :rejected (try (incompatible 7) ([_] :rejected))) "incompatible direct call boxed")
`)
(def env (merge @{} (os/environ)
                {"JANET_NO_PROFILE" "1"
                 "XDG_CACHE_HOME" (or (os/getenv "XDG_CACHE_HOME") root)}))
(assert (= 0 (os/execute ["./build/bender" "--aot" source "--native"
                          "--no-auto-pgo" "-o" binary] :e env))
        "native build succeeds")
(def names (string (slurp (string binary "-native/native-names.txt"))))
(each name ["mut-return" "fresh-return" "composed" "distinct" "exact-tail" "mut-nil" "fold-limbs"]
  (assert (string/find name names) (string "native name " name)))
(each name ["incompatible" "mixed-slot"]
  (assert (not (string/find name names)) (string "boxed name " name)))
(def ccode (slurp (string binary "-native/native.c")))
(assert (string/find "JanetArray*" ccode) "array C pointer type")
(assert (string/find "= mut_return(" ccode) "direct array result assignment")
(assert (string/find "= fresh_return(" ccode) "distinct array direct assignment")
(assert (= 0 (os/execute [binary] :e env)) "native parity assertions")
(assert (= 0 (os/execute ["./build/bender" source] :e env)) "interpreter parity assertions")
(end-suite)
