# Copyright (c) 2026 Calvin Rose & contributors
# MIT-licensed; see suite-ev.janet for the full text.

# Cross-lane channel safety.
#
# A plain ev/chan takes no lock and copies nothing, so it is only meaningful
# inside the VM that created it. A proc spawned onto a worker lane receives a
# MARSHALLED COPY of the closure, so its view of the channel is detached: writes
# land in a copy nobody reads. The runtime must say so loudly rather than
# silently dropping every value.

(import ./helper :prefix "" :exit true)
(start-suite)

# Channels are pinned to the lane that created them.
(def c (ev/chan 4))
(ev/give c :a)
(assert (= :a (ev/take c)) "own-lane give/take round-trips")

# A worker lane runs the thunk, but its closure is marshal-COPIED: captured
# mutable state is detached, so observation must cross lanes explicitly.
(proc/lanes-start 1)
(def ran (ev/thread-chan 8))
(proc/spawn (fn [] (ev/give ran :ran)) 8)
(ev/sleep 0.4)
(assert (= :ran (ev/take ran)) "worker lane ran the thunk (observed via thread-chan)")

# A worker lane receives a MARSHALLED COPY of captured values, so a plain
# channel it looks at belongs to another lane. Using it must raise, not
# silently swallow the value.
(def plain (ev/chan 8))
(def err-ch (ev/thread-chan 4))
(proc/spawn (fn []
              (try (ev/give plain :lost)
                   ([e] (ev/give err-ch (string e)))))
            8)
(ev/sleep 0.5)
(assert (nil? (ev/try-take plain))
        "a worker lane's write never reaches the original plain channel")
(def emsg (ev/take err-ch))
(assert (string/find "MARSHALLED COPY" emsg)
        (string "plain channel from a worker lane must error loudly, got: " emsg))

# A same-thread marshal round-trip on the MAIN VM stays legal.
(def rt (-> (do (def rtch (ev/chan 4)) (ev/give rtch :v) rtch) marshal unmarshal))
(assert (= :v (ev/take rt)) "main-VM marshal round-trip of a channel still works")

# thread-chan DOES cross lanes.
(def tchan (ev/thread-chan 8))
(proc/spawn (fn [] (ev/give tchan :kept)) 8)
(ev/sleep 0.5)
(assert (= :kept (ev/take tchan)) "thread-chan carries values across lanes")

# A cross-lane spawn MARSHALS the closure, so a mutable capture would arrive
# detached. Rather than erroring, such a proc is placed on THIS VM: capturing a
# mutable value means "I share state with you", and only a same-VM spawn honours
# that. The proc still runs concurrently; only independent procs use lanes.
(defn make-mutator []
  (def seen @[])
  (fn [] (array/push seen 1)))

# NOTE: the capture must be LEXICAL -- the array has to be LOCAL to an enclosing
# function. A top-level (def seen @[]) is a global lookup even when referenced
# from inside a defn, so it is (rightly) not a capture at all.
(defn spawn-with-shared-capture []
  (def seen @[])
  (def p (proc/spawn (fn [] (array/push seen 7)) 8))
  [p seen])

(def pair (spawn-with-shared-capture))
(def placed (pair 0))
(def seen (pair 1))

# Placement is the observable: a local core/proc object means this VM (sharing
# the capture), a tuple would mean a lane (and a detached copy).
(assert (not (tuple? placed))
        "a proc capturing mutable state must be placed on this VM, not a lane")

(ev/sleep 0.1)
(assert (deep= @[7] seen)
        (string "the shared capture must actually be mutated, got: " seen))

# A capture-free closure still distributes across lanes.
(def clean-ok (try (do (proc/spawn (fn [] 7) 8) true) ([_e] false)))
(assert clean-ok "a capture-free closure still spawns across lanes")

(proc/lanes-stop)

(end-suite)
