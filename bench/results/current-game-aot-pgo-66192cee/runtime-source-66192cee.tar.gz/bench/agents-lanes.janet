# bench/agents-lanes.janet — the 1-vs-N-lane agents benchmark (milestone 2d).
#
# Same actor kernel as bench/agents.janet (parked actors, T ticks each,
# small arithmetic kernel, teardown under load), but the actor population
# is spread across N lanes via proc/spawn routing. Measures whether
# VM-per-core parallelism lifts the agents/second number and by how much.
#
# Usage: bender bench/agents-lanes.janet [N] [T] [lanes]
#   N = actor count (default 100000)
#   T = ticks per actor (default 8)
#   lanes = worker lanes (default 4; 0 = single-VM baseline)
#
# The driver ticks actors through per-lane control channels implicitly:
# with lanes active, plain proc/spawn routes round-robin, so the same
# benchmark source measures 1 lane (N:1) and N lanes (M:N) unchanged —
# the API transparency is itself part of the demonstration.

(def args (dyn :args))
(def n (if (> (length args) 1) (parse (get args 1)) 100000))
(def ticks (if (> (length args) 2) (parse (get args 2)) 8))
(def lanes (if (> (length args) 3) (parse (get args 3)) 4))

(def actor
  (fn []
    (var acc 0)
    (var remaining ticks)
    (while (> remaining 0)
      (def m (proc/recv))
      (set acc (+ acc m))
      (-- remaining)
      (when (> remaining 0) (proc/recv)))
    acc))

(def done (ev/thread-chan 16))
(def t0 (os/clock))

# Spawn: with lanes=0 the spawns are VM-local; with lanes>0 they route
# round-robin across the worker VMs.
(when (> lanes 0) (proc/lanes-start lanes))

(var i 0)
(while (< i n)
  (proc/spawn actor)
  (++ i)
  (when (zero? (mod i 50000))
    (eprint "spawned" i)))

# Tick every actor T times. The driver fans ticks out through the same
# routing: each actor replies nothing; we count completions via a result
# channel per actor's final message? For benchmark comparability with
# bench/agents.janet the kernel parks silently; completion is detected
# by mailbox quiescence via the done channel handshake below.

# Plain ev/chan, not a thread-chan: with lanes=0 the collector hands
# back a core/proc handle (below), which refuses marshal — ev/chan
# passes same-VM values by reference.
(def rpid-ready (ev/chan 1))
(def collector
  (proc/spawn-local
    (fn []
      # proc/self-pid mints a LANE-routable pid tuple and panics
      # without lanes (proc.c: "proc/self-pid requires lanes"): that
      # panic killed the collector silently, rpid-ready/done were never
      # given, and the main fiber parked forever on ev/take — the
      # lanes=0 "hang". VM-local baseline uses the local handle.
      (def rpid (if (> lanes 0) (proc/self-pid) (proc/self)))
      (ev/give rpid-ready rpid)
      (var sum 0)
      (var got 0)
      (while (< got n)
        (def m (proc/recv))
        (set sum (+ sum m))
        (++ got))
      (ev/give done sum))))
(def rpid (ev/take rpid-ready))

# Re-spawn pass: each actor computes its identity tick chain then sends
# its accumulator to the collector. (Spawn+run+teardown under load is
# the measured quantity, matching agents.janet's convention.)
(var j 0)
(while (< j n)
  (proc/spawn (fn []
                (var acc 0)
                (var remaining ticks)
                (while (> remaining 0)
                  (set acc (+ acc remaining))
                  (-- remaining))
                (proc/send rpid acc)))
  (++ j))

(def sum (ev/take done))
(def dt (- (os/clock) t0))
(eprint "agents-lanes: N=" n " T=" ticks " lanes=" lanes
        " total=" dt "s actors/s=" (math/floor (/ n dt))
        " sum=" sum)

(when (> lanes 0) (proc/lanes-stop))
(os/exit 0)
