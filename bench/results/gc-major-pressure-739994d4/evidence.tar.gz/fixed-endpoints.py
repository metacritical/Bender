import os, pathlib, subprocess, time, signal, json, hashlib
D=pathlib.Path('/tmp/janet-forward-455-evidence'); G=D/'game-source'
arms=[('fixed-profile','/tmp/janet-forward-fixed-739994d4/build/bender',True),('fixed-off','/tmp/janet-forward-fixed-739994d4/build/bender',False)]
for tag,exe,profile in arms:
 env=dict(os.environ)
 for k in list(env):
  if k.startswith(('JANET_','BENDER_')):env.pop(k)
 env['JANET_LANES']='0'; env['XDG_CACHE_HOME']=str(D/('cache-'+tag))
 if not profile:env['JANET_NO_PROFILE']='1'
 cmd=[exe,str(G/'main.janet'),'--frames','6000','--uncapped'];start=time.monotonic();peak=0;reason=None;samples=[]
 with (D/(tag+'.stdout')).open('w') as o,(D/(tag+'.stderr')).open('w') as e:
  p=subprocess.Popen(cmd,cwd=G,env=env,stdout=o,stderr=e,start_new_session=True)
  while p.poll() is None:
   q=subprocess.run(['/bin/ps','-o','rss=,%cpu=','-p',str(p.pid)],capture_output=True,text=True).stdout.split()
   if len(q)==2:
    peak=max(peak,int(q[0]));samples.append([round(time.monotonic()-start,3),int(q[0]),float(q[1])])
   if peak>1048576:reason='rss>1GiB'
   if time.monotonic()-start>90:reason='wall>90s'
   if reason:
    os.killpg(p.pid,signal.SIGKILL);break
   try:p.wait(timeout=0.25)
   except subprocess.TimeoutExpired:pass
  rc=p.wait()
 text=(D/(tag+'.stdout')).read_text();lines=[s for s in text.splitlines() if any(k in s for k in ['frames:','steady:','worst frame:','stalls >'])]
 row=dict(tag=tag,argv=cmd,cwd=str(G),profiling=profile,exit=rc,termination_reason=reason,wall_s=time.monotonic()-start,peak_sampled_rss_kib=peak,sha256=hashlib.sha256(pathlib.Path(exe).read_bytes()).hexdigest(),summary=lines,samples=samples)
 (D/(tag+'.json')).write_text(json.dumps(row,indent=2));print({k:v for k,v in row.items() if k!='samples'},flush=True)
