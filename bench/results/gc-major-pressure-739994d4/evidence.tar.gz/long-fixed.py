import pathlib
s=pathlib.Path('/tmp/janet-forward-455-evidence/endpoints.py').read_text();a=s.index('arms=');b=s.index('\nfor tag',a)
s=s[:a]+"arms=[('survivor-soak-profile','/tmp/janet-forward-survivor-739994d4/build/bender',True)]"+s[b:]
s=s.replace("'6000'","'12000'").replace('>90:', '>150:').replace("'wall>90s'","'wall>150s'")
exec(s)
